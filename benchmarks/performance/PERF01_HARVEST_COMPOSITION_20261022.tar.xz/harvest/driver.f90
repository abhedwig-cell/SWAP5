program test_b112_retained_thermal
 use iso_fortran_env,only:real64,int64
 use ieee_arithmetic,only:ieee_value,ieee_quiet_nan
 use literal_reproductive,only:literal_n=>literal
 use mod_fmr_runtime_core
 use mod_fmr_serialized_reference_backend
 use mod_fmr_production_application_bootstrap
 use mod_kernel_transactions
 use mod_fixed_flux_top_boundary_provider
 use mod_b110_default_mvg_provider
 use MOD_grid,only:numnod,z,dz,disnod
 use mod_transaction_reference,only:transaction_state_t,TX_TEMPORAL_MODEL_CERTIFICATE
 use mod_b111_soil_n_mineral_owner
 use mod_b111_soil_n_reactive_owner
 use mod_soil_n_pool_state
 use mod_b111_soil_n_addition
 use mod_crop_soil_n_material_day
 use mod_fmr_crop_soil_n_material_application
 use mod_crop_soil_n_day
 use mod_crop_soil_n_configuration
 use mod_wofost81_crop_owner_state
 use mod_wofost81_n_owner_state,only:initialize_wofost81_n_owner_state,WOFOST81_N_OWNER_OK
 use mod_wofost_one_day_structural_evolution
 use mod_fmr_crop_soil_n_joint_application
 use mod_crop_soil_n_joint_restart_file
 use mod_fmr_b111_mineral_route,only:aggregate_mineral_trace,mineral_daily_carrier_t
 use mod_soil_n_day_environment
 use mod_crop_senescence_residue
 use mod_crop_soil_n_senescence_day
 use mod_fmr_crop_soil_n_senescence_application
 use mod_fmr_crop_soil_n_thermal_application
 use mod_fmr_soil_n_accepted_temperature
 use mod_soil_temperature_contract
 use mod_restricted_soil_temperature,only:initialize_soil_temperature_parameters
 use mod_canonical_contracts,only:canonical_numerical_config_t
 use mod_crop_soil_n_output_day
 use mod_crop_n_output_generation
 use mod_crop_soil_n_output_observation
 use mod_soil_n_crop_extended_output
 use mod_crop_soil_n_output_harvest
 implicit none
 real(real64),parameter::T0=0d0,T1=1d0,HARD_MASS_GATE=1d-10
 type(fmr_production_application_config_t)::cfg
 type(fmr_serialized_reference_backend_t)::backend,second
 type(fixed_flux_top_boundary_provider_t),target::top
 type(fmr_logical_column_t)::column
 type(kernel_committed_state_t)::water,other_water,initial_water
 type(reactive_state_t)::soil,initial_soil,after_soil
 type(crop_soil_state_t)::state,other_state,initial_state
 type(crop_soil_n_thermal_restart_t)::payload
 type(senescence_joint_result_t)::result
 type(soil_n_material_input_t)::items(2),bad_items(2)
 type(b111_soil_n_split_parameters_t)::split
 type(crop_senescence_policy_t)::policy,bad_policy
 type(crop_residue_pending_t)::pending
 logical::has_pending
 type(soil_n_day_environment_t)::env,bad_env
 type(reactive_parameters_t)::oracle_p
 type(reactive_parameters_t)::sp,bad_sp
 type(crop_n_configuration_t)::cp,bad_cp
 type(wofost81_crop_owner_state_t)::crop,after_crop
 type(wofost_one_day_forcing_t)::weather,bad_weather
 type(soil_n_pool_state_t)::pools,s
 type(fmr_b110_physical_forcing_t)::invalid
 real(real64),allocatable::old_crop(:),actual_crop(:)
 real(real64)::k,time,theta
 integer(int64)::revision
 integer::status
 logical::ok
 character(512)::mode,path,endpoint
 character(32)::selected
 call get_command_argument(1,mode);call get_command_argument(2,path);call get_command_argument(3,endpoint)
 call get_command_argument(4,selected)
 policy%application_age=[1.57d0,.99d0,1.57d0]
 env=soil_n_day_environment_t(0d0,1d0,5d0)
 call initialize_application_config(cfg,-75d0,k)
 call enable_heat()
 cfg%tiles(1)%template%numerical_continuation_layout_id=FMR_NUMERICAL_CONTINUATION_RICHARDS_TEMPORAL_HISTORY
 cfg%tiles(1)%base_forcing%top_flux=0d0;cfg%tiles(1)%base_forcing%bottom_flux=-.1d0
 cfg%tiles(1)%base_forcing%drainage_flux_by_level=1d-4
 cfg%tiles(1)%base_forcing%subsurface_irrigation_source=0d0
 cfg%tiles(1)%parameters%root_extraction_active=.true.
 cfg%tiles(1)%base_forcing%root_extraction_sink=1d-4
 cfg%tiles(1)%base_forcing%root_potential_transpiration=.0008d0
 cfg%numerical%transaction%temporal_mode=TX_TEMPORAL_MODEL_CERTIFICATE
 cfg%numerical%model_temporal_indicator_budget_available=.true.;cfg%numerical%model_temporal_indicator_budget=1d-4
 cfg%numerical%transaction%temporal_tolerance=0d0
 cfg%numerical%transaction%max_retries=30;cfg%numerical%max_committed_substeps=4096
 column%column_id=cfg%tiles(1)%tile_id;column%template_id=cfg%tiles(1)%template%template_id
 column%parameter_ref=1_int64;column%state_handle=1_int64;column%forcing_handle=1_int64
 column%backend_id=FMR_BACKEND_SERIALIZED_REFERENCE
 call parameters(sp);call materials(items,split);call configure_crop(cp);cp%base%nitrogen%nfix_fr=.3d0;cp%update%leaf_lifespan=100d0;cp%lai_crit_nupt=1d0
 if(trim(selected)=='old-profile')then
  allocate(cp%b111_request);cp%b111_request%dvsnlt=.9d0;cp%b111_request%nfixf=.25d0
 else if(trim(selected)/='absent')then
  allocate(cp%b111_reproductive)
  cp%b111_reproductive%dvsnlt=.9d0;cp%b111_reproductive%dvsnt=.4d0
  cp%b111_reproductive%nfixf=.25d0;cp%b111_reproductive%fntrt=.25d0
  select case(trim(selected))
  case('wrong-dvsnlt');cp%b111_reproductive%dvsnlt=.7d0
  case('wrong-dvsnt');cp%b111_reproductive%dvsnt=.3d0
  case('wrong-nfixf');cp%b111_reproductive%nfixf=.5d0
  case('wrong-fntrt');cp%b111_reproductive%fntrt=.5d0
  end select
 end if
 if(trim(selected)/='old-profile'.and.trim(selected)/='absent'.and.trim(selected)/='legacy')then
  allocate(cp%b112_return,cp%harvest)
  cp%b112_return%leaf_fraction=.25d0
  if(trim(selected)=='wrong-return')cp%b112_return%leaf_fraction=.5d0
  cp%harvest%crop_identity=1;cp%harvest%crop_end=1d0;cp%harvest%sw_harv=0;cp%harvest%sw_wofost=1
  cp%harvest%policy%return_fraction=[.5d0,.25d0,.5d0]
  cp%harvest%policy%application_age=[1.57d0,.99d0,1.57d0,1.57d0]
 endif
 cp%tables(15)%y=.02d0
 call configure_owner(crop,cp,status);call require(status==0,'WOFOST81 owner initialize')
 crop%nitrogen%value%namountlv=4d0;crop%nitrogen%value%namountst=1d0;crop%nitrogen%value%namountrt=.5d0
 crop%nitrogen%value%namountso=.5d0;crop%nitrogen%value%initial_total=6d0
 crop%nitrogen%value%namountlv=crop%nitrogen%value%namountlv-2d0
 crop%nitrogen%value%initial_total=crop%nitrogen%value%initial_total-2d0
 weather%minimum_temperature=3d0;weather%average_temperature=10d0;weather%daytime_average_temperature=15d0
 weather%global_radiation=1d7;weather%daylength_hours=12d0;weather%photoperiodic_daylength_hours=12d0
 weather%sinld=.3d0;weather%cosld=.7d0;weather%diffuse_perpendicular_radiation=100d0
 weather%daily_sine_solar_elevation_integral=30000d0
 call initialize_soil_n_pool_state(sp%mineral%inventory,spread(1d0,1,8),5d0,40d0,.02d0,.03d0,pools,status)
 call require(status==0,'soil inventory initialize')
 call backend%initialize(top);call second%initialize(top)
 if(trim(mode)=='generation-read'.or.trim(mode)=='generation-reject')then
  call output_generation_mode()
  stop
 end if
 if(trim(mode)=='harvest-resume')then
  call harvest_resume_mode()
  stop
 end if
 if(trim(mode)=='reject')then
  call read_crop_soil_n_joint_restart_file(trim(path),column,cfg%tiles(1)%template,670001_int64,9001_int64,9101_int64, &
    sp,cp,water,state,status,cfg%tiles(1)%parameters)
  call require(status/=0.and..not.water%ready().and..not.state%ready(),'invalid complete restart atomic rejection')
  print '(A)','CROP_SOIL_INVALID_DISK=PASS';stop
 end if
 if(trim(mode)=='resume')then
  block
   type(crop_ext_state_t)::d
   type(crop_ext_row_t),allocatable::rows(:)
   character(10),allocatable::dates(:)
   call read_crop_n_output_generation(trim(path)//'.generation',column,cfg%tiles(1)%template, &
    670001_int64,9001_int64,9101_int64,sp,cp,water,state,d,dates,rows,status,cfg%tiles(1)%parameters)
   call require(status==0,'fresh thermal output-only joint reconstruction')
  end block
  call second_day(backend,water,state)
  call finish_harvest(water,state,trim(endpoint)//'.fresh-stages')
  call write_crop_soil_n_joint_restart_file(trim(endpoint),column,cfg%tiles(1)%template,670001_int64,water,state,status)
  call require(status==0,'fresh complete endpoint')
  print '(A)','CROP_SOIL_FRESH_PROCESS_CONTINUATION=PASS';stop
 end if
 call initialize_thermal_water(water)
 theta=sum(dz*cfg%tiles(1)%initial_state%water_content)/sum(dz)
 call initialize_reactive(sp,9001_int64,0d0,theta,pools,soil,status);call require(status==0,'reactive initialize')
 call initialize_crop_soil(soil,crop,cp,9101_int64,state,status);call require(status==0,'three-owner initialize')
 call state%snapshot(after_soil,crop)
 initial_water=water;initial_state=state;initial_soil=soil;old_crop=pack_crop_n_owner(crop)
 call write_crop_soil_n_joint_restart_file(trim(endpoint)//'.initial',column,cfg%tiles(1)%template,670001_int64,water,state,status)
 call require(status==0,'thermal live empty native phase')
 bad_items=items;bad_items(2)%kind=999
 call run_selected(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water, &
   cfg%tiles(1)%base_forcing,cfg%numerical,state,weather,0d0,1d0,bad_items,split,policy,result,env)
 call require(result%status/=0,'late material rejects whole batch');call unchanged()

 invalid=cfg%tiles(1)%base_forcing;invalid%root_extraction_sink=-1d0
 call run_selected(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water,invalid, &
    cfg%numerical,state,weather,0d0,1d0,items,split,policy,result,env)
 call require(result%status/=0,'water rejected');call unchanged()
 invalid=cfg%tiles(1)%base_forcing;invalid%top_flux=-.001d0
 call run_selected(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water,invalid, &
    cfg%numerical,state,weather,0d0,1d0,items,split,policy,result,env)
 call require(result%status==JOINT_CHEMICAL_REJECTED,'carrier rejects after actual water trial');call unchanged()
 bad_weather=weather;bad_weather%average_temperature=ieee_value(0d0,ieee_quiet_nan)
 call run_selected(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water, &
    cfg%tiles(1)%base_forcing,cfg%numerical,state,bad_weather,0d0,1d0,items,split,policy,result,env)
 call require(result%status==JOINT_CHEMICAL_REJECTED,'crop forcing rejects after actual water trial');call unchanged()
 block
  type(crop_soil_state_t)::bad_state
  type(kernel_committed_state_t)::bad_water
  bad_sp=sp;bad_sp%organic_reference%ratecon_bio=0d0;bad_sp%organic_reference%ratecon_hum=0d0
  call initialize_reactive(bad_sp,9001_int64,0d0,theta,pools,after_soil,status)
  call initialize_crop_soil(after_soil,crop,cp,9101_int64,bad_state,status)
  call require(status==0,'stage singular organic trial')
  bad_water=water
  call run_selected(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,bad_water, &
    cfg%tiles(1)%base_forcing,cfg%numerical,bad_state,weather,0d0,1d0,items,split,policy,result,env)
  call require(result%status==JOINT_CHEMICAL_REJECTED,'reaction rejects after actual crop preparation')
  call require(bad_water%current_revision()==water%current_revision(),'reaction no water leak')
  call bad_state%snapshot(after_soil,after_crop);actual_crop=pack_crop_n_owner(after_crop)
  call require(all(actual_crop==old_crop),'reaction no crop leak')
 end block
 bad_policy=policy;bad_policy%application_age(3)=100.01d0
 call run_selected(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water, &
    cfg%tiles(1)%base_forcing,cfg%numerical,state,weather,0d0,1d0,items,split,bad_policy,result,env)
 call require(result%status/=0,'late invalid pending material after actual water crop');call unchanged()
 call run_selected(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water, &
    cfg%tiles(1)%base_forcing,cfg%numerical,state,weather,0d0,1d0,items,split,policy,result,env)
 if(result%status/=0)print *,'diagnostics',result%status,result%joint%joint%water%status,result%joint%joint%chemical%status,result%joint%joint%chemical%soil%status
 call require(result%status==JOINT_OK,'actual Richards WOFOST81 material N valid retry')
 call require(result%senescence%materials%gross_n>0d0.and.result%senescence%materials%volatilized_n>0d0.and. &
   abs(result%senescence%materials%residual)<=1d-12,'material plus day whole N')
 call require(abs(result%joint%joint%chemical%whole_n_residual)<=1d-12,'hard soil crop whole N balance')
 call require(result%joint%joint%chemical%internal_supply_kg_m2>0d0.and.result%joint%joint%chemical%fixation_kg_m2>0d0,'soil debit plus WOFOST81 fixation')
 call require(result%joint%joint%chemical%internal_supply_kg_m2<result%joint%joint%chemical%prepared%nitrogen_request%soil_request*1d-4,'actual limited supply')
 call literal_actual()
 call first_output_day()
 call source_n(crop,after_crop,result%joint%joint%chemical)
 call require(result%joint%joint%chemical%crop%rntranslocation_applied>0d0,'active source storage and multi donor transfer')
 call state%pending_snapshot(pending,has_pending)
 call require(has_pending.and.all(pending%dry_matter_kg_ha(1:2)>0d0).and.pending%dry_matter_kg_ha(3)==0d0.and.result%senescence%incorporated_n==0d0,'source root/partial leaf pending and retained stem')
 call state%snapshot(after_soil,after_crop)
 call require(after_crop%nitrogen%b112_residue_profile.and.all(after_crop%nitrogen%retained_dead_n>0d0),'nonzero actual retained N')
 call require(all(after_crop%crop%biomass%retained_dead_biomass>0d0),'nonzero actual retained DM')
 call require(abs(result%senescence%whole_n_residual)<=1d-12,'pending included whole N')
 block
  real(real64),allocatable::before(:),after(:)
  integer(int64)::water_revision
  call state%snapshot(after_soil,after_crop);before=pack_crop_n_owner(after_crop);water_revision=water%current_revision()
  call run_selected(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water, &
    cfg%tiles(1)%base_forcing,cfg%numerical,state,weather,0d0,1d0,items,split,policy,result,env)
  call require(result%status/=0,'consumed batch cannot replay')
  call state%snapshot(after_soil,after_crop);after=pack_crop_n_owner(after_crop)
  call require(all(before==after).and.water%current_revision()==water_revision,'replay no owner leak')
 end block
 call export_crop_soil_n_thermal_restart(column,cfg%tiles(1)%template,670001_int64,water,state,payload,status)
 call require(status==0,'opaque complete export')
 call write_crop_soil_n_joint_restart_file(trim(path),column,cfg%tiles(1)%template,670001_int64,water,state,status)
 call require(status==0,'complete disk export')
 other_water=kernel_committed_state_t();other_state=crop_soil_state_t()
 call restore_crop_soil_n_thermal_restart(payload,column,cfg%tiles(1)%template,670001_int64,9999_int64,other_water,other_state,status)
 call require(status/=0.and..not.other_water%ready().and..not.other_state%ready(),'opaque wrong crop identity atomic')
 call restore_crop_soil_n_thermal_restart(payload,column,cfg%tiles(1)%template,670001_int64,9101_int64,other_water,other_state,status)
 call require(status==0,'opaque complete restore')
 call second_day(backend,water,state);call second_day(second,other_water,other_state)
 call finish_harvest(water,state,trim(endpoint)//'.stages')
 call finish_harvest(other_water,other_state,trim(endpoint)//'.opaque-stages')
 call write_crop_soil_n_joint_restart_file(trim(endpoint),column,cfg%tiles(1)%template,670001_int64,water,state,status)
 call require(status==0,'continuous complete endpoint')
 call write_crop_soil_n_joint_restart_file(trim(endpoint)//'.opaque',column,cfg%tiles(1)%template,670001_int64,other_water,other_state,status)
 call require(status==0,'opaque complete endpoint')
 print '(A)','B112_THERMAL_RETAINED_PENDING_HARVEST_OPAQUE_NATIVE=PASS'
contains
 include 'harvest_output_proof.inc'
 include 'thermal_output_proof.inc'
 subroutine run_selected(backend,column,template,parameters,water,forcing,config,chemical,weather,t0,t1,items,split,policy,result,environment)
  type(fmr_serialized_reference_backend_t),intent(inout)::backend
  type(fmr_logical_column_t),intent(in)::column
  type(fmr_template_t),intent(in)::template
  type(fmr_b110_physical_parameters_t),target,intent(in)::parameters
  type(kernel_committed_state_t),intent(inout)::water
  type(fmr_b110_physical_forcing_t),intent(in)::forcing
  type(canonical_numerical_config_t),intent(in)::config
  type(crop_soil_state_t),intent(inout)::chemical
  type(wofost_one_day_forcing_t),intent(in)::weather
  real(real64),intent(in)::t0,t1
  type(soil_n_material_input_t),intent(in)::items(2)
  type(b111_soil_n_split_parameters_t),intent(in)::split
  type(crop_senescence_policy_t),intent(in)::policy
  type(senescence_joint_result_t),intent(out)::result
  type(soil_n_day_environment_t),optional,intent(in)::environment
  call run_crop_soil_n_thermal_interval(backend,column,template,parameters,water,forcing,config, &
   chemical,weather,t0,t1,items,split,policy,result)
 end subroutine
 subroutine finish_harvest(w,n,prefix)
  type(kernel_committed_state_t),intent(inout)::w
  type(crop_soil_state_t),intent(inout)::n
  character(*),intent(in)::prefix
  type(crop_soil_harvest_receipt_t)::receipt
  type(crop_soil_harvest_observation_t)::observation
  type(crop_soil_state_t)::disk
  type(kernel_committed_state_t)::disk_water
  type(reactive_state_t)::chemical
  type(wofost81_crop_owner_state_t)::owner
  type(wofost81_harvest_record_t)::h
  real(real64)::before_n,before_dm
  logical::has
  integer::code
  before_n=crop_soil_whole_n(n);before_dm=crop_soil_organic_mass(n)
  call harvest_crop_soil_boundary(n,receipt)
  if(receipt%status/=0)print *,'joint harvest rejected',receipt%rejection_stage
  call require(receipt%status==0,'actual Richards accepted-boundary harvest')
  call n%snapshot(chemical,owner);call owner%harvest_snapshot(h,has)
  call require(has.and.all(owner%nitrogen%retained_dead_n==0d0),'harvest clears physical retained N once')
  call require(abs(before_n-crop_soil_whole_n(n)-sum(h%exported_n)*1d-4)<1d-12,'actual harvest whole N')
  call require(abs(before_dm-crop_soil_organic_mass(n)-sum(h%exported_dm)*1d-4)<1d-12,'actual harvest whole OM')
  call write_crop_soil_n_joint_restart_file(prefix//'.harvest-pending',column,cfg%tiles(1)%template,670001_int64,w,n,code)
  call require(code==0,'selected native harvest/pending version')
  call read_crop_soil_n_joint_restart_file(prefix//'.harvest-pending',column,cfg%tiles(1)%template,670001_int64,9001_int64,9101_int64, &
    sp,cp,disk_water,disk,code,cfg%tiles(1)%parameters)
  call require(code==0,'native retained harvest snapshot reconstructs before incorporation')
  call consume_crop_soil_harvest_pending(n,receipt);call require(receipt%status==0,'accepted harvest and daily pending incorporate')
  call consume_crop_soil_harvest_pending(disk,receipt);call require(receipt%status==0,'restored harvest incorporates once')
  call write_crop_soil_n_joint_restart_file(prefix//'.consumed',column,cfg%tiles(1)%template,670001_int64,w,n,code)
  call require(code==0,'selected native consumed harvest version')
  call write_crop_soil_n_joint_restart_file(prefix//'.disk-consumed',column,cfg%tiles(1)%template,670001_int64,disk_water,disk,code)
  call require(code==0,'restored native consumed harvest version')
  call observe_crop_soil_harvest(n,observation,code);call require(code==0,'harvest observation is same-owner receipt')
  call acknowledge_crop_soil_harvest(n,observation,receipt);call require(receipt%status==0,'retire acknowledged harvest')
  call n%snapshot(chemical,owner)
  call require(owner%harvest_retired().and.owner%nitrogen%b112_residue_profile,'retired profile identity remains explicit')
 end subroutine
 subroutine literal_actual()
  type(fmr_serialized_physical_observation_t)::obs
  type(mineral_state_t)::base
  type(mineral_daily_carrier_t)::c
  type(soil_n_pool_state_t)::want,staged
  integer::i
  real(real64)::nit,denit,carbon,supply,literal(12)
  obs=backend%observation();call initial_soil%mineral_snapshot(base)
  call aggregate_mineral_trace(base,obs%accepted_water_flux_substeps,c,status);call require(status==0,'actual validated carrier')
  staged=pools
  do i=1,2
   call literal_material(items(i)%kind,items(i)%material,split,literal)
   staged%fom_kg_m3=staged%fom_kg_m3+literal(1:8);staged%humus_kg_m3=staged%humus_kg_m3+literal(9)
   staged%ammonium_n_kg_m2=staged%ammonium_n_kg_m2+literal(10);staged%nitrate_n_kg_m2=staged%nitrate_n_kg_m2+literal(11)
  end do
  oracle_p=sp;oracle_p%environment%temperature_c=accepted_literal_temperature(water,0d0,1d0)
  call require(result%joint%joint%chemical%soil%environment_forcing_used.and.result%joint%joint%chemical%soil%temperature_used_c==accepted_literal_temperature(water,0d0,1d0),'actual material first temperature')
  call literal_crop_day(oracle_p,staged,c%water_start,c%water_end,c%outflow,c%in_bottom,c%in_lateral,c%root_water,want, &
    nit,denit,carbon,result%joint%joint%chemical%prepared%nitrogen_request%soil_request,.5d0,4d0,30d0,1d0,1d0,supply)
  call state%snapshot(after_soil,after_crop);call after_soil%snapshot(time,theta,s,revision)
  call require(abs(supply-result%joint%joint%chemical%internal_supply_kg_m2)<=1d-12,'actual literal soil supply')
  call require(abs(s%ammonium_n_kg_m2-want%ammonium_n_kg_m2)<=1d-12.and. &
    abs(s%nitrate_n_kg_m2-want%nitrate_n_kg_m2)<=1d-12,'actual literal full NH4 NO3 state')
  call require(maxval(abs(s%fom_kg_m3-want%fom_kg_m3))<=1d-12.and.abs(s%biomass_kg_m3-want%biomass_kg_m3)<=1d-12.and.abs(s%humus_kg_m3-want%humus_kg_m3)<=1d-12,'literal actual eight FOM biomass humus')
  call require(time==1d0.and.revision==1,'joint daily consumed clock')
 end subroutine
 subroutine unchanged()
  call require(water%current_revision()==initial_water%current_revision(),'water revision unchanged')
  call state%snapshot(after_soil,after_crop);actual_crop=pack_crop_n_owner(after_crop)
  call require(all(actual_crop==old_crop),'crop mass N cohorts history unchanged')
  call after_soil%snapshot(time,theta,s,revision)
  call require(time==0d0.and.revision==0.and.all(s%fom_kg_m3==pools%fom_kg_m3).and. &
    s%ammonium_n_kg_m2==pools%ammonium_n_kg_m2.and.s%nitrate_n_kg_m2==pools%nitrate_n_kg_m2,'soil rollback')
 end subroutine
 subroutine second_day(b,w,n)
  type(fmr_serialized_reference_backend_t),intent(inout)::b
  type(kernel_committed_state_t),intent(inout)::w
  type(crop_soil_state_t),intent(inout)::n
  type(fmr_b110_physical_forcing_t)::forcing
  type(senescence_joint_result_t)::r
  type(soil_n_day_environment_t)::next_env
  type(reactive_state_t)::prior_soil
  type(wofost81_crop_owner_state_t)::prior_crop
  type(mineral_state_t)::base
  type(mineral_daily_carrier_t)::carrier
  type(fmr_serialized_physical_observation_t)::obs
  type(soil_n_pool_state_t)::prior_pools,staged,want,got
  type(crop_residue_pending_t)::old_pending,new_pending
  type(b111_soil_n_material_t)::m(3)
  real(real64)::clock,moisture,literal(12),nit,denit,carbon,supply,lai_before
  logical::has
  integer(int64)::rev
  integer::i,code
  type(kernel_committed_state_t)::automatic_water,before_water
  type(crop_soil_state_t)::automatic_soil,before_soil
  type(crop_ext_state_t)::diagnostic,manual
  type(crop_ext_row_t)::manual_row
  type(crop_ext_row_t),allocatable::output_rows(:)
  character(10),allocatable::output_dates(:)
  type(senescence_joint_result_t)::automatic_result
  integer::output_code
  call read_crop_n_output_generation(trim(path)//'.generation',column,cfg%tiles(1)%template, &
   670001_int64,9001_int64,9101_int64,sp,cp,automatic_water,automatic_soil,diagnostic,output_dates,output_rows, &
   output_code,cfg%tiles(1)%parameters)
  call require(output_code==0,'thermal first-day diagnostic reconstruction')
  before_water=automatic_water;before_soil=automatic_soil;manual=diagnostic
  next_env=soil_n_day_environment_t(1d0,2d0,30d0)
  call n%snapshot(prior_soil,prior_crop);call prior_soil%snapshot(clock,moisture,prior_pools,rev)
  call n%pending_snapshot(old_pending,has);call require(has,'restart retains yesterday physical material')
  call prior_crop%crop%derive_actual_leaf_area_index(cp%stem_area,cp%storage_area,lai_before,code)
  forcing=cfg%tiles(1)%base_forcing;forcing%bottom_flux=.1d0;forcing%drainage_flux_by_level=0d0
  forcing%soil_temperature%prescribed_surface_temperature_c=30d0
  call run_selected(b,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w,forcing, &
    cfg%numerical,n,weather,1d0,2d0,items,split,policy,r,next_env)
  if(r%status/=0)print *,'day2 diagnostics',r%status,r%joint%joint%water%status,r%joint%joint%chemical%status,r%joint%joint%chemical%soil%status
  call require(r%status==0,'actual inflow plus material crop N continuation')
  call run_crop_soil_n_output_day(trim(endpoint)//'.generation','1900-01-03',.true.,670001_int64,b,column, &
   cfg%tiles(1)%template,cfg%tiles(1)%parameters,automatic_water,forcing,cfg%numerical,automatic_soil,weather, &
   1d0,2d0,items,split,policy,diagnostic,output_dates,output_rows,automatic_result,output_code, &
   csv_path=trim(endpoint)//'.csv')
  call require(output_code==OUTPUT_DAY_OK.and.size(output_rows)==1,'actual second thermal output generation')
  call observe_accepted_crop_soil_n_day(manual,before_water,before_soil,w,n,r,1d0,2d0,.true.,manual_row, &
   output_code,thermal=.true.)
  call require(output_code==0.and.diagnostic_equal(manual,diagnostic),'automatic thermal second report exact')
  call require(output_rows(1)%values(3)==old_pending%dry_matter_kg_ha(2)+old_pending%dry_matter_kg_ha(3), &
   'thermal output uses saved previous surface residues')
  call require(output_rows(1)%values(6)==old_pending%dry_matter_kg_ha(1),'thermal output uses saved root residues')
  call write_crop_soil_n_joint_restart_file(trim(endpoint)//'.automatic-inner',column,cfg%tiles(1)%template, &
   670001_int64,automatic_water,automatic_soil,output_code);call require(output_code==0,'automatic thermal second state')
  call write_crop_soil_n_joint_restart_file(trim(endpoint)//'.ordinary-inner',column,cfg%tiles(1)%template, &
   670001_int64,w,n,output_code);call require(output_code==0,'ordinary thermal second state')

  call require(r%joint%joint%chemical%soil%environment_forcing_used.and.r%joint%joint%chemical%soil%temperature_used_c==accepted_literal_temperature(w,1d0,2d0),'second material day new temperature')
  call require(sp%environment%temperature_c==20d0.and.next_env%temperature_c==30d0,'immutable configuration and forcing')
  obs=b%observation();call prior_soil%mineral_snapshot(base)
  call aggregate_mineral_trace(base,obs%accepted_water_flux_substeps,carrier,code);call require(code==0,'second actual carrier')
  staged=prior_pools;call build_pending_residue_materials(old_pending,m,code)
  do i=1,5
   if(i<=3)then;call literal_material(2,m(i),split,literal)
   else;call literal_material(items(i-3)%kind,items(i-3)%material,split,literal);end if
   staged%fom_kg_m3=staged%fom_kg_m3+literal(1:8);staged%humus_kg_m3=staged%humus_kg_m3+literal(9)
   staged%ammonium_n_kg_m2=staged%ammonium_n_kg_m2+literal(10);staged%nitrate_n_kg_m2=staged%nitrate_n_kg_m2+literal(11)
  end do
  oracle_p=sp;oracle_p%environment%temperature_c=accepted_literal_temperature(w,1d0,2d0)
  call literal_crop_day(oracle_p,staged,carrier%water_start,carrier%water_end,carrier%outflow,carrier%in_bottom,carrier%in_lateral,carrier%root_water, &
   want,nit,denit,carbon,r%joint%joint%chemical%prepared%nitrogen_request%soil_request,prior_crop%crop%development_stage,lai_before,30d0,1d0,1d0,supply)
  call n%snapshot(after_soil,after_crop);call after_soil%snapshot(clock,moisture,got,rev)
  call require(maxval(abs(got%fom_kg_m3-want%fom_kg_m3))<=1d-12.and.abs(got%biomass_kg_m3-want%biomass_kg_m3)<=1d-12.and. &
   abs(got%humus_kg_m3-want%humus_kg_m3)<=1d-12.and.abs(got%ammonium_n_kg_m2-want%ammonium_n_kg_m2)<=1d-12.and. &
   abs(got%nitrate_n_kg_m2-want%nitrate_n_kg_m2)<=1d-12.and.abs(supply-r%joint%joint%chemical%internal_supply_kg_m2)<=1d-12,'second full literal state and supply')
  call require(abs(r%senescence%materials%residual)<=1d-12.and.r%senescence%materials%gross_n>0d0,'second batch whole N')
  call require(r%senescence%incorporated_n==old_pending%nitrogen_kg_m2().and.abs(r%senescence%whole_n_residual)<=1d-12,'delayed internal transfer full whole N')
  call source_n(prior_crop,after_crop,r%joint%joint%chemical)
  call n%pending_snapshot(new_pending,has);call require(has.and.new_pending%clock==2d0,'new day replaces consumed pending once')
  call require(r%joint%joint%chemical%soil%external_in>0d0.and.abs(r%joint%joint%chemical%whole_n_residual)<=1d-12,'inflow whole soil crop N')
  call harvest_output_proof(trim(endpoint)//'.harvest',automatic_water,automatic_soil, &
   diagnostic,output_dates,output_rows)
 end subroutine
 subroutine source_n(before,after,day)
  type(wofost81_crop_owner_state_t),intent(in)::before,after
  type(crop_soil_receipt_t),intent(in)::day
  real(real64)::want(8),loss(3),trans(3),uptake(3),requests(6),x(3),pv(4),m(4),dead(3),nmaxlv
  integer::code
  pv=[cp%b111_reproductive%dvsnlt,cp%b111_reproductive%dvsnt,cp%b111_reproductive%nfixf,cp%b111_reproductive%fntrt]
  ! The fixture has a constant maximum concentration table.
  nmaxlv=.02d0
  associate(q=>day%prepared)
   m=[q%wlv_before,q%wst_before,q%wrt_before,q%wso_before];dead=[q%drlv,q%drst,q%drrt]
   call literal_n(cp%base%nitrogen%donor_view(),pv,before%nitrogen%value,before%crop%development_stage, &
     nmaxlv,m,dead,q%corrected_rates%relative_transpiration_used,day%internal_supply_kg_m2*1d4, &
     want,loss,trans,uptake,requests,x)
  end associate
  associate(n=>after%nitrogen%value)
   call require(maxval(abs([n%namountlv,n%namountst,n%namountrt,n%namountso,n%nuptake_total,n%nfix_total, &
    n%nlosses_total,n%initial_total]-want))<=1d-12,'actual joint literal source N all organs ledgers')
  end associate
  call require(all([day%crop%rndeathlv,day%crop%rndeathst,day%crop%rndeathrt]==loss),'joint residual death source')
  call require(all([day%crop%rntranslocationlv_applied,day%crop%rntranslocationst_applied, &
    day%crop%rntranslocationrt_applied]==trans),'joint source donor partitions')
  call require(abs(day%crop%rntranslocation_applied-sum(trans))<=1d-12,'storage credit funded independently')
 end subroutine
 subroutine require(ok,label)
  logical,intent(in)::ok
  character(*),intent(in)::label
  if(.not.ok)then;print '(A)','FAIL '//label;error stop 1;end if
 end subroutine
 include 'crop_fixture.inc'
 include 'material_fixture.inc'
 include 'material_oracle.inc'
 include 'crop_oracle.inc'
 include 'matrix_fixture.inc'
 subroutine initialize_thermal_water(w)
  type(kernel_committed_state_t),intent(out)::w
  type(kernel_committed_state_t)::temporary
  class(transaction_state_t),allocatable::physical
  logical::available
  call fmr_new_b110_temporal_indicator_committed_state(temporary,column%column_id,cfg%tiles(1)%initial_state,0d0,available, &
   spread(0d0,1,numnod))
  call require(available,'initial temporal history')
  call temporary%snapshot(physical,available);call require(available,'initial detached physical state')
  call w%initialize(column%column_id,physical,available,0d0,cfg%tiles(1)%parameters)
  call require(available,'certified initial temporal heat water')
 end subroutine
 subroutine enable_heat()
  integer::code
  cfg%tiles(1)%parameters%soil_temperature_active=.true.
  cfg%tiles(1)%template%optional_state_layout_id=FMR_OPTIONAL_STATE_LAYOUT_RESTRICTED_SOIL_TEMPERATURE
  allocate(cfg%tiles(1)%parameters%soil_temperature,cfg%tiles(1)%initial_state%soil_temperature,cfg%tiles(1)%base_forcing%soil_temperature)
  call initialize_soil_temperature_parameters(dz,disnod(1:numnod),cfg%tiles(1)%parameters%cofgen(2,:), &
   spread(.3d0,1,numnod),spread(.2d0,1,numnod),spread(.04d0,1,numnod),cfg%tiles(1)%parameters%soil_temperature,code)
  call require(code==SOIL_TEMP_OK,'real thermal parameters')
  call initialize_soil_temperature_state([5d0,10d0,20d0,35d0],cfg%tiles(1)%initial_state%soil_temperature,code)
  call require(code==SOIL_TEMP_OK,'nonuniform real thermal profile')
  cfg%tiles(1)%base_forcing%soil_temperature%prescribed_surface_temperature_c=5d0
 end subroutine
 real(real64)function accepted_literal_temperature(w,t0,t1)result(temperature)
  type(kernel_committed_state_t),intent(in)::w
  real(real64),intent(in)::t0,t1
  class(transaction_state_t),allocatable::physical
  type(soil_temperature_field_view_t)::heat
  type(soil_n_day_environment_t)::sampled
  real(real64)::used,selected
  logical::available
  integer::code
  call w%snapshot(physical,available);call require(available,'detached accepted profile')
  select type(physical)
  class is(fmr_b110_physical_state_t)
   call build_soil_temperature_field_view(physical%soil_temperature,heat,code)
   call require(code==0,'accepted actual thermal field')
  end select
  call literal_profile(cfg%tiles(1)%parameters%dz,heat%temperature_c,.3d0,temperature,used)
  call sample_accepted_soil_n_environment(w,w%current_lineage_id(),w%current_revision(),t0,t1,.3d0,sampled,selected,code)
  call require(code==0.and.sampled%temperature_c==temperature.and.selected==used,'certified reducer matches literal accepted profile')
  call require(used==.2d0,'source strict depth boundary')
 end function
 include 'literal_profile.inc'

end program
