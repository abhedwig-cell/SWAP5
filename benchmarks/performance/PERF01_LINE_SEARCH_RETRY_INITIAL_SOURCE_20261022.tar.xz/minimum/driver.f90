program test_weather_line_search_retry
 use iso_fortran_env,only:real64,int64
 use ieee_arithmetic,only:ieee_value,ieee_quiet_nan
 use MOD_grid,only:numnod,z,dz,disnod
 use mod_soil_water_solver_contract
 use mod_b110_default_mvg_provider
 use mod_b110_source_sink_provider
 use mod_b110_root_sink_provider
 use mod_b110_dynamic_top_boundary_solver_adapter
 use mod_reference_richards_state_binding,only:FSI_TOP_MODE_DYNAMIC_PROVIDER
 use mod_reference_richards_legacy_binding
 use variables,only:fldtmin
 implicit none
 type,extends(b110_root_sink_provider_t)::unsupported_root_t
 end type
 type(unsupported_root_t),target::other_root
 type(soil_water_parameter_set_t),target::p
 type(b110_default_mvg_parameters_t),target::hp
 type(b110_default_mvg_provider_t),target::hyd
 type(b110_source_sink_provider_t),target::source
 type(b110_root_sink_provider_t),target::root
 type(b110_dynamic_top_boundary_solver_provider_t),target::top
 type(reference_richards_legacy_solver_t)::solver
 type(reference_richards_legacy_workspace_t)::warm,cold
 type(soil_water_solve_request_t)::r
 type(soil_water_solve_result_t)::v,c
 real(real64)::cof(24,4),kk(4),cc(4),dd(4),input_head(4),input_theta(4),input_pond
 real(real64),target::drain(1,4),irrigation(4),qroot(4)
 integer::i,hits,invalidations,fallbacks
 p%parameter_set_id=380038_int64;p%active_nodes=numnod
 allocate(p%z(numnod),p%dz(numnod),p%node_distance(numnod))
 p%z=z;p%dz=dz;p%node_distance=disnod(1:numnod)
 cof=0d0
 do i=1,numnod
  cof(1,i)=.032d0;cof(2,i)=.423d0;cof(3,i)=4.75d0;cof(4,i)=.0135d0
  cof(5,i)=.365d0;cof(6,i)=1.455d0;cof(7,i)=1d0-1d0/cof(6,i);cof(8,i)=cof(4,i)
  cof(10,i)=cof(3,i);cof(11,i)=.999d0;cof(12,i)=.99d0*cof(3,i)
  cof(22,i)=-1d6;cof(23,i)=1d-12
 end do
 call initialize_b110_default_mvg_parameters(hp,cof)
 hp%continuous_saturation_conductivity=.true.
 drain=0d0;irrigation=0d0;qroot=[.012646582580739821d0,.012646582580739821d0,.025293165161479642d0,.025293165161479645d0]
 call bind_b110_source_sink_provider(source,drain,irrigation,irrigation)
 call bind_b110_root_sink_provider(root,qroot)
 r%parameters=>p;r%base_state%active_nodes=4
 allocate(r%base_state%pressure_head(4),r%base_state%water_content(4))
 r%base_state%pressure_head=[.22883381555844240d0,.16227285460717916d0,.082399701465663375d0,.029150932704653389d0]
 r%base_state%ponding_depth=.26877039212919984d0;r%base_state%groundwater_level=-2d0
 r%boundary%top_mode=FSI_TOP_MODE_DYNAMIC_PROVIDER;r%boundary%bottom_mode=7
 r%numerical%consistent_provider_conductivity=.true.;r%numerical%reuse_trial_head=.true.
 r%numerical%max_iterations=20;r%numerical%max_backtracking=8
 r%numerical%conductivity_mean_method=1;r%numerical%min_step_duration=1d-10
 r%numerical%compartment_balance_tolerance=1d-12;r%numerical%total_balance_tolerance=1d-12
 r%numerical%head_abs_tolerance=1d-9;r%numerical%head_rel_tolerance=1d-9;r%numerical%ponding_tolerance=1d-12
 r%evaluation%constitutive=>hyd;r%evaluation%source_sink=>source;r%evaluation%root_sink=>root
 r%evaluation%dynamic_top_boundary=>top
 call require(.not.r%numerical%abort_failed_line_search,'typed option defaults OFF')
 r%numerical%reuse_trial_head=.false.
 input_head=r%base_state%pressure_head;input_pond=r%base_state%ponding_depth
 do i=0,4
  call prepare(.0078125d0/2d0**i)
  input_theta=r%base_state%water_content
  r%numerical%abort_failed_line_search=.false.
  call solver%solve(r,cold,c)
  r%numerical%abort_failed_line_search=.true.
  call solver%solve(r,warm,v)
  call require(v%status==c%status,'ON/OFF failure/success class')
  if(i==0)then
   call require(v%status==SW_SOLVE_RETRY_ADVISED,'failed phase never accepted')
   call require(v%diagnostics%jacobian_builds<c%diagnostics%jacobian_builds,'actual cheaper failed phase')
   print *, 'FAILED_PHASE_WORK',c%diagnostics%jacobian_builds,v%diagnostics%jacobian_builds
  else
   call require(v%status==SW_SOLVE_CONVERGED,'smaller physical step converges')
   call require(abs(v%unrounded_mass_balance_residual)<1d-12,'original hard equation gate')
   call require(maxval(abs(v%candidate_state%pressure_head-c%candidate_state%pressure_head))<1d-5,'bounded head difference')
  end if
  call require(all(r%base_state%pressure_head==input_head).and.all(r%base_state%water_content==input_theta).and. &
    r%base_state%ponding_depth==input_pond,'ON/OFF immutable request')
 end do
 ! Same inherited physical evaluator with an unrecognized dynamic type must
 ! retain the old route, rather than silently widening numerical admission.
 other_root%b110_root_sink_provider_t=root
 r%evaluation%root_sink=>other_root
 call prepare(.0078125d0)
 r%numerical%abort_failed_line_search=.false.;call solver%solve(r,cold,c)
 r%numerical%abort_failed_line_search=.true.;call solver%solve(r,warm,v)
 call require(v%status==c%status.and.v%diagnostics%jacobian_builds==c%diagnostics%jacobian_builds.and. &
    v%diagnostics%backtracking_attempts==c%diagnostics%backtracking_attempts,'unsupported provider exact fallback')
 r%evaluation%root_sink=>root
 r%request_interface_sensitivity=.true.
 r%numerical%abort_failed_line_search=.false.;call solver%solve(r,cold,c)
 r%numerical%abort_failed_line_search=.true.;call solver%solve(r,warm,v)
 call require(v%status==c%status.and.v%diagnostics%jacobian_builds==c%diagnostics%jacobian_builds.and. &
    v%diagnostics%backtracking_attempts==c%diagnostics%backtracking_attempts,'sensitivity exact fallback')
 call require(all(r%base_state%pressure_head==input_head).and.all(r%base_state%water_content==input_theta),'fallback immutable base')
 r%request_interface_sensitivity=.false.
 fldtmin=.true.
 r%numerical%abort_failed_line_search=.false.;call solver%solve(r,cold,c)
 r%numerical%abort_failed_line_search=.true.;call solver%solve(r,warm,v)
 call require(v%status==SW_SOLVE_FAILED.and.c%status==SW_SOLVE_FAILED,'legacy minimum mode remains deferred')
 call require(v%diagnostics%headcalc_calls==0.and.c%diagnostics%headcalc_calls==0,'minimum mode never enters Newton')
 call require(all(r%base_state%pressure_head==input_head).and.all(r%base_state%water_content==input_theta),'minimum rejection immutable')
 fldtmin=.false.
 print *, 'WEATHER_LINE_SEARCH_MINIMUM_DEFERRED_OFF_ON_PASS'
 print *, 'WEATHER_LINE_SEARCH_RETRY_TYPED_CONTRACT_PASS'

contains
 subroutine prepare(step)
  real(real64),intent(in)::step
  call bind_b110_default_mvg_provider(hyd,hp,step)
  call hyd%evaluate(r%base_state%pressure_head,r%base_state%water_content,kk,cc,dd)
  call bind_b110_dynamic_top_boundary_solver_provider(top,p,hp,1,r%base_state%ponding_depth,step, &
   .72d0,0d0,0d0,0d0,.0040205045155610863d0,.0040205045155610863d0,0d0,1d0,1d0,implicit_conductivity=.true.)
  r%step_duration=step
 end subroutine
 subroutine require(condition,label)
  logical,intent(in)::condition
  character(*),intent(in)::label
  if(.not.condition)then
   print *, 'WARM_CONTRACT_FAIL ',label
   error stop 1
  end if
 end subroutine
end program
