module perf_clock
 use iso_fortran_env,only:int64,real64
 implicit none
 integer(int64)::started(5)=0,total(5)=0,calls(5)=0,counts(12)=0
 contains
 subroutine perf_start(k)
 integer,intent(in)::k
 call system_clock(started(k))
 calls(k)=calls(k)+1
 end subroutine
 subroutine perf_stop(k)
 integer,intent(in)::k
 integer(int64)::now
 call system_clock(now)
 total(k)=total(k)+now-started(k)
 end subroutine
 subroutine perf_report()
 integer::u,k
 integer(int64)::rate
 call system_clock(count_rate=rate)
 open(newunit=u,file='profile.csv',status='new')
 write(u,'(A)')'category,seconds,calls'
 do k=1,5
 write(u,'(I0,A,ES25.17E3,A,I0)')k,',',real(total(k),real64)/real(rate,real64),',',calls(k)
 enddo
 close(u)
 open(newunit=u,file='counts.csv',status='new')
 write(u,'(12(I0,1X))')counts
 close(u)
 end subroutine
 end module
