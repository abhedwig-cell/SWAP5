program perf01_weather
  use iso_fortran_env, only: real64,int64
  use MOD_grid, only: numnod,z,dz,disnod
  use mod_fmr_runtime_core, only: FMR_BACKEND_SERIALIZED_REFERENCE,FMR_NUMERICAL_CONTINUATION_NONE, &
       FMR_NUMERICAL_CONTINUATION_RICHARDS_TEMPORAL_HISTORY
  use mod_transaction_reference, only: TX_TEMPORAL_MODEL_CERTIFICATE
  use mod_fmr_serialized_reference_backend, only: fmr_b110_physical_parameters_t, &
       fmr_b110_physical_forcing_t,fmr_b110_physical_state_t,fmr_b110_temporal_indicator_state_t
  use mod_fmr_serialized_multiswap_runtime, only: fmr_serialized_column_result_t
  use mod_fmr_production_application_bootstrap, only: fmr_production_application_config_t, &
       fmr_production_application_bootstrap_t,fmr_application_crop_daystart_controls_t,FMR_APP_BOOT_OK, &
       FMR_APP_BOOT_WEATHER_REJECTED,FMR_APP_BOOT_CROP_PREFLIGHT_FAILED
  use mod_b110_default_mvg_provider, only: b110_default_mvg_parameters_t,b110_default_mvg_provider_t, &
       initialize_b110_default_mvg_parameters,bind_b110_default_mvg_provider
  use mod_swap_daily_weather_file_adapter, only: swap_daily_weather_record_t,read_swap_daily_weather_file, &
       swap_weather_calendar_day,SWAP_WEATHER_FILE_OK
  use mod_kernel_transactions, only: kernel_committed_state_t
  use mod_fmr_crop_certified_daily_preflight, only: crop_certified_daily_preflight_t
  use mod_fmr_crop_certified_germination_moisture, only: sample_certified_committed_germination_head,CROP_CERT_GERM_OK
  use mod_ppa_wu03_common_forcing_adapter, only: ppa_wu03_common_forcing_config_t
  use mod_reference_et_demand_process, only: reference_et_demand_canopy_view_t
  use mod_kernel_transactions, only: kernel_executor_t,kernel_result_t
  use mod_kernel_committed_persistence, only: kernel_persistence_snapshot_t, &
       export_kernel_committed_state,restore_kernel_committed_state,KERNEL_PERSISTENCE_OK, &
       KERNEL_PERSISTENCE_TARGET_ALREADY_INITIALIZED
  use mod_canonical_contracts, only: canonical_numerical_config_t
  use mod_transaction_reference, only: transaction_state_t
  use mod_fmr_wofost_crop_transaction, only: fmr_wofost_crop_transaction_state_t, &
       fmr_wofost_crop_transaction_model_t, fmr_wofost_crop_transaction_parameters_t, &
       initialize_fmr_wofost_crop_transaction_state, construct_fmr_wofost_crop_transaction_parameters, FMR_WOF38_OK
  use mod_fmr_wofost_crop_transaction, only: fmr_wofost_crop_transaction_persistence_t, &
       export_fmr_wofost_crop_transaction_persistence,reconstruct_fmr_wofost_crop_transaction_from_persistence
  use mod_crop_lifecycle_continuation, only: crop_lifecycle_continuation_t,CROP_PROFILE_B111_TASK2, &
       initialize_b111_crop_lifecycle,CROP_CONT_OK
  use mod_crop_root_uptake_input_contract, only: crop_root_uptake_input_t
  use mod_fmr_runtime_core, only: FMR_OPTIONAL_STATE_LAYOUT_RESTRICTED_SOIL_TEMPERATURE
  use mod_soil_temperature_contract, only: SOIL_TEMP_TOP_AIR_TEMPERATURE, SOIL_TEMP_TOP_PRESCRIBED_HEAT_FLUX
  use mod_restricted_soil_temperature, only: initialize_soil_temperature_parameters, &
       initialize_soil_temperature_state, copy_soil_temperature_profile, SOIL_TEMP_OK
  use mod_wofost_crop_owner_state, only: WOFOST_CROP_OWNER_OK,wofost_crop_owner_state_t
  use mod_wofost_rate_parameters
  use mod_crop_et_canopy_view_provider,only: construct_crop_et_canopy_parameters,CROP_ET_CANOPY_OK
  use mod_wofost_rate_table
  use mod_wofost_one_day_structural_evolution, only: wofost_one_day_update_parameters_t, &
       wofost_one_day_forcing_t,wofost_accepted_window_aggregates_t,wofost_one_day_rate_packet_t
  use mod_wofost_two_phase_crop_window,only: wofost_two_phase_crop_window_t, &
       wofost_crop_window_begin_diagnostics_t,wofost_crop_window_complete_diagnostics_t, &
       begin_wofost_one_day_crop_window,complete_wofost_one_day_crop_window,WOFOST_CROP_WINDOW_OK
  use mod_fmr_production_application_bootstrap, only: FMR_APP_BOOT_CROP_WINDOW_UNAVAILABLE, &
       FMR_APP_BOOT_CROP_EVENT_DELIVERED,FMR_APP_BOOT_CROP_TRANSACTION_FAILED,FMR_APP_BOOT_INVALID_CONFIG,FMR_APP_BOOT_PROFILE_NOT_ADMITTED, &
       fmr_weather_crop_application_continuation_t
  use mod_fmr_wofost_accepted_window_lineage, only: prepare_wofost_crop_event_delivery, fmr_wofost_crop_event_token_t
  use mod_fmr_production_application_bootstrap, only: fmr_weather_crop_native_view_t, export_weather_crop_native_view
  implicit none
  real(real64),parameter::T0=0.0_real64,T1=1.0_real64,H0_CM=-75.0_real64,HARD_MASS_GATE=1.0e-12_real64
  type(fmr_production_application_config_t)::config,tc
  type(fmr_production_application_bootstrap_t)::ta
  type(fmr_application_crop_daystart_controls_t)::c
  type(kernel_committed_state_t)::cs,ss
  type(kernel_executor_t)::ck
  type(fmr_wofost_crop_transaction_model_t),target::cm
  type(fmr_wofost_crop_transaction_parameters_t)::cp
  type(canonical_numerical_config_t)::cn
  type(kernel_result_t)::cr
  type(swap_daily_weather_record_t)::wr
  type(fmr_serialized_column_result_t),allocatable::rr(:)
  type(wofost_crop_owner_state_t)::empty_owner,wo
  type(wofost_rate_parameter_bundle_t)::bundle
  type(wofost_one_day_update_parameters_t)::update
  type(fmr_weather_crop_application_continuation_t)::saved
  type(fmr_weather_crop_native_view_t)::view
  type(wofost_accepted_window_aggregates_t)::aggregates
  type(fmr_wofost_crop_event_token_t)::token
  type(ppa_wu03_common_forcing_config_t)::forcing_config
  type(reference_et_demand_canopy_view_t)::canopy
  class(transaction_state_t),allocatable::ps
  real(real64),allocatable::dist(:),temps(:)
  character(1024)::path,arg,restart_mode,profile_mode
  real(real64)::k,budget,wd,tmn,tmx,rain,etref,uptake,waterin,waterout,residual,initial_storage,storage
  real(real64)::startcpu,endcpu,previous_storage,weight,lai,head(4),theta(4)
  integer::st,q,d,j,iday,month,dom,year,days,windows,unit,pu,accepted,heads,rejections,njac,nback,nfailed
  logical::ok,dayend=.false.
  call get_command_argument(1,path)
  call get_command_argument(2,arg);read(arg,*)budget
  call get_command_argument(3,arg);read(arg,*)days
  call get_command_argument(4,arg);read(arg,*)windows
  call get_command_argument(5,restart_mode);call get_command_argument(6,profile_mode)
  call require(budget>0d0.and.budget<=1d0.and.days>=1.and.days<=97.and.windows>=1,'explicit bounded run arguments')
  call initialize_application_config(config,k)
  config%file_weather_daystart=.true.
  config%file_weather_epoch_day=swap_weather_calendar_day(1999,1,20)
  config%tiles(1)%template%numerical_continuation_layout_id=FMR_NUMERICAL_CONTINUATION_RICHARDS_TEMPORAL_HISTORY
  allocate(config%tiles(1)%initial_right_derivative(numnod));config%tiles(1)%initial_right_derivative=0d0
  config%numerical%transaction%temporal_mode=TX_TEMPORAL_MODEL_CERTIFICATE
  config%numerical%transaction%temporal_tolerance=0d0
  config%numerical%model_temporal_indicator_budget_available=.true.
  config%numerical%model_temporal_indicator_budget=budget
  config%numerical%transaction%max_retries=32
  config%numerical%max_committed_substeps=262144
  config%tiles(1)%parameters%head_abs_tolerance=1d-9
  config%tiles(1)%parameters%head_rel_tolerance=1d-9
  config%tiles(1)%parameters%ponding_tolerance=HARD_MASS_GATE
  config%tiles(1)%parameters%max_iterations=20
  config%tiles(1)%parameters%max_backtracking=8
  config%tiles(1)%parameters%min_step_duration=1d-10
  config%tiles(1)%parameters%compartment_balance_tolerance=1d-10
  config%tiles(1)%parameters%total_balance_tolerance=1d-10
  
    tc=config;tc%file_weather_rooted=.true.;tc%file_weather_dayend=dayend
    ! Explicit bounded site parameter, not a claim of Andelst site geometry.
    tc%file_weather_latitude=52.0_real64;tc%file_weather_emergence_dry_weight=10.0_real64
    tc%file_weather_maximum_root_depth_cm=30.0_real64
    call construct_wofost_rate_table([0.0_real64,0.1_real64,2.0_real64], &
         [5.0_real64,20.0_real64,30.0_real64],tc%file_weather_root_depth,st)
    call require(st==WOFOST_RATE_TABLE_OK,'existing DVS root depth parameter table')
    call construct_wofost_rate_table([0.0_real64,1.0_real64],[1.0_real64,1.0_real64],tc%file_weather_root_density,st)
    call require(st==WOFOST_RATE_TABLE_OK,'existing cumulative root density table')
    tc%file_weather_root_parameters%active_nodes=numnod
    tc%file_weather_root_parameters%hlim3l=-500.0_real64;tc%file_weather_root_parameters%hlim3h=-800.0_real64
    tc%file_weather_root_parameters%hlim4=-16000.0_real64
    tc%file_weather_root_parameters%adcrl=0.1_real64;tc%file_weather_root_parameters%adcrh=0.5_real64
    call construct_crop_et_canopy_parameters(0.8_real64,0.6_real64,[0.0_real64,2.0_real64], &
         [1.0_real64,1.0_real64],.false.,tc%file_weather_canopy_parameters,st)
    call require(st==CROP_ET_CANOPY_OK,'existing optical crop canopy parameter owner')
    tc%tiles(1)%parameters%root_extraction_active=.true.
    tc%tiles(1)%template%optional_state_layout_id=FMR_OPTIONAL_STATE_LAYOUT_RESTRICTED_SOIL_TEMPERATURE
    tc%tiles(1)%parameters%soil_temperature_active=.true.
    allocate(tc%tiles(1)%parameters%soil_temperature,tc%tiles(1)%initial_state%soil_temperature, &
         tc%tiles(1)%base_forcing%soil_temperature)
    dist=tc%tiles(1)%parameters%node_distance
    where(dist<=0.0_real64) dist=0.5_real64*tc%tiles(1)%parameters%dz
    call initialize_soil_temperature_parameters(tc%tiles(1)%parameters%dz,dist, &
         [(0.45_real64,q=1,numnod)],[(0.35_real64,q=1,numnod)], &
         [(0.15_real64,q=1,numnod)],[(0.05_real64,q=1,numnod)],tc%tiles(1)%parameters%soil_temperature,st)
    call require(st==SOIL_TEMP_OK,'rooted existing AIR thermal parameters')
    call initialize_soil_temperature_state([(0.0_real64,q=1,numnod)],tc%tiles(1)%initial_state%soil_temperature,st)
    call require(st==SOIL_TEMP_OK,'rooted initial cold soil')
    tc%tiles(1)%base_forcing%soil_temperature%top_boundary_mode=SOIL_TEMP_TOP_AIR_TEMPERATURE

  if(trim(profile_mode)=='sensitive')then
    tc%file_weather_root_parameters%hlim3l=-100d0
    tc%file_weather_root_parameters%hlim3h=-150d0
    tc%file_weather_root_parameters%hlim4=-500d0
  end if
  call ta%initialize(tc,st);call require(st==FMR_APP_BOOT_OK,'live weather crop bootstrap')
  call initialize_crop(cs,cp,cn,leaf_lifespan=40d0);call ck%bind_model(cm)
  c=fmr_application_crop_daystart_controls_t();c%initialization_profile=CROP_PROFILE_B111_TASK2
  c%swprep=0;c%swsow=1;c%germ_mode=2;c%optimal_sum=1d0
  c%hsow_threshold=100d0;c%sow_temperature=.0001d0
  c%zprep=-1d0;c%zsow=-1d0;c%ztempsow=-1d0;c%zgerm=-1d0
  open(newunit=unit,file='daily.csv',status='new')
  write(unit,'(a)') 'day,rain_mm,etref_mm,transpiration_mm,storage_mm,water_in_mm,water_out_mm,residual_mm,biomass,dvs,lai,head1_cm,head2_cm,head3_cm,head4_cm,theta1,theta2,theta3,theta4,potential_transpiration_mm,accepted,headcalc_calls,temporal_rejections,core_cpu_s'
  dom=20;month=1;year=1999
  print *, 'PERF01_INITIAL_STORAGE_CM',sum(tc%tiles(1)%initial_state%water_content*tc%tiles(1)%parameters%dz)
  do d=0,days-1
    call read_swap_daily_weather_file(trim(path),year,month,dom,wr,st)
    call require(st==SWAP_WEATHER_FILE_OK,'authentic daily weather record')
    call wr%values(wd,tmn,tmx,rain,etref,ok);call require(ok,'weather values available')
    call cpu_time(startcpu)
    if(d==0)then
      call ta%initialize_weather_crop_daystart(wr,c,empty_owner,19_int64,941_int64,cs,st)
    else
      call ta%run_weather_crop_daystart(wr,c,ck,cp,cn,cs,cr,st)
    end if
    if(st/=FMR_APP_BOOT_OK)print *, 'DAYSTART_REJECTED',d,st
    call require(st==FMR_APP_BOOT_OK,'live daily crop commit')
    uptake=0d0;waterin=0d0;waterout=0d0;residual=0d0;accepted=0;heads=0;rejections=0;njac=0;nback=0;nfailed=0
    do q=0,windows-1
      call ta%run_weather_interval(wr,real(d,real64)+real(q,real64)/windows, &
        real(d,real64)+real(q+1,real64)/windows,forcing_config,canopy,rr,st,crop_committed=cs)
      if(st/=FMR_APP_BOOT_OK)print *, 'HYDRO_REJECTED',d,q,st
      call require(st==FMR_APP_BOOT_OK,'live weather hydrology')
      call require(rr(1)%committed.and.rr(1)%mass%complete,'accepted complete water accounting')
      call require(abs(rr(1)%mass%residual)<=HARD_MASS_GATE,'unchanged hard water budget')
      call require(rr(1)%actual_transpiration_available,'physical transpiration available')
      uptake=uptake+rr(1)%actual_transpiration_amount
      waterin=waterin+rr(1)%mass%total_in;waterout=waterout+rr(1)%mass%total_out
      residual=residual+rr(1)%mass%residual
      accepted=accepted+rr(1)%accepted_substeps;heads=heads+rr(1)%solver_headcalc_calls
      njac=njac+rr(1)%solver_jacobian_builds;nback=nback+rr(1)%solver_backtracking_attempts
      nfailed=nfailed+rr(1)%solver_rejections
      rejections=rejections+rr(1)%temporal_rejections
    end do
    call cpu_time(endcpu)
    write(*,'(a,4(1x,i0))') 'NEWTON_WORK',d+1,njac,nback,nfailed
    call ta%capture_weather_crop_continuation(cs,saved,st)
    call require(st==FMR_APP_BOOT_OK,'accepted daily crop water window')
    call export_weather_crop_native_view(saved,view,st)
    call require(st==FMR_APP_BOOT_OK,'read-only daily continuation view')
    call prepare_wofost_crop_event_delivery(view%current_window,aggregates,token,ok,st)
    call require(ok,'complete daily uptake and demand aggregates')
    call require(aggregates%actual_root_uptake==uptake,'independent uptake publication agrees with window')
    call ta%copy_committed_for_crop(1,ss,st);call require(st==FMR_APP_BOOT_OK,'accepted soil snapshot')
    call ss%snapshot(ps,ok);call require(ok,'soil owner available')
    select type(ps)
    type is(fmr_b110_temporal_indicator_state_t)
      storage=sum(ps%water_content*tc%tiles(1)%parameters%dz)+ps%ponding_depth
      head=ps%pressure_head;theta=ps%water_content
    class default
      call require(.false.,'existing Richards history state')
    end select
    call cs%snapshot(ps,ok);call require(ok,'crop owner available')
    select type(ps)
    type is(fmr_wofost_crop_transaction_state_t)
      call ps%snapshot_owner(wo,ok);call require(ok,'live biomass')
    class default
      call require(.false.,'existing crop state')
    end select
    weight=0d0;lai=0d0
    if(allocated(wo%biomass))then
      weight=wo%biomass%root_biomass+wo%biomass%stem_biomass+wo%biomass%storage_biomass
      if(allocated(wo%biomass%leaf_biomass))weight=weight+sum(wo%biomass%leaf_biomass)
      lai=wo%biomass%leaf_area_sum()
    end if
    write(unit,'(i0,19(",",es25.17e3),3(",",i0),",",es25.17e3)') &
      d+1,rain,etref,10d0*uptake,10d0*storage,10d0*waterin,10d0*waterout,10d0*residual,weight, &
      wo%development_stage,lai,head,theta,10d0*aggregates%potential_transpiration,accepted,heads,rejections,endcpu-startcpu
    flush(unit)
    print *, 'COMPLETED_DAY',d+1,10d0*storage,10d0*uptake
    if(trim(restart_mode)=='restart'.and.d==days/2-1)then
      call ta%close(st);call require(st==FMR_APP_BOOT_OK,'close midpoint accepted application')
      cs=kernel_committed_state_t()
      call ta%restore_weather_crop_continuation(saved,cs,st)
      call require(st==FMR_APP_BOOT_OK,'reconstruct complete soil weather crop history at midpoint')
    end if
    dom=dom+1
    if((month==1.or.month==3).and.dom>31)then
      month=month+1;dom=1
    else if(month==2.and.dom>28)then
      month=3;dom=1
    end if
  end do
  close(unit)
  call ta%close(st);call require(st==FMR_APP_BOOT_OK,'close completed live application')
  print *, 'PERF01_LIVE_WEATHER_COMPLETE',days,budget

contains
  subroutine initialize_application_config(value, conductivity0)
    type(fmr_production_application_config_t), intent(out) :: value
    real(real64), intent(out) :: conductivity0

    value%initial_time = T0
    value%numerical%transaction%temporal_tolerance = 0.0_real64
    ! Tighten each internal transaction so accumulated interval residual
    ! remains beneath the independent 1e-12 cm interval acceptance gate.
    value%numerical%transaction%mass_tolerance = 1.0e-14_real64
    value%numerical%transaction%retry_scale = 0.5_real64
    value%numerical%transaction%max_retries = 2
    value%numerical%max_committed_substeps = 8
    value%numerical%progress_tolerance = 0.0_real64

    allocate(value%tiles(1))
    value%tiles(1)%tile_id = 630101_int64
    value%tiles(1)%ledger_id = 730101_int64
    value%tiles(1)%template%template_id = 630201_int64
    value%tiles(1)%template%physics_topology_id = 630210_int64
    value%tiles(1)%template%vertical_layout_id = 630220_int64
    value%tiles(1)%template%state_layout_id = 630230_int64
    value%tiles(1)%template%solver_interface_id = 630240_int64
    value%tiles(1)%template%optional_state_layout_id = 0_int64
    value%tiles(1)%template%numerical_continuation_layout_id = FMR_NUMERICAL_CONTINUATION_NONE
    value%tiles(1)%template%compatible_backend_id = FMR_BACKEND_SERIALIZED_REFERENCE

    call initialize_parameters(value%tiles(1)%parameters)
    call initialize_state_and_forcing(value%tiles(1)%parameters, value%tiles(1)%initial_state, &
         value%tiles(1)%base_forcing, conductivity0)
  end subroutine initialize_application_config
  subroutine initialize_parameters(p)
    type(fmr_b110_physical_parameters_t), intent(out) :: p
    integer :: k

    p%parameter_set_id = 640001_int64
    p%active_nodes = numnod
    allocate(p%z(numnod), p%dz(numnod), p%node_distance(numnod), p%cofgen(24, numnod))
    p%z = z
    p%dz = dz
    p%node_distance = disnod(1:numnod)
    p%cofgen = 0.0_real64
    do k = 1, numnod
      p%cofgen(1,k) = 0.032_real64
      p%cofgen(2,k) = 0.423_real64
      p%cofgen(3,k) = 4.75_real64
      p%cofgen(4,k) = 0.0135_real64
      p%cofgen(5,k) = 0.365_real64
      p%cofgen(6,k) = 1.455_real64
      p%cofgen(7,k) = 1.0_real64 - 1.0_real64 / p%cofgen(6,k)
      p%cofgen(8,k) = p%cofgen(4,k)
      p%cofgen(10,k) = p%cofgen(3,k)
      p%cofgen(11,k) = 0.999_real64
      p%cofgen(12,k) = 0.99_real64 * p%cofgen(3,k)
      p%cofgen(22,k) = -1.0e6_real64
      p%cofgen(23,k) = 1.0e-12_real64
    end do
    p%bottom_mode = 7
    p%swkimpl = 0
    p%swkmean = 1
    p%swsophy = 0
    p%root_extraction_active = .false.
    p%macropore_active = .false.
    p%snow_active = .false.
    p%hysteresis_active = .false.
    p%tabulated_hydraulics_active = .false.
    p%elasticity_active = .false.
    p%frost_active = .false.
    p%soil_temperature_active = .false.
    p%drainage_response_active = .false.
  end subroutine initialize_parameters
  subroutine initialize_state_and_forcing(p, state, forcing, conductivity0)
    type(fmr_b110_physical_parameters_t), intent(in) :: p
    type(fmr_b110_physical_state_t), intent(out) :: state
    type(fmr_b110_physical_forcing_t), intent(out) :: forcing
    real(real64), intent(out) :: conductivity0

    type(b110_default_mvg_parameters_t), target :: hp
    type(b110_default_mvg_provider_t) :: provider
    real(real64) :: heads(numnod), water(numnod), conductivity(numnod), capacity(numnod), dkdh(numnod)
    integer :: i

    heads = H0_CM
    call initialize_b110_default_mvg_parameters(hp, p%cofgen)
    call bind_b110_default_mvg_provider(provider, hp, T1 - T0)
    call provider%evaluate(heads, water, conductivity, capacity, dkdh)
    conductivity0 = conductivity(1)

    state%active_nodes = numnod
    allocate(state%pressure_head(numnod), state%water_content(numnod))
    state%pressure_head = heads
    state%water_content = water
    state%ponding_depth = 0.0_real64
    state%groundwater_level = -2.0_real64

    forcing%top_flux = -conductivity0
    forcing%top_head = H0_CM
    forcing%bottom_flux = -conductivity0
    forcing%bottom_head = -100.0_real64
    allocate(forcing%drainage_flux_by_level(2,numnod), forcing%subsurface_irrigation_source(numnod), &
         forcing%root_extraction_sink(numnod))
    do i = 1, numnod
      forcing%drainage_flux_by_level(1,i) = 1.0e-5_real64 * real(i,real64)
      forcing%drainage_flux_by_level(2,i) = -2.0e-6_real64 * real(i+1,real64)
      forcing%subsurface_irrigation_source(i) = forcing%drainage_flux_by_level(1,i) + &
           forcing%drainage_flux_by_level(2,i)
      forcing%root_extraction_sink(i) = 0.0_real64
    end do
  end subroutine initialize_state_and_forcing
  subroutine initialize_crop(committed,parameters,numerical,leaf_lifespan)
    type(kernel_committed_state_t),intent(out)::committed
    type(fmr_wofost_crop_transaction_parameters_t),intent(out)::parameters
    type(canonical_numerical_config_t),intent(out)::numerical
    real(real64),intent(in),optional::leaf_lifespan
    type(wofost_crop_owner_state_t)::owner
    type(crop_lifecycle_continuation_t)::initial
    type(fmr_wofost_crop_transaction_state_t)::state
    type(wofost_rate_parameter_bundle_t)::bundle
    type(wofost_one_day_update_parameters_t)::update
    class(transaction_state_t),allocatable::physical
    integer::s
    logical::ok
    call make_bundle(bundle)
    if(present(leaf_lifespan)) update%leaf_lifespan=leaf_lifespan
    call construct_fmr_wofost_crop_transaction_parameters(bundle,update,0.0_real64,0.0_real64,parameters,s)
    call require(s==FMR_WOF38_OK,'existing WOFOST parameters ready')
    numerical%transaction%temporal_mode=TX_TEMPORAL_MODEL_CERTIFICATE
    numerical%transaction%temporal_tolerance=0.0_real64
    numerical%transaction%mass_tolerance=0.0_real64
    numerical%transaction%max_retries=0
    numerical%max_committed_substeps=1
  end subroutine
  subroutine make_bundle(bundle)
    type(wofost_rate_parameter_bundle_t), intent(out) :: bundle
    type(wofost_rate_scalar_parameters_t) :: scalar
    type(wofost_rate_parameter_tables_t) :: tables
    integer :: status

    scalar = wofost_rate_scalar_parameters_t()
    scalar%development_daylength_mode = 1
    scalar%daylength_upper_hours = 16.0_real64
    scalar%daylength_lower_hours = 8.0_real64
    scalar%vegetative_temperature_sum_required = 1000.0_real64
    scalar%generative_temperature_sum_required = 800.0_real64
    scalar%diffuse_extinction_coefficient = 0.6_real64
    scalar%initial_light_use_efficiency = 0.45_real64
    scalar%co2_to_dry_matter_fraction = 0.4_real64
    scalar%attainable_yield_multiplier = 0.9_real64
    scalar%conversion_efficiency_root = 0.7_real64
    scalar%conversion_efficiency_stem = 0.65_real64
    scalar%conversion_efficiency_leaf = 0.72_real64
    scalar%conversion_efficiency_storage = 0.8_real64
    scalar%respiration_temperature_q10 = 2.0_real64
    scalar%maintenance_respiration_root = 0.01_real64
    scalar%maintenance_respiration_leaf = 0.02_real64
    scalar%maintenance_respiration_stem = 0.015_real64
    scalar%maintenance_respiration_storage = 0.005_real64
    scalar%maximum_leaf_relative_death_rate = 0.03_real64
    scalar%leaf_age_base_temperature = 0.0_real64
    scalar%maximum_relative_lai_growth_rate = 0.04_real64

    call constant_table(10.0_real64, tables%temperature_sum_increment)
    call constant_table(30.0_real64, tables%maximum_assimilation)
    call constant_table(1.0_real64, tables%daytime_temperature_factor)
    call constant_table(1.0_real64, tables%minimum_temperature_factor)
    call constant_table(1.0_real64, tables%maintenance_respiration_factor)
    call constant_table(0.2_real64, tables%root_partition_fraction)
    call constant_table(0.4_real64, tables%leaf_partition_fraction)
    call constant_table(0.4_real64, tables%stem_partition_fraction)
    call constant_table(0.2_real64, tables%storage_partition_fraction)
    call constant_table(0.01_real64, tables%relative_root_death_rate)
    call constant_table(0.01_real64, tables%relative_stem_death_rate)
    call constant_table(0.02_real64, tables%specific_leaf_area)

    call construct_wofost_rate_parameter_bundle(scalar, tables, bundle, status)
    call require(status == WOFOST_RATE_PARAMETER_OK, 'rate parameter bundle status')
    call require(bundle%ready(), 'rate parameter bundle ready')
  end subroutine make_bundle
  subroutine constant_table(value, table)
    real(real64), intent(in) :: value
    type(wofost_rate_table_t), intent(out) :: table
    real(real64) :: x(1), y(1)
    integer :: status
    x = [0.0_real64]
    y = [value]
    call construct_wofost_rate_table(x, y, table, status)
    call require(status == WOFOST_RATE_TABLE_OK, 'constant rate table')
  end subroutine constant_table
  subroutine require(ok,message)
    logical,intent(in)::ok
    character(*),intent(in)::message
    if(.not.ok) then
      print *, 'CROP_FILE_WEATHER_FAIL ',message
      error stop 1
    end if
  end subroutine
end program
