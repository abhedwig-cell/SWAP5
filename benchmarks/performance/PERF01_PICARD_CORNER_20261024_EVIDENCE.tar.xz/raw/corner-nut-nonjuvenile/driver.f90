program test_b112_retained_joint
 use iso_fortran_env,only:real64,int64
 use ieee_arithmetic,only:ieee_value,ieee_quiet_nan
 use mod_fmr_runtime_core
 use mod_fmr_serialized_reference_backend
 use mod_fmr_production_application_bootstrap
 use mod_kernel_transactions
 use mod_fixed_flux_top_boundary_provider
 use mod_b110_default_mvg_provider
 use MOD_grid,only:numnod,z,dz,disnod
 use mod_transaction_reference,only:transaction_state_t,TX_TEMPORAL_MODEL_CERTIFICATE,TX_TEMPORAL_EXTERNAL_FULL_HALF
 use mod_b111_soil_n_mineral_owner
 use mod_b111_soil_n_reactive_owner
 use mod_soil_n_pool_state
 use mod_b111_soil_n_addition
 use mod_crop_soil_n_material_day
 use mod_fmr_crop_soil_n_material_application
 use mod_crop_soil_n_historical_project_binding,only:initialize_historical_crop_soil_owner
 use mod_soil_n_historical_activation,only:soil_n_historical_selection_t
 use mod_soil_n_amendment_calendar,only:soil_n_amendment_calendar_t,select_soil_n_amendments, &
  create_soil_n_amendment_calendar,N_CALENDAR_OK
 use mod_soil_n_amendment_input,only:parse_soil_n_date,N_INPUT_OK
 use mod_crop_soil_n_day
 use mod_crop_soil_n_configuration
 use mod_wofost81_crop_owner_state
 use mod_wofost81_n_owner_state,only:initialize_wofost81_n_owner_state,WOFOST81_N_OWNER_OK
 use mod_wofost_one_day_structural_evolution
 use mod_fmr_crop_soil_n_joint_application
 use mod_crop_soil_n_joint_restart_file
 use mod_fmr_b111_mineral_route,only:aggregate_mineral_trace,mineral_daily_carrier_t
 use mod_soil_n_day_environment
 use mod_crop_senescence_residue
 use mod_crop_soil_n_senescence_day
 use mod_fmr_crop_soil_n_senescence_application
 use mod_fmr_crop_soil_n_calendar_application,only:run_crop_soil_n_calendar_interval
 use mod_crop_soil_n_calendar_day,only:advance_crop_soil_fallow_calendar_day
 use mod_gash_interception_process
 use mod_gash_daily_application
 implicit none
 real(real64),parameter::T0=0d0,T1=1d0,HARD_MASS_GATE=1d-10
 type(fmr_production_application_config_t)::cfg
 type(fmr_serialized_reference_backend_t)::backend,second
 type(fixed_flux_top_boundary_provider_t),target::top
 type(fmr_logical_column_t)::column
 type(kernel_committed_state_t)::water,other_water,initial_water
 type(reactive_state_t)::soil,initial_soil,after_soil
 type(crop_soil_state_t)::state,other_state,initial_state
 type(crop_soil_n_joint_restart_t)::payload
 type(senescence_joint_result_t)::result
 type(soil_n_material_input_t)::items(2),bad_items(2)
 type(b111_soil_n_split_parameters_t)::split
 type(crop_senescence_policy_t)::policy,bad_policy
 type(crop_residue_pending_t)::pending
 logical::has_pending
 type(soil_n_day_environment_t)::env,bad_env
 type(reactive_parameters_t)::oracle_p
 type(reactive_parameters_t)::sp,bad_sp
 type(crop_n_configuration_t)::cp,bad_cp
 type(wofost81_crop_owner_state_t)::crop,after_crop
 type(wofost_one_day_forcing_t)::weather,bad_weather
 type(soil_n_pool_state_t)::pools,s
 type(fmr_b110_physical_forcing_t)::invalid
 real(real64),allocatable::old_crop(:),actual_crop(:)
 real(real64)::k,time,theta
 integer(int64)::revision
 integer::status
 logical::ok,gash_composition
 character(512)::mode,path,endpoint
 character(32)::selected
 call get_command_argument(1,mode);call get_command_argument(2,path);call get_command_argument(3,endpoint)
 call get_command_argument(4,selected)
 gash_composition=trim(selected)=='gash-profile'
 if(gash_composition)selected='surface-profile'
 policy%application_age=[1.57d0,.99d0,1.57d0]
 env=soil_n_day_environment_t(0d0,1d0,5d0)
 call initialize_application_config(cfg,-75d0,k)
 cfg%tiles(1)%template%numerical_continuation_layout_id=FMR_NUMERICAL_CONTINUATION_RICHARDS_TEMPORAL_HISTORY
 cfg%tiles(1)%base_forcing%top_flux=0d0;cfg%tiles(1)%base_forcing%bottom_flux=-.1d0
 cfg%tiles(1)%base_forcing%drainage_flux_by_level=1d-4
 cfg%tiles(1)%base_forcing%subsurface_irrigation_source=0d0
 cfg%tiles(1)%parameters%root_extraction_active=.true.
 cfg%tiles(1)%base_forcing%root_extraction_sink=1d-4
 cfg%tiles(1)%base_forcing%root_potential_transpiration=.0008d0
 cfg%numerical%transaction%temporal_mode=TX_TEMPORAL_MODEL_CERTIFICATE
 cfg%numerical%model_temporal_indicator_budget_available=.true.;cfg%numerical%model_temporal_indicator_budget=1d-4
 cfg%numerical%transaction%temporal_tolerance=0d0
 cfg%numerical%transaction%max_retries=30;cfg%numerical%max_committed_substeps=4096
 if(trim(selected)=='surface-profile')then
  cfg%tiles(1)%template%numerical_continuation_layout_id=FMR_NUMERICAL_CONTINUATION_NONE
  cfg%numerical%transaction%temporal_mode=TX_TEMPORAL_EXTERNAL_FULL_HALF
  cfg%numerical%retain_accepted_step_proposal=.true.
  cfg%numerical%transaction%temporal_tolerance=1d-6
  cfg%numerical%transaction%max_retries=30;cfg%numerical%max_committed_substeps=4096
 end if
 column%column_id=cfg%tiles(1)%tile_id;column%template_id=cfg%tiles(1)%template%template_id
 column%parameter_ref=1_int64;column%state_handle=1_int64;column%forcing_handle=1_int64
 column%backend_id=FMR_BACKEND_SERIALIZED_REFERENCE
 call parameters(sp);call materials(items,split);call configure_crop(cp);cp%base%nitrogen%nfix_fr=.3d0;cp%update%leaf_lifespan=100d0;cp%lai_crit_nupt=1d0
 if(trim(selected)=='old-profile')then
  allocate(cp%b111_request);cp%b111_request%dvsnlt=.9d0;cp%b111_request%nfixf=.25d0
 else if(trim(selected)/='absent')then
  allocate(cp%b111_reproductive)
  cp%b111_reproductive%dvsnlt=.9d0;cp%b111_reproductive%dvsnt=.4d0
  cp%b111_reproductive%nfixf=.25d0;cp%b111_reproductive%fntrt=.25d0
  select case(trim(selected))
  case('wrong-dvsnlt');cp%b111_reproductive%dvsnlt=.7d0
  case('wrong-dvsnt');cp%b111_reproductive%dvsnt=.3d0
  case('wrong-nfixf');cp%b111_reproductive%nfixf=.5d0
  case('wrong-fntrt');cp%b111_reproductive%fntrt=.5d0
  end select
 end if
 if(trim(selected)/='old-profile'.and.trim(selected)/='absent'.and.trim(selected)/='legacy')then
  allocate(cp%b112_return,cp%harvest)
  cp%b112_return%leaf_fraction=.25d0
  if(trim(selected)=='wrong-return')cp%b112_return%leaf_fraction=.5d0
  cp%harvest%crop_identity=1;cp%harvest%crop_end=1d0;cp%harvest%sw_harv=0;cp%harvest%sw_wofost=1
  cp%harvest%policy%return_fraction=[.5d0,.25d0,.5d0]
  cp%harvest%policy%application_age=[1.57d0,.99d0,1.57d0,1.57d0]
 endif
 cp%tables(15)%y=.02d0
 call configure_owner(crop,cp,status);call require(status==0,'WOFOST81 owner initialize')
 crop%nitrogen%value%namountlv=4d0;crop%nitrogen%value%namountst=1d0;crop%nitrogen%value%namountrt=.5d0
 crop%nitrogen%value%namountso=.5d0;crop%nitrogen%value%initial_total=6d0
 crop%nitrogen%value%namountlv=crop%nitrogen%value%namountlv-2d0
 crop%nitrogen%value%initial_total=crop%nitrogen%value%initial_total-2d0
 weather%minimum_temperature=3d0;weather%average_temperature=10d0;weather%daytime_average_temperature=15d0
 weather%global_radiation=1d7;weather%daylength_hours=12d0;weather%photoperiodic_daylength_hours=12d0
 weather%sinld=.3d0;weather%cosld=.7d0;weather%diffuse_perpendicular_radiation=100d0
 weather%daily_sine_solar_elevation_integral=30000d0
 call initialize_soil_n_pool_state(sp%mineral%inventory,spread(1d0,1,8),5d0,40d0,.02d0,.03d0,pools,status)
 call require(status==0,'soil inventory initialize')
 call backend%initialize(top);call second%initialize(top)
 call crop_depletion_joint()
contains
 subroutine crop_depletion_joint()
  type(crop_soil_n_joint_result_t)::r,rejected
  type(fmr_b110_physical_forcing_t)::forcing,harder
  type(soil_n_day_environment_t)::e,stale
  real(real64)::ledger(14),before,residual,external_in,external_out
  integer::first,d,u,code
  character(32)::arg
  logical::immobilise,limited,zero_pools,all_zero,bio_zero,hum_zero,resonant,repeated,singular,small_det,empty_nh4,empty_both,crop_nh4,crop_both
  real(real64)::p1,p2,p3,p4,p5
  real(real64)::available_before,demand_after
  zero_pools=trim(selected)=='zero_pools';all_zero=trim(selected)=='all_zero'
  bio_zero=trim(selected)=='bio_zero';hum_zero=trim(selected)=='hum_zero'
  resonant=trim(selected)=='resonant';repeated=trim(selected)=='repeated'
  singular=trim(selected)=='singular';small_det=trim(selected)=='small_det'
  empty_nh4=trim(selected)=='empty_nh4';empty_both=trim(selected)=='empty_both'
  crop_nh4=trim(selected)=='crop_nh4';crop_both=trim(selected)=='crop_both'
  if(crop_nh4.or.crop_both)then
   cp%lai_crit_nupt=0d0;cp%tcsf_n=.05d0
  end if
  immobilise=trim(selected)=='immobilise'.or.zero_pools.or.bio_zero.or.hum_zero.or.resonant.or.repeated.or.singular.or.small_det
  limited=trim(selected)=='limited'
  if(limited.or.empty_nh4.or.empty_both)cp%lai_crit_nupt=0d0
  sp%mineral%c_top=[.002d0,.005d0];sp%mineral%c_bottom=0d0;sp%mineral%c_lateral=0d0
  if(immobilise)then
   sp%mineral%inventory%nfrac_fom=.0001d0
   sp%mineral%inventory%nfrac_biomass=.08d0;sp%mineral%inventory%nfrac_humus=.06d0
  end if
  sp%organic_reference%ratecon_fom=1d-4;sp%organic_reference%ratecon_hum=1d-5
  if(immobilise)then
   sp%organic_reference%ratecon_bio=1d-4;sp%organic_reference%ratecon_hum=1d-5
  end if
  if(zero_pools.or.all_zero)then
   sp%organic_reference%ratecon_bio=0d0;sp%organic_reference%ratecon_hum=0d0
   if(all_zero)sp%organic_reference%ratecon_fom=0d0
  end if
  if(bio_zero)sp%organic_reference%ratecon_bio=0d0
  if(hum_zero)sp%organic_reference%ratecon_hum=0d0
  if(resonant)then
   sp%organic_reference%ratecon_bio=2d-4;sp%organic_reference%ratecon_hum=1d-4
   p1=(1d0-sp%organic_reference%asfa_bio)*sp%organic_reference%ratecon_bio
   p2=sp%organic_reference%asfa_bio*sp%organic_reference%ratecon_hum
   p3=sp%organic_reference%asfa_hum*sp%organic_reference%ratecon_bio
   p4=(1d0-sp%organic_reference%asfa_hum)*sp%organic_reference%ratecon_hum
   p5=sqrt((p1-p4)**2+4d0*p2*p3)
   sp%organic_reference%ratecon_fom=(p1+p4-p5)/2d0
  end if
  if(repeated)then
   sp%organic_reference%asfa_bio=0d0;sp%organic_reference%asfa_hum=0d0
   sp%organic_reference%ratecon_bio=1d-4;sp%organic_reference%ratecon_hum=1d-4
   sp%organic_reference%ratecon_fom=1d-4
  end if
  if(singular)then
   sp%organic_reference%asfa_bio=.5d0;sp%organic_reference%asfa_hum=.5d0
  end if
  if(small_det)then
   sp%organic_reference%ratecon_bio=1d-7;sp%organic_reference%ratecon_hum=2d-7
  end if
  if(empty_nh4.or.empty_both)then
   sp%organic_reference%ratecon_fom=0d0;sp%organic_reference%ratecon_bio=0d0;sp%organic_reference%ratecon_hum=0d0
   sp%mineral%c_top(1)=0d0
   if(empty_both)sp%mineral%c_top(2)=0d0
  end if
  if(crop_nh4.or.crop_both)then
   sp%organic_reference%ratecon_fom=0d0;sp%organic_reference%ratecon_bio=0d0;sp%organic_reference%ratecon_hum=0d0
   sp%mineral%c_top=[.002d0,.005d0]
  end if
  sp%environment%nitrification_ref_per_day=.02d0;sp%environment%denitrification_ref_per_day=.025d0
  sp%environment%cdissi_half_kg_m2=1d-12
  cfg%tiles(1)%base_forcing%bottom_flux=0d0;cfg%tiles(1)%base_forcing%drainage_flux_by_level=0d0
  cfg%tiles(1)%base_forcing%root_extraction_sink=1d-4
  cfg%tiles(1)%base_forcing%root_potential_transpiration=.0008d0
  call get_command_argument(5,arg);first=0;ledger=0d0
  if(trim(mode)=='resume')then
   read(arg,*)first
   call read_crop_soil_n_joint_restart_file(trim(path),column,cfg%tiles(1)%template, &
    670001_int64,9001_int64,9101_int64,sp,cp,water,state,code)
   call require(code==0,'competing process restart restores real crop/soil/water')
   open(newunit=u,file=trim(path)//'.ledger',status='old',form='unformatted',access='stream');read(u)ledger;close(u)
  else
   call fmr_new_b110_temporal_indicator_committed_state(water,column%column_id,cfg%tiles(1)%initial_state, &
    0d0,ok,spread(0d0,1,numnod));call require(ok,'competing real Richards initialization')
   theta=sum(dz*cfg%tiles(1)%initial_state%water_content)/sum(dz)
   call initialize_soil_n_pool_state(sp%mineral%inventory,spread(1d0,1,8),.1d0,.1d0,.02d0,.03d0,pools,code)
   if(empty_nh4.or.empty_both)then
    call initialize_soil_n_pool_state(sp%mineral%inventory,spread(0d0,1,8),0d0,0d0,0d0,merge(0d0,.03d0,empty_both),pools,code)
   end if
   if(crop_nh4.or.crop_both)then
    call initialize_soil_n_pool_state(sp%mineral%inventory,spread(0d0,1,8),0d0,0d0,2d-7,merge(3d-7,.03d0,crop_both),pools,code)
   end if
   if(limited)then
    call initialize_soil_n_pool_state(sp%mineral%inventory,spread(0d0,1,8),1d-4,0d0,2d-7,3d-7,pools,code)
   end if
   call require(code==0,'competing organic and mineral inventories')
   call initialize_reactive(sp,9001_int64,0d0,theta,pools,soil,code);call require(code==0,'competing reactive init')
   call initialize_crop_soil(soil,crop,cp,9101_int64,state,code);call require(code==0,'competing crop init')
   ledger(1)=crop_soil_whole_n(state)
  end if
  do d=first,7
   forcing=cfg%tiles(1)%base_forcing;forcing%top_flux=merge(-.03d0,.01d0,mod(d,2)==0)
   e=soil_n_day_environment_t(real(d,real64),real(d+1,real64),20d0)
   if(d==2.or.d==5)then
    write(arg,'(I0)')d
    call write_crop_soil_n_joint_restart_file(trim(path)//'.before-'//trim(arg),column,cfg%tiles(1)%template, &
     670001_int64,water,state,code);call require(code==0,'competing save before rejection')
    ! Empty zero-loaded donors cannot be exhausted. In that case exercise an
    ! invalid chemical temperature after actual water, independently of the
    ! separate stale-interval rejection below.
    stale=e
    if(empty_both.or.crop_nh4.or.crop_both)stale%temperature_c=ieee_value(0d0,ieee_quiet_nan)
    call run_crop_soil_n_joint_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters, &
     water,forcing,cfg%numerical,state,weather,e%t0,e%t1,rejected,stale,atmospheric_n_surface=.true., &
     historical_top_water=-100d0,nondepleting_top=.true.,proportional_constant_sinks=.true.)
    call require(rejected%status==JOINT_CHEMICAL_REJECTED.and.rejected%water%completed,'unsupported or exhausted chemistry rejects completed water trial')
    call write_crop_soil_n_joint_restart_file(trim(path)//'.exhaust-reject-'//trim(arg),column,cfg%tiles(1)%template, &
     670001_int64,water,state,code);call require(code==0,'competing save after exhaustion rejection')
    stale=e;stale%t1=stale%t1+1d0
    call run_crop_soil_n_joint_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters, &
     water,forcing,cfg%numerical,state,weather,e%t0,e%t1,rejected,stale,atmospheric_n_surface=.true., &
     historical_top_water=merge(-.000002d0,-.002d0,limited),nondepleting_top=.true.,proportional_constant_sinks=.true.)
    call require(rejected%status==JOINT_CHEMICAL_REJECTED.and.rejected%water%completed,'competing stale chemical trial')
    call write_crop_soil_n_joint_restart_file(trim(path)//'.stale-reject-'//trim(arg),column,cfg%tiles(1)%template, &
     670001_int64,water,state,code);call require(code==0,'competing save after stale trial')
    harder=forcing;harder%top_flux=-.5d0;cfg%numerical%max_committed_substeps=1
    call run_crop_soil_n_joint_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters, &
     water,harder,cfg%numerical,state,weather,e%t0,e%t1,rejected,e,atmospheric_n_surface=.true., &
     historical_top_water=merge(-.000002d0,-.002d0,limited),nondepleting_top=.true.,proportional_constant_sinks=.true.)
    cfg%numerical%max_committed_substeps=4096
    call require(rejected%status==JOINT_WATER_REJECTED,'competing hydraulic rejection')
    call write_crop_soil_n_joint_restart_file(trim(path)//'.water-reject-'//trim(arg),column,cfg%tiles(1)%template, &
     670001_int64,water,state,code);call require(code==0,'competing save after water rejection')
   end if
   call state%snapshot(soil,crop)
   call soil%snapshot(time,theta,pools,revision)
   available_before=pools%ammonium_n_kg_m2+pools%nitrate_n_kg_m2
   before=crop_soil_whole_n(state)
   if(trim(mode)=='probe')then
    call write_crop_soil_n_joint_restart_file(trim(path)//'.probe-before',column,cfg%tiles(1)%template, &
     670001_int64,water,state,code);call require(code==0,'preimage before-state')
   end if
   call run_crop_soil_n_joint_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters, &
    water,forcing,cfg%numerical,state,weather,e%t0,e%t1,r,e,atmospheric_n_surface=.true., &
    historical_top_water=merge(-.000002d0,-.002d0,limited),nondepleting_top=.true.,proportional_constant_sinks=.true.)
   if(trim(mode)=='probe')then
    call require((crop_nh4.or.crop_both).and.r%status==JOINT_CHEMICAL_REJECTED.and.r%water%completed,'preimage rejected receiving determinant')
    call write_crop_soil_n_joint_restart_file(trim(path)//'.probe-after',column,cfg%tiles(1)%template, &
     670001_int64,water,state,code);call require(code==0,'preimage rejected state')
    print *,'PREIMAGE_DETERMINANT_REJECTION_PASS'
    return
   end if
   if(r%status/=0)print *,'COMPETING_FAILURE',d,r%status,r%chemical%status,r%chemical%soil%status, &
    r%chemical%soil%process%status,r%chemical%soil%process%exchange%status
   call require(r%status==JOINT_OK,'competing accepted actual Richards crop soil interval')
   if(limited)then
    demand_after=r%chemical%prepared%nitrogen_request%soil_request*1d-4
    call require(demand_after>available_before+max(0d0,r%chemical%soil%process%organic%nitrogen%mineralized_n_kg_m2), &
     'both unused demand branches exceed all available mineral N')
   end if
   if(all_zero)then
    call require(r%chemical%soil%process%organic%nitrogen%mineralized_n_kg_m2==0d0,'all zero organic N transfer')
    call require(r%chemical%soil%process%dissimilation%carbon_dissimilation_kg_m2==0d0,'all zero organic carbon loss')
   end if
   if(crop_nh4.or.crop_both)then
    call require(r%chemical%soil%process%exchange%cnh4_end==0d0,'actual selected juvenile ammonium depletion')
    call require(r%chemical%prepared%nitrogen_request%soil_request*1d-4>r%chemical%internal_supply_kg_m2,'actual crop demand exceeds constrained soil supply')
    if(crop_both)call require(r%chemical%soil%process%exchange%cno3_end==0d0,'actual selected juvenile nitrate depletion')
   else if(empty_both)then
    call require(r%chemical%internal_supply_kg_m2==0d0,'empty donors supply zero soil N')
   else
    call require(r%chemical%internal_supply_kg_m2>0d0,'live plant receives actual soil N')
   end if
   if(empty_nh4.or.empty_both)then
    call require(r%chemical%soil%process%exchange%cnh4_end==0d0,'empty ammonium exact equilibrium')
    call require(r%chemical%soil%process%exchange%nh4_crop_uptake_kg_m2==0d0,'empty ammonium has zero uptake')
   end if
   call require(all(r%chemical%soil%top_unmet>=0d0),'partition unmet nonnegative')
   call require(maxval(abs(r%chemical%soil%top_actual-r%chemical%soil%top_unmet-r%chemical%soil%top_requested))<1d-12,'actual and unmet top receipt close request')
   external_in=r%chemical%soil%external_in+r%chemical%fixation_kg_m2
   external_out=r%chemical%soil%external_out-r%chemical%internal_supply_kg_m2+r%chemical%crop_loss_kg_m2
   residual=before+external_in-external_out-crop_soil_whole_n(state)
   call require(abs(residual)<1d-12,'competing daily whole crop soil nitrogen')
   ledger(2)=ledger(2)+external_in;ledger(3)=ledger(3)+external_out
   ledger(4)=ledger(4)+r%chemical%internal_supply_kg_m2
   ledger(5)=ledger(5)+r%chemical%soil%process%organic%nitrogen%mineralized_n_kg_m2
   ledger(6)=ledger(6)+r%chemical%soil%process%exchange%nh4_nitrified_kg_m2
   ledger(7)=ledger(7)+r%chemical%soil%process%exchange%no3_denitrified_kg_m2
   ledger(8:9)=ledger(8:9)+r%chemical%soil%top_actual
   ledger(10:11)=ledger(10:11)+r%chemical%soil%top_unmet
   ledger(12)=max(ledger(12),abs(residual));ledger(13)=max(ledger(13),r%diagnostics%max_abs_step_mass_residual)
   ledger(14)=crop_soil_whole_n(state)
   if(d+1==1.or.d+1==4)then
    write(arg,'(I0)')d+1
    call write_crop_soil_n_joint_restart_file(trim(path)//'.'//trim(arg),column,cfg%tiles(1)%template, &
     670001_int64,water,state,code);call require(code==0,'competing persistent checkpoint')
    open(newunit=u,file=trim(path)//'.'//trim(arg)//'.ledger',status='replace',form='unformatted',access='stream');write(u)ledger;close(u)
   end if
   print *,'COMPETING_DAY',d+1,r%chemical%internal_supply_kg_m2,r%chemical%soil%process%organic%nitrogen%mineralized_n_kg_m2, &
    r%chemical%soil%top_actual,residual,r%diagnostics%max_abs_step_mass_residual
  end do
  call require(abs(ledger(1)+ledger(2)-ledger(3)-ledger(14))<1d-12,'competing integrated whole N')
  if(crop_nh4.or.crop_both)call require(ledger(4)>0d0,'finite donor actually supplies crop before depletion')
  if(immobilise)call require(ledger(5)<0d0,'actual organic immobilisation competes for NH4')
  call write_crop_soil_n_joint_restart_file(trim(endpoint),column,cfg%tiles(1)%template,670001_int64,water,state,code)
  call require(code==0,'competing complete persistent endpoint')
  open(newunit=u,file=trim(endpoint)//'.ledger',status='replace',form='unformatted',access='stream');write(u)ledger;close(u)
  print *,'NONDEPLETING_COMPETING_JOINT_PASS',trim(selected),ledger
 end subroutine
 subroutine require(ok,label)
  logical,intent(in)::ok
  character(*),intent(in)::label
  if(.not.ok)then;print '(A)','FAIL '//label;error stop 1;end if
 end subroutine
 include 'crop_fixture.inc'
 include 'material_fixture.inc'
 include 'matrix_fixture.inc'
end program
subroutine swap_error(origin,message)
 character(*)::origin,message
 print *,origin,message
 error stop 1
end subroutine
