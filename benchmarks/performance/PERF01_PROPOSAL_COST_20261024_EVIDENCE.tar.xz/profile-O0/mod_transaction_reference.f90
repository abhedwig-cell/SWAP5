module mod_transaction_reference
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite, ieee_value, ieee_quiet_nan
  use, intrinsic :: iso_fortran_env, only: real64, int64
  implicit none
  private

  integer, parameter, public :: TX_STATUS_ACCEPTED = 0
  integer, parameter, public :: TX_STATUS_RETRY_EXHAUSTED = 1
  integer, parameter, public :: TX_STATUS_INVALID_INTERVAL = 2
  integer, parameter, public :: TX_ROUTE_NONE = 0
  integer, parameter, public :: TX_ROUTE_MODEL_CERTIFIED = 1
  integer, parameter, public :: TX_ROUTE_TWO_HALF = 2

  integer, parameter, public :: TX_TEMPORAL_NONE = 0
  integer, parameter, public :: TX_TEMPORAL_EXTERNAL_FULL_HALF = 1
  integer, parameter, public :: TX_TEMPORAL_MODEL_CERTIFICATE = 2

  integer, parameter, public :: TX_INTERFACE_SENSITIVITY_NONE = 0
  integer, parameter, public :: TX_INTERFACE_SENSITIVITY_LOCAL_TERMINAL = 1

  integer(int64), parameter, public :: TX_MASS_MISSING_NONE = 0_int64
  integer(int64), parameter, public :: TX_MASS_MISSING_STORAGE_START = 1_int64
  integer(int64), parameter, public :: TX_MASS_MISSING_STORAGE_END = 2_int64
  integer(int64), parameter, public :: TX_MASS_MISSING_EXTERNAL_FLUX = 4_int64
  integer(int64), parameter, public :: TX_MASS_MISSING_ACTIVE_CONTRIBUTION = 8_int64
  integer(int64), parameter, public :: TX_MASS_MISSING_NONFINITE = 16_int64
  integer(int64), parameter, public :: TX_MASS_MISSING_UNSPECIFIED = 32_int64

  type, abstract, public :: transaction_state_t
  contains
    procedure(clone_state_iface), deferred :: clone
  end type transaction_state_t

  ! Worker/job-local rollback context that accompanies a physical trial but is
  ! deliberately not persistent column state. Legacy adapters may extend this
  ! type with forcing/time/accounting cursors or other trial-only bookkeeping.
  type, public :: transaction_attempt_context_t
  end type transaction_attempt_context_t

  ! Opaque model-owned scratch lifetime. It is neither physical state nor an
  ! externally restorable attempt context. The engine only passes it back.
  type, public :: transaction_scratch_scope_t
    integer(int64) :: token(2) = 0_int64
  end type transaction_scratch_scope_t

  ! Generic accepted-result carrier. It is deliberately result metadata rather
  ! than committed physical state or solver scratch. A model may populate the
  ! value/method on a trial outcome; the transaction core owns accepted-route
  ! provenance and never publishes a rejected trial's value.
  type, public :: transaction_interface_sensitivity_t
    logical :: available = .false.
    integer :: semantic = TX_INTERFACE_SENSITIVITY_NONE
    real(real64) :: dh_bottom_dq_bottom = 0.0_real64
    character(len=24) :: method = 'not-available'
    real(real64) :: origin_t0 = 0.0_real64
    real(real64) :: origin_t1 = 0.0_real64
    logical :: covers_requested_interval = .false.
  end type transaction_interface_sensitivity_t

  type, public :: trial_outcome_t
    logical :: solver_ok = .false.
    real(real64) :: mass_in = 0.0_real64
    real(real64) :: mass_out = 0.0_real64
    logical :: actual_transpiration_available = .false.
    real(real64) :: actual_transpiration_amount = 0.0_real64
    logical :: bottom_interface_exchange_available = .false.
    real(real64) :: bottom_outward_exchange_native = 0.0_real64
    real(real64) :: terminal_bottom_outward_flux_native = 0.0_real64
    logical :: mass_accounting_complete = .false.
    integer(int64) :: missing_mass_contribution_mask = TX_MASS_MISSING_UNSPECIFIED
    logical :: temporal_certificate_available = .false.
    real(real64) :: temporal_indicator = huge(0.0_real64)
    integer :: nonlinear_iterations = 0
    integer :: internal_retries = 0
    integer :: headcalc_calls = 0
    integer :: jacobian_builds = 0
    integer :: linear_solves = 0
    integer :: backtracking_attempts = 0
    integer :: alternative_solver_calls = 0
    integer :: workspace_full_resets = 0
    integer(int64) :: workspace_zeroed_bytes = 0_int64
    type(transaction_interface_sensitivity_t) :: interface_sensitivity
  end type trial_outcome_t

  type, abstract, public :: transaction_model_t
  contains
    procedure(advance_iface), deferred :: advance
    procedure(storage_iface), deferred :: storage
    procedure(temporal_error_iface), deferred :: temporal_error
    procedure :: storage_accounting_status => default_storage_accounting_status
    procedure :: attempt_context_required => default_attempt_context_required
    procedure :: capture_attempt_context => default_capture_attempt_context
    procedure :: restore_attempt_context => default_restore_attempt_context
    procedure :: begin_scratch_scope => default_begin_scratch_scope
    procedure :: end_scratch_scope => default_end_scratch_scope
  end type transaction_model_t

  type, public :: transaction_policy_t
    real(real64) :: temporal_tolerance = 1.0e-6_real64
    real(real64) :: mass_tolerance = 1.0e-10_real64
    real(real64) :: retry_scale = 0.5_real64
    integer :: max_retries = 8
    integer :: temporal_mode = TX_TEMPORAL_EXTERNAL_FULL_HALF
  end type transaction_policy_t

  type, public :: transaction_result_t
    integer :: status = TX_STATUS_INVALID_INTERVAL
    integer :: accepted_route = TX_ROUTE_NONE
    integer :: temporal_acceptance_source = TX_TEMPORAL_NONE
    integer :: attempts = 0
    integer :: retries = 0
    integer :: rollbacks = 0
    integer :: commits = 0
    integer :: full_trials = 0
    integer :: half_trials = 0
    integer :: solver_rejections = 0
    integer :: temporal_rejections = 0
    integer :: temporal_certificate_unavailable_rejections = 0
    integer :: mass_rejections = 0
    integer :: nonlinear_iterations = 0
    integer :: accepted_nonlinear_iterations = 0
    integer :: internal_retries = 0
    integer :: accepted_internal_retries = 0
    integer :: headcalc_calls = 0
    integer :: accepted_headcalc_calls = 0
    integer :: jacobian_builds = 0
    integer :: accepted_jacobian_builds = 0
    integer :: linear_solves = 0
    integer :: accepted_linear_solves = 0
    integer :: backtracking_attempts = 0
    integer :: accepted_backtracking_attempts = 0
    integer :: alternative_solver_calls = 0
    integer :: accepted_alternative_solver_calls = 0
    integer :: workspace_full_resets = 0
    integer(int64) :: workspace_zeroed_bytes = 0_int64
    integer :: accepted_workspace_full_resets = 0
    integer(int64) :: accepted_workspace_zeroed_bytes = 0_int64
    logical :: accepted_mass_complete = .false.
    integer(int64) :: accepted_missing_contribution_mask = TX_MASS_MISSING_UNSPECIFIED
    real(real64) :: accepted_storage_start = 0.0_real64
    real(real64) :: accepted_storage_end = 0.0_real64
    real(real64) :: accepted_storage_change = 0.0_real64
    real(real64) :: accepted_total_in = 0.0_real64
    real(real64) :: accepted_total_out = 0.0_real64
    logical :: actual_transpiration_available = .false.
    real(real64) :: actual_transpiration_amount = 0.0_real64
    logical :: bottom_interface_exchange_available = .false.
    real(real64) :: accepted_bottom_outward_exchange_native = 0.0_real64
    real(real64) :: terminal_bottom_outward_flux_native = 0.0_real64
    real(real64) :: accepted_mass_residual = huge(0.0_real64)
    real(real64) :: requested_t0 = 0.0_real64
    real(real64) :: requested_t1 = 0.0_real64
    real(real64) :: accepted_t1 = 0.0_real64
    real(real64) :: accepted_dt = 0.0_real64
    real(real64) :: temporal_error = huge(0.0_real64)
    real(real64) :: temporal_indicator = huge(0.0_real64)
    real(real64) :: full_mass_residual = huge(0.0_real64)
    real(real64) :: half_mass_residual = huge(0.0_real64)
    type(transaction_interface_sensitivity_t) :: interface_sensitivity
  end type transaction_result_t

  public :: execute_reference_interval

  abstract interface
    subroutine clone_state_iface(self, copy)
      import :: transaction_state_t
      class(transaction_state_t), intent(in) :: self
      class(transaction_state_t), allocatable, intent(out) :: copy
    end subroutine clone_state_iface

    subroutine advance_iface(self, state, t0, t1, outcome)
      import :: transaction_model_t, transaction_state_t, trial_outcome_t, real64
      class(transaction_model_t), intent(inout) :: self
      class(transaction_state_t), intent(inout) :: state
      real(real64), intent(in) :: t0, t1
      type(trial_outcome_t), intent(out) :: outcome
    end subroutine advance_iface

    function storage_iface(self, state) result(value)
      import :: transaction_model_t, transaction_state_t, real64
      class(transaction_model_t), intent(in) :: self
      class(transaction_state_t), intent(in) :: state
      real(real64) :: value
    end function storage_iface

    function temporal_error_iface(self, full_state, half_state) result(value)
      import :: transaction_model_t, transaction_state_t, real64
      class(transaction_model_t), intent(in) :: self
      class(transaction_state_t), intent(in) :: full_state
      class(transaction_state_t), intent(in) :: half_state
      real(real64) :: value
    end function temporal_error_iface
  end interface

contains

  logical function default_attempt_context_required(self) result(required)
    class(transaction_model_t), intent(in) :: self
    if (.not. same_type_as(self, self)) error stop 'unreachable transaction model type'
    required = .true.
  end function default_attempt_context_required

  subroutine default_capture_attempt_context(self, context)
    class(transaction_model_t), intent(inout) :: self
    class(transaction_attempt_context_t), allocatable, intent(out) :: context
    if (.not. same_type_as(self, self)) error stop 'unreachable transaction model type'
    allocate(transaction_attempt_context_t :: context)
  end subroutine default_capture_attempt_context

  subroutine default_restore_attempt_context(self, context)
    class(transaction_model_t), intent(inout) :: self
    class(transaction_attempt_context_t), intent(in) :: context
    if (.not. same_type_as(self, self) .or. .not. same_type_as(context, context)) then
      error stop 'unreachable transaction attempt context type'
    end if
  end subroutine default_restore_attempt_context

  subroutine default_storage_accounting_status(self, state, complete, missing_mask)
    class(transaction_model_t), intent(in) :: self
    class(transaction_state_t), intent(in) :: state
    logical, intent(out) :: complete
    integer(int64), intent(out) :: missing_mask

    if (.not. same_type_as(self, self) .or. .not. same_type_as(state, state)) then
      error stop 'unreachable transaction mass-accounting type'
    end if
    complete = .false.
    missing_mask = TX_MASS_MISSING_UNSPECIFIED
  end subroutine default_storage_accounting_status

  subroutine default_begin_scratch_scope(self, scope)
    class(transaction_model_t), intent(inout) :: self
    type(transaction_scratch_scope_t), intent(out) :: scope
    if (.not. same_type_as(self, self)) error stop 'unreachable transaction model type'
    scope = transaction_scratch_scope_t()
  end subroutine default_begin_scratch_scope

  subroutine default_end_scratch_scope(self, scope)
    class(transaction_model_t), intent(inout) :: self
    type(transaction_scratch_scope_t), intent(in) :: scope
    if (.not. same_type_as(self, self) .or. any(scope%token /= 0_int64)) &
         error stop 'invalid default transaction scratch scope'
  end subroutine default_end_scratch_scope

  subroutine execute_reference_interval(model, committed, t0, t1, policy, result)
 use perf_clock
    class(transaction_model_t), intent(inout) :: model
    class(transaction_state_t), allocatable, intent(inout) :: committed
    real(real64), intent(in) :: t0, t1
    type(transaction_policy_t), intent(in) :: policy
    type(transaction_result_t), intent(out) :: result
    type(transaction_scratch_scope_t) :: scope

    call model%begin_scratch_scope(scope)
call perf_start(2)
    call execute_reference_interval_body(model, committed, t0, t1, policy, result)
call perf_stop(2)
    ! The body's private checkpoint/half contexts have now left scope. A model
    ! may reclaim their abandoned scratch without invalidating live contexts.
    call model%end_scratch_scope(scope)
  end subroutine execute_reference_interval

  subroutine execute_reference_interval_body(model, committed, t0, t1, policy, result)
 use perf_clock
    class(transaction_model_t), intent(inout) :: model
    class(transaction_state_t), allocatable, intent(inout) :: committed
    real(real64), intent(in) :: t0, t1
    type(transaction_policy_t), intent(in) :: policy
    type(transaction_result_t), intent(out) :: result

    class(transaction_state_t), allocatable :: checkpoint
    class(transaction_state_t), allocatable :: full_state
    class(transaction_state_t), allocatable :: half_state
    class(transaction_attempt_context_t), allocatable :: checkpoint_context
    class(transaction_attempt_context_t), allocatable :: half_context
    type(trial_outcome_t) :: full_outcome, half1_outcome, half2_outcome
    real(real64) :: attempt_dt, attempt_t1, midpoint
    real(real64) :: storage0, storage_full, storage_half
    real(real64) :: full_mass_residual, half_mass_residual, terr
    logical :: solver_ok, mass_ok, temporal_ok, context_required
    logical :: storage_start_complete, storage_end_complete, full_storage_end_complete
    integer(int64) :: start_missing_mask, end_missing_mask, accepted_missing_mask
    integer(int64) :: full_end_missing_mask, full_missing_mask
    integer :: retry_index

    result = transaction_result_t()
    result%requested_t0 = t0
    result%requested_t1 = t1
    result%accepted_t1 = t0

    if (.not. valid_policy(policy) .or. t1 <= t0 .or. .not. allocated(committed)) then
      result%status = TX_STATUS_INVALID_INTERVAL
      return
    end if

    if (policy%temporal_mode == TX_TEMPORAL_MODEL_CERTIFICATE) then
      call execute_model_certificate_interval(model, committed, t0, t1, policy, result)
      return
    end if
    result%temporal_acceptance_source = TX_TEMPORAL_EXTERNAL_FULL_HALF

    context_required = model%attempt_context_required()
    call committed%clone(checkpoint)
    if (context_required) call model%capture_attempt_context(checkpoint_context)
    call model%storage_accounting_status(checkpoint, storage_start_complete, start_missing_mask)
    if (storage_start_complete) then
      storage0 = model%storage(checkpoint)
    else
      storage0 = ieee_value(0.0_real64, ieee_quiet_nan)
    end if
    attempt_dt = t1 - t0

    do retry_index = 0, policy%max_retries
 call perf_start(5)
      result%attempts = result%attempts + 1
      attempt_t1 = t0 + attempt_dt
      midpoint = t0 + 0.5_real64 * attempt_dt

      if (context_required) call model%restore_attempt_context(checkpoint_context)
      call checkpoint%clone(full_state)
call perf_start(3)
      call model%advance(full_state, t0, attempt_t1, full_outcome)
call perf_stop(3)
      result%full_trials = result%full_trials + 1
      result%nonlinear_iterations = result%nonlinear_iterations + full_outcome%nonlinear_iterations
      result%internal_retries = result%internal_retries + full_outcome%internal_retries
      result%headcalc_calls = result%headcalc_calls + full_outcome%headcalc_calls
      result%jacobian_builds = result%jacobian_builds + full_outcome%jacobian_builds
      result%linear_solves = result%linear_solves + full_outcome%linear_solves
      result%backtracking_attempts = result%backtracking_attempts + full_outcome%backtracking_attempts
      result%alternative_solver_calls = result%alternative_solver_calls + full_outcome%alternative_solver_calls
      result%workspace_full_resets = result%workspace_full_resets + full_outcome%workspace_full_resets
      result%workspace_zeroed_bytes = result%workspace_zeroed_bytes + full_outcome%workspace_zeroed_bytes

      if (.not. full_outcome%solver_ok) then
        result%solver_rejections = result%solver_rejections + 1
        if (context_required) call model%restore_attempt_context(checkpoint_context)
        call perf_stop(5)
        call reject_and_retry(result, retry_index, policy, attempt_dt)
        if (result%status == TX_STATUS_RETRY_EXHAUSTED) return
        cycle
      end if

      call model%storage_accounting_status(full_state, full_storage_end_complete, full_end_missing_mask)
      if (full_storage_end_complete) then
        storage_full = model%storage(full_state)
      else
        storage_full = ieee_value(0.0_real64, ieee_quiet_nan)
      end if
      full_mass_residual = storage_full - storage0 - (full_outcome%mass_in - full_outcome%mass_out)
      full_missing_mask = ior(start_missing_mask, full_end_missing_mask)
      full_missing_mask = ior(full_missing_mask, full_outcome%missing_mass_contribution_mask)
      if (.not. storage_start_complete) full_missing_mask = &
           ior(full_missing_mask, TX_MASS_MISSING_STORAGE_START)
      if (.not. full_storage_end_complete) full_missing_mask = &
           ior(full_missing_mask, TX_MASS_MISSING_STORAGE_END)
      if (.not. full_outcome%mass_accounting_complete) full_missing_mask = &
           ior(full_missing_mask, TX_MASS_MISSING_EXTERNAL_FLUX)
      if (.not. ieee_is_finite(storage0) .or. .not. ieee_is_finite(storage_full) .or. &
          .not. ieee_is_finite(storage_full - storage0) .or. &
          .not. ieee_is_finite(full_outcome%mass_in) .or. .not. ieee_is_finite(full_outcome%mass_out) .or. &
          .not. ieee_is_finite(full_mass_residual)) then
        full_missing_mask = ior(full_missing_mask, TX_MASS_MISSING_NONFINITE)
      end if

      if (context_required) call model%restore_attempt_context(checkpoint_context)
      call checkpoint%clone(half_state)
call perf_start(3)
      call model%advance(half_state, t0, midpoint, half1_outcome)
call perf_stop(3)
      result%half_trials = result%half_trials + 1
      result%nonlinear_iterations = result%nonlinear_iterations + half1_outcome%nonlinear_iterations
      result%internal_retries = result%internal_retries + half1_outcome%internal_retries
      result%headcalc_calls = result%headcalc_calls + half1_outcome%headcalc_calls
      result%jacobian_builds = result%jacobian_builds + half1_outcome%jacobian_builds
      result%linear_solves = result%linear_solves + half1_outcome%linear_solves
      result%backtracking_attempts = result%backtracking_attempts + half1_outcome%backtracking_attempts
      result%alternative_solver_calls = result%alternative_solver_calls + half1_outcome%alternative_solver_calls
      result%workspace_full_resets = result%workspace_full_resets + half1_outcome%workspace_full_resets
      result%workspace_zeroed_bytes = result%workspace_zeroed_bytes + half1_outcome%workspace_zeroed_bytes

      if (half1_outcome%solver_ok) then
call perf_start(3)
        call model%advance(half_state, midpoint, attempt_t1, half2_outcome)
call perf_stop(3)
        result%half_trials = result%half_trials + 1
        result%nonlinear_iterations = result%nonlinear_iterations + half2_outcome%nonlinear_iterations
        result%internal_retries = result%internal_retries + half2_outcome%internal_retries
        result%headcalc_calls = result%headcalc_calls + half2_outcome%headcalc_calls
        result%jacobian_builds = result%jacobian_builds + half2_outcome%jacobian_builds
        result%linear_solves = result%linear_solves + half2_outcome%linear_solves
        result%backtracking_attempts = result%backtracking_attempts + half2_outcome%backtracking_attempts
        result%alternative_solver_calls = result%alternative_solver_calls + half2_outcome%alternative_solver_calls
        result%workspace_full_resets = result%workspace_full_resets + half2_outcome%workspace_full_resets
        result%workspace_zeroed_bytes = result%workspace_zeroed_bytes + half2_outcome%workspace_zeroed_bytes
        if (context_required) call model%capture_attempt_context(half_context)
      else
        half2_outcome = trial_outcome_t()
      end if

      solver_ok = half1_outcome%solver_ok .and. half2_outcome%solver_ok
      if (.not. solver_ok) then
        result%solver_rejections = result%solver_rejections + 1
        if (context_required) call model%restore_attempt_context(checkpoint_context)
        call perf_stop(5)
        call reject_and_retry(result, retry_index, policy, attempt_dt)
        if (result%status == TX_STATUS_RETRY_EXHAUSTED) return
        cycle
      end if

      call model%storage_accounting_status(half_state, storage_end_complete, end_missing_mask)
      if (storage_end_complete) then
        storage_half = model%storage(half_state)
      else
        storage_half = ieee_value(0.0_real64, ieee_quiet_nan)
      end if
      half_mass_residual = storage_half - storage0 - &
        ((half1_outcome%mass_in + half2_outcome%mass_in) - &
         (half1_outcome%mass_out + half2_outcome%mass_out))
      terr = model%temporal_error(full_state, half_state)

      result%full_mass_residual = full_mass_residual
      result%half_mass_residual = half_mass_residual
      result%temporal_error = terr

      accepted_missing_mask = ior(start_missing_mask, end_missing_mask)
      accepted_missing_mask = ior(accepted_missing_mask, half1_outcome%missing_mass_contribution_mask)
      accepted_missing_mask = ior(accepted_missing_mask, half2_outcome%missing_mass_contribution_mask)
      if (.not. storage_start_complete) accepted_missing_mask = &
           ior(accepted_missing_mask, TX_MASS_MISSING_STORAGE_START)
      if (.not. storage_end_complete) accepted_missing_mask = &
           ior(accepted_missing_mask, TX_MASS_MISSING_STORAGE_END)
      if (.not. half1_outcome%mass_accounting_complete .or. &
          .not. half2_outcome%mass_accounting_complete) then
        accepted_missing_mask = ior(accepted_missing_mask, TX_MASS_MISSING_EXTERNAL_FLUX)
      end if
      if (.not. ieee_is_finite(storage0) .or. .not. ieee_is_finite(storage_half) .or. &
          .not. ieee_is_finite(storage_half - storage0) .or. &
          .not. ieee_is_finite(half1_outcome%mass_in) .or. .not. ieee_is_finite(half1_outcome%mass_out) .or. &
          .not. ieee_is_finite(half2_outcome%mass_in) .or. .not. ieee_is_finite(half2_outcome%mass_out) .or. &
          .not. ieee_is_finite(half_mass_residual)) then
        accepted_missing_mask = ior(accepted_missing_mask, TX_MASS_MISSING_NONFINITE)
      end if

      mass_ok = full_missing_mask == TX_MASS_MISSING_NONE .and. &
                accepted_missing_mask == TX_MASS_MISSING_NONE .and. &
                storage_start_complete .and. full_storage_end_complete .and. &
                full_outcome%mass_accounting_complete .and. storage_end_complete .and. &
                half1_outcome%mass_accounting_complete .and. half2_outcome%mass_accounting_complete
      if (mass_ok) then
        mass_ok = abs(full_mass_residual) <= policy%mass_tolerance .and. &
                  abs(half_mass_residual) <= policy%mass_tolerance
      end if
      temporal_ok = terr <= policy%temporal_tolerance

      if (.not. mass_ok) then
        result%mass_rejections = result%mass_rejections + 1
        if (context_required) call model%restore_attempt_context(checkpoint_context)
        call perf_stop(5)
        call reject_and_retry(result, retry_index, policy, attempt_dt)
        if (result%status == TX_STATUS_RETRY_EXHAUSTED) return
        cycle
      end if

      if (.not. temporal_ok) then
        result%temporal_rejections = result%temporal_rejections + 1
        if (context_required) call model%restore_attempt_context(checkpoint_context)
        call perf_stop(5)
        call reject_and_retry(result, retry_index, policy, attempt_dt)
        if (result%status == TX_STATUS_RETRY_EXHAUSTED) return
        cycle
      end if

      result%accepted_storage_start = storage0
      result%accepted_storage_end = storage_half
      result%accepted_storage_change = storage_half - storage0
      result%accepted_total_in = half1_outcome%mass_in + half2_outcome%mass_in
      result%accepted_total_out = half1_outcome%mass_out + half2_outcome%mass_out
      result%actual_transpiration_available = half1_outcome%actual_transpiration_available .and. &
           half2_outcome%actual_transpiration_available
      if(result%actual_transpiration_available) then
        result%actual_transpiration_available=ieee_is_finite(half1_outcome%actual_transpiration_amount).and. &
             ieee_is_finite(half2_outcome%actual_transpiration_amount).and. &
             half1_outcome%actual_transpiration_amount>=0.0_real64.and.half2_outcome%actual_transpiration_amount>=0.0_real64
      end if
      if(result%actual_transpiration_available) then
        result%actual_transpiration_amount = half1_outcome%actual_transpiration_amount + &
             half2_outcome%actual_transpiration_amount
        if(.not.ieee_is_finite(result%actual_transpiration_amount).or.result%actual_transpiration_amount<0.0_real64) then
          result%actual_transpiration_available=.false.;result%actual_transpiration_amount=0.0_real64
        end if
      end if
      result%bottom_interface_exchange_available = half1_outcome%bottom_interface_exchange_available .and. &
           half2_outcome%bottom_interface_exchange_available
      if (result%bottom_interface_exchange_available) then
        result%accepted_bottom_outward_exchange_native = half1_outcome%bottom_outward_exchange_native + &
             half2_outcome%bottom_outward_exchange_native
        result%terminal_bottom_outward_flux_native = half2_outcome%terminal_bottom_outward_flux_native
        if (.not. ieee_is_finite(result%accepted_bottom_outward_exchange_native) .or. &
            .not. ieee_is_finite(result%terminal_bottom_outward_flux_native)) then
          result%bottom_interface_exchange_available = .false.
          result%accepted_bottom_outward_exchange_native = 0.0_real64
          result%terminal_bottom_outward_flux_native = 0.0_real64
        end if
      end if
      result%accepted_mass_residual = half_mass_residual
      result%accepted_missing_contribution_mask = accepted_missing_mask
      result%accepted_mass_complete = storage_start_complete .and. storage_end_complete .and. &
           half1_outcome%mass_accounting_complete .and. half2_outcome%mass_accounting_complete .and. &
           accepted_missing_mask == TX_MASS_MISSING_NONE

      if (context_required) call model%restore_attempt_context(half_context)
      call move_alloc(half_state, committed)
      result%status = TX_STATUS_ACCEPTED
      result%accepted_route = TX_ROUTE_TWO_HALF
      result%accepted_t1 = attempt_t1
      result%accepted_dt = attempt_dt
      result%accepted_nonlinear_iterations = half1_outcome%nonlinear_iterations + half2_outcome%nonlinear_iterations
      result%accepted_internal_retries = half1_outcome%internal_retries + half2_outcome%internal_retries
      result%accepted_headcalc_calls = half1_outcome%headcalc_calls + half2_outcome%headcalc_calls
      result%accepted_jacobian_builds = half1_outcome%jacobian_builds + half2_outcome%jacobian_builds
      result%accepted_linear_solves = half1_outcome%linear_solves + half2_outcome%linear_solves
      result%accepted_backtracking_attempts = half1_outcome%backtracking_attempts + half2_outcome%backtracking_attempts
      result%accepted_alternative_solver_calls = half1_outcome%alternative_solver_calls + half2_outcome%alternative_solver_calls
      result%accepted_workspace_full_resets = half1_outcome%workspace_full_resets + half2_outcome%workspace_full_resets
      result%accepted_workspace_zeroed_bytes = half1_outcome%workspace_zeroed_bytes + half2_outcome%workspace_zeroed_bytes
      call publish_local_terminal_sensitivity(half2_outcome%interface_sensitivity, midpoint, attempt_t1, &
           t0, t1, result%interface_sensitivity)
      result%commits = result%commits + 1
      return
    end do

    if (context_required) call model%restore_attempt_context(checkpoint_context)
    result%status = TX_STATUS_RETRY_EXHAUSTED
  end subroutine execute_reference_interval_body

  subroutine execute_model_certificate_interval(model, committed, t0, t1, policy, result)
 use perf_clock
    class(transaction_model_t), intent(inout) :: model
    class(transaction_state_t), allocatable, intent(inout) :: committed
    real(real64), intent(in) :: t0, t1
    type(transaction_policy_t), intent(in) :: policy
    type(transaction_result_t), intent(out) :: result

    class(transaction_state_t), allocatable :: checkpoint
    class(transaction_state_t), allocatable :: candidate_state
    class(transaction_attempt_context_t), allocatable :: checkpoint_context
    class(transaction_attempt_context_t), allocatable :: accepted_context
    type(trial_outcome_t) :: outcome
    real(real64) :: attempt_dt, attempt_t1
    real(real64) :: storage0, storage_candidate, mass_residual
    logical :: mass_ok, temporal_ok, certificate_valid, context_required
    logical :: storage_start_complete, storage_end_complete
    integer(int64) :: start_missing_mask, end_missing_mask, accepted_missing_mask
    integer :: retry_index

    result = transaction_result_t()
    result%requested_t0 = t0
    result%requested_t1 = t1
    result%accepted_t1 = t0
    result%temporal_acceptance_source = TX_TEMPORAL_MODEL_CERTIFICATE

    context_required = model%attempt_context_required()
    call committed%clone(checkpoint)
    if (context_required) call model%capture_attempt_context(checkpoint_context)
    call model%storage_accounting_status(checkpoint, storage_start_complete, start_missing_mask)
    if (storage_start_complete) then
      storage0 = model%storage(checkpoint)
    else
      storage0 = ieee_value(0.0_real64, ieee_quiet_nan)
    end if
    attempt_dt = t1 - t0

    do retry_index = 0, policy%max_retries
 call perf_start(5)
      result%attempts = result%attempts + 1
      attempt_t1 = t0 + attempt_dt

      if (context_required) call model%restore_attempt_context(checkpoint_context)
      call checkpoint%clone(candidate_state)
call perf_start(3)
      call model%advance(candidate_state, t0, attempt_t1, outcome)
call perf_stop(3)
      result%full_trials = result%full_trials + 1
      result%nonlinear_iterations = result%nonlinear_iterations + outcome%nonlinear_iterations
      result%internal_retries = result%internal_retries + outcome%internal_retries
      result%headcalc_calls = result%headcalc_calls + outcome%headcalc_calls
      result%jacobian_builds = result%jacobian_builds + outcome%jacobian_builds
      result%linear_solves = result%linear_solves + outcome%linear_solves
      result%backtracking_attempts = result%backtracking_attempts + outcome%backtracking_attempts
      result%alternative_solver_calls = result%alternative_solver_calls + outcome%alternative_solver_calls
      result%workspace_full_resets = result%workspace_full_resets + outcome%workspace_full_resets
      result%workspace_zeroed_bytes = result%workspace_zeroed_bytes + outcome%workspace_zeroed_bytes

      if (.not. outcome%solver_ok) then
        result%solver_rejections = result%solver_rejections + 1
        if (context_required) call model%restore_attempt_context(checkpoint_context)
        call perf_stop(5)
        call reject_and_retry(result, retry_index, policy, attempt_dt)
        if (result%status == TX_STATUS_RETRY_EXHAUSTED) return
        cycle
      end if

      if (context_required) call model%capture_attempt_context(accepted_context)
      call model%storage_accounting_status(candidate_state, storage_end_complete, end_missing_mask)
      if (storage_end_complete) then
        storage_candidate = model%storage(candidate_state)
      else
        storage_candidate = ieee_value(0.0_real64, ieee_quiet_nan)
      end if
      mass_residual = storage_candidate - storage0 - (outcome%mass_in - outcome%mass_out)
      result%full_mass_residual = mass_residual
      result%accepted_mass_residual = mass_residual
      result%temporal_indicator = outcome%temporal_indicator

      accepted_missing_mask = ior(start_missing_mask, end_missing_mask)
      accepted_missing_mask = ior(accepted_missing_mask, outcome%missing_mass_contribution_mask)
      if (.not. storage_start_complete) accepted_missing_mask = &
           ior(accepted_missing_mask, TX_MASS_MISSING_STORAGE_START)
      if (.not. storage_end_complete) accepted_missing_mask = &
           ior(accepted_missing_mask, TX_MASS_MISSING_STORAGE_END)
      if (.not. outcome%mass_accounting_complete) accepted_missing_mask = &
           ior(accepted_missing_mask, TX_MASS_MISSING_EXTERNAL_FLUX)
      if (.not. ieee_is_finite(storage0) .or. .not. ieee_is_finite(storage_candidate) .or. &
          .not. ieee_is_finite(storage_candidate - storage0) .or. &
          .not. ieee_is_finite(outcome%mass_in) .or. .not. ieee_is_finite(outcome%mass_out) .or. &
          .not. ieee_is_finite(mass_residual)) then
        accepted_missing_mask = ior(accepted_missing_mask, TX_MASS_MISSING_NONFINITE)
      end if

      mass_ok = storage_start_complete .and. storage_end_complete .and. &
                outcome%mass_accounting_complete .and. &
                accepted_missing_mask == TX_MASS_MISSING_NONE
      if (mass_ok) mass_ok = abs(mass_residual) <= policy%mass_tolerance

      if (.not. mass_ok) then
        result%mass_rejections = result%mass_rejections + 1
        if (context_required) call model%restore_attempt_context(checkpoint_context)
        call perf_stop(5)
        call reject_and_retry(result, retry_index, policy, attempt_dt)
        if (result%status == TX_STATUS_RETRY_EXHAUSTED) return
        cycle
      end if

      certificate_valid = outcome%temporal_certificate_available .and. &
           ieee_is_finite(outcome%temporal_indicator) .and. outcome%temporal_indicator >= 0.0_real64
      temporal_ok = certificate_valid .and. outcome%temporal_indicator <= 1.0_real64
      if (.not. certificate_valid) then
        result%temporal_certificate_unavailable_rejections = &
             result%temporal_certificate_unavailable_rejections + 1
      end if
      if (.not. temporal_ok) then
        result%temporal_rejections = result%temporal_rejections + 1
        if (context_required) call model%restore_attempt_context(checkpoint_context)
        call perf_stop(5)
        call reject_and_retry(result, retry_index, policy, attempt_dt)
        if (result%status == TX_STATUS_RETRY_EXHAUSTED) return
        cycle
      end if

      result%accepted_storage_start = storage0
      result%accepted_storage_end = storage_candidate
      result%accepted_storage_change = storage_candidate - storage0
      result%accepted_total_in = outcome%mass_in
      result%accepted_total_out = outcome%mass_out
      result%actual_transpiration_available = outcome%actual_transpiration_available
      if(result%actual_transpiration_available) then
        result%actual_transpiration_amount=outcome%actual_transpiration_amount
        if(.not.ieee_is_finite(result%actual_transpiration_amount).or.result%actual_transpiration_amount<0.0_real64) then
          result%actual_transpiration_available=.false.;result%actual_transpiration_amount=0.0_real64
        end if
      end if
      result%bottom_interface_exchange_available = outcome%bottom_interface_exchange_available
      if (result%bottom_interface_exchange_available) then
        result%accepted_bottom_outward_exchange_native = outcome%bottom_outward_exchange_native
        result%terminal_bottom_outward_flux_native = outcome%terminal_bottom_outward_flux_native
        if (.not. ieee_is_finite(result%accepted_bottom_outward_exchange_native) .or. &
            .not. ieee_is_finite(result%terminal_bottom_outward_flux_native)) then
          result%bottom_interface_exchange_available = .false.
          result%accepted_bottom_outward_exchange_native = 0.0_real64
          result%terminal_bottom_outward_flux_native = 0.0_real64
        end if
      end if
      result%accepted_missing_contribution_mask = accepted_missing_mask
      result%accepted_mass_complete = storage_start_complete .and. storage_end_complete .and. &
           outcome%mass_accounting_complete .and. accepted_missing_mask == TX_MASS_MISSING_NONE

      if (context_required) call model%restore_attempt_context(accepted_context)
      call move_alloc(candidate_state, committed)
      result%status = TX_STATUS_ACCEPTED
      result%accepted_route = TX_ROUTE_MODEL_CERTIFIED
      result%accepted_t1 = attempt_t1
      result%accepted_dt = attempt_dt
      result%accepted_nonlinear_iterations = outcome%nonlinear_iterations
      result%accepted_internal_retries = outcome%internal_retries
      result%accepted_headcalc_calls = outcome%headcalc_calls
      result%accepted_jacobian_builds = outcome%jacobian_builds
      result%accepted_linear_solves = outcome%linear_solves
      result%accepted_backtracking_attempts = outcome%backtracking_attempts
      result%accepted_alternative_solver_calls = outcome%alternative_solver_calls
      result%accepted_workspace_full_resets = outcome%workspace_full_resets
      result%accepted_workspace_zeroed_bytes = outcome%workspace_zeroed_bytes
      call publish_local_terminal_sensitivity(outcome%interface_sensitivity, t0, attempt_t1, &
           t0, t1, result%interface_sensitivity)
      result%commits = result%commits + 1
      return
    end do

    if (context_required) call model%restore_attempt_context(checkpoint_context)
    result%status = TX_STATUS_RETRY_EXHAUSTED
  end subroutine execute_model_certificate_interval

  subroutine publish_local_terminal_sensitivity(source, origin_t0, origin_t1, requested_t0, requested_t1, published)
    type(transaction_interface_sensitivity_t), intent(in) :: source
    real(real64), intent(in) :: origin_t0, origin_t1, requested_t0, requested_t1
    type(transaction_interface_sensitivity_t), intent(out) :: published

    published = transaction_interface_sensitivity_t()
    if (.not. source%available) return
    published%available = .true.
    published%semantic = TX_INTERFACE_SENSITIVITY_LOCAL_TERMINAL
    published%dh_bottom_dq_bottom = source%dh_bottom_dq_bottom
    published%method = source%method
    published%origin_t0 = origin_t0
    published%origin_t1 = origin_t1
    published%covers_requested_interval = ordered_real_equal(origin_t0, requested_t0) .and. &
         ordered_real_equal(origin_t1, requested_t1)
  end subroutine publish_local_terminal_sensitivity

  pure logical function ordered_real_equal(a, b) result(matches)
    real(real64), intent(in) :: a, b
    ! Exact ordered IEEE equality without REAL == so strict warning builds keep
    ! the original no-tolerance coverage semantics.
    matches = a <= b .and. b <= a
  end function ordered_real_equal

  subroutine reject_and_retry(result, retry_index, policy, attempt_dt)
    type(transaction_result_t), intent(inout) :: result
    integer, intent(in) :: retry_index
    type(transaction_policy_t), intent(in) :: policy
    real(real64), intent(inout) :: attempt_dt

    result%rollbacks = result%rollbacks + 1
    if (retry_index >= policy%max_retries) then
      result%status = TX_STATUS_RETRY_EXHAUSTED
      return
    end if
    result%retries = result%retries + 1
    attempt_dt = attempt_dt * policy%retry_scale
  end subroutine reject_and_retry

  pure logical function valid_policy(policy)
    type(transaction_policy_t), intent(in) :: policy
    valid_policy = policy%temporal_tolerance >= 0.0_real64 .and. &
                   policy%mass_tolerance >= 0.0_real64 .and. &
                   policy%retry_scale > 0.0_real64 .and. policy%retry_scale < 1.0_real64 .and. &
                   policy%max_retries >= 0 .and. &
                   (policy%temporal_mode == TX_TEMPORAL_EXTERNAL_FULL_HALF .or. &
                    policy%temporal_mode == TX_TEMPORAL_MODEL_CERTIFICATE)
  end function valid_policy

end module mod_transaction_reference
