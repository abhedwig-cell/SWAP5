module perf_clock
 use iso_fortran_env,only:int64,real64
 implicit none
 integer(int64)::started(10)=0,total(10)=0,calls(10)=0,counts(12,5)=0
 integer(int64)::regime_ticks(5)=0,reject_ticks(5)=0,before_tx,before_reject,abandoned=0
 integer::phase=0
 contains
 subroutine perf_start(k)
 integer,intent(in)::k
 call system_clock(started(k))
 calls(k)=calls(k)+1
 end subroutine
 subroutine perf_stop(k)
 integer,intent(in)::k
 integer(int64)::now
 call system_clock(now)
 total(k)=total(k)+now-started(k)
 end subroutine
 subroutine perf_report()
 integer::u,k
 integer(int64)::rate
 call system_clock(count_rate=rate)
 open(newunit=u,file='profile.csv',status='new')
 write(u,'(A)')'category,seconds,calls'
 do k=1,10
 write(u,'(I0,A,ES25.17E3,A,I0)')k,',',real(total(k),real64)/real(rate,real64),',',calls(k)
 enddo
 close(u)
 open(newunit=u,file='regimes.txt',status='new')
 do k=1,5
 write(u,'(I0,2(1X,ES25.17E3),12(1X,I0))')k,real(regime_ticks(k),real64)/real(rate,real64), &
 real(reject_ticks(k),real64)/real(rate,real64),counts(:,k)
 enddo
 close(u)
 open(newunit=u,file='abandoned.txt',status='new')
 write(u,*)real(abandoned,real64)/real(rate,real64)
 close(u)
 end subroutine
 end module
