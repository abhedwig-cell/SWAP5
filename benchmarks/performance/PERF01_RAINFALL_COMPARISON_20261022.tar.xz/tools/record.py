from pathlib import Path
import hashlib,io,json,runpy,sys,tarfile
root=Path('/workspace/scratch/324eaf19444d/SWAP5');sys.argv=['assess','/tmp'];helper=runpy.run_path(str(root/'benchmarks/performance/assess_perf01_weather.py'));sha=lambda raw:hashlib.sha256(raw).hexdigest()
b1=json.loads(Path('/tmp/wet4-comparison-1x-build/BUILD.json').read_text());b4=json.loads(Path('/tmp/wet4-review-20261022-fallback-O2/BUILD.json').read_text());assert b1['executable_sha256']==b4['executable_sha256'] and b1['sources']==b4['sources'] and b1['headcalc_sha256']==b4['headcalc_sha256'];assert sha((root/'src/legacy/b1_10_port/headcalc.f90').read_bytes())==b1['headcalc_sha256']
files={};cases=[]
for case,name4 in [('1e6','strict'),('1e4','1e4'),('1e3','1e3'),('1e2','1e2'),('1e1','1e1'),('1','1')]:
 pairs=[]
 for label,path,expected in [('1x',Path('/tmp/wet4-comparison-1x-'+case),227),('4x',Path('/tmp/wet4-review-20261022-fallback-'+name4),908)]:
  m,rows=helper['read'](path);assert m['expected_rain_mm']==expected and m['totals']['rain_mm']==expected;assert m['executable_sha256']==b1['executable_sha256'];pairs.append(m)
  for p in path.iterdir():
   if p.is_file():files[label+'/'+case+'/'+p.name]=p.read_bytes()
 cases.append({'tolerance_cm':pairs[0]['head_budget_cm'],'1x_cpu_seconds':pairs[0]['user_seconds'],'4x_cpu_seconds':pairs[1]['user_seconds'],'4x_over_1x_cpu':pairs[1]['user_seconds']/pairs[0]['user_seconds'],'1x':pairs[0],'4x':pairs[1]})
s={'status':'SAME_REPAIRED_EXECUTABLE_97DAY_RAINFALL_COMPARISON_COMPLETE','source_commit':'a1c127a6e6ad6c09c2133eff27d85a3f3d1005a7','executable_sha256':b1['executable_sha256'],'headcalc_sha256':b1['headcalc_sha256'],'scope':'Same repaired4cell30cm97day illustrative Reference/MvG/freebottom live crop/weather/heat executable,64windows/day. Only rainfall differs, exactly4x in116weather records;227vs908mmover97days.','cases':cases,'limits':['Single CPU observations,not alternating repeated benchmark or portable speed guarantee','Older1xcurve used historical model-certificate temporal estimation; current repaired path uses full/half temporal control. Not matched-accuracy old/new speed evidence.','No field calibration or canonical admission change']}
p=root/'benchmarks/performance/PERF01_RAINFALL_COMPARISON_20261022.json';p.write_text(json.dumps(s,indent=2)+'\n');files['comparison.json']=p.read_bytes();files['build/1x/BUILD.json']=json.dumps(b1,indent=2).encode();files['build/4x/BUILD.json']=json.dumps(b4,indent=2).encode();files['build/1x/weather.999']=Path('/tmp/wet4-comparison-1x-build/weather.999').read_bytes();files['build/4x/weather.999']=Path('/tmp/wet4-review-20261022-fallback-O2/weather.999').read_bytes();files['tools/record.py']=Path(__file__).read_bytes();files['MANIFEST.json']=(json.dumps({p:sha(raw) for p,raw in files.items()},indent=2)+'\n').encode();archive=p.with_suffix('.tar.xz')
with tarfile.open(archive,'w:xz') as tar:
 for name,raw in sorted(files.items()):
  m=tarfile.TarInfo(name);m.size=len(raw);m.mtime=0;tar.addfile(m,io.BytesIO(raw))
idx={'path':str(archive.relative_to(root)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(files)};archive.with_suffix('.index.json').write_text(json.dumps(idx,indent=2)+'\n')
status=root/'benchmarks/performance/PERF01_WEATHER_SURFACE_REPAIR_STATUS.json';v=json.loads(status.read_text());v['review_20261022']['rainfall_comparison']={'status':s['status'],'summary':str(p.relative_to(root)),'evidence':idx,'source_commit':s['source_commit'],'scope':s['scope']};status.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps([{k:r[k] for k in ['tolerance_cm','1x_cpu_seconds','4x_cpu_seconds','4x_over_1x_cpu']} for r in cases],indent=2))
