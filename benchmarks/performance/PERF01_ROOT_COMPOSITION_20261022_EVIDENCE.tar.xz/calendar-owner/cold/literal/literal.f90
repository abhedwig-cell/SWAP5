module literal_reproductive
 use iso_fortran_env,only:real64
 use MOD_wofost81_nitrogen,only:WOFOST81_n_param,WOFOST81_n_state
 implicit none
contains
 subroutine literal(p,policy,n,dvs,nmaxlv,m,dead,reltr,supply,after,loss,trans,uptake,requests,unclipped)
 type(WOFOST81_n_param),intent(in)::p
 type(WOFOST81_n_state),intent(in)::n
 real(real64),intent(in)::policy(4),dvs,nmaxlv,m(4),dead(3),reltr,supply
 real(real64),intent(out)::after(8),loss(3),trans(3),uptake(3),requests(6),unclipped(3)
 real(real64)::wlv,wst,wrt,wso,anlv,anst,anrt,anso,rnflv,rnfst,rnfrt,nmaxst,nmaxrt,nmaxso
 real(real64)::drlv,drst,drrt,dvsnlt,dvsnt,nfixf,fntrt,tcnt,delt,nsupplysoil
 real(real64)::ndeml,ndems,ndemr,ndemso,ndemto,nlimit,ndemandsoil,ndemandbiofix,nuptr,nfixtr
 real(real64)::atnst,atnlv,atnrt,atn,nsupso,rnso,rntlv,rntst,rntrt,rnulv,rnust,rnurt
 real(real64)::rnldrt,rnldst,rnldlv,rnlv,rnst,rnrt,nuptt,nfixtt,nlossl,nlossr,nlosss
 wlv=m(1);wst=m(2);wrt=m(3);wso=m(4)
 anlv=n%namountlv;anst=n%namountst;anrt=n%namountrt;anso=n%namountso
 rnflv=p%nresidlv;rnfst=p%nresidst;rnfrt=p%nresidrt
 nmaxst=nmaxlv*p%nmaxst_fr;nmaxrt=nmaxlv*p%nmaxrt_fr;nmaxso=p%nmaxso
 drlv=dead(1);drst=dead(2);drrt=dead(3)
 dvsnlt=policy(1);dvsnt=policy(2);nfixf=policy(3);fntrt=policy(4)
 tcnt=p%tcnt;delt=1d0;nsupplysoil=supply
 nuptt=n%nuptake_total;nfixtt=n%nfix_total;nlossl=n%nlosses_total;nlossr=0d0;nlosss=0d0
      ndeml = max (nmaxlv * wlv - anlv, 0.d0)
      ndems = max (nmaxst * wst - anst, 0.d0)
      ndemr = max (nmaxrt * wrt - anrt, 0.d0)
      ndemso = max (nmaxso * wso - anso, 0.d0) / tcnt
      
      ! total N demand (kg N ha-1)
      ndemto = max (0.d0, (ndemr + ndems + ndeml))

      ! nutrient uptake limiting factor (-) at low moisture conditions in the 
      ! rooted soil layer before anthesis. After anthesis/DVSNLT there is no
      ! nutrient uptake from the soil
      nlimit = 0.d0
      if (dvs - dvsnlt < 0.d0 .AND. reltr - 0.01d0 > 0.d0) then
        nlimit = 1.d0
      end if
      NdemandSoil = (1.d0 - nfixf) * ndemto * nlimit
      NdemandBioFix = nfixf * ndemto * nlimit
      nuptr = max(0.d0, min(NdemandSoil, NsupplySoil)) / delt
      nfixtr = max(0.d0, NdemandBioFix) / delt

      ! estimate the translocatable nutrients in leaves, stem, roots and storage organs (kg N ha-1)
      atnst = max (0.d0, anst - wst * rnfst)
      atnlv = max (0.d0, anlv - wlv * rnflv)
      atnrt = max ((atnlv + atnst) * fntrt, anrt - wrt * rnfrt)
      atn = atnlv +  atnst + atnrt
         
      ! N supply to the storage organs (kg N ha-1 d-1)
      if (dvs - dvsnt < 0.d0) then
         nsupso = 0.d0
      else
         nsupso = atn / tcnt
      end if   

      ! rate of N uptake in grains (kg N ha-1 d-1)
      rnso = min (ndemso, nsupso)

      ! calculate nutrient translocation from leaves, stem, and roots (kg N ha-1 d-1)
      rntlv = 0.d0
      if (atn > 1.0d-5)  rntlv = rnso * atnlv / atn
      rntst = 0.d0
      if (atn > 1.0d-5)  rntst = rnso * atnst / atn
      rntrt = 0.d0
      if (atn > 1.0d-5)  rntrt = rnso * atnrt / atn
      
      ! compute the partitioning of the total nutrient uptake rate (NUPTR) over the leaves, stem and roots (kg N ha-1 d-1)
      rnulv = 0.d0; rnust = 0.d0; rnurt = 0.d0
      if (ndemto > 1.d-5) then
         rnulv = (ndeml / ndemto) * (nuptr + nfixtr)
         rnust = (ndems / ndemto) * (nuptr + nfixtr)
         rnurt = (ndemr / ndemto) * (nuptr + nfixtr)
      end if
      
      ! calculate nutrient losses due to dying leaves, stems and roots (kg N ha-1 d-1)
      rnldrt = rnfrt * drrt
      rnldst = rnfst * drst
      rnldlv = rnflv * drlv
   
      ! rate of change of N in crop organs   
      rnlv = rnulv - rntlv - rnldlv
      rnst = rnust - rntst - rnldst
      rnrt = rnurt - rntrt - rnldrt

      ! total N uptake by crop over time (kg N ha-1) from soil and by biological fixation
      nuptt = nuptt + nuptr * delt
      nfixtt = nfixtt + nfixtr * delt

      ! actual N amount in various living organs and total living N amount(kg N ha-1)
 unclipped=[anlv+rnlv*delt,anst+rnst*delt,anrt+rnrt*delt]
      anlv = max(0.0d0, (anlv + rnlv * delt))
      anst = max(0.0d0, (anst + rnst * delt))
      anrt = max(0.0d0, (anrt + rnrt * delt))
      anso = anso + rnso * delt

      ! N losses from leaves, roots and stems due to senescence and total N loss (kg N ha-1)
      nlossl = nlossl + rnldlv * delt
      nlossr = nlossr + rnldrt * delt
      nlosss = nlosss + rnldst * delt
 after=[anlv,anst,anrt,anso,nuptt,nfixtt,nlossl+nlossr+nlosss,n%initial_total]
 loss=[rnldlv,rnldst,rnldrt];trans=[rntlv,rntst,rntrt];uptake=[rnulv,rnust,rnurt]
 requests=[ndemto,ndemso,ndemandsoil,ndemandbiofix,atn,rnso]
 end subroutine
end module
