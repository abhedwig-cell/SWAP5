#!/bin/sh
exec /workspace/scratch/4112bba79f91/compiler/usr/bin/x86_64-linux-gnu-gfortran-13 -B/workspace/scratch/4112bba79f91/compiler/usr/lib/gcc/x86_64-linux-gnu/13/ -B/usr/lib/gcc/x86_64-linux-gnu/13/ "$@"
