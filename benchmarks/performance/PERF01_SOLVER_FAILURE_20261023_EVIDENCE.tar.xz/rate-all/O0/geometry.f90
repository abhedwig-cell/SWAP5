module research_geometry
 use iso_fortran_env,only:real64
 implicit none
 real(real64),allocatable::dz(:)
 end module
