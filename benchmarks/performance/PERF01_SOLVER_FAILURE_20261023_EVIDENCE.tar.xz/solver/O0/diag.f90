module perf_failure_diag
 use iso_fortran_env,only:int64,real64
 implicit none
 integer::diag_day=1,diag_app_phase=1,detail_unit=0
 integer(int64)::tally(6,97,2,3,2)=0
 real(real64)::seconds(97,2,3,2)=0d0
 contains
 subroutine failure_record(kind,phase,niter,nback,nfail,dt,initial,last,fmax,resid,h,cap,origin,started)
 integer,intent(in)::kind,phase,niter,nback,nfail
 real(real64),intent(in)::dt,initial,last,fmax,resid,h(:),cap(:),origin(:)
 integer(int64),intent(in)::started
 integer(int64)::now,rate
 integer::d,a
 call system_clock(now,count_rate=rate)
 d=diag_day;a=diag_app_phase
 tally(:,d,a,phase,kind)=tally(:,d,a,phase,kind)+int([1,niter,nback,nfail, &
 merge(1,0,all(origin>=0d0)),merge(1,0,nfail>0)],int64)
 seconds(d,a,phase,kind)=seconds(d,a,phase,kind)+real(now-started,real64)/real(rate,real64)
 if(detail_unit==0)then
 open(newunit=detail_unit,file='nonlinear.csv',status='new')
 write(detail_unit,'(A)')'day,app_phase,internal_phase,result,iterations,backtracks,failed_lines,dt,initial_norm,last_norm,max_residual,sum_residual,min_head,max_head,min_capacity,max_capacity,min_origin,max_origin'
 endif
 if(kind==2.or.nfail>0)write(detail_unit,'(I0,6(A,I0),11(A,ES25.17E3))')d,',',a,',',phase,',',kind,',',niter,',',nback,',',nfail, &
 ',',dt,',',initial,',',last,',',fmax,',',resid,',',minval(h),',',maxval(h),',',minval(cap),',',maxval(cap),',',minval(origin),',',maxval(origin)
 end subroutine
 subroutine failure_report()
 integer::u,d,a,p,k
 if(detail_unit/=0)close(detail_unit)
 open(newunit=u,file='nonlinear_summary.csv',status='new')
 write(u,'(A)')'day,app_phase,internal_phase,result,calls,iterations,backtracks,failed_lines,saturated_origins,phases_with_failed_lines,seconds'
 do k=1,2
 do p=1,3
 do a=1,2
 do d=1,97
 if(tally(1,d,a,p,k)>0)write(u,'(I0,9(A,I0),A,ES25.17E3)')d,',',a,',',p,',',k, &
 ',',tally(1,d,a,p,k),',',tally(2,d,a,p,k),',',tally(3,d,a,p,k),',',tally(4,d,a,p,k), &
 ',',tally(5,d,a,p,k),',',tally(6,d,a,p,k),',',seconds(d,a,p,k)
 enddo
 enddo
 enddo
 enddo
 close(u)
 end subroutine
 end module
