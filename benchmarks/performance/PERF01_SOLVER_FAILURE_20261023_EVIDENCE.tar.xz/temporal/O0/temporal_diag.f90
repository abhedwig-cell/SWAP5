module temporal_diag
 use iso_fortran_env,only:int64,real64
 implicit none
 integer::day=1,phase=1
 real(real64)::tol=0d0
 real(real64),allocatable::dz(:)
 integer(int64)::counts(10,97,2)=0
 real(real64)::maxima(4,97,2)=0d0
 contains
 subroutine record_error(hf,hh,wf,wh,pf,ph,gf,gh)
 real(real64),intent(in)::hf(:),hh(:),wf(:),wh(:),pf,ph,gf,gh
 real(real64)::h,p,g,w,v
 h=maxval(abs(hf-hh));p=abs(pf-ph);g=abs(gf-gh)
 w=10d0*(sum(abs(wf-wh)*dz)+p)
 v=max(h,p,g)
 counts(1,day,phase)=counts(1,day,phase)+1
 maxima(:,day,phase)=max(maxima(:,day,phase),[h,p,g,w])
 if(v<=tol)return
 counts(2,day,phase)=counts(2,day,phase)+1
 if(h==v)counts(3,day,phase)=counts(3,day,phase)+1
 if(p==v)counts(4,day,phase)=counts(4,day,phase)+1
 if(g==v)counts(5,day,phase)=counts(5,day,phase)+1
 if(w<1d-4)counts(6,day,phase)=counts(6,day,phase)+1
 if(w<1d-3)counts(7,day,phase)=counts(7,day,phase)+1
 if(w<1d-2)counts(8,day,phase)=counts(8,day,phase)+1
 if(w<1d-1)counts(9,day,phase)=counts(9,day,phase)+1
 if(all(wf==wh).and.pf==ph)counts(10,day,phase)=counts(10,day,phase)+1
 end subroutine
 subroutine report_errors()
 integer::u,d,a
 open(newunit=u,file='temporal_components.csv',status='new')
 write(u,'(A)')'day,phase,assessments,rejects,head_max,pond_max,gwl_max,water_below_0.0001mm,water_below_0.001mm,water_below_0.01mm,water_below_0.1mm,water_identical,max_head_cm,max_pond_cm,max_gwl_cm,max_water_l1_mm'
 do a=1,2
 do d=1,97
 if(counts(1,d,a)>0)write(u,'(I0,11(A,I0),4(A,ES25.17E3))')d,',',a,',',counts(1,d,a),',',counts(2,d,a),',',counts(3,d,a),',',counts(4,d,a),',',counts(5,d,a),',',counts(6,d,a),',',counts(7,d,a),',',counts(8,d,a),',',counts(9,d,a),',',counts(10,d,a),',',maxima(1,d,a),',',maxima(2,d,a),',',maxima(3,d,a),',',maxima(4,d,a)
 enddo
 enddo
 close(u)
 end subroutine
 end module
