module oracle_context
 implicit none
 integer::iun_min2=80,iun_max2=99,unit_err=0
 character(200)::pathatm=''
 real(8)::tstart,tend
end module
module original_meteo
 use oracle_context
 implicit none
 integer::swmetfilall=1,swetr=1,swrain=0,meteo_rec,rain_rec
 logical::fl_loadmeteodata=.false.
 character(200)::metfil
 real(8)::tmnmin=-1d5,tmnmax=1d5,tmxmin=-1d5,tmxmax=1d5
 real(8)::radmin=-1d5,radmax=5d6,hummin=-1d5,hummax=1d5,winmin=-1d5,winmax=1d5
 real(8)::raimin=0d0,raimax=1d3,etrmin=-.00001d0,etrmax=100d0
 real(8),allocatable::atmn(:),atmx(:),arad(:),ahum(:),awin(:),aetr(:),arai(:),wet(:)
 real(8),allocatable::raintim(:),rainflx(:),raintb(:)
contains
   subroutine LoadMeteoData ()
   
      ! ------------------------------------------------------------------
       
      ! global variables
      use oracle_context, only: iun_min2, iun_max2, pathatm, unit_err
      use oracle_context, only: tstart, tend

      implicit none

      ! local variables
      integer, allocatable :: all_dd(:), all_mm(:), all_yyyy(:)
      real(8), allocatable :: all_rad(:), all_tmin(:), all_tmax(:), all_hum(:), all_wind(:), all_rain(:), all_etref(:), all_wet(:)
        
      integer              :: unit, getun2, i1, i2, i
      character(len=3)     :: ext
      character(len=80)    :: metf

      integer              :: datea(6)
      integer              :: yr, s_yr, e_yr
      integer              :: rec, s_rec, e_rec, n_rec
      real(4)              :: fsec
        
      real(8)              :: wstart, wend
      real(8)              :: tmeteo, tmeteo_old
      real(8)              :: rtim, rflx, doy
      logical              :: file_exists
      character(len=11)    :: datedum
      character(len=800)   :: message

      ! local variables (ttutil)
      real(8)              :: afgen
      logical              :: rdinqr
      logical              :: dtleap

      ! local parameters
      integer, parameter   :: firstdayofmonth365(12) = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]
      integer, parameter   :: firstdayofmonth366(12) = [1, 32, 61, 92, 122, 153, 183, 214, 245, 275, 306, 336]
      real(8), parameter   :: vsmall = 1.0d-8
        
      ! ------------------------------------------------------------------
   
      ! determine total number of records to allocate
      if (swmetfilall == 0) then
   
         ! determine start and end of simulation
         call dtdpar (tstart+0.1d0, datea, fsec)
         s_yr = datea(1)
  
         call dtdpar (tend+0.1d0, datea, fsec)
         e_yr = datea(1)
  
         ! determine total number of records to allocate
         n_rec = 0
         do yr = s_yr,e_yr,1
   
            ! open connection
            write (ext,'(i3.3)') mod(yr,1000)
            metf = trim(pathatm)//trim(metfil)//'.'//trim(ext)
            inquire(file = metf, exist = file_exists)
            if (.NOT. file_exists) then
               message ='File '//trim(metf)//' does not exists!'
               call swap_error ('loadmeteodata', message)
            end if
            unit = getun2 (iun_min2, iun_max2, 2)
            call rdinit (unit,unit_err,metf)
   
            ! determine number of records in single file
            if (.NOT. rdinqr('yyyy')) call swap_error ('loadmeteodata', 'Variable YYYY not present in file '//trim(metfil)//'.'//trim(ext))
            call rdinne ('yyyy',rec)
            n_rec = n_rec + rec

            close(unit)
         end do
   
      else
   
         ! open connection
         unit = getun2 (iun_min2, iun_max2, 2)
         metf =  trim(pathatm) // trim(metfil)
         inquire(file = metf, exist = file_exists)
         if (.NOT. file_exists) then
            message ='File '//trim(metf)//' does not exists!'
            call swap_error ('loadmeteodata', message)
         end if
         call rdinit (unit,unit_err,metf)
   
         ! determine number of records
         if (.NOT. rdinqr('yyyy')) call swap_error ('loadmeteodata', 'Variable YYYY not present in file '//trim(metfil))
         call rdinne ('yyyy',n_rec)
   
      end if     
  
      ! allocate variables
      allocate (all_dd(n_rec))
      allocate (all_mm(n_rec))
      allocate (all_yyyy(n_rec))
      allocate (all_tmin(n_rec))
      allocate (all_tmax(n_rec))
      if (fl_loadmeteodata) then
         allocate (all_rad(n_rec))
         allocate (all_hum(n_rec))
         allocate (all_wind(n_rec))
      end if
      if (swetr == 1) then
         allocate (all_etref(n_rec))
      end if
      if (swrain /= 3) allocate (all_rain(n_rec))
      if (swrain == 2) allocate (all_wet(n_rec))
      
      ! load variables
      if (swmetfilall == 0) then
   
         n_rec = 0
         do yr = s_yr,e_yr
   
            ! open connection
            unit = getun2 (iun_min2, iun_max2, 2)
            write (ext,'(i3.3)') mod(yr,1000)
            metf = trim(pathatm)//trim(metfil)//'.'//trim(ext)
            call rdinit (unit,unit_err,metf)
   
            ! determine number of records in single file
            call rdinne ('yyyy',rec)
   
            ! set array to fill
            i1 = n_rec + 1
            i2 = n_rec + rec
   
            ! load variables
            call rdfinr ('dd',1,31,all_dd(i1:i2),rec,rec)
            call rdfinr ('mm',1,12,all_mm(i1:i2),rec,rec)
            call rdfint ('yyyy',all_yyyy(i1:i2),rec,rec)
            call rdfdor ('tmin',tmnmin,tmnmax,all_tmin(i1:i2),rec,rec)
            call rdfdor ('tmax',tmxmin,tmxmax,all_tmax(i1:i2),rec,rec)
            if (fl_loadmeteodata) then
               call rdfdor ('rad',radmin,radmax,all_rad(i1:i2),rec,rec)
               call rdfdor ('hum',hummin,hummax,all_hum(i1:i2),rec,rec)
               call rdfdor ('wind',winmin,winmax,all_wind(i1:i2),rec,rec)
            end if
            if (swetr == 1) then
               call rdfdor ('etref',etrmin,etrmax,all_etref(i1:i2),rec,rec)
            end if   
            if (swrain /= 3) call rdfdor ('rain',raimin,raimax,all_rain(i1:i2),rec,rec)
            if (swrain == 2) call rdfdor ('wet',0.d0,1.d0,all_wet(i1:i2),rec,rec)
   
            n_rec = n_rec + rec

            close(unit)
    
         end do
   
      else
   
         call rdfinr ('dd',1,31,all_dd,n_rec,n_rec)
         call rdfinr ('mm',1,12,all_mm,n_rec,n_rec)
         call rdfint ('yyyy',all_yyyy,n_rec,n_rec)
         call rdfdor ('tmin',tmnmin,tmnmax,all_tmin,n_rec,n_rec)
         call rdfdor ('tmax',tmxmin,tmxmax,all_tmax,n_rec,n_rec)
         if (fl_loadmeteodata) then
            call rdfdor ('rad',radmin,radmax,all_rad,n_rec,n_rec)
            call rdfdor ('hum',hummin,hummax,all_hum,n_rec,n_rec)
            call rdfdor ('wind',winmin,winmax,all_wind,n_rec,n_rec)
         end if
         if (swetr == 1) then
            call rdfdor ('etref',etrmin,etrmax,all_etref,n_rec,n_rec)
         end if   
         if (swrain /= 3) call rdfdor ('rain',raimin,raimax,all_rain,n_rec,n_rec)
         if (swrain == 2) call rdfdor ('wet',0.d0,1.d0,all_wet,n_rec,n_rec)
  
         close (unit)
   
      end if
  
      ! check if start and end time are present in meteofile
      datea = 0
      datea(1) = all_yyyy(1); datea(2) = all_mm(1); datea(3) = all_dd(1)
      call DTARDP (datea, 0.0, wstart)
      datea(1) = all_yyyy(n_rec); datea(2) = all_mm(n_rec); datea(3) = all_dd(n_rec)
      call DTARDP (datea, 0.0, wend)
      if (wstart > tstart .OR. wend < tend) call swap_error ('loadmeteodata', 'incomplete meteofile')
  
      ! check whether dates are in ascending order and if all dates are available
      datea = 0; datea(1) = all_yyyy(1); datea(2) = all_mm(1); datea(3) = all_dd(1)
      call dtardp (datea,0.0,tmeteo)
      do i = 2, n_rec
         tmeteo_old = tmeteo 
         datea(1) = all_yyyy(i); datea(2) = all_mm(i); datea(3) = all_dd(i)
         call dtardp (datea,0.0,tmeteo)
         if (tmeteo - tmeteo_old - 1.d0 > 0.1d0) then
           call dtdpst ('year-month-day',tmeteo_old,datedum)           
           message ='The date after '//datedum//' is not correct! Adapt meteo file!'
           call swap_error ('loadmeteodata', message)
         end if
      end do
       
      ! store records
      n_rec = nint(tend - tstart) + 1
      s_rec = nint(tstart - wstart) + 1
      e_rec = nint(tend - wstart) + 1
   
      ! check if RAIN and WET correspond (SWRAIN = 2)
      if (swrain == 2) then
         do i = s_rec, e_rec
            if ((all_rain(i) > 1.d-10 .AND. all_wet(i) < 1.d-10) .OR. (all_rain(i) < 1.d-10 .AND. all_wet(i) > 1.d-10)) then
               datea = 0; datea(1) = all_yyyy(i); datea(2) = all_mm(i); datea(3) = all_dd(i)
               call dtardp (datea,0.0,tmeteo)
               call dtdpst ('year-month-day',tmeteo,datedum)           
               message = ' In METFIL at '//datedum//' RAIN and WET do not correspond (SWRAIN = 2)! Adapt meteo data!'
               call swap_error ('loadmeteodata', message)
            end if  
         end do
      end if
       
      ! store meteo records within simulation period
   
      if (allocated(atmn)) deallocate(atmn); allocate(atmn(n_rec)); atmn = all_tmin(s_rec:e_rec)
      if (allocated(atmx)) deallocate(atmx);allocate(atmx(n_rec)); atmx = all_tmax(s_rec:e_rec)
      if (fl_loadmeteodata) then
         if (allocated(arad)) deallocate(arad);allocate(arad(n_rec)); arad = all_rad(s_rec:e_rec)
         if (allocated(ahum)) deallocate(ahum);allocate(ahum(n_rec)); ahum = all_hum(s_rec:e_rec)
         if (allocated(awin)) deallocate(awin);allocate(awin(n_rec)); awin = all_wind(s_rec:e_rec)
      end if
      if (swetr == 1) then
         if (allocated(aetr)) deallocate(aetr);allocate(aetr(n_rec)); aetr = all_etref(s_rec:e_rec)
      end if   
      if (swrain /= 3) then 
         if (allocated(arai)) deallocate(arai);allocate(arai(n_rec)); arai = all_rain(s_rec:e_rec)
      end if
      if (swrain == 2) then
         if (allocated(wet)) deallocate(wet);allocate(wet(n_rec)); wet = all_wet(s_rec:e_rec)
      end if   
       
      meteo_rec = 0
  
      ! convert radiation from kJ/m2/d to J/m2/d
      if (fl_loadmeteodata) arad = 1000.d0 * arad

      ! convert precipitation from mm to cm
      if (swrain /= 3) arai = arai * 0.1d0
   
      ! store raintime and rainflux (SWRAIN = 1 or SWRAIN = 2)
      if (swrain == 1 .OR. swrain == 2) then
   
         ! allocate raintime and rainflux
         if (allocated(raintim)) deallocate(raintim);allocate(raintim(n_rec*2 + 1)); raintim = 0.d0
         if (allocated(rainflx)) deallocate(rainflx);allocate(rainflx(n_rec*2 + 1)); rainflx = 0.d0
   
         ! loop over simulation period
         rain_rec = 0
         do i = s_rec, e_rec

            if (all_rain(i) > vsmall) then

               tmeteo = wstart + i - 1.d0
       
               ! closure of previous rain event
               if (rain_rec /= 0) then
                  if (tmeteo - raintim(rain_rec) > vsmall) then
                     rain_rec = rain_rec + 1
                     raintim(rain_rec) = tmeteo
                     rainflx(rain_rec) = 0.d0
                  end if
               else
                  rain_rec = rain_rec + 1
                  raintim(rain_rec) = tmeteo
                  rainflx(rain_rec) = 0.d0
               end if
       
               rain_rec = rain_rec + 1
       
               ! set rainflux at start of day
               if (swrain == 1) then  
          
                  ! mean rainfall intensities
                  if (dtleap(all_yyyy(i))) then 
                     doy = dble(firstdayofmonth366(all_mm(i)) + all_dd(i) - 1)
                  else
                     doy = dble(firstdayofmonth365(all_mm(i)) + all_dd(i) - 1)
                  end if
                  rflx = afgen(raintb, size(raintb), doy)
                  rtim = dmin1(1.d0, all_rain(i) * 0.1d0 / rflx)

               else if (swrain == 2) then

                  ! rainfall durations are specified
                  rtim = all_wet(i)
               end if
       
               ! start of rain event
               raintim(rain_rec) = tmeteo + rtim
               rainflx(rain_rec) = all_rain(i) * 0.1d0 / rtim
       
            end if
         end do
   
         ! closure of previous rain event
         raintim(rain_rec + 1) = tend + 2.d0
         rainflx(rain_rec + 1) = 0.d0
   
         rain_rec = 1
   
      end if      

      ! deallocate temporary data
      deallocate(all_yyyy, all_mm, all_dd, all_tmin, all_tmax)
      if (fl_loadmeteodata) then
          deallocate(all_rad, all_hum, all_wind)
      end if
      if (swetr == 1) then
          deallocate(all_etref)
      end if
      if (swrain /= 3) deallocate(all_rain)
      if (swrain == 2) deallocate(all_wet)
   
      ! data read and stored properly
      write (unit_err,'(A)') ' METFIL: all meteo data read and stored.'

      return

   end subroutine LoadMeteoData
end module
subroutine swap_error(where,message)
 character(*)::where,message
 print *,where,message
 error stop 1
end subroutine
program oracle
 use original_meteo
 implicit none
 integer::i,u
 character(200)::swp
 call get_command_argument(1,swp)
 call get_command_argument(2,metfil)
 call rdinit(74,0,trim(swp))
 call rdstim('tstart',tstart)
 call rdstim('tend',tend)
 close(74)
 call LoadMeteoData()
 open(newunit=u,file='oracle.csv',status='new')
 write(u,'(A)')'end_day,t1900,rain_cm_day,tmin_c,tmax_c,tav_c,etref_cm_day'
 do i=1,size(arai)
 write(u,'(I0,6(A,ES25.16E3))')i,',',tstart+i-1,',',arai(i),',',atmn(i),',',atmx(i), &
   ',',(atmx(i)+atmn(i))*.5d0,',',aetr(i)
 end do
 close(u)
 print '(A)','ORIGINAL_DAILY_MET_COMPLETED'
end program

   real(8) function afgen (table, iltab, x)

      ! ------------------------------------------------------------------
      ! source  : kees rappoldt, 1/86
      ! purpose : linear interpolation in table with length iltab for a 
      !           given value of the independent variable x.
      ! ------------------------------------------------------------------
      
      implicit none
      
      ! global
      integer, intent(in) :: iltab
      real(8), intent(in) :: table(iltab), x
      
      ! local
      integer :: i
      real(8) :: slope
      
      ! ------------------------------------------------------------------
      
      if (table(1) >= x)  goto 40
      do i = 3,iltab-1,2
        if (table(i) >= x) goto 30
        if (table(i) < table(i-2)) goto 20
      end do
      
      ! table fully filled, argument larger then last x in table
      afgen = table(iltab)
      return
      
      ! table partly filled, argument larger then last x in table
 20   afgen = table(i-1)
      return
      ! argument between first and last x in table, interpolation
 30   slope = (table(i+1)-table(i-1))/(table(i)-table(i-2))
      afgen = table(i-1) + (x-table(i-2))*slope
      return
 
      ! argument less or equal to first x in table
 40   afgen = table(2)
      return

   end function afgen
