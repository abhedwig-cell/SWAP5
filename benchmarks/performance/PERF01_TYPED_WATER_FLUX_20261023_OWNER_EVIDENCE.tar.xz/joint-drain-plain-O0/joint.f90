program test_root_substep_transaction
 use iso_fortran_env,only:real64,int64
 use mod_transaction_reference,only:transaction_state_t,TX_TEMPORAL_EXTERNAL_FULL_HALF
 use mod_canonical_contracts,only:canonical_numerical_config_t
 use mod_kernel_transactions,only:kernel_committed_state_t
 use MOD_grid,only:numnod,z,dz,disnod
 use solute_column_context,only:initialize_column_context
 use mod_fmr_runtime_core
 use mod_fmr_serialized_reference_backend
 use mod_fixed_flux_top_boundary_provider
 use mod_b110_default_mvg_provider
 use mod_fmr_root_uptake_process_binding
 use mod_process_hydraulic_view,only:process_hydraulic_view_t
 use mod_root_water_uptake_process
 use mod_b111_reactive_solute_substep
 use mod_fmr_b111_matrix_solute_route
 use mod_fmr_b111_matrix_joint_application
 use mod_fmr_b111_pond_joint_application
 use mod_b111_persistent_pond
 use mod_matrix_joint_restart_file
 use mod_fmr_drainage_response_binding,only:FMR_DRAIN_VARIANT_DRAMET3
 use mod_drainage_dramet3_response
 use mod_drainage_spatial_distribution
 use mod_b111_profile_groundwater_projection
 implicit none
 type(fmr_b110_physical_parameters_t),target::p
 type(fmr_b110_physical_state_t)::initial
 type(fmr_b110_physical_forcing_t)::forcing
 type(b110_default_mvg_parameters_t),target::hp
 type(b110_default_mvg_provider_t)::provider
 type(fmr_logical_column_t)::column
 type(fmr_template_t)::template
 type(canonical_numerical_config_t)::config
 type(fmr_serialized_reference_backend_t)::backend,fresh
 type(fixed_flux_top_boundary_provider_t),target::top
 type(kernel_committed_state_t)::water,base,other
 type(matrix_solute_state_t)::chemical,original,other_chemical
 type(b111_reactive_solute_substep_forcing_t)::chemistry
 type(matrix_joint_result_t)::result
 type(pond_step_t)::supply,invalid
 type(root_water_uptake_parameters_t)::root_parameters
 type(fmr_root_uptake_crop_input_t)::crop
 type(root_water_uptake_flux_result_t)::fluxes,again
 type(root_water_uptake_diagnostics_t)::diagnostics
 type(fmr_root_uptake_binding_diagnostics_t)::binding
 real(real64),allocatable::k(:),c(:),dk(:)
 logical::ok
 integer::s,i
 type(fmr_serialized_physical_observation_t)::observation
 type(process_hydraulic_view_t)::view
 real(real64)::actual,potential,loss,first_sink,variation,dt
 type(fmr_substep_root_forcing_t)::saved_root
 type(b111_profile_groundwater_projection_t)::projection
 type(drainage_node_transfer_t)::partition
 type(drainage_distribution_diagnostics_t)::partition_diagnostic
 type(dramet3_level_result_t)::scalar
 type(fmr_b110_physical_parameters_t)::bad
 real(real64)::drained
 call initialize_column_context([1d0,2d0])
 p%parameter_set_id=670001_int64;p%active_nodes=numnod
 p%z=z;p%dz=dz;p%node_distance=disnod(:numnod)
 allocate(p%cofgen(24,numnod));p%cofgen=0d0
 p%cofgen(1,:)=.032d0;p%cofgen(2,:)=.423d0;p%cofgen(3,:)=.00475d0
 p%cofgen(4,:)=.0135d0;p%cofgen(5,:)=.365d0;p%cofgen(6,:)=1.455d0
 p%cofgen(7,:)=1d0-1d0/1.455d0;p%cofgen(8,:)=.0135d0;p%cofgen(10,:)=.00475d0
 p%cofgen(11,:)=.999d0;p%cofgen(12,:)=.99d0*.00475d0;p%cofgen(22,:)=-1d6;p%cofgen(23,:)=1d-12
 p%bottom_mode=2;p%swkimpl=0;p%swkmean=1;p%max_iterations=8;p%max_backtracking=4;p%root_extraction_active=.true.
 initial%active_nodes=numnod;initial%pressure_head=[-.5d0,1d0]
 allocate(initial%water_content(numnod),k(numnod),c(numnod),dk(numnod))
 call initialize_b110_default_mvg_parameters(hp,p%cofgen)
 hp%continuous_saturation_conductivity=.true.;p%prepared_default_mvg=hp;p%prepared_default_mvg_available=.true.
 p%picard_conductivity_iteration=.true.;p%max_iterations=64
 call bind_b110_default_mvg_provider(provider,hp,.001d0)
 call provider%evaluate(initial%pressure_head,initial%water_content,k,c,dk)
 initial%ponding_depth=0d0;initial%groundwater_level=-1d0
 forcing%top_flux=0d0;forcing%top_head=-75d0;forcing%bottom_flux=0d0
 allocate(forcing%drainage_flux_by_level(1,numnod));forcing%drainage_flux_by_level=0d0
 forcing%root_extraction_sink=[0d0,0d0];forcing%subsurface_irrigation_source=[0d0,0d0]
 allocate(forcing%pond_input);forcing%pond_input%ponding_max_cm=1d6
 chemistry%dz_cm=dz;chemistry%theta=initial%water_content
 chemistry%bulk_density=[1.3d0,1.3d0];chemistry%kf=[.2d0,.2d0];chemistry%frexp=.5d0
 chemistry%temperature_c=[0d0,0d0];chemistry%gampar=[0d0,0d0];chemistry%rtheta=[.3d0,.3d0]
 chemistry%bexp=[1d0,1d0];chemistry%decpot=[0d0,0d0];chemistry%fdepth=[1d0,1d0]
 chemistry%face_distance_cm=disnod(2:numnod)
 chemistry%face_left_weight=.5d0*dz(2:numnod)/chemistry%face_distance_cm
 chemistry%face_right_weight=.5d0*dz(:numnod-1)/chemistry%face_distance_cm
 chemistry%theta_sat_left=[.423d0];chemistry%dispersivity_cm=[.2d0]
 chemistry%molecular_diffusion_cm2_day=.05d0;chemistry%tscf=.5d0
 column%column_id=660101_int64;column%template_id=660201_int64
 column%parameter_ref=1;column%state_handle=1;column%forcing_handle=1;column%backend_id=FMR_BACKEND_SERIALIZED_REFERENCE
 template%template_id=column%template_id;template%physics_topology_id=660210_int64
 template%vertical_layout_id=660220_int64;template%state_layout_id=660230_int64;template%solver_interface_id=660240_int64
 template%compatible_backend_id=FMR_BACKEND_SERIALIZED_REFERENCE
 config%transaction%temporal_mode=TX_TEMPORAL_EXTERNAL_FULL_HALF;config%transaction%temporal_tolerance=1d-4
 config%transaction%mass_tolerance=1d-10;config%transaction%max_retries=30;config%max_committed_substeps=100000
 p%drainage_response_active=.true.;p%drainage_qbot_smooth_freatic_projection=.true.
 allocate(p%drainage_response_levels(1),p%drainage_trial_distribution,forcing%drainage_response_controls(1))
 deallocate(forcing%drainage_flux_by_level)
 p%drainage_response_levels(1)%variant=FMR_DRAIN_VARIANT_DRAMET3
 p%drainage_response_levels(1)%dramet3=dramet3_level_parameters_t(-2d0,500d0,220d0,3,1,.false.)
 call initialize_dramet3_channel_control(p%drainage_response_levels(1)%dramet3_channel,0d0,36000d0, &
  [36000d0,36001d0],[-1.5d0,-1.4d0],s)
 call check(s==0,'channel initialization')
 p%drainage_trial_distribution%active_nodes=numnod
 p%drainage_trial_distribution%dz=dz;p%drainage_trial_distribution%zbotcp=z-.5d0*dz
 p%drainage_trial_distribution%saturated_conductivity=p%cofgen(3,:)
 p%drainage_trial_distribution%horizontal_anisotropy_factor=[1d0,2d0]
 p%drainage_trial_distribution%drain_spacing=1000d0
 call backend%initialize(top);call fresh%initialize(top)
 call fmr_new_b110_committed_state(water,column%column_id,initial,0d0,ok);call check(ok,'initialize water')
 call initialize_matrix_solute(chemistry,9001_int64,0d0,initial%water_content,[.2d0,.4d0],chemical,s)
 call check(s==MATRIX_OK,'initialize solute')
 base=water;original=chemical;other=water;other_chemical=chemical
 allocate(forcing%substep_root)
 forcing%substep_root%parameters=root_water_uptake_parameters_t(numnod,-100d0,-100d0,-120d0,.1d0,.5d0)
 forcing%substep_root%request%potential_transpiration=.0001d0
 forcing%substep_root%request%rooted_nodes=2
 forcing%substep_root%request%cumulative_root_fraction=[0d0,.5d0,1d0]
 supply%t0=0d0;supply%t1=.2d0
 call snapshot('original.bin')
 invalid=supply;invalid%rain_c=-1d0
 call run_pond_joint_interval(backend,column,template,p,water,forcing,config,chemical,invalid,0d0,.2d0,result)
 print *, 'REJECT_DEBUG',result%status,result%water%status,result%diagnostics
 observation=backend%observation()
 print *, 'DRAIN_DEBUG',observation%drainage_response%status,observation%drainage_response_evaluations, &
  observation%drainage_projected_groundwater_level,observation%drainage_response_signed_exchange_native
 print *, 'SOLVE_DEBUG',observation%solver_status,observation%solver_diagnostics
 call check(result%status==JOINT_CHEMICAL_REJECTED.and.result%water%completed,'real chemical rejection')
 call snapshot('rejected.bin')
 call run_pond_joint_interval(backend,column,template,p,water,forcing,config,chemical,supply,0d0,.2d0,result)
 call check(result%status==JOINT_OK,'retry accepts')
 call check(abs(result%water%mass%residual)<1d-10.and.abs(result%chemical%residual)<1d-10,'joint mass')
 observation=backend%observation();drained=0d0
 call check(observation%accepted_water_flux_trace_available,'accepted drainage trace')
 do i=1,size(observation%accepted_water_flux_substeps)
  associate(t=>observation%accepted_water_flux_substeps(i))
   call evaluate_b111_profile_groundwater_projection(z,disnod(:numnod),t%root_pressure_head_start, &
    t%pond_start_cm,projection)
   call check(projection%valid.and.projection%level_present,'actual trial groundwater')
   call evaluate_dramet3_level(p%drainage_response_levels(1)%dramet3,p%drainage_response_levels(1)%dramet3_channel, &
    projection%level_cm,t%t1,scalar)
   call check(scalar%available.and.scalar%signed_exchange_cm_per_day>0d0,'positive actual scalar')
   view%groundwater_level=projection%level_cm
   call distribute_single_level_signed_divdra(p%drainage_trial_distribution,view,scalar%signed_exchange_cm_per_day, &
    partition,partition_diagnostic)
   call check(partition_diagnostic%status==DRAIN_DIST_OK,'existing DIVDRA owner')
   call check(all(t%drainage_sink_by_level(1,:)==partition%soil_to_drain_rate),'exact trial-local partition')
   call check(abs(sum(t%drainage_sink_by_level)-scalar%signed_exchange_cm_per_day)<1d-15,'scalar booked once')
   drained=drained+sum(t%drainage_sink_by_level)*(t%t1-t%t0)
  end associate
 end do
 call check(drained>0d0,'positive accepted drainage');call snapshot('retry.bin')
 water=base;chemical=original
 call run_pond_joint_interval(fresh,column,template,p,water,forcing,config,chemical,supply,0d0,.2d0,result)
 call check(result%status==JOINT_OK,'fresh accepts');call snapshot('fresh.bin')
 water=base;chemical=original;bad=p;bad%drainage_response_levels(1)%dramet3%allocation_mode=1
 call run_pond_joint_interval(backend,column,template,bad,water,forcing,config,chemical,supply,0d0,.2d0,result)
 call check(result%status/=JOINT_OK,'unqualified infiltration rejects');call snapshot('invalid.bin')
 bad=p;bad%drainage_trial_distribution%horizontal_anisotropy_factor(1)=-1d0
 call run_pond_joint_interval(backend,column,template,bad,water,forcing,config,chemical,supply,0d0,.2d0,result)
 call check(result%status/=JOINT_OK,'invalid geometry rejects');call snapshot('geometry.bin')
 bad=p;bad%drainage_response_levels(1)%dramet3%drainage_resistance_day=700d0
 call run_pond_joint_interval(backend,column,template,bad,water,forcing,config,chemical,supply,0d0,.2d0,result)
 call check(result%status==JOINT_OK,'B accepts')
 water=base;chemical=original
 call run_pond_joint_interval(backend,column,template,p,water,forcing,config,chemical,supply,0d0,.2d0,result)
 call check(result%status==JOINT_OK,'A again accepts');call snapshot('again.bin')
 print *, 'DRAINAGE_TRIAL_PARTITION_REJECTION_RETRY_ABA_PASS',drained
contains
 subroutine check(ok,why)
  logical,intent(in)::ok
  character(*),intent(in)::why
  if(.not.ok)then
   print *,why;error stop 1
  end if
 end subroutine
 subroutine snapshot(path)
  character(*),intent(in)::path
  call write_matrix_joint_restart_file(path,column,template,p%parameter_set_id,water,chemical,s,allow_surface_mass=.true.)
  call check(s==JOINT_OK,'snapshot')
 end subroutine
end program
