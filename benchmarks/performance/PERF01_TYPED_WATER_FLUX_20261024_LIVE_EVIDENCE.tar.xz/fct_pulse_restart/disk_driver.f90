program research_joint_test
 use mod_research_joint_reactive_fct
 use mod_kernel_committed_persistence
 use mod_transaction_reference,only:transaction_state_t
 use mod_solute_mobile_salt_state
 use mod_solute_compartment_state
 use mod_b111_reactive_solute_substep
 use mod_research_restart_bridge
 use iso_fortran_env,only:real64,int64
 use mod_fmr_runtime_core
 use mod_fmr_serialized_reference_backend
 use mod_canonical_contracts,only:canonical_numerical_config_t
 use mod_kernel_transactions
 use mod_fixed_flux_top_boundary_provider
 use mod_b110_default_mvg_provider
 use mod_transaction_reference,only:TX_TEMPORAL_MODEL_CERTIFICATE
 use mod_solute_water_face_flux_reconstruction
 use MOD_grid,only:numnod,z,dz,disnod
 use solute_column_context,only:initialize_column_context
 implicit none
 ! Local input holder only. All physical state, forcing, parameters, solver and
 ! transaction types below are the real production interfaces.
 type tile_input_t
  integer(int64)::tile_id,ledger_id
  type(fmr_template_t)::template
  type(fmr_b110_physical_parameters_t)::parameters
  type(fmr_b110_physical_state_t)::initial_state
  type(fmr_b110_physical_forcing_t)::base_forcing
 end type
 type input_t
  real(real64)::initial_time
  type(canonical_numerical_config_t)::numerical
  type(tile_input_t),allocatable::tiles(:)
 end type
 type(input_t)::cfg
 type(fmr_serialized_reference_backend_t)::backend
 type(fixed_flux_top_boundary_provider_t),target::top
 type(fmr_logical_column_t)::column
 type(kernel_committed_state_t)::water
 type(kernel_checkpoint_t)::cp
 type(kernel_candidate_state_t)::candidate
 type(kernel_result_t)::result
 type(kernel_diagnostics_t)::diag
 type(fmr_serialized_physical_observation_t)::obs
 type(b110_default_mvg_parameters_t),target::hp
 type(b110_default_mvg_provider_t)::provider
 real(real64),allocatable::heads(:),theta(:),conduct(:),capacity(:),derivative(:),faces(:)
 real(real64)::factor,k0,closure,maxclosure,maxchange
 integer::i,j,code,u,count,nodes
 logical::ok,committed
 character(512)::arg,path
 ! Declarations injected into the unchanged accepted-water fixture.
 type(research_chemical_t)::chem,initial_chem,saved_chem,reference_chem,restored_chem
 type(kernel_committed_state_t)::initial_water,saved_water,reference_water,restored_water
 type(kernel_persistence_snapshot_t)::persisted
 type(research_joint_result_t)::jr,ref_result
 type(b111_reactive_solute_substep_forcing_t)::model
 type(b111_reactive_solute_substep_forcing_t),allocatable::models(:)
 type(canonical_numerical_config_t)::bad_config
 real(real64),allocatable::concentration(:)
 real(real64)::exponent,h,initial_mass,total_in,total_out,worst
 integer::nt,k,accepted,rejected
 type(kernel_committed_state_t)::loaded_water
 type(research_chemical_t)::loaded_chem
 character(1024)::mode,input_path,output_path
 integer::stop_window
 call get_command_argument(1,arg);read(arg,*)nodes
 call get_command_argument(2,arg);read(arg,*)factor
 call get_command_argument(3,path)
 call initialize_column_context(spread(40d0/nodes,1,nodes))
 allocate(cfg%tiles(1));cfg%initial_time=0d0
 cfg%numerical%transaction%temporal_mode=TX_TEMPORAL_MODEL_CERTIFICATE
 cfg%numerical%model_temporal_indicator_budget_available=.true.
 cfg%numerical%model_temporal_indicator_budget=1d-3
 cfg%numerical%transaction%temporal_tolerance=0d0
 cfg%numerical%transaction%mass_tolerance=1d-10
 cfg%numerical%transaction%retry_scale=.5d0;cfg%numerical%transaction%max_retries=30
 cfg%numerical%max_committed_substeps=100000;cfg%numerical%progress_tolerance=0d0
 associate(tile=>cfg%tiles(1))
  tile%tile_id=660101_int64;tile%ledger_id=760101_int64
  tile%template%template_id=660201_int64;tile%template%physics_topology_id=660210_int64
  tile%template%vertical_layout_id=660220_int64;tile%template%state_layout_id=660230_int64
  tile%template%solver_interface_id=660240_int64;tile%template%optional_state_layout_id=0_int64
  tile%template%numerical_continuation_layout_id=FMR_NUMERICAL_CONTINUATION_RICHARDS_TEMPORAL_HISTORY
  tile%template%compatible_backend_id=FMR_BACKEND_SERIALIZED_REFERENCE
  associate(p=>tile%parameters)
   p%parameter_set_id=670001_int64;p%active_nodes=numnod
   p%z=z;p%dz=dz;p%node_distance=disnod(:numnod)
   allocate(p%cofgen(24,numnod));p%cofgen=0d0
   p%cofgen(1,:)=.032d0;p%cofgen(2,:)=.423d0;p%cofgen(3,:)=4.75d0
   p%cofgen(4,:)=.0135d0;p%cofgen(5,:)=.365d0;p%cofgen(6,:)=1.455d0
   p%cofgen(7,:)=1d0-1d0/1.455d0;p%cofgen(8,:)=.0135d0
   p%cofgen(10,:)=4.75d0;p%cofgen(11,:)=.999d0;p%cofgen(12,:)=.99d0*4.75d0
   p%cofgen(22,:)=-1d6;p%cofgen(23,:)=1d-12
   p%bottom_mode=2;p%swkimpl=0;p%swkmean=1;p%swsophy=0
   p%max_iterations=8;p%max_backtracking=4
   call initialize_b110_default_mvg_parameters(hp,p%cofgen)
  end associate
  call bind_b110_default_mvg_provider(provider,hp,.1d0)
  allocate(heads(numnod),theta(numnod),conduct(numnod),capacity(numnod),derivative(numnod));heads=-75d0
  call provider%evaluate(heads,theta,conduct,capacity,derivative);k0=conduct(1)
  tile%initial_state%active_nodes=numnod
  tile%initial_state%pressure_head=heads;tile%initial_state%water_content=theta
  tile%initial_state%ponding_depth=0d0;tile%initial_state%groundwater_level=-100d0
  tile%base_forcing%top_flux=-factor*k0;tile%base_forcing%top_head=-75d0
  tile%base_forcing%bottom_flux=-k0;tile%base_forcing%bottom_head=-100d0
  allocate(tile%base_forcing%drainage_flux_by_level(1,numnod));tile%base_forcing%drainage_flux_by_level=0d0
  tile%base_forcing%subsurface_irrigation_source=0d0*theta;tile%base_forcing%root_extraction_sink=0d0*theta
 end associate
 column%column_id=cfg%tiles(1)%tile_id;column%template_id=cfg%tiles(1)%template%template_id
 column%state_handle=1;column%parameter_ref=1;column%forcing_handle=1
 column%backend_id=FMR_BACKEND_SERIALIZED_REFERENCE
 call backend%initialize(top)
 call fmr_new_b110_temporal_indicator_committed_state(water,column%column_id,cfg%tiles(1)%initial_state,0d0,ok,0d0*theta)
 if(.not.ok)error stop 'initial water'
 read(path,*)exponent
 h=40d0/nodes
 allocate(concentration(nodes))
 do k=1,nodes
  concentration(k)=.05d0+exp(-.5d0*((k-.5d0)*h-15d0)**2)
 end do
 call initialize_mobile_salt_state(dz,theta,concentration,chem%mobile,code)
 if(code/=SOLUTE_OK)error stop 'mobile init'
 call initialize_solute_compartment_state(.26d0*concentration**exponent*dz,0d0,0d0,0d0*theta,chem%companion,code)
 if(code/=SOLCOMP_OK)error stop 'companion init'
 chem%water=theta;chem%clock=0d0;initial_water=water;initial_chem=chem
 model%transport_scheme=B111_TRANSPORT_IMPLICIT_UPWIND
 model%temperature_active=.true.;model%temperature_c=20d0+0d0*theta;model%gampar=0d0*theta
 model%rtheta=.3d0+0d0*theta;model%bexp=1d0+0d0*theta;model%decpot=0d0*theta;model%fdepth=1d0+0d0*theta
 model%bulk_density=1.3d0+0d0*theta;model%kf=.2d0+0d0*theta;model%frexp=exponent
 model%face_distance_cm=[(h,k=1,nodes-1)];model%face_left_weight=[(.5d0,k=1,nodes-1)]
 model%face_right_weight=model%face_left_weight;model%theta_sat_left=[(.423d0,k=1,nodes-1)]
 model%decpot=.05d0+0d0*theta;model%molecular_diffusion_cm2_day=.02d0;model%dispersivity_cm=.25d0+0d0*model%face_distance_cm;model%rain_c_mg_cm3=.05d0
 initial_mass=sum(chem%mobile%mass_mg_cm2)+chem%companion%solute_total()
 total_in=0d0;total_out=0d0;worst=0d0;accepted=0;rejected=0
 call get_command_argument(4,mode)
 call get_command_argument(5,input_path)
 call get_command_argument(6,output_path)
 call get_command_argument(7,arg);read(arg,*)stop_window
 model%dz_cm=dz
 if(trim(mode)=='wrong_parameters')model%decpot(1)=model%decpot(1)+.01d0
 if(trim(mode)/='full')then
  call read_research_payload(trim(input_path),column,cfg%tiles(1)%template,cfg%tiles(1)%parameters%parameter_set_id, &
   model,loaded_water,loaded_chem,code)
  if(trim(mode)=='reject'.or.trim(mode)=='wrong_parameters')then
   if(code==0.or.loaded_water%ready().or.allocated(loaded_chem%water))error stop 'invalid disk state published'
   print '(A)','RESTORE_REJECTED_BOTH_TARGETS_EMPTY';stop
  end if
  if(code/=0)error stop 'disk restore'
  water=loaded_water;chem=loaded_chem
 end if
 if(stop_window<1.or.stop_window>4.or.chem%clock>stop_window*.1d0)error stop 'disk window'
 do i=nint(chem%clock/.1d0)+1,stop_window
  call run_research_joint_fct(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water, &
   cfg%tiles(1)%base_forcing,cfg%numerical,chem,model,i*.1d0,jr)
  if(jr%status/=RESEARCH_JOINT_OK)error stop 'disk joint'
  print '(A,1X,2(I0,1X),5(ES25.16E3,1X))','WINDOW',i,jr%substeps,jr%ledger
 end do
 call write_research_payload(trim(output_path)//'/payload.bin',column,cfg%tiles(1)%template, &
  cfg%tiles(1)%parameters%parameter_set_id,water,chem,model,code)
 if(code/=0)error stop 'disk export'
 print '(A,1X,I0,1X,ES25.16E3,1X,I0)','DISK_RUN_PASS',nodes,chem%clock,water%current_revision()
end program
