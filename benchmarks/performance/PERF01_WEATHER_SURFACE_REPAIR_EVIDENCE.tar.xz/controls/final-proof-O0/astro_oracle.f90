subroutine b111_astro_oracle(iday,lat,rad,solar)
use iso_fortran_env,only:real64
implicit none
integer,intent(in)::iday
real(real64),intent(in)::lat,rad
real(real64),intent(out)::solar(6)
real(real64),parameter::pi=3.141592653589793238462643383279502884197d0,radial=pi/180.d0,angle=-4.d0
real(real64)::dec,sc,aob,aob_corr,angot,dsinb,frdif
real(real64)::atmtr_,dayl_,daylp_,sinld_,cosld_,difpp_,dsinbe_

      dec = -asin(dsin(23.45d0 * radial) * dcos(2.d0 * pi * dble(iday + 10.d0) / 365.d0))
      sc = 1370.d0*(1.d0 + 0.033d0 * dcos(2.d0 * pi * dble(iday) / 365.d0))

      ! calculation of daylength from intermediate variables (sinld, cosld, aob)
      sinld_ = dsin(radial * lat) * dsin(dec)
      cosld_ = dcos(radial * lat) * dcos(dec)
      aob = sinld_ / cosld_

      ! For very high latitudes and days in summer and winter a limit is
      ! inserted to avoid math errors when daylength reaches 24 hours in
      ! summer or 0 hours in winter.

      ! calculate solution for base=0 degrees
      if (dabs(aob) <= 1.d0) then
        
         dayl_  = 12.d0 * (1.d0 + 2.d0 * asin(aob) / pi)
        
         ! integrals of sine of solar height
         dsinb  = 3600.d0 * (dayl_ * sinld_ + 24.d0 * cosld_ * dsqrt(1.d0 - aob**2) / pi)
         dsinbe_ = 3600.d0 * (dayl_ * (sinld_ + 0.4d0 * (sinld_**2 + cosld_**2 * 0.5d0)) + &
                  12.d0 * cosld_ * (2.d0 + 3.d0 * 0.4d0 * sinld_) * dsqrt(1.d0 - aob**2) / pi)
      else
        
         if (aob > 1.d0)  dayl_ = 24.d0
         if (aob < -1.d0) dayl_ = 0.d0

         ! integrals of sine of solar height      
         dsinb = 3600.d0 * (dayl_ * sinld_)
         dsinbe_ = 3600.d0 * (dayl_ * (sinld_ + 0.4d0 * (sinld_**2 + cosld_**2 * 0.5d0)))
      end if

      ! calculate solution for base=-4 (ANGLE) degrees
      aob_corr = (-dsin(angle * radial) + sinld_) / cosld_
      if (dabs(aob_corr) <= 1.0d0) then 
         daylp_ = 12.d0 * (1.d0 + 2.d0 * asin(aob_corr) / pi)
      else
         if (aob_corr > 1.0d0)  daylp_ = 24.d0
         if (aob_corr < -1.0d0) daylp_ = 0.d0
      end if

      ! extraterrestrial radiation and atmospheric transmission
      angot = sc * dsinb

      ! check for DAYL=0 as in that case the angot radiation is 0 as well
      if (dayl_ > 0.d0) then
         atmtr_ = rad / angot
      else
         atmtr_ = 0.d0
      end if

      ! estimate fraction diffuse irradiation
      if (atmtr_ > 0.75d0) frdif = 0.23d0
      if (atmtr_ <= 0.75d0 .AND. atmtr_ > 0.35d0) frdif = 1.33d0 - 1.46d0 * atmtr_
      if (atmtr_ <= 0.35d0 .AND. atmtr_ > 0.07d0) frdif = 1.d0 - 2.3d0 * (atmtr_ - 0.07d0)**2
      if (atmtr_ <= 0.07d0) frdif = 1.d0

      difpp_ = frdif * atmtr_ * 0.5d0 * sc

solar=[dayl_,daylp_,sinld_,cosld_,difpp_,dsinbe_]
end subroutine
