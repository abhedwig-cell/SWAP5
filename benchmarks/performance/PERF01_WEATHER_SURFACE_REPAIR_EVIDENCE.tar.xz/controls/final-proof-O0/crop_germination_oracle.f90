subroutine b111_germination_oracle(sw_germ,tsumgerm,tsumemeopt,tbasem,teffmx,tav, &
  sampled_head,hdrygerm,hwetgerm,agerm,fl_germ)
use iso_fortran_env, only: real64
implicit none
integer,intent(in)::sw_germ
real(real64),intent(inout)::tsumgerm
real(real64),intent(in)::tsumemeopt,tbasem,teffmx,tav,sampled_head,hdrygerm,hwetgerm,agerm
logical,intent(out)::fl_germ
real(real64)::tsumemesub,h_avg,pF_avg,cgerm,bgerm,dvs,zgerm
zgerm=0.0_real64
            cgerm = - (tsumemeopt - agerm * log10(-1.d0 * hdrygerm))
            bgerm =   (tsumemeopt + agerm * log10(-1.d0 * hwetgerm))


         ! optimal situation in case germination only depends on temperature
         if (sw_germ == 1) then
         
            tsumemesub = tsumemeopt
           
         ! germination depends on temperature and hydrological conditions
         else if (sw_germ == 2) then
         
            ! average pressure head of rootzone (h and pF)
            h_avg = h_average(zgerm)
            pF_avg = dlog10(max(1.d0,-h_avg))
            
            if (h_avg < hdrygerm) then
               ! dry situation
               tsumemesub = agerm * pF_avg - cgerm
            else if (h_avg >= hdrygerm .AND. h_avg <= hwetgerm) then       
               ! optimal situation
               tsumemesub = tsumemeopt
            else
               ! wet situation
               tsumemesub = -1.d0 * agerm * pF_avg + bgerm
            end if

         end if
       
         ! update of tsumgerm, for the time step of 1 day
         if (tav > tbasem) then
            if (tav < teffmx) then
               if (tsumemesub < 0.1d0) then
                  tsumgerm = tsumgerm + (tav - tbasem)
               else
                  tsumgerm = tsumgerm + (tsumemeopt / tsumemesub) * (tav - tbasem)
               end if
            else
               if (tsumemesub < 0.1d0) then
                  tsumgerm = tsumgerm + (teffmx - tbasem)
               else
                  tsumgerm = tsumgerm + (tsumemeopt / tsumemesub) * (teffmx - tbasem)
               end if
            end if
         end if
           
         ! delay growth until tsumgerm is reached
         fl_germ = .TRUE.
         if (tsumgerm < tsumemeopt) then
            dvs = -0.1d0 * max(1.d0 - (tsumgerm / tsumemeopt), 0.d0)
            fl_germ = .FALSE.
         else
            dvs = 0.d0
         end if
       
         return
       
contains
function h_average(depth) result(head)
real(real64),intent(in)::depth
real(real64)::head
head=sampled_head
end function
end subroutine
