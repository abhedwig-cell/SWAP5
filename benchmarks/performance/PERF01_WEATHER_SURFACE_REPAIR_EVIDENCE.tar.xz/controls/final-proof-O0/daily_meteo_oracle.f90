function b111_daily_tav(tmin,tmax) result(tav)
use iso_fortran_env, only: real64
implicit none
real(real64),intent(in)::tmin,tmax
real(real64)::tmn,tmx,tav
tmn=tmin
tmx=tmax
         tav = (tmx+tmn)*0.5d0
end function
