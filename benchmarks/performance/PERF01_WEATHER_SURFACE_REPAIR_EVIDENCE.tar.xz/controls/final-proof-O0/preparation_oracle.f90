subroutine b111_prep3_oracle(sampled_head,h_prep,delay_prep,max_delay_prep,delay_sow,fl_prep)
use iso_fortran_env, only: real64
implicit none
real(real64),intent(in)::sampled_head,h_prep
integer,intent(inout)::delay_prep,delay_sow
integer,intent(in)::max_delay_prep
logical,intent(out)::fl_prep
real(real64)::dh_prep,dvs,z_prep
z_prep=0.0_real64
  
      
         ! threshold pressure head
         dh_prep = h_average(z_prep) - h_prep
       
          fl_prep = .TRUE.
          if (dh_prep > 0.d0) then
             if (delay_prep < max_delay_prep) then
                dvs = -0.3d0
                fl_prep = .FALSE.
                delay_prep = delay_prep + 1
             end if
          end if
       
          delay_sow = delay_prep
       
 contains
function h_average(depth) result(head)
real(real64),intent(in)::depth
real(real64)::head
head=sampled_head
end function
end subroutine
