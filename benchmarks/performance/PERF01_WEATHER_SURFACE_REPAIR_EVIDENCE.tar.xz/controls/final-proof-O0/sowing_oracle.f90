subroutine b111_sow3_oracle(sampled_head,h_sow,soil_temperature,tempsow,delay_sow,max_delay_sow,fl_sow)
use iso_fortran_env, only: real64
implicit none
real(real64),intent(in)::sampled_head,h_sow,soil_temperature,tempsow
integer,intent(inout)::delay_sow
integer,intent(in)::max_delay_sow
logical,intent(out)::fl_sow
real(real64)::dh_sow,dtempsow,dvs,z_sow,tsoil(1)
integer::nodsow
z_sow=0.0_real64;nodsow=1;tsoil(1)=soil_temperature
  
     
         ! sowing before crop growth
         
         ! threshold pressure head
         dh_sow = h_average(z_sow) - h_sow
         
         ! threshold temperature
         dtempsow = tsoil(nodsow) - tempsow
       
         fl_sow = .TRUE.
         if (dtempsow < 0.d0 .OR. dh_sow > 0.d0) then
            if (delay_sow < max_delay_sow) then
               dvs = -0.2d0
               fl_sow = .FALSE.
               delay_sow = delay_sow + 1
            end if
         end if
       
contains
function h_average(depth) result(head)
real(real64),intent(in)::depth
real(real64)::head
head=sampled_head
end function
end subroutine
