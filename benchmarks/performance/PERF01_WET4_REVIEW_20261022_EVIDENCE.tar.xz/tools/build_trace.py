import hashlib,json,shutil,subprocess,time
from pathlib import Path
root=Path.cwd();base=Path('/tmp/perf01-weather-surface-final-v2-O2');out=Path('/tmp/wet4-review-20261022-trace-build');out.mkdir();b=json.loads((base/'BUILD.json').read_text());fc=b['compiler_command'];flags=[x for x in b['flags'] if not x.startswith(('-I','-J'))]+['-I'+str(out),'-J'+str(out)]
for f in base.glob('*.mod'):shutil.copy2(f,out/f.name)
patches={}
p='src/transaction/mod_transaction_reference.f90';s=(root/p).read_text();anchor='      temporal_ok = terr <= policy%temporal_tolerance\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+"      if(t0>=42.28125d0.and.t0<42.296875d0) print *, 'STRICT_TX',t0,attempt_dt,retry_index,terr,full_mass_residual,half_mass_residual,mass_ok\n");patches[p]=s
p='src/runtime/mod_fmr_serialized_reference_backend.f90';s=(root/p).read_text();anchor='    self%last_observation%solver_status = solve_result%status\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+"    if(t0>=42.28125d0.and.t0<42.296875d0)then\n      print *, 'STRICT_SOLVE',t0,t1,solve_result%status,solve_result%native_balance_rate_residual_cm_per_day\n      print *, 'STRICT_BASE',request%base_state%pressure_head,request%base_state%ponding_depth\n      print *, 'STRICT_CAND',solve_result%candidate_state%pressure_head,solve_result%candidate_state%ponding_depth\n    end if\n");patches[p]=s
p='src/runtime/mod_canonical_interval_runtime.f90';s=(root/p).read_text();anchor='      call accumulate_transaction(result, tx)\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+"      if(cursor>=42.28125d0.and.cursor<42.296875d0) print *, 'STRICT_RESULT',cursor,transaction_t1,tx%status,tx%attempts,tx%solver_rejections,tx%mass_rejections,tx%temporal_rejections\n");patches[p]=s
objects=[];events=[]
def run(cmd):
 t=time.monotonic();p=subprocess.run(cmd,capture_output=True);events.append({'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-t});(out/'compile.stderr').write_bytes(p.stderr);p.check_returncode()
for i,p in enumerate(b['sources']):
 if p in patches:
  src=out/Path(p).name;src.write_text(patches[p]);obj=out/f'{i:04d}.o';run(fc+flags+['-c',str(src),'-o',str(obj)])
 else:obj=base/f'{i:04d}.o'
 objects.append(str(obj))
shutil.copy2(base/'driver.f90',out/'driver.f90');run(fc+flags+[str(out/'driver.f90'),str(root/'src/legacy/b1_10_port/headcalc.f90'),*objects,'-o',str(out/'weather')]);shutil.copy2('/tmp/weather-physical-build/weather.999',out/'weather.999');b.update(executable_sha256=hashlib.sha256((out/'weather').read_bytes()).hexdigest(),weather_sha256=hashlib.sha256((out/'weather.999').read_bytes()).hexdigest(),trace_events=events);(out/'BUILD.json').write_text(json.dumps(b,indent=2)+'\n');print('TRACE_BUILT')
