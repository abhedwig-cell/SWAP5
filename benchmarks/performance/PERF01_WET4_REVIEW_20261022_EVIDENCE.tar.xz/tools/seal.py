import csv,hashlib,io,json,subprocess,sys,tarfile
from pathlib import Path
root=Path.cwd();prefix=Path('/tmp');stem='wet4-review-20261022-';out=root/'benchmarks/performance';sha=lambda x:hashlib.sha256(x).hexdigest()
assessment=json.loads((prefix/(stem+'final-assessment.json')).read_text());summary={'status':'BOUNDED_CURRENT_NATIVE_PASS_CANONICAL_ADMISSION_PENDING','tested_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'production_postimages':{'src/legacy/b1_10_port/headcalc.f90':sha((root/'src/legacy/b1_10_port/headcalc.f90').read_bytes())},'strict':assessment,'current_controls':{},'scope':'97days,30cm/4cells,nonirrigated live crop/weather Reference/defaultMvG/mean1/freebottom7/restrictedheat;908mmrain','hosted':'NOT_SELECTED','canonical_admitted':False,'publication':'AUTO_REVIEW_REJECTED_PUSH_EXPLICIT_PUBLISH_AUTHORIZATION_REQUESTED','native_input_hash':'b69d91f8af402b4783a3b5bbd51026492b93b04de6be90717648e9b806db0fb8'}
for opt in ['O0','O2']:
 for kind in ['focused','default']:
  p=prefix/(stem+'fallback-'+kind+'-'+opt);r=json.loads((p/'RESULT.json').read_text());assert 'PASS' in r['status'] or 'BYTE_EXACT' in r['status']
  if kind=='focused':
   assert r['strict_corner_contracts']==1
   for name,h in r['input_sha256'].items():assert sha((root/name).read_bytes())==h,name
  summary['current_controls'][kind+'-'+opt]=r['status']
p=prefix/(stem+'corner-rejection');assert json.loads((p/'RESULT.json').read_text())['status']=='CORNER_FAILURE_NONMUTATION_O0_O2_PASS';summary['current_controls']['bounded_corner_rejection']='O0_O2_STATE_NONMUTATION_AND_STDOUT_EXACT'
base=prefix/(stem+'fallback-1e3');reference=list(csv.DictReader((base/'daily.csv').open()))
for name in ['fallback-O0-1e3','fallback-restart-active']:
 p=prefix/(stem+name);r=json.loads((p/'RESULT.json').read_text());assert r['status']=='COMPLETE_NATIVE_OBSERVATION';rows=list(csv.DictReader((p/'daily.csv').open()));assert len(rows)==97
 assert all({k:v for k,v in x.items() if k!='core_cpu_s'}=={k:v for k,v in y.items() if k!='core_cpu_s'} for x,y in zip(reference,rows));assert (p/'stdout').read_bytes()==(base/'stdout').read_bytes()
 if 'restart' in name:assert r['command'][8]=='restart'
 summary['current_controls'][name]='COMPLETE_97DAY_PHYSICAL_AND_WORK_EXACT'
p=prefix/(stem+'fallback-rollback');r=json.loads((p/'RESULT.json').read_text());assert r['returncode']==0 and not r['timed_out'];assert b'WEATHER_SURFACE_ROLLBACK_PASS           1' in (p/'stdout').read_bytes();summary['current_controls']['rollback']='21_BITS_CROP_REVISION_AND_NO_GROSS_RECEIPTS_AFTER_ONE_PRIVATE_STEP'
for p,expected in [('bound-good','COMPLETE_NATIVE_OBSERVATION'),('bound-bad','FORCING_MISMATCH'),('manifest-mismatch','MUTATED_WEATHER_REJECTED_BEFORE_NATIVE_PASS')]:assert json.loads((prefix/(stem+p)/'RESULT.json').read_text())['status']==expected
summary['current_controls']['forcing_guard']='VALID_FORCING_PASS_WRONG_DECLARED_RAIN_AND_MUTATED_INPUT_REJECT'
summary['budget_cases']={}
for name in ['strict','1e4','1e3','1e2','1e1','1']:
 r=json.loads((prefix/(stem+'fallback-'+name)/'RESULT.json').read_text());assert r['status']=='COMPLETE_NATIVE_OBSERVATION' and r['completed_days']==97 and r['total_rain_mm']==908;summary['budget_cases'][name]={k:r[k] for k in ['head_budget_cm','user_seconds','wall_seconds','executable_sha256','weather_sha256','completed_days']}
summary['limits']=['Finite1e-6temporal refinement is not exact truth or a spatial convergence proof','O0/O2full97day identity is at1e-3; strict97day1e-6 is O2, with O0/O2exact corner drivers','Original frozen headcalc-dependent capsule is historical; affected source/admission owners not reconciled or inherited PASS','Timings are single observations with concurrent checks; no portable speed guarantee','No expanded RossFast/highestlowair/fullFCI scope']
sp=out/'PERF01_WET4_REVIEW_20261022_SUMMARY.json';sp.write_text(json.dumps(summary,indent=2)+'\n')
files={}
def put(name,path):
 if path.is_file() and not path.is_symlink():
  raw=path.read_bytes()
  if raw.startswith(b'\x7fELF') or path.suffix in ['.mod','.o','.pyc']:return
  files[name]=raw
native=['strict','1e4','1e3','1e2','1e1','1','O0-1e3','restart-active','rollback']
for name in native:
 for p in (prefix/(stem+'fallback-'+name)).iterdir():put('native/'+name+'/'+p.name,p)
for name in ['fallback-focused-O0','fallback-focused-O2','fallback-default-O0','fallback-default-O2','corner-rejection','bound-good','bound-bad','manifest-mismatch']:
 for p in (prefix/(stem+name)).rglob('*'):
  if p.is_file():put('controls/'+name+'/'+str(p.relative_to(prefix/(stem+name))),p)
for name in ['strict','strict-correct','trace','fixed-strict','fixed-1e3','fixed-1e4','narrow-strict','narrow-1e4','narrow-1e3']:
 for p in (prefix/(stem+name)).glob('*'):put('retained/'+name+'/'+p.name,p)
for name in ['fallback-O0','fallback-O2','fallback-restart-build','fallback-rollback-build','trace-build','repair-O2','narrow-O2']:
 p=prefix/(stem+name)
 for f in ['BUILD.json','driver.f90','headcalc.f90','mod_fmr_serialized_reference_backend.f90','mod_canonical_interval_runtime.f90','mod_transaction_reference.f90','observed_serial_runtime.f90','observed_bootstrap.f90','grid_stubs.f90','weather.999','link.stdout','link.stderr']:put('build/'+name+'/'+f,p/f)
paths=set(subprocess.check_output(['git','diff','--name-only','bb0d81617','HEAD'],text=True).splitlines())-{'benchmarks/performance/PERF01_WEATHER_SURFACE_REPAIR_STATUS.json'}
paths.update(['benchmarks/performance/PERF01_WET4_REVIEW_20261022_RESULT.md','benchmarks/performance/verify_perf01_wet4_review.py','benchmarks/performance/run_perf01_weather.py','benchmarks/performance/assess_perf01_weather.py','benchmarks/performance/build_perf01_weather_surface.py','tests/fmig431/build_weather_surface_controls.py','tests/fmig431/preserve_weather_surface_default.py'])
for p in sorted(paths):put('source/'+p,root/p)
put('assessment.json',prefix/(stem+'final-assessment.json'));put('summary.json',sp);put('discarded_wrong_forcing_assessment.json',prefix/(stem+'assessment.json'));put('tools/build_trace.py',prefix/'build_wet4_strict_trace.py');put('tools/relink.py',prefix/'relink_wet4_review.py');put('tools/seal.py',Path(__file__));put('docs-build.log',prefix/(stem+'docs.log'))
manifest={p:sha(b) for p,b in files.items()};files['MANIFEST.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();archive=out/'PERF01_WET4_REVIEW_20261022_EVIDENCE.tar.xz'
with tarfile.open(archive,'w:xz') as tar:
 for name,raw in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
index={'path':str(archive.relative_to(root)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(files),'source_postimages':{p:sha((root/p).read_bytes()) for p in paths},'status':'BOUNDED_NATIVE_EVIDENCE_NOT_CANONICAL_ADMISSION'};archive.with_suffix('.index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({k:index[k] for k in ['path','sha256','bytes','members']}))
