program original_duration_oracle
use iso_fortran_env,only:real64
use mod_daily_rain_duration
implicit none
real(real64),allocatable::all_rain(:),all_wet(:)
real(real64)::rtim,rainflx(1),duration,rate
integer::i,n,status,rain_rec,wetdays
call rdinit(74,0,'input.met');call rdinne('rain',n)
allocate(all_rain(n),all_wet(n))
call rdfdor('rain',0d0,1000d0,all_rain,n,n)
call rdfdor('wet',0d0,1d0,all_wet,n,n);close(74)
rain_rec=1;wetdays=0
 do i=1,n
 call resolve_daily_rain_duration(all_rain(i),all_wet(i),duration,rate,status)
 if(status/=0)error stop 'production rejects original forcing'
 if(all_rain(i)>1d-8)then
rtim = all_wet(i)
rainflx(rain_rec) = all_rain(i) * 0.1d0 / rtim
 if(duration/=rtim.or.rate/=rainflx(1))error stop 'B0 duration/rate mismatch'
 wetdays=wetdays+1
 else
 if(duration/=0d0.or.rate/=0d0)error stop 'B0 dry threshold mismatch'
 end if
 end do
print *, 'ORIGINAL_DURATION_ORACLE_PASS',n,wetdays
end program
