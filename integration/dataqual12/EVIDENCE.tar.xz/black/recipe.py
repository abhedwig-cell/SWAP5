import json,subprocess,pathlib,re,sys
root=pathlib.Path.cwd();out=root.parent/'dq12-black-contract2';out.mkdir(exist_ok=True)
shell=(root/'tests/fapp/run_ppa_wu04a_black_evaporation.sh').read_text();sources=re.search(r'MODULE_SRC=\((.*?)\n\)',shell,re.S)[1].split();sources=subprocess.check_output([sys.executable,'tests/support/augment_bartholomeus_backend_sources.py',*sources],text=True).splitlines()
for opt in ['O0','O2']:
 folder=out/opt;folder.mkdir(exist_ok=True);objects={};fc=['/usr/bin/x86_64-linux-gnu-gfortran-13'];flags=['-'+opt,'-fcheck=all','-ffree-line-length-none','-fopenmp','-fbacktrace','-I'+str(folder),'-J'+str(folder)]
 def compile_source(source):
  source=str(source)
  if source in objects:return
  obj=folder/(pathlib.Path(source).stem+'.o')
  for attempt in range(30):
   r=subprocess.run(fc+flags+['-c',source,'-o',str(obj)],capture_output=True);(folder/(obj.stem+'.compile')).write_bytes(r.stdout+r.stderr)
   if not r.returncode:objects[source]=str(obj);return
   missing=re.search(r'Cannot open module file [‘\x27]([^’\x27]+)\.mod',r.stderr.decode())
   if not missing:raise RuntimeError(r.stderr.decode())
   matches=list((root/'src').rglob(missing[1]+'.f90'));assert len(matches)==1,missing[1];compile_source(matches[0])
  raise RuntimeError(source)
 for source in sources:compile_source(root/source)
 for case in ['test_ppa_wu04a_black_process','test_ppa_wu04a_black_runtime','test_ppa_wu01_production_application_bootstrap','test_ppa_wu03_common_forcing_adapter']:
  exe=folder/case;r=subprocess.run(fc+flags+[str(root/'tests/fapp'/(case+'.f90')),*objects.values(),'-o',str(exe)],capture_output=True);(folder/(case+'.compile')).write_bytes(r.stdout+r.stderr)
  if not r.returncode:
   r=subprocess.run([str(exe)],capture_output=True,timeout=30);(folder/(case+'.log')).write_bytes(r.stdout+r.stderr)
  print(opt,case,r.returncode,flush=True)
