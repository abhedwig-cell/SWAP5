* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-29 14:03:31

Period             :  1900-01-01  until  2002-01-30 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.22 cm       0.4800E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            1.04 cm       0.4800E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     4.08    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.27
                             Crack flux        :     0.00
                             Drainage level 1  :     5.18
=========================    ============================
Sum            :     6.48    Sum               :     5.44


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2131E-02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2131E-02

