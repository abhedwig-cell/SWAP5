* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-29 13:49:53

Period             :  1900-01-01  until  2002-01-05 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.01 cm       0.4800E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            1.82 cm       0.4800E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     0.00    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.00
                             Crack flux        :     0.00
                             Drainage level 1  :     0.57
=========================    ============================
Sum            :     2.40    Sum               :     0.58


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.6409E-06
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.6409E-06

