
   subroutine rdadortb (name,xmin,xmax,ymin,ymax,xy,ildec,flip_index)
      
      ! ------------------------------------------------------------------
      ! Reads two arrays, with y = f(x), of double precision values from a
      ! TTUTIL format data file and carries out a range check on the
      ! returned values.
      ! ------------------------------------------------------------------
   
      implicit none

      ! variables
      integer, intent(in)           :: ildec
      real(8), intent(in)           :: xmin,xmax,ymin,ymax
      character(len=*), intent(in)  :: name
      real(8), intent(out)          :: xy(ildec)
      logical, intent(in)           :: flip_index
      
      ! local variables
      integer                       :: i, ifnd
      character(len=200)            :: message
      
      ! local parameters
      character(len=1), parameter :: quote = ''''

      ! ------------------------------------------------------------------
      
      ! check specified range   
      if (xmax < xmin .OR. ymax < ymin) then
         message = 'Range not valid of identifier ' // quote // trim(name) // quote
         call swap_error ('rdadortb', message)
      end if
      
      ! reset array
      xy(:) = 0.d0
      
      ! load array without range check
      call rdadou(trim(name), xy, ildec, ifnd)
      
      ! check range
      do i = 2,ifnd,2
         if (xy(i-1) < xmin .OR. xy(i-1) > xmax) then
             write(message,'(4a,i3,3a,3(g12.5,a))') 'Range error of identifier ', quote, trim(name), '(', i-1, ')', quote, ' value =' , xy(i-1), ', range = [', xmin , ',', xmax ,']'
             call swap_error ('rdadortb', message)
         end if
         if (xy(i) < ymin .OR. xy(i) > ymax) then
             write(message,'(4a,i3,3a,3(g12.5,a))') 'Range error of identifier ', quote, trim(name), '(', i, ')', quote, ' value =' , xy(i), ', range = [', ymin , ',', ymax ,']'
             call swap_error ('rdadortb', message)
         end if
         if (flip_index) xy(i-1) = dabs(xy(i-1))
      end do

      return
   end subroutine rdadortb
   
   subroutine afgen_2(table, iltab, x, y, ipos)
      
      ! ------------------------------------------------------------------
      ! source  : kees rappoldt, 1/86
      !           adapted to become subroutine with extra output of position
      ! purpose : linear interpolation in table with
      !           length iltab for a given value of the independent variable x.
      !           y is result, ipos is the current position in the table.
      ! ------------------------------------------------------------------
      
      implicit none

      real(8), dimension(iltab), intent(in)     :: table(iltab)
      integer,                   intent(in)     :: iltab
      real(8),                   intent(in)     :: x
      real(8),                   intent(out)    :: y
      integer,                   intent(inout)  :: ipos

      integer                                   :: i
      real(8)                                   :: slope
      
      ! ------------------------------------------------------------------
      if (ipos > 0 .AND. mod(ipos,2) == 0) call swap_error ('afgen_2', 'ipos must be zero or odd on entry')
      if (table(1) >= x)  goto 40
      do i = max(3, ipos), iltab-1, 2
        if (table(i) >= x) goto 30
        if (table(i) < table(i-2)) goto 20
      end do

      ! table fully filled, argument larger then last x in table
      y    = table(iltab)
      ipos = iltab - 1
      return

      ! table partly filled, argument larger then last x in table
20    y    = table(i-1)
      ipos = i - 2
      return

      ! argument between first and last x in table, interpolation
 30   slope = (table(i+1)-table(i-1))/(table(i)-table(i-2))
      y     = table(i-1) + (x-table(i-2))*slope
      ipos  = i - 2
      return

      ! argument less or equal to first x in table
40    y     = table(2)
      ipos  = 1
      return

   end subroutine afgen_2

   real(8) function afgen (table, iltab, x)

      ! ------------------------------------------------------------------
      ! source  : kees rappoldt, 1/86
      ! purpose : linear interpolation in table with length iltab for a 
      !           given value of the independent variable x.
      ! ------------------------------------------------------------------
      
      implicit none
      
      ! global
      integer, intent(in) :: iltab
      real(8), intent(in) :: table(iltab), x
      
      ! local
      integer :: i
      real(8) :: slope
      
      ! ------------------------------------------------------------------
      
      if (table(1) >= x)  goto 40
      do i = 3,iltab-1,2
        if (table(i) >= x) goto 30
        if (table(i) < table(i-2)) goto 20
      end do
      
      ! table fully filled, argument larger then last x in table
      afgen = table(iltab)
      return
      
      ! table partly filled, argument larger then last x in table
 20   afgen = table(i-1)
      return
      ! argument between first and last x in table, interpolation
 30   slope = (table(i+1)-table(i-1))/(table(i)-table(i-2))
      afgen = table(i-1) + (x-table(i-2))*slope
      return
 
      ! argument less or equal to first x in table
 40   afgen = table(2)
      return

   end function afgen
subroutine swap_error(caller,message)
character(*)::caller,message
print *,caller,message
error stop 1
end subroutine
