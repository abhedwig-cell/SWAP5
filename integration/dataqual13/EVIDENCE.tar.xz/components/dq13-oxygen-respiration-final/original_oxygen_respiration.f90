subroutine original_oxygen_respiration()
use MOD_wofost,only:p,s_act,r_act,m_act,sw_wofost
use MOD_arrays,only:macroptb
use plant_interface,only:dvs,q10_root,c_mroot,f_senes,max_resp_factor
use atmosphere_interface,only:tav
implicit none
real(8)::rmres,teff,mres,asrc,cvf,help,froots,rg_roots,rm_roots,fr,fs,fl,fo,afgen
         q10_root = p%q10
         c_mroot = p%rmr * 32.d0 / 30.d0
         f_senes = afgen(p%rfsetb, macroptb, dvs)
         
         if (sw_wofost == 3 .AND. m_act%tdelay > 0) then

            ! assume no oxygen stress after mowing
            max_resp_factor = 1.d0

         else   

            ! respiration and partitioning of carbohydrates between growth and maintenance respiration
            rmres = (p%rmr*s_act%wrt + p%rml*s_act%wlv + p%rms*s_act%wst + p%rmo*s_act%wso) * f_senes

            teff = p%q10**((tav - 25.d0) / 10.d0)
            mres = min(r_act%pgass, rmres * teff)
            asrc = r_act%pgass - mres
           
            ! cvf: factor used in wofost to calculate the increase in biomass (dmi) from the
            ! net assimilation of the whole plant (asrc); dmi = cvf*asrc. 
            ! What is left is the growth respiration (i.e. asrc = dmi + growth respiration). 
            ! Therefore, growth respiration of the whole plant = asrc * (1 - cvf)
        
            ! partitioning factors
            fr = afgen (p%frtb, macroptb, dvs)
            fl = afgen (p%fltb, macroptb, dvs)
            fs = afgen (p%fstb, macroptb, dvs)
            fo = afgen (p%fotb, macroptb, dvs)
         
            ! conversion factor
            help = 0.d0; if (p%cvo > 0.d0) help = fo / p%cvo
            cvf = 1.d0 / ((fl / p%cvl + fs / p%cvs + help) * (1.d0 - fr) + fr / p%cvr)

            ! froots: contribution of the roots to cvf
            froots = (fr / p%cvr) * cvf
        
            ! rg_roots: growth respiration roots        
            rg_roots = froots * (1.d0 - cvf) * asrc
        
            ! rm_roots: maintenance respiration roots
            rm_roots = min(froots * (1.d0 - cvf) * r_act%pgass, p%rmr * s_act%wrt * f_senes * teff)
        
            ! max_resp_factor: ratio total respiration / maintenance respiration        
            if (rm_roots > 0.d0) then
                max_resp_factor = (rg_roots + rm_roots) / rm_roots
            else 
                max_resp_factor = 1.d0
            end if
         end if
        

end subroutine
