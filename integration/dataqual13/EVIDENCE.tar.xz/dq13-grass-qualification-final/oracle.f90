program original_grass
use iso_fortran_env,only:real64
use MOD_wofost,only:update_dvs_rate,dtsum,dvr,fl_tsum,sw_wofost,p_grs,t_tsumcum,nodtsum
use atmosphere_interface,only:tav
use plant_interface,only:tsum
use MOD_SoilTemperature,only:tsoil
implicit none
integer::mode,warm,delay,required,ios
real(real64)::soil
nodtsum=1;sw_wofost=3
 do
 read(*,*,iostat=ios)mode,tsum,tav,soil,warm,delay,required
 if(ios/=0)exit
 p_grs%sw_tsum=mode;p_grs%temptsum=5d0;p_grs%t_temptsum=required
 t_tsumcum=warm;tsoil(1)=soil
 call update_dvs_rate()
 write(*,'(2(es25.16e3,1x),l1,1x,i0)')dtsum,dvr,fl_tsum,t_tsumcum
 end do
end program
