* Project:       ruurlo
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-29 19:43:44

Period             :  1980-01-01  until  1980-12-31 
Depth soil profile :  600.00 cm

            Water storage
Final   :       220.24 cm
Initial :       217.02 cm
            =============
Change            3.22 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    86.12    Interception      :     7.90
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    26.69
Bottom flux    :   -35.48    Soil evaporation  :    12.77
                             Crack flux        :     0.00
                             Drainage level 1  :     0.06
=========================    ============================
Sum            :    50.64    Sum               :    47.41

Period             :  1981-01-01  until  1981-12-31 
Depth soil profile :  600.00 cm

            Water storage
Final   :       221.24 cm
Initial :       220.24 cm
            =============
Change            1.00 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    99.21    Interception      :     7.98
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    28.15
Bottom flux    :   -46.97    Soil evaporation  :    13.47
                             Crack flux        :     0.00
                             Drainage level 1  :     1.65
=========================    ============================
Sum            :    52.24    Sum               :    51.24

Period             :  1982-01-01  until  1982-12-31 
Depth soil profile :  600.00 cm

            Water storage
Final   :       218.81 cm
Initial :       221.24 cm
            =============
Change           -2.43 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.06    Interception      :     6.37
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    29.68
Bottom flux    :   -14.81    Soil evaporation  :    10.89
                             Crack flux        :     0.00
                             Drainage level 1  :     0.75
=========================    ============================
Sum            :    45.25    Sum               :    47.68

Period             :  1983-01-01  until  1983-12-31 
Depth soil profile :  600.00 cm

            Water storage
Final   :       214.31 cm
Initial :       218.81 cm
            =============
Change           -4.50 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    82.79    Interception      :     7.10
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    27.69
Bottom flux    :   -40.61    Soil evaporation  :    11.76
                             Crack flux        :     0.00
                             Drainage level 1  :     0.13
=========================    ============================
Sum            :    42.18    Sum               :    46.68

Period             :  1984-01-01  until  1984-12-31 
Depth soil profile :  600.00 cm

            Water storage
Final   :       217.41 cm
Initial :       214.31 cm
            =============
Change            3.10 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    81.93    Interception      :     6.60
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    25.98
Bottom flux    :   -34.34    Soil evaporation  :    11.78
                             Crack flux        :     0.00
                             Drainage level 1  :     0.13
=========================    ============================
Sum            :    47.59    Sum               :    44.49
