from pathlib import Path
import subprocess,json,hashlib,time
out=Path(__file__).parent.resolve();base=out.parent/'andelst-event-edge-O2';r=json.loads((base/'BUILD.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();fc='/workspace/scratch/c3166a264227/toolchain/root/usr/bin/x86_64-linux-gnu-gfortran-13';flags=['-O2','-ffree-line-length-none','-fopenmp','-fcheck=all','-fbacktrace','-ffpe-trap=invalid,zero,overflow','-I'+str(out.parent/'andelst-contact-conservative-O2'),'-J'+str(out)];cmd=[fc,*flags,'-c',str(out/'backend.f90'),'-o',str(out/'backend.o')];p=subprocess.run(cmd,capture_output=True);assert p.returncode==0,p.stderr.decode();objects=[]
for src,obj in zip(r['source_sha256'],r['object_sha256']):
 assert sha(obj)==r['object_sha256'][obj]
 if src.endswith('/mod_fmr_serialized_reference_backend.f90'):obj=str(out/'backend.o')
 objects.append(obj)
cmd=[fc,'-fopenmp',*objects,'/workspace/scratch/f29d9f3066a3/dq13-reference431/providers/ttobj/libttutil.a','-o',str(out/'native')];p=subprocess.run(cmd,capture_output=True);assert p.returncode==0,p.stderr.decode();(out/'BUILD.json').write_text(json.dumps(dict(scope='ACTUAL_DAY129_TEMPORAL_COMPONENT_OBSERVATION_ONLY',base_build=r,source_sha256=sha(out/'backend.f90'),executable_sha256=sha(out/'native'),objects_sha256={o:sha(o)for o in objects}),indent=2))
