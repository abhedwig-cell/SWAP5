from pathlib import Path
import hashlib,json,subprocess,time,shutil
root=Path('/workspace/scratch/c3166a264227/SWAP5-andelst65');out=Path(__file__).parent;base=root.parent/'andelst-contact-conservative-O2';r=json.loads((base/'BUILD.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fc='/workspace/scratch/c3166a264227/toolchain/root/usr/bin/x86_64-linux-gnu-gfortran-13';source=root/'src/legacy/b1_10_port/headcalc.f90';flags=['-O2','-ffree-line-length-none','-fopenmp','-fcheck=all','-fbacktrace','-ffpe-trap=invalid,zero,overflow','-I'+str(base),'-J'+str(out)];events=[]
for obj,h in r['object_sha256'].items():assert sha(Path(obj))==h,obj
for src,h in r['source_sha256'].items():
 p=Path(src).resolve()
 if p.is_relative_to(root.parent/'SWAP5-andelst'):assert sha(p)==h,p
 else:assert sha(p)==h,p
cmd=[fc,*flags,'-c',str(source),'-o',str(out/'headcalc.o')];t=time.monotonic();cp=subprocess.run(cmd,capture_output=True);events.append(dict(command=cmd,seconds=time.monotonic()-t,returncode=cp.returncode));assert cp.returncode==0,cp.stderr.decode()
driver=root/'app/solute_project/main_water.f90'
cmd=[fc,*flags,'-c',str(driver),'-o',str(out/'main.o')];cp=subprocess.run(cmd,capture_output=True);assert cp.returncode==0,cp.stderr.decode()
backend=root/'src/runtime/mod_fmr_serialized_reference_backend.f90'
cmd=[fc,*flags,'-c',str(backend),'-o',str(out/'backend.o')];cp=subprocess.run(cmd,capture_output=True);assert cp.returncode==0,cp.stderr.decode()
objects=[]
for (src,h),obj in zip(r['source_sha256'].items(),r['object_sha256']):objects.append(str(out/'headcalc.o')if src.endswith('/src/legacy/b1_10_port/headcalc.f90')else str(out/'main.o')if src.endswith('/app/solute_project/main_water.f90')else str(out/'backend.o')if src.endswith('/src/runtime/mod_fmr_serialized_reference_backend.f90')else obj)
archive=root.parent.parent/'f29d9f3066a3/dq13-reference431/providers/ttobj/libttutil.a';archive=Path('/workspace/scratch/f29d9f3066a3/dq13-reference431/providers/ttobj/libttutil.a');cmd=[fc,'-fopenmp',*objects,str(archive),'-o',str(out/'native')];t=time.monotonic();cp=subprocess.run(cmd,capture_output=True);events.append(dict(command=cmd,seconds=time.monotonic()-t,returncode=cp.returncode));assert cp.returncode==0,cp.stderr.decode()
report=dict(scope='ACTUAL_RAMPED_DAY65_FAILED_NEWTON_DIAGNOSTIC_ONLY',provider_count=len(objects),freshly_compiled_providers=3,reused_source_build=r,diagnostic_headcalc_sha256=sha(source),events=events,executable_sha256=sha(out/'native'));(out/'BUILD.json').write_text(json.dumps(report,indent=2));print(report['executable_sha256'])
