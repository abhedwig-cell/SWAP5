import sys,json,re,shutil,subprocess,time,hashlib
from pathlib import Path
root=Path('/workspace/scratch/c3166a264227/SWAP5-andelst');out=Path(__file__).parent;prior=Path('/workspace/scratch/c3166a264227/dq15-weighted-O2');sys.path.insert(0,str(root/'tools/solute'))
from legacy_reader_sources import materialize
orig,tt=materialize(root,out)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((prior/'BUILD.json').read_text());fc='/workspace/scratch/c3166a264227/toolchain/root/usr/bin/x86_64-linux-gnu-gfortran-13';flags=['-O2','-ffree-line-length-none','-fopenmp','-fcheck=all','-fbacktrace','-ffpe-trap=invalid,zero,overflow','-I'+str(out),'-J'+str(out)]
for f in prior.glob('*.mod'):shutil.copyfile(f,out/f.name)
old={}
for (src,h),(obj,oh)in zip(b['source_sha256'].items(),b['object_sha256'].items()):
 assert sha(Path(obj))==oh
 if '/SWAP5/'in src:old[src.split('/SWAP5/',1)[1]]=(h,Path(obj))
sources=list((root/'src').rglob('*.f90'))+list((root/'app/solute_column').glob('*.f90'))+[orig]
mp={}
for s in sources:
 for n in re.findall(r'^\s*module\s+(\w+)\s*$',s.read_text(),re.I|re.M):mp[n.lower()]=s
order=[];seen=set();active=set()
def deps(s):return {mp[n.lower()]for n in re.findall(r'^\s*use\s*(?:,\s*(?:non_)?intrinsic\s*::\s*|::\s*)?(\w+)',s.read_text(),re.I|re.M)if n.lower()in mp}
def visit(s):
 if s in seen:return
 assert s not in active,s;active.add(s)
 for q in deps(s):
  if q!=s:visit(q)
 active.remove(s);seen.add(s);order.append(s)
driver=root/'app/solute_project/main_water.f90';visit(driver);order.remove(driver);visit(root/'src/legacy/b1_10_port/headcalc.f90');visit(orig);order.append(driver)
changed=set();objects=[];events=[]
for i,s in enumerate(order):
 key=str(s.relative_to(root))if s.is_relative_to(root)else s.name
 if key in old and old[key][0]==sha(s)and not(deps(s)&changed):o=old[key][1]
 else:
  changed.add(s);o=out/(str(i)+'.o');cmd=[fc,*flags,'-c',str(s),'-o',str(o)];t=time.monotonic();r=subprocess.run(cmd,capture_output=True);events.append(dict(source=str(s),command=cmd,seconds=time.monotonic()-t,returncode=r.returncode));(out/'last.stderr').write_bytes(r.stderr);assert r.returncode==0,(s,r.stderr.decode()[-3000:])
 objects.append(o)
archive=Path('/workspace/scratch/f29d9f3066a3/dq13-reference431/providers/ttobj/libttutil.a');exe=out/'native';cmd=[fc,'-fopenmp',*map(str,objects),str(archive),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True);assert r.returncode==0,r.stderr.decode();(out/'BUILD.json').write_text(json.dumps(dict(status='BUILT_DIAGNOSTIC',compiler=subprocess.check_output([fc,'--version'],text=True).splitlines()[0],source_sha256={str(s):sha(s)for s in order},events=events,executable_sha256=sha(exe),provider_count=len(order),reused_count=len(order)-len(events)),indent=2));print('BUILT',len(order),'compiled',len(events),sha(exe))
