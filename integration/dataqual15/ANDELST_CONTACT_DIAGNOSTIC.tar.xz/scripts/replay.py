from pathlib import Path
import json,subprocess,hashlib,zlib,struct,time,shutil,os
b=Path(__file__).parent;prior=b.parent/'andelst-replay07/run';out=b.parent/'andelst-terminal-replay';out.mkdir();sha=lambda raw:hashlib.sha256(raw).hexdigest();exe=b/'native';exe.chmod(exe.stat().st_mode|0o100)
for n in ['input.nml','input.swp','input.bbc','input.dra','macro.nml']:shutil.copyfile(prior/n,out/n)
raw=(prior/'origin.bin').read_bytes();assert raw[:8]==b'S5WM0001';assert zlib.crc32(raw[:-4])==struct.unpack('=I',raw[-4:])[0]
binding=sha((out/'input.nml').read_bytes()+(out/'input.swp').read_bytes()+(out/'macro.nml').read_bytes()+sha(exe.read_bytes()).encode());new=raw[:8]+binding.encode()+raw[72:-4];new+=struct.pack('=I',zlib.crc32(new));(out/'origin.bin').write_bytes(new)
assert new[72:-4]==raw[72:-4]
cmd=[str(exe),'input.nml','origin.bin','5','input.swp','macro.nml',binding,'5.0','anchored-cauchy','0.0001','experimental','source-surface-demand','perched-jacobian','conservative-macro-storage']
env=dict(os.environ,SWAP5_DIAG_ANDELST_JACOBIAN='1',SWAP5_DIAG_MACRO_TEMPORAL='1');t=time.monotonic();rc=None;censored=False
with(out/'stdout').open('wb')as so,(out/'stderr').open('wb')as se:
 try:r=subprocess.run(cmd,cwd=out,env=env,stdout=so,stderr=se,timeout=60);rc=r.returncode
 except subprocess.TimeoutExpired:censored=True
report=dict(scope='DIAGNOSTIC_ONLY_REBOUND_HISTORICAL_PHYSICAL_STATE_NOT_CURRENT_QUALIFICATION',command=cmd,seconds=time.monotonic()-t,returncode=rc,censored=censored,source_checkpoint_sha256=sha(raw),rebound_checkpoint_sha256=sha(new),physical_payload_unchanged=True,executable_sha256=sha(exe.read_bytes()),files={p.name:sha(p.read_bytes())for p in out.iterdir()if p.is_file()});(out/'RESULT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
