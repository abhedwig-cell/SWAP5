from pathlib import Path
import json,subprocess,hashlib,zlib,struct,time,shutil,os
base=Path('/workspace/scratch/c3166a264227');build=base/'andelst-sharp-diagnostic-O2';prior=base/'andelst-original-entry-O2';out=base/'andelst-sharp-failed-state';out.mkdir();sha=lambda raw:hashlib.sha256(raw).hexdigest();exe=build/'native';exe.chmod(exe.stat().st_mode|0o100)
for n in ['input.nml','input.swp','input.bbc','input.dra','macro.nml']:shutil.copyfile(prior/n,out/n)
raw=(prior/'restart.bin').read_bytes();assert raw[:8]==b'S5WM0001';assert zlib.crc32(raw[:-4])==struct.unpack('=I',raw[-4:])[0];assert struct.unpack_from('=d',raw,204)[0]==1.
binding=sha((out/'input.nml').read_bytes()+(out/'input.swp').read_bytes()+(out/'macro.nml').read_bytes()+sha(exe.read_bytes()).encode());new=raw[:8]+binding.encode()+raw[72:-4];new+=struct.pack('=I',zlib.crc32(new));(out/'origin.bin').write_bytes(new);assert new[72:-4]==raw[72:-4]
cmd=[str(exe),'input.nml','origin.bin','2','input.swp','macro.nml',binding,'2.0','anchored-cauchy','','experimental','source-surface-demand','perched-jacobian','conservative-macro-storage','quiet-macro-stages','corrected-partial-perched-contact'];env=dict(os.environ,SWAP5_DIAG_SHARP_ENTRY='1');t=time.monotonic();rc=None;censored=False
with(out/'stdout').open('wb')as so,(out/'stderr').open('wb')as se:
 try:r=subprocess.run(cmd,cwd=out,env=env,stdout=so,stderr=se,timeout=60);rc=r.returncode
 except subprocess.TimeoutExpired:censored=True
r=dict(scope='ACTUAL_FAILED_NEWTON_DIAGNOSTIC_FROM_AUTHENTIC_SHARP_DAY1_NOT_MODEL_QUALIFICATION',command=cmd,seconds=time.monotonic()-t,returncode=rc,censored=censored,diagnostic_stop_expected=86,source_checkpoint_sha256=sha(raw),rebound_checkpoint_sha256=sha(new),physical_payload_unchanged=True,executable_sha256=sha(exe.read_bytes()),files={p.name:sha(p.read_bytes())for p in out.iterdir()if p.is_file()});(out/'RESULT.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items()if k!='files'},indent=2))
