from pathlib import Path
import json,subprocess,time,hashlib,tarfile,struct,zlib,concurrent.futures
root=Path('/workspace/scratch/5d5d09814239/SWAP5');sha=lambda b:hashlib.sha256(b).hexdigest()
def run(kind,exe):
 out=root.parent/('closure16-contact-'+kind);out.mkdir()
 with tarfile.open(root/'integration/dataqual15/ANDELST_CONTACT_DIAGNOSTIC.tar.xz')as t:
  for n in ['input.nml','input.swp','input.bbc','input.dra','macro.nml']:(out/n).write_bytes(t.extractfile('run/'+n).read())
  raw=t.extractfile('run/origin.bin').read()
 assert zlib.crc32(raw[:-4])==struct.unpack('=I',raw[-4:])[0]
 binding=sha(b''.join((out/n).read_bytes()for n in ['input.nml','input.swp','macro.nml'])+sha(exe.read_bytes()).encode())
 new=raw[:8]+binding.encode()+raw[72:-4];new+=struct.pack('=I',zlib.crc32(new));(out/'origin.bin').write_bytes(new)
 cmd=[str(exe),'input.nml','origin.bin','3','input.swp','macro.nml',binding,'3','anchored-cauchy','0.0001','experimental','source-surface-demand','perched-jacobian','conservative-macro-storage']
 (out/'LAUNCH.json').write_text(json.dumps({'command':cmd,'historical_payload_rebound':True,'payload_unchanged':raw[72:-4]==new[72:-4],'checkpoint_from_ramped_route':True,'qualified_restart':False},indent=2))
 start=time.monotonic()
 with(out/'stdout').open('wb')as so,(out/'stderr').open('wb')as se:
  try:r=subprocess.run(cmd,cwd=out,stdout=so,stderr=se,timeout=60);rc=r.returncode;c=False
  except subprocess.TimeoutExpired:rc=None;c=True
 d={'kind':kind,'returncode':rc,'censored':c,'seconds':time.monotonic()-start,'skipped_refresh_seen':b'REFRESH_WITH_SKIPPED_JACOBIAN'in(out/'stdout').read_bytes(),'qualified':False};(out/'RESULT.json').write_text(json.dumps(d,indent=2));return d
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 futures=[pool.submit(run,'baseline',root.parent/'closure16-build-O2/column/swap5_solute_project'),pool.submit(run,'refresh-observer',root.parent/'closure16-refresh-probe/native')]
 for f in futures:print(json.dumps(f.result()),flush=True)
