module mod_entry_observation_clock
end module
