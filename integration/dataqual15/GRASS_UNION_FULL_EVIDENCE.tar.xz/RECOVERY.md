# Exact native recovery

Verify every archive digest with verify_grass_full_evidence.py first. Retain the
original application.binding bytes. For O2, copy build/O2/swap5_grass_startup and
the five literal input files plus application.binding from the full native case
to a new working directory. Verify the executable SHA256 against the manifest,
then restore owner execute permission. Run that exact executable from the new
case directory with arguments: 1827 retain-step 100000 /absolute/captured/checkpoint-1800.bin
(the captured checkpoint is from the archived full O2 case). Compare the terminal
checkpoint and daily suffix with the archived full case. No source rebinding is
permitted. Original absolute build paths in application.binding are opaque
provenance; retain them byte for byte. The TTUTIL archive and complete source
identity are included for rebuild audit; exact recovery uses the retained binary.
