module MOD_arrays
! File VersionID:
!   $Id: arrays.fi 362 2018-01-08 13:08:33Z kroes006 $
! ----------------------------------------------------------------------

   integer, parameter :: mayrs        = 100           ! maximum number of years in the simulation period
   integer, parameter :: fillen       = 100
   integer, parameter :: listlen      = 2048
   integer, parameter :: macp         = 5000          ! maximum number of compartments
   integer, parameter :: maday        = mayrs*366     ! maximum number of days in the simulation period
   integer, parameter :: madr         = 25            ! maximum number of drainage systems
   integer, parameter :: magrs        = 366           ! maximum number of growth stages
   integer, parameter :: maho         = 25            ! maximum number of horizons
   integer, parameter :: mabbc        = maday         ! maximum number of time-dependent values for bottom boundary conditions
   integer, parameter :: mascale      = 100           ! maximum number of scaling factors
   integer, parameter :: mrain        = 40000         ! maximum number of rainfall records in case of detailed rainfall
   integer, parameter :: mairg        = mayrs*366     ! maximum number of applied irrigations
   integer, parameter :: maout        = 3000          ! maximum number of specified output dates
   integer, parameter :: maowl        = 10*366        ! maximum number of open water levels (basic drainage routine
   integer, parameter :: masme        = 1000          ! maximum number of soil management events
   integer, parameter :: matab        = 1000          ! maximum number of data pairs in input tables for soil hydraulica relations
   integer, parameter :: matabentries = 50005         ! maximum number of data pairs in input tables for soil hydraulica relations
   integer, parameter :: mawlp        = 10*366        ! maximum number of water levels prim. system (ext. dr.
   integer, parameter :: mawls        = 10*366        ! maximum number of water levels sec. system (ext. dr.
   integer, parameter :: mamp         = 10*366        ! maximum number of surfacewater management periods (ext. dr.
   integer, parameter :: mamte        = 25            ! maximum number of surfacewater management table entries (ext. dr.
   integer, parameter :: madm         = 20            ! maximum number of macropore domains
   integer, parameter :: masteq       = 10000         ! maximum number of static equilibrium relations
   integer, parameter :: nmetfile     = 17568         ! maximum number of weather records in one year (48 per day
   integer, parameter :: mcof         = 42            ! first dimension of matrix cofgen

   integer, parameter :: macrop       = 200           ! maximum number of crops
   integer, parameter :: macroptb     = 40            ! maximum records crop development
   integer, parameter :: mahrv        = 100           ! maximum harvest events

end module MOD_arrays
