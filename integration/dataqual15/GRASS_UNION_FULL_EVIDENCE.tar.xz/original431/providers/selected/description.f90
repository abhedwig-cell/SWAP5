module MOD_description

   character(len=*), parameter :: Name        = 'SWAP'
   character(len=*), parameter :: Version     = '4.3.1'
   character(len=*), parameter :: VersionDate = '2026-06-30'

end module MOD_description

! File VersionID:
!   resource file with a description of the model
!   Semantic Versioning, according to semver.org:
!      Given a version number MAJOR.MINOR.PATCH, increment the:
!         MAJOR version when you make incompatible API changes,
!         MINOR version when you add functionality in a backwards-compatible manner, and
!         PATCH version when you make backwards-compatible bug fixes.
!   Version number assigned by the maintainers: (Marius Heinen, Martin Mulder)
! -----------------------------------------------------------------------------
! NameShort = 'SWAP'
! NameLong = 'Soil-Water-Atmosphere-Plant'
! Author = 'Wageningen Environmental Research (WENR) & Wageningen University (WU)'
! DescriptionShort = 'Dynamic simulation of the hydrological cycle in the upper part of the soil system'
! Maintainer = 'Workgroup SWAP <swap.wenr@wur.nl>'
! License = 'GPL Version 2 or later'
! Built = 'Intel(R) Fortran Compiler 2023.1, Copyright (C) 2002-2023 Intel Corporation. All rights reserved.'
