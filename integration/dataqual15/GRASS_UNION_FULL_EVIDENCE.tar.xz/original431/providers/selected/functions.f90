! File VersionID:
!   $Id: functions.f90 373 2018-03-19 15:19:33Z heine003 $
! ------------------------------------------------------------------------
   function hcomean(swkmean, kup, klow, dzup, dzlow, iboundary, htop, hbot)
      ! ------------------------------------------------------------------
      !     UpDate             : 20090630
      !     Purpose            : calc. mean hydraulic conductivity
      !     Subroutines called : -
      !     Functions called   : -                                           
      !     File usage         : -
      ! ------------------------------------------------------------------
      
      use MOD_Kavg_Szym
   
      implicit none
      
      ! global
      integer, intent(in)  :: swkmean, iboundary
      real(8), intent(in)  :: kup,klow,dzup,dzlow, htop, hbot
      real(8)              :: hcomean

      ! local
      real(8)              :: a1, a2

      ! ------------------------------------------------------------------
      
      ! unweighted arithmic mean
      if (swkmean == 1) then
         hcomean = 0.5d0 * (kup + klow)
      
      ! weighted arithmic mean
      else if (swkmean == 2) then
         hcomean = (dzup * kup + dzlow * klow) / (dzup + dzlow)

      ! unweighted geometric mean
      else if (swkmean == 3) then
         hcomean = dsqrt( kup * klow)

      ! weighted geometric mean
      else if (swkmean == 4) then
         a1 = dzup / (dzup + dzlow)
         a2 = 1.0d0 - a1
         hcomean =  (kup ** a1) * (klow ** a2)

      ! unweighted harmonic mean
      else if (swkmean == 5) then
         hcomean =  1.0d0/(0.5d0/kup + 0.5d0/klow)

      ! weighted harmonic mean
      else if (swkmean == 6) then
         a1 = dzup / (dzup + dzlow)
         a2 = 1.0d0 - a1
         hcomean =  1.0d0/(a1/kup + a2/klow)

      ! Darcian means according to Szymkiewicz (2009) and Szymkiewicz & Helmig (2011) (based on suggestion by Warrick, 1991)
      else if (swkmean == 7) then
         call sub_Kavg_Szym(2, iboundary, htop, hbot, hcomean)
      end if
      
      return
      
   end function hcomean
   
   !----------------------------------------------------------------------

   real(8) function afgen (table, iltab, x)

      ! ------------------------------------------------------------------
      ! source  : kees rappoldt, 1/86
      ! purpose : linear interpolation in table with length iltab for a 
      !           given value of the independent variable x.
      ! ------------------------------------------------------------------
      
      implicit none
      
      ! global
      integer, intent(in) :: iltab
      real(8), intent(in) :: table(iltab), x
      
      ! local
      integer :: i
      real(8) :: slope
      
      ! ------------------------------------------------------------------
      
      if (table(1) >= x)  goto 40
      do i = 3,iltab-1,2
        if (table(i) >= x) goto 30
        if (table(i) < table(i-2)) goto 20
      end do
      
      ! table fully filled, argument larger then last x in table
      afgen = table(iltab)
      return
      
      ! table partly filled, argument larger then last x in table
 20   afgen = table(i-1)
      return
      ! argument between first and last x in table, interpolation
 30   slope = (table(i+1)-table(i-1))/(table(i)-table(i-2))
      afgen = table(i-1) + (x-table(i-2))*slope
      return
 
      ! argument less or equal to first x in table
 40   afgen = table(2)
      return

   end function afgen

   !----------------------------------------------------------------------   
   
   subroutine afgen_2(table, iltab, x, y, ipos)
      
      ! ------------------------------------------------------------------
      ! source  : kees rappoldt, 1/86
      !           adapted to become subroutine with extra output of position
      ! purpose : linear interpolation in table with
      !           length iltab for a given value of the independent variable x.
      !           y is result, ipos is the current position in the table.
      ! ------------------------------------------------------------------
      
      implicit none

      real(8), dimension(iltab), intent(in)     :: table(iltab)
      integer,                   intent(in)     :: iltab
      real(8),                   intent(in)     :: x
      real(8),                   intent(out)    :: y
      integer,                   intent(inout)  :: ipos

      integer                                   :: i
      real(8)                                   :: slope
      
      ! ------------------------------------------------------------------
      if (ipos > 0 .AND. mod(ipos,2) == 0) call swap_error ('afgen_2', 'ipos must be zero or odd on entry')
      if (table(1) >= x)  goto 40
      do i = max(3, ipos), iltab-1, 2
        if (table(i) >= x) goto 30
        if (table(i) < table(i-2)) goto 20
      end do

      ! table fully filled, argument larger then last x in table
      y    = table(iltab)
      ipos = iltab - 1
      return

      ! table partly filled, argument larger then last x in table
20    y    = table(i-1)
      ipos = i - 2
      return

      ! argument between first and last x in table, interpolation
 30   slope = (table(i+1)-table(i-1))/(table(i)-table(i-2))
      y     = table(i-1) + (x-table(i-2))*slope
      ipos  = i - 2
      return

      ! argument less or equal to first x in table
40    y     = table(2)
      ipos  = 1
      return

   end subroutine afgen_2   
   
   !----------------------------------------------------------------------

   subroutine rdadortb (name,xmin,xmax,ymin,ymax,xy,ildec,flip_index)
      
      ! ------------------------------------------------------------------
      ! Reads two arrays, with y = f(x), of double precision values from a
      ! TTUTIL format data file and carries out a range check on the
      ! returned values.
      ! ------------------------------------------------------------------
   
      implicit none

      ! variables
      integer, intent(in)           :: ildec
      real(8), intent(in)           :: xmin,xmax,ymin,ymax
      character(len=*), intent(in)  :: name
      real(8), intent(out)          :: xy(ildec)
      logical, intent(in)           :: flip_index
      
      ! local variables
      integer                       :: i, ifnd
      character(len=200)            :: message
      
      ! local parameters
      character(len=1), parameter :: quote = ''''

      ! ------------------------------------------------------------------
      
      ! check specified range   
      if (xmax < xmin .OR. ymax < ymin) then
         message = 'Range not valid of identifier ' // quote // trim(name) // quote
         call swap_error ('rdadortb', message)
      end if
      
      ! reset array
      xy(:) = 0.d0
      
      ! load array without range check
      call rdadou(trim(name), xy, ildec, ifnd)
      
      ! check range
      do i = 2,ifnd,2
         if (xy(i-1) < xmin .OR. xy(i-1) > xmax) then
             write(message,'(4a,i3,3a,3(g12.5,a))') 'Range error of identifier ', quote, trim(name), '(', i-1, ')', quote, ' value =' , xy(i-1), ', range = [', xmin , ',', xmax ,']'
             call swap_error ('rdadortb', message)
         end if
         if (xy(i) < ymin .OR. xy(i) > ymax) then
             write(message,'(4a,i3,3a,3(g12.5,a))') 'Range error of identifier ', quote, trim(name), '(', i, ')', quote, ' value =' , xy(i), ', range = [', ymin , ',', ymax ,']'
             call swap_error ('rdadortb', message)
         end if
         if (flip_index) xy(i-1) = dabs(xy(i-1))
      end do

      return
   end subroutine rdadortb
   
   subroutine remove_spaces(string)

      ! ------------------------------------------------------------------
      ! Reads two arrays, with y = f(x), of double precision values from a
      ! TTUTIL format data file and carries out a range check on the
      ! returned values.
      ! ------------------------------------------------------------------
   
      implicit none
      ! global
      character(len=*), intent(inout) :: string
      ! local
      integer :: ipos1
      logical :: done

      ! ------------------------------------------------------------------
   
      ! remove spaces from string
      done = .FALSE.
      do while (.NOT. done)
         ipos1 = index(string, " ")
         if (ipos1 > 0 .AND. ipos1 < len_trim(string)) then
            string = string(1:(ipos1-1))//string((ipos1+1):len_trim(string))
         else
            done = .TRUE.
         end if
      end do
      return
   end subroutine remove_spaces
   

      SUBROUTINE ilocate(xx,n,x,j)
      INTEGER     :: j,n
      integer     :: x,xx(n)
      INTEGER     :: jl,jm,ju
      jl=0
      ju=n+1
10    if(ju-jl.gt.1)then
        jm=(ju+jl)/2
        if((xx(n).ge.xx(1)).eqv.(x.ge.xx(jm)))then
          jl=jm
        else
          ju=jm
        endif
      goto 10
      endif
      if(x.eq.xx(1))then
        j=1
      else if(x.eq.xx(n))then
        j=n-1
      else
        j=jl
      endif
      return
   END

   
   ! ---------------------------------------------------------------------
    
   real(8) function h_average (z_monitor)
    
      ! ------------------------------------------------------------------

      use MOD_params, only: small   
      use MOD_grid, only: dz
      use variables, only: h

      implicit none
 
      integer :: node
      real(8), intent(in) :: z_monitor
      real(8) :: drz1, pFz1

      ! ------------------------------------------------------------------
   
      ! calculate average pressure head of rootzone
      if (dabs(z_monitor - 0.d0) < small) then
         pFz1 = dlog10(max(1.d0,-h(1)))
      else
         node = 0
         pFz1 = 0.0d0
         drz1 = -z_monitor
         do while (drz1 > 0.d0)
            node = node + 1
            if (drz1 - dz(node) >= 0.d0) then
               pFz1 = pFz1 + dlog10(max(1.d0,-h(node))) * dz(node) / (-z_monitor)
            else
               pFz1 = pFz1 + dlog10(max(1.d0,-h(node))) * drz1 / (-z_monitor)
            end if
            drz1 = drz1 - dz(node)
         end do
      end if
 
      ! simulate germination time
      h_average = -1.d0 * 10.d0**pFz1

   end function h_average
