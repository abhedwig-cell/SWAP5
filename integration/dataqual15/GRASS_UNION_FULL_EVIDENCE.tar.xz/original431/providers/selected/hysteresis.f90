 ! File VersionID:
 !   $Id: hysteresis.f90 362 2018-01-08 13:08:33Z kroes006 $
 ! ----------------------------------------------------------------------
subroutine hysteresis ()
! ----------------------------------------------------------------------
!     date               : 23/10/2022
!     purpose            : check for hysteretic reversal and update      
!                          model parameters            
! ----------------------------------------------------------------------
use MOD_grid,  only: numnod,layer,disnod 
use MOD_MvG,   only: moiscap, prhead, watcon, cofgen, calc_cofgen_extra, paramvg
use variables, only: h,hm1,delp,indeks,tau,dimoca,theta,fhyst ! date, tcum
implicit none

! global

! local
integer              :: node,lay
real(8)              :: theta_tmp, theta_wet, theta_dry, theta_scan
real(8), parameter   :: fadapt = 1.0d-1

! ----------------------------------------------------------------------
! dynamic check for reversal
do node = 1,numnod
  lay = layer(node)
  if (abs(paramvg(4,lay)-paramvg(8,lay)) > 1.d-6) then
    delp(node) = delp(node) + hm1(node) - h(node)
    if (abs(delp(node)/min(h(node),-1.0d0)) > tau) then
      if (h(node) > -1.0d0) then
        ! Set the scanning curve on the unadjusted drying curve when the layer is almost saturated
        indeks(node) = -1
        fhyst(node) = 1.0d0
        h(node) = prhead(node,disnod(node),theta(node),cofgen,h)
      else
        ! if delp > 0 so  drying and if indeks =  1 (wetting curve) then change to indeks = -1 (drying)
        ! if delp < 0 so wetting and if indeks = -1 (drying curve)  then change to indeks =  1 (wetting)
        if (delp(node)/dble(indeks(node)) > 0.d0) then
          indeks(node) = -1 * indeks(node)
          ! ---  calculate theta for h on the wetting or drying curve, theta_tmp is theta on scanning curve.
          theta_scan = watcon(node, h(node))
          if (indeks(node) == 1) then
            ! ---  wetting curve
            theta_wet = paramvg(2,lay) - (paramvg(2,lay) - theta_scan) / fhyst(node)
            fhyst(node) = (theta(node) - paramvg(2,lay))/(theta_wet - paramvg(2,lay))
            if (fhyst(node) < fadapt) then
              fhyst(node) = fadapt 
              ! Get the pressure head for theta on this scanning curve
              ! Firstly, convert theta to theta for the basic wetting curve
              theta_tmp = (theta(node) - paramvg(2,lay)) / fhyst(node) + paramvg(2,lay)
              h(node) = prhead(node,disnod(node),theta_tmp,cofgen,h)
            end if        
          else
            ! ---  drying curve
            theta_dry = paramvg(1,lay) +  (theta_scan - paramvg(1,lay)) / fhyst(node)
            fhyst(node) = (theta(node) - paramvg(1,lay))/(theta_dry - paramvg(1,lay))
            if (fhyst(node) < fadapt) then
              fhyst(node) = fadapt 
              ! Get the pressure head for theta on this scanning curve
              ! Firstly, convert theta to theta for the basic drying curve
              theta_tmp = (theta(node) - paramvg(1,lay)) / fhyst(node) + paramvg(1,lay)
              h(node) = prhead(node,disnod(node),theta_tmp,cofgen,h)
            end if
          end if    
        end if
      end if
      ! ---   update capacity 
      call calc_cofgen_extra(-node) 
      dimoca(node) = moiscap(node,h(node))
      delp(node) = 0.d0
    end if
  end if
end do
end subroutine hysteresis

