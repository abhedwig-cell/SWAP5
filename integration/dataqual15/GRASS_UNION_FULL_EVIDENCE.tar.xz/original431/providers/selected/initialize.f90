! File VersionID:
!   $Id: initialize.f90 374 2018-03-21 13:12:23Z heine003 $
! ----------------------------------------------------------------------
      Subroutine Initialize
! --- Initialize all variables (except crop) in subroutine Variables
      use MOD_swap_base,      only: swirfix, swpondmx, swhyst
      use MOD_grid,           only: numnod, layer, botcom, disnod, dz, hcomp, hsublay, inpola, inpolb, isoillay, ncomp, nod1lay, nsublay, numlay, z, zbotcp, ztopcp
      use MOD_integral,       only: integral
      use MOD_MvG,            only: cofgen, paramvg, swsophy, h_enpr_global
      use MOD_meteo,          only: cfevappond, fprecnosnow, empreva
      use MOD_irrigation,     only: cirr, cirrs, dcrit, ditab, dt_irr_event, dwatab, fidtab, flheadirg, flirrigate, gird, hcritab, irconc, irdate,         &
                                    irdepth, irrate, ir_z, irrigevent, irtype, isua, isuas, nird, nirri, qssdi, raithreshold, rawtab, schedule, tawtab,    &
                                    tcritab, tendirrig, treltab, tstairrig
      use variables,          only: aqamp, aqave, aqper, aqtmax, bal, blc, bpegwl, cfbs, cntper, cofqha, cofqhb, cofred, CritDevh1Cp, CritDevh2Cp,         &
                                    CritDevMasBal, CritDevPondDt, daycum, daynr, deepgw, delp, dimoca, dt, dtmax, dtmin, flbaloutput,                      &
                                    fldayend, fldaystart, fldecdt, fldtmin, fldtreduce, flheader, flksatexm, fllowgwl, floutput, floutputshort, flprintdt, &
                                    flprintshort, flrunend, fluseksatexm, flzerocumu, flzerointr, gwl, gwlconv, gwli, gwlinp, gwlm1, gwltab, h,            &
                                    haqtab, hbot, hbotab, hdrain, hm1, imonth, indeks, ioutdat, ioutdatint, isteps, Itnumb, iyear,                         &
                                    k, kmean, ksatexm, ksatfit, ldwet, MaxBackTr, MaxIt, msteps, nhead, nodgwl, npegwl, nprintcount, nprintday,            &
                                    numbit, outdat, outdatint, outper, pegwl, pegwl_bot,period, pond, pondini, pondm1, pondmx, pondmxtab, q,               &
                                    qbot, qbot_nonfrozen, qbotab, qimmob, qrot, qtop, epd, reva, rimlay, rsigni, rsoil, rsro, rsroexp, runon,              &
                                    runots, saev, shape_3, sinamp, sinave, sinmax, spev, sw2, sw3, sw4, swafo, swaun, swbal, swblc,swbotb, swbotb3Impl,    &
                                    SwBotb3ResVert, swcfbs, swheader, swkimpl, swkmean, swodat, swqhbot, swredu, swres, t, t1900, tau, tcum,               &
                                    tend, theta, thetar, thetas, thetm1, thetsl, tstart, volact, volini, volm1, zi
      use MOD_re_global,      only: mflux, mroot, hroot, qredwetsum, qreddrysum, qredsolsum, qredfrssum, qrosum
      use SWAP_csv_output,    only: swdiscrvert, numnodnew, dznew
      use MOD_meteo,          only: fwind
      
      implicit none 

! --- time & control variables
      flprintdt          = .FALSE. 
      flprintshort       = .FALSE. 
      floutputshort      = .FALSE. 
      nprintday          = 0 
      nprintcount        = 0 
      cntper             = 0 
      daycum             = 0 
      daynr              = 0 
      imonth             = 0 
      ioutdat            = 0 
      ioutdatint         = 0 
      isteps             = 0 
      iyear              = 0 

      period             = 0 
      swheader           = 0 
      swodat             = 0 
      swres              = 0 

      dt                 = 0.0d0 
      dtmax              = 0.0d0 
      dtmin              = 0.0d0 
      outdat             = 0.0d0 
      outdatint          = 0.0d0 
      outper             = 0.0d0 
      t                  = 0.0d0 
      t1900              = 0.0d0 
      tcum               = 0.0d0 
      tend               = 0.0d0 
      tstart             = 0.0d0 
      flbaloutput        = .FALSE. 
      fldayend           = .FALSE. 
      fldaystart         = .FALSE. 
      fldecdt            = .FALSE. 
      fldtmin            = .FALSE. 
      fldtreduce         = .FALSE. 
      flheader           = .FALSE. 
      floutput           = .FALSE. 
      flrunend           = .FALSE. 
      flzerocumu         = .FALSE. 
      flzerointr         = .FALSE. 

      
! --- meteo variables
      !idregr             = 0
      !iharvest           = 1
      !ilvold             = 0
      !ilvoldpot          = 0
      !iseqgm             = 0
      !iseqgmpot          = 0
      !swinter            = 0 

      !daylp              = 0.0d0 


      !dwlvpot            = 0.0d0 
      !dwrtpot            = 0.0d0 
      !dwstpot            = 0.0d0 
      fwind              = 1.0d0
      empreva            = 0.0d0 
      cfevappond         = 0.0d0 
      fprecnosnow        = 0.0d0 

      !laiexp             = 0.0d0 
      !laiexppot          = 0.0d0 
      !laimax             = 0.0d0 

      !tadw               = 0.0d0 
      !tadwpot            = 0.0d0 
      !tmnr               = 0.0d0 

! --- irrigation variables
      irrigevent         = 0 
      irtype             = 0 
      isua               = 0 
      isuas              = 0 
      nirri              = 0 
      schedule           = 0 
      swirfix            = 0 
      cirr               = 0.0d0
      cirrs              = 0.0d0 
      dcrit              = 0.0d0 
      ditab              = 0.0d0 
      dwatab             = 0.0d0 
      fidtab             = 0.0d0 
      gird               = 0.0d0 
      hcritab            = 0.0d0 
      irconc             = 0.0d0 
      irdate             = 0.0d0 
      irdepth            = 0.0d0 
      irrate             = 0.0d0
      ir_z               = 0.0d0
      dt_irr_event       = 1.0d0
      nird               = 0.0d0 
      raithreshold       = 0.0d0 
      rawtab             = 0.0d0 
      tawtab             = 0.0d0 
      tcritab            = 0.0d0 
      tstairrig          = 0.0d0 
      tendirrig          = 0.0d0 
      treltab            = 0.0d0 
      flheadirg          = .FALSE. 
      flirrigate         = .FALSE. 

! --- soilwater variables
      MaxBackTr          = 0 
      MaxIt              = 0 
      Itnumb             = 0 
      CritDevh1Cp        = 0.0d0 
      CritDevh2Cp        = 0.0d0 
      CritDevPondDt      = 0.0d0 
      flksatexm          = .FALSE. 
      fluseksatexm       = .FALSE. 
      bal                = 0 
      blc                = 0 
      bpegwl             = 0 
      botcom             = 0 
      indeks             = -1 
      isoillay           = 0 
      layer              = 0 
      msteps             = 0 
      ncomp              = 0 
      nhead              = 0 
      nodgwl             = 0 
      nod1lay            = 0 
      npegwl             = 0 
      nsublay            = 0 
      numbit             = 0 
      numlay             = 0 
      numnod             = 0 
      numnodnew          = 0 
      sw2                = 0 
      sw3                = 0 
      sw4                = 0 
      swafo              = 0 
      swaun              = 0 
      swbal              = 0
      swblc              = 0 
      swbotb             = 0 
      swbotb3Impl        = 0 
      SwBotb3ResVert     = 0 
      swcfbs             = 0 
      swdiscrvert        = 0 
      swhyst             = 0 
      swkmean            = 0 
      swkimpl            = 0 
      swpondmx           = 0 
      swqhbot            = 0 
      swredu             = 0 
      swsophy            = 0 
      aqamp              = 0.0d0 
      aqave              = 0.0d0 
      aqper              = 0.0d0 
      aqtmax             = 0.0d0 
      !bdens              = 0.0d0 
      cfbs               = 0.0d0 
      cofgen             = 0.0d0   ! initialized in see MOD_MvG
      cofqha             = 0.0d0 
      cofqhb             = 0.0d0 
      cofred             = 0.0d0 
      CritDevMasBal      = 0.0d0 
      deepgw             = 0.0d0 
      dimoca             = 0.0d0 
      disnod             = 0.0d0 
      dz                 = 0.0d0 
      dznew              = 0.0d0 
      gwl                = 0.0d0 
      gwlconv            = 0.0d0 
      gwli               = 0.0d0 
      gwlinp             = 0.0d0 
      gwlm1              = 0.0d0 
      gwltab             = 0.0d0 
      h                  = 0.0d0 
      h_enpr_global      = 0.0d0 
      haqtab             = 0.0d0 
      hbot               = 0.0d0 
      hbotab             = 0.0d0 
      hcomp              = 0.0d0 
      hdrain             = 0.0d0 
      hm1                = 0.0d0 
      delp               = 0.0d0
      hroot              = 0.0d0 
      hsublay            = 0.0d0 
      inpola             = 0.0d0 
      inpolb             = 0.0d0 
      k                  = 0.0d0 
      kmean              = 0.0d0 
      ksatfit            = 0.0d0 
      ksatexm            = 0.0d0 
      ldwet              = 0.0d0 
      mflux              = 0.0d0 
      mroot              = 0.0d0 
      paramvg            = 0.0d0   ! initialized in see MOD_MvG
      pegwl              = 0.0d0 
      pegwl_bot          = 0.0d0 
      pond               = 0.0d0
      pondini            = 0.0d0 
      pondm1             = 0.0d0 
      pondmx             = 0.0d0 
      pondmxtab          = 0.0d0 
      q                  = 0.0d0 
      qbot               = 0.0d0 
      qbotab             = 0.0d0 
      qbot_nonfrozen     = 0.0d0 
      qimmob             = 0.0d0 
      qrosum             = 0.0d0 
      qredwetsum         = 0.0d0 
      qreddrysum         = 0.0d0 
      qredsolsum         = 0.0d0 
      qredfrssum         = 0.0d0 
      qrot               = 0.0d0
      qssdi              = 0.0d0
      qtop               = 0.0d0 
      epd                = 0.0d0
      reva               = 0.0d0 
      rimlay             = 0.0d0 
      rsigni             = 0.0d0 
      rsoil              = 0.0d0 
      rsro               = 0.0d0 
      rsroexp            = 0.0d0
      runon              = 0.0d0 
      runots             = 0.0d0 
      saev               = 0.0d0 
      shape_3            = 0.0d0 
      sinamp             = 0.0d0 
      sinave             = 0.0d0 
      sinmax             = 0.0d0 
      spev               = 0.0d0 
      tau                = 0.0d0 
      theta              = 0.0d0 
      thetar             = 0.0d0 
      thetas             = 0.0d0 
      thetm1             = 0.0d0 
      thetsl             = 0.0d0 
      volact             = 0.0d0
      volini             = 0.0d0 
      volm1              = 0.0d0 
      z                  = 0.0d0 
      ztopcp             = 0.0d0
      zbotcp             = 0.0d0
      zi                 = 0.0d0 
      fllowgwl           = .FALSE. 

      call integral(1)

      return
      end subroutine Initialize

