module atmosphere_interface
   
   implicit none
   
   real(8), save :: tav                                    ! average air temperature of a day ( degrees C)
   real(8), save :: rad                                    ! global solar radiation (J/m2/d)
   real(8), save :: grai                                   ! Daily gross rain flux (L/T), without rain on snow

end module atmosphere_interface
