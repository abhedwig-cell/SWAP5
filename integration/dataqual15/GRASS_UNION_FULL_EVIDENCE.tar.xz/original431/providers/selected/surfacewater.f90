!submodule (MOD_drain) SMOD_drainage_extended

!   contains

      subroutine SurfaceWater(itask)
! ----------------------------------------------------------------------
!     date               : december 2004
!     purpose            : calculate surface water balance
! ----------------------------------------------------------------------
!     global
      use MOD_grid,      only: numnod, dz
      use variables,     only: t1900, gwl, dt
      use MOD_drain,     only: qdrain, nrlevs, qdra, qdrtot, swdivd, ksatcp, swsrf, wlp, wlptab, mawlp, swsec, wls, wlstab, mawls, swst, wlstar,   &
                               nmper, impend, swman, hbweir, intwl, nphase, gwlcrit, vcrit, nodhd, hcrit, wlsman, dropr, numadj, wldip, nrpri,     &
                               zbotdr, wscap, qdrd, swqhr, alphaw, betaw, sttab, qqhtab, wlsbak, osswlm, hqhtab, divdra
      implicit none 

!     global
      integer, intent(in)  :: itask

!     local
      integer              :: level
      
      real(8) :: afgen, swstlev

! ----------------------------------------------------------------------
      select case (itask)
      case (2)

! === lateral drainage fluxes to surface water ========================

! ---    no drainage at all
         if (gwl > 998.0d0) then
            qdrain(1:nrlevs)        = 0.0d0
            qdra(1:nrlevs,1:numnod) = 0.0d0   
            qdrtot                  = 0.0d0
            return
         end if

! ---    calculate lateral drainage
         call drainflux_extended ()

! ---    partition drainage flux over compartments
         if (swdivd == 1) then
            call divdra (ksatcp,gwl)
         else
            do level = 1,nrlevs
               qdra(level,numnod) = qdrain(level)
            end do
         end if

         qdrtot = 0.0d0
         do level=1,nrlevs
            qdrtot = qdrtot + qdrain(level)
         end do

      case (3)

! === surface water balance ========================

         if (swsrf == 3) then 
            wlp = afgen (wlptab,2*mawlp,t1900-1.0d0+dt)
         end if
         if (swsec == 2) then
! ---       water level of secondary system is simulated
            call wlevbal ()
         else if (swsec == 1) then
! ---       water level of secondary system is input
            wls = AFGEN (WLSTAB,2*MAWLS,t1900-1.d0+DT)
            swst = swstlev(wls)
         end if
      
      case default
         call swap_error ('surfacewater', 'Illegal value for TASK')
      end select

      contains
      
      ! ----------------------------------------------------------------------
            subroutine WLEVBAL ()
      ! ----------------------------------------------------------------------
      !     UpDate             : 20080109
      !     Date               : 19990929
      !     Purpose            : calculate surf. water level from water balance

      ! --- Set target level wlstar:
      ! --- SWMAN = 1: HBWEIR
      ! --- SWMAN = 2: from table (4e #2) and within adjustment period and 
      ! --- taking into account the maximum drop rate. 
      ! --- Calculate level for maximum supply wlstara ( = wlstar-wldip)

      ! --- Calculate storage at wlstar and at wlstara
      ! ---   If wlstara is above deepest bottom level then water supply 
      ! ---   capacity is set to maximum value otherwise both swsttara and
      ! ---   wsmax are set to zero

      ! --- Calculate max. new storage: old + incoming/outgoing fluxes
      ! --- 1 System falls dry: set supply to maximum,
      !       set wls at bottom of deepest channel
      ! --- 2 System will not become full: set supply to maximum
      !       calculate new level from storage
      ! --- 3 System becomes full under maximum supply conditions,
      ! ---   Determine how, first without supply
      ! --- 3a wlstara cannot be reached: calculate required supply,
      ! ---    to reach wlstara and set wls to wlstara
      ! --- 3b system can be filled above wlstara, however no discharge:
      ! ---    wls is calculated from storage and is somewhere between
      ! ---    wlstar and wlstara, no supply, no discharge
      ! --- 3c wlstar can be reached :wsupp = 0;
      ! ---    Now check whether there are automatic weirs for keeping the 
      ! ---    level at target value or that the discharge relationship
      ! ---    determines new level:
      ! --- 3c1 SWMAN=2: calculate discharge
      ! ---     check whether there is enough discharge capacity:
      ! ---     in case SWQHR = 1: calculate discap
      ! ---     in case SWQHR = 2: find discap from table
      ! ---     if sufficient capacity wls = wlstar otherwise set overflow
      ! --- 3c2 SWMAN=1 or overflow
      ! ---     Calculate highest possible discharge, if still unsufficient 
      ! ---     to handle present drain fluxes: stop - system overflow
      ! ---     otherwise start iteration procedure to determine new level,
      ! ---     storage and discharge:

      ! ***********************************************
      ! --- Iteration Procedure:
      ! --- Establish lower and upper bounds: hbweir(imper) and +100cm
      ! --- Calculate storage and discharge for point halfway: swsti, wdisi
      ! --- Calculate new storage: if higher than swsti then adjust lower
      ! --- bound to point halfway otherwise adapt upper bound to point halfway
      ! --- Continue until upper and lower bounds converge (< 0.001 cm)   
      ! --- Ready: update wls, swst and wdis
      ! ***********************************************

      !     Subroutines called :                          
      !     Functions called   : swstlev                          
      !     File usage         :
      ! ----------------------------------------------------------------------
            use MOD_swap_mp,   only: QRapDra
            use variables,     only: tcum,gwl,runots,t,thetas,theta,h,fldecdt,fldtmin,rsro,pond,pondmx

            implicit none

      ! --- global
     
      ! --- local
            INTEGER              :: iphase,NODE,Intday,imper
            real(8)              :: wlstx,swsttar,dvmax,swstmax,wdis,wlstarb
            real(8)              :: wover,discap,wlsl,wlsu,wlsi,swsti,wdisi,swstn
            real(8)              :: wprod1,wprod2,oscil,wlstara
            real(8)              :: swsttara,rday,wsmax,vtair
            character(len=200)   :: message
            character(len=19)    :: datetime
            logical              :: overfl

            save
      !-----------------------------------------------------------------------
      ! --- resetting of flag for overflowing of automatic weir
            overfl = .FALSE.

      ! --- memorizing previous target level
            wlstarb = wlstar

      ! --- determine which management period the model is in:
            imper = 0
       100  imper = imper + 1

      ! --- error handling
            if (imper > nmper) then
               message = 'error sw-management periods(IMPER), more than defined'
               call swap_error ('wlevbal', message)
            end if
      
            if (t1900-1.d0+0.1d-10 > impend(imper)) goto 100

      ! --- determine the target sw-level:
            if (swman(imper) == 1) then

      ! --- In the case of a fixed weir the 'target level' is set to the 
      ! --- weir crest, for later use in calculations to determine whether 
      ! --- there is any outflow at all (see below):
              wlstar = hbweir(imper)
            else

      ! ---  For automatic weir, determine the target level of the surface 
      ! ---  water, dependent on groundwater level:

      ! ---   only adjust it if new subperiod, with length intwl(imper) has 
      !       started  (or if it is is the first call)
              rday = (T+1.0D0)/intwl(imper)
              intday = int(rday)

              if (abs(rday-1.0d0*intday) < 0.00001d0 .OR. tcum < 1.0d-10) then

                iphase = nphase(imper)
                do while(gwl > gwlcrit(imper,iphase) .AND. iphase > 1) 
                  iphase = iphase-1
                end do

      ! --- compare total air volume with VCRIT, adapt iphase
                VTAIR = 0.0d0
                do NODE = 1,NUMNOD
                  VTAIR = VTAIR + dmax1(0.0d0, (THETAS(NODE)-THETA(NODE)))*abs(DZ(NODE))
                end do
                do while (VTAIR < VCRIT(imper,iphase) .AND. IPHASE > 1)
                  iphase = iphase - 1
                end do

      ! --- compare H(nodhd(imper)) with HCRIT, adapt iphase 
                do while (h(nodhd(imper)) > hcrit(imper,iphase)  .AND. iphase > 1) 
                  iphase = iphase - 1
                end do

                wlstx = wlsman(imper,iphase)
              else

      ! --- use old level
                wlstx = wlstarb
              end if

      ! ---   if the level must drop, then do not let it drop at more than 
      ! ---   the specified rate:
              if (wlstx < wlstar .AND. dropr(imper) > 0.001d0) then
                wlstar = wlstar - dropr(imper)*dt
                if (wlstar < wlstx) wlstar = wlstx
              else
                wlstar = wlstx
              end if
            end if

      ! --- counter of adjustments
            if (abs(wlstar-wlstarb) > 0.00001d0) then
               numadj = numadj + 1
            end if

      ! --- storage for the 'target level'
            swsttar = swstlev(wlstar)

      ! --- level and storage for "max. level for supply"
            wlstara = wlstar - wldip(imper)
            if (wlstara > (zbotdr(1+nrpri)+1.d-4)) then
               swsttara = swstlev(wlstara)
               wsmax = wscap(imper)
            else
               swsttara = 0.0d0
               wsmax = 0.0d0
            end if
      
      ! --- determine whether the system will become full (target level or
      ! --- level of weir crest):
            dvmax = (qdrd + QRapDra + wsmax) * dt + runots
            swstmax = swst + dvmax

            if (swstmax < 1.0d-7) then
      ! ---   storage decreases to zero, then the surface water system 
      ! ---   falls dry; set surface water supply to maximum: 

              if (swstmax < -0.1d0) then
                message = 'error algorithm for sw falling dry'
                call swap_error ('wlevbal', message)
              end if

              wdis = 0.0d0
              swst = 0.0d0
              wls = zbotdr(nrpri+1)

            else if (swstmax >= 0.0d0 .AND. swstmax < swsttara) then
      ! --- system will not become full - set supply to max. capacity
              wdis = 0.0d0
              swst = swstmax

      ! --- calculate new level from storage
              wls = wlevst(swst)
            else

      ! --- determine how system will become full: with or without needing
      !     surface water supply; try first without any supply:
              dvmax = (qdrd + QRapDra) * dt + runots
              swstmax = swst + dvmax
              if (swstmax <= swsttara) then

      ! --- apparently supply is needed for reaching target level, system 
      !     is made full up to level wlstara, because supply is controllable:
                wdis = 0.0d0
                swst = swsttara
                wls = wlstara
              else if (swstmax <= swsttar) then

      ! --- apparently drainage is more than sufficient for filling system
      !     to a level above the target level FOR SUPPLY, but not enough
      !     for generating discharge; so calculate level from storage:
                wdis = 0.0d0
                swst = swstmax
                wls = wlevst(swst)
              else

      ! --- drainage water is more than sufficient for reaching target
      !     level;  now see whether there are automatic weirs for keeping
      !     the level at target value, or that the discharge relationship
      !     determines new level:
                if (swman(imper) == 2) then

      ! --- the outflow equals the drainage flux, plus the storage
      !     excess (or deficit !) in the target situation compared to
      !     the actual situation: 
                  wdis = (swst-swsttar + (qdrd+QRapDra)*dt + runots )/dt

      ! --- now check whether the weir has enough discharge capacity 
      !     at this water level
                  if (SWQHR == 1) then
                    wover = wls - hbweir(imper)
                    discap = alphaw(imper) * (wover**betaw(imper))
                  else if (SWQHR == 2) then

      ! --- interpolate QH table
                    discap = fun_qhtab(imper,wlstar)
                  end if
                  if (discap > wdis) then
                    wls = wlstar
                    swst = swsttar
                    overfl = .FALSE.
                  else
                    overfl = .TRUE.
                  end if
                end if
                if (swman(imper) == 1 .OR. overfl) then

      ! --- determine level from q-h relationship, and also account
      !     for change in storage (see below)
      !     check first that the system does not overflow 
                  if (SWQHR == 1) then
                    wover = sttab(1,1) - hbweir(imper)
                    discap = alphaw(imper) * (wover**betaw(imper))
                  else if (SWQHR == 2) then
                    discap = QQHTAB(imper,1)
                  end if
            
      ! ---       error handling
                  swstn = swst + (qdrd + QRapDra - discap)*dt + runots
                  if ( swstn > sttab(1,2) ) then
                    message = 'surface water system has overflowed!'
                    call swap_error ('wlevbal', message)
                  end if

      ! --- iteration procedure for determining new level, storage, 
      !     and discharge
                  wlsl = hbweir(imper)
                  wlsu = sttab(1,1)

      ! --- find storage and discharge for intermediate point
       700        wlsi = (wlsl + wlsu) * 0.5d0
                  swsti = swstlev(wlsi)
                  if (SWQHR == 1) then
                    wdisi = alphaw(imper)*(wlsi-hbweir(imper))**betaw(imper)
                  else
                    wdisi = fun_qhtab(imper,wlsi)
                  end if
                  swstn = swst + (qdrd + QRapDra - wdisi)*dt + runots
                  if (swstn < swsti) then
                    wlsu = wlsi 
                  else
                    wlsl = wlsi
                  end if
                  if ((wlsu - wlsl) > 0.001d0) then

      ! --- continue iteration procedure:
                    goto 700
                  else

      ! --- updating of sw-parameters:
                    wls = wlsi
                    swst = swstn
                    wdis = wdisi
                  end if
                end if
              end if
            end if

      !        ponding in case of extended drainage may limit timestep

            if (wls > pondmx .OR. pond > pondmx) then
              if (dt > 0.02*rsro) fldecdt = .TRUE.
              return
            end if

      ! --- updating registration of last four levels, for noting oscillation
            wlsbak(1) = wlsbak(2)
            wlsbak(2) = wlsbak(3)
            wlsbak(3) = wlsbak(4)
            wlsbak(4) = wls
            wprod1 = (wlsbak(2)-wlsbak(1))*(wlsbak(3)-wlsbak(2))
            wprod2 = (wlsbak(3)-wlsbak(2))*(wlsbak(4)-wlsbak(3))
            if (wprod1 < 0.0d0 .AND. wprod2 < 0.0d0) then
              oscil = abs(wlsbak(3)-wlsbak(2)) 
              if (oscil > osswlm) then
                 if (.NOT.fldtmin ) then
                    fldecdt = .TRUE.
                    return  
                 else
                    call dtdpst('year-month-day,hour:minute:seconds',t1900,datetime)
                    message = 'sw-level oscillation at '//datetime//'; advise: reduction of dtmax !'
                    call swap_error ('wlevbal', message)
                 end if
              end if
            end if

            return
            end subroutine WLEVBAL

            function fun_qhtab (imper,wlev)
      !-----------------------------------------------------------------------
      !     date               : 23/08/99
      !     purpose            : calculate surface water discharge from  
      !                          surface water level, using table
      ! ----------------------------------------------------------------------
            implicit none
            integer, intent(in)  :: imper
            real(8), intent(in)  :: wlev
            real(8)              :: fun_qhtab

            integer              :: itab
            real(8)              :: dwl
      ! ----------------------------------------------------------------------

            itab = 2
            do while (wlev < hqhtab(imper,itab))
              itab = itab+1
            end do
            dwl = (wlev-hqhtab(imper,itab))/(hqhtab(imper,itab-1)-hqhtab(imper,itab))
            fun_qhtab = qqhtab(imper,itab) + dwl * (qqhtab(imper,itab-1)-qqhtab(imper,itab))  

            return
            end function fun_qhtab

            function WLEVST(swstor)
      ! ----------------------------------------------------------------------
      !     Date               : 23/08/99
      !     Purpose            : calculate surface water level from    
      !                          surface water storage, using table
      !     Subroutines called : -
      !     Functions called   : -
      !     File usage         : -
      !     Differences SWAP/SWAPS: None
      ! ----------------------------------------------------------------------
            implicit none
      ! --- global
            real(8), intent(in)  :: swstor
            real(8)              :: WLEVST
      ! --- local
            integer              :: i
            real(8)              ::dswst

      ! ----------------------------------------------------------------------
            if (swstor < sttab(22,2)) call swap_error ('wlevst', 'Surface water storage below bottom of table')
            if (swstor > sttab(1,2))  call swap_error ('wlevst', 'Surface water storage above top of table')

            i = 0
       100  i = i+1
            if (.NOT.(swstor >= sttab(i+1,2) .AND. swstor <= sttab(i,2))) goto 100
            dswst = (swstor - sttab(i+1,2)) / (sttab(i,2) - sttab(i+1,2))
            wlevst = sttab(i+1,1) + dswst * (sttab(i,1) - sttab(i+1,1))

            return
            end function WLEVST
   
      end subroutine SurfaceWater

! ----------------------------------------------------------------------
      subroutine drainflux_extended ()
! ----------------------------------------------------------------------
!     Date               : 5/5/2001
!     Purpose            :        
! --- Calculate drainage/infiltration fluxes for all levels: qdrain(level).
! --- Summate fluxes to secondary system: qdrd
! --- Given present storage (swst), qdrd and wscap(imper), check if the
! --- system falls dry. If so reduce drainage fluxes proportionally in 
! --- such a way that total drainage flux equals available amount 
! --- ( = swst + wscap).
!     Subroutines called : -                                           
!     Functions called   : -                                     
!     File usage         : -  Error handling
! ----------------------------------------------------------------------  
      use MOD_swap_base, only: swmacro
      use MOD_swap_mp,   only: NumLevRapdra,ZDraBas, swdrrap
      use variables,     only: gwl,pond,pondmx,dt,t1900
      use MOD_drain,     only: qdrd, nrlevs, swsrf, nrpri, wls, wlp, zbotdr, drainl, swdtyp, wetper, widthr, taludr, diffl, gwlinf, swnrsrf,    &
                               qdrain, cofintfl, expintfl, rdrain, rentry, rsurfdeep, rsurfshallow, rinfi, rexit, lspacing, swsec, nmper,       &
                               impend, wscap, swst
      IMPLICIT NONE

! --- local
      integer              :: level,imper
      real(8)              :: qdrdm,qdratio,swdepth,swexbrd,dvmax,swstmax,wl,rd,re  !,wetper

      save
! ----------------------------------------------------------------------

! --- summate fluxes for use by swballev and swlevbal
      qdrd = 0.0d0

      do level = 1,nrlevs

! ---    surface water level
         if (swsrf >= 2) then
            if (level > nrpri) then
               wl = wls
            else
               wl = wlp
            end if
         end if

! ---    drainage fluxes are set to zero if both groundwater level and surface 
!        water level are above ponding sill (so the nonzero drainage flux 
!        is only computed if either the gwl or the wl is below pondmx)
         if (wl < pondmx .OR. gwl < pondmx) then

! ---       channel is active medium if either groundwater or surface water
!           level is above channel bottom
            if (gwl > (zbotdr(level) + 0.001d0) .OR. wl > (zbotdr(level) + 0.001d0)) then
               if (wl <= (zbotdr(level) + 0.001d0) .OR. swsrf == 1) then

! ---             only groundw. level above channel bottom; bottom is dr. base
                  drainl(level) = zbotdr(level)

! ---             wetted perimeter only computed for open channels (for drains it is input) 
                  if (swdtyp(level) == 2) wetper = widthr(level)
               else

! ---             surface water level above channel bottom
                  drainl(level) = wl
                  if (swdtyp(level) == 2) then
                     swdepth = wl-zbotdr(level)
                     swexbrd = (wl-zbotdr(level)) / taludr(level)
                     wetper = widthr(level) + 2.d0 * dsqrt(swdepth**2 + swexbrd**2) 
                  end if
               end if

! ---          drainage flux (cm/d)
               ! calculate head difference
               diffl(level) = gwl - drainl(level)
               if (gwl > -0.1d0) diffl(level) = diffl(level) + pond
               if (diffl(level) < 0.0d0  .AND. gwl < gwlinf(level)) then
                  diffl(level) = gwlinf(level) - drainl(level)
               end if
               ! interflow flux calculated by a power function, 
               if ((level == nrlevs) .AND. (swnrsrf == 2)) then               
                  qdrain(level) = cofintfl * diffl(level)**expintfl                 
               else 
                  if (diffl(level) > 0.0d0) then
                     rd = rdrain(level)
                     re = rentry(level)
! ---                surface drainage (vaccuum cleaner)
                     if ((level == nrlevs) .AND. (swnrsrf == 1)) then
                        rd = rsurfdeep - diffl(level)
                        rd = max(rd, rsurfshallow)
                     end if
                  else
                     rd = rinfi(level)
                     re = rexit(level)
                  end if 
                  if (swdtyp(level) == 2) then
                     qdrain(level) = diffl(level) / ((rd + re * Lspacing(level) / wetper))
                  else
                     qdrain(level) = diffl(level) / rd
                  end if 
               end if
            else
               diffl(level) = 0.0d0
               qdrain(level) = 0.0d0

!              for determining drainage basis for rapid drainage through macropores
               drainl(level) = zbotdr(level)

            end if
!
         else
            qdrain(level) = 0.0d0

!           for determining drainage basis for rapid drainage through macropores
            drainl(level) = wl

         end if
!
         if (swsrf >= 2 .AND. level > nrpri) then

! ---       qdrd is total flux to or from secondary system
            qdrd = qdrd + qdrain(level)
         end if

      end do

!   - drainage basis for rapid drainage through macropores
      if (swmacro == 1) then
         if (swdrrap == 1) then
            if (swdtyp(NumLevRapDra) == 2) then
               ZDraBas = drainl(NumLevRapDra)
            end if
         end if
      end if

! ----------------------------------------------------------------------
! --- check for system falling dry (only for swsec = 2):
      if (swsec == 1) return
      if (swsrf == 1) then
         do level = 1,nrlevs
            if (qdrain(level) < 0.0d0) then
               qdrain(level) = 0.0d0
            end if
         end do
      else if (swsrf >= 2) then

! ---    determine which management period the model is in:
         imper = 0
 800     imper = imper + 1

! ---    Error handling
         if (imper > nmper) call swap_error ('drainflux_extended', 'sw-management periods(IMPER), more than defined')
         if (t1900 - 1.d0 + 0.1d-10 > impend(imper)) goto 800

! ---    determine whether the system will become empty
         dvmax = (qdrd + wscap(imper)) * dt
         swstmax = swst + dvmax

         if (swstmax < 0.0d0) then
! ---       storage decreases to below zero, then the surface water system 
!           falls dry; make the total infiltration exactly equal to the
!           available amount:
            qdrdm = - (swst + wscap(imper) * dt) / dt
            qdratio = qdrdm / qdrd

! ---       Error handling
            if (qdratio > 1.0d0 .OR. qdratio < 0.0d0) call swap_error ('drainflux_extended', 'sw-management error with storage (qdratio)')

            do level = 1 + NRPRI, nrlevs
               qdrain(level) = qdrain(level) * qdratio
            end do 
            qdrd = qdrdm
         end if
      end if

      return
      end subroutine drainflux_extended
   
      ! ----------------------------------------------------------------------
      subroutine read_drainage_extended()

   ! ----------------------------------------------------------------------
   !     UpDate             : 20080109
   !     Date               : 20010605                   
   !     Purpose            : reading multilevel drainage characteristics 
   !                          and specification of the surface water system
   !                          for a period up to one year;  
   !
   ! --- 1 Reading extended drainage input from .dra-file
   ! --- 2 Initializations
   !
   ! --- Initializations:
   ! -1- wlp: water level in primary system   (SWSRF = 3)
   ! -2- wls: water level in secondary system (SWSRF = 2 or 3, SWSEC = 1 or 2) 
   ! -3- HBWEIR(IMPER) in case of table discharge relation (SWQHR = 2)
   ! -4- NUMADJ: number of target level adjustments
   ! -5- sttab(22,2) table with storage as a function of water level
   ! ---    sttab(i,1) contains levels:
   ! ---    i=1: +100 cm; i=2: 0 cm; i=22: bottom of deepest dr. medium
   ! ---    sttab(i,2) contains storage expressed as surface layer 
   ! ----------------------------------------------------------------------
      
         use MOD_arrays,    only: maho, mawls, madr, mamp, mamte, mawlp, mabbc
         use MOD_swap_base, only: iun_min2, iun_max2, pathdrain, unit_err, swmacro, swsolu
         use MOD_swap_mp,   only: swdrrap, numlevrapdra, zdrabas
         use MOD_grid,      only: numnod, dz, numlay, layer
         use variables,     only: t1900,tstart,tend, ksatexm, ksatfit, fluseksatexm
         use MOD_drain,     only: drfil, swdivd, ksatcp, swdivdinf, facdpthinf, cofani, nrlevs, swdislay, swtopdislay, ztopdislay, ftopdislay,  &
                                  swdtyp, lspacing, zbotdr, gwlinf, rdrain, rinfi, rentry, rexit, widthr, taludr, swnrsrf, rsurfdeep,           &
                                  rsurfshallow, cofintfl, expintfl, swtopnrsrf, swsrf, nrpri, nrsec, wlptab, wlp, swsec, wlstab, wls, osswlm,   &
                                  nmper, wlstar, impend, swman, wscap, wldip, intwl, swqhr, hbweir, alphaw, betaw, hqhtab, qqhtab, dropr,       &
                                  nodhd, nphase, wlsman, gwlcrit, hcrit, vcrit, sttab, swst, maowl
         implicit none

   ! --- global
      
   ! --- local
         integer            :: level(Madr),itab,i,ilev
         integer            :: iph,nrman1,nrman2,node,imperb,imperi,ifnd,imper
         integer            :: imper_4b(mamp),imper_4c(mamp),imper_4d(mamp)
         integer            :: imper_4e1(mamp*mamte),imper_4e2(mamp*mamte)
         integer            :: imptab(mamte),impphase(mamp*mamte), nmper2, nqh(mamp)
         real(8)            :: wlp1(mawlp),wls1(mawlp),zb, hhtab(mamp),qhtab(mamp)
         real(8)            :: wlsman_t(mamp*mamte),gwlcrit_t(mamp*mamte)
         real(8)            :: hcrit_t(mamp*mamte),vcrit_t(mamp*mamte)
         real(8)            :: dates(mabbc)
         real(8)            :: wdepth,wbreadth,wvolum,dep,sofcu,altcu
         real(8)            :: hdepth(mamp*mamte)
         logical            :: flweir(mamp),exists(mamp),flzero(mamp),rdinqr,rdinar
         character(len=80)  :: filnam
         character(len=200) :: message
         logical            :: file_exists
         integer            :: unit_dra
         real(8), parameter :: small = 0.0001d0
      
         ! functions
         integer            :: getun2
         real(8)            :: afgen, swstlev

   ! ----------------------------------------------------------------------

   ! --- open file with extended drainage data
         filnam = trim(pathdrain)//trim(drfil)//'.dra'
         inquire(file = filnam, exist = file_exists)
         if (.NOT. file_exists) then
            message ='File '//trim(filnam)//' does not exists!'
            call swap_error ('rddre', message)
         end if        
         unit_dra = getun2 (iun_min2, iun_max2, 2)
         call rdinit(unit_dra,unit_err,filnam)

   ! --- division of drainage fluxes
         call rdsinr ('swdivd',0,1,swdivd)
         if (swdivd == 0 .AND. swsolu > 0) then
            write(message,'(3a)') ' Variabel SWDIVD=0 and SWSOLU>0 in inputfile :',trim(filnam),' this yields incorrect results for solute transport'
            call swap_error ('rddre', message)
         end if
         if (swdivd == 0) then
             message = 'Variabel SWDIVD=0 in input file: '//trim(filnam)//'; this is not recommended and may cause numerical instability'
             call swap_warning ('rddre', message)
         end if
         if (swdivd == 1) then
            ! Initialize ksatcp for use in divdra
            do node = 1,numnod
               if (fluseksatexm(node) .AND. swmacro == 0) then
                  ksatcp(node) = ksatexm(layer(node))
               else
                  ksatcp(node) = ksatfit(layer(node))
               end if
            end do
            ! Read additional input
            if (rdinqr('swdivdinf')) then
               call rdsinr ('swdivdinf',0,1,swdivdinf)
               if (swdivdinf == 1) call rdsdor ('FacDpthInf',0.d0,1.d0,FacDpthInf)
            end if
            if (rdinar('cofani')) then
               call rdfdor ('cofani',1.d-4,1000.d0,cofani,maho,numlay)
            else
               call rdsdor ('cofani',1.d-4,1000.d0,cofani(1))
            end if
         end if

   ! --- altitude of control unit (relative to reference level)
         call rdsdor ('altcu',-3.0d5,3.0d5,altcu)

   ! --- part 1

   ! --  number of drainage levels
         call rdsinr ('nrsrf',1,Madr,nrlevs)

   ! --  top of model dicharge layer, determined by factor or direct input
         if (swdivd == 1) then
           call rdsinr ('swdislay',0,2,swdislay)
           if (swdislay == 1) then
             call rdfinr ('swtopdislay',0,1,swtopdislay,madr,nrlevs)
             call rdfdor('ztopdislay',-1.0d4,0.0d0,ztopdislay,madr,nrlevs)
           else if (swdislay == 2) then
             call rdfinr ('swtopdislay',0,1,swtopdislay,madr,nrlevs)
             call rdfdor('ftopdislay',0.0d0,1.0d0,ftopdislay,madr,nrlevs)
           end if
         end if

   ! --- characteristics of each drainage level 
         call rdfinr ('lev',1,Madr,level,Madr,nrlevs)
         call rdfinr ('swdtyp',0,2,swdtyp,Madr,nrlevs)
         call rdfdor ('l',1.0d0,100000.0d0,Lspacing,Madr,nrlevs)
         call rdfdor ('zbotdre',(altcu-1.0d3),(altcu-1.0d-2),zbotdr,Madr,nrlevs)
         call rdfdor ('gwlinf',-10000.0d0,0.0d0,gwlinf,Madr,nrlevs)
         call rdfdor ('rdrain',1.0d0,1.0d5,rdrain,Madr,nrlevs)
         call rdfdor ('rinfi',1.0d0,1.0d5,rinfi,Madr,nrlevs)
         call rdfdor ('rentry',0.0d0,10.0d0,rentry,Madr,nrlevs)
         call rdfdor ('rexit',0.0d0,10.0d0,rexit,Madr,nrlevs)
         call rdfdor ('widthr',0.0d0,10000.0d0,widthr,Madr,nrlevs)
         call rdfdor ('taludr',1.0d-2,5.0d0,taludr,Madr,nrlevs)

   ! -   conversions and security checks....
         do i = 1, nrlevs
   !       conversions
           Lspacing(i) = Lspacing(i)*100.0d0
           if (swdtyp(i) == 0) swdtyp(i) = 2
           zbotdr(i) = zbotdr(i) -altcu
           if (swdivd == 1 .AND. swdislay == 1) then
             ztopdislay(i) = ztopdislay(i) - altcu
             if (ztopdislay(i) < zbotdr(i)) then
               message = 'Ztopdislay cannot be below Zbotdre, verify input!' 
               call swap_error ('rddre', message)
             end if
           end if
   ! -     security checks....
   ! -     0 - verify levels-index
   ! -     1 - levels must be ordered, starting with the deepest
   ! -     2 - zbotdr always below surface level
   ! -     3 - gwlinf must be below bottom of deepest drainage medium
   ! -     4 - widthr must be greater than zero for non-tube drain systems
           if (level(i) /= i) call swap_error ('rddre', 'Drainage level index is not consistent' )
           if (i > 1) then
             if (zbotdr(i) < zbotdr(i-1)) call swap_error ('rddre', 'Levels must be ordered, starting with deepest')
           end if
           if (gwlinf(i) > zbotdr(i)) call swap_error ('rddre', 'Gwlinf should be lower than Zbotdr !')
           if (swdtyp(i) == 2  .AND. widthr(i) < small) then
               write(message,'(a,f10.5)') 'widthr must be greater than ',small
               call swap_error ('rddre', message)
           end if
         end do

   ! --- type of highest drainage level
         call rdsinr ('swnrsrf',0,2,swnrsrf)
         if (swnrsrf == 1) then
           call rdsdor ('rsurfdeep',0.001d0,1000.0d0,rsurfdeep)
           call rdsdor ('rsurfshallow',0.001d0,1000.0d0,rsurfshallow)
         else if (swnrsrf == 2) then
           call rdsdor ('cofintfl',0.01d0,10.0d0,cofintfl)     
           call rdsdor ('expintfl',0.1d0,1.0d0,expintfl) 
         end if

   ! kroes 20080707 : allow disabling of option
         if (swdivd == 1) then
           if (swnrsrf > 0)  call rdsinr ('SwTopnrsrf',0,1,SwTopnrsrf)
         end if

   ! --- part 2a
         call rdsinr ('swsrf',1,3,swsrf)
         if (swsrf == 3) then
           nrpri = 1
           nrsec = nrlevs-nrpri
         else if (swsrf == 2) then
           nrpri = 0
           nrsec = nrlevs-nrpri
         else if (swsrf == 1) then
   ! ---   no surface water system...ready
           close (unit_dra)
           return
         end if

         if (swdtyp(1+nrpri) == 1) call swap_error ('rddre', 'Deepest sec. level must be open.')

   ! --- part 2b
   ! --- read table with water levels in the primary system (SWSRF=3)
         if (swsrf == 3) then
   ! -     read and store
           call rdatim ('datepri',dates,mawlp,ifnd)
   ! -     at least one date must be within simulation period
           call checkdate(ifnd,dates,tend,tstart,'datepri ','readswap//swsrf=3        ')
           call rdfdor('wlp',(altcu-1000.0d0),(altcu+200.0d0),wlp1,mawlp,ifnd)
           do i = 1, ifnd
             wlptab(i*2) = wlp1(i) - altcu
             wlptab(i*2-1) = dates(i)
           end do
   ! ---   set initial value
           wlp = afgen (wlptab,2*mawlp,t1900-1.d0)

         end if

   ! --- part 2c

         call rdsinr ('swsec',1,2,swsec)

   ! --- part 3

         if (swsec == 1) then
   ! ---   surface water level of secondary system is input
   ! ---   position file pointer

   ! -     read and store
           call rdatim ('datesec',dates,mawlp,ifnd)
   ! -     at least one date must be within simulation period
           call checkdate(ifnd,dates,tend,tstart,'datesec ','readswap//swsec=1        ')

           call rdfdor ('wls',(altcu-1000.0d0),(altcu+200.0d0),wls1,mawlp,ifnd)
           do i = 1, ifnd
             wlstab(i*2) = wls1(i) -altcu
             wlstab(i*2-1) = dates(i)
           end do
   ! ---   set initial value
           wls = afgen (wlstab,2*mawls,t1900-1.0d0)

   ! ---   part 4a

   ! --- surface water level of secondary system is simulated
         else if (swsec == 2) then
           call rdsdor ('wlact',dble(zbotdr(1+nrpri)+altcu),dble(altcu),wls)
           wls = wls - altcu
           call rdsdor ('osswlm',0.0d0,10.0d0,osswlm)

   ! ---   part 4b

           call rdsinr ('nmper',1,mamp,nmper)
           wlstar = wls

           call rdfinr ('imper_4b',1,nmper,imper_4b,mamp,nmper)
           call rdftim ('impend',impend,mamp,nmper)
           call rdfinr ('swman',1,2,swman,mamp,nmper)
           call rdfdor ('wscap',0.0d0,10.0d0,wscap,mamp,nmper)
           call rdfdor ('wldip',0.0d0,100.0d0,wldip,mamp,nmper)
           call rdfinr ('intwl',1,31,intwl,mamp,nmper)

   ! -     for each type of management: count number of periods 
           nrman1 = 0
           nrman2 = 0
           do imper = 1, nmper
             if (swman(imper) == 2 .AND. intwl(imper) < 1) call swap_error ('rddre', 'intwl (management interval) must be > = 1d')
             wldip(imper) = abs(wldip(imper))
             if (swman(imper) == 1) then 
               nrman1 = nrman1+1
             else if (swman(imper) == 2) then
               nrman2 = nrman2+1
             else
               call swap_error ('rddre', 'SWMAN is out of range.')
             end if
           end do
           if ((nrman1+nrman2) /= nmper) call swap_error ('rddre', 'nrman1+nrman2 does not match nmper')

   ! ---   type of discharge relationship
           call rdsinr ('swqhr',1,2,swqhr)

           IF (SWQHR == 1) THEN

   ! ---     part 4c
             call rdsdor ('sofcu',0.1d0 ,100000.0d0,sofcu)
             call rdfinr ('imper_4c',1,nmper,imper_4c,mamp,nmper)
             zb = min(zbotdr(1),zbotdr(2))
             call rdfdor('hbweir',(altcu+zb),(altcu+100.0d0),hbweir,mamp,nmper)
             call rdfdor('alphaw',0.1d0,50.0d0,alphaw,mamp,nmper)
             call rdfdor('betaw',0.5d0,3.0d0,betaw,mamp,nmper)

   ! ---     convert and check values
   !         initialise
             imperb = 0
             imperi = 0
             do imper = 1, nmper
               hbweir(imper) = hbweir(imper)-ALTCU
   ! ---       correction for units
               alphaw(imper) = alphaw(imper)* (8.64d0* 100.0d0**           &
                               (1.0d0-betaw(imper))/SOFCU)     
               if (hbweir(imper) < zbotdr(1+NRPRI)) call swap_error ('rddre', 'Weir crest level is below bottom of deepest channel of secondary system.')
   ! --- check for target level above channel bottom when supply is 
   ! --- attempted (system may never become dry in this case)
               if (swman(imper) == 1 .AND. wscap(imper) > 1.d-7 .AND. (hbweir(imper)-wldip(imper)) < (zbotdr(1+NRPRI)+1.d-4)) then
                 call swap_error ('rddre', 'HBWEIR/WLDIP! Supply not possible =< zbotdr !')
               end if

               if (imper /= imperb) then
                 imperb = imper
                 imperi = imperi + 1
               else
                 call swap_error ('rddre', '4c imper not unique')
               end if
             end do

   ! ---     check number of records.. 
             if (imperi /= nmper) call swap_error ('rddre', 'part 4c - not enough records')

           else if (swqhr == 2) then

   ! ---     part 4d
   ! --      initialise
             imperb = 0
             imperi = 0
             do imper = 1,nmper
               nqh (imper) = 0
               flweir (imper) = .FALSE.
               exists (imper) = .FALSE.
               flzero (imper) = .FALSE.
             end do

   ! --      read and store
             call rdainr ('imper_4d',1,nmper,imper_4d,mamp,ifnd)
             call rdfinr ('imptab',1,mamte,imptab,mamte,ifnd)
             call rdfdor ('hhtab',(altcu-1000.0d0),(altcu+100.0d0),hhtab,mamp,ifnd)
             call rdfdor ('qhtab',0.0d0,500.0d0,qhtab,mamp,ifnd)

   ! ---     convert
             do i = 1, ifnd
               hqhtab(imper_4d(i),imptab(i)) = hhtab(i) - Altcu
               qqhtab(imper_4d(i),imptab(i)) = qhtab(i)
             end do

   ! ---     check values
             do i = 1, ifnd
               imper = imper_4d(i)
               itab = imptab(i)
               nqh(imper) = nqh(imper)+1
               exists(imper) = .TRUE.
               if (qqhtab(imper,itab) < 0.000001d0) flzero(imper)=.TRUE.
               if (hqhtab(imper,itab) < zbotdr(1+nrpri)) call swap_error ('rddre', 'Level in q-h table below bottom of deepest channel of secondary system.')
               if (imper /= imperb) then
                 imperb = imper
                 imperi = imperi + 1
               end if

   ! -         establish hbweir (at level where qtab = 0) 
               if (qqhtab(imper,itab) < 0.0001d0 .AND. .NOT.flweir(imper)) then
                 hbweir(imper) = hqhtab(imper,itab)
                 flweir(imper) = .TRUE.
               end if 

   ! -         consistency checks
               if (nqh(imper) /= itab) call swap_error ('rddre', 'qh-table / imper - itab mismatch')
               if (itab == 1) then
                 if (abs(hqhtab(imper,itab)-100.0d0) > 0.00001d0) call swap_error ('rddre', 'First value in htab should be altcu+100.0')
               end if
               if (itab > 1) then
                 if ((hqhtab(imper,itab) >= hqhtab(imper,itab-1)) .OR. (qqhtab(imper,itab) > qqhtab(imper,itab-1))) then
                    call swap_error ('rddre', 'qh-table - no descending values')
                 end if
               end if

             end do

   ! ---     check number of periods.. 
             if (imperi /= nmper) call swap_error ('rddre', 'part 4d - number of periods incorrect.')

   ! ---     check that QQHTAB goes down to zero
             do imper = 1,nmper
               if (exists(imper) .AND. .NOT.flzero(imper)) call swap_error ('rddre', 'qqhtab not going down to zero.')
             end do

           end if

   ! ---   part 4e1

           if (nrman2 > 0) then

             imperb = 0
             imperi = 0

   ! ---     read table with drop rates (length of table must be equal 
   !            to the nr of management periods referred to in tabel 4e2
             call rdainr('imper_4e1',1,nmper,imper_4e1,(mamp*mamte),nmper2)
             call rdfdor('dropr',0.0d0,100.0d0,dropr,(mamp*mamte),nmper2)
             call rdfdor('hdepth',-100d0,0.0d0,hdepth,(mamp*mamte),nmper2)

             do i = 1, nmper2
               imper = imper_4e1(i)
               hdepth(i) = -abs(hdepth(i))

   ! ---       determine compartment number related to hdepth
               dep = 0.0d0
               node = 1
               do while (hdepth(i) < (dep-1.0d-6) .AND. node <= numnod) 
                 nodhd(imper) = node
                 dep = dep-dz(node)
                 node = node + 1
               end do

               if (swman(imper) /= 2) call swap_error ('rddre', 'SWMAN - IMPER mismatch.')
               if (imper /= imperb) then
                 imperb = imper
                 imperi = imperi + 1
               else
                 call swap_error ('rddre', 'Two drop rates at the same period.')
               end if
             end do
             if (imperi /= nrman2) call swap_error ('rddre', 'Number of periods for drop rate incorrect.')

   ! ---   part 4e2

             imperb = 0
             imperi = 0

             do imper = 1,nmper
               nphase(imper) = 0
             end do

   ! --      read and store
             call rdainr('imper_4e2',1,nmper,imper_4e2,(mamte*mamp),ifnd)
             call rdfinr('impphase',1,mamte,impphase,(mamte*mamp),ifnd)
             call rdfdor('wlsman',(altcu-500.0d0),altcu,wlsman_t,(mamp*mamte),ifnd)
             call rdfdor('gwlcrit',-500.0d0,0.0d0,gwlcrit_t,(mamp*mamte),ifnd)
             call rdfdor('hcrit',-1000.0d0,0.0d0,hcrit_t,(mamp*mamte),ifnd)
             call rdfdor('vcrit',0.0d0,20.0d0,vcrit_t,(mamp*mamte),ifnd)

   ! ---     convert
             do i = 1, ifnd
               wlsman(imper_4e2(i),impphase(i)) = wlsman_t(i) - Altcu
               gwlcrit(imper_4e2(i),impphase(i)) = gwlcrit_t(i)
               hcrit(imper_4e2(i),impphase(i)) = hcrit_t(i)
               vcrit(imper_4e2(i),impphase(i)) = vcrit_t(i)
             end do

   ! ---     check values
             do i = 1, ifnd
               imper = imper_4e2(i)
               iph = impphase(i)

               nphase(imper) = nphase(imper) + 1
               if (wlsman(imper,iph) < zbotdr(1+nrpri)) call swap_error ('rddre', 'Level of automatic weir below bottom deepest channel of secondary system.')
               if (swman(imper) /= 2) call swap_error ('rddre', 'SWMAN - IMPER mismatch')
               if (imper /= imperb) then
                 imperb = imper
                 imperi = imperi + 1
               end if
             end do

             if (imperi /= nrman2) call swap_error ('rddre', 'Inconsistency between the nr of periods with automatic weir (tabel 4e (IMPER4e2)) and swman in tabel4b (IMPER_4b)')

   ! ---     consistency checks WLSMAN, GWLCRIT, HCRIT and VCRIT
             do imper = 1,nmper
               if (swman(imper) == 2) then
                 if (abs(gwlcrit(imper,1)) > 0.01d0) call swap_error ('rddre', 'gwlcrit(1) must be 0.')
                 if (abs(vcrit(imper,1)) > 0.01d0) call swap_error ('rddre', 'vcrit(1) must be 0.')
                 if (abs(hcrit(imper,1)) > 0.01d0) call swap_error ('rddre', 'hcrit(1) must be 0.')
                 if (hbweir(imper) >  (wlsman(imper,1)-0.99999d0)) call swap_error ('rddre', 'HBWEIR within 1 cm of wlsman(1)')

                 do iph = 2,nphase(imper)
                   if (wlsman(imper,iph) < wlsman(imper,iph-1)) call swap_error ('rddre', 'wlsman inconsistent')
                   if (gwlcrit(imper,iph) > gwlcrit(imper,iph-1)) call swap_error ('rddre', 'gwlcrit inconsistent')
                   if (hcrit(imper,iph) > hcrit(imper,iph-1)) call swap_error ('rddre', 'hcrit inconsistent')
                   if (vcrit(imper,iph) < vcrit(imper,iph-1)) call swap_error ('rddre', 'vcrit inconsistent')
                 end do
               end if
             end do
           end if
         end if
   ! ----------------------------------------------------------------------

   ! --- sttab(i,1) contains depths

   ! --- sw-levels, to be used in piece-wise linear functions (first level)
   ! --- is 100 cm above soil surface to allow for situations with ponding)
         sttab(1,1) = 100.0d0
         sttab(2,1) =   0.0d0
         do i = 3,22
   ! ---   layer between surface level and deepest
   ! ---   drain/channel bottom is divided into 20 compartments
           sttab(i,1) = zbotdr(1+nrpri)*(i-2)/20.0d0
         end do

   ! --- sttab(i,2) contains storage expressed in cm

   ! --- calculation of surface water storage (in cm, i.e. volume
   ! --- per unit area), as a function of sw-level, only for open channels:
         do i = 1,22
           do ilev = 1+nrpri,nrlevs
             if (swdtyp(ilev) == 2 .AND. sttab(i,1) > zbotdr(ilev)) then
   ! ---       for levels above soil surface the volume-increment is
   ! ---       computed for a rectangle, and not a trapezium
               if (sttab(i,1) <= 0.0d0) then
                 wdepth = sttab(i,1)-zbotdr(ilev)
                 wvolum = wdepth*(widthr(ilev)+wdepth/taludr(ilev))
               else
                 wdepth = -zbotdr(ilev)
                 wvolum = wdepth*(widthr(ilev)+wdepth/taludr(ilev))
                 wbreadth = widthr(ilev) + 2*wdepth/taludr(ilev)
                 wdepth = sttab(i,1)
                 wvolum = wvolum + wbreadth*wdepth
               end if
               sttab(i,2) = sttab(i,2)+wvolum/Lspacing(ilev)
             end if
           end do
         end do

   ! --- initial storage
         swst = swstlev(wls)
      
   !     In case of macropores: initialise drainage basis for rapid drainage through macropores
         if (swmacro == 1) then
            if (swdrrap == 1) then
               if (NumLevRapDra > nrlevs) call swap_error ('drainage', 'NUMLEVRAPDRA greater then NRLEVS')
               if (swdtyp(NumLevRapDra) == 1) then
                  ZDraBas = zbotdr(NumLevRapDra)      ! drain tube
               else if (Swsec == 1) then            
                  ZDraBas = afgen (wlstab,2*maowl,t1900) ! open drain, surf.wat. level input
               else if (Swsec == 2) then
                  ZDraBas = WlStar                    ! open drain, srf.wat. level simulated
               end if   
            end if
         end if    

         close (unit_dra)         

         return
         end subroutine read_drainage_extended
   
   
!   end submodule SMOD_drainage_extended

      function swstLEV (wlev)
      !-----------------------------------------------------------------------
      !     Date               : 23/08/99
      !     Purpose            : calculate surface water storage from  
      !                          surface water level
      !     Subroutines called : -
      !     Functions called   : -
      !     File usage         : -
      !     Differences SWAP/SWAPS: None
      ! ----------------------------------------------------------------------
            use MOD_drain, only: sttab
            implicit none
      ! --- global
            real(8), intent(in)  :: wlev
            real(8)              :: swstLEV

      ! --- local
            integer              :: i
            real(8)              :: dwl
      ! ----------------------------------------------------------------------

            if (wlev < sttab(22,1)) call swap_error ('swstlev', 'Surface water storage below bottom of table')
            if (wlev > sttab(1,1))  call swap_error ('swstlev', 'Surface water storage above top of table')

            i = 0
       100  i = i+1
            if (.NOT.(wlev >= sttab(i+1,1) .AND. wlev <= sttab(i,1))) goto 100
            dwl = (wlev - sttab(i+1,1)) / (sttab(i,1) - sttab(i+1,1))
            swstlev = sttab(i+1,2) + dwl * (sttab(i,2) - sttab(i+1,2))

            return
            end function swstLEV
   
