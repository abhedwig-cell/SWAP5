! File VersionID:
!   $Id: watstor.f90 298 2016-07-25 20:07:31Z kroes006 $
! ----------------------------------------------------------------------
      subroutine watstor ()
! ----------------------------------------------------------------------
!     Date               : 29/9/99
!     Purpose            : calc. water storage in the soil profile        
!     Subroutines called : -                                           
!     Functions called   : -                                           
!     File usage         : -                                           
!     Differences SWAP/SWAPS: 
!     - SWAPS: extra parameters
! ----------------------------------------------------------------------
      use MOD_swap_base, only: swmacro
      use MOD_grid,      only: numnod, dz
      use MOD_swap_mp,   only: FrArMtrx
      use variables,     only: volm1,volact,theta
      IMPLICIT NONE

! ----------------------------------------------------------------------
! --- update soil profile water storage
      volm1  = volact
      volact = 0.0d0
      if (swmacro == 0) then
         volact = sum(theta(1:numnod)*dz(1:numnod))
      else
         volact = sum(theta(1:numnod)*dz(1:numnod)*FrArMtrx(1:numnod))
      end if

      return
      end subroutine watstor

!function f_volunsat(gwl, theta, numnod, dz, zbotcp, thetas)
!use variables,   only: swbotb
!use MOD_swap_mp, only: frarmtrx
!implicit none
!! global
!integer,                    intent(in) :: numnod
!real(8),                    intent(in) :: gwl
!real(8), dimension(numnod), intent(in) :: dz, zbotcp
!real(8), dimension(numnod), intent(in) :: theta, thetas
!real(8)                                :: f_volunsat
!! local
!integer                                :: i
!
!f_volunsat = 0.0d0
!if (gwl < 0.0d0) then
!   do i = 1, numnod
!      if (gwl < zbotcp(i)) then
!         ! current compartment is completely unsaturated: add volume of water
!         f_volunsat = f_volunsat + theta(i)*dz(i)*FrArMtrx(i)
!      else
!         ! gwl is located inside current compartment (at most exactly at the bottom, but not exactly at the top)
!         f_volunsat = f_volunsat + (dz(i)*theta(i) - (gwl - zbotcp(i))*thetas(i))*FrArMtrx(i)
!         exit
!      end if
!   end do
!else if (swbotb == 7) then
!   do i = 1, numnod
!      ! current compartment is completely unsaturated: add volume of water
!      f_volunsat = f_volunsat + theta(i)*dz(i)*FrArMtrx(i)
!   end do
!end if
!
!return
!end function f_volunsat
