module MOD_wofost

   use MOD_arrays, only: macroptb, mahrv
   
   implicit none

   ! model parameters
   real(8), parameter :: delt = 1.d0

   logical, save :: fl_tsum                           ! temperature criteria grass

   ! global rates
   real(8), save :: dtsum                             ! increase temperature sum
   real(8), save :: dvr                               ! increase development stage
      
   ! phenology flags
   logical, save :: fl_vernalised
   logical, save :: fl_anthesis
   
   ! type of crop development
   integer, save :: sw_wofost                         ! type of WOFOST crop development: 1 = WOFOST; 2 = WOFOST soybeans; 3 = WOFOST grass
   
   ! running average minimum temperature
   integer, save :: nofd                              ! number of days for running average minimum temperatures (-)
   real(8), dimension (7), save :: atmin7             ! array with minimum temperatures of last week (C)

   ! assimilation
   real(8), save :: daylp                             ! photoperiodic daylength in hours (T)
        
   ! vernalisation
   real(8), save :: vernrate                          ! vernalisation rate
   real(8), save :: vern                              ! vernalisation state

   ! grass
   integer, save :: t_tsumcum                         ! number of days above temperature threshold
   integer, save :: nodtsum                           ! node depth tsum

   ! type for crop specific development stage
   type WOFOST_dvs_param

      ! phenology (wofost)
      integer :: idsl
      real(8) :: dlo
      real(8) :: dlc
      real(8) :: tsumea
      real(8) :: tsumam
      real(8), dimension (macroptb) :: dtsmtb

      ! vernalisation
      real(8) :: verndvs
      real(8) :: vernsat
      real(8) :: vernbase
      real(8), dimension (macroptb) :: vernrtb
   
   end type WOFOST_dvs_param
   type (WOFOST_dvs_param), save :: p_wof
   
   type SOYBEANS_dvs_param

      ! phenology (soybeans)
      real(8) :: mg
      real(8) :: dvrmax1
      real(8) :: dvrmax2
      real(8) :: tmaxdvr
      real(8) :: tmindvr
      real(8) :: toptdvr
      integer :: sw_rfphotoveg
      integer :: sw_phenodayl
      real(8) :: popt
      real(8) :: pcrt   
   
   end type SOYBEANS_dvs_param
   type (SOYBEANS_dvs_param), save :: p_soy
   
   type GRASS_dvs_param

      ! grass
      integer :: sw_tsum
      real(8) :: temptsum
      integer :: t_temptsum
      real(8) :: z_temptsum
   
   end type GRASS_dvs_param
   type (GRASS_dvs_param), save :: p_grs

   ! parameters for all croptypes
   type WOFOST_param

      ! timing of harvest
      integer :: sw_harv
      real(8) :: dvsend

      ! initial
      real(8) :: tdwi
      real(8) :: rgrlai

      ! green area
      real(8) :: spa
      real(8) :: ssa
      real(8) :: span
      real(8) :: tbase
      real(8), dimension (macroptb) :: slatb

      ! assimilation
      real(8) :: eff
      real(8) :: cfrdm
      real(8), dimension (macroptb) :: amaxtb
      real(8), dimension (macroptb) :: tmpftb
      real(8), dimension (macroptb) :: tmnftb

      ! conversion of assimilates into biomass
      real(8) :: cvl
      real(8) :: cvo
      real(8) :: cvr
      real(8) :: cvs

      ! maintenance respiration
      real(8) :: q10
      real(8) :: rml
      real(8) :: rmo
      real(8) :: rmr
      real(8) :: rms
      real(8), dimension (macroptb) :: rfsetb

      ! partitioning
      real(8), dimension (macroptb) :: frtb
      real(8), dimension (macroptb) :: fltb
      real(8), dimension (macroptb) :: fstb
      real(8), dimension (macroptb) :: fotb

      ! death rates
      real(8) :: perdl
      real(8), dimension (macroptb) :: rdrrtb
      real(8), dimension (macroptb) :: rdrstb
      
      ! management factor
      real(8) :: relmf
      integer :: sw_potrelmf
    
   end type WOFOST_param
   type (WOFOST_param), save :: p

   type WOFOST_states

      ! growth
      logical :: fl_potential
      
      integer :: ilv
      real(8), dimension (366) :: sla
      real(8), dimension (366) :: lv
      real(8), dimension (366) :: lvage
      
      real(8) :: wrt
      real(8) :: wst
      real(8) :: wlv
      real(8) :: wso
      
      real(8) :: dwrt
      real(8) :: dwst
      real(8) :: dwlv
      
      ! leaf area index
      real(8) :: lasum
      real(8) :: laiexp
      real(8) :: lai
      
   end type WOFOST_states
   type (WOFOST_states), save :: s_pot, s_act

   type WOFOST_rates

      real(8) :: fr
      real(8) :: fl
      real(8) :: fs
      real(8) :: fo
      
      real(8) :: pgass
      real(8) :: gass
      real(8) :: mres
      
      real(8) :: dmi
      real(8) :: admi
      
      real(8) :: grrt
      real(8) :: grlv
      real(8) :: grst
      real(8) :: grso
      
      real(8) :: fysdel
      real(8) :: dslv
      real(8) :: dalv
      real(8) :: drlv
      real(8) :: drst
      real(8) :: drrt
      
      real(8) :: gwst
      real(8) :: gwrt
      real(8) :: gwso
    
      real(8) :: slat
      real(8) :: glaiex
      real(8) :: gla
      
   end type WOFOST_rates
   type (WOFOST_rates), save :: r_pot, r_act 

   type AGRO_param
      
      integer, dimension (mahrv) :: seqgrzmow
      integer :: sw_harvest
      real(8), dimension (mahrv) :: date_harvest
      
      ! grazing event
      real(8), dimension (macroptb) :: dmgrztb
      integer :: mxgdgrz
      real(8) :: dmrestgrz
      real(8) :: dmrestdew
      
      integer :: daygrz
      real(8) :: uptgrz
      real(8) :: lossgrz
      integer :: sw_lossmow
      real(8) :: z_mow
      real(8), dimension (macroptb) :: lossmowtb
      integer :: sw_lossgrz
      real(8) :: z_grz
      real(8), dimension (macroptb) :: lossgrztb

      ! mowing event
      real(8), dimension (macroptb) :: dmmowtb
      integer :: mxgdmow
      real(8) :: dmrestmow
      real(8), dimension (macroptb) :: delaymowtb

   end type AGRO_param
   type (AGRO_param), save :: p_agro
   
   type AGRO_management
      
      ! growth
      logical :: fl_potential
      
      logical :: fl_mow
      logical :: fl_grz
      logical :: fl_cutend
      
      integer :: icut
      integer :: tcut
      integer :: tdelay
      integer :: tgrz

      real(8) :: dmhrv = 0.d0
      real(8) :: dmloss = 0.d0

   end type AGRO_management
   type (AGRO_management), save :: m_pot, m_act

   private
   
   public :: assimilation, wofost, reset_wofost_states_rates
   public :: wofost_param, wofost_dvs_param, agro_param, grass_dvs_param, p_agro, p_wof, p, p_grs
   public :: wofost_states, agro_management, m_act, m_pot, s_act, s_pot
   public :: sw_wofost
   public :: vern, nodtsum, fl_anthesis, fl_vernalised, t_tsumcum, nofd, atmin7
   
   contains
   
   ! ---------------------------------------------------------------------

   subroutine wofost (task)
    
      use MOD_params, only: nihil
      use MOD_grid, only: zbotcp
      use MOD_integral, only: iqrot_day, iptra_day
      use MOD_swap_base, only: swcropsnm
      use plant_interface, only: icrop, cropend, fl_cropemergence, fl_cropharvest, ipgass, igass, imres, ipgasspot, igasspot, imrespot, dvs
      use MOD_wofost_nut, only: read_wofost_nut, initialize_wofost_nut, demand_wofost_nut, update_wofost_nut, fstr
      use variables, only: t1900, date
      
      implicit none
      
      integer, intent(in)  :: task
      
      integer :: node
      real(8) :: reltr
      character(len=200) :: message
      logical, save :: first_warning = .TRUE.

      select case (task)
      
      case (1)
          
         ! read crop data
         call read_wofost ()
         
         ! read wofost nut
         if (swcropsnm == 1) call read_wofost_nut ()
         
      case (2)  
         
         ! initialize states (wofost)
         s_pot%fl_potential =.TRUE.
         call initialize_wofost (s_pot)
         call update_wofost_interface (s_pot, r_pot)
         
         if (sw_wofost == 3) then
            m_pot%fl_potential = .TRUE.
            call initialize_grass (m_pot)
            call update_grass_interface (m_pot)
         end if
         
         s_act%fl_potential =.FALSE.
         call initialize_wofost (s_act)
         call update_wofost_interface (s_act, r_act)

         if (sw_wofost == 3) then
            m_act%fl_potential =.FALSE.
            call initialize_grass (m_act)
            call update_grass_interface (m_act)
         end if
         
         if (swcropsnm == 1) call initialize_wofost_nut ()

         ! determine compartment for temperature sum
         nodtsum = 0
         if (sw_wofost == 3) then
            if (p_grs%sw_tsum == 2) then
               node = 1
               do 
                  if (zbotcp(node) < (p_grs%z_temptsum + 1.d-8)) exit
                  node = node + 1
               end do
               nodtsum = node
            end if
         end if
         
         ! intermediate variables
         ipgasspot= 0.d0; ipgass= 0.d0
         igasspot = 0.d0; igass = 0.d0
         imrespot = 0.d0; imres = 0.d0  
         
         ! set first warning
         first_warning = .TRUE.
         
      case (3)
      
         ! determine rate development stage
         call update_dvs_rate ()
         
         ! reduction due to stress
         reltr = 1.d0
        
         ! update wofost stats (potential)
         call update_wofost (s_pot, r_pot, m_pot, reltr)
         call update_wofost_interface (s_pot, r_pot)
         
         if (sw_wofost == 3) then
            call update_grass_interface (m_pot)
         end if

         ! water stress reduction of pgass to gass
         if (dabs(iptra_day) < nihil) then
            reltr = 1.d0
         else
            reltr = max(0.d0, min(1.d0, iqrot_day / iptra_day))
         end if
        
         ! nitrogen stress reduction of pgass to gass
         if (swcropsnm == 1) reltr = min(reltr, fstr)

         ! update wofost status (actual)
         call update_wofost (s_act, r_act, m_act, reltr)
         call update_wofost_interface (s_act, r_act)
         
         if (sw_wofost == 3) then
            call update_grass_interface (m_act)
         end if
         
         ! vernalisation state
         if (sw_wofost == 1) then
            if (p_wof%idsl == 2) then
               vern = vern + vernrate
               if (.NOT. fl_vernalised .AND. vern >= p_wof%vernsat) then
                  fl_vernalised = .TRUE.
               else
                  if (fl_vernalised .AND. vern < p_wof%vernsat .AND. first_warning) then
                     message = 'Critical DVS for vernalisation reached at '//trim(date)//' but requirements not yet fulfilled, forcing vernalisation now'
                     call swap_warning ('wofost', message)
                     first_warning = .false.
                  end if
               end if
            end if
         end if

         ! total n demand
         if (swcropsnm == 1) call demand_wofost_nut(reltr)
         
      case (4)
         
         ! check end of cropping period
         if (p%sw_harv == 0) then
            if (dabs(t1900 - cropend(icrop) - 1.d0) < 0.1d0) then
               fl_cropemergence = .FALSE.
               fl_cropharvest = .TRUE.
            end if
         else
            if (sw_wofost == 1 .OR. sw_wofost == 2) then
               if (dvs >= p%dvsend .OR. dabs(t1900 - cropend(icrop) - 1.d0) < 0.1d0) then
                  fl_cropemergence = .FALSE.
                  fl_cropharvest = .TRUE.
               end if
            end if
         end if
         
         ! update wofost nut
         if (swcropsnm == 1) call update_wofost_nut()
         
      case (9)

         ! write end-status
         call write_wofost (s_pot)
         call write_wofost (s_act)

      case default
      
         call fatalerr ('wofost', 'Illegal value for iTask')
         
      end select

      return

   end subroutine wofost
   
   ! ---------------------------------------------------------------------

   subroutine read_wofost ()

      ! ------------------------------------------------------------------

      use MOD_swap_base, only: unit_err
      use plant_interface, only: unit_crp, crpfilnam, kdif, kdir
      
      implicit none

      logical :: rdinqr
      logical :: fl_grz, fl_mow, fl_dew
      integer :: i, ifnd, n_seqgrzmow

      ! ------------------------------------------------------------------

      ! open connection
      call rdinit(unit_crp, unit_err, crpfilnam)
      
      ! type of WOFOST crop development
      sw_wofost = 1
      if (rdinqr('swwofost')) call rdsinr ('swwofost', 1, 3, sw_wofost)
      
      ! phenology for WOFOST crops:
      if (sw_wofost == 1) then

         ! idsl = Switch for crop development before anthesis: 
         !        0 depends on temperature; 
         !        1 depends on temperature and day length; 
         !        2 depends on temperature, day length and vernalisation factor
         call rdsinr ('idsl', 0, 2, p_wof%idsl)
         if (p_wof%idsl == 1 .OR. p_wof%idsl == 2) then
           call rdsdor ('dlo', 0.d0, 24.d0, p_wof%dlo)
           call rdsdor ('dlc', 0.d0, 24.d0, p_wof%dlc)
         end if
         call rdsdor ('tsumea', 0.d0, 10000.d0, p_wof%tsumea)
         call rdsdor ('tsumam', 0.d0, 10000.d0, p_wof%tsumam)
         
         call rdadortb ('dtsmtb',0.d0, 60.d0, -10.d0, 100.d0, p_wof%dtsmtb, macroptb, .FALSE.)

         ! vernalisation
         if (p_wof%idsl == 2) then
            call rdsdor ('verndvs', 0.d0, 0.4d0, p_wof%verndvs)
            call rdsdor ('vernsat', 0.d0, 200.d0, p_wof%vernsat)
            call rdsdor ('vernbase', 0.d0, 200.d0, p_wof%vernbase)

            call rdadortb ('vernrtb', -10.d0, 100.d0, 0.d0, 1.d0, p_wof%vernrtb, macroptb, .FALSE.)
         end if
            

      ! phenology for WOFOST soybean crops
      else if (sw_wofost == 2) then

         call rdsdor ('mg', 0.1d0, 9.d0, p_soy%mg)
         call rdsdor ('dvrmax1', 0.d0, 1.d0, p_soy%dvrmax1)
         call rdsdor ('dvrmax2', 0.d0, 1.d0, p_soy%dvrmax2)
         call rdsdor ('tmaxdvr', 0.d0, 45.d0, p_soy%tmaxdvr)
         call rdsdor ('tmindvr', 0.d0, p_soy%tmaxdvr, p_soy%tmindvr)
         call rdsdor ('toptdvr', p_soy%tmindvr, p_soy%tmaxdvr, p_soy%toptdvr)

         p_soy%sw_rfphotoveg = 1
         if (rdinqr('swrfphotoveg')) call rdsinr ('swrfphotoveg', 0, 1, p_soy%sw_rfphotoveg)

         p_soy%sw_phenodayl = 0
         if (rdinqr('swphenodayl')) then
            call rdsinr ('swphenodayl', 0, 1, p_soy%sw_phenodayl)
            if (p_soy%sw_phenodayl == 1) then
               call rdsdor ('popt', 0.d0, 24.d0, p_soy%popt)
               call rdsdor ('pcrt', 0.d0, 24.d0, p_soy%pcrt)
            end if
         end if
            
      ! phenology for WOFOST grass
      else if (sw_wofost == 3) then
         
         call rdsinr ('swtsum', 0, 2, p_grs%sw_tsum)
         
         if (p_grs%sw_tsum == 2) then
           call rdsdor ('temptsum', 0.d0, 20.d0, p_grs%temptsum)
           call rdsdor ('ztemptsum', -100.d0, 0.d0, p_grs%z_temptsum)
           call rdsinr ('ttemptsum', 1, 20, p_grs%t_temptsum)
         end if

      end if

      ! end of cropping period
      if (sw_wofost == 1 .OR. sw_wofost == 2) then
         
         ! timing of harvest
         if (rdinqr('swharv')) then
            call rdsinr ('swharv', 0, 1, p%sw_harv)
         else
            p%sw_harv  = 0   
         end if

         call rdsdor ('dvsend', 0.d0, 3.d0, p%dvsend)

      else
         p%sw_harv = 0
         p%dvsend = 2.d0
      end if
      
      ! initial
      call rdsdor ('tdwi', 0.d0, 10000.d0, p%tdwi)
      call rdsdor ('rgrlai', 0.d0, 1.d0, p%rgrlai)

      ! green area
      call rdsdor ('spa', 0.d0, 1.d0, p%spa)
      call rdsdor ('ssa', 0.d0, 1.d0, p%ssa)
      call rdsdor ('span', 0.d0, 366.d0, p%span)
      call rdsdor ('tbase', -10.d0, 30.d0, p%tbase)
      
      call rdadortb ('slatb',0.d0, 3.d0, 0.d0, 1.d0, p%slatb, macroptb, .FALSE.)

      ! assimilation
      call rdsdor ('kdif', 0.d0, 2.d0, kdif)
      call rdsdor ('kdir', 0.d0, 2.d0, kdir)
      call rdsdor ('eff', 0.d0, 10.d0, p%eff)
      p%cfrdm = 0.4d0
      if (rdinqr('cfrdm')) call rdsdor ('cfrdm', 0.d0, 1.d0, p%cfrdm)
      
      call rdadortb ('amaxtb', 0.d0, 3.d0, 0.d0, 100.d0, p%amaxtb, macroptb, .FALSE.)
      call rdadortb ('tmpftb', -10.d0, 50.d0, 0.d0, 1.d0, p%tmpftb, macroptb, .FALSE.)
      call rdadortb ('tmnftb', -10.d0, 50.d0, 0.d0, 1.d0, p%tmnftb, macroptb, .FALSE.)

      ! conversion of assimilates into biomass
      call rdsdor ('cvr', 0.d0, 1.d0, p%cvr)
      call rdsdor ('cvs', 0.d0, 1.d0, p%cvs)
      call rdsdor ('cvl', 0.d0, 1.d0, p%cvl)
      call rdsdor ('cvo', 0.d0, 1.d0, p%cvo)

      ! maintenance respiration
      call rdsdor ('q10', 0.d0, 5.d0, p%q10)
      call rdsdor ('rml', 0.d0, 1.d0, p%rml)
      call rdsdor ('rmo', 0.d0, 1.d0, p%rmo)
      call rdsdor ('rmr', 0.d0, 1.d0, p%rmr)
      call rdsdor ('rms', 0.d0, 1.d0, p%rms)
      
      call rdadortb ('rfsetb', 0.d0, 3.d0, 0.d0, 1.d0, p%rfsetb, macroptb, .FALSE.)

      ! partitioning
      call rdadortb ('frtb', 0.d0, 3.d0, 0.d0, 1.d0, p%frtb, macroptb, .FALSE.)
      call rdadortb ('fltb', 0.d0, 3.d0, 0.d0, 1.d0, p%fltb, macroptb, .FALSE.)
      call rdadortb ('fstb', 0.d0, 3.d0, 0.d0, 1.d0, p%fstb, macroptb, .FALSE.)
      call rdadortb ('fotb', 0.d0, 3.d0, 0.d0, 1.d0, p%fotb, macroptb, .FALSE.)

      ! death rates
      call rdsdor ('perdl', 0.d0, 3.d0, p%perdl)

      call rdadortb ('rdrrtb', 0.d0, 3.d0, 0.d0, 1.d0, p%rdrrtb, macroptb, .FALSE.)
      call rdadortb ('rdrstb', 0.d0, 3.d0, 0.d0, 1.d0, p%rdrstb, macroptb, .FALSE.)

      ! switch to account for difference between theoretical potential and attainable yield
      p%sw_potrelmf = 1
      if(rdinqr('swpotrelmf')) call rdsinr ('swpotrelmf', 1, 2, p%sw_potrelmf)

      p%relmf = 1.d0
      if(rdinqr('relmf')) call rdsdor ('relmf', 0.d0, 1.d0, p%relmf)
      
      ! management of grassland
      if (sw_wofost == 3) then
         
         ! read yearly sequence of mowing and grazing events (1=grazing, 2=mowing, 3=grazing with dewooling)
         p_agro%seqgrzmow(:) = 0
         call rdainr ('seqgrzmow', 1, 3, p_agro%seqgrzmow, mahrv, ifnd)
         n_seqgrzmow = ifnd
         
         ! trigger of harvest
         call rdsinr ('swharvest', 1, 2, p_agro%sw_harvest)

         ! determine type of harvest present
         fl_grz = .FALSE.; fl_mow = .FALSE.; fl_dew = .FALSE.
         do i = 1, macroptb
            if (p_agro%seqgrzmow(i) == 0) exit
            if (p_agro%seqgrzmow(i) == 1) then
               fl_grz = .TRUE.
            else if (p_agro%seqgrzmow(i) == 2) then
               fl_mow = .TRUE. 
            else if (p_agro%seqgrzmow(i) == 3) then
               fl_grz = .TRUE.; fl_dew = .TRUE.
            end if
         end do

         ! event triggered by biomass
         if (p_agro%sw_harvest == 1) then

            if (fl_grz) then

               ! dry matter threshold for grazing
               call rdadortb ('dmgrztb',0.d0, 366.d0, 0.d0, 30000.d0, p_agro%dmgrztb, macroptb, .FALSE.)

               ! maximum duration (after first event)
               call rdsinr ('mxgdgrz', 1, 366, p_agro%mxgdgrz)

            end if
            
            if (fl_mow) then
               
               ! dry matter threshold for mowing
               call rdadortb ('dmmowtb',0.d0, 366.d0, 0.d0, 30000.d0, p_agro%dmmowtb, macroptb, .FALSE.)
               
               ! maximum duration
               call rdsinr ('mxgdmow', 1, 366, p_agro%mxgdmow)

            end if

         ! event triggered by date 
         else
            
           p_agro%date_harvest(:) = 0.d0
           call rdatim ('dateharvest', p_agro%date_harvest, mahrv, ifnd)
           if (ifnd /= n_seqgrzmow) call swap_error('read_wofost', 'Number of harvest dates (DATEHARVEST) should be equal to length sequence harvest types (SEQGRZMOW)')

         end if
         
         ! in case of grazing
         if (fl_grz) then
            
            ! remaining amount
            call rdsdor ('dmrestgrz', 0.d0, 5000.d0, p_agro%dmrestgrz)
            if (fl_dew) call rdsdor ('dmrestdew', 0.d0, 5000.d0, p_agro%dmrestdew)
            
            ! grazing settings
            call rdsinr ('daygrz', 1, 366, p_agro%daygrz)
            call rdsdor ('uptgrz', 0.d0, 2500.d0, p_agro%uptgrz)
            call rdsdor ('lossgrz', 0.d0, 2500.d0, p_agro%lossgrz)

            ! extra losses due to treading
            p_agro%sw_lossgrz = 0
            if (rdinqr('swlossgrz')) then
               call rdsinr ('swlossgrz', 0, 1, p_agro%sw_lossgrz)
               if (p_agro%sw_lossgrz == 1) then
                  call rdsdor ('zgrz', -100.d0, 0.d0, p_agro%z_grz)
                  call rdadortb ('lossgrztb', -1000.d0, 0.d0, 0.d0, 1.d0, p_agro%lossgrztb, macroptb, .FALSE.)
               end if
            end if

         end if
         
         ! in case of mowing
         if (fl_mow) then
            
            ! remaining amount
            call rdsdor ('dmrestmow', 0.d0, 5000.d0, p_agro%dmrestmow)
            
            ! extra losses due to workability
            p_agro%sw_lossmow = 0
            if (rdinqr('swlossmow')) then
               call rdsinr ('swlossmow', 0, 1, p_agro%sw_lossmow)
               if (p_agro%sw_lossmow == 1) then
                  call rdsdor ('zmow', -100.d0, 0.d0, p_agro%z_mow)
                  call rdadortb ('lossmowtb', -1000.d0, 0.d0, 0.d0, 1.d0, p_agro%lossmowtb, macroptb, .FALSE.)
               end if
            end if

            ! delay after mowing event
            call rdadortb ('delaymowtb',0.d0, 30000.d0, 0.d0, 366.d0, p_agro%delaymowtb, macroptb, .FALSE.)
         end if

      end if

      close (unit_crp)

      return

   end subroutine read_wofost

   ! ---------------------------------------------------------------------
    
   subroutine initialize_wofost (s)

      ! ------------------------------------------------------------------
      use plant_interface, only: fl_start_cropemergence, dvs, tsum
   
      implicit none
      type (WOFOST_states), intent(inout) :: s
      
      ! local
      real(8) :: fr, fs, fl, fo, tadw
      
      ! functions
      real(8) :: afgen

      ! ------------------------------------------------------------------
      
      if (fl_start_cropemergence) then
         
         ! running average low temperature 
         nofd = 0
         atmin7 = 0.d0

         ! phenology
         dvs = 0.d0
         tsum = 0.d0
         fl_anthesis = .FALSE.
      
         ! vernalisation
         vern = 0.d0
         fl_vernalised = .FALSE.
         
         ! specific leaf area
         s%sla(1) = afgen (p%slatb, macroptb, dvs)
         s%ilv = 1
         s%lvage(1) = 0.0d0
      
         ! biomass
         fr = afgen (p%frtb, macroptb, dvs)
         fl = afgen (p%fltb, macroptb, dvs)
         fs = afgen (p%fstb, macroptb, dvs)
         fo = afgen (p%fotb, macroptb, dvs)
         
         s%wrt = fr * p%tdwi
         tadw = (1.0d0 - fr) * p%tdwi
         s%wst = fs * tadw
         s%wlv = fl * tadw
         s%wso = fo * tadw

         s%dwrt = 0.d0
         s%dwst = 0.d0
         s%dwlv = 0.d0
         
         ! leaf area index
         s%lasum = s%wlv * s%sla(1)

         s%lv(1) = s%wlv
         s%laiexp = s%lasum
         s%lai = s%lasum + p%ssa * s%wst + p%spa * s%wso
         
      end if

      return

   end subroutine initialize_wofost
   
   ! ---------------------------------------------------------------------
    
   subroutine initialize_grass (m)

      ! ------------------------------------------------------------------
      use plant_interface, only: fl_start_cropemergence
      use variables, only: t1900
   
      implicit none
      type (AGRO_management), intent(inout) :: m
      
      ! ------------------------------------------------------------------
      
      if (fl_start_cropemergence) then
         ! grass
         t_tsumcum = 0
            
         ! management
         m%fl_grz = .FALSE.
         m%fl_cutend = .FALSE.

         m%icut = 1
         if (p_agro%sw_harvest == 2) then
            do while (t1900 > p_agro%date_harvest(m%icut))
               m%icut = m%icut + 1
               if (p_agro%date_harvest(m%icut) < 1.d0) exit
            end do
         end if
         
         m%tcut = 0
         m%tdelay = 0
         m%tgrz = 0
         
      end if
         
      ! initialize harvest
      m%dmhrv = 0.d0
      m%dmloss = 0.d0

      ! management
      m%fl_mow = .FALSE.

      return

   end subroutine initialize_grass

! ------------------------------------------------------------------------

   subroutine update_dvs_rate ()

      ! ------------------------------------------------------------------
      
      use atmosphere_interface, only: tav
      use plant_interface, only: dvs, tsum
      use MOD_SoilTemperature, only : tsoil

      implicit none

      ! local
      real(8) :: dvred
      real(8) :: vernfac

      ! functions
      real(8) :: afgen
      
      ! ------------------------------------------------------------------
      
      ! - rates of change of the crop variables -

      ! phenological development rate for WOFOST crops
      if (sw_wofost == 1) then

         ! increase in temperature sum
         dtsum = afgen (p_wof%dtsmtb, macroptb, tav)
        
         ! increase in development stage
         if (dvs < 1.d0) then
          
            ! vegetative phase
            dvred = 1.d0
            if (p_wof%idsl >= 1) then
               dvred = max(0.d0, min(1.d0, (daylp - p_wof%dlc) / (p_wof%dlo - p_wof%dlc)))
            end if
          
            ! vernalisation rate, based on routines from pyWofost (A. de Wit, 2015)
            vernfac = 1.d0
            if (p_wof%idsl == 2) then
               if (.NOT. fl_vernalised) then
                  vernrate = 0.d0      
                  if (dvs < p_wof%verndvs) then
                     vernrate = afgen (p_wof%vernrtb, macroptb, tav)
                     vernfac = max(0.0d0, min(1.0d0, (vern - p_wof%vernbase) / (p_wof%vernsat - p_wof%vernbase)))
                  else
                     fl_vernalised = .TRUE.
                  end if
               end if
            end if
          
            dvr = vernfac * dvred * dtsum / p_wof%tsumea
        
         else
          
            ! generative phase
            dvr = dtsum / p_wof%tsumam
        
         end if

      ! phenological development rate for WOFOST soybean crops
      else if (sw_wofost == 2) then

         ! increase in temperature sum
         dtsum = max (0.d0, tav)
            
         ! increase in development stage
         if (dvs < 1.d0) then 
            
            ! vegetative phase
            if (p_soy%sw_rfphotoveg == 1) then
               dvr = p_soy%dvrmax1 * rfmgphotop() * rfmgtemp()
            else
               dvr = p_soy%dvrmax1 * rfmgtemp()
            end if
            
         else
            
            ! generative phase
            dvr = p_soy%dvrmax2 * rfmgphotop() * rfmgtemp()
            
         end if
      
      ! phenological development rate for WOFOST grass
      else if (sw_wofost == 3) then
         
         ! increase in temperature sum
         dtsum = max (0.d0, tav)
         
         ! increase in development stage
         dvr = 2.d0 / 366.d0
         
         ! check if crop development should be updated (grass)
         fl_tsum = .FALSE.
         if (p_grs%sw_tsum == 1) then
            if (tsum + dtsum >= 200.d0) fl_tsum = .TRUE.
         elseif (p_grs%sw_tsum == 2) then
            if (tsoil(nodtsum) - p_grs%temptsum >= 0.d0) t_tsumcum = t_tsumcum + 1
            if (t_tsumcum >= p_grs%t_temptsum) fl_tsum = .TRUE.
         else
           fl_tsum = .TRUE.
         end if
         
      end if
      
      ! adjust development stage for realistic TSUM
      if (sw_wofost == 1 .OR. sw_wofost == 2) then
         if (dvs + dvr >= 1.d0 .AND. .NOT. fl_anthesis) then
            fl_anthesis = .TRUE.
            dvr = 1.d0 - dvs
         end if
      end if

   end subroutine update_dvs_rate
   
! ------------------------------------------------------------------------

   subroutine update_wofost (s, r, m, reltr)

      ! ------------------------------------------------------------------
      
      use MOD_swap_base,  only: swcropsnm   
      use atmosphere_interface, only: tav
      use plant_interface, only: dvs, tsum, swrd, aeratecrit, swwrtnonox, wrtmax
      use MOD_integral, only: ialpwet_day
      use MOD_wofost_nut, only: nni, nsla

      implicit none

      ! global
      type (WOFOST_states), intent(inout)   :: s
      type (WOFOST_rates), intent(inout)    :: r
      type (AGRO_management), intent(inout) :: m
      real(8), intent(in) :: reltr

      ! local
      logical :: fl_continue
      real(8) :: rmres, teff, asrc
      real(8) :: cvf, help
      
      ! functions
      real(8) :: afgen
      
      ! ------------------------------------------------------------------

      ! check update crop development
      fl_continue = .TRUE.
      if (sw_wofost == 3) then
         m%tdelay = max(0, m%tdelay - 1)
         if (.NOT. fl_tsum .OR. m%tdelay > 0) fl_continue = .FALSE.
      end if
      
      ! update crop development
      if (fl_continue) then
      
         ! - daily dry matter production -
      
         r%gass = r%pgass * reltr

         ! respiration and partitioning of carbohydrates between growth and maintenance respiration
         rmres = (p%rmr*s%wrt + p%rml*s%wlv + p%rms*s%wst + p%rmo*s%wso) * afgen (p%rfsetb, macroptb, dvs)

         teff = p%q10**((tav - 25.d0) / 10.d0)
         r%mres = min(r%gass, rmres * teff)
         asrc = r%gass - r%mres

         ! partitioning factors
         r%fr = afgen (p%frtb, macroptb, dvs)
         r%fl = afgen (p%fltb, macroptb, dvs)
         r%fs = afgen (p%fstb, macroptb, dvs)
         r%fo = afgen (p%fotb, macroptb, dvs)

         ! check on partitioning
         call chckprt(r)

         ! partitioning correction as influenced by water and N stress
         if (.NOT. s%fl_potential .AND. swcropsnm == 1) call subpar (r, reltr)

         ! conversion factor
         help = 0.d0; if (p%cvo > 0.d0) help = r%fo / p%cvo
         cvf = 1.d0 / ((r%fl / p%cvl + r%fs / p%cvs + help) * (1.d0 - r%fr) + r%fr / p%cvr)
      
         ! dry matter increase
         r%dmi = cvf * asrc

         ! check on carbon balance
         call chckcbl(r, cvf)

         ! - growth rate by plant organ -

         ! growth rate roots and aerial parts
         call relgrwt(r)

         ! death of leaves due to water stress or high lai or nitrogen stress
         call deaths(s, r, reltr)

         ! death of leaves due to exceeding life span:
         call deatha(s, r)

         ! death rate leaves as result of death due to water stress or high lai and death due to exceeding life span
         r%drlv = r%dslv + r%dalv

         ! death rate stems
         r%drst = s%wst * afgen (p%rdrstb, macroptb, dvs)

         ! stop root growth in case oxgenstress exceeds aeratecrit (SWRD=3)
         if (.NOT. s%fl_potential .AND. swrd == 3 .AND. swwrtnonox == 1) then
            if (ialpwet_day < aeratecrit) r%grrt = 0.d0
         end if      
      
         ! after reaching maximum live weight, the growth of the roots is balanced by the death of root tissue (SWRD=3)
         if (swrd == 3 .AND. s%wrt > wrtmax) then
            r%drrt = max(r%grrt, s%wrt * afgen (p%rdrrtb, macroptb, dvs))
         else  
            r%drrt = s%wrt * afgen (p%rdrrtb, macroptb, dvs)
         end if
      
         ! - net growth rate stems, roots, storage organs -
      
         r%gwst = r%grst - r%drst
         r%gwrt = r%grrt - r%drrt
         r%gwso = r%grso
      
         ! - management grassland -
         
         fl_continue = .TRUE.
         if (sw_wofost == 3) call management_event (s, r, m, fl_continue)
         
         ! continue if no mowing event
         if (fl_continue) then
         
            ! physiologic ageing of leaves per time step
            r%fysdel = max (0.0d0, (tav - p%tbase) / (35.d0 - p%tbase))
      
            ! specific leaf area valid for current timestep
            if (.NOT. s%fl_potential .AND. swcropsnm == 1) then
               r%slat = afgen(p%slatb, macroptb, dvs) * exp(-1.d0 * nsla * (1.d0 - nni))
            else
               r%slat = afgen(p%slatb, macroptb, dvs)
            end if

            ! leaf area not to exceed exponential growth curve
            call glai (s, r, reltr)
   
            ! - UPDATE STATES: integrals of the crop -

            ! leaf death (due to water stress or high lai) is imposed on array 
            ! untill no more leaves have to die or all leaves are gone
            call lvdth(s, r, delt)

            ! shifting of contents, updating of physiological age
            call lvshft(s, r, delt)
   
            ! calculation of new leaf area and weight
            call lvwgli(s)

            ! leaf area index in case of exponential growth
            s%laiexp = s%laiexp + r%glaiex * delt
      
         end if
         
         ! dry weight of living plant organs
         s%wrt = s%wrt + r%gwrt * delt
         s%wst = s%wst + r%gwst * delt
         s%wso = s%wso + r%gwso * delt

         ! dry weight of dead plant organs (roots,leaves & stems)
         s%dwrt = s%dwrt + r%drrt * delt
         s%dwlv = s%dwlv + r%drlv * delt
         s%dwst = s%dwst + r%drst * delt

         ! leaf area index
         s%lai = s%lasum + p%ssa * s%wst + p%spa * s%wso
      
      else
         r%gass = 0.0d0
         r%mres = 0.0d0
         r%grrt = 0.0d0
      end if
      
      ! update development stage
      if (.NOT. s%fl_potential) then
         ! update temperature sum
         tsum = tsum + dtsum * delt
         
         ! phenological development stage
         dvs = min(dvs + dvr * delt, p%dvsend)
      end if
      
      return

   end subroutine update_wofost
   
   ! ---------------------------------------------------------------------

   subroutine write_wofost (s)
      
      ! ------------------------------------------------------------------

      use MOD_swap_base, only: iun_min, iun_max, pathwork, sw_end
      use plant_interface, only: icrop, cropfil, dvs, tsum
      use variables, only: outfil, t1900
      
      implicit none
      
      type (WOFOST_states), intent(in) :: s
      
      ! local
      integer :: fin, sw_value, i
      character(len=300) :: filnam
      character(len=10) :: date
      character(len=20) :: form_rea_E1

      ! functions
      integer :: getun
      
      ! ------------------------------------------------------------------

      ! format output
      form_rea_E1 = 'e22.14'
   
      ! re-open output file for final crop status
      if (sw_end == 1) then
         filnam = trim(pathwork) // trim(outfil) // '.end'
      else
         call dtdpst ('year-month-day',t1900 - 0.5d0, date)
         filnam = trim(pathwork) // trim(outfil) // '_' // date(1:4) // date(6:7) // date(9:10) // '.end'
      end if
      fin = getun (iun_min, iun_max)
      open(unit=fin, file=filnam, status="old", position = "append", action="write")
      !call fopens(fin, filnam, 'old', ' ')
      
      if (s%fl_potential) then
         
         write(fin,'(/,"* Crop growth data of last crop: ", a)') trim(cropfil(icrop))

         write(fin,'(/,"* Weather data")')
         write(fin,'("* Minimum temperatures of last week")')
         write(fin,'(" nofd = ", i4)') nofd
         write(fin,'(" atmin7 = ", 7'// form_rea_E1 // ')') atmin7(1:7)
         
         write(fin,'(/,"* Phenology")')
         
         write(fin,'(" dvs = ", ' // form_rea_E1 // ')') dvs
         write(fin,'(" tsum = ", ' // form_rea_E1 // ')') tsum
                  
         if (fl_anthesis) then
            sw_value = 1
         else
            sw_value = 0
         end if
         write(fin,'(" fl_anthesis = ", i4)') sw_value

         if (fl_vernalised) then
            sw_value = 1
         else
            sw_value = 0
         end if
         write(fin,'(" fl_vernalised = ", i4)') sw_value
         write(fin,'(" vern = ", ' // form_rea_E1 // ')') vern

         write(fin,'(/,"* WOFOST potential development")')

         write(fin,'(" wrtpot = ",' // form_rea_E1 // ')') s%wrt
         write(fin,'(" wstpot = ",' // form_rea_E1 // ')') s%wst
         write(fin,'(" wlvpot = ",' // form_rea_E1 // ')') s%wlv
         write(fin,'(" wsopot = ",' // form_rea_E1 // ')') s%wso

         write(fin,'(" dwrtpot = ",' // form_rea_E1 // ')') s%dwrt
         write(fin,'(" dwstpot = ",' // form_rea_E1 // ')') s%dwst
         write(fin,'(" dwlvpot = ",' // form_rea_E1 // ')') s%dwlv

         write(fin,'(" laiexppot = ",' // form_rea_E1 // ')') s%laiexp
         write(fin,'(" laipot = ",' // form_rea_E1 // ')') s%lai
         write(fin,'(" ilvpot = ",i4)') s%ilv

         write(fin,'(/," slapot                lvagepot              lvpot")')
         do i = 1, s%ilv
            write (fin,'(3'// form_rea_E1 // ')')  s%sla(i), s%lvage(i), s%lv(i)
         end do

      else

         write(fin,'(/,"* WOFOST actual development")')

         write(fin,'(" wrt = ",' // form_rea_E1 // ')') s%wrt
         write(fin,'(" wst = ",' // form_rea_E1 // ')') s%wst
         write(fin,'(" wlv = ",' // form_rea_E1 // ')') s%wlv
         write(fin,'(" wso = ",' // form_rea_E1 // ')') s%wso

         write(fin,'(" dwrt = ",' // form_rea_E1 // ')') s%dwrt
         write(fin,'(" dwst = ",' // form_rea_E1 // ')') s%dwst
         write(fin,'(" dwlv = ",' // form_rea_E1 // ')') s%dwlv

         write(fin,'(" laiexp = ",' // form_rea_E1 // ')') s%laiexp
         write(fin,'(" lai = ",' // form_rea_E1 // ')') s%lai
         write(fin,'(" ilv = ", i4)') s%ilv

         write(fin,'(/," sla                   lvage                 lv")')
         do i = 1, s%ilv
            write (fin,'(3' // form_rea_E1 // ')')  s%sla(i), s%lvage(i), s%lv(i)
         end do

      end if

      ! close connection
      close(fin)
      
      return

   end subroutine write_wofost

   ! ---------------------------------------------------------------------
   
   subroutine update_wofost_interface (s, r)
      ! ------------------------------------------------------------------
      use plant_interface, only: lai, wrt, wst, wlv, wso, dwrt, dwst, dwlv, grrt, drrt, drlv, drst, ipgass, igass, imres, &
                                 laipot, wrtpot, wstpot, wlvpot, wsopot, dwrtpot, dwstpot, dwlvpot, grrtpot, ipgasspot, igasspot, imrespot
      
      implicit none
      
      ! global
      type (WOFOST_states), intent(in) :: s
      type (WOFOST_rates), intent(in) :: r
      
      ! ------------------------------------------------------------------
      
      ! potential crop status
      if (s%fl_potential) then
         
         laipot = s%lai
         
         dwrtpot = s%dwrt
         dwstpot = s%dwst
         dwlvpot = s%dwlv
         
         wrtpot = s%wrt
         wstpot = s%wst
         wlvpot = s%wlv
         wsopot = s%wso
         
         grrtpot = r%grrt ! rate; not for output
         
         ipgasspot= ipgasspot+ r%pgass
         igasspot = igasspot + r%gass
         imrespot = imrespot + r%mres

      ! actual crop status
      else

         lai = s%lai
         
         grrt = r%grrt ! rate; not for output
         
         drrt = r%drrt ! rate; not for output
         drst = r%drst ! rate; not for output
         drlv = r%drlv ! rate; not for output
         
         dwrt = s%dwrt
         dwst = s%dwst
         dwlv = s%dwlv
         
         wrt = s%wrt
         wst = s%wst
         wlv = s%wlv
         wso = s%wso
                  
         ipgass= ipgass+ r%pgass
         igass = igass + r%gass
         imres = imres + r%mres

      end if

      return

   end subroutine update_wofost_interface

   ! ---------------------------------------------------------------------

   subroutine update_grass_interface (m)
      ! ------------------------------------------------------------------
      use plant_interface, only: icut, tcut, dmhrv, dmloss, icutpot, tcutpot, dmhrvpot, dmlosspot

      implicit none
      
      ! global
      type (AGRO_management), intent(inout) :: m
      
      ! ------------------------------------------------------------------
      
      ! potential crop status
      if (m%fl_potential) then
         
         dmhrvpot = dmhrvpot + m%dmhrv
         dmlosspot = dmlosspot + m%dmloss
         icutpot = m%icut
         tcutpot = m%tcut
         
      ! actual crop status
      else

         dmhrv = dmhrv + m%dmhrv
         dmloss = dmloss + m%dmloss

         icut = m%icut
         tcut = m%tcut

      end if
      
      ! reset harvest event
      if (m%fl_cutend) then
         
         m%fl_mow = .FALSE.
         m%fl_grz = .FALSE.
         m%fl_cutend = .FALSE.
         
         m%icut = m%icut + 1
         m%tcut = 0
         m%tgrz = 0

      end if

      ! reset harvest
      m%dmhrv = 0.d0
      m%dmloss = 0.d0
      
      return

   end subroutine update_grass_interface

   ! ---------------------------------------------------------------------

   subroutine assimilation
   
      ! ------------------------------------------------------------------
   
      use MOD_swap_base, only: swcropsnm   
      use atmosphere_interface, only: tav
      use plant_interface, only: dvs, fco2eff, fco2amax, sw_oxygen, max_resp_factor, q10_root, c_mroot, f_senes 
      use MOD_meteo, only: tmn, tavd, astro
      use MOD_wofost_nut, only: nutrie
      use variables, only: daynr

      implicit  none
   
      real(8) :: tmnr
      real(8) :: difpp, dsinbe
      real(8) :: dayl, cosld, sinld
      real(8) :: effc, amax
      real(8) :: dtgapot, dtga
      real(8) :: rmres, teff, mres, asrc, cvf, help, froots, rg_roots, rm_roots
      real(8) :: fr, fs, fl, fo
   
      ! functions
      real(8) :: afgen
      
      ! ------------------------------------------------------------------
   
      ! set running average of minimum temperature (only for detailed crop growth)
      nofd = min(nofd + 1, 7)
      atmin7(2:7) = atmin7(1:6); atmin7(1) = tmn
      tmnr = sum(atmin7(1:7)) / nofd
   
      ! phenological development rate 
      call astro (daynr, dayl=dayl, daylp=daylp, sinld=sinld, cosld=cosld, difpp=difpp, dsinbe=dsinbe)

      ! daily gross assimilation
      effc = fco2eff * p%eff
      amax = fco2amax * afgen (p%amaxtb, macroptb, dvs) * afgen (p%tmpftb, macroptb, tavd)

      ! potential assimilation
      call totass (dayl, amax, effc, s_pot%lai, difpp, dsinbe, sinld, cosld, dtgapot)

      ! correction for low minimum temperature
      dtgapot = dtgapot * afgen (p%tmnftb, macroptb, tmnr)

      ! potential assimilation in kg ch2o per ha, corrected for carbon fraction
      r_pot%pgass = dtgapot * 30.d0 * (0.4d0 / p%cfrdm) / 44.d0
      if (p%sw_potrelmf == 2) r_pot%pgass = r_pot%pgass * p%relmf

      ! actual assimilation
      call totass (dayl, amax, effc, s_act%lai, difpp, dsinbe, sinld, cosld, dtga)

      ! correction for low minimum temperature
      dtga = dtga * afgen (p%tmnftb, macroptb, tmnr)
      
      ! actual assimilation in kg ch2o per ha, corrected for carbon fraction
      r_act%pgass = dtga * 30.d0 * (0.4d0 / p%cfrdm)/ 44.d0
      r_act%pgass = r_act%pgass * p%relmf

      ! determine nitrogen stress
      if (swcropsnm == 1) call nutrie ()
      
      ! calculate ratio total respiration / maintenance respiration
      if (sw_oxygen == 2) then

         q10_root = p%q10
         c_mroot = p%rmr * 32.d0 / 30.d0
         f_senes = afgen(p%rfsetb, macroptb, dvs)
         
         if (sw_wofost == 3 .AND. m_act%tdelay > 0) then

            ! assume no oxygen stress after mowing
            max_resp_factor = 1.d0

         else   

            ! respiration and partitioning of carbohydrates between growth and maintenance respiration
            rmres = (p%rmr*s_act%wrt + p%rml*s_act%wlv + p%rms*s_act%wst + p%rmo*s_act%wso) * f_senes

            teff = p%q10**((tav - 25.d0) / 10.d0)
            mres = min(r_act%pgass, rmres * teff)
            asrc = r_act%pgass - mres
           
            ! cvf: factor used in wofost to calculate the increase in biomass (dmi) from the
            ! net assimilation of the whole plant (asrc); dmi = cvf*asrc. 
            ! What is left is the growth respiration (i.e. asrc = dmi + growth respiration). 
            ! Therefore, growth respiration of the whole plant = asrc * (1 - cvf)
        
            ! partitioning factors
            fr = afgen (p%frtb, macroptb, dvs)
            fl = afgen (p%fltb, macroptb, dvs)
            fs = afgen (p%fstb, macroptb, dvs)
            fo = afgen (p%fotb, macroptb, dvs)
         
            ! conversion factor
            help = 0.d0; if (p%cvo > 0.d0) help = fo / p%cvo
            cvf = 1.d0 / ((fl / p%cvl + fs / p%cvs + help) * (1.d0 - fr) + fr / p%cvr)

            ! froots: contribution of the roots to cvf
            froots = (fr / p%cvr) * cvf
        
            ! rg_roots: growth respiration roots        
            rg_roots = froots * (1.d0 - cvf) * asrc
        
            ! rm_roots: maintenance respiration roots
            rm_roots = min(froots * (1.d0 - cvf) * r_act%pgass, p%rmr * s_act%wrt * f_senes * teff)
        
            ! max_resp_factor: ratio total respiration / maintenance respiration        
            if (rm_roots > 0.d0) then
                max_resp_factor = (rg_roots + rm_roots) / rm_roots
            else 
                max_resp_factor = 1.d0
            end if
         end if
        
      end if
      
      return

   end subroutine assimilation

   ! ---------------------------------------------------------------------

   subroutine totass (dayl, amax, eff, lai, difpp, dsinbe, sinld, cosld, dtga)

      ! ------------------------------------------------------------------
      ! Purpose: This routine calculates the daily total gross CO2
      !          assimilation by performing a Gaussian integration over
      !          time. At three different times of the day, irradiance is
      !          computed and used to calculate the instantaneous canopy
      !          assimilation, whereafter integration takes place. More
      !          information on this routine is given by Spitters et al.
      !          (1988).
      !
      ! DAYL     Astronomical daylength (base = 0 degrees)  (h)
      ! AMAX     Assimilation rate at light saturation (kg CO2/ha leaf/h)
      ! EFF      Initial light use efficiency (kg CO2/J/ha/h m2 s)
      ! LAI      Leaf area index (ha/ha)    I
      ! DIFPP    Diffuse irradiation perpendicular to direction of light (J m-2 s-1)
      ! DSINBE   Daily total of effective solar height (s)
      ! SINLD    Seasonal offset of sine of solar height (-)
      ! COSLD    Amplitude of sine of solar height (-)
      ! DTGA     Daily total gross assimilation (kg CO2/ha/d)
      ! ------------------------------------------------------------------

      use parameters, only: pi
      use atmosphere_interface, only: rad
      
      implicit none

      ! formal parameters
      real(8), intent(in) :: dayl, amax, eff, lai, difpp, dsinbe, sinld, cosld
      real(8), intent(out) :: dtga

      ! local parameters
      integer :: i
      real(8) :: hour, sinb, par, pardif, pardir, fgros

      ! gauss points and weights
      real(8), dimension(3), parameter :: xgauss = (/0.1127017d0, 0.5000000d0, 0.8872983d0/)
      real(8), dimension(3), parameter :: wgauss = (/0.2777778d0, 0.4444444d0, 0.2777778d0/)
      
      save
      
      ! ------------------------------------------------------------------

      ! calculation of assimilation is done only when it will not be zero (AMAX > 0, LAI > 0)
      dtga  = 0.0d0
      if (amax > 0.0d0 .AND. lai > 0.0d0) then
         do i = 1,3
            hour = 12.0d0 + 0.5d0 * dayl * xgauss(i)
            sinb = max(0.0d0, sinld + cosld * dcos(2.0d0 * pi * (hour + 12.0d0) / 24.0d0))
            par = 0.5d0 * rad * sinb * (1.0d0 + 0.4d0 * sinb) / dsinbe
            pardif = min(par, sinb * difpp)
            pardir = par - pardif
            call assim (amax, eff, lai, sinb, pardir, pardif, fgros)
            dtga = dtga + fgros * wgauss(i)
         end do
         dtga = dtga * dayl
      end if

      return
   end subroutine totass

   ! ---------------------------------------------------------------------

   subroutine assim (amax, eff, lai, sinb, pardir, pardif, fgros)
   
      ! ------------------------------------------------------------------
      ! Purpose: This routine calculates the gross CO2 assimilation rate of
      !          the whole crop, FGROS, by performing a Gaussian integration
      !          over depth in the crop canopy. At three different depths in
      !          the canopy, i.e. for different values of LAI, the
      !          assimilation rate is computed for given fluxes of photosynthe-
      !          tically active radiation, whereafter integration over depth
      !          takes place. More information on this routine is given by
      !          Spitters et al. (1988). The input variables SINB, PARDIR
      !          and PARDIF are calculated in routine TOTASS.
      !
      ! AMAX     Maximum CO2 assimilation rate (kg/ha/hr)
      ! EFF      Light use efficiency of a leaf (kg CO2 / J adsorbed)
      ! LAI      Leaf area index (ha /ha)
      ! SINB
      ! PARDIR
      ! DIFPP    Diffuse irradiation perpendicular to direction of light (J m-2 s-1)
      ! PARDIF   (-)
      ! FGROS    (s)
      ! ------------------------------------------------------------------

      use plant_interface, only: kdif
   
      implicit none

      ! formal parameters
      real(8), intent(in) :: amax, eff, lai, sinb, pardir, pardif
      real(8), intent(out) :: fgros

      ! local parameters
      integer :: i
      real(8) :: refh, refs, kdirbl, kdirt, laic, visdf, vist, visd, visshd
      real(8) :: fgrsh, vispp, fgrsun, fslla, fgl
      
      real(8), parameter :: scv = 0.2d0
      real(8), parameter :: sqrt_scv = (1.d0 - scv)**0.5d0

      ! gauss points and weights
      real(8), dimension(3), parameter :: xgauss = (/0.1127017d0, 0.5000000d0, 0.8872983d0/)
      real(8), dimension(3), parameter :: wgauss = (/0.2777778d0, 0.4444444d0, 0.2777778d0/)

      save

      ! ------------------------------------------------------------------
      
      ! extinction coefficients KDIF, KDIRBL, KDIRT
      refh = (1.0d0 - sqrt_scv) / (1.0d0 + sqrt_scv)
      refs = refh * 2.0d0 / (1.0d0 + 1.6d0 * sinb)
      kdirbl = (0.5d0 / sinb) * kdif / (0.8d0 * sqrt_scv)
      kdirt = kdirbl * sqrt_scv

      ! three-point Gaussian integration over LAI
      fgros = 0.0d0
      do i = 1,3
         
         laic = lai * xgauss(i)
         
         ! absorbed diffuse radiation (VISDF),light from direct origine (VIST) and direct light(VISD)
         visdf = (1.d0 - refs) * pardif * kdif  * exp(-kdif * laic)
         vist = (1.d0 - refs) * pardir * kdirt * exp(-kdirt * laic)
         visd = (1.d0 - scv) * pardir * kdirbl * exp(-kdirbl * laic)

         ! absorbed flux in W/m2 for shaded leaves and assimilation
         visshd = visdf + vist - visd
         fgrsh = amax * (1.0d0 - exp(-visshd * eff / max(2.0d0,amax)))
         
         ! direct light absorbed by leaves perpendicular on direct beam and assimilation of sunlit leaf area
         vispp = (1.0d0 - scv) * pardir / sinb
         if (vispp <= 0.0d0) then
            fgrsun = fgrsh
         else
            fgrsun = amax * (1.d0 - (amax - fgrsh) * (1.d0 - exp(-vispp * eff / max(2.d0, amax))) / (eff * vispp))
         end if
         
         ! fraction of sunlit leaf area (FSLLA) and local assimilation rate (FGL)
         fslla = exp (-kdirbl * laic)
         fgl = fslla * fgrsun + (1.d0 - fslla) * fgrsh
         
         ! integration
         fgros = fgros + fgl * wgauss(i)
      
      end do

      fgros = fgros * lai
      
      return

   end subroutine assim   
    
   ! ---------------------------------------------------------------------

   subroutine chckprt(r)

      ! ------------------------------------------------------------------
      ! checks the partitioning factors and interrupt in case of error
      ! ------------------------------------------------------------------

      use plant_interface, only: dvs

      implicit none

      ! global
      type (WOFOST_rates), intent(in)  :: r
      
      ! local
      character(len=300) :: message
      real(8) :: sum

      ! check on partitioning
      sum = r%fr + (r%fs + r%fl + r%fo) * (1.0d0 - r%fr) - 1.0d0
      if (dabs (sum) > 0.0001d0) then
         write (message,'(a,f5.2,5(a,g12.5))')' error in partitioning functions, dvs= ', dvs,' fcheck = ', sum, ' fr = ', r%fr, ' fl = ', r%fl,' fs = ', r%fs, ' fo = ', r%fo
         call swap_error ('wofost', message)
      end if
      
      return
   end    

   ! ---------------------------------------------------------------------
      
   subroutine chckcbl(r, cvf)

      !-------------------------------------------------------------------
      ! check the carbon balance, and interrupt in case of error
      !-------------------------------------------------------------------

      use plant_interface, only: dvs

      implicit none

      ! global
      type (WOFOST_rates), intent(in) :: r
      real(8) :: cvf
      
      ! local
      real(8) :: sum
      character(len=300) :: message

      ! check on c-balance
      sum = (r%gass - r%mres - (r%fr + (r%fl + r%fs + r%fo) * (1.d0 - r%fr)) * r%dmi / cvf) / max(0.0001d0, r%gass)
      if (dabs (sum) > 0.0001d0) then
         write (message,'(a,f5.2,9(a,g12.5))') ' carbon flows nog balanced on day ',               &
          dvs,' ccheck = ', sum, ' gass = ', r%gass, ' mres = ', r%mres,' fr = ',r%fr,           &
         ' fl = ',r%fl, ' fs = ',r%fs,' fo = ',r%fo,' dmi = ', r%dmi,' dvf = ', cvf
         call swap_error ('wofost', message)
      end if    
      return
   end

   ! ---------------------------------------------------------------------
      
   subroutine relgrwt(r)

      !-------------------------------------------------------------------
      ! Purpose: to calculate relative growth rate of roots, stems,
      !          leaves and storage organs  
      !-------------------------------------------------------------------

      implicit none
      
      ! global
      type (WOFOST_rates), intent(inout) :: r
      
      r%admi = (1.d0 - r%fr) * r%dmi
      r%grrt = r%fr * r%dmi
      r%grlv = r%fl * r%admi
      r%grst = r%fs * r%admi
      r%grso = r%fo * r%admi
      
      return
   end 
    
   ! ---------------------------------------------------------------------
      
   subroutine deaths(s, r, reltr)

      !-------------------------------------------------------------------
      ! Purpose: Compute the relative death rate leaves due to stress
      !          (kg DM ha-1 d-1)   
      !-------------------------------------------------------------------
      
      use MOD_swap_base, only: swcropsnm
      use plant_interface, only: kdif
      use MOD_wofost_nut, only: rdrns, nni
   
      implicit none
      
      ! global
      type (WOFOST_states), intent(in)    :: s
      type (WOFOST_rates),  intent(inout) :: r
      real(8),              intent(in)    :: reltr
      
      ! local
      real(8)   dslv1, dslv2, laicr
      ! ------------------------------------------------------------------
      
      ! death rate of leaves due to water stress
      dslv1 = s%wlv * (1.d0 - reltr) * p%perdl
      
      ! death rate of leaves due high LAI
      laicr = 3.2d0 / kdif
      dslv2 = s%wlv * max(0.d0, min(0.03d0, (0.03d0 * (s%lai - laicr) / laicr)))
      r%dslv = max(dslv1, dslv2)
      
      ! death rate increase due to nutrient shortage
      if (.NOT. s%fl_potential .AND. swcropsnm == 1 .AND. nni < 1.d0) then
         r%dslv = r%dslv + s%wlv * rdrns * (1.d0 - nni)
      end if
      
      return
   end
    
   ! ---------------------------------------------------------------------
      
   subroutine deatha (s, r)
      
      !-------------------------------------------------------------------
      ! Purpose: to compute the relative death rate leaves due to ageing
      !          (kg DM ha-1 d-1)   
      !-------------------------------------------------------------------

      implicit none

      ! global
      type (WOFOST_states), intent(in) :: s
      type (WOFOST_rates), intent(inout) :: r
      
       ! local
      integer :: ilv
      real(8) :: rest
      real(8) :: dalv
            
      ! first: leaf death due to water stress or high lai is imposed on
      ! array until no more leaves have to die or all leaves are gone

      ilv = s%ilv
      
      rest = r%dslv * delt
      do while (rest > s%lv(max(ilv, 1)) .AND. ilv >= 1)
        rest = rest - s%lv(ilv) 
        ilv = ilv - 1
      end do

      ! then: check if some of the remaining leaves are older than span,
      ! sum their weights

      dalv = 0.d0
      if (s%lvage(max(ilv, 1)) > p%span .AND. rest > 0.0d0 .AND. ilv >= 1)then
         dalv = s%lv(ilv) - rest
         rest = 0.d0
         ilv = ilv - 1
      end if

      do while (ilv >= 1 .AND. s%lvage(max(ilv, 1)) > p%span)
         dalv = dalv + s%lv(ilv)
         ilv = ilv - 1
      end do

      r%dalv = dalv / delt
      
      return
    end
    
   ! ---------------------------------------------------------------------
    
   subroutine glai(s, r, reltr)
      !-------------------------------------------------------------------
      ! exponential, sink limited leave increase and adjustment of 
      ! specific leaf area of youngest leaf class. Adjust for water and 
      ! nitrogen stress.
      !-------------------------------------------------------------------
    
      use MOD_swap_base, only: swcropsnm
      use atmosphere_interface, only: tav
      use plant_interface, only: dvs
      use MOD_wofost_nut, only: nlai, nni
    
      implicit none

      ! global
      type (WOFOST_states), intent(in) :: s
      type (WOFOST_rates), intent(inout) :: r
      real(8), intent(in) :: reltr
      
      ! local
      real(8) :: dteff, glasol
      real(8) :: f_stress
      !-------------------------------------------------------------------
      
      if (s%laiexp < 6.d0) then

         f_stress = reltr
         if (.NOT. s%fl_potential .AND. swcropsnm == 1) then
            if ((dvs < 0.2d0) .AND. (s%lai < 0.75d0)) then
               f_stress = reltr * exp(-1.d0 * nlai * (1.d0 - nni))
            end if
         end if
         
         dteff = max(0.d0, tav - p%tbase)
         r%glaiex = f_stress * s%laiexp * p%rgrlai * dteff

         ! source-limited increase in leaf area
         glasol = r%grlv * r%slat

         ! sink-limited increase in leaf area
         r%gla = min(r%glaiex, glasol)

         ! adjustment of specific leaf area of youngest leaf class
         if (r%grlv > 0.d0) r%slat = r%gla / r%grlv
      end if
      
      return

   end subroutine glai

   ! ---------------------------------------------------------------------
    
   subroutine lvdth(s, r, delt)
      !-------------------------------------------------------------------
      ! impose leave death on LV array 
      !-------------------------------------------------------------------
      
      implicit none
      
      ! global
      type (WOFOST_states), intent(inout) :: s
      type (WOFOST_rates),  intent(in)    :: r
      real(8),              intent(in)    :: delt
      
      ! local
      real(8) :: dslvt

      ! remaining leaves
      dslvt = r%dslv * delt
      do while ((dslvt > 0.d0) .AND. (s%ilv >= 1))
         if (dslvt >= s%lv(s%ilv)) then
            dslvt = dslvt - s%lv(s%ilv)
            s%lv(s%ilv) = 0.d0
            s%ilv = s%ilv - 1
         else
            s%lv(s%ilv) = s%lv(s%ilv) - dslvt
            dslvt = 0.d0
         end if
      end do

      ! leaves older than span die
      do while (s%lvage(max(s%ilv, 1)) > p%span .AND. s%ilv >= 1)
         s%lv(s%ilv) = 0.d0
         s%ilv = s%ilv - 1
      end do

      return
      
   end
    
   !----------------------------------------------------------------------
    
   subroutine lvshft(s, r, delt)
      !-------------------------------------------------------------------
      ! shift contents of LV, LVAGE, SLA tables with one day  
      !-------------------------------------------------------------------

      implicit none

      ! global
      type (WOFOST_states), intent(inout) :: s
      type (WOFOST_rates),  intent(in)    :: r
      real(8),              intent(in)    :: delt

      !-------------------------------------------------------------------

      ! shift contents of LV, LVAGE, SLA tables with one day
      s%lv(2:(s%ilv + 1)) = s%lv(1:s%ilv)
      s%sla(2:(s%ilv + 1)) = s%sla(1:s%ilv)
      s%lvage(2:(s%ilv + 1)) = s%lvage(1:s%ilv) + r%fysdel * delt

      ! new leaves in first class
      s%lv(1) = r%grlv * delt
      s%sla(1) = r%slat
      s%lvage(1) = 0.0d0 
      
      s%ilv = s%ilv + 1

       return

   end
    
   !----------------------------------------------------------------------
    
    subroutine lvwgli(s)
      !-------------------------------------------------------------------
      ! calculate new wlv and lai 
      !-------------------------------------------------------------------
      
      implicit none

      ! global
      type (WOFOST_states), intent(inout) :: s
      
      ! local
      integer :: i

      ! calculation of new leaf area and weight
      s%lasum = 0.d0
      s%wlv = 0.d0
      do i = 1, s%ilv
         s%lasum = s%lasum + s%lv(i) * s%sla(i)
         s%wlv = s%wlv + s%lv(i)
      end do
  
      return
   end

   !----------------------------------------------------------------------

   real(8) function rfmgtemp()
      ! ------------------------------------------------------------------
      ! temperature reduction factor (short day)
      ! approach and parameters based on Setiyono et al. doi 10.1016/j.fcr.2006.07.011
      ! http://digitalcommons.unl.edu/agronomyfacpub/112
      !-------------------------------------------------------------------
      
      use atmosphere_interface, only: tav
    
      implicit none
      
      ! local
      real(8) :: alpha, p1, p2, p3, p4

      !-------------------------------------------------------------------

      if (tav < p_soy%tmindvr .OR. tav > p_soy%tmaxdvr) then
         rfmgtemp = 0.d0
      else
         alpha = log(2.d0) / log((p_soy%tmaxdvr - p_soy%tmindvr) / (p_soy%toptdvr - p_soy%tmindvr))
         p1 = 2.d0 * (tav - p_soy%tmindvr)**alpha
         p2 = (p_soy%toptdvr - p_soy%tmindvr)**alpha
         p3 = (tav - p_soy%tmindvr)**(2.d0 * alpha)
         p4 = (p_soy%toptdvr - p_soy%tmindvr)**(2.d0 * alpha)
         rfmgtemp = (p1 * p2 - p3) / p4
      end if
    
   end function rfmgtemp

   !----------------------------------------------------------------------

   real(8) function rfmgphotop()
      ! ------------------------------------------------------------------
      ! photoperiod reduction factor (short day)
      ! approach and parameters based on Setiyono et al. doi 10.1016/j.fcr.2006.07.011
      ! http://digitalcommons.unl.edu/agronomyfacpub/112
      ! ------------------------------------------------------------------
      
      use MOD_meteo, only: lat
      use parameters, only: pi, radial
      use variables, only: daynr
    
      implicit none
    
      ! local
      real(8) :: alpha, p0, p1, p2
      real(8) :: dec, daylp, sinld, cosld, aob

      ! astronomic daylength according to solar elevation angle of -0.833 day
      ! declination and solar constant for this day
      dec = -asin(dsin(23.45d0 * radial) * dcos(2.d0 * pi * dble(daynr + 10) / 365.d0))
      sinld = dsin(radial * lat) * dsin(dec)
      cosld = dcos(radial * lat) * dcos(dec)
      aob = sinld / cosld
      if (dabs(aob) <= 1.d0) then 
         daylp = 12.d0 * (1.d0 + 2.d0 * asin(aob) / pi)
      else
         if (aob > 1.d0)  daylp = 24.d0
         if (aob < -1.d0) daylp =  0.d0
      end if

      ! first determine popt and pcrt based on maturity group rating
      if(p_soy%sw_phenodayl == 0) then
        p_soy%popt = 12.759d0 - 0.388d0 * p_soy%mg - 0.058d0 * p_soy%mg**2
        p_soy%pcrt = 27.275d0 - 0.493d0 * p_soy%mg - 0.066d0 * p_soy%mg**2
      end if

      if (daylp < p_soy%popt) then
         rfmgphotop = 1.d0
      else
         if (daylp > p_soy%pcrt) then
            rfmgphotop = 0.0d0
         else
            alpha = log(2.d0) / log(((p_soy%pcrt - p_soy%popt) / 3.d0) + 1.d0)
            p0 = (p_soy%pcrt - p_soy%popt) / 3.d0
            p1 = (daylp - p_soy%popt) / 3.d0 + 1.0d0
            p2 = (p_soy%pcrt - daylp) / (p_soy%pcrt - p_soy%popt)
            rfmgphotop = (p1 * (p2**p0))**alpha
         end if
      end if
      
   end function rfmgphotop

   ! ---------------------------------------------------------------------
   
   subroutine subpar (r, reltr)
      ! ------------------------------------------------------------------
      ! modification of dry matter partitioning to leaves, stems, roots
      ! and storage organs in dependence of water and N stress
      ! ------------------------------------------------------------------

      use MOD_wofost_nut, only: nni, npart
      
      implicit none
      
      ! global
      type (WOFOST_rates), intent(inout) :: r
      real(8), intent(in) :: reltr

      real(8)  frtmod, flold, flvmod
      ! ------------------------------------------------------------------

      if (reltr < nni) THEN

         ! water stress is more severe as compared to nutrient stress and
         ! partitioning will follow the original assumptions of LINTUL2

         frtmod = max(1.d0, 1.d0 / (reltr + 0.5d0))
         r%fr = min(0.6d0, r%fr * frtmod)

      else

         ! nutrient stress is more severe as compared to water stress resulting in
         ! less partitioning to leaves and more to stems

         flold = r%fl
         flvmod = exp(-1.d0 * npart * (1.d0 - nni))
         r%fl = flold * flvmod
         r%fs = r%fs + flold - r%fl 

      end if
      
      return

   end subroutine subpar
   
   ! ---------------------------------------------------------------------
   
   subroutine management_event (s, r, m, fl_continue)

      use plant_interface, only: fl_cropharvestday
      implicit none

      ! global
      type (WOFOST_states), intent(inout) :: s
      type (WOFOST_rates), intent(inout) :: r
      type (AGRO_management), intent(inout) :: m
      logical, intent(out) :: fl_continue

      ! local
      real(8) :: twlvdm, twdm, twgrz, dmgrzlv, f_evtgrz
      real(8) :: dmloss

      ! functions
      real(8) :: afgen, h_average

      ! ---------------------------------------------------------------------

      fl_continue = .TRUE.
      if (sw_wofost == 3) then

         twlvdm = s%wst + s%wlv + s%wso
         twdm = twlvdm + s%dwst + s%dwlv
         m%tcut = m%tcut + 1

         ! check management event
         if (.NOT. m%fl_grz) call trigger_management_event (m, twdm)
         
         ! set fl_cropharvestday
         if (.NOT. s%fl_potential) then
            if (m%fl_mow .OR. m%fl_grz) fl_cropharvestday = .TRUE.
         end if

         ! mowing event
         if (m%fl_mow) then

            ! reset crop development
            if (twdm >= p_agro%dmrestmow) call mowing_event (s, r, p_agro%dmrestmow)

            ! update harvest
            m%dmloss = 0.d0
            if (p_agro%sw_lossmow == 1) then
               m%dmloss = max(0.d0, twdm - min(twlvdm, p_agro%dmrestmow)) * afgen(p_agro%lossmowtb, macroptb, h_average(p_agro%z_mow))
            end if
            m%dmhrv = max(0.d0, twdm - min(twlvdm, p_agro%dmrestmow)) - m%dmloss
            m%tdelay = int(afgen (p_agro%delaymowtb, macroptb, m%dmhrv + m%dmloss))
            m%fl_cutend = .TRUE.
            fl_continue = .FALSE.

         ! grazing event
         else if (m%fl_grz) then

            ! extra losses due to treading
            m%dmloss = 0.d0
            if (p_agro%sw_lossgrz == 1) then
               dmloss = twdm * afgen(p_agro%lossgrztb, macroptb, h_average(p_agro%z_grz))
            end if
            
            ! check if full grazing event (f_evtgrz = 1.0)
            twgrz = p_agro%uptgrz + p_agro%lossgrz + dmloss
            f_evtgrz = min(1.d0, max(0.d0, twdm - p_agro%dmrestgrz) / twgrz)
            
            ! distribute grazing over stems and leaves (living and dead parts)
            s%wst  = s%wst  - twgrz * f_evtgrz * s%wst  / twdm
            s%dwst = s%dwst - twgrz * f_evtgrz * s%dwst / twdm
            s%dwlv = s%dwlv - twgrz * f_evtgrz * s%dwlv / twdm
            dmgrzlv = twgrz * f_evtgrz * s%wlv  / twdm

            ! reduce leave weight
            do while (dmgrzlv > 0.d0 .AND. s%ilv >= 1)
               if (dmgrzlv >= s%lv(s%ilv)) then
                  dmgrzlv = dmgrzlv - s%lv(s%ilv)
                  s%lv(s%ilv) = 0.d0
                  s%ilv = s%ilv - 1
               else
                  s%lv(s%ilv) = s%lv(s%ilv) - dmgrzlv
                  dmgrzlv = 0.d0
               end if
            end do

            ! update harvest after grazing
            m%dmhrv = p_agro%uptgrz * f_evtgrz
            m%dmloss = dmloss * f_evtgrz
            m%tgrz = m%tgrz + 1
            if (m%tgrz >= p_agro%daygrz .OR. f_evtgrz < 1.d0) m%fl_cutend = .TRUE.

            ! dewooling
            if (p_agro%seqgrzmow(m%icut) == 3 .AND. m%fl_cutend .AND. twdm >= p_agro%dmrestdew) then

               ! reset crop development
               call mowing_event (s, r, p_agro%dmrestdew)

               ! update harvest after dewooling
               m%tdelay = 1
               fl_continue = .FALSE.
            end if

         end if

      end if

      return

   end subroutine management_event

   ! ---------------------------------------------------------------------

   subroutine trigger_management_event (m, twdm)
      
      use variables, only: t1900, daynr

      implicit none

      ! global
      type (AGRO_management), intent(inout) :: m
      real(8), intent(in) :: twdm
      
      ! local
      real(8) :: dm_trigger
      
      ! funtions
      real(8) :: afgen

      ! ------------------------------------------------------------------
      
      m%fl_mow = .FALSE.
      m%fl_grz = .FALSE.
      
      ! mowing
      if (p_agro%seqgrzmow(m%icut) == 2) then
      
         if (p_agro%sw_harvest == 1) then
            dm_trigger = afgen(p_agro%dmmowtb, macroptb, dble(daynr))
            if (twdm > dm_trigger .OR. (m%tcut > p_agro%mxgdmow .AND. m%icut > 1)) m%fl_mow = .TRUE.
         else
            if (t1900 > p_agro%date_harvest(m%icut)) m%fl_mow = .TRUE.
         end if
      end if

      ! grazing
      if (p_agro%seqgrzmow(m%icut) == 1 .OR. p_agro%seqgrzmow(m%icut) == 3) then

         if (p_agro%sw_harvest == 1) then
            dm_trigger = afgen(p_agro%dmgrztb, macroptb, dble(daynr))
            if (twdm > dm_trigger .OR. (m%tcut > p_agro%mxgdgrz .AND. m%icut > 1)) m%fl_grz = .TRUE.
         else
            if (t1900 > p_agro%date_harvest(m%icut)) m%fl_grz = .TRUE.
         end if
      end if

      return

   end subroutine trigger_management_event

   ! ---------------------------------------------------------------------

   subroutine mowing_event (s, r, dmrest)
      
      use plant_interface, only: dvs

      implicit none

      ! global
      type (WOFOST_states), intent(inout) :: s
      type (WOFOST_rates), intent(inout) :: r
      real(8), intent(in) :: dmrest
      
      ! functions
      real(8) :: afgen

      ! ------------------------------------------------------------------
      
      ! reset crop development after mowing
      s%sla(:) = 0.d0; s%sla(1) = afgen (p%slatb, macroptb, dvs)
      r%fl = afgen (p%fltb, macroptb, dvs)
      r%fs = afgen (p%fstb, macroptb, dvs)
      if (dmrest < (s%wlv + s%wst)) then
         s%wlv = min(dmrest,s%wlv+s%wst) / (1.d0 + (r%fs / r%fl))
         s%wst = r%fs / r%fl * s%wlv
      end if
      s%dwlv = 0.d0
      s%dwst = 0.d0
      s%lvage(:) = 0.d0
      s%ilv = 1
      s%lasum = s%wlv * s%sla(1)
      s%laiexp = s%lasum
      s%lv(:) = 0.d0; s%lv(1) = s%wlv

      r%gwst = 0.d0; r%gwrt = 0.d0
      r%drst = 0.d0; r%drlv = 0.d0; r%drrt = 0.d0

      r%gass = 0.d0
      r%mres = 0.d0
      
      return
      
   end subroutine mowing_event

   ! ---------------------------------------------------------------------
   
   subroutine reset_wofost_states_rates()
   implicit none
   call reset_wofost_states(s_pot)
   call reset_wofost_states(s_act)
   call reset_wofost_rates(r_pot)
   call reset_wofost_rates(r_act)
   end subroutine reset_wofost_states_rates

   subroutine reset_wofost_states(s)
      implicit none
      type(WOFOST_states), intent(inout) :: s
      s%ilv = 0
      s%sla = 0.0d0
      s%lv = 0.0d0
      s%lvage = 0.0d0
      s%wrt = 0.0d0
      s%wst = 0.0d0
      s%wlv = 0.0d0
      s%wso = 0.0d0
      s%dwrt = 0.0d0
      s%dwst = 0.0d0
      s%dwlv = 0.0d0
      s%lasum = 0.0d0
      s%laiexp = 0.0d0
      s%lai = 0.0d0
   end subroutine reset_wofost_states

   subroutine reset_wofost_rates(r)
      implicit none
      type(WOFOST_rates), intent(inout) :: r
      r%fr = 0.0d0
      r%fl = 0.0d0
      r%fs = 0.0d0
      r%fo = 0.0d0
      r%pgass = 0.0d0
      r%gass = 0.0d0
      r%mres = 0.0d0
      r%dmi = 0.0d0
      r%admi = 0.0d0
      r%grrt = 0.0d0
      r%grlv = 0.0d0
      r%grst = 0.0d0
      r%grso = 0.0d0
      r%fysdel = 0.0d0
      r%dslv = 0.0d0
      r%dalv = 0.0d0
      r%drlv = 0.0d0
      r%drst = 0.0d0
      r%drrt = 0.0d0
      r%gwst = 0.0d0
      r%gwrt = 0.0d0
      r%gwso = 0.0d0
      r%slat = 0.0d0
      r%glaiex = 0.0d0
      r%gla = 0.0d0
   end subroutine reset_wofost_rates

end module MOD_wofost
    