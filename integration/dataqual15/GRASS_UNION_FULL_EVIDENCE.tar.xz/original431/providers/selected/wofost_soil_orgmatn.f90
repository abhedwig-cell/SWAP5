! File VersionID:
!   $Id: wofost_soil_orgmatn.f90 362 2018-01-08 13:08:33Z kroes006 $
! ----------------------------------------------------------------------
   subroutine wofost_soilorgmatn
      ! ------------------------------------------------------------------
      use wofost_soil_declarations
      
      implicit none

      integer :: fn
      real(8) :: p1, p2, p3, p4, p5
      real(8) :: p111, p112, p121, p122, p211, p212, p221, p222 
      real(8) :: eval1, eval2, help, dt
      real(8) :: Bio_av, Hum_av, RHS_bio, RHS_hum
      ! ------------------------------------------------------------------
      
      dt = dt_WSN

      ! 1 residue of Fresh Organic Matter fractions
      do fn = 1,nf
         FOM_t(fn) = FOM_t0(fn) * exp(-1.d0 * RateconFOM(fn) * dt) 
      end do

      ! - mutual dependent Biomass & Humus pools -
      
      ! 2.1 intermediate variables
      p1 = (1.d0 - AsfaBio) * RateconBio
      p2 = AsfaBio * RateconHum
      p3 = AsfaHum * RateconBio
      p4 = (1.d0 - AsfaHum) * RateconHum
      
      ! 2.2 eigenvalues of the mutual interacting Biomass - Humus system
      p5 = dsqrt((p1 - p4)**2 + 4 * p2 * p3)
      eval1 = -(p1 + p4 + p5) / 2.d0
      eval2 = -(p1 + p4 - p5) / 2.d0

      ! 2.3 coefficients of the Fundamental Matrix, third subscript refers to resp. Eival1 and Eval2
      p111 = -1.d0 * (p4 + eval1) / p5
      p112 =  (p4 + eval2) / p5
      p121 = - 1.d0 * p2 / p5
      p122 =  p2 / p5
      p211 = -1.d0 * p3 / p5
      p212 =  p3 / p5
      p221 = -1.d0 * (p1 + eval1) / p5
      p222 =  (p1 + eval2) / p5

      !2.4  Residue of Biomass and Humus
      Bio_t = (p111 * exp(eval1 * dt) + p112 * exp(eval2 * dt)) * Bio_t0 + (p121 * exp(eval1 * dt) + p122 * exp(eval2 * dt)) * Hum_t0
      Hum_t = (p211 * exp(eval1 * dt) + p212 * exp(eval2 * dt)) * Bio_t0 + (p221 * exp(eval1 * dt) + p222 * exp(eval2 * dt)) * Hum_t0
      
      do fn = 1,nf
         Bio_t = Bio_t + AsfaFOM_Bio(fn) * FOM_t0(fn) * RateconFOM(fn) *                                     &
                 (p111 / (eval1 + RateconFOM(fn)) * (exp(eval1 * dt) - exp(-1.d0 * RateconFOM(fn) * dt)) +   &
                  p112 / (eval2 + RateconFOM(fn)) * (exp(eval2 * dt) - exp(-1.d0 * RateconFOM(fn) * dt)))
         Bio_t = Bio_t + AsfaFOM_Hum(fn) * FOM_t0(fn) * RateconFOM(fn) *                                     &
                 (p121 / (eval1 + RateconFOM(fn)) * (exp(eval1 * dt) - exp(-1.d0 * RateconFOM(fn) * dt)) +   &
                  p122 / (eval2 + RateconFOM(fn)) * (exp(eval2 * dt) - exp(-1.d0 * RateconFOM(fn) * dt)))
         Hum_t = Hum_t + AsfaFOM_Bio(fn) * FOM_t0(fn) * RateconFOM(fn) *                                     &
                 (p211 / (eval1 + RateconFOM(fn)) * (exp(eval1 * dt) - exp(-1.d0 * RateconFOM(fn) * dt)) +   &
                  p212 / (eval2 + RateconFOM(fn)) * (exp(eval2 * dt) - exp(-1.d0 * RateconFOM(fn) * dt)))
         Hum_t = Hum_t + AsfaFOM_Hum(fn) * FOM_t0(fn) * RateconFOM(fn) *                                     &
                 (p221 / (eval1 + RateconFOM(fn)) * (exp(eval1 * dt) - exp(-1.d0 * RateconFOM(fn) * dt)) +   &
                  p222 / (eval2 + RateconFOM(fn)) * (exp(eval2 * dt) - exp(-1.d0 * RateconFOM(fn) * dt)))
      end do

      ! balance variables in kg/m2
      do fn = 1, nf

         ! gross dissociation of FOM
         help =  (FOM_t0(fn) - FOM_t(fn)) * dz_WSN

         ! incorporation of dissociated FOM into BIO
         FOM2Bio = FOM2Bio + AsfaFOM_Bio(fn) * help
         NFOM2Bio = NFOM2Bio + NFracBio * AsfaFOM_Bio(fn) * help

         ! incorporation of dissociated FOM into Hum
         FOM2Hum = FOM2Hum + AsfaFOM_Hum(fn) * help
         NFOM2Hum = NFOM2Hum + NFracHum * AsfaFOM_Hum(fn) * help

         ! nett dissociation of FOM
         FOM_dis = FOM_dis + (1.d0 - AsfaFOM_Bio(fn) - AsfaFOM_Hum(fn)) * help

         ! nett N-mineralisation of FOM
         NFOM_min = NFOM_min + (NFracFOM(fn) - AsfaFOM_Bio(fn) * NFracBio -  AsfaFOM_Hum(fn) * NFracHum) * help 
      end do

      ! calculate time averaged Bio and Hum values
      RHS_bio = (Bio_t - Bio_t0) / dt - FOM2Bio / dt / dz_WSN
      RHS_hum = (Hum_t - Hum_t0) / dt - FOM2Hum / dt / dz_WSN
      Bio_av = (p4 * RHS_bio + p2 * RHS_hum) / (p2 * p3 - p1 * p4)
      Hum_av = (p3 * RHS_bio + p1 * RHS_hum) / (p2 * p3 - p1 * p4)

      ! conversion of Bio into Bio
      help = dt * dz_WSN
      Bio2Bio = Bio2Bio + help * RateconBio * AsfaBio * Bio_av 
      NBio2Bio = NBio2Bio + help * NFracBio * RateconBio * AsfaBio * Bio_av

      ! conversion of Bio into Hum
      Bio2Hum = Bio2Hum + help * RateconBio * AsfaHum * Bio_av
      NBio2Hum = NBio2Hum + help * NFracHum * RateconBio * AsfaHum * Bio_av

      ! nett dissimilation of Bio
      Bio_dis = Bio_dis + (1.d0 - AsfaBio - AsfaHum) * help * RateconBio * Bio_av
      NBio_min = NBio_min + (NFracBio - NFracBio * AsfaBio - NFracHum * AsfaHum) * help * RateconBio * Bio_av

      ! conversion of Hum into Bio
      Hum2Bio = Hum2Bio + help * RateconHum * AsfaBio * Hum_av
      NHum2Bio = NHum2Bio + NFracBio * help * RateconHum * AsfaBio * Hum_av

      ! conversion of Hum into Hum
      Hum2Hum = Hum2Hum + help * RateconHum * AsfaHum * Hum_av
      NHum2Hum = NHum2Hum + NFracHum *help * RateconHum * AsfaHum * Hum_av

      ! nett dissimilation of Hum
      Hum_dis = Hum_dis + (1.d0 - AsfaBio - AsfaHum) * help * RateconHum * Hum_av
      NHum_min = NHum_min + (NFracHum - NFracBio * AsfaBio - NFracHum * AsfaHum) * help * RateconHum * Hum_av

      ! dissimilation of carbon
      Cdissi = 0.d0
      do fn = 1,nf
         Cdissi = Cdissi + CFracFOM(fn) * (FOM_t0(fn) - FOM_t(fn)) * dz_WSN * (1.d0 - AsfaFOM_Bio(fn) - AsfaFOM_Hum(fn))
      end do
      Cdissi = Cdissi + CFracBio * dt * dz_WSN * (1.d0 - AsfaBio - AsfaHum) * RateconBio * Bio_av &
                      + CFracHum * dt * dz_WSN * (1.d0 - AsfaBio - AsfaHum) * RateconHum * Hum_av
 
      ! mineralisation of nitrogen
      Nminer = 0.d0
      do fn = 1,nf
         Nminer = Nminer + (NFracFOM(fn) - AsfaFOM_Bio(fn) * NFracBio - AsfaFOM_Bio(fn) * NFracBio) * (FOM_t0(fn) - FOM_t(fn))
      end do
      Nminer = Nminer + (NFracBio - NFracBio * AsfaBio - NFracHum * AsfaHum) * RateconBio * Bio_av * dt
      Nminer = Nminer + (NFracHum - NFracBio * AsfaBio - NFracHum * AsfaHum) * RateconHum * Hum_av * dt

      return
      
   end subroutine wofost_soilorgmatn

