module MOD_wofost_nut
   
   use MOD_arrays, only: macroptb
   
   implicit none
   
   real(8), save :: rdrns                         ! maximum relative death rate of leaves due to N stress
   real(8), save :: dvsnlt                        ! development stage above which no crop nitrogen uptake does occur
   real(8), save :: dvsnt                         ! development stage above which nitrogen translocation to storage organs does occur 
   real(8), save :: fntrt                         ! nitrogen translocation from roots as a fraction of total N amount translocated from leaves and stems
   real(8), save :: frnx                          ! optimal N concentration as fraction of maximum N concentration
   real(8), save :: lrnr                          ! maximum N concentration in roots as fraction of maximum N concentration in leaves
   real(8), save :: lsnr                          ! maximum N concentration in stems as fraction of maximum N concentration in leaves
   real(8), save :: nlai                          ! coefficient for the reduction due to N stress of the LAI increase (during juvenile phase)
   real(8), save :: nlue                          ! coefficient for the reduction of RUE due to Nitrogen stress
   real(8), save :: nmaxso                        ! maximum N concentration (= 1.6*min. N conc.) in storage organs [kg N kg-1 dry biomass]
   real(8), save :: npart                         ! coefficient for the effect of N stress on leaf biomass reduction 
   real(8), save :: nsla                          ! coefficient for the effect of N stress on SLA reduction
   real(8), save :: rnfrt                         ! residual N fraction in roots [kg N kg-1 dry biomass]
   real(8), save :: rnfst                         ! residual N fraction in stems [kg N kg-1 dry biomass]
   real(8), save :: rnflv                         ! residual N fraction in leaves [kg N kg-1 dry biomass]
   real(8), save :: tcnt                          ! time coefficient for N translocation to storage organs [days]
   real(8), save :: nfixf                         ! fraction of crop nitrogen uptake by biological fixation [-]
   real(8), allocatable, save :: nmxlv(:)         ! maximum N concentration in leaves as function of development stage [kg N kg-1 dry biomass]
   
   real(8), save :: fraharlosorm_st               ! fraction harvest losses of organic matter from stems [0.0..1.0 kg.kg-1 DM, R]
   real(8), save :: fraharlosorm_lv               ! fraction harvest losses of organic matter from leaves [0.0..1.0 kg.kg-1 DM, R]
   real(8), save :: fraharlosorm_so               ! fraction harvest losses of organic matter from storage organs [0.0..1.0 kg.kg-1 DM, R]
   real(8), save :: fradeceasedlvtosoil           ! fraction of deceased leaves entering the soil system

   real(8), save :: nni
   real(8), save :: anlv, anst, anrt, anso
   real(8), save :: anlvi, ansti, anrti, ansoi
   real(8), save :: nmaxrt, nmaxst, nmaxlv
   real(8), save :: nlossl, nlossr, nlosss
   real(8), save :: nuptt, nfixtt, nlossldeceasedlvtosoil
   real(8), save :: ndeml, ndems, ndemr, ndemso, ndemto
   real(8), save :: fstr                          ! nutrient reduction factor
   
   real(8), save :: NdemandBioFix
   
   private
   
   public :: nutrie, read_wofost_nut, initialize_wofost_nut, update_wofost_nut, demand_wofost_nut
   public :: outbalcropN
   
   public :: fstr
   public :: nlue, nsla, nlai, nni
   public :: anlv, anst, nmaxlv, nmaxst, nmaxrt, lrnr, lsnr, rnflv, rnfst, frnx, npart, rdrns
   public :: dvsnlt, dvsnt
   public :: nmxlv
   public :: ndeml, ndems, ndemr, ndemto
   
   contains

   ! ---------------------------------------------------------------------
   
   subroutine read_wofost_nut ()
      ! ------------------------------------------------------------------
      use MOD_swap_base, only: unit_err
      use plant_interface, only: unit_crp, crpfilnam
      
      implicit none
      
      ! functions
      logical :: rdinqr
      
      ! ------------------------------------------------------------------
         
      ! open connection
      call rdinit(unit_crp, unit_err, crpfilnam)
         
      call rdsdou ('rdrns', rdrns)
      call rdsdou ('dvsnlt', dvsnlt)
      call rdsdou ('dvsnt', dvsnt)
      call rdsdou ('fntrt', fntrt)
      call rdsdou ('frnx', frnx)
      call rdsdou ('lrnr', lrnr)
      call rdsdou ('lsnr', lsnr)
      call rdsdou ('nlai', nlai)
      call rdsdou ('nlue', nlue)
      call rdsdou ('nmaxso', nmaxso)
      call rdsdou ('npart', npart)
      call rdsdou ('nsla', nsla)
      call rdsdou ('rnfrt', rnfrt)
      call rdsdou ('rnfst', rnfst)
      call rdsdou ('rnflv', rnflv)
      call rdsdou ('tcnt', tcnt)
      call rdsdou ('nfixf', nfixf)
      
      if (allocated(nmxlv)) deallocate(nmxlv); allocate(nmxlv(1:macroptb)); nmxlv = 0.0d0
      call rdadortb ('nmxlv', 0.d0, 3.d0, 0.d0, 1.d0, nmxlv, macroptb, .FALSE.)
      
      ! harvest losses (fractions of leaves, stems, storage organs)
      call rdsdor ('fraharlosorm_lv',0.d0, 1.d0, fraharlosorm_lv) 
      call rdsdor ('fraharlosorm_st',0.d0, 1.d0, fraharlosorm_st) 
      call rdsdor ('fraharlosorm_so',0.d0, 1.d0, fraharlosorm_so) 
      
      ! fraction of deceased leaves entering the soil system
      fradeceasedlvtosoil = 0.d0
      if (rdinqr('fradeceasedlvtosoil')) call rdsdor ('fradeceasedlvtosoil',0.d0,1.d0,fradeceasedlvtosoil)
      
      ! close connection
      close(unit_crp)

      
   end subroutine read_wofost_nut

   ! ---------------------------------------------------------------------

   subroutine initialize_wofost_nut ()
      ! ------------------------------------------------------------------
      
      use plant_interface, only: dvs, wrt, wst, wlv
      
      implicit none
      real(8) :: nmaxlvi
      real(8) :: nbalan
      logical, save :: first = .TRUE.
      
      ! functions
      real(8) :: afgen
      
      ! ------------------------------------------------------------------
      
      ! initial maximum N concentration in plant organs
      nmaxlvi = afgen (nmxlv, macroptb, dvs)
      
      anlvi = nmaxlvi * wlv
      ansti = lsnr * nmaxlvi * wst
      anrti = lrnr * nmaxlvi * wrt
      ansoi = 0.d0
            
      anlv = anlvi
      anst = ansti
      anrt = anrti
      anso = ansoi      
      
      
      ! initialization of nutrient parameters
      nlossl = 0.d0; nlossr = 0.d0; nlosss = 0.d0
      nuptt = 0.d0; nfixtt = 0.d0
      nni = 1.d0
      nlossldeceasedlvtosoil = 0.d0
      
      ! open output files and write header 
      if (first) then
         
         nbalan = 0.d0
         
         first = .FALSE.
         
         call outbalcropN(1, nbalan)
      end if
      
   end subroutine initialize_wofost_nut

   ! ---------------------------------------------------------------------

   subroutine update_wofost_nut ()
   
      ! ------------------------------------------------------------------
      
      use plant_interface, only: fl_cropharvest, dvs, wrt, wst, wlv, wso, dwst, dwlv, drrt, drst, drlv
      use variables, only: DAYCUM
      use wofost_soil_interface, only: NdemandSoil, NsupplySoil, idwrt, idwlv, idwst, idwso, iNLOSSL,  iNLOSSR, iNLOSSS, iNLOSSO
   
      implicit none
      
      
      real(8), parameter :: delt = 1.d0
      character(len=200) :: message
      
      real(8) :: atnlv, atnst, atnrt, atn
      real(8) :: rnso
      real(8) :: rntrt, rntst, rntlv
      real(8) :: nsupso, nuptr
      real(8) :: nfixtr
      real(8) :: rnurt, rnust, rnulv
      real(8) :: rnrt, rnst, rnlv
      real(8) :: rnldrt, rnldst, rnldlv
      
      ! --- n-p-k use

      
      real(8) NBALAN

      real(8) :: HarLosOrm_rt, HarLosOrm_lv, HarLosOrm_st, HarLosOrm_so
      real(8) :: HarLosNit_rt, HarLosNit_lv, HarLosNit_st, HarLosNit_so
      real(8) :: HarLosOrm_dwst, HarLosOrm_dwlv

      real(8) :: HarLosNit_dwst, HarLosNit_dwlv
      
      ! ------------------------------------------------------------------
      
      ! total N uptake (kg N ha-1 d-1) from soil and by biological N fixation         
      nuptr = max(0.d0, min(NdemandSoil, NsupplySoil)) / delt
      nfixtr = max(0.d0, NdemandBioFix) / delt

      ! estimate the translocatable nutrients in leaves, stem, roots and storage organs (kg N ha-1)
      atnst = max (0.d0, anst - wst * rnfst)
      atnlv = max (0.d0, anlv - wlv * rnflv)
      atnrt = max ((atnlv + atnst) * fntrt, anrt - wrt * rnfrt)
      atn = atnlv +  atnst + atnrt
         
      ! N supply to the storage organs (kg N ha-1 d-1)
      if (dvs - dvsnt < 0.d0) then
         nsupso = 0.d0
      else
         nsupso = atn / tcnt
      end if   

      ! rate of N uptake in grains (kg N ha-1 d-1)
      rnso = min (ndemso, nsupso)

      ! calculate nutrient translocation from leaves, stem, and roots (kg N ha-1 d-1)
      rntlv = 0.d0
      if (atn > 1.0d-5)  rntlv = rnso * atnlv / atn
      rntst = 0.d0
      if (atn > 1.0d-5)  rntst = rnso * atnst / atn
      rntrt = 0.d0
      if (atn > 1.0d-5)  rntrt = rnso * atnrt / atn
      
      ! compute the partitioning of the total nutrient uptake rate (NUPTR) over the leaves, stem and roots (kg N ha-1 d-1)
      rnulv = 0.d0; rnust = 0.d0; rnurt = 0.d0
      if (ndemto > 1.d-5) then
         rnulv = (ndeml / ndemto) * (nuptr + nfixtr)
         rnust = (ndems / ndemto) * (nuptr + nfixtr)
         rnurt = (ndemr / ndemto) * (nuptr + nfixtr)
      end if
      
      ! calculate nutrient losses due to dying leaves, stems and roots (kg N ha-1 d-1)
      rnldrt = rnfrt * drrt
      rnldst = rnfst * drst
      rnldlv = rnflv * drlv
   
      ! rate of change of N in crop organs   
      rnlv = rnulv - rntlv - rnldlv
      rnst = rnust - rntst - rnldst
      rnrt = rnurt - rntrt - rnldrt

      ! total N uptake by crop over time (kg N ha-1) from soil and by biological fixation
      nuptt = nuptt + nuptr * delt
      nfixtt = nfixtt + nfixtr * delt

      ! actual N amount in various living organs and total living N amount(kg N ha-1)
      anlv = max(0.0d0, (anlv + rnlv * delt))
      anst = max(0.0d0, (anst + rnst * delt))
      anrt = max(0.0d0, (anrt + rnrt * delt))
      anso = anso + rnso * delt

      ! N losses from leaves, roots and stems due to senescence and total N loss (kg N ha-1)
      nlossl = nlossl + rnldlv * delt
      nlossr = nlossr + rnldrt * delt
      nlosss = nlosss + rnldst * delt

      ! increment values of dead weight of plant organs to be used in the soil nutrient submodel
      idwrt = drrt * delt
      idwlv = fradeceasedlvtosoil * drlv * delt
      idwst = 0.d0
      idwso = 0.d0

      inlossr = rnldrt * delt
      inlossl = fradeceasedlvtosoil * rnldlv * delt
      nlosslDeceasedLvToSoil = nlosslDeceasedLvToSoil + inlossl
      nlossl = nlossl - inlossl
      inlosss = 0.d0
      iNLOSSO = 0.d0
      HarLosOrm_rt = 0.d0; HarLosOrm_lv = 0.d0; HarLosOrm_st = 0.d0
      HarLosOrm_dwlv = 0.d0; HarLosOrm_dwst = 0.d0
      HarLosOrm_so = 0.d0
      HarLosNit_rt = 0.d0; HarLosNit_lv = 0.d0 
      HarLosNit_st = 0.d0; HarLosNit_so = 0.d0 

      HarLosNit_dwst = 0.d0; HarLosNit_dwlv = 0.d0 

      ! during the last day of the crop period: add the weight of living roots to the dead roots and reset living weight to zero
      if (fl_cropharvest) then
            HarLosOrm_rt = wrt
            HarLosOrm_dwlv = FraHarLosOrm_lv * dwlv
            HarLosOrm_lv = FraHarLosOrm_lv * wlv + HarLosOrm_dwlv
            HarLosOrm_dwst = FraHarLosOrm_st * dwst
            HarLosOrm_st = FraHarLosOrm_st * wst + HarLosOrm_dwst
            HarLosOrm_so = FraHarLosOrm_so * wso

            !ckro_sup_20170714 : suppressed because it will happen after harvest
            ! wrt = wrt - HarLosOrm_rt
            ! wlv = wlv - FraHarLosOrm_lv * wlv
            ! wst = wst - FraHarLosOrm_st * wst
            ! wso = wso - FraHarLosOrm_so * wso
            idwrt = idwrt + HarLosOrm_rt
            idwlv = idwlv + HarLosOrm_lv
            idwst = idwst + HarLosOrm_st
            idwso = idwso + HarLosOrm_so
            HarLosNit_rt = anrt
            HarLosNit_dwlv = FraHarLosOrm_lv * NLOSSL 
            HarLosNit_lv = FraHarLosOrm_lv * anlv + HarLosNit_dwlv 
            HarLosNit_dwst = FraHarLosOrm_st * NLOSSS 
            HarLosNit_st = FraHarLosOrm_st * anst + HarLosNit_dwst 
            HarLosNit_so = FraHarLosOrm_so * anso
            
            inlossl = inlossl + HarLosNit_lv
            inlosss = inlosss + HarLosNit_st
            inlosso = inlosso + HarLosNit_so
            inlossr = inlossr + HarLosNit_rt
            
            anlv = anlv - FraHarLosOrm_lv * anlv
            anst = anst - FraHarLosOrm_st * anst
            anso = anso - FraHarLosOrm_so * anso
            anrt = anrt - HarLosNit_rt
        end if

        ! check and write mass balance: nitrogen of crop

        NBALAN =  NUPTT + NFIXTT + (ANLVI+ANSTI+ANRTI+ANSOI)            &
            - (ANLV+ANST+ANRT+ANSO) - (NLOSSL+NLOSSR+NLOSSS)            &
            - NLOSSLDeceasedLvToSoil                                    &
            - (HarLosNit_lv+HarLosNit_st+HarLosNit_so+HarLosNit_rt)     &
            +  HarLosNit_dwlv + HarLosNit_dwst

        ! output of N balance
        call outbalcropN(2,NBALAN)
        
        if (dabs(NBALAN) >= 1.0d-03) then
           write(message,'(1a,i6,a,f8.3)') ' Nitrogen balance not 0, simulation stopped, day = ', daycum,' NBAL=',NBALAN
           call swap_warning ('wofost', message)
        end if
 
        if (fl_cropharvest) then
          NdemandSoil = 0.0d0
        end if
      
      return
   
   end subroutine update_wofost_nut
   
   ! ---------------------------------------------------------------------
   
   subroutine demand_wofost_nut (reltr)
      ! ------------------------------------------------------------------
      ! update state variables for nutrient stress
      ! ------------------------------------------------------------------
      use plant_interface,       only: dvs, wrt, wst, wlv, wso
      use wofost_soil_interface, only: NdemandSoil
      
      implicit none
      
      real(8), intent(in) :: reltr
      real(8) :: nlimit
      
      ! ------------------------------------------------------------------

      ! N demand of leaves, roots and stem storage organs (kg N ha-1 d-1)
      ndeml = max (nmaxlv * wlv - anlv, 0.d0)
      ndems = max (nmaxst * wst - anst, 0.d0)
      ndemr = max (nmaxrt * wrt - anrt, 0.d0)
      ndemso = max (nmaxso * wso - anso, 0.d0) / tcnt
      
      ! total N demand (kg N ha-1)
      ndemto = max (0.d0, (ndemr + ndems + ndeml))

      ! nutrient uptake limiting factor (-) at low moisture conditions in the 
      ! rooted soil layer before anthesis. After anthesis/DVSNLT there is no
      ! nutrient uptake from the soil
      nlimit = 0.d0
      if (dvs - dvsnlt < 0.d0 .AND. reltr - 0.01d0 > 0.d0) then
        nlimit = 1.d0
      end if
      NdemandSoil = (1.d0 - nfixf) * ndemto * nlimit
      NdemandBioFix = nfixf * ndemto * nlimit

      return

   end subroutine demand_wofost_nut

   ! ---------------------------------------------------------------------

   subroutine nutrie ()
      ! ------------------------------------------------------------------
      use plant_interface, only: dvs, wst, wlv
      
      implicit none
      
      real(8) :: tbgmr, noptmr, nupgmr, nrmr, nfgmr
      real(8), parameter :: tiny = 0.001d0
      
      ! function
      real(8) :: afgen
      ! ------------------------------------------------------------------

      ! vegetative living above-ground biomass (kg DM ha-1)
      tbgmr = wlv + wst     
        
      ! maximum N concentration in the leaves, from which the N conc. in the
      ! stems and roots are derived, as a function of development stage (kg N kg-1 DM)  
      nmaxlv = afgen (nmxlv, macroptb, dvs)
      
      ! maximum N concentrations in stems and roots (kg N kg-1 DM)
      nmaxst = lsnr * nmaxlv
      nmaxrt = lrnr * nmaxlv

      ! maximum N crop concentration organs (kg N kg-1 DM)
      noptmr = noptm ()

      ! total N in vegetative living above-ground biomass (kg N ha-1)
      nupgmr = anlv + ANST
      
      ! N concentration in total vegetative living per kg above-ground biomass  (kg N kg-1 DM) 
      nfgmr  = 1.0d-5
      if (tbgmr > 1.0d-5)  nfgmr = nupgmr / tbgmr

      ! residual N concentration in total vegetative living above-ground biomass  (kg N kg-1 DM) 
      nrmr = 1.0d-5
      if (tbgmr > 1.0d-5)  nrmr = (wlv * rnflv + wst * rnfst) / tbgmr

      ! nutrient stress factor           
      nni = tiny
      if ((noptmr - nrmr) > 1.d-5)  then
        nni = max(tiny, min(1.d0, ((nfgmr - nrmr) / (noptmr - nrmr))))
      end if

      ! nutrient reduction factor     
      fstr = max(0.d0, min(1.d0, (1.d0 - nlue * (1.0001d0 - nni)**2)))
      
      return

   end subroutine nutrie
   
   ! ---------------------------------------------------------------------

   real(8) function noptm ()
      
      ! ------------------------------------------------------------------
      ! compute the maximum N crop concentration organs (kg N kg-1 DM)
      ! ------------------------------------------------------------------
      
      use plant_interface, only: wst, wlv
      
      implicit none

      real(8) :: noptl, nopts, tbgmr
      
      ! ------------------------------------------------------------------
      
      ! total vegetative living above-ground biomass (kg DM ha-1)     
      tbgmr = wlv + wst 
      
      ! optimal N amount in vegetative above-ground living biomass and its N concentration
      noptl = frnx * nmaxlv * wlv
      nopts = frnx * nmaxst * wst

      noptm = 1.0d-5
      if (tbgmr > 1.0d-5) noptm = (noptl + nopts) / tbgmr
      
      return

   end function noptm
   
   ! ---------------------------------------------------------------------


! ----------------------------------------------------------------------
      subroutine outbalcropN(task, nbalan) 
! ----------------------------------------------------------------------
!     Date               : March 2015  
!     Purpose            : open and write crop output N balance files 
! ----------------------------------------------------------------------
      use MOD_swap_base, only: iun_min, iun_max, pathwork, project
      use plant_interface, only: dvs, tsum
      use variables, only: outfil, date, t
      implicit none

! --- global variables ------------------
      integer,           intent(in) :: task
      real(8),           intent(in) :: nbalan
!      real(8) cwdmpot,cwdm,wsopot,wso,wstpot,wst,wlvpot,wlv,wrtpot,wrt
! --- local variables ------------------
      character(len=1) comma
!      character(len=200) messag
      integer   getun,nba
      character(len=160) filnam,filtext

      save    nba

      comma = ',' 
    
      select case (task)
      case (1)

! === open output file and write headers =====================

      filnam = trim(pathwork)//trim(outfil)//'.nba'
      nba = getun (iun_min, iun_max)
      call fopens(nba,filnam,'new','del')
      filtext = 'output of N-balance of detailed crop growth model'
      call writehead (nba,1,filnam,filtext,project)

      write (nba,100)
 100    format ('*',/,                                                  &
       '*             day      -    grC   kg/ha   kg/ha   kg/',         &
       'ha   kg/ha   kg/ha   kg/ha   kg/ha   kg/ha   kg/ha   kg/ha   ', &
       'kg/ha   kg/ha   kg/ha  kg/ha',/,                                &
       '      Date, Daynr, Daycrp,   DVS,  TSUM,  NUPTT, NFIXTT,  ANLVI'&
       ,',  ANSTI,  ANRTI,  ANSOI,   ANLV,   ANST,   ANRT',             &
       ',   ANSO, NLOSSL, NLOSSR, NLOSSS, NBALAN, NNI')
      return

      case (2)
! --- write dynamic data ----------------------------------------------------
      write (nba,200) date,comma,nint(t),comma,dvs,comma,               &
       tsum,comma,NUPTT,comma,NFIXTT,comma,ANLVI,comma,ANSTI,comma,     &
       ANRTI,comma,ANSOI,comma,ANLV,comma,ANST,comma,ANRT,comma,        &
       ANSO,comma,NLOSSL,comma,NLOSSR,comma,NLOSSS,comma,NBALAN,        &
       comma,NNI
 200  format (a11,a1,i5,a1,f6.2,a1,f6.0, 15(a1,f7.2) )

      return

      case (3)
! --- close crop output file ------------------------------------------------

      close (nba)

      case default
         call swap_error ('outbalcropn', 'Illegal value for TASK')
      end select

      return
      end subroutine outbalcropN

end module MOD_wofost_nut