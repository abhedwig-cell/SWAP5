import hashlib,io,json,subprocess,tarfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'SWAP5-MIGRATION-CONTINUE'
ART=ROOT.parent/'native-coupled-linux-artifacts'
sha=lambda b:hashlib.sha256(b).hexdigest()
entries=json.loads((ART/'DOWNLOADS.json').read_text(encoding='utf-8'))
assert len(entries)==4,'all four latest artifacts required'
tree={line.split('\t',1)[1]:line.split()[2] for line in subprocess.check_output(['git','ls-tree','-r','HEAD'],cwd=ROOT,text=True).splitlines()}
files={};reports={};observations={}
for item in entries:
 a=item['artifact'];p=ART/item['zip_file'];assert 'sha256:'+sha(p.read_bytes())==a['digest']
 opt=a['name'][-2:].lower();component='component' in a['name'];label=('component-' if component else 'native-')+opt
 with zipfile.ZipFile(p) as z:raw={name:z.read(name) for name in z.namelist() if not name.endswith('/')}
 if component:
  payload={name.removeprefix('feedback-component-ci/'):value for name,value in raw.items() if name.startswith('feedback-component-ci/')}
 else:payload=raw
 r=json.loads(payload['RESULT.json']);reports[label]=r
 for path,blob in r.get('source_git_blob',r.get('sources',{})).items():assert tree[path]==blob,path
 assert r['baseline']=='6966ab6a837abd9cb2a44436f8273fd0b0697348'
 assert r['status']==('PASS' if component else 'CORRECTED_NATIVE_SUBSTEP_HEAT_HISTORY_FULL_HALF_AND_DISK_ACCEPTED')
 for name,data in payload.items():
  if name.endswith(('.o','.mod','.tmp')):continue
  if name.startswith('build/') and name not in ['build/native.exe','build/legacy_swp_original.f90']:continue
  if name.startswith('original/') and not name.endswith(('.json','.stdout','.stderr')):continue
  files[label+'/'+name]=data
 if component:
  assert r['compile_closure']==11 and sha(payload['component.exe'])==r['executable_sha256']
  assert 'ADAPTIVE_COMPLETE_WINDOW_AND_LATE_FAILURE_ROLLBACK_PASS' in r['stdout']
  observations[label]=dict(status=r['status'],measurement_commit=r['baseline'],fortran_closure=11,c_publisher_objects=1,events=r['events'])
  continue
 cert=json.loads(payload['COMPILED_INPUTS.json']);assert len(cert)==207 and not any(e['reused'] for e in cert)
 for i,e in enumerate(cert):
  rel=e['source'].split('/home/runner/work/SWAP5/SWAP5/',1)[1]
  if rel.startswith('native-coupled-ci/'):data=payload[rel.removeprefix('native-coupled-ci/')]
  else:data=subprocess.check_output(['git','cat-file','blob',r['source_git_blob'][rel]],cwd=ROOT)
  assert sha(data)==e['source_sha256'],rel
  files[label+'/compiled-source/'+str(i)+'.f90']=data
 assert sha(payload['build/native.exe'])==r['executable_sha256']
 assert payload['contact-0/origin.bin']==payload['contact-0/diagnostic-rejected.bin']==payload['contact-1/diagnostic-rejected.bin']
 observations[label]=dict(status=r['status'],measurement_commit=r['baseline'],compiler=r['compiler'],fortran_closure=207,ttutil_fortran_providers=153,reused_objects=r['reused_objects'],events=r['events'],transaction_rows=[row for row in r['native_transaction_rows'] if row.startswith(('TRANSACTION','WINDOW','REVISION'))])
for name in ['contact-1/native-coupled-transaction.csv','contact-1/coupled-contact.csv']:
 assert files['native-o0/'+name]==files['native-o2/'+name],name
with tarfile.open(ROOT/'integration/dataqual15/NATIVE_COUPLED_WINDOWS_EVIDENCE_20261103.tar.xz') as t:
 windows=t.extractfile('native-o0/contact-1/native-coupled-transaction.csv').read()
assert windows.replace(b'\r\n',b'\n')==files['native-o0/contact-1/native-coupled-transaction.csv'].replace(b'\r\n',b'\n')
files['CAPTURE_SCRIPT.py']=Path(__file__).read_bytes()
files['MANIFEST.json']=(json.dumps({name:sha(data) for name,data in files.items()},indent=2)+'\n').encode()
archive=ROOT/'integration/dataqual15/NATIVE_COUPLED_LINUX_EVIDENCE_20261103.tar.xz'
with tarfile.open(archive,'w:xz') as t:
 for name,data in sorted(files.items()):
  m=tarfile.TarInfo(name);m.size=len(data);t.addfile(m,io.BytesIO(data))
r=dict(run_id=41688523556,qualified_head='819334f70fc13b62c4a9e44863e76f63ed38272d',tested_merge='6966ab6a837abd9cb2a44436f8273fd0b0697348',archive=archive.relative_to(ROOT).as_posix(),archive_sha256=sha(archive.read_bytes()),artifacts=[e['artifact'] for e in entries],observations=observations,windows_linux_native_transaction_text_exact_after_newline_normalization=True,linux_O0_O2_transaction_bytes_exact=True,original_outer_interval_accepted=False,full_energy_balance_complete=False)
(ROOT/'integration/dataqual15/NATIVE_COUPLED_LINUX_EVIDENCE_20261103.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8',newline='\n')
print('SEALED_LINUX_NATIVE_O0_O2_AND_REAL_CONTRACTS',archive.stat().st_size)
