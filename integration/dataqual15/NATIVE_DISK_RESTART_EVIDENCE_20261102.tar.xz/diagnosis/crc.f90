program probe
use iso_fortran_env,only:int8,int32
implicit none
integer(int8),allocatable::bytes(:)
integer::u,n
character(2048)::path
call get_command_argument(1,path)
inquire(file=trim(path),size=n)
allocate(bytes(n))
open(newunit=u,file=trim(path),access='stream',form='unformatted',status='old')
read(u)bytes
close(u)
write(*,'(z8.8)')crc32(bytes)
contains
  function crc32(bytes) result(crc)
    integer(int8),intent(in)::bytes(:)
    integer(int32)::crc
    integer::i,j
    crc=not(0_int32)
    do i=1,size(bytes)
      crc=ieor(crc,iand(int(bytes(i),int32),int(z'FF',int32)))
      do j=1,8
        if(btest(crc,0))then
          crc=ieor(shiftr(crc,1),int(z'EDB88320',int32))
        else
          crc=shiftr(crc,1)
        end if
      end do
    end do
    crc=not(crc)
  end function
end program
