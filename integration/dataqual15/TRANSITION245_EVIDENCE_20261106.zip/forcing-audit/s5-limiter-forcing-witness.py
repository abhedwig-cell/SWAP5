exec((__import__('pathlib').Path(__import__('os').environ['TEMP'])/'s5-limiter-forcing-audit.py').read_text().split('daily=list',1)[0])
from decimal import Decimal,localcontext
finish=float(list(csv.DictReader((run/'budget.csv').open()))[-1]['t1']);idx=0;trueidx=0;cases=[]
with localcontext()as ctx:
 ctx.prec=120;total=Decimal(0)
 for row in csv.DictReader((run/'progress.csv').open()):
  t0=float(row['t0']);t1=float(row['t1'])
  if t1>finish:break
  while idx<count-1 and ends[idx]<=t0+1e-12:idx+=1
  while trueidx<count-1 and ends[trueidx]<=t0:trueidx+=1
  local=trueidx;cursor=t0;parts=[];expected=Decimal(0)
  while cursor<t1:
   endpoint=min(t1,ends[local]);assert endpoint>cursor
   expected+=Decimal.from_float(rates[local])*(Decimal.from_float(endpoint)-Decimal.from_float(cursor));parts.append([cursor,endpoint,rates[local]]);cursor=endpoint
   if cursor<t1:local+=1
  native=Decimal.from_float(rates[idx])*(Decimal.from_float(t1)-Decimal.from_float(t0));difference=native-expected
  if difference:
   total+=difference;cases.append(dict(t0=t0,t1=t1,caller_rain_index=idx+1,true_rain_index=trueidx+1,caller_rate=rates[idx],parts=parts,difference_cm=str(difference),last_committed_rain_event=ends[trueidx]))
 report=dict(scope='EXACT_INPUT_RAIN_VS_ACTUAL_CALLER_PHASE_ASSIGNMENT',complete_through=finish,nonzero_cases=len(cases),difference_cm=str(total),cases=cases)
(root/'s5-limiter-forcing-witness.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='cases'}));print(json.dumps(sorted(cases,key=lambda r:abs(Decimal(r['difference_cm'])),reverse=True)[:8],indent=2))
