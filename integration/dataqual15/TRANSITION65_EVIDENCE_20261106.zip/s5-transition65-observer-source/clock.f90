module mod_entry_observation_clock
real(8)::obs_last_t0=0d0,obs_last_t1=0d0
end module
