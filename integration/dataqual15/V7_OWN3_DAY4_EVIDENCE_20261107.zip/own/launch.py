from pathlib import Path
import os,json,time,subprocess,sys,hashlib
root=Path(r"C:\Users\Veldh012\AppData\Local\Temp\s5-andelst-joint-entry-20261106")
temp=Path(os.environ['TEMP']); full=temp/'s5-connectivity-final-original481-O2'; captures=temp/'s5-connectivity-final-captured-own-O2'; own=temp/'s5-connectivity-final-own3-4-O2'
while not(captures/'4/restart.bin').exists():
 if(full/'RESULT.json').exists():
  print('PRIMARY_TERMINAL_BEFORE_OWN4',flush=True);sys.exit(2)
 time.sleep(1)
assert(captures/'3/restart.bin').exists()
command=[sys.executable,'-B','tests/dataqual15/continue_joint_entry.py','--bundle',str(temp/'s5-connectivity-final-water-O2'),'--restart',str(captures/'3/restart.bin'),'--output',str(own),'--end','4','--seconds','900','--quiet-stages']
r=subprocess.run(command,cwd=root);assert r.returncode==0
result=json.loads((own/'RESULT.json').read_text());assert result['returncode']==0 and not result['censored'] and result['completed_days']==4
fullrows=(full/'progress.csv').read_text().splitlines();ownrows=(own/'progress.csv').read_text().splitlines()[1:];lookup={line.split(',')[2].strip():line for line in fullrows[1:]};assert ownrows and all(lookup.get(line.split(',')[2].strip())==line for line in ownrows)
assert(own/'restart.bin').read_bytes()==(captures/'4/restart.bin').read_bytes()
receipt=dict(scope='STRICT_CURRENT_EXECUTABLE_OWN3_TO4',seconds=result['seconds'],executable_sha256=result['executable_sha256'],input_restart_sha256=result['strict_own_restart_sha256'],all_progress_rows_exact=True,progress_rows=len(ownrows),entire_checkpoint4_byte_exact=True,checkpoint4_sha256=hashlib.sha256((own/'restart.bin').read_bytes()).hexdigest(),same_input_binding=True,historical_original_equivalence=False)
(own/'EXACT_COMPARISON.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
