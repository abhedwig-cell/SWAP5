module mod_b111_profile_groundwater_projection
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  use, intrinsic :: iso_fortran_env, only: real64
  implicit none
  private

  integer, parameter, public :: B111_PROFILE_GWL_INVALID = 0
  integer, parameter, public :: B111_PROFILE_GWL_INTERIOR = 1
  integer, parameter, public :: B111_PROFILE_GWL_FULLY_SATURATED = 2
  integer, parameter, public :: B111_PROFILE_GWL_BELOW_PROFILE = 3

  type, public :: b111_profile_groundwater_projection_t
    integer :: status = B111_PROFILE_GWL_INVALID
    integer :: crossing_lower_node = 0
    logical :: valid = .false.
    logical :: level_present = .false.
    real(real64) :: level_cm = 0.0_real64
  end type b111_profile_groundwater_projection_t

  public :: evaluate_b111_profile_groundwater_projection, evaluate_b111_pore_volume_connectivity

contains

  pure subroutine evaluate_b111_profile_groundwater_projection(z, node_distance, pressure_head, ponding_depth, result)
    real(real64), intent(in) :: z(:), node_distance(:), pressure_head(:), ponding_depth
    type(b111_profile_groundwater_projection_t), intent(out) :: result

    integer :: n, node, lower
    real(real64) :: denominator

    result = b111_profile_groundwater_projection_t()
    n = size(pressure_head)
    if (n < 2 .or. size(z) /= n .or. size(node_distance) /= n) return
    if (any(.not. ieee_is_finite(z)) .or. any(.not. ieee_is_finite(node_distance)) .or. &
        any(.not. ieee_is_finite(pressure_head)) .or. .not. ieee_is_finite(ponding_depth)) return
    if (any(node_distance(2:n) <= 0.0_real64) .or. ponding_depth < 0.0_real64) return

    ! Literal active CALCGWL option-1 value semantics. Keep the historical
    ! below-profile sentinel out of the typed result: absence is explicit.
    if (pressure_head(n) < 0.0_real64) then
      result%status = B111_PROFILE_GWL_BELOW_PROFILE
      result%valid = .true.
      return
    end if

    lower = 0
    do node = n - 1, 1, -1
      if (pressure_head(node) < 0.0_real64) then
        lower = node
        exit
      end if
    end do

    if (lower == 0) then
      result%status = B111_PROFILE_GWL_FULLY_SATURATED
      result%valid = .true.
      result%level_present = .true.
      if (pressure_head(1) > 0.0_real64) then
        if (ponding_depth == 0.0_real64) then
          result%level_cm = min(z(1) + pressure_head(1), ponding_depth)
        else
          result%level_cm = ponding_depth
        end if
      else
        result%level_cm = 0.0_real64
      end if
      return
    end if

    denominator = pressure_head(lower+1) - pressure_head(lower)
    if (.not. ieee_is_finite(denominator) .or. denominator <= 0.0_real64) return
    result%level_cm = z(lower+1) + pressure_head(lower+1) * node_distance(lower+1) / denominator
    if (.not. ieee_is_finite(result%level_cm)) return
    result%status = B111_PROFILE_GWL_INTERIOR
    result%crossing_lower_node = lower
    result%valid = .true.
    result%level_present = .true.
  end subroutine evaluate_b111_profile_groundwater_projection

  ! Private research closure for a positive upper pressure region and a
  ! bottom saturated region. Disconnection weights consume the configured
  ! physical pore deficit from depth upward. A vanishing layer has zero
  ! weight, so it cannot move the drainage level by whole compartments.
  pure subroutine evaluate_b111_pore_volume_connectivity(z,distance,dz,head,theta,theta_s,pond,critical,projection)
    real(real64),intent(in)::z(:),distance(:),dz(:),head(:),theta(:),theta_s(:),pond,critical
    type(b111_profile_groundwater_projection_t),intent(out)::projection
    type(b111_profile_groundwater_projection_t)::connected
    real(real64)::remaining,gap,amount,crossing,lower_head,level_delta,upper_support
    integer::n,j
    call evaluate_b111_profile_groundwater_projection(z,distance,head,pond,projection)
    if(.not.projection%valid.or..not.projection%level_present)return
    n=size(head)
    if(n<3.or.head(1)<=0.0_real64.or.projection%crossing_lower_node<=1)return
    if(size(theta)/=n.or.size(theta_s)/=n.or.size(dz)/=n)then
      projection=b111_profile_groundwater_projection_t();return
    end if
    if(.not.ieee_is_finite(critical).or.any(.not.ieee_is_finite(theta)).or. &
       any(.not.ieee_is_finite(theta_s)).or.any(.not.ieee_is_finite(dz)).or.any(dz<=0.0_real64))then
      projection=b111_profile_groundwater_projection_t();return
    end if
    if(critical<=0.0_real64)return
    call evaluate_b111_profile_groundwater_projection(z,distance,max(head,0.0_real64),pond,connected)
    if(.not.connected%valid.or..not.connected%level_present)then
      projection=b111_profile_groundwater_projection_t();return
    end if
    remaining=critical;level_delta=0.0_real64
    do j=projection%crossing_lower_node,2,-1
      if(head(j)>=0.0_real64)cycle
      gap=dz(j)*max(0.0_real64,theta_s(j)-theta(j))
      if(gap<=0.0_real64)cycle
      if(j==projection%crossing_lower_node.and.gap>=critical)return
      amount=min(remaining,gap)
      lower_head=max(0.0_real64,head(j+1))
      crossing=z(j+1)+lower_head*distance(j+1)/(lower_head-head(j))
      level_delta=level_delta+(amount/critical)*(crossing-connected%level_cm)
      remaining=remaining-amount
      if(remaining<=0.0_real64)exit
    end do
    ! If only the uppermost node is wet, use its linearly interpolated
    ! saturated support toward the next node. It vanishes continuously
    ! at h(1)=0 when the next resolved compartment remains unsaturated.
    upper_support=1.0_real64
    if(head(2)<0.0_real64)upper_support=head(1)/(head(1)-head(2))
    projection%level_cm=projection%level_cm+upper_support* &
      ((connected%level_cm-projection%level_cm)+level_delta)
    if(.not.ieee_is_finite(projection%level_cm))projection=b111_profile_groundwater_projection_t()
  end subroutine evaluate_b111_pore_volume_connectivity


end module mod_b111_profile_groundwater_projection
