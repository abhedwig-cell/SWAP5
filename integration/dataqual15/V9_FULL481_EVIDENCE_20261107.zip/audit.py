from pathlib import Path
import os,json,csv,re,math
from decimal import Decimal,localcontext
import sys,hashlib
root=Path(os.environ.get('TEMP','/tmp'));run=Path(sys.argv[1]).resolve()if len(sys.argv)>1 else root/'s5-phase-exact-tiny-drain-original481-O2';text=(run/'input.nml').read_text();section=text.lower().split('&rain_events',1)[1].split('/',1)[0]
count=int(re.search(r'rain_count\s*=\s*(\d+)',section).group(1));ends=[float(x)for x in re.search(r'rain_ends\s*=(.*?)rain_rates\s*=',section,re.S).group(1).replace('d','e').split(',')if x.strip()];rates=[float(x)for x in section.split('rain_rates=',1)[1].replace('d','e').split(',')if x.strip()];assert len(ends)==len(rates)==count and all(b>a for a,b in zip([0.0]+ends[:-1],ends))
daily=list(csv.DictReader((run/'budget.csv').open()));finish=float(daily[-1]['t1']);amounts=[];idx=0;clock=0.0;windows=0
with localcontext()as ctx:
 ctx.prec=120;native=Decimal(0);expected=Decimal(0);expected_rounded=[]
 for row in csv.DictReader((run/'progress.csv').open()):
  t0=float(row['t0']);t1=float(row['t1'])
  if t1>finish:break
  assert t0==clock and t1>t0,(clock,t0,t1)
  while idx<count-1 and ends[idx]<=t0:idx+=1
  assert t1<=ends[idx],(t0,t1,ends[idx])
  native+=Decimal.from_float(rates[idx])*(Decimal.from_float(t1)-Decimal.from_float(t0));amounts.append(rates[idx]*(t1-t0));clock=t1;windows+=1
 assert clock==finish
 previous=0.0
 for end,rate in zip(ends,rates):
  clipped=min(end,finish)
  if clipped>previous:
   expected+=Decimal.from_float(rate)*(Decimal.from_float(clipped)-Decimal.from_float(previous));expected_rounded.append(rate*(clipped-previous))
  if end>=finish:break
  previous=end
 difference=native-expected
 report=dict(scope='INDEPENDENT_PREPARED_RAIN_INTEGRAL_AND_ACTUAL_CALLER_WINDOW_ALLOCATION_NOT_WHOLE_ENERGY_OR_REFERENCE_PARITY',completed_through=finish,continuous_time_coverage=True,no_source_interval_crosses_rain_phase=True,source_windows=windows,prepared_rain_events=count,exact_binary_input_mathematical_integral_cm=str(expected),exact_binary_window_allocation_integral_cm=str(native),exact_integral_difference_cm=str(difference),integrals_exact=difference==0,rounded_native_amount_sum_cm=math.fsum(amounts),rounded_input_phase_sum_cm=math.fsum(expected_rounded),rounded_sum_difference_cm=math.fsum(amounts)-math.fsum(expected_rounded),new_tolerance_introduced=False)
launch=json.loads((run/'LAUNCH.json').read_text());input_hash=hashlib.sha256((run/'input.nml').read_bytes()).hexdigest();assert input_hash==launch['original_input_sha256']['input.nml'];report.update(input_nml_sha256=input_hash,supplied_progress_file_sha256=hashlib.sha256((run/'progress.csv').read_bytes()).hexdigest(),declared_executable_sha256=launch['executable_sha256'])
print(json.dumps(report,indent=2))
if finish==481:(run/'FORCING_INTEGRAL_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
