"""Terminal-only receipt for the actual corrected original-input execution.

Does not edit a native stream, binding, numerical setting or source file.
"""
from pathlib import Path
import csv, hashlib, json, math, os, subprocess, sys, zipfile, re
from datetime import date, timedelta

root = Path(r'C:\Users\Veldh012\AppData\Local\Temp\s5-andelst-joint-entry-20261106')
temp = Path(os.environ['TEMP'])
full = temp / 's5-upper-support-final-original481-O2'
capture = temp / 's5-upper-support-final-captured-own-O2'
bundle = temp / 's5-upper-support-final-water-O2'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text(encoding='utf8'))
r = load(full / 'RESULT.json')
assert r['returncode'] == 0 and not r['censored']
assert r['original_initialization'] and r['completed_days'] == 481
assert r['full_corrected_complete'] and not r['full_original_complete']
assert not r['historical_original_equivalence']
assert r['executable_sha256'] == '093461e1effeef763f72ccc5592a7f7d8c7ac29516c4dd900be93a82e9104501'

build = load(bundle / 'BUILD.json')
assert build['executable_sha256'] == r['executable_sha256']
assert sha(bundle / 'swap5_hupsel_germination.exe') == r['executable_sha256']
assert build['provider_count'] == len(build['source_sha256']) == 202
for name, digest in build['source_sha256'].items():
    assert sha(Path(name)) == digest, name
assert sha(Path(build['ttutil_archive'])) == build['archive_sha256']
pub = build['publication_provider']
assert sha(Path(pub['source'])) == pub['source_sha256']
assert sha(Path(pub['object'])) == pub['object_sha256']
for name, digest in r['original_input_sha256'].items():
    assert sha(full / name) == digest, name
binding = hashlib.sha256(b''.join((full / n).read_bytes() for n in
    ('input.nml', 'input.swp', 'macro.nml')) + r['executable_sha256'].encode()).hexdigest()
assert r['command'][2] == '-' and r['command'][6] == binding == 'e4c7bf6cead265c45a10228fdea1a965db948177f75ee407f00d8db3cc13c91d'
for name, digest in r['files_sha256'].items():
    assert sha(full / name) == digest, name
assert (full / 'input.swp').read_bytes() == (root / 'reference/swap-4.3.1/projects/3.macroporeflow/swap.swp').read_bytes()

swp=(full/'input.swp').read_text()
start_date=date.fromisoformat(re.search(r'(?m)^\s*TSTART\s*=\s*(\d{4}-\d{2}-\d{2})',swp).group(1))
end_date=date.fromisoformat(re.search(r'(?m)^\s*TEND\s*=\s*(\d{4}-\d{2}-\d{2})',swp).group(1))
assert (end_date-start_date).days+1==481
assert (date(1999,1,1)-start_date).days==365
daily = list(csv.DictReader((full / 'budget.csv').open()))
assert len(daily) == 481
for day, row in enumerate(daily, 1):
    assert int(row['day']) == day and float(row['t0']) == day-1 and float(row['t1']) == day
    assert all(math.isfinite(float(v)) for v in row.values())
progress = (full / 'progress.csv').read_text().splitlines()[1:]
assert progress and len(progress) == len(r['cost'])
clock = 0.0
for line, cost in zip(progress, r['cost']):
    row = line.split(',')
    t0, t1 = float(row[2]), float(row[3])
    assert t0 == clock and t1 > t0
    assert float(cost['t0']) == t0 and float(cost['t1']) == t1
    assert cost['completed'].strip() == 'T'
    clock = t1
assert clock == 481.0
assert (capture / '481/restart.bin').read_bytes() == (full / 'restart.bin').read_bytes()

lookup = {line.split(',')[2].strip(): line for line in progress}
owns = {}
for window in ['3-4', '256-257', '300-301', '365-367']:
    first, last = map(int, window.split('-'))
    d = temp / ('s5-upper-support-final-own' + window + '-O2')
    native, receipt = load(d / 'RESULT.json'), load(d / 'EXACT_COMPARISON.json')
    assert native['returncode'] == 0 and not native['censored'] and native['completed_days'] == last
    assert native['executable_sha256'] == receipt['executable_sha256'] == r['executable_sha256']
    assert native['strict_own_restart_sha256'] == receipt['input_restart_sha256'] == sha(capture / str(first) / 'restart.bin')
    assert native['original_input_sha256'] == r['original_input_sha256']
    assert Path(native['command'][2]).resolve() == (capture / str(first) / 'restart.bin').resolve()
    assert native['command'][6] == binding
    for name, digest in native['files_sha256'].items():
        assert sha(d / name) == digest, name
    lines = (d / 'progress.csv').read_text().splitlines()[1:]
    assert lines and all(lookup.get(line.split(',')[2].strip()) == line for line in lines)
    assert len(lines) == receipt['progress_rows']
    assert (d / 'restart.bin').read_bytes() == (capture / str(last) / 'restart.bin').read_bytes()
    owns[window] = receipt

audit_script = temp / 's5-exact-source-phase-audit.py'
audit_process = subprocess.run([sys.executable, '-B', str(audit_script), str(full)], capture_output=True, text=True, check=True)
audit = json.loads(audit_process.stdout)
assert audit['completed_through'] == 481 and audit['integrals_exact']
assert audit['source_windows'] == len(progress)
assert audit['declared_executable_sha256'] == r['executable_sha256']
assert audit['supplied_progress_file_sha256'] == sha(full / 'progress.csv')

record_path = root / 'integration/dataqual15/TRANSITION65_RECOVERY_20261106.json'
record = load(record_path)
cur = record['current_execution']
assert cur['executable_sha256'] == r['executable_sha256']
cur.update(status='COMPLETE_CORRECTED_ORIGINAL_INPUT481_AND_EXACT_OWN_YEAR',
    whole481=True, own3_to4=True, own256_to257=True, own300_to301=True, own365_to367=True, completed_days=481, seconds=r['seconds'],
    returncode=0, censored=False, original_input_files_unchanged=True,
    maximum_daily_water_residual_cm=max(abs(float(x['water_residual_cm'])) for x in daily),
    sum_daily_water_residuals_cm=math.fsum(float(x['water_residual_cm']) for x in daily),
    source_intervals=len(progress), all_source_intervals_completed=True,
    unchanged_numerical_controls=r['numerical_controls_observed'],
    own_restarts=owns, independent_original_rain_integral=audit,
    all202_actual_source_pins_exact=True, publication_and_ttutil_pins_exact=True,
    whole_science=False, historical_original_equivalence=False,
    production_default_contact_law_admitted=False)
cur['native_cost_totals'] = {n: sum(int(x[n]) for x in r['cost']) for n in
    ['nonlinear_iterations','headcalc_calls','linear_solves','backtracking_attempts','accepted_substeps']}
cur['maximum_component_residuals_cm'] = {n: max(abs(float(x[n])) for x in daily) for n in
    ['max_macro_cell_cm','max_matrix_cm','max_combined_cm','max_net_source_cm']}
archive = root / 'integration/dataqual15/V9_FULL481_EVIDENCE_20261107.zip'
assert not archive.exists(), 'Never overwrite an immutable evidence archive'
manifest = {}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for folder in [full.name, capture.name] + ['s5-upper-support-final-own'+w+'-O2' for w in owns]:
        for p in sorted((temp / folder).rglob('*')):
            if p.is_file():
                name = folder + '/' + p.relative_to(temp / folder).as_posix()
                raw = p.read_bytes()
                manifest[name] = hashlib.sha256(raw).hexdigest()
                z.writestr(name, raw)
    for name, p in [('audit.py', audit_script), ('finalize.py', Path(__file__)), ('own-watch.py', temp/'s5-upper-support-own-watch.py')]:
        raw = p.read_bytes(); manifest[name] = hashlib.sha256(raw).hexdigest(); z.writestr(name, raw)
    raw=(json.dumps({k: record[k] for k in
        ['upper_support_v9_research','pore_volume_v8_research','v7_source300317_diagnosis']}, indent=2)+'\n').encode()
    manifest['SOURCE_BUNDLE_REFERENCES.json']=hashlib.sha256(raw).hexdigest()
    z.writestr('SOURCE_BUNDLE_REFERENCES.json',raw)
    z.writestr('MANIFEST_SHA256.json', json.dumps(manifest, indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(n)).hexdigest() == h for n,h in manifest.items())
record['v9_full481_evidence'] = dict(archive=archive.name, sha256=sha(archive), bytes=archive.stat().st_size, members=len(manifest)+1)
record['next_action'] = ('Corrected original-input481 and exact own3-4/256-257/300-301/365-367 execution gates closed. '
    'Admit this full execution receipt after actual canonical reconciliation and selected docs validation. '
    'Historical sharp-law equivalence, production-default graph admission and whole physical science remain separate.')
cur['own_year_calendar']={'original_start':str(start_date),'original_end_inclusive':str(end_date),'own365_start':str(start_date+timedelta(days=365)),'own367_end':str(start_date+timedelta(days=367))}
cur['next_action']=record['next_action']
v6=record['upper_support_v9_research']
v6.update(status='CORRECTED_ORIGINAL_INPUT481_AND_EXACT_OWN_YEAR_EXECUTION_COMPLETE',
          whole481=True,own_year=True,next_action=record['next_action'])
admission=v6.get('canonical_admission',{})
if 'full481_and_year_active_not_pass' in admission:
    admission['at_admission_full481_and_year_active_not_pass']=admission.pop('full481_and_year_active_not_pass')
record_path.write_text(json.dumps(record, indent=2)+'\n', encoding='utf8')
print(json.dumps({'current_execution':cur,'evidence':record['v9_full481_evidence']}, indent=2))
