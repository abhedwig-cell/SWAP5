from pathlib import Path
import os,json,time,subprocess,sys,hashlib
root=Path.cwd()
temp=Path(os.environ['TEMP']); prefix='s5-upper-support-final-'
full=temp/(prefix+'original481-O2'); captures=temp/(prefix+'captured-own-O2')
first,last,timeout=map(int,sys.argv[1:])
own=temp/(prefix+f'own{first}-{last}-O2')
while True:
 try: completed=json.loads((captures/'CAPTURES.json').read_text())['captures']
 except (FileNotFoundError,json.JSONDecodeError): completed={}
 if str(first) in completed and str(last) in completed:break
 if (full/'RESULT.json').exists():
  print(f'PRIMARY_TERMINAL_BEFORE_OWN{last}',flush=True);sys.exit(2)
 time.sleep(1)
command=[sys.executable,'-B','tests/dataqual15/continue_joint_entry.py','--bundle',str(temp/(prefix+'water-O2')),
 '--restart',str(captures/str(first)/'restart.bin'),'--output',str(own),'--end',str(last),'--seconds',str(timeout),'--quiet-stages']
r=subprocess.run(command,cwd=root); assert r.returncode==0
result=json.loads((own/'RESULT.json').read_text()); full_launch=json.loads((full/'LAUNCH.json').read_text())
assert result['returncode']==0 and not result['censored'] and result['completed_days']==last
assert result['executable_sha256']==full_launch['executable_sha256'] and result['command'][6]==full_launch['command'][6]
assert result['original_input_sha256']==full_launch['original_input_sha256']
lookup={line.split(',')[2].strip():line for line in (full/'progress.csv').read_text().splitlines()[1:] if line.count(',')==8}
ownrows=(own/'progress.csv').read_text().splitlines()[1:]
assert ownrows and all(lookup.get(line.split(',')[2].strip())==line for line in ownrows)
expected=(captures/str(last)/'restart.bin').read_bytes()
assert (own/'restart.bin').read_bytes()==expected
h=lambda b:hashlib.sha256(b).hexdigest()
assert h(expected)==completed[str(last)]['sha256']
assert result['strict_own_restart_sha256']==completed[str(first)]['sha256']
receipt=dict(scope=f'STRICT_CURRENT_EXECUTABLE_OWN{first}_TO{last}',seconds=result['seconds'],
 executable_sha256=result['executable_sha256'],input_restart_sha256=result['strict_own_restart_sha256'],
 all_progress_rows_exact=True,progress_rows=len(ownrows),entire_ending_checkpoint_byte_exact=True,
 ending_checkpoint_sha256=h(expected),same_input_binding=True,historical_original_equivalence=False)
(own/'EXACT_COMPARISON.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)

