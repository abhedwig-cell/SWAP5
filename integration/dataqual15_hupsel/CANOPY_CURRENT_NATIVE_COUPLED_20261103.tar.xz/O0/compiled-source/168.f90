module mod_ppa_wu05a16_inner_macropore_provider
  use, intrinsic :: iso_fortran_env, only: real64
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  use mod_soil_water_solver_contract, only: macropore_storage_coupling_provider_t, soil_water_physical_state_t
  use mod_macropore_continuation_state, only: macropore_continuation_state_t, copy_macropore_continuation_state
  use mod_ppa_wu05a5_multi_domain_process, only: macropore_geometry_config_t, macropore_geometry_result_t, &
       evaluate_macropore_geometry, evaluate_macropore_geometry_return
  use mod_macropore_dynamic_shrinkage, only: dynamic_shrinkage_config_t, evaluate_dynamic_crack_profile
  use mod_macropore_dynamic_shrinkage, only: find_dynamic_groundwater_cutoff
  use mod_macropore_standard_storage, only: macropore_standard_storage_view_t, derive_macropore_standard_storage_view
  use mod_ppa_wu05a6_rate_bundle, only: macropore_rate_bundle_request_t, macropore_rate_bundle_result_t, &
       evaluate_macropore_rate_bundle
  use mod_macropore_standard_rate_adapter, only: matrix_saturated_zone_view_t, &
       prepare_standard_macropore_rate_request
  use mod_ppa_wu05a15_exchange_derivative, only: macropore_exchange_derivative_result_t, &
       evaluate_macropore_exchange_derivative
  use mod_macropore_covering_layer_input, only: covering_layer_input_request_t, evaluate_covering_layer_input, &
       evaluate_covering_layer_rate_derivative
  use mod_fmr_macropore_top_input, only: fmr_macropore_top_input_forcing_t, prepare_fmr_macropore_top_input
  use mod_contact_action_memory,only:complete_contact_action_memory
  use mod_macropore_standard_storage,only:macropore_standard_candidate_receipt_t,build_macropore_standard_candidate
  use mod_ppa_wu05a5_top_partition,only:macropore_top_partition_result_t
  use mod_ppa_wu05a6_sorptivity_history,only:sorptivity_history_update_request_t,apply_sorptivity_history_update
  use mod_macropore_standard_rate_adapter,only:prepare_standard_sorptivity_history_request
  use mod_ppa_wu05a6_vertical_flux_reconstruction,only:vertical_flux_reconstruction_request_t,vertical_flux_reconstruction_result_t,reconstruct_vertical_flux
  implicit none
  private

  type, extends(macropore_storage_coupling_provider_t), public :: ppa_wu05a16_inner_macropore_provider_t
    logical :: configured=.false.
    logical :: perched_jacobian_enabled=.false.
    type(macropore_continuation_state_t) :: accepted_macro
    type(macropore_geometry_result_t) :: geometry
    type(macropore_geometry_config_t) :: geometry_config
    type(dynamic_shrinkage_config_t) :: shrinkage
    type(fmr_macropore_top_input_forcing_t) :: top_input
    type(macropore_standard_storage_view_t) :: accepted_view
    real(real64), allocatable :: accepted_matrix_theta(:), matrix_area_fraction(:)
    type(macropore_rate_bundle_request_t) :: rate_template
    real(real64), allocatable :: z(:),dz(:)
    real(real64) :: step_duration=0.0_real64
    real(real64) :: accepted_ponding_depth=0.0_real64
    real(real64) :: accepted_groundwater_level=0.0_real64
    real(real64) :: candidate_pond_lateral_cm=0.0_real64
    integer :: bottom_boundary_mode=1
    logical :: covering_layer_enabled=.false.
    real(real64) :: covering_minimum_polygon_diameter_cm=0.0_real64
    real(real64) :: covering_ksat_cm_per_day=0.0_real64
  contains
    procedure, public :: configure => configure_inner_macropore_provider
    procedure, public :: evaluate_rate => evaluate_inner_macropore_rate
    procedure, public :: evaluate_derivative => evaluate_inner_macropore_derivative
    procedure, public :: evaluate_storage_coupling => evaluate_inner_storage_coupling
    procedure, public :: evaluate_trial_geometry => evaluate_inner_trial_geometry
    procedure, public :: permits_source_freezing => inner_permits_source_freezing
    procedure, public :: set_candidate_pond_lateral => inner_set_candidate_pond_lateral
    procedure, public :: candidate_pond_lateral => inner_candidate_pond_lateral
    procedure,public::research_contact_lifecycle
    procedure,public::research_contact_selector
    procedure,public::research_contact_rates
  end type ppa_wu05a16_inner_macropore_provider_t

contains
  subroutine research_contact_lifecycle(self,head,theta,fraction,u,kind,macro_result,face_result,exchange_result,external_result,top_amount,valid)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    real(real64),intent(in)::head(:),theta(:),fraction
    integer,intent(in)::u,kind
    type(macropore_continuation_state_t),intent(out),optional::macro_result
    real(real64),allocatable,intent(out),optional::face_result(:,:),exchange_result(:,:),external_result(:,:)
    real(real64),intent(out),optional::top_amount
    logical,intent(out),optional::valid
    type(macropore_rate_bundle_request_t)::request
    type(macropore_rate_bundle_result_t)::ordinary,off,on
    type(matrix_saturated_zone_view_t)::matrix_view
    type(soil_water_physical_state_t)::matrix
    type(macropore_geometry_result_t)::geometry
    type(macropore_standard_storage_view_t)::view
    type(macropore_standard_candidate_receipt_t)::receipt
    type(macropore_continuation_state_t)::candidate,history_off,history_on,completed,repeat_completion
    type(sorptivity_history_update_request_t)::template,history
    type(vertical_flux_reconstruction_request_t)::vertical
    type(vertical_flux_reconstruction_result_t)::faces
    type(macropore_top_partition_result_t)::top
    real(real64),allocatable::exchange(:,:),rapid(:),returned(:,:)
    real(real64)::history_difference
    logical::ok,aok,bok,unique
    integer::nd,n
    if(present(valid))valid=.false.
    call evaluate_current_rates(self,head,theta,request,ordinary,matrix_view,matrix,ok)
    if(.not.ok)error stop 'full lifecycle request'
    call self%evaluate_trial_geometry(theta,geometry,ok,head)
    if(.not.ok)error stop 'full lifecycle geometry'
    request%unsaturated%sorptivity%perched_top_node=26
    call evaluate_macropore_rate_bundle(request,off)
    request%unsaturated%sorptivity%perched_top_node=27
    call evaluate_macropore_rate_bundle(request,on)
    if(.not.off%valid.or..not.on%valid)error stop 'full lifecycle branch rates'
    exchange=(1d0-fraction)*off%qexc_to_matrix_rate+fraction*on%qexc_to_matrix_rate
    if(self%shrinkage%enabled)then
      call evaluate_macropore_geometry_return(self%accepted_macro,geometry,returned,ok)
      if(.not.ok)return
      exchange=exchange+returned/self%step_duration
    end if
    rapid=(1d0-fraction)*off%rapid_outflow_cp_cm+fraction*on%rapid_outflow_cp_cm
    top=off%top_partition
    top%accepted_vertical_cm=(1d0-fraction)*off%top_partition%accepted_vertical_cm+fraction*on%top_partition%accepted_vertical_cm
    top%accepted_lateral_cm=(1d0-fraction)*off%top_partition%accepted_lateral_cm+fraction*on%top_partition%accepted_lateral_cm
    top%redistributed_cm=(1d0-fraction)*off%top_partition%redistributed_cm+fraction*on%top_partition%redistributed_cm
    top%accepted_total_cm=sum(top%accepted_vertical_cm+top%accepted_lateral_cm)
    top%redistributed_total_cm=sum(top%redistributed_cm)
    top%returned_surface_cm=(1d0-fraction)*off%top_partition%returned_surface_cm+fraction*on%top_partition%returned_surface_cm
    top%receipt_residual_cm=top%accepted_total_cm+top%returned_surface_cm-top%requested_total_cm
    if(abs(top%receipt_residual_cm)>1d-10)error stop 'full lifecycle top budget'
    call build_macropore_standard_candidate(self%accepted_macro,geometry,top,exchange,rapid,self%step_duration, &
         geometry%top_node,self%z,self%dz,candidate,view,receipt,ok)
    write(u,'(a,a,i0,a,l1,a,es25.17e3)')'MACRO_STORAGE',',',kind,',',ok,',',receipt%macro_balance_residual_cm
    if(.not.ok)return
    nd=candidate%num_domains;n=candidate%num_nodes
    vertical%num_domains=nd;vertical%num_nodes=n;vertical%top_node=geometry%top_node
    vertical%step_duration=self%step_duration;vertical%bottom_domain=candidate%icp_bottom_domain
    vertical%top_inflow_rate=(top%accepted_vertical_cm+top%accepted_lateral_cm)/self%step_duration
    vertical%previous_water_cm=self%accepted_macro%water_domain_cp;vertical%current_water_cm=candidate%water_domain_cp
    vertical%exchange_to_matrix_rate=exchange;allocate(vertical%external_outflow_rate(nd,n));vertical%external_outflow_rate=0d0
    vertical%external_outflow_rate(1,:)=rapid/self%step_duration
    call reconstruct_vertical_flux(vertical,faces)
    write(u,'(a,a,i0,a,l1,a,es25.17e3)')'MACRO_VERTICAL',',',kind,',',faces%valid,',',faces%max_local_residual_rate
    if(.not.faces%valid)return
    template%num_domains=nd;template%num_nodes=n;template%top_node=geometry%top_node
    template%wall_correction=request%unsaturated%sorptivity%wall_correction
    template%domain_fraction=request%unsaturated%sorptivity%domain_fraction
    template%diameter=request%unsaturated%sorptivity%diameter
    call prepare_standard_sorptivity_history_request(template,geometry,view,matrix_view,self%step_duration,history,ok)
    if(.not.ok)error stop 'full lifecycle history contract'
    history_off=candidate;history_on=candidate
    call apply_sorptivity_history_update(history,self%accepted_macro,off%unsaturated,history_off,aok)
    call apply_sorptivity_history_update(history,self%accepted_macro,on%unsaturated,history_on,bok)
    history_difference=maxval(abs(history_off%absorption_time-history_on%absorption_time))
    write(u,'(a,a,i0,3(a,l1),a,es25.17e3)')'HISTORY_BRANCHES',',',kind,',',aok,',',bok,',', &
         history_off%same_values(history_on),',',history_difference
    if(.not.aok.or..not.bok)error stop 'full lifecycle history failure'
    call complete_contact_action_memory(history,self%accepted_macro,on%unsaturated,history_off,history_on, &
         26,fraction,completed,ok)
    if(.not.ok)error stop 'native action memory completion'
    call complete_contact_action_memory(history,self%accepted_macro,on%unsaturated,history_off,history_on, &
         26,fraction,repeat_completion,unique)
    unique=unique.and.completed%same_values(repeat_completion)
    write(u,'(a,a,i0,2(a,l1),3(a,es25.17e3))')'ACTION_HISTORY',',',kind,',',ok,',',unique,',',fraction, &
         ',',maxval(completed%absorption_time(:,26)),',',maxval(completed%theta_sorption_ref(:,26))
    if(.not.unique)error stop 'nonunique native action memory'

    if(present(macro_result))macro_result=completed
    if(present(face_result))face_result=faces%vertical_face_rate
    if(present(exchange_result))exchange_result=exchange
    if(present(external_result))external_result=vertical%external_outflow_rate
    if(present(top_amount))top_amount=receipt%accepted_top_cm
    if(present(valid))valid=.true.
    write(u,'(a,a,i0,a,es25.17e3)')'EXCHANGE_OPPOSITE_SIGN_AMOUNT' ,',',kind,',',receipt%internal_exchange_to_matrix_cm
  end subroutine

 subroutine research_contact_selector(self,head,theta,fraction,ok)
  class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
  real(real64),intent(in)::head(:),theta(:)
  real(real64),intent(out)::fraction
  logical,intent(out)::ok
  type(macropore_rate_bundle_request_t)::request
  type(macropore_rate_bundle_result_t)::rates
  type(matrix_saturated_zone_view_t)::view
  type(soil_water_physical_state_t)::matrix
  call evaluate_current_rates(self,head,theta,request,rates,view,matrix,ok)
  if(.not.ok)return
  ok=request%unsaturated%sorptivity%perched_active.and.request%unsaturated%sorptivity%perched_bottom_node==27
  if(.not.ok)return
  fraction=0d0
  if(request%unsaturated%sorptivity%perched_top_node==27)fraction=1d0
  ok=request%unsaturated%sorptivity%perched_top_node==26.or.request%unsaturated%sorptivity%perched_top_node==27
 end subroutine
  subroutine research_contact_rates(self,head,theta,fraction,domain_rate,ok)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    real(real64),intent(in)::head(:),theta(:),fraction
    real(real64),allocatable,intent(out)::domain_rate(:,:)
    logical,intent(out)::ok
    type(macropore_rate_bundle_request_t)::request
    type(macropore_rate_bundle_result_t)::ordinary,off,on
    type(matrix_saturated_zone_view_t)::view
    type(soil_water_physical_state_t)::matrix
    type(macropore_geometry_result_t)::geometry
    real(real64),allocatable::returned(:,:)
    ok=.false.
    if(fraction<0d0.or.fraction>1d0)return
    call evaluate_current_rates(self,head,theta,request,ordinary,view,matrix,ok)
    if(.not.ok)return
    ok=.false.
    if(.not.request%unsaturated%sorptivity%perched_active)return
    if(request%unsaturated%sorptivity%perched_bottom_node/=27)return
    ! Proposed set-valued completion of the partly saturated top-cell exclusion.
    ! Rebuild both whole rate bundles, including donor limiters, for every call.
    request%unsaturated%sorptivity%perched_top_node=26
    call evaluate_macropore_rate_bundle(request,off)
    request%unsaturated%sorptivity%perched_top_node=27
    call evaluate_macropore_rate_bundle(request,on)
    if(.not.off%valid.or..not.on%valid)return
    domain_rate=(1d0-fraction)*off%qexc_to_matrix_rate+fraction*on%qexc_to_matrix_rate
    if(self%shrinkage%enabled)then
      call self%evaluate_trial_geometry(theta,geometry,ok,head)
      if(.not.ok)return
      call evaluate_macropore_geometry_return(self%accepted_macro,geometry,returned,ok)
      if(.not.ok)return
      domain_rate=domain_rate+returned/self%step_duration
    end if
    ok=.true.
  end subroutine

  subroutine inner_set_candidate_pond_lateral(self,amount_cm)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(inout)::self
    real(real64),intent(in)::amount_cm
    if(ieee_is_finite(amount_cm) .and. amount_cm>=0.0_real64)then
      self%candidate_pond_lateral_cm=amount_cm
    else
      self%candidate_pond_lateral_cm=0.0_real64
    end if
  end subroutine inner_set_candidate_pond_lateral

  real(real64) function inner_candidate_pond_lateral(self) result(amount_cm)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    amount_cm=self%candidate_pond_lateral_cm
  end function inner_candidate_pond_lateral

  logical function inner_permits_source_freezing(self) result(permitted)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    permitted=.true.
    if(.not.self%configured)return
    ! A pond-derived B1.11 receipt is residual-synchronous: its amount is
    ! recomputed from candidate ponding inside the Newton residual. Freezing
    ! macropore sources while that receipt is active would let the residual
    ! change while the macropore Jacobian/source contribution is held stale.
    if(self%candidate_pond_lateral_cm>0.0_real64)then
      permitted=.false.
      return
    end if
    if(.not.self%shrinkage%enabled)return
    permitted=all(self%shrinkage%theta_crack==0.0_real64) .and. &
         all(self%accepted_macro%dynamic_volume_cp==0.0_real64)
  end function inner_permits_source_freezing

  subroutine derive_dynamic_surface_area(config,crack_area_node,geometry,ok)
    type(macropore_geometry_config_t),intent(in)::config
    integer,intent(in)::crack_area_node
    type(macropore_geometry_result_t),intent(inout)::geometry
    logical,intent(out)::ok
    integer::ic,top
    real(real64)::dynamic_area,static_area,minimum_area,denominator
    ok=.false.
    if(.not.config%valid() .or. .not.geometry%valid)return
    top=config%top_node
    if(crack_area_node<1 .or. crack_area_node>config%num_nodes)return
    ic=max(top,crack_area_node)
    if(ic>config%num_nodes)return
    if(.not.allocated(geometry%subsidence_cp))return
    if(size(geometry%subsidence_cp)/=config%num_nodes)return
    denominator=config%dz(ic)-geometry%subsidence_cp(ic)
    if(denominator<=0.0_real64)return
    dynamic_area=geometry%dynamic_volume_cp(ic)/denominator
    static_area=config%static_volume_cp(top)/config%dz(top)
    geometry%surface_area_fraction=min(0.6_real64,max(0.0_real64,dynamic_area+static_area))
    minimum_area=1.0_real64-(1.0_real64-0.001_real64/config%characteristic_diameter(top))**2
    if(geometry%surface_area_fraction<minimum_area)geometry%surface_area_fraction=0.0_real64
    ok=.true.
  end subroutine derive_dynamic_surface_area

  subroutine configure_inner_macropore_provider(self,accepted_macro,geometry,rate_template,z,dz,step_duration, &
                                                 accepted_ponding_depth,accepted_groundwater_level,ok, &
                                                 covering_minimum_polygon_diameter_cm,covering_ksat_cm_per_day, &
                                                 geometry_config,shrinkage,accepted_matrix_theta,matrix_area_fraction,top_input, &
                                                 bottom_boundary_mode,perched_jacobian_enabled)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(inout)::self
    type(macropore_continuation_state_t),intent(in)::accepted_macro
    type(macropore_geometry_result_t),intent(in)::geometry
    type(macropore_rate_bundle_request_t),intent(in)::rate_template
    real(real64),intent(in)::z(:),dz(:),step_duration,accepted_ponding_depth,accepted_groundwater_level
    logical,intent(out)::ok
    real(real64),intent(in),optional::covering_minimum_polygon_diameter_cm,covering_ksat_cm_per_day
    type(macropore_geometry_config_t),intent(in),optional::geometry_config
    type(dynamic_shrinkage_config_t),intent(in),optional::shrinkage
    real(real64),intent(in),optional::accepted_matrix_theta(:),matrix_area_fraction(:)
    type(fmr_macropore_top_input_forcing_t),intent(in),optional::top_input
    integer,intent(in),optional::bottom_boundary_mode
    logical,intent(in),optional::perched_jacobian_enabled

    self%configured=.false.
    self%perched_jacobian_enabled=.false.
    if(present(perched_jacobian_enabled))self%perched_jacobian_enabled=perched_jacobian_enabled
    ok=.false.
    if(.not.accepted_macro%ready() .or. .not.geometry%valid)return
    if(step_duration<=0.0_real64)return
    if(size(z)/=accepted_macro%num_nodes .or. size(dz)/=accepted_macro%num_nodes .or. any(dz<=0.0_real64))return
    if(geometry%num_nodes/=accepted_macro%num_nodes .or. geometry%num_domains/=accepted_macro%num_domains)return

    call copy_macropore_continuation_state(accepted_macro,self%accepted_macro,ok)
    if(.not.ok)return
    self%geometry=geometry
    self%rate_template=rate_template
    self%shrinkage=dynamic_shrinkage_config_t()
    if(present(shrinkage))self%shrinkage=shrinkage
    self%top_input=fmr_macropore_top_input_forcing_t()
    if(present(top_input))self%top_input=top_input
    if(present(geometry_config))then
      if(.not.geometry_config%valid())return
      self%geometry_config=geometry_config
    else if(self%top_input%supplied)then
      return
    end if
    if(self%shrinkage%enabled)then
      if(.not.present(geometry_config) .or. .not.present(accepted_matrix_theta) .or. .not.present(matrix_area_fraction))return
      if(.not.geometry_config%valid())return
      if(.not.self%shrinkage%valid_for_nodes(accepted_macro%num_nodes))return
      if(size(accepted_matrix_theta)/=accepted_macro%num_nodes .or. size(matrix_area_fraction)/=accepted_macro%num_nodes)return
      self%geometry_config=geometry_config
      self%accepted_matrix_theta=accepted_matrix_theta
      self%matrix_area_fraction=matrix_area_fraction
    end if
    self%z=z
    self%dz=dz
    self%step_duration=step_duration
    self%accepted_ponding_depth=accepted_ponding_depth
    self%accepted_groundwater_level=accepted_groundwater_level
    self%candidate_pond_lateral_cm=0.0_real64
    self%bottom_boundary_mode=1
    if(present(bottom_boundary_mode))self%bottom_boundary_mode=bottom_boundary_mode
    self%covering_layer_enabled=.false.
    if(self%geometry%top_node>1)then
      if(.not.present(covering_minimum_polygon_diameter_cm) .or. .not.present(covering_ksat_cm_per_day))return
      if(covering_minimum_polygon_diameter_cm<=0.0_real64 .or. covering_ksat_cm_per_day<0.0_real64)return
      self%covering_layer_enabled=.true.
      self%covering_minimum_polygon_diameter_cm=covering_minimum_polygon_diameter_cm
      self%covering_ksat_cm_per_day=covering_ksat_cm_per_day
    end if

    call derive_macropore_standard_storage_view(self%accepted_macro,self%geometry%top_node,self%z,self%dz,self%accepted_view)
    if(.not.self%accepted_view%valid)return
    if(maxval(abs(self%accepted_view%normalized_water_cm-self%accepted_macro%water_domain_cp))>1.0e-10_real64)return

    self%configured=.true.
    ok=.true.
  end subroutine configure_inner_macropore_provider

  subroutine evaluate_inner_macropore_rate(self,pressure_head,water_content,exchange_flux,active,surface_area_fraction)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    real(real64),intent(in)::pressure_head(:),water_content(:)
    real(real64),intent(out)::exchange_flux(:)
    logical,intent(out)::active
    real(real64),intent(out),optional::surface_area_fraction

    type(macropore_rate_bundle_request_t)::request
    type(macropore_rate_bundle_result_t)::rates
    type(matrix_saturated_zone_view_t)::matrix_view
    type(soil_water_physical_state_t)::matrix
    type(covering_layer_input_request_t)::covering
    real(real64),allocatable::covered_cm(:)
    integer::cover_node
    logical::ok

    active=.false.
    if(present(surface_area_fraction))surface_area_fraction=-1.0_real64
    if(.not.self%configured)return
    if(size(exchange_flux)/=self%accepted_macro%num_nodes)return
    exchange_flux=0.0_real64
    call evaluate_current_rates(self,pressure_head,water_content,request,rates,matrix_view,matrix,ok, &
         surface_area_fraction)
    if(.not.ok)return
    if(allocated(rates%qexc_to_matrix_rate))then
      if(size(rates%qexc_to_matrix_rate,2)/=size(exchange_flux))return
      exchange_flux=sum(rates%qexc_to_matrix_rate,dim=1)
    else
      ! A valid pure top receipt need not allocate a matrix-exchange bundle.
      if(self%candidate_pond_lateral_cm<=0.0_real64)return
    end if
    if(self%covering_layer_enabled)then
      cover_node=self%geometry%top_node-1
      covering%top_node=self%geometry%top_node
      covering%step_duration_day=self%step_duration
      covering%matrix_head_above_cm=pressure_head(cover_node)
      covering%dz_above_cm=self%dz(cover_node)
      covering%minimum_polygon_diameter_cm=self%covering_minimum_polygon_diameter_cm
      covering%covering_layer_ksat_cm_per_day=self%covering_ksat_cm_per_day
      covering%total_macropore_volume_top_cm=sum(self%geometry%volume_domain_cp(:,self%geometry%top_node))
      covering%domain_top_volume_cm=self%geometry%volume_domain_cp(:,self%geometry%top_node)
      call evaluate_covering_layer_input(covering,covered_cm,ok)
      if(.not.ok)return
      exchange_flux(cover_node)=exchange_flux(cover_node)-sum(covered_cm)/self%step_duration
    end if
    active=maxval(abs(exchange_flux))>1.0e-14_real64
    ! A pure surface-to-macropore receipt can be physically active while its
    ! same-residual matrix exchange is zero. Keep the provider active so the
    ! top receipt participates in the candidate rather than being discarded.
    if(self%candidate_pond_lateral_cm>0.0_real64)then
      if(rates%valid .and. rates%top_partition%valid .and. &
         rates%top_partition%requested_total_cm>0.0_real64)active=.true.
    end if
  end subroutine evaluate_inner_macropore_rate

  subroutine evaluate_inner_macropore_derivative(self,pressure_head,water_content,capacity,dexchange_dhead,derivative_available,active)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    real(real64),intent(in)::pressure_head(:),water_content(:),capacity(:)
    real(real64),intent(out)::dexchange_dhead(:)
    logical,intent(out)::derivative_available,active
    call evaluate_inner_derivative_data(self,pressure_head,water_content,capacity,dexchange_dhead,derivative_available,active)
  end subroutine evaluate_inner_macropore_derivative

  subroutine evaluate_inner_storage_coupling(self,pressure_head,water_content,capacity,dexchange_dhead,active,left,right,diagonal_restore,available)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    real(real64),intent(in)::pressure_head(:),water_content(:),capacity(:)
    real(real64),intent(out)::dexchange_dhead(:)
    logical,intent(out)::active,available
    real(real64),allocatable,intent(out)::left(:,:),right(:,:),diagonal_restore(:)
    call evaluate_inner_derivative_data(self,pressure_head,water_content,capacity,dexchange_dhead,available,active,left,right,diagonal_restore)
  end subroutine evaluate_inner_storage_coupling

  subroutine evaluate_inner_derivative_data(self,pressure_head,water_content,capacity,dexchange_dhead, &
                                                  derivative_available,active,left,right,diagonal_restore)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    real(real64),intent(in)::pressure_head(:),water_content(:),capacity(:)
    real(real64),intent(out)::dexchange_dhead(:)
    logical,intent(out)::derivative_available,active
    real(real64),allocatable,intent(out),optional::left(:,:),right(:,:),diagonal_restore(:)
    integer::id,nrank,column

    type(macropore_rate_bundle_request_t)::request
    type(macropore_rate_bundle_result_t)::rates
    type(macropore_exchange_derivative_result_t)::derivative
    type(macropore_geometry_result_t)::geometry_plus,geometry_minus
    type(matrix_saturated_zone_view_t)::matrix_view
    type(soil_water_physical_state_t)::matrix
    real(real64),allocatable::exchange(:),covered_cm(:)
    real(real64),allocatable::theta_plus(:),theta_minus(:),return_plus(:,:),return_minus(:,:)
    type(covering_layer_input_request_t)::covering
    real(real64)::covered_dqdh
    integer::cover_node
    logical::ok

    if(present(left))allocate(left(size(pressure_head),0))
    if(present(right))allocate(right(size(pressure_head),0))
    if(present(diagonal_restore))then
      allocate(diagonal_restore(size(pressure_head)));diagonal_restore=0d0
    end if
    dexchange_dhead=0.0_real64
    derivative_available=.false.
    active=.false.
    if(.not.self%configured)return
    if(size(capacity)/=self%accepted_macro%num_nodes)return

    call evaluate_current_rates(self,pressure_head,water_content,request,rates,matrix_view,matrix,ok)
    if(.not.ok)return
    if(.not.allocated(rates%qexc_to_matrix_rate))then
      ! A pure top receipt has no matrix exchange and therefore no exchange
      ! Jacobian contribution. It remains active through evaluate_rate.
      if(self%candidate_pond_lateral_cm>0.0_real64)then
        derivative_available=.true.
        active=.true.
      end if
      return
    end if
    call evaluate_macropore_exchange_derivative(request,rates,capacity,derivative,self%perched_jacobian_enabled)
    if(.not.derivative%valid)return
    if(size(dexchange_dhead)/=self%accepted_macro%num_nodes)return

    allocate(exchange(self%accepted_macro%num_nodes))
    exchange=sum(rates%qexc_to_matrix_rate,dim=1)
    dexchange_dhead=derivative%total_dqdh_node
    if(self%shrinkage%enabled)then
      ! Geometry displacement is an implicit matrix source. Its local theta
      ! derivative must accompany the same source in the Richards Jacobian.
      ! Accepted neighbour history is fixed, so each theta perturbation is local;
      ! hold the discrete groundwater cutoff at the current pressure profile.
      theta_plus=min(self%shrinkage%theta_s,water_content+sqrt(epsilon(1.0_real64)))
      theta_minus=max(0.0_real64,water_content-sqrt(epsilon(1.0_real64)))
      call self%evaluate_trial_geometry(theta_plus,geometry_plus,ok,pressure_head)
      if(.not.ok)return
      call self%evaluate_trial_geometry(theta_minus,geometry_minus,ok,pressure_head)
      if(.not.ok)return
      call evaluate_macropore_geometry_return(self%accepted_macro,geometry_plus,return_plus,ok)
      if(.not.ok)return
      call evaluate_macropore_geometry_return(self%accepted_macro,geometry_minus,return_minus,ok)
      if(.not.ok)return
      dexchange_dhead=dexchange_dhead+sum(return_plus-return_minus,dim=1)*capacity / &
           ((theta_plus-theta_minus)*self%step_duration)
    end if
    if(self%covering_layer_enabled)then
      cover_node=self%geometry%top_node-1
      covering%top_node=self%geometry%top_node
      covering%step_duration_day=self%step_duration
      covering%matrix_head_above_cm=pressure_head(cover_node)
      covering%dz_above_cm=self%dz(cover_node)
      covering%minimum_polygon_diameter_cm=self%covering_minimum_polygon_diameter_cm
      covering%covering_layer_ksat_cm_per_day=self%covering_ksat_cm_per_day
      covering%total_macropore_volume_top_cm=sum(self%geometry%volume_domain_cp(:,self%geometry%top_node))
      covering%domain_top_volume_cm=self%geometry%volume_domain_cp(:,self%geometry%top_node)
      call evaluate_covering_layer_input(covering,covered_cm,ok)
      if(.not.ok)return
      call evaluate_covering_layer_rate_derivative(covering,covered_dqdh,ok)
      if(.not.ok)return
      exchange(cover_node)=exchange(cover_node)-sum(covered_cm)/self%step_duration
      dexchange_dhead(cover_node)=dexchange_dhead(cover_node)-covered_dqdh
    end if
    if(present(left).and.present(right).and.present(diagonal_restore))then
      if(allocated(derivative%storage_left))then
        nrank=0
        do id=1,size(derivative%storage_left,2)
          if(any(derivative%storage_left(:,id)/=0d0).and.any(derivative%storage_right(:,id)/=0d0))nrank=nrank+1
        end do
        deallocate(left,right);allocate(left(size(pressure_head),nrank),right(size(pressure_head),nrank));column=0
        do id=1,size(derivative%storage_left,2)
          if(.not.(any(derivative%storage_left(:,id)/=0d0).and.any(derivative%storage_right(:,id)/=0d0)))cycle
          column=column+1;left(:,column)=derivative%storage_left(:,id);right(:,column)=derivative%storage_right(:,id)
        end do
        diagonal_restore=derivative%storage_diagonal_restore
      end if
    end if
    derivative_available=.true.
    active=max(maxval(abs(exchange)),maxval(abs(dexchange_dhead)))>1.0e-14_real64
  end subroutine evaluate_inner_derivative_data

  subroutine evaluate_inner_trial_geometry(self,water_content,geometry_current,ok,pressure_head)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    real(real64),intent(in)::water_content(:)
    type(macropore_geometry_result_t),intent(out)::geometry_current
    logical,intent(out)::ok
    real(real64),intent(in),optional::pressure_head(:)
    real(real64),allocatable::dynamic_current(:),subsidence_current(:)
    integer::active_node

    ok=.false.
    geometry_current=self%geometry
    if(.not.self%shrinkage%enabled)then
      ok=geometry_current%valid
      return
    end if
    if(size(water_content)/=self%accepted_macro%num_nodes)return
    active_node=self%accepted_macro%num_nodes
    if(present(pressure_head))then
      if(size(pressure_head)/=self%accepted_macro%num_nodes)return
      active_node=min(self%accepted_macro%num_nodes, &
           find_dynamic_groundwater_cutoff(pressure_head,self%z,self%dz,self%bottom_boundary_mode))
    end if
    call evaluate_dynamic_crack_profile(self%shrinkage,water_content,self%accepted_matrix_theta,self%dz, &
         self%matrix_area_fraction,self%accepted_macro%dynamic_volume_cp,dynamic_current,ok, &
         subsidence_current,active_node,self%geometry_config%top_node)
    if(.not.ok)return
    call evaluate_macropore_geometry(self%geometry_config,dynamic_current,geometry_current)
    if(.not.geometry_current%valid)return
    geometry_current%subsidence_cp=subsidence_current
    call derive_dynamic_surface_area(self%geometry_config,self%shrinkage%surface_crack_area_node,geometry_current,ok)
  end subroutine evaluate_inner_trial_geometry

  subroutine evaluate_current_rates(self,pressure_head,water_content,request,rates,matrix_view,matrix,ok, &
                                    surface_area_fraction)
    class(ppa_wu05a16_inner_macropore_provider_t),intent(in)::self
    real(real64),intent(in)::pressure_head(:),water_content(:)
    type(macropore_rate_bundle_request_t),intent(out)::request
    type(macropore_rate_bundle_result_t),intent(out)::rates
    type(matrix_saturated_zone_view_t),intent(out)::matrix_view
    type(soil_water_physical_state_t),intent(out)::matrix
    type(macropore_geometry_result_t)::geometry_current
    type(macropore_standard_storage_view_t)::view_current
    real(real64),allocatable::geometry_return(:,:),top_vertical(:),top_lateral(:)
    logical,intent(out)::ok
    real(real64),intent(out),optional::surface_area_fraction
    integer::n

    ok=.false.
    if(present(surface_area_fraction))surface_area_fraction=-1.0_real64
    n=self%accepted_macro%num_nodes
    if(size(pressure_head)/=n .or. size(water_content)/=n)return

    matrix%active_nodes=n
    allocate(matrix%pressure_head(n),matrix%water_content(n))
    matrix%pressure_head=pressure_head
    matrix%water_content=water_content
    matrix%ponding_depth=self%accepted_ponding_depth
    matrix%groundwater_level=self%accepted_groundwater_level

    call self%evaluate_trial_geometry(water_content,geometry_current,ok,pressure_head)
    if(.not.ok)return
    if(present(surface_area_fraction))then
      if(geometry_current%surface_area_fraction>=0.0_real64)then
        surface_area_fraction=geometry_current%surface_area_fraction
      else
        surface_area_fraction=sum(geometry_current%volume_domain_cp(:,geometry_current%top_node))/ &
             self%dz(geometry_current%top_node)
      end if
      if(.not.ieee_is_finite(surface_area_fraction) .or. surface_area_fraction<0.0_real64 .or. &
         surface_area_fraction>1.0_real64)return
    end if
    view_current=self%accepted_view
    if(self%shrinkage%enabled)then
      call derive_macropore_standard_storage_view(self%accepted_macro,geometry_current%top_node,self%z,self%dz,view_current)
      if(.not.view_current%valid)return
    end if

    call prepare_standard_macropore_rate_request(self%rate_template,self%accepted_macro,geometry_current,view_current, &
         matrix,self%z,self%dz,self%step_duration,request,matrix_view,ok)
    if(.not.ok)return
    if(self%top_input%supplied)then
      call prepare_fmr_macropore_top_input(self%top_input,self%geometry_config,geometry_current,self%step_duration, &
           top_vertical,top_lateral,ok)
      if(.not.ok)return
      request%limiter%potential_top_vertical_cm=top_vertical
      request%limiter%potential_top_lateral_cm=top_lateral
    end if
    if(self%candidate_pond_lateral_cm>0.0_real64)then
      if(.not.self%geometry_config%valid())return
      ! Pond-derived lateral inflow is an additional B1.11 receipt. It must
      ! coexist with any independently configured direct top forcing rather
      ! than making the residual callback fail closed when that forcing exists.
      request%limiter%potential_top_lateral_cm=request%limiter%potential_top_lateral_cm+ &
           self%geometry_config%domain_fraction(:,geometry_current%top_node)*self%candidate_pond_lateral_cm
    end if
    call evaluate_macropore_rate_bundle(request,rates)
    ok=rates%valid
    if(.not.ok)return
    if(self%shrinkage%enabled)then
      call evaluate_macropore_geometry_return(self%accepted_macro,geometry_current,geometry_return,ok)
      if(.not.ok)return
      rates%qexc_to_matrix_rate = rates%qexc_to_matrix_rate + geometry_return/self%step_duration
    end if
  end subroutine evaluate_current_rates

end module mod_ppa_wu05a16_inner_macropore_provider
