module mod_a23bu_worker_execution_context
  use, intrinsic :: iso_fortran_env, only: real64
  use mod_accepted_trajectory_directional_sensitivity, only: accepted_trajectory_direction_t, &
       fkt21_accept_trajectory_step => accept_trajectory_step, &
       fkt21_discard_trajectory_step => discard_trajectory_step
  implicit none
  private

  type, public :: a23bu_headcalc_scratch_t
    real(real64), allocatable :: dfdhl(:), dfdhm(:), dfdhu(:)
    real(real64), allocatable :: difh(:), residual(:)
    real(real64), allocatable :: sink(:), source(:), dkdh(:), hold(:)
    real(real64), allocatable :: qv(:), hgrad(:)
    logical, allocatable :: flnonconv1(:), flnonconv2(:)
    logical :: flunsatok(3) = .false.
  end type a23bu_headcalc_scratch_t

  type, public :: a23bu_solver_history_t
    logical :: flwarn = .true.
    integer :: iwarn = 0
    integer :: nstep = 0
  end type a23bu_solver_history_t

  type, public :: a23bu_solver_diagnostics_t
    integer :: headcalc_calls = 0
    integer :: nonlinear_iterations = 0
    integer :: jacobian_builds = 0
    integer :: linear_solves = 0
    integer :: backtracking_attempts = 0
    integer :: alternative_solver_calls = 0
    integer :: internal_retries = 0
    integer :: constitutive_evaluations = 0
    integer :: constitutive_initial_full_evaluations = 0
    integer :: constitutive_candidate_full_evaluations = 0
    integer :: constitutive_candidate_demand_evaluations = 0
    integer :: constitutive_capacity_only_evaluations = 0
    integer :: constitutive_candidate_terminal_evaluations = 0
    integer :: constitutive_candidate_capacity_reuses = 0
  end type a23bu_solver_diagnostics_t

  ! F-KT15 trial-local metadata only. This is worker-owned numerical/result scratch,
  ! never committed column state. It is reset before every hydraulic task-2 trial.
  type, public :: a23bu_soil_water_trial_result_t
    logical :: typed_attempted = .false.
    logical :: typed_accepted = .false.
    logical :: retry_advised = .false.
    logical :: sensitivity_available = .false.
    real(real64) :: dh_bottom_dq_bottom = 0.0_real64
    character(len=24) :: sensitivity_method = 'not-available'
    character(len=32) :: route = 'not-run'
    integer :: interface_sensitivity_backsolves = 0
  end type a23bu_soil_water_trial_result_t

  integer, parameter, public :: A23BU_TS_LIMIT_NONE = 0
  integer, parameter, public :: A23BU_TS_LIMIT_HARD_EVENT = 1
  integer, parameter, public :: A23BU_TS_LIMIT_SOLVER_RETRY = 2
  integer, parameter, public :: A23BU_TS_LIMIT_SOLVER_RETRY_FLOOR = 3

  type, public :: a23bu_timestep_decision_trace_t
    logical :: available = .false.
    real(real64) :: input_dt = 0.0_real64
    real(real64) :: preferred_dt = 0.0_real64
    real(real64) :: executed_dt = 0.0_real64
    integer :: proposal_reason = 0
    integer :: limit_reason = A23BU_TS_LIMIT_NONE
    logical :: event_clamped = .false.
  end type a23bu_timestep_decision_trace_t

  type, public :: a23bu_timestep_shadow_memory_t
    logical :: available = .false.
    real(real64) :: retain_preferred_dt = 0.0_real64
    real(real64) :: evidence_preferred_dt = 0.0_real64
    logical :: previous_event_clamped = .false.
  end type a23bu_timestep_shadow_memory_t

  type, public :: a23bu_numerical_control_t
    integer :: last_numbit = 0
    logical :: request_dt_reduction = .false.
    logical :: at_min_dt = .false.
  end type a23bu_numerical_control_t

  type, public :: a23bu_execution_time_t
    real(real64) :: interval_t0 = 0.0_real64
    real(real64) :: interval_t1 = 0.0_real64
    real(real64) :: legacy_start = 0.0_real64
    real(real64) :: legacy_end = 0.0_real64
    logical :: day_start_event = .false.
    logical :: day_end_event = .false.
  end type a23bu_execution_time_t

  type, public :: a23bu_reporting_progress_t
    integer :: nprintcount = 1
    integer :: cntper = 0
    integer :: ioutdat = 1
    integer :: ioutdatint = 1
    real(real64) :: outper = 0.0_real64
    real(real64) :: tcumold = 0.0_real64
    logical :: output_short = .false.
    logical :: balance_output = .false.
    logical :: header = .false.
    logical :: output = .false.
    logical :: reset_intermediate = .true.
    logical :: reset_cumulative = .false.
  end type a23bu_reporting_progress_t

  type, public :: a23bu_worker_context_t
    integer :: worker_id = -1
    integer :: active_nodes = 0
    type(a23bu_headcalc_scratch_t) :: headcalc
    type(a23bu_solver_history_t) :: history
    type(a23bu_solver_diagnostics_t) :: diagnostics
    type(a23bu_soil_water_trial_result_t) :: soil_water_trial
    type(a23bu_numerical_control_t) :: control
    type(a23bu_timestep_decision_trace_t) :: timestep_trace
    type(a23bu_timestep_shadow_memory_t) :: timestep_shadow
    type(a23bu_execution_time_t) :: time
    type(a23bu_reporting_progress_t) :: reporting
    ! F-KT21 trajectory directions are optional worker/job-local numerical
    ! scratch. They are checkpointed only in transaction attempt contexts and
    ! are never persistent physical column state.
    type(accepted_trajectory_direction_t) :: trajectory_direction
  end type a23bu_worker_context_t

  public :: a23bu_initialize_worker, a23bu_release_worker
  public :: a23bu_reset_attempt_diagnostics, a23bu_record_internal_retry
  public :: a23bu_reset_soil_water_trial_result
  public :: a23bu_reset_attempt_control, a23bu_reset_all_numerical_control
  public :: a23bu_seed_timestep_control, a23bu_request_dt_reduction
  public :: a23bu_seed_execution_window, a23bu_reset_calendar_events
  public :: a23bu_seed_reporting_progress
  public :: a23bu_record_timestep_trace, a23bu_reset_timestep_trace
  public :: a23bu_discard_unaccepted_trajectory_step, a23bu_accept_pending_trajectory_step
  public :: a23bu_scratch_payload_bytes, a23bu_reporting_shim_payload_bytes

contains

  subroutine a23bu_initialize_worker(worker, active_nodes, worker_id)
    type(a23bu_worker_context_t), intent(inout) :: worker
    integer, intent(in) :: active_nodes
    integer, intent(in), optional :: worker_id

    if (active_nodes <= 0) error stop 'A23BU worker: active_nodes must be positive'
    call a23bu_release_worker(worker)
    worker%active_nodes = active_nodes
    if (present(worker_id)) worker%worker_id = worker_id
    allocate(worker%headcalc%dfdhl(active_nodes), worker%headcalc%dfdhm(active_nodes), &
             worker%headcalc%dfdhu(active_nodes), worker%headcalc%difh(active_nodes), &
             worker%headcalc%residual(active_nodes), worker%headcalc%sink(active_nodes), &
             worker%headcalc%source(active_nodes), worker%headcalc%dkdh(active_nodes), &
             worker%headcalc%hold(active_nodes), worker%headcalc%qv(active_nodes+1), &
             worker%headcalc%hgrad(active_nodes+1), worker%headcalc%flnonconv1(active_nodes), &
             worker%headcalc%flnonconv2(active_nodes))
    worker%headcalc%dfdhl = 0.0_real64
    worker%headcalc%dfdhm = 0.0_real64
    worker%headcalc%dfdhu = 0.0_real64
    worker%headcalc%difh = 0.0_real64
    worker%headcalc%residual = 0.0_real64
    worker%headcalc%sink = 0.0_real64
    worker%headcalc%source = 0.0_real64
    worker%headcalc%dkdh = 0.0_real64
    worker%headcalc%hold = 0.0_real64
    worker%headcalc%qv = 0.0_real64
    worker%headcalc%hgrad = 0.0_real64
    worker%headcalc%flnonconv1 = .false.
    worker%headcalc%flnonconv2 = .false.
    worker%headcalc%flunsatok = .false.
    worker%history = a23bu_solver_history_t()
    worker%diagnostics = a23bu_solver_diagnostics_t()
    worker%soil_water_trial = a23bu_soil_water_trial_result_t()
    worker%control = a23bu_numerical_control_t()
    worker%timestep_trace = a23bu_timestep_decision_trace_t()
    worker%timestep_shadow = a23bu_timestep_shadow_memory_t()
    worker%time = a23bu_execution_time_t()
    worker%reporting = a23bu_reporting_progress_t()
    worker%trajectory_direction = accepted_trajectory_direction_t()
  end subroutine a23bu_initialize_worker

  subroutine a23bu_release_worker(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    if (allocated(worker%headcalc%dfdhl)) deallocate(worker%headcalc%dfdhl)
    if (allocated(worker%headcalc%dfdhm)) deallocate(worker%headcalc%dfdhm)
    if (allocated(worker%headcalc%dfdhu)) deallocate(worker%headcalc%dfdhu)
    if (allocated(worker%headcalc%difh)) deallocate(worker%headcalc%difh)
    if (allocated(worker%headcalc%residual)) deallocate(worker%headcalc%residual)
    if (allocated(worker%headcalc%sink)) deallocate(worker%headcalc%sink)
    if (allocated(worker%headcalc%source)) deallocate(worker%headcalc%source)
    if (allocated(worker%headcalc%dkdh)) deallocate(worker%headcalc%dkdh)
    if (allocated(worker%headcalc%hold)) deallocate(worker%headcalc%hold)
    if (allocated(worker%headcalc%qv)) deallocate(worker%headcalc%qv)
    if (allocated(worker%headcalc%hgrad)) deallocate(worker%headcalc%hgrad)
    if (allocated(worker%headcalc%flnonconv1)) deallocate(worker%headcalc%flnonconv1)
    if (allocated(worker%headcalc%flnonconv2)) deallocate(worker%headcalc%flnonconv2)
    worker%active_nodes = 0
    worker%history = a23bu_solver_history_t()
    worker%diagnostics = a23bu_solver_diagnostics_t()
    worker%soil_water_trial = a23bu_soil_water_trial_result_t()
    worker%control = a23bu_numerical_control_t()
    worker%timestep_trace = a23bu_timestep_decision_trace_t()
    worker%timestep_shadow = a23bu_timestep_shadow_memory_t()
    worker%time = a23bu_execution_time_t()
    worker%reporting = a23bu_reporting_progress_t()
    worker%trajectory_direction = accepted_trajectory_direction_t()
  end subroutine a23bu_release_worker

  subroutine a23bu_reset_attempt_diagnostics(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    worker%diagnostics = a23bu_solver_diagnostics_t()
  end subroutine a23bu_reset_attempt_diagnostics

  subroutine a23bu_reset_soil_water_trial_result(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    worker%soil_water_trial = a23bu_soil_water_trial_result_t()
  end subroutine a23bu_reset_soil_water_trial_result

  subroutine a23bu_reset_attempt_control(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    worker%control%last_numbit = 0
    worker%control%request_dt_reduction = .false.
  end subroutine a23bu_reset_attempt_control

  subroutine a23bu_reset_all_numerical_control(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    worker%control = a23bu_numerical_control_t()
  end subroutine a23bu_reset_all_numerical_control

  subroutine a23bu_seed_timestep_control(worker, dt, dtmin)
    type(a23bu_worker_context_t), intent(inout) :: worker
    real(real64), intent(in) :: dt, dtmin
    real(real64), parameter :: dtcrit = 1.0e-8_real64
    call a23bu_reset_attempt_control(worker)
    worker%control%at_min_dt = dt <= (1.0_real64 + dtcrit) * dtmin
  end subroutine a23bu_seed_timestep_control

  subroutine a23bu_request_dt_reduction(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    worker%control%request_dt_reduction = .true.
  end subroutine a23bu_request_dt_reduction

  subroutine a23bu_seed_execution_window(worker, t0, t1, legacy_start, legacy_end)
    type(a23bu_worker_context_t), intent(inout) :: worker
    real(real64), intent(in) :: t0, t1, legacy_start, legacy_end
    worker%time%interval_t0 = t0
    worker%time%interval_t1 = t1
    worker%time%legacy_start = legacy_start
    worker%time%legacy_end = legacy_end
    call a23bu_reset_calendar_events(worker)
  end subroutine a23bu_seed_execution_window

  subroutine a23bu_reset_calendar_events(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    worker%time%day_start_event = .false.
    worker%time%day_end_event = .false.
  end subroutine a23bu_reset_calendar_events

  subroutine a23bu_reset_timestep_trace(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    worker%timestep_trace = a23bu_timestep_decision_trace_t()
  end subroutine a23bu_reset_timestep_trace

  subroutine a23bu_record_timestep_trace(worker, input_dt, preferred_dt, executed_dt, proposal_reason, limit_reason, event_clamped)
    type(a23bu_worker_context_t), intent(inout) :: worker
    real(real64), intent(in) :: input_dt, preferred_dt, executed_dt
    integer, intent(in) :: proposal_reason, limit_reason
    logical, intent(in) :: event_clamped

    worker%timestep_trace%available = .true.
    worker%timestep_trace%input_dt = input_dt
    worker%timestep_trace%preferred_dt = preferred_dt
    worker%timestep_trace%executed_dt = executed_dt
    worker%timestep_trace%proposal_reason = proposal_reason
    worker%timestep_trace%limit_reason = limit_reason
    worker%timestep_trace%event_clamped = event_clamped
  end subroutine a23bu_record_timestep_trace

  subroutine a23bu_seed_reporting_progress(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    worker%reporting = a23bu_reporting_progress_t()
  end subroutine a23bu_seed_reporting_progress

  subroutine a23bu_record_internal_retry(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    worker%diagnostics%internal_retries = worker%diagnostics%internal_retries + 1
  end subroutine a23bu_record_internal_retry

  subroutine a23bu_discard_unaccepted_trajectory_step(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    if (.not. worker%trajectory_direction%requested) return
    if (.not. worker%trajectory_direction%pending .and. .not. worker%trajectory_direction%issued) return
    call fkt21_discard_trajectory_step(worker%trajectory_direction)
  end subroutine a23bu_discard_unaccepted_trajectory_step

  subroutine a23bu_accept_pending_trajectory_step(worker)
    type(a23bu_worker_context_t), intent(inout) :: worker
    logical :: accepted
    if (.not. worker%trajectory_direction%requested) return
    if (.not. worker%trajectory_direction%pending) return
    call fkt21_accept_trajectory_step(worker%trajectory_direction, accepted)
    ! Optional directional sensitivity can fail closed without invalidating the
    ! already-accepted physical substep. The trajectory state itself records
    ! FAILED/UNAVAILABLE provenance for publication.
  end subroutine a23bu_accept_pending_trajectory_step

  integer function a23bu_reporting_shim_payload_bytes() result(bytes)
    integer :: rb, ib, lb
    rb = storage_size(0.0_real64)/8
    ib = storage_size(0)/8
    lb = storage_size(.false.)/8
    bytes = 4*ib + 2*rb + 6*lb
  end function a23bu_reporting_shim_payload_bytes

  integer function a23bu_scratch_payload_bytes(worker) result(bytes)
    type(a23bu_worker_context_t), intent(in) :: worker
    integer :: rb, lb
    rb = storage_size(0.0_real64)/8
    lb = storage_size(.false.)/8
    bytes = 0
    if (allocated(worker%headcalc%dfdhl)) then
      bytes = rb * (size(worker%headcalc%dfdhl) + size(worker%headcalc%dfdhm) + &
                    size(worker%headcalc%dfdhu) + size(worker%headcalc%difh) + &
                    size(worker%headcalc%residual) + size(worker%headcalc%sink) + &
                    size(worker%headcalc%source) + size(worker%headcalc%dkdh) + &
                    size(worker%headcalc%hold) + size(worker%headcalc%qv) + &
                    size(worker%headcalc%hgrad))
      bytes = bytes + lb * (size(worker%headcalc%flnonconv1) + size(worker%headcalc%flnonconv2) + &
                            size(worker%headcalc%flunsatok))
    end if
    if (allocated(worker%trajectory_direction%pressure_head_direction)) &
      bytes = bytes + rb*size(worker%trajectory_direction%pressure_head_direction)
    if (allocated(worker%trajectory_direction%water_content_direction)) &
      bytes = bytes + rb*size(worker%trajectory_direction%water_content_direction)
    if (allocated(worker%trajectory_direction%pending_pressure_head_direction)) &
      bytes = bytes + rb*size(worker%trajectory_direction%pending_pressure_head_direction)
    if (allocated(worker%trajectory_direction%pending_water_content_direction)) &
      bytes = bytes + rb*size(worker%trajectory_direction%pending_water_content_direction)
  end function a23bu_scratch_payload_bytes

end module mod_a23bu_worker_execution_context
