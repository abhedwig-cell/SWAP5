program test_pond_thermal
 use iso_fortran_env,only:real64,int64
 use ieee_arithmetic,only:ieee_value,ieee_quiet_nan
 use mod_canonical_contracts,only:canonical_numerical_config_t
 use mod_fmr_runtime_core
 use mod_fmr_serialized_reference_backend
 use mod_fmr_production_application_bootstrap
 use mod_kernel_transactions
 use mod_fixed_flux_top_boundary_provider
 use mod_b110_default_mvg_provider
 use MOD_grid,only:numnod,z,dz,disnod
 use mod_transaction_reference,only:transaction_state_t,TX_TEMPORAL_EXTERNAL_FULL_HALF
 use mod_b111_reactive_solute_substep,only:b111_reactive_solute_substep_forcing_t
 use mod_fmr_b111_matrix_solute_route
 use mod_fmr_b111_matrix_joint_application,only:matrix_joint_result_t,JOINT_OK,JOINT_CHEMICAL_REJECTED
 use mod_fmr_b111_pond_thermal_application
 use mod_pond_thermal_restart_file
 use mod_b111_persistent_pond,only:pond_step_t
 use mod_soil_temperature_contract
 use mod_restricted_surface_evaporation,only:black_evaporation_state_t
 use mod_rutter_source_window_processor,only:initialize_rutter_canopy_state
 use mod_interception_source_window_runtime,only:initialize_interception_window
 use mod_restricted_soil_temperature,only:initialize_soil_temperature_parameters
 use mod_solute_mobile_salt_state,only:mobile_salt_state_t
 use mod_solute_compartment_state,only:solute_compartment_state_t
 use b111_literal_oracle,only:literal_step
 use solute_column_context,only:initialize_column_context
 implicit none
 real(real64),parameter::HARD_MASS_GATE=1d-10
 type(fmr_production_application_config_t)::cfg
 type(fmr_serialized_reference_backend_t)::backend
 type(fixed_flux_top_boundary_provider_t),target::top
 type(fmr_logical_column_t)::column
 type(kernel_committed_state_t)::water,initial,badwater
 type(matrix_solute_state_t)::chemical,initial_c,badchemical
 type(b111_reactive_solute_substep_forcing_t)::p,pbad
 type(matrix_joint_result_t)::r
 real(real64)::k,dt,t0,t1,decay_total,max_residual,exponent
 logical::rutter_black=.false.
 integer::status,j,windows,first,last,accepted
 integer(int64)::restore_id
 character(512)::mode,path,endpoint,arg
 call get_command_argument(1,mode);call get_command_argument(2,path);call get_command_argument(3,endpoint)
 call get_command_argument(4,arg);read(arg,*)windows
 exponent=1d0
 call get_command_argument(5,arg)
 if(len_trim(arg)>0)read(arg,*)exponent
 rutter_black=index(trim(mode),"rutter-")==1
 if(rutter_black)mode=mode(8:)
 t0=0d0;t1=.001d0
 call initialize_column_context([.5d0,.5d0,1d0,1d0])
 call initialize_application_config(cfg,-75d0,k)
 ! Same low-conductivity pond fixture as the admitted evolving surface route.
 cfg%tiles(1)%parameters%cofgen(3,:)=cfg%tiles(1)%parameters%cofgen(3,:)*1d-3
 cfg%tiles(1)%parameters%cofgen(10,:)=cfg%tiles(1)%parameters%cofgen(10,:)*1d-3
 cfg%tiles(1)%parameters%cofgen(12,:)=cfg%tiles(1)%parameters%cofgen(12,:)*1d-3
 cfg%tiles(1)%template%numerical_continuation_layout_id=FMR_NUMERICAL_CONTINUATION_NONE
 cfg%tiles(1)%template%optional_state_layout_id=FMR_OPTIONAL_STATE_LAYOUT_RESTRICTED_SOIL_TEMPERATURE
 cfg%tiles(1)%parameters%soil_temperature_active=.true.
 allocate(cfg%tiles(1)%parameters%soil_temperature,cfg%tiles(1)%initial_state%soil_temperature, &
  cfg%tiles(1)%base_forcing%soil_temperature)
 call initialize_soil_temperature_parameters(dz,disnod(1:numnod),cfg%tiles(1)%parameters%cofgen(2,:), &
  spread(.3d0,1,numnod),spread(.2d0,1,numnod),spread(.04d0,1,numnod),cfg%tiles(1)%parameters%soil_temperature,status)
 call require(status==0,'heat parameters')
 call initialize_soil_temperature_state([5d0,10d0,20d0,35d0],cfg%tiles(1)%initial_state%soil_temperature,status)
 call require(status==0,'nonuniform thermal owner')
 cfg%tiles(1)%base_forcing%top_flux=0d0;cfg%tiles(1)%base_forcing%bottom_flux=-.1d0
 cfg%tiles(1)%base_forcing%drainage_flux_by_level=1d-4;cfg%tiles(1)%base_forcing%subsurface_irrigation_source=0d0
 cfg%tiles(1)%parameters%root_extraction_active=.true.
 cfg%tiles(1)%base_forcing%root_extraction_sink=1d-4
 cfg%tiles(1)%base_forcing%root_potential_transpiration=.0008d0
 cfg%numerical%transaction%temporal_mode=TX_TEMPORAL_EXTERNAL_FULL_HALF
 cfg%numerical%model_temporal_indicator_budget_available=.true.;cfg%numerical%model_temporal_indicator_budget=1d-6
 cfg%numerical%transaction%temporal_tolerance=1d-6
 cfg%numerical%transaction%max_retries=30;cfg%numerical%max_committed_substeps=10000
 column%column_id=cfg%tiles(1)%tile_id;column%template_id=cfg%tiles(1)%template%template_id
 column%parameter_ref=1;column%state_handle=1;column%forcing_handle=1;column%backend_id=FMR_BACKEND_SERIALIZED_REFERENCE
 cfg%tiles(1)%initial_state%ponding_depth=.5d0
 allocate(cfg%tiles(1)%base_forcing%pond_input)
 cfg%tiles(1)%base_forcing%pond_input%rain_rate_cm_day=.25d0
 cfg%tiles(1)%base_forcing%pond_input%irrigation_rate_cm_day=.25d0
 if(rutter_black)then
  cfg%tiles(1)%initial_state%ponding_depth=0d0
  cfg%tiles(1)%template%optional_state_layout_id=FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BLACK
  cfg%tiles(1)%parameters%black_evaporation_active=.true.
  cfg%tiles(1)%parameters%black_heat_composition_enabled=.true.
  cfg%tiles(1)%parameters%reactive_solute_active=.true.
  cfg%tiles(1)%parameters%root_extraction_active=.false.
  allocate(cfg%tiles(1)%parameters%black_evaporation,cfg%tiles(1)%initial_state%rutter)
  cfg%tiles(1)%parameters%black_evaporation%cofred=.5d0
  call initialize_rutter_canopy_state(.02d0,cfg%tiles(1)%initial_state%rutter,status)
  call require(status==0,'initial incumbent Rutter canopy')
  cfg%tiles(1)%base_forcing%root_extraction_sink=0d0
  cfg%tiles(1)%base_forcing%root_potential_transpiration=0d0
  deallocate(cfg%tiles(1)%base_forcing%pond_input)
  allocate(cfg%tiles(1)%base_forcing%black_evaporation,cfg%tiles(1)%base_forcing%rutter)
  associate(f=>cfg%tiles(1)%base_forcing%black_evaporation)
   f%precipitation_rate_cm_per_day=.25d0;f%irrigation_rate_cm_per_day=.25d0
   f%potential_bare_soil_evaporation_cm_per_day=.1d0;f%potential_pond_evaporation_cm_per_day=.01d0
   f%ponding_max_cm=1d0
  end associate
  associate(f=>cfg%tiles(1)%base_forcing%rutter)
   f%prepared=.true.
   call initialize_interception_window(19001_int64,0d0,.002d0,.0005d0,f%source_window,status)
   call require(status==0,'existing source window')
   f%process%vegetation_cover_fraction=.8d0;f%process%canopy_storage_capacity_cm=.01d0
   f%process%interception_evaporation_capacity_cm_per_day=.2d0;f%process%surface_irrigation_cm_per_day=.25d0
   f%potential_bare_soil_evaporation_cm_per_day=.1d0;f%potential_pond_evaporation_cm_per_day=.01d0
   f%ponding_max_cm=1d0
  end associate
 end if
 call parameters(p)
 call backend%initialize(top)
 if(index(trim(mode),'reject')==1)then
  restore_id=9001_int64
  if(trim(mode)=='reject-id')restore_id=9002_int64
  if(trim(mode)=='reject-heat')cfg%tiles(1)%parameters%soil_temperature%theta_sat(1)=.99d0
  if(trim(mode)=='reject-chemical')p%decpot=p%decpot*2d0
  call read_pond_thermal_restart(trim(path),column,cfg%tiles(1)%template,670001_int64,restore_id, &
   cfg%tiles(1)%parameters,p,water,chemical,status)
  call require(status/=0.and..not.water%ready().and..not.chemical%ready(),'invalid generation atomic reject')
  print '(A)','THERMAL_INVALID_RESTART=PASS';stop
 end if
 if(trim(mode)=='resume')then
  call read_pond_thermal_restart(trim(path),column,cfg%tiles(1)%template,670001_int64,9001_int64, &
   cfg%tiles(1)%parameters,p,water,chemical,status)
  call require(status==0,'fresh-process complete thermal reconstruction')
  first=windows/2+1
 else
  call initialize_owners(water,chemical,p)
  first=1
 end if
 last=windows
 if(trim(mode)=='split')last=windows/2
 decay_total=0d0;max_residual=0d0;accepted=0
 if(trim(mode)=='controls')then
  initial=water;initial_c=chemical
  cfg%tiles(1)%base_forcing%soil_temperature%prescribed_surface_temperature_c=30d0
  pbad=p;pbad%decpot=1d6
  call initialize_matrix_solute(pbad,9001_int64,0d0,cfg%tiles(1)%initial_state%water_content, &
   [.2d0,.3d0,.4d0,.5d0],badchemical,status)
  call require(status==0,'overdraw parameters valid')
  badwater=water
  call write_pond_thermal_restart(trim(endpoint)//'.before',column,cfg%tiles(1)%template,670001_int64, &
   cfg%tiles(1)%parameters,badwater,badchemical,status);call require(status==0,'before rejected joint generation')
  call run_test_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,badwater, &
   cfg%tiles(1)%base_forcing,cfg%numerical,badchemical,0d0,.001d0,r)
  call require(r%status==JOINT_CHEMICAL_REJECTED,'chemical failure rejects staged heat and water')
  call write_pond_thermal_restart(trim(endpoint)//'.after',column,cfg%tiles(1)%template,670001_int64, &
   cfg%tiles(1)%parameters,badwater,badchemical,status);call require(status==0,'unchanged rejected joint generation')
  call run_test_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,badwater, &
   cfg%tiles(1)%base_forcing,cfg%numerical,badchemical,0d0,1d-9,r)
  if(r%status/=0)print *,'RETRY DIAGNOSTIC',r%status,r%water%status,r%chemical%status,r%chemical%process_status
  call require(r%status==0,'smaller physical retry')
  block
   type(fmr_b110_physical_forcing_t)::invalid
   invalid=cfg%tiles(1)%base_forcing;invalid%root_extraction_sink=-1d0
   call run_test_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water, &
    invalid,cfg%numerical,chemical,0d0,.001d0,r)
   call require(r%status/=0,'invalid water rejected')
   call write_pond_thermal_restart(trim(endpoint)//'.hydraulic',column,cfg%tiles(1)%template,670001_int64, &
    cfg%tiles(1)%parameters,water,chemical,status);call require(status==0,'hydraulic rejection serializable')
   call write_pond_thermal_restart(trim(endpoint)//'.initial',column,cfg%tiles(1)%template,670001_int64, &
    cfg%tiles(1)%parameters,initial,initial_c,status);call require(status==0,'initial serializable')
  end block
  call run_test_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water, &
   cfg%tiles(1)%base_forcing,cfg%numerical,chemical,ieee_value(0d0,ieee_quiet_nan),.001d0,r)
  call require(r%status/=0,'nonfinite clock rejected under FPE traps')
  pbad=p;pbad%frexp=.49999d0
  call initialize_matrix_solute(pbad,9001_int64,0d0,cfg%tiles(1)%initial_state%water_content, &
   [.2d0,.3d0,.4d0,.5d0],badchemical,status)
  call require(status/=0,'below admitted nonlinear exponent rejected at owner construction')
  pbad=p;pbad%frexp=2.00001d0
  call initialize_matrix_solute(pbad,9001_int64,0d0,cfg%tiles(1)%initial_state%water_content, &
   [.2d0,.3d0,.4d0,.5d0],badchemical,status)
  call require(status/=0,'above admitted nonlinear exponent rejected at owner construction')
  cfg%tiles(1)%parameters%soil_temperature%solution_mode=SOIL_TEMP_SOLUTION_ANALYTIC
  call run_test_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,water, &
   cfg%tiles(1)%base_forcing,cfg%numerical,chemical,0d0,.001d0,r)
  call require(r%status/=0.and.water%current_revision()==initial%current_revision(),'unqualified analytic thermal composition rejected')
  cfg%tiles(1)%parameters%soil_temperature%solution_mode=SOIL_TEMP_SOLUTION_NUMERIC
  ! Source SWHEA=0 branch: actual heat may evolve, decay remains zero.
  pbad=p;pbad%temperature_active=.false.
  call initialize_owners(badwater,badchemical,pbad)
  call checked_interval(badwater,badchemical,0d0,.001d0,pbad)
  call require(r%chemical%decay_out==0d0,'historical heat-off zero factor')
  print '(A)','THERMAL_REJECTION_RETRY_HEAT_OFF=PASS';stop
 end if
 do j=first,last
  t0=.002d0*real(j-1,real64)/real(windows,real64);t1=.002d0*real(j,real64)/real(windows,real64)
  cfg%tiles(1)%base_forcing%soil_temperature%prescribed_surface_temperature_c=5d0
  if(j>windows/2)cfg%tiles(1)%base_forcing%soil_temperature%prescribed_surface_temperature_c=30d0
  if(rutter_black)then
   call checked_rutter_interval(water,chemical,t0,t1)
  else
   call checked_interval(water,chemical,t0,t1,p)
  end if
  decay_total=decay_total+r%chemical%decay_out;max_residual=max(max_residual,abs(r%chemical%residual))
  accepted=accepted+r%chemical%completed_substeps
 end do
 call endpoint_controls(water,chemical,t1)
 if(trim(mode)=='split')then
  call write_pond_thermal_restart(trim(path),column,cfg%tiles(1)%template,670001_int64, &
   cfg%tiles(1)%parameters,water,chemical,status)
 else
  call write_pond_thermal_restart(trim(endpoint),column,cfg%tiles(1)%template,670001_int64, &
   cfg%tiles(1)%parameters,water,chemical,status)
 end if
 call require(status==0,'publish complete thermal generation')
 print '(A,I0)','ACCEPTED=',accepted
 print '(A,ES25.17)','DECAY=',decay_total
 print '(A,ES25.17)','MAX_SOLUTE_RESIDUAL=',max_residual
 call summary(water,chemical)
 if(rutter_black)then
  print '(A)','BLACK_RUTTER_HEAT_REACTIVE_MASS_RESTART=PASS'
 else
  print '(A)','THERMAL_PHYSICAL_LITERAL_RESTART=PASS'
 end if
contains
 subroutine checked_rutter_interval(w,c,a,b)
  type(kernel_committed_state_t),intent(inout)::w
  type(matrix_solute_state_t),intent(inout)::c
  real(real64),intent(in)::a,b
  class(transaction_state_t),allocatable::physical
  type(fmr_serialized_physical_observation_t)::obs
  type(mobile_salt_state_t)::m
  type(solute_compartment_state_t)::s
  real(real64),allocatable::theta(:)
  real(real64)::time,mass0,mass1,water_residual,stock0,stock1,canopy0,canopy1,rutter_residual
  integer(int64)::revision
  integer::h
  logical::ok
  call c%snapshot(time,theta,m,s,revision);mass0=sum(m%mass_mg_cm2)+s%solute_total()
  call w%snapshot(physical,ok);call require(ok,'initial full water stock')
  select type(q=>physical)
  type is(fmr_b110_black_evaporation_state_t)
   canopy0=q%rutter%canopy_storage();stock0=sum(dz*q%water_content)+q%ponding_depth+canopy0
  class default
   call require(.false.,'initial Black/canopy owner')
  end select
  call run_test_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w, &
       cfg%tiles(1)%base_forcing,cfg%numerical,c,a,b,r)
  if(r%status/=0)print *,'BLACK_RUTTER_DIAGNOSTIC',r%status,r%water%status,r%chemical%status, &
       r%diagnostics%admission_rejections,r%diagnostics%solver_rejections,r%diagnostics%mass_rejections
  call require(r%status==JOINT_OK,'existing Black Rutter heat reactive interval')
  call c%snapshot(time,theta,m,s,revision);mass1=sum(m%mass_mg_cm2)+s%solute_total()
  call require(abs(mass1-mass0-r%chemical%external_in+r%chemical%external_out)<1d-10,'direct chemical stock ledger')
  call require(abs(r%water%mass%residual)<1d-10,'direct water stock ledger')
  obs=backend%observation();water_residual=0d0
  call require(obs%accepted_water_flux_trace_available,'actual trial water trace')
  do h=1,size(obs%accepted_water_flux_substeps)
   associate(t=>obs%accepted_water_flux_substeps(h))
    water_residual=water_residual+sum(dz*(t%water_end-t%water_start))- &
         (t%t1-t%t0)*(t%bottom_flux-t%top_flux+sum(t%net_node_source))
    call require(t%rutter_reservoir_available,'same accepted trial canopy receipt')
    rutter_residual=(t%rutter_gross_rain_rate_cm_day+t%rutter_gross_irrigation_rate_cm_day- &
         t%converged_rain_rate_cm_day-t%converged_irrigation_rate_cm_day)*(t%t1-t%t0)- &
         t%rutter_evaporation_cm-t%rutter_canopy_end_cm+t%rutter_canopy_start_cm
    call require(abs(rutter_residual)<1d-10.and.abs(t%rutter_reservoir_residual_cm)<1d-10,'independent canopy stock ledger')
    call require(t%reactive_chemical_available,'same accepted trial chemical receipt')
   end associate
  end do
  call require(abs(water_residual)<1d-10,'independent actual matrix stock balance')
  call w%snapshot(physical,ok);call require(ok,'same incumbent physical owner')
  select type(q=>physical)
  type is(fmr_b110_black_evaporation_state_t)
   call require(allocated(q%rutter).and.allocated(q%reactive_solute),'incumbent canopy and reactive owners')
   call require(q%rutter%accepted_until()==b,'actual Rutter endpoint clock')
   call require(q%rutter%canopy_storage()<=.01d0,'source falling-leaf capacity bound')
   call require(q%reactive_solute%same_state(c),'single authoritative chemical state and export mirror')
   canopy1=q%rutter%canopy_storage();stock1=sum(dz*q%water_content)+q%ponding_depth+canopy1
   call require(abs(stock1-stock0-r%water%mass%total_in+r%water%mass%total_out)<1d-10,'complete matrix pond canopy stock ledger')
   call require(abs(r%water%mass%total_in-.5d0*(b-a))<1d-10,'actual gross canopy and surface input ledger')

  class default
   call require(.false.,'existing Black physical state type')
  end select
 call incomplete_endpoint_control(w,b)
 end subroutine checked_rutter_interval

 subroutine run_test_interval(backend,column,template,parameters,water,forcing,config,chemical,a,b,result)
  type(fmr_serialized_reference_backend_t),intent(inout)::backend
  type(fmr_logical_column_t),intent(in)::column
  type(fmr_template_t),intent(in)::template
  type(fmr_b110_physical_parameters_t),target,intent(in)::parameters
  type(kernel_committed_state_t),intent(inout)::water
  type(fmr_b110_physical_forcing_t),intent(in)::forcing
  type(canonical_numerical_config_t),intent(in)::config
  type(matrix_solute_state_t),intent(inout)::chemical
  real(real64),intent(in)::a,b
  type(matrix_joint_result_t),intent(out)::result
  type(pond_step_t)::supply
  supply%t0=a;supply%t1=b;supply%rain_rate=.25d0;supply%irrigation_rate=.25d0
  supply%rain_c=.125d0;supply%irrigation_c=.375d0
  if(rutter_black)then;supply%rain_c=0d0;supply%irrigation_c=0d0;end if
  call run_pond_thermal_interval(backend,column,template,parameters,water,forcing,config,chemical,supply,a,b,result)
 end subroutine
 subroutine summary(w,c)
  type(kernel_committed_state_t),intent(in)::w
  type(matrix_solute_state_t),intent(in)::c
  class(transaction_state_t),allocatable::physical
  type(soil_temperature_field_view_t)::heat
  type(mobile_salt_state_t)::m
  type(solute_compartment_state_t)::s
  real(real64),allocatable::theta(:)
  real(real64)::time
  integer(int64)::rev
  integer::code
  logical::ok
  call w%snapshot(physical,ok);call require(ok,'endpoint snapshot')
  select type(physical)
  class is(fmr_b110_physical_state_t)
   call build_soil_temperature_field_view(physical%soil_temperature,heat,code)
  end select
  call require(code==0,'endpoint thermal summary')
  call c%snapshot(time,theta,m,s,rev)
  print '(A,5ES25.17)','MASS_VECTOR=',m%mass_mg_cm2+s%sorbed_matrix_mass,s%pond_mass
  print '(A,4ES25.17)','HEAT_VECTOR=',heat%temperature_c
 end subroutine
 subroutine initialize_owners(w,c,f)
  type(kernel_committed_state_t),intent(out)::w
  type(matrix_solute_state_t),intent(out)::c
  type(b111_reactive_solute_substep_forcing_t),intent(in)::f
  type(kernel_committed_state_t)::tmp
  class(transaction_state_t),allocatable::physical
  logical::ok
  if(rutter_black)then
   call fmr_new_b110_black_evaporation_committed_state(w,column%column_id,cfg%tiles(1)%initial_state, &
        black_evaporation_state_t(),0d0,ok,parameters=cfg%tiles(1)%parameters)
  else
  call fmr_new_b110_committed_state(w,column%column_id,cfg%tiles(1)%initial_state,0d0,ok,parameters=cfg%tiles(1)%parameters)
  end if
  call require(ok,'initial certified heat water')
  call initialize_matrix_solute(f,9001_int64,0d0,cfg%tiles(1)%initial_state%water_content, &
   [.2d0,.3d0,.4d0,.5d0],c,status);call require(status==0,'initial chemical owner')
  block
   real(real64),allocatable::theta(:)
   real(real64)::time
   integer(int64)::rev
   type(mobile_salt_state_t)::m
   type(solute_compartment_state_t)::s
   type(matrix_solute_state_t)::next
   call c%snapshot(time,theta,m,s,rev)
   call reconstruct_matrix_solute_trusted(f,9001_int64,rev,time,theta,m%concentration_mg_cm3,m%mass_mg_cm2, &
    s%sorbed_matrix_mass,next,status,surface_mass=merge(0d0,.25d0,rutter_black))
   call require(status==0,'initial pond chemistry');c=next
  end block
  call require(pond_thermal_states_match(w,c),'initial joint match')
 end subroutine
 subroutine checked_interval(w,c,a,b,f)
  type(kernel_committed_state_t),intent(inout)::w
  type(matrix_solute_state_t),intent(inout)::c
  real(real64),intent(in)::a,b
  type(b111_reactive_solute_substep_forcing_t),intent(in)::f
  class(transaction_state_t),allocatable::physical
  type(soil_temperature_field_view_t)::heat
  type(fmr_serialized_physical_observation_t)::obs
  type(b111_reactive_solute_substep_forcing_t)::oracle,config_after
  type(mobile_salt_state_t)::m
  type(solute_compartment_state_t)::s
  real(real64),allocatable::theta(:),conc(:),mass(:),water0(:),q(:)
  real(real64)::time,dec,ein,eout,expected_decay,water_residual,surface_mass
  integer(int64)::rev,id
  integer::i,h,code
  logical::ok
  call c%snapshot(time,theta,m,s,rev);conc=m%concentration_mg_cm3;mass=m%mass_mg_cm2+s%sorbed_matrix_mass
  water0=theta;surface_mass=s%pond_mass
  call run_test_interval(backend,column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w, &
   cfg%tiles(1)%base_forcing,cfg%numerical,c,a,b,r)
  if(r%status/=0)print *,'DIAGNOSTIC',r%status,r%water%status,r%chemical%status
  call require(r%status==JOINT_OK,'real coupled interval')
  call w%snapshot(physical,ok);call require(ok,'staged heat published')
  select type(physical)
  class is(fmr_b110_physical_state_t)
   call build_soil_temperature_field_view(physical%soil_temperature,heat,code)
  end select
  call require(code==0,'actual endpoint temperature')
  call require(maxval(abs(heat%temperature_c-f%temperature_c))>1d0,'actual profile differs from configured constant')
  oracle=f;oracle%temperature_c=heat%temperature_c
  obs=backend%observation();expected_decay=0d0;water_residual=0d0
  allocate(q(numnod+1))
  do h=1,size(obs%accepted_water_flux_substeps)
   associate(t=>obs%accepted_water_flux_substeps(h))
    oracle%dt_day=t%t1-t%t0;oracle%theta=t%water_end;oracle%theta_previous=t%water_start
    q(1)=t%top_flux
    do i=1,numnod
     q(i+1)=q(i)+(t%water_end(i)-t%water_start(i))*dz(i)/oracle%dt_day-t%net_node_source(i)
    end do
    water_residual=water_residual+sum(dz*(t%water_end-t%water_start))- &
     oracle%dt_day*(t%bottom_flux-t%top_flux+sum(t%net_node_source))
    oracle%q_face_up_cm_day=q;oracle%root_sink_cm_day=t%root_sink;oracle%qdra_cm_day=t%drainage_sink_by_level
    oracle%pond_end_cm=t%pond_end_cm
    oracle%rain_rate_cm_day=.25d0;oracle%rain_c_mg_cm3=.125d0
    oracle%irrigation_rate_cm_day=.25d0;oracle%irrigation_c_mg_cm3=.375d0
    call literal_step(oracle,conc,mass,surface_mass,dec,ein,eout);expected_decay=expected_decay+dec
   end associate
  end do
  call c%snapshot(time,theta,m,s,rev)
  call require(maxval(abs(m%concentration_mg_cm3-conc))<1d-12,'literal source concentration at dynamic heat')
  call require(maxval(abs(m%mass_mg_cm2+s%sorbed_matrix_mass-mass))<1d-12,'literal source inventory')
  call require(abs(s%pond_mass-surface_mass)<1d-12,'literal pond inventory')
  call require(abs(r%chemical%decay_out-expected_decay)<1d-12,'literal temperature moisture depth decay ledger')
  call require(abs(water_residual)<1d-10.and.abs(r%chemical%residual)<1d-11,'independent joint water/solute balance')
  call c%configuration(config_after,id)
  call require(all(matrix_parameter_vector(config_after)==matrix_parameter_vector(f)),'immutable chemical configuration')
 end subroutine
 subroutine parameters(f)
  type(b111_reactive_solute_substep_forcing_t),intent(out)::f
  f%frexp=exponent
  f%dz_cm=dz;f%theta=cfg%tiles(1)%initial_state%water_content
  f%bulk_density=spread(1.3d0,1,numnod);f%kf=spread(.2d0,1,numnod)
  f%temperature_active=.true.;f%temperature_c=spread(20d0,1,numnod)
  f%gampar=spread(.05d0,1,numnod);f%rtheta=spread(.3d0,1,numnod)
  f%bexp=spread(1d0,1,numnod);f%decpot=spread(.02d0,1,numnod);f%fdepth=[1d0,.8d0,.5d0,.2d0]
  f%face_distance_cm=disnod(2:numnod)
  f%face_left_weight=.5d0*dz(2:numnod)/f%face_distance_cm;f%face_right_weight=.5d0*dz(1:numnod-1)/f%face_distance_cm
  f%theta_sat_left=cfg%tiles(1)%parameters%cofgen(2,1:numnod-1)
  f%dispersivity_cm=spread(.2d0,1,numnod-1);f%molecular_diffusion_cm2_day=.05d0;f%tscf=.5d0
  f%cdrain_mg_cm3=.4d0;f%cseep_mg_cm3=.3d0
 end subroutine
 subroutine require(ok,label)
  logical,intent(in)::ok
  character(*),intent(in)::label
  if(.not.ok)then;print '(A)','FAIL '//label;error stop 1;end if
 end subroutine
 include 'matrix_fixture.inc'
 subroutine incomplete_endpoint_control(w,b)
  type(kernel_committed_state_t),intent(inout)::w
  real(real64),intent(in)::b
  type(kernel_candidate_state_t)::candidate
  type(kernel_result_t)::event
  type(kernel_diagnostics_t)::diagnostics
  integer(int64)::revision
  if(b>=.002d0)return
  revision=w%current_revision()
  call backend%run_canopy_capacity_event(column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w,.005d0,b, &
    cfg%numerical,event,candidate,diagnostics)
  call require(.not.event%completed.and..not.candidate%ready(),'incomplete immutable source window refuses event')
  call require(w%current_revision()==revision,'incomplete source refuses without publication')
 end subroutine

 subroutine endpoint_controls(w,c,b)
  type(kernel_committed_state_t),intent(inout)::w
  type(matrix_solute_state_t),intent(inout)::c
  real(real64),intent(in)::b
  type(kernel_candidate_state_t)::candidate,stale
  type(kernel_committed_state_t)::day_candidate
  type(kernel_result_t)::event
  type(kernel_diagnostics_t)::diagnostics
  type(fmr_logical_column_t)::wrong_column
  class(transaction_state_t),allocatable::raw
  real(real64)::before_canopy,expected,time
  integer(int64)::revision
  logical::ok
  integer::code
  call w%snapshot(raw,ok);call require(ok,'event origin snapshot')
  select type(q=>raw)
  type is(fmr_b110_black_evaporation_state_t)
   before_canopy=q%rutter%canopy_storage()
  class default
   error stop 'wrong event origin type'
  end select
  call require(before_canopy>.005d0,'wet discriminating event fixture')
  expected=before_canopy-.005d0;revision=w%current_revision()
  call write_pond_thermal_restart(trim(endpoint)//'.event-before',column,cfg%tiles(1)%template,670001_int64, &
    cfg%tiles(1)%parameters,w,c,code);call require(code==0,'event origin full typed serialization')
  wrong_column=column;wrong_column%column_id=column%column_id+1
  call backend%run_canopy_capacity_event(wrong_column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w,.005d0,b, &
    cfg%numerical,event,candidate,diagnostics)
  call require(.not.event%completed.and..not.candidate%ready(),'event wrong column refuses')
  call backend%run_canopy_capacity_event(column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w,.005d0,b-.0001d0, &
    cfg%numerical,event,candidate,diagnostics)
  call require(.not.event%completed.and..not.candidate%ready(),'event wrong endpoint refuses')
  call backend%run_canopy_capacity_event(column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w,-1d0,b, &
    cfg%numerical,event,candidate,diagnostics)
  call require(.not.event%completed.and..not.candidate%ready(),'negative event capacity refuses')
  call backend%run_canopy_capacity_event(column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w, &
    ieee_value(0d0,ieee_quiet_nan),b,cfg%numerical,event,candidate,diagnostics)
  call require(.not.event%completed.and..not.candidate%ready(),'NaN event capacity refuses under FPE traps')
  call backend%run_canopy_capacity_event(column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w,.005d0,b, &
    cfg%numerical,event,candidate,diagnostics)
  call require(event%completed.and.event%mass%complete.and.candidate%ready(),'actual wet owner event')
  call require(abs(event%mass%total_out-expected)<1d-14.and.abs(event%mass%residual)<1d-10,'actual event stock/export')
  stale=candidate
  call backend%discard_trial_candidate(candidate,diagnostics)
  call write_pond_thermal_restart(trim(endpoint)//'.event-rollback',column,cfg%tiles(1)%template,670001_int64, &
    cfg%tiles(1)%parameters,w,c,code);call require(code==0,'rolled back full owner serialization')
  call backend%run_canopy_capacity_event(column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w,.005d0,b, &
    cfg%numerical,event,candidate,diagnostics)
  call require(event%completed,'resample same current event origin')
  ! A later joint-day failure discards this complete staged water generation.
  ! Intrinsic committed-state cloning must not alias any persistent owner.
  day_candidate=w
  call backend%commit_trial_candidate(day_candidate,candidate,diagnostics,ok,code)
  call require(ok.and.day_candidate%current_revision()==revision+1,'event accepted only in staged day')
  call require(w%current_revision()==revision,'late day rejection preserves global revision')
  call write_pond_thermal_restart(trim(endpoint)//'.event-late-abort',column,cfg%tiles(1)%template,670001_int64, &
    cfg%tiles(1)%parameters,w,c,code);call require(code==0,'global owners after discarded staged event')
  candidate=stale
  call backend%commit_trial_candidate(w,candidate,diagnostics,ok,code)
  call require(ok.and.code==0.and.w%current_revision()==revision+1,'one accepted event revision')
  call w%current_time(time,ok);call require(ok.and.time==b,'event does not advance physical time')
  call backend%commit_trial_candidate(w,stale,diagnostics,ok,code)
  call require(.not.ok.and.code==KERNEL_COMMIT_STATUS_STALE_REVISION,'stale actual owner event refuses')
  call backend%discard_trial_candidate(stale,diagnostics)
  call backend%run_canopy_capacity_event(column,cfg%tiles(1)%template,cfg%tiles(1)%parameters,w,.005d0,b, &
    cfg%numerical,event,candidate,diagnostics)
  call require(.not.event%completed.and..not.candidate%ready(),'consumed hydraulic origin cannot export twice')
  call write_pond_thermal_restart(trim(endpoint)//'.event-after',column,cfg%tiles(1)%template,670001_int64, &
    cfg%tiles(1)%parameters,w,c,code);call require(code==0,'accepted full owner serialization')
  print '(a)','ACTUAL_RUTTER_ENDPOINT_EXPORT_ROLLBACK_LINEAGE_SOURCE_WINDOW_AND_STALE_CONTROLS_PASS'
 end subroutine

end program
