module crc_fixture
use iso_fortran_env,only:int8,int32,int64
implicit none
integer,parameter::MAX_BYTES=10485760
contains

  function crc32(bytes) result(crc)
    integer(int8),intent(in)::bytes(:)
    integer(int32)::crc
    integer::i,j,k
    integer(int32)::table(0:255),entry
    ! Separate the fixed polynomial table from the byte stream. The previous
    ! nested data/bit loop stalls under GNU Fortran16.2 Windows O2. This is the
    ! same reflected CRC-32/ISO-HDLC polynomial and initial/final complement.
    do k=0,255
      entry=int(k,int32)
      do j=1,8
        entry=ieor(shiftr(entry,1),iand(-iand(entry,1_int32),int(z'EDB88320',int32)))
      end do
      table(k)=entry
    end do
    crc=not(0_int32)
    do i=1,size(bytes)
      k=int(iand(ieor(crc,int(bytes(i),int32)),255_int32))
      crc=ieor(shiftr(crc,8),table(k))
    end do
    crc=not(crc)
  end function

subroutine append_crc(path,code)
character(*),intent(in)::path
integer,intent(out)::code
code=1
end subroutine
subroutine check_crc(path,code)
character(*),intent(in)::path
integer,intent(out)::code
code=1
end subroutine
end module
program probe
 use crc_fixture
 implicit none
 character(512)::mode,path
 integer::u,n,code
 integer(int8),allocatable::bytes(:)
 call get_command_argument(1,mode);call get_command_argument(2,path)
 select case(trim(mode))
 case('value')
  inquire(file=trim(path),size=n);allocate(bytes(n))
  open(newunit=u,file=trim(path),access='stream',form='unformatted',status='old',action='read')
  read(u)bytes;close(u);print '(I0)',crc32(bytes)
 case('append')
  call append_crc(trim(path),code);print '(I0)',code
 case('check')
  call check_crc(trim(path),code);print '(I0)',code
 end select
end program
