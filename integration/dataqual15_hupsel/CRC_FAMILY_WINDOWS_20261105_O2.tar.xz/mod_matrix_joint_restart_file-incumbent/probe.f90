module crc_fixture
use iso_fortran_env,only:int8,int32,int64
implicit none
integer,parameter::MAX_BYTES=10485760
contains

  function crc32(bytes) result(crc)
    integer(int8),intent(in)::bytes(:)
    integer(int32)::crc
    integer::i,j
    crc=not(0_int32)
    do i=1,size(bytes)
      crc=ieor(crc,iand(int(bytes(i),int32),int(z'FF',int32)))
      do j=1,8
        if(btest(crc,0))then
          crc=ieor(shiftr(crc,1),int(z'EDB88320',int32))
        else
          crc=shiftr(crc,1)
        end if
      end do
    end do
    crc=not(crc)
  end function


  subroutine append_crc(path,status)
    character(*),intent(in)::path
    integer,intent(out)::status
    integer(int8),allocatable::bytes(:)
    integer::u,n,io
    integer(int32)::crc
    status=1
    inquire(file=path,size=n,iostat=io)
    if(io/=0.or.n<1.or.n>MAX_BYTES-4)return
    allocate(bytes(n))
    open(newunit=u,file=path,access='stream',form='unformatted',status='old',action='readwrite',iostat=io)
    if(io/=0)return
    read(u,iostat=io)bytes
    if(io==0)then
      crc=crc32(bytes);write(u,pos=n+1,iostat=io)crc
    end if
    close(u)
    if(io==0)status=0
  end subroutine


  subroutine check_crc(path,status)
    character(*),intent(in)::path
    integer,intent(out)::status
    integer(int8),allocatable::bytes(:)
    integer::u,n,io
    integer(int32)::actual,expected
    status=1
    inquire(file=path,size=n,iostat=io)
    if(io/=0.or.n<12.or.n>MAX_BYTES)return
    allocate(bytes(n-4))
    open(newunit=u,file=path,access='stream',form='unformatted',status='old',action='read',iostat=io)
    if(io/=0)return
    read(u,iostat=io)bytes,expected
    close(u)
    if(io/=0)return
    actual=crc32(bytes)
    if(actual==expected)status=0
  end subroutine
end module
program probe
 use crc_fixture
 implicit none
 character(512)::mode,path
 integer::u,n,code
 integer(int8),allocatable::bytes(:)
 call get_command_argument(1,mode);call get_command_argument(2,path)
 select case(trim(mode))
 case('value')
  inquire(file=trim(path),size=n);allocate(bytes(n))
  open(newunit=u,file=trim(path),access='stream',form='unformatted',status='old',action='read')
  read(u)bytes;close(u);print '(I0)',crc32(bytes)
 case('append')
  call append_crc(trim(path),code);print '(I0)',code
 case('check')
  call check_crc(trim(path),code);print '(I0)',code
 end select
end program
