module mod_fmr_serialized_reference_backend
  use mod_fmr_water_flux_trace_contract,only:fmr_water_flux_substep_trace_t
  use mod_fmr_b111_matrix_solute_route,only:matrix_solute_state_t,matrix_solute_receipt_t,MATRIX_OK
  use mod_fmr_b111_pond_solute_route,only:consume_reactive_thermal_substep
  use mod_b111_persistent_pond,only:pond_step_t
  use, intrinsic :: iso_fortran_env, only: int64, real64, error_unit
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  use mod_transaction_reference, only: transaction_state_t, transaction_attempt_context_t, transaction_scratch_scope_t, trial_outcome_t, &
       TX_MASS_MISSING_NONE, TX_MASS_MISSING_UNSPECIFIED, TX_TEMPORAL_EXTERNAL_FULL_HALF, &
       TX_TEMPORAL_MODEL_CERTIFICATE
  use mod_pond_water_temporal_difference,only:evaluate_pond_water_temporal_difference, &
    water_flux_temporal_policy_t,evaluate_water_flux_temporal_difference
  use mod_fkt_temporal_indicator_history, only: fkt_temporal_indicator_history_t
  use mod_ppa_wu05_perch19_reduction_controller, only: macropore_reduction_continuation_t
  use mod_canonical_contracts, only: canonical_state_t, canonical_forcing_t, canonical_interval_t, &
       canonical_numerical_config_t
  use mod_kernel_transactions,only:kernel_reconstruct_committed_state_trusted
  use mod_kernel_transactions, only: kernel_parameter_identity_t, kernel_parameters_t, kernel_model_t, kernel_committed_state_t, &
       kernel_checkpoint_t, kernel_executor_t, kernel_result_t, kernel_candidate_state_t, kernel_diagnostics_t, &
       kernel_reference_floor_result_t, kernel_reference_floor_candidate_t, &
       KERNEL_STATUS_NOT_ADMITTED, KERNEL_REFERENCE_FLOOR_STATUS_NOT_ADMITTED
  use mod_fmr_checkpoint_orchestrator, only: fmr_trial_from_checkpoint, fmr_commit_candidate, fmr_discard_candidate
  use mod_fmr_mode7_temporal_head_envelope, only: fmr_mode7_head_envelope_assessment_t, &
       assess_fmr_mode7_temporal_head_envelope, FMR_MODE7_HEAD_ENVELOPE_OK
  use mod_fmr_runtime_core, only: fmr_logical_column_t, fmr_template_t, FMR_BACKEND_SERIALIZED_REFERENCE, &
       FMR_NUMERICAL_CONTINUATION_NONE, FMR_NUMERICAL_CONTINUATION_RICHARDS_TEMPORAL_HISTORY, &
       FMR_NUMERICAL_CONTINUATION_MACROPORE_REDUCTION, &
       FMR_OPTIONAL_STATE_LAYOUT_SNOW, FMR_OPTIONAL_STATE_LAYOUT_RESTRICTED_SOIL_TEMPERATURE, &
       fmr_optional_state_layout_known
  use mod_fmr_runtime_core, only: FMR_OPTIONAL_STATE_LAYOUT_BASE, FMR_OPTIONAL_STATE_LAYOUT_FIXED_WEIR_SURFACE_WATER, &
       FMR_OPTIONAL_STATE_LAYOUT_BLACK_EVAPORATION, FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_EVAPORATION, &
       FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_MACROPORE, FMR_OPTIONAL_STATE_LAYOUT_MACROPORE, &
       FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BOESTEN_MACROPORE, FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BLACK, &
       FMR_OPTIONAL_STATE_LAYOUT_RFM, FMR_OPTIONAL_STATE_LAYOUT_RUTTER, &
       FMR_SOLUTE_STATE_LAYOUT_NONE, FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED, &
       FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED_MACROPORE, fmr_solute_state_layout_known
  use mod_interception_source_window_runtime, only: interception_source_window_t
  use mod_rutter_interception_process, only: rutter_interval_input_t, rutter_interval_result_t, rutter_diagnostics_t, &
       RUTTER_OK
  use mod_rutter_source_window_processor, only: rutter_source_state_t, rutter_source_trial_t, &
       initialize_rutter_source_state, initialize_rutter_canopy_state, prepare_rutter_source_trial, &
       accept_rutter_source_trial, RUTTER_WINDOW_OK
  use mod_fmr_bottom_thermal_carrier, only: fmr_bottom_thermal_carrier_t, fmr_bottom_thermal_candidate_t
  use mod_fmr_top_sensible_boundary_carrier, only: fmr_top_sensible_boundary_carrier_t, &
       fmr_top_sensible_boundary_candidate_t
  use mod_soil_water_solver_contract, only: soil_water_parameter_set_t, soil_water_solve_request_t, &
       soil_water_solve_result_t, soil_water_solver_diagnostics_t, &
       soil_water_top_boundary_result_t, top_boundary_provider_t, &
       SW_SOLVE_CONVERGED, SW_TOP_BOUNDARY_AVAILABLE, &
       soil_water_temporal_indicator_request_t, soil_water_temporal_indicator_result_t, &
       SW_TEMPORAL_INDICATOR_NOT_RUN
  use mod_soil_water_accepted_step_direction_contract, only: soil_water_accepted_step_direction_request_t, &
       soil_water_accepted_step_direction_result_t, SW_STEP_DIRECTION_UNAVAILABLE
  use mod_accepted_trajectory_directional_sensitivity, only: accepted_trajectory_direction_t, trajectory_step_token_t, &
       configure_trajectory_direction, begin_or_continue_trajectory, build_trajectory_step_request, &
       stage_trajectory_step_result, accept_trajectory_step, finalize_trajectory_direction
  use mod_accepted_trajectory_directional_publication, only: accepted_trajectory_direction_result_t, &
       publish_accepted_trajectory_direction
  use mod_reference_richards_accepted_step_directional_service, only: solve_with_accepted_step_direction
  use mod_reference_richards_state_binding, only: FSI_TOP_MODE_EXPLICIT_FLUX, FSI_TOP_MODE_DYNAMIC_PROVIDER
  use mod_reference_richards_legacy_binding, only: reference_richards_legacy_solver_t, &
       reference_richards_legacy_workspace_t, clear_reference_trial_guess
  use mod_fixed_flux_top_boundary_provider, only: fixed_flux_top_boundary_provider_t
  use mod_fmr_rossfast_solver_selection_binding, only: fmr_rossfast_solver_selection_binding_t, &
       FMR_ROSSFAST_BIND_INTERNAL_ERROR
  use mod_rossfast_d3r_model_binding, only: rossfast_d3r_material_t, rossfast_d3r_material_from_id, &
       ROSSFAST_D3R_N_CELLS, ROSSFAST_D3R_DZ_CM, ROSSFAST_D3R_HARD_MASS_TOL_CM
  use mod_rossfast_d3r_execution_policy, only: ROSSFAST_D3R_RETRY_SCALE, ROSSFAST_D3R_MAX_FULL_INDEX, &
       rossfast_d3r_full_duration_for_index
  use mod_b110_default_mvg_provider, only: b110_default_mvg_parameters_t, b110_default_mvg_provider_t, &
       initialize_b110_default_mvg_parameters, bind_b110_default_mvg_provider, evaluate_b110_default_mvg_conductivity
  use mod_b111_analytical_hydraulic_provider, only: b111_analytical_hydraulic_parameters_t, &
       b111_analytical_hydraulic_provider_t, initialize_b111_analytical_hydraulic_parameters, &
       bind_b111_analytical_hydraulic_provider, B111_HYD_EXPONENTIAL, B111_HYD_BIMODAL_MVG, &
       B111_HYD_BIMODAL_MVG_WCK
  use mod_b111_explicit_cauchy_profile_flux, only: evaluate_b111_explicit_cauchy_profile_flux, B111_EXPLICIT_CAUCHY_OK
  use mod_b111_profile_groundwater_projection, only: b111_profile_groundwater_projection_t, &
       evaluate_b111_profile_groundwater_projection
  use mod_b110_direct_retention_core, only: acquire_b110_direct_retention_slot
  use mod_b110_direct_retention_provider, only: b110_direct_retention_provider_t, bind_b110_direct_retention_provider
  use mod_b110_dynamic_top_boundary_solver_adapter, only: b110_dynamic_top_boundary_solver_provider_t, &
       bind_b110_dynamic_top_boundary_solver_provider
  use mod_restricted_surface_evaporation, only: black_evaporation_parameters_t, black_evaporation_state_t, &
       black_evaporation_forcing_t, black_evaporation_result_t, evaluate_black_evaporation_reduction, &
       BLACK_EVAP_AVAILABLE, BLACK_EVAP_PONDING_CLASSIFICATION_CM, &
       boesten_evaporation_parameters_t, boesten_evaporation_state_t, boesten_evaporation_forcing_t, &
       boesten_evaporation_result_t, evaluate_boesten_evaporation_reduction, BOESTEN_EVAP_AVAILABLE, &
       BOESTEN_EVAP_PONDING_CLASSIFICATION_CM
  use mod_b110_source_sink_provider, only: b110_source_sink_provider_t, bind_b110_source_sink_provider
  use mod_b110_root_sink_provider, only: b110_root_sink_provider_t, bind_b110_root_sink_provider
  use mod_root_micro_matric_flux_table, only: micro_matric_flux_table_t
  use mod_root_micro_de_willigen_process, only: micro_de_willigen_parameters_t, micro_de_willigen_result_t, &
       evaluate_micro_de_willigen,attribute_micro_root_stress_losses, MICRO_DW_OK
  use mod_fmr_micro_mvg_table_binding, only: fmr_build_micro_mvg_tables, fmr_micro_horizon_map_valid
  use mod_b110_serialized_context_binding, only: bind_b110_serialized_legacy_context
  use mod_snow_process, only: snow_parameters_t, snow_state_t, snow_forcing_t, snow_flux_result_t, &
       snow_mass_contribution_t, snow_diagnostics_t, evaluate_snow_reference_call, SNOW_OK
  use mod_process_hydraulic_view, only: process_hydraulic_view_t, build_process_hydraulic_view
  use mod_b110_smooth_freatic_projection, only: b110_smooth_freatic_projection_diagnostics_t, &
       evaluate_b110_smooth_freatic_projection, B110_GWL_PROJECTION_OK
  use mod_soil_temperature_contract, only: copy_soil_temperature_profile, soil_temperature_at_node, soil_temperature_field_view_t, &
       build_soil_temperature_field_view
  use mod_crop_bartholomeus_input, only: crop_bartholomeus_input_t, valid_crop_bartholomeus_input
  use mod_fmr_bartholomeus_contract, only: fmr_bartholomeus_parameters_t, valid_fmr_bartholomeus_parameters, &
       matches_bartholomeus_hydraulic_owner
  use mod_fmr_bartholomeus_activation, only: select_fmr_bartholomeus_route, FMR_BARTHOLOMEUS_ACTIVE, &
       FMR_BARTHOLOMEUS_DISABLED
  use mod_fmr_bartholomeus_execution, only: fmr_apply_bartholomeus_to_root_sink, FMR_BARTHOLOMEUS_EXEC_OK
  use mod_root_water_uptake_process, only: root_water_uptake_flux_result_t, root_water_uptake_diagnostics_t, &
       root_water_uptake_parameters_t, root_water_uptake_request_t, evaluate_macro_feddes_drought_uptake, ROOT_UPTAKE_OK
  use mod_root_uptake_compensation, only: root_compensation_config_t, root_compensation_diagnostics_t, compose_jarvis_root_uptake, &
       ROOT_COMP_OFF, ROOT_COMP_JARVIS, ROOT_COMP_WALSUM, ROOT_COMP_FROST, root_walsum_geometry_t, ROOT_COMP_OK, &
       attribute_root_stress_losses, evaluate_walsum_geometry
  use mod_frost_low_air_drainage_effect, only: frost_low_air_drainage_config_t, frost_low_air_drainage_result_t, &
       compose_legacy_bracketed_frost_drainage
  use mod_frost_divdra_drainage_effect, only: frost_divdra_parameters_t, frost_divdra_result_t, &
       compose_single_level_signed_frost_divdra, valid_frost_divdra_parameters
  use mod_frost_multilevel_divdra_effect, only: frost_multilevel_divdra_result_t, FROST_DIVDRA_MAX_LEVELS, &
       compose_multilevel_signed_frost_divdra, valid_multilevel_frost_divdra
  use mod_frost_geometry_effect, only: frost_geometry_result_t, evaluate_legacy_bracketed_frost_geometry
  use mod_frost_drainage_effect, only: frost_drainage_config_t, frost_drainage_result_t, &
       compose_legacy_normal_frost_drainage, FROST_DRAIN_OK
  use mod_frost_bottom_boundary_effect, only: frost_bottom_config_t, frost_bottom_result_t, &
       compose_legacy_no_drain_frost_bottom, FROST_BOTTOM_OK
  use mod_root_frost_stress, only: root_frost_config_t, compose_legacy_zero_root_frost, ROOT_FROST_OK
  use mod_root_uptake_compensation_execution, only: apply_root_uptake_compensation, ROOT_COMP_EXEC_OK
  use mod_fmr_drainage_response_binding, only: fmr_drainage_response_level_parameters_t, &
       fmr_drainage_response_level_control_t, fmr_drainage_response_diagnostics_t, &
       evaluate_fmr_drainage_response_bottom_lumped, fmr_drainage_response_configuration_status, &
       FMR_DRAIN_BIND_OK, FMR_DRAIN_VARIANT_LINEAR, FMR_DRAIN_VARIANT_TABULATED, &
       FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS1, FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS2, &
       FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS3, FMR_DRAIN_VARIANT_ERNST_IPOS4, FMR_DRAIN_VARIANT_ERNST_IPOS5, &
       FMR_DRAIN_VARIANT_EMPIRICAL_INTERFLOW, FMR_DRAIN_VARIANT_EXTENDED_SIGNED
  use mod_fmr_drainage_response_binding, only: FMR_DRAIN_VARIANT_DRAMET3
  use mod_drainage_spatial_distribution, only: drainage_distribution_parameters_t, &
       drainage_node_transfer_t, drainage_distribution_diagnostics_t, distribute_single_level_signed_divdra, DRAIN_DIST_OK
  use mod_drainage_empirical_interflow_response, only: valid_empirical_interflow_parameters
  use mod_drainage_extended_exchange, only: valid_extended_drainage_parameters, &
       EXT_DRAIN_TUBE, EXT_DRAIN_OPEN_CHANNEL, EXT_DRAIN_TOP_NONE, &
       EXT_DRAIN_TOP_SURFACE_RESISTANCE, EXT_DRAIN_TOP_POWER_INTERFLOW
  use mod_drainage_tabulated_response, only: valid_tabulated_drainage_parameters
  use mod_drainage_hooghoudt_ipos1_response, only: valid_hooghoudt_ipos1_parameters
  use mod_drainage_hooghoudt_ipos23_response, only: valid_hooghoudt_ipos2_parameters, &
       valid_hooghoudt_ipos3_parameters, valid_hooghoudt_prepared
  use mod_drainage_ernst_ipos45_response, only: valid_ernst_ipos4_prepared, valid_ernst_ipos5_prepared
  use mod_fmr_legacy_qgwl_bottom_boundary_provider, only: fmr_qgwl_bottom_boundary_config_t, &
       fmr_qgwl_bottom_boundary_result_t, fmr_evaluate_legacy_qgwl_bottom_boundary, FMR_QGWL_OK
  use mod_fmr_drainage_qbot_directional_binding, only: project_fmr_qbot_smooth_groundwater_level, &
       compose_fmr_qbot_drainage_sink_direction, FMR_QBOT_DRAIN_DIRECTION_OK
  use mod_restricted_soil_temperature, only: SOIL_TEMP_OK, soil_temperature_parameters_t, &
       soil_temperature_numerical_config_t, soil_temperature_forcing_t, soil_temperature_state_t, &
       soil_temperature_workspace_t, soil_temperature_result_t, soil_temperature_diagnostics_t, &
       trial_restricted_soil_temperature, commit_soil_temperature_state, SOIL_TEMP_SOLUTION_NUMERIC, &
       SOIL_TEMP_TOP_PRESCRIBED_TEMPERATURE, SOIL_TEMP_BOTTOM_ZERO_HEAT_FLUX
  use mod_frost_hydraulic_effect, only: frost_hydraulic_parameters_t, FROST_EFFECT_OK, &
       evaluate_frost_hydraulic_factor
  use mod_frost_hydraulic_provider, only: frost_constitutive_provider_t, &
       bind_frost_constitutive_provider, FROST_PROVIDER_OK
  use mod_restricted_fixed_weir_surface_water, only: fixed_weir_surface_water_parameters_t, &
       fixed_weir_surface_water_state_t, fixed_weir_surface_water_forcing_t, &
       fixed_weir_surface_water_numerical_config_t, fixed_weir_surface_water_result_t, &
       evaluate_restricted_fixed_weir_surface_water, validate_fixed_weir_surface_water_parameters, &
       FIXED_WEIR_AVAILABLE
  use mod_macropore_continuation_state, only: macropore_continuation_state_t
  use mod_rfm_physical_state, only: rfm_physical_state_t, copy_rfm_physical_state
  use mod_rfm_runtime_configuration, only: rfm_runtime_configuration_t
  use mod_rfm_surface_forcing, only: rfm_surface_forcing_t
  use mod_rfm_matrix_source_provider, only: rfm_matrix_source_provider_t, bind_rfm_matrix_source_provider
  use mod_rfm_live_trial_preparer, only: rfm_live_trial_prepare_result_t, prepare_rfm_live_trial
  use mod_solute_macropore_exchange, only: mobile_macro_salt_state_t
  use mod_solute_mobile_salt_state, only: mobile_salt_state_t, mobile_salt_fluxes_t, &
       initialize_mobile_salt_state, advance_mobile_salt_trial, SOLUTE_OK
  use mod_solute_mobile_advection_dispersion, only: mobile_dispersion_physics_t, mobile_transport_receipt_t, &
       advance_mobile_advection_dispersion
  use mod_fmr_base_salt_temporal_policy, only: fmr_base_salt_temporal_policy_t, fmr_base_salt_normalized_error
  use mod_solute_mobile_macro_salt_transport, only: mobile_macro_salt_receipt_t, &
       advance_mobile_macro_salt_trial, initialize_mobile_macro_salt_state, MACRO_SALT_OK, MACRO_SALT_INVALID
  use mod_solute_water_face_flux_reconstruction, only: reconstruct_interval_water_face_flux, WATER_FACE_FLUX_OK
  use mod_root_salinity_response, only: evaluate_mobile_root_salinity_sink, SALINITY_OK

  use mod_b111_hysteresis_state, only: b111_hysteresis_state_t, b111_hysteresis_parameters_t, &
       b111_hysteresis_transition_t, advance_b111_hysteresis_accepted, B111_HYST_OK
  use mod_b111_legacy_hydraulic_provider, only: b111_legacy_hydraulic_provider_t, &
       configure_b111_legacy_hydraulic_provider, bind_b111_legacy_hydraulic_provider, B111_LEGACY_HYD_OK
  use mod_b111_extended_hydraulic_provider, only: b111_extended_hydraulic_parameters_t, &
       b111_extended_hydraulic_provider_t, initialize_b111_extended_hydraulic_parameters, &
       bind_b111_extended_hydraulic_provider, B111_EXT_OK
  use mod_b111_conductivity_power_tail, only: b111_conductivity_power_tail_t
  use mod_b111_linear_table_provider, only: b111_linear_table_parameters_t, b111_linear_table_provider_t, &
       bind_b111_linear_table_provider, B111_LINEAR_TABLE_OK
  use mod_fmr_macropore_configuration, only: fmr_macropore_physical_config_t
  use mod_fmr_macropore_top_input, only: fmr_macropore_top_input_forcing_t
  use mod_macropore_single_column_runtime, only: macropore_single_column_runtime_t, macropore_runtime_policy_t, &
       macropore_runtime_result_t, MACRO_RUNTIME_CONVERGED, MACRO_RUNTIME_RETRY
  use mod_fmr_legacy_head_bottom_boundary_provider, only: fmr_hbot5_control_t, fmr_hbot5_proposal_t, FMR_HBOT5_OK
  use mod_fmr_legacy_cauchy_bottom_boundary_provider, only: fmr_cauchy3_control_t, fmr_cauchy3_proposal_t, &
       FMR_CAUCHY3_OK
  implicit none
  private
  public :: fmr_frost_response_drainage_configuration_valid
  public :: fmr_b110_certified_candidate_layout_matches
  public :: fmr_frost_divdra_configuration_valid, fmr_frost_divdra_forcing_valid
  public :: fmr_frost_divdra_pair_valid

  integer, parameter, public :: B110_SWBOTB2_OK = 0
  real(real64), parameter :: FMR_PRACTICAL_RICHARDS_A2C_TOL = 1.0e-8_real64
  real(real64), parameter :: FMR_REFERENCE_BALANCE_FLOOR_DEPTH_CM = 2.8e-16_real64
  integer, parameter, public :: B110_SWBOTB2_INVALID_CONTROL = 1
  integer, parameter, public :: B110_SWBOTB2_TIME_NOT_COVERED = 2

  integer, parameter, public :: B110_SWBOTB2_SINE = 1
  integer, parameter, public :: B110_SWBOTB2_TABLE = 2
  real(real64), parameter, public :: B110_SWBOTB2_DRY_HEAD_CM = -1.0e7_real64

  type, public :: b110_legacy_swbotb2_application_control_t
    private
    logical :: initialized = .false.
    integer :: sw2 = 0
    real(real64) :: canonical_origin_time = 0.0_real64
    real(real64) :: legacy_t1900_origin = 0.0_real64
    real(real64) :: sinave = 0.0_real64
    real(real64) :: sinamp = 0.0_real64
    real(real64) :: sinmax = 0.0_real64
    real(real64), allocatable :: calendar_year_start_t1900(:)
    real(real64), allocatable :: table_t1900(:)
    real(real64), allocatable :: table_qbot(:)
  contains
    procedure, public :: initialize_sine => b110_swbotb2_initialize_sine
    procedure, public :: initialize_table => b110_swbotb2_initialize_table
    procedure, public :: ready => b110_swbotb2_ready
    procedure, public :: evaluate => b110_swbotb2_evaluate
  end type b110_legacy_swbotb2_application_control_t


  type, public :: fmr_snow_runtime_state_t
    type(snow_state_t) :: process
    logical :: event_applied = .false.
    real(real64) :: event_t0 = 0.0_real64
  end type fmr_snow_runtime_state_t

  type, public :: fmr_mobile_salt_component_t
    real(real64), allocatable :: mass_mg_cm2(:)
    real(real64), allocatable :: macro_mass_mg_cm2(:,:)
    integer(int64) :: cdrain_source_id = 0_int64
    integer(int64) :: cdrain_revision = -1_int64
  contains
    procedure, public :: ready => fmr_mobile_salt_ready
  end type fmr_mobile_salt_component_t

  type, extends(canonical_state_t), public :: fmr_b110_physical_state_t
    integer :: active_nodes = 0
    real(real64), allocatable :: pressure_head(:)
    real(real64), allocatable :: water_content(:)
    real(real64) :: ponding_depth = 0.0_real64
    real(real64) :: groundwater_level = 0.0_real64
    type(fmr_snow_runtime_state_t), allocatable :: snow
    type(soil_temperature_state_t), allocatable :: soil_temperature
    type(macropore_continuation_state_t), allocatable :: macropore
    type(fmr_mobile_salt_component_t), allocatable :: salt
    type(rutter_source_state_t), allocatable :: rutter
    type(b111_hysteresis_state_t), allocatable :: hysteresis
    type(matrix_solute_state_t),allocatable::reactive_solute
    real(real64),allocatable::micro_drought_factor_carry
  contains
    procedure :: clone => fmr_b110_state_clone
  end type fmr_b110_physical_state_t

  type, extends(fmr_b110_physical_state_t), public :: fmr_b110_macropore_reduction_state_t
    type(macropore_reduction_continuation_t) :: reduction_continuation
  contains
    procedure :: clone => fmr_b110_macropore_reduction_state_clone
  end type fmr_b110_macropore_reduction_state_t

  type, extends(fmr_b110_physical_state_t), public :: fmr_b110_temporal_indicator_state_t
    private
    type(fkt_temporal_indicator_history_t) :: temporal_history
  contains
    procedure :: clone => fmr_b110_temporal_indicator_state_clone
    procedure, public :: temporal_history_available => fmr_b110_temporal_history_available
    procedure, public :: temporal_history_snapshot => fmr_b110_temporal_history_snapshot
  end type fmr_b110_temporal_indicator_state_t

  ! D7 physical optional-state family.  SWST exists only on feature-active
  ! columns; inactive B1.10 states retain their previous layout and footprint.
  type, extends(fmr_b110_physical_state_t), public :: fmr_b110_fixed_weir_surface_water_state_t
    type(fixed_weir_surface_water_state_t) :: surface_water
  contains
    procedure :: clone => fmr_b110_fixed_weir_surface_water_state_clone
  end type fmr_b110_fixed_weir_surface_water_state_t

  ! PPA-WU04-A option-discriminated process continuation family. LDWET is
  ! physical process continuation state, not a hydraulic field or worker scratch.
  type, extends(fmr_b110_physical_state_t), public :: fmr_b110_black_evaporation_state_t
    type(black_evaporation_state_t) :: black_evaporation
  contains
    procedure :: clone => fmr_b110_black_evaporation_state_clone
  end type fmr_b110_black_evaporation_state_t

  ! PPA-WU04-B keeps the Boesten-Stroosnijder continuation pair atomic and
  ! option-discriminated from both BASE and SWREDU=1 Black.
  type, extends(fmr_b110_physical_state_t), public :: fmr_b110_boesten_evaporation_state_t
    type(boesten_evaporation_state_t) :: boesten_evaporation
  contains
    procedure :: clone => fmr_b110_boesten_evaporation_state_clone
  end type fmr_b110_boesten_evaporation_state_t

  ! MIGMAC10 explicitly composes the atomic Boesten SPEV/SAEV pair with the
  ! existing macropore continuation carried by the physical parent state.
  type, extends(fmr_b110_boesten_evaporation_state_t), public :: fmr_b110_boesten_macropore_state_t
  contains
    procedure :: clone => fmr_b110_boesten_macropore_state_clone
  end type fmr_b110_boesten_macropore_state_t

  ! PPA-WU05-A20 dedicated RFM optional physical-state carrier.
  ! Carrier/checkpoint semantics are admitted separately from live execution.
  type, extends(fmr_b110_physical_state_t), public :: fmr_b110_rfm_state_t
    type(rfm_physical_state_t) :: rfm
  contains
    procedure :: clone => fmr_b110_rfm_state_clone
  end type fmr_b110_rfm_state_t

  type, extends(kernel_parameters_t), public :: fmr_b110_physical_parameters_t
    integer(int64) :: parameter_set_id = 0_int64
    integer :: active_nodes = 0
    real(real64), allocatable :: z(:)
    real(real64), allocatable :: dz(:)
    real(real64), allocatable :: node_distance(:)
    real(real64), allocatable :: cofgen(:,:)
    ! Optional per-node semantic constitutive family. Absence preserves admitted default MvG.
    integer, allocatable :: hydraulic_model_kind(:)
    ! Explicitly select the extended MODEL6 route; default preserves admitted analytical MODEL6.
    logical :: extended_model6_active = .false.
    logical :: conductivity_power_tail_active = .false.
    logical :: pdi_vapor_active = .false.
    type(b111_linear_table_parameters_t), allocatable :: linear_hydraulic_table
    logical :: prepared_default_mvg_available = .false.
    type(b110_default_mvg_parameters_t) :: prepared_default_mvg
    integer :: bottom_mode = 7
    logical :: prescribed_groundwater_active = .false.
    logical :: swbotb3_explicit_active = .false.
    logical :: profile_groundwater_projection = .false.
    real(real64) :: swbotb3_explicit_hdrain_cm = 0.0_real64
    real(real64) :: swbotb3_explicit_shape_3 = 1.0_real64
    integer :: swkimpl = 0
    integer :: swkmean = 1
    integer :: swsophy = 0
    logical :: picard_conductivity_iteration = .false.
    logical :: weather_trial_warm_start = .false.
    logical :: weather_line_search_retry = .false.
    integer :: max_iterations = 8
    integer :: max_backtracking = 4
    real(real64) :: min_step_duration = 1.0e-6_real64
    real(real64) :: compartment_balance_tolerance = 1.0e-12_real64
    real(real64) :: total_balance_tolerance = 1.0e-12_real64
    real(real64) :: head_abs_tolerance = 1.0e-12_real64
    real(real64) :: head_rel_tolerance = 1.0e-12_real64
    real(real64) :: ponding_tolerance = 1.0e-12_real64
    logical :: practical_richards_a2c_active = .false.
    logical :: root_extraction_active = .false.
    ! MICRO owns the one trial root sink when this optional configuration exists.
    type(micro_de_willigen_parameters_t), allocatable :: micro_de_willigen
    integer::micro_maximum_drought=0,micro_combined_stress_mode=1
    integer, allocatable :: micro_horizon_first_node(:)
    logical :: root_salinity_active = .false.
    logical :: reactive_solute_active=.false.,reactive_salinity_active=.false.
    type(mobile_dispersion_physics_t), allocatable :: mobile_dispersion
    real(real64) :: solute_tscf = 0.0_real64
    real(real64) :: saltmax_mg_cm3 = 0.0_real64
    real(real64) :: saltslope_cm3_mg = 0.0_real64
    real(real64) :: salt_temporal_tolerance_mg_cm2 = 0.0_real64
    type(root_compensation_config_t) :: root_compensation
    type(frost_low_air_drainage_config_t) :: frost_low_air_drainage
    type(frost_drainage_config_t) :: frost_drainage
    logical :: frost_divdra_active = .false.
    type(frost_divdra_parameters_t) :: frost_divdra
    type(frost_divdra_parameters_t), allocatable :: frost_divdra_levels(:)
    logical :: frost_response_drainage_active = .false.
    logical :: frost_low_air_response_drainage_active = .false.
    logical :: frost_tabulated_response_drainage_active = .false.
    logical :: frost_analytic_response_drainage_active = .false.
    logical :: frost_empirical_response_drainage_active = .false.
    logical :: frost_extended_response_drainage_active = .false.
    logical :: frost_highest_response_drainage_active = .false.
    type(frost_bottom_config_t) :: frost_bottom
    type(root_frost_config_t) :: root_frost
    real(real64) :: root_frost_head_budget_cm=0.0_real64
    real(real64) :: root_frost_temperature_budget_c=0.0_real64
    type(fmr_bartholomeus_parameters_t), allocatable :: bartholomeus
    logical :: macropore_active = .false.
    type(fmr_macropore_physical_config_t), allocatable :: macropore
    logical :: snow_active = .false.
    logical :: hysteresis_active = .false.
    integer :: hysteresis_initial_mode = 0
    type(b111_hysteresis_parameters_t), allocatable :: hysteresis_parameters
    logical :: tabulated_hydraulics_active = .false.
    logical :: direct_retention_active = .false.
    integer :: prepared_direct_retention_slot = 0
    ! F-SI39: explicit opt-in to the exact B1.11 near-saturated KSATEXM
    ! conductivity extension. Default false preserves all pre-F-SI39 routes.
    logical :: ksatexm_extension_active = .false.
    logical :: elasticity_active = .false.
    logical :: frost_active = .false.
    type(frost_hydraulic_parameters_t) :: frost_hydraulic
    logical :: soil_temperature_active = .false.
    logical :: black_heat_composition_enabled = .false.
    logical :: black_evaporation_active = .false.
    type(black_evaporation_parameters_t), allocatable :: black_evaporation
    logical :: boesten_evaporation_active = .false.
    type(boesten_evaporation_parameters_t), allocatable :: boesten_evaporation
    ! F-PM14 drainage response runtime composition. Immutable response and
    ! prepared geometry data belong to parameters, never to persistent state.
    logical :: drainage_response_active = .false.
    ! F-GC31 opt-in: for prescribed-qbot coupling only, derive the lagged
    ! drainage hydraulic-view GWL from the current substep-start pressure
    ! profile. Default false preserves every previously admitted PM14 route.
    logical :: drainage_qbot_smooth_freatic_projection = .false.
    type(fmr_drainage_response_level_parameters_t), allocatable :: drainage_response_levels(:)
    ! Opt-in single-level trial-local DIVDRA. Geometry is immutable; the
    ! response scalar and partition are rebuilt from each full/half/retry base.
    type(drainage_distribution_parameters_t), allocatable :: drainage_trial_distribution
    type(snow_parameters_t), allocatable :: snow
    type(soil_temperature_parameters_t), allocatable :: soil_temperature
  contains
    procedure :: capture_identity => fmr_b110_capture_parameter_identity
    procedure :: matches_physical_identity => fmr_b110_matches_physical_identity
  end type fmr_b110_physical_parameters_t

  type, public :: fmr_black_evaporation_runtime_forcing_t
    real(real64)::significant_wetting_cm=0.0_real64
    logical :: wetting_reset_each_trial=.false.
    real(real64) :: precipitation_rate_cm_per_day = 0.0_real64
    real(real64) :: irrigation_rate_cm_per_day = 0.0_real64
    real(real64) :: snowmelt_rate_cm_per_day = 0.0_real64
    real(real64) :: runon_rate_cm_per_day = 0.0_real64
    real(real64) :: potential_bare_soil_evaporation_cm_per_day = 0.0_real64
    real(real64) :: potential_pond_evaporation_cm_per_day = 0.0_real64
    real(real64) :: ponding_max_cm = 0.0_real64
    real(real64) :: runoff_resistance_day = 0.0_real64
    real(real64) :: runoff_exponent = 1.0_real64
    logical :: wetting_reset_event = .false.
    real(real64) :: wetting_event_time = 0.0_real64
  end type fmr_black_evaporation_runtime_forcing_t

  type, public :: fmr_boesten_evaporation_runtime_forcing_t
    real(real64) :: precipitation_rate_cm_per_day = 0.0_real64
    real(real64) :: irrigation_rate_cm_per_day = 0.0_real64
    real(real64) :: snowmelt_rate_cm_per_day = 0.0_real64
    real(real64) :: runon_rate_cm_per_day = 0.0_real64
    real(real64) :: potential_bare_soil_evaporation_cm_per_day = 0.0_real64
    real(real64) :: potential_pond_evaporation_cm_per_day = 0.0_real64
    real(real64) :: ponding_max_cm = 0.0_real64
    real(real64) :: runoff_resistance_day = 0.0_real64
    real(real64) :: runoff_exponent = 1.0_real64
  end type fmr_boesten_evaporation_runtime_forcing_t

  integer, parameter, public :: FMR_C_DRAIN_UNIT_MG_CM3 = 1
  type, public :: fmr_c_drain_salt_forcing_t
    logical :: available = .false.
    real(real64) :: concentration_mg_cm3 = 0.0_real64
    real(real64) :: valid_t0 = 0.0_real64, valid_t1 = 0.0_real64
    integer(int64) :: source_id = 0_int64, revision = -1_int64
    integer :: unit_id = 0
  end type fmr_c_drain_salt_forcing_t

  ! Resolved dissolved concentrations at the soil interfaces. The boundary
  ! owner handles surface-pool mixing and schedules these values over a trial.
  type, public :: fmr_soil_salt_boundary_forcing_t
    logical :: available = .false.
    logical :: matrix_top_outflow_carries_solute = .false.
    real(real64) :: matrix_top_mg_cm3 = 0.0_real64, matrix_bottom_mg_cm3 = 0.0_real64
    real(real64), allocatable :: macropore_top_mg_cm3(:), macropore_bottom_mg_cm3(:)
    real(real64) :: valid_t0 = 0.0_real64, valid_t1 = 0.0_real64
    integer(int64) :: source_id = 0_int64, revision = -1_int64
    integer :: unit_id = 0
  end type fmr_soil_salt_boundary_forcing_t
  type, public :: fmr_rutter_runtime_forcing_t
    logical :: matrix_source_area_partition = .false.
    logical :: prepared = .false.
    type(interception_source_window_t) :: source_window
    type(rutter_interval_input_t) :: process
    type(rutter_interval_result_t) :: result
    type(rutter_source_state_t) :: candidate_state
    real(real64) :: snowmelt_rate_cm_per_day = 0.0_real64
    real(real64) :: runon_rate_cm_per_day = 0.0_real64
    real(real64) :: potential_bare_soil_evaporation_cm_per_day = 0.0_real64
    real(real64) :: potential_pond_evaporation_cm_per_day = 0.0_real64
    real(real64) :: ponding_max_cm = 0.0_real64
    real(real64) :: runoff_resistance_day = 0.0_real64
    real(real64) :: runoff_exponent = 1.0_real64
  end type fmr_rutter_runtime_forcing_t

  ! MC-SOL01 opt-in bare surface water input. No additional committed owner.
  ! Gross input and potential demand; the dynamic provider owns actual losses.
  type, public :: fmr_pond_input_forcing_t
    real(real64) :: rain_rate_cm_day = 0.0_real64
    real(real64) :: irrigation_rate_cm_day = 0.0_real64
    real(real64) :: runon_rate_cm_day = 0.0_real64
    real(real64) :: potential_pond_evaporation_cm_day = 0.0_real64
    real(real64) :: ponding_max_cm = 1.e6_real64
    real(real64) :: runoff_resistance_day = 0.0_real64
    logical :: implicit_pond_evaporation = .false.
    real(real64) :: potential_bare_soil_evaporation_cm_day = 0.0_real64
  end type fmr_pond_input_forcing_t

  ! Immutable physical request, not a solver policy or a persistent state owner.
  type, public :: fmr_substep_root_forcing_t
    type(root_water_uptake_parameters_t) :: parameters
    type(root_water_uptake_request_t) :: request
  end type

  type, extends(canonical_forcing_t), public :: fmr_b110_physical_forcing_t
    ! DATAQUAL01: admission evidence only; never changes process equations or budgets.
    type(pond_step_t),allocatable::reactive_supply
    logical :: experimental_empirical_oxygen = .false.
    ! Explicit application mode; bypasses evidence-only guards, never inputs/interfaces.
    logical :: experimental_process_combinations = .false.
    real(real64) :: frost_divdra_scalar_cm_per_day = 0.0_real64
    real(real64), allocatable :: frost_divdra_scalars_cm_per_day(:)
    real(real64) :: top_flux = 0.0_real64
    real(real64) :: top_head = 0.0_real64
    real(real64) :: bottom_flux = 0.0_real64
    real(real64) :: bottom_head = 0.0_real64
    type(fmr_hbot5_control_t), allocatable :: legacy_swbotb5_control
    type(fmr_cauchy3_control_t), allocatable :: legacy_swbotb3_implicit_control
    type(b110_legacy_swbotb2_application_control_t), allocatable :: legacy_swbotb2_control
    type(fmr_qgwl_bottom_boundary_config_t), allocatable :: legacy_swbotb4_qgwl_control
    type(fmr_c_drain_salt_forcing_t), allocatable :: c_drain_salt
    type(fmr_soil_salt_boundary_forcing_t), allocatable :: soil_salt_boundary
    real(real64), allocatable :: drainage_flux_by_level(:,:)
    type(fmr_drainage_response_level_control_t), allocatable :: drainage_response_controls(:)
    real(real64), allocatable :: subsurface_irrigation_source(:)
    real(real64), allocatable :: root_extraction_sink(:)
    type(fmr_substep_root_forcing_t), allocatable :: substep_root
    integer :: micro_rooted_nodes = 0
    real(real64), allocatable :: micro_root_length_density(:)
    real(real64) :: root_potential_transpiration = 0.0_real64
    real(real64) :: root_drought_reduction_total = 0.0_real64
    real(real64), allocatable :: root_potential_sink(:)
    type(root_walsum_geometry_t), allocatable :: root_walsum_geometry
    type(crop_bartholomeus_input_t), allocatable :: crop_oxygen
    type(snow_forcing_t), allocatable :: snow
    type(soil_temperature_forcing_t), allocatable :: soil_temperature
    type(fmr_black_evaporation_runtime_forcing_t), allocatable :: black_evaporation
    type(fmr_boesten_evaporation_runtime_forcing_t), allocatable :: boesten_evaporation
    type(fmr_macropore_top_input_forcing_t), allocatable :: macropore_top_input
    type(rfm_surface_forcing_t), allocatable :: rfm_surface
    type(fmr_pond_input_forcing_t), allocatable :: pond_input
    ! Immutable atmospheric rates; resolved inside each Richards sibling/retry.
    type(fmr_pond_input_forcing_t), allocatable :: weather_surface
    type(fmr_rutter_runtime_forcing_t), allocatable :: rutter
  end type fmr_b110_physical_forcing_t

  public :: fmr_macropore_trace_cell_balance_valid
  public :: fmr_macropore_trace_receipt_valid

  ! Read-only trial trace of one accepted Richards physical substep. It is
  ! worker observation data, never committed or restart state.
  public :: fmr_water_flux_substep_trace_t


  type, public :: fmr_serialized_physical_observation_t
    logical :: bartholomeus_executed = .false.
    integer :: bartholomeus_status = 0
    real(real64) :: root_oxygen_base_uptake = 0.0_real64
    real(real64) :: root_oxygen_final_uptake = 0.0_real64
    real(real64) :: deepest_root_oxygen_factor = 1.0_real64
    real(real64)::micro_drought_loss=0d0,micro_oxygen_loss=0d0,micro_salinity_loss=0d0,micro_drought_factor=0d0
    real(real64), allocatable :: root_oxygen_final_sink(:)
    type(frost_low_air_drainage_result_t) :: frost_low_air_drainage
    logical :: frost_divdra_executed = .false., frost_divdra_mass_accounted_in_trial = .false.
    real(real64) :: frost_divdra_raw_scalar = 0.0_real64, frost_divdra_start_gwl = 0.0_real64
    real(real64) :: frost_divdra_signed_exchange_native = 0.0_real64, frost_divdra_trial_duration = 0.0_real64
    type(frost_geometry_result_t) :: frost_divdra_geometry
    type(frost_divdra_result_t) :: frost_divdra
    type(frost_multilevel_divdra_result_t) :: frost_multilevel_divdra
    logical :: frost_drainage_executed = .false.
    type(frost_drainage_result_t) :: frost_drainage
    logical :: frost_bottom_executed = .false.
    type(frost_bottom_result_t) :: frost_bottom
    logical :: root_frost_executed = .false.
    integer :: root_frost_status = 0
    real(real64) :: root_frost_loss = 0.0_real64
    real(real64), allocatable :: root_frost_final_sink(:)
    real(real64) :: root_compensation_frost_loss = 0.0_real64
    logical :: root_compensation_executed = .false.
    integer :: root_compensation_status = 0
    real(real64) :: root_compensation_base_uptake = 0.0_real64
    real(real64) :: root_compensation_final_uptake = 0.0_real64
    real(real64) :: root_compensation_drought_loss = 0.0_real64
    real(real64) :: root_compensation_oxygen_loss = 0.0_real64
    real(real64), allocatable :: root_compensation_final_sink(:)
    logical :: root_salinity_executed = .false.
    integer :: root_salinity_status = 0
    real(real64) :: root_salinity_base_uptake = 0.0_real64
    real(real64) :: root_salinity_final_uptake = 0.0_real64
    real(real64) :: root_salinity_reduction_total = 0.0_real64
    real(real64), allocatable :: root_salinity_alpha(:), root_salinity_cml_mg_cm3(:)
    logical :: salt_transport_executed = .false.
    integer :: salt_transport_status = 0
    integer :: salt_internal_substeps = 0
    real(real64) :: salt_transport_closure_mg_cm2 = 0.0_real64
    real(real64) :: salt_root_uptake_mg_cm2 = 0.0_real64
    real(real64), allocatable :: salt_qdra_signed_out_mg_cm2(:)
    logical :: solver_executed = .false.
    logical :: accepted_water_flux_trace_available = .false.
    type(fmr_water_flux_substep_trace_t), allocatable :: accepted_water_flux_substeps(:)
    logical :: hbot5_proposal_available = .false.
    real(real64) :: hbot5_proposed_t0 = 0.0_real64, hbot5_proposed_t1 = 0.0_real64
    real(real64) :: hbot5_sample_t1900 = 0.0_real64, hbot5_pressure_head_cm = 0.0_real64
    logical :: cauchy3_proposal_available = .false.
    real(real64) :: cauchy3_proposed_t0 = 0.0_real64, cauchy3_proposed_t1 = 0.0_real64
    real(real64) :: cauchy3_head_sample_t1900 = 0.0_real64, cauchy3_sine_phase_day = 0.0_real64
    real(real64) :: cauchy3_aquifer_head_cm = 0.0_real64
    real(real64) :: cauchy3_q4_sample_t1900 = 0.0_real64, cauchy3_q4_cm_per_day = 0.0_real64
    logical :: cauchy3_explicit_active = .false.
    real(real64) :: cauchy3_explicit_qbot_cm_per_day = 0.0_real64
    real(real64) :: cauchy3_explicit_gwlmean_cm = 0.0_real64
    real(real64) :: cauchy3_explicit_profile_resistance_day = 0.0_real64
    integer :: solver_status = 0
    real(real64) :: top_flux = 0.0_real64
    real(real64) :: bottom_flux = 0.0_real64
    logical :: macropore_top_input_active = .false.
    real(real64) :: macropore_requested_top_cm = 0.0_real64
    real(real64) :: macropore_accepted_top_cm = 0.0_real64
    real(real64) :: macropore_returned_surface_cm = 0.0_real64
    real(real64) :: macropore_pond_requested_cm = 0.0_real64
    real(real64) :: macropore_pond_accepted_cm = 0.0_real64
    real(real64) :: macropore_pond_returned_cm = 0.0_real64
    logical :: macropore_rapid_drain_active = .false.
    real(real64) :: macropore_rapid_outflow_cm = 0.0_real64
    logical :: macropore_inner_richards_exchange_used = .false.
    logical :: macropore_matrix_source_area_partition_used = .false.
    real(real64) :: macropore_inner_initial_exchange_rate_cm_per_day = 0.0_real64
    real(real64) :: macropore_inner_final_exchange_rate_cm_per_day = 0.0_real64
    real(real64) :: solver_equation_residual = 0.0_real64
    logical :: solver_equation_residual_available = .false.
    type(soil_water_solver_diagnostics_t) :: solver_diagnostics
    logical :: picard_conductivity_iteration = .false.
    logical :: practical_richards_a2c_active = .false.
    real(real64) :: practical_richards_head_abs_tolerance = 0.0_real64
    real(real64) :: practical_richards_head_rel_tolerance = 0.0_real64
    real(real64) :: practical_richards_compartment_balance_tolerance = 0.0_real64
    real(real64) :: practical_richards_total_balance_tolerance = 0.0_real64
    real(real64) :: effective_reference_compartment_balance_tolerance = 0.0_real64
    real(real64) :: effective_reference_total_balance_tolerance = 0.0_real64
    logical :: temporal_indicator_enabled = .false.
    logical :: temporal_previous_derivative_available = .false.
    logical :: temporal_current_derivative_available = .false.
    integer :: temporal_indicator_status = SW_TEMPORAL_INDICATOR_NOT_RUN
    logical :: temporal_indicator_available = .false.
    character(len=40) :: temporal_indicator_route = 'not-run'
    real(real64) :: temporal_head_inf_bound = 0.0_real64
    logical :: temporal_head_budget_supplied = .false.
    logical :: temporal_head_budget_valid = .false.
    real(real64) :: temporal_head_budget = 0.0_real64
    logical :: temporal_certificate_available = .false.
    real(real64) :: temporal_normalized_indicator = 0.0_real64
    character(len=48) :: temporal_certificate_unavailable_reason = 'not-evaluated'
    integer :: temporal_additional_tridiagonal_solves = 0
    integer :: temporal_additional_full_nonlinear_solves = 0
    logical :: snow_active = .false.
    logical :: snow_event_prepared = .false.
    integer :: snow_status = 0
    real(real64) :: snow_melt_rate = 0.0_real64
    type(snow_flux_result_t) :: snow_fluxes
    type(snow_mass_contribution_t) :: snow_mass
    logical :: soil_temperature_active = .false.
    logical :: soil_temperature_executed = .false.
    logical :: frost_hydraulic_active = .false.
    logical :: frost_hydraulic_executed = .false.
    integer :: frost_hydraulic_status = 0
    real(real64) :: frost_factor_min = 1.0_real64
    real(real64) :: frost_factor_max = 1.0_real64
    integer :: soil_temperature_status = 0
    logical :: soil_temperature_energy_accounting_complete = .false.
    real(real64) :: soil_temperature_energy_residual_j_cm2 = 0.0_real64
    real(real64) :: soil_temperature_top_heat_flux_j_cm2_day = 0.0_real64
    real(real64) :: soil_temperature_bottom_heat_flux_j_cm2_day = 0.0_real64
    real(real64) :: soil_temperature_storage_change_j_cm2 = 0.0_real64
    real(real64) :: soil_temperature_boundary_energy_j_cm2 = 0.0_real64
    logical :: fixed_weir_surface_water_active = .false.
    integer :: fixed_weir_surface_water_status = 0
    real(real64) :: fixed_weir_surface_water_storage = 0.0_real64
    real(real64) :: fixed_weir_surface_water_level = 0.0_real64
    real(real64) :: fixed_weir_surface_water_supply_rate = 0.0_real64
    real(real64) :: fixed_weir_surface_water_discharge_rate = 0.0_real64
    real(real64) :: fixed_weir_surface_water_mass_residual = 0.0_real64
    real(real64) :: fixed_weir_surface_water_rating_residual = 0.0_real64
    integer :: fixed_weir_surface_water_iterations = 0
    character(len=32) :: fixed_weir_surface_water_route = 'not-run'
    logical :: drainage_response_active = .false.
    logical :: drainage_qbot_projection_active = .false.
    logical :: drainage_qbot_projection_available = .false.
    real(real64) :: drainage_projected_groundwater_level = 0.0_real64
    integer :: drainage_response_evaluations = 0
    logical :: drainage_response_mass_accounted_in_trial = .false.
    real(real64) :: drainage_response_signed_exchange_native = 0.0_real64
    logical :: drainage_response_window_exchange_available = .false.
    real(real64) :: drainage_response_window_signed_exchange_native = 0.0_real64
    type(fmr_drainage_response_diagnostics_t) :: drainage_response
    logical :: black_evaporation_active = .false.
    logical :: black_evaporation_evaluated = .false.
    logical :: black_wetting_reset_applied = .false.
    logical :: black_ponding_reset_applied = .false.
    real(real64) :: black_empirical_demand = 0.0_real64
    real(real64) :: black_candidate_ldwet = 0.0_real64
    logical :: boesten_evaporation_active = .false.
    logical :: boesten_evaporation_evaluated = .false.
    logical :: boesten_ponding_reset_applied = .false.
    real(real64) :: boesten_empirical_demand = 0.0_real64
    real(real64) :: boesten_candidate_spev = 0.0_real64
    real(real64) :: boesten_candidate_saev = 0.0_real64
    real(real64) :: rutter_net_rain_rate_cm_per_day = 0.0_real64
    real(real64) :: rutter_net_irrigation_rate_cm_per_day = 0.0_real64
    real(real64) :: boesten_wetting_rate_cm_per_day = 0.0_real64
    real(real64) :: macropore_top_rain_rate_cm_per_day = 0.0_real64
    real(real64) :: macropore_top_irrigation_rate_cm_per_day = 0.0_real64
  end type fmr_serialized_physical_observation_t

  ! Worker-local transactional scratch for thermal transfer provenance. This is
  ! attempt context, never compact committed column state.
  ! Immutable successful trial records. Branch contexts refer to predecessor
  ! chains in this worker-local arena; publication alone creates a flat array.
  type :: fmr_trace_arena_entry_t
    type(fmr_water_flux_substep_trace_t), allocatable :: payload
    integer :: predecessor = 0
  end type fmr_trace_arena_entry_t

  type, extends(transaction_attempt_context_t) :: fmr_serialized_attempt_context_t
    type(fmr_hbot5_proposal_t) :: hbot5_proposal
    type(fmr_cauchy3_proposal_t) :: cauchy3_proposal
    logical :: bottom_thermal_active = .false.
    logical :: bottom_thermal_valid = .true.
    type(fmr_bottom_thermal_carrier_t) :: bottom_thermal_carrier
    logical :: top_sensible_boundary_active = .false.
    logical :: top_sensible_boundary_valid = .true.
    type(fmr_top_sensible_boundary_carrier_t) :: top_sensible_boundary_carrier
    logical :: drainage_response_window_exchange_available = .false.
    real(real64) :: drainage_response_window_signed_exchange_native = 0.0_real64
    type(accepted_trajectory_direction_t) :: trajectory_direction
    integer(int64) :: trace_generation = 0_int64
    integer :: trace_tail = 0, trace_count = 0
    logical :: accepted_water_flux_trace_failed = .false.
  end type fmr_serialized_attempt_context_t

  type, extends(kernel_model_t) :: fmr_serialized_reference_model_t
    type(fmr_substep_root_forcing_t), allocatable :: substep_root
    type(root_water_uptake_diagnostics_t) :: substep_root_diagnostics
    type(fmr_hbot5_control_t), allocatable :: legacy_swbotb5_control
    type(fmr_hbot5_proposal_t) :: hbot5_proposal
    type(fmr_cauchy3_control_t), allocatable :: legacy_swbotb3_implicit_control
    type(fmr_cauchy3_proposal_t) :: cauchy3_proposal
    type(soil_water_parameter_set_t), pointer :: soil_parameters => null()
    type(b110_default_mvg_parameters_t), pointer :: owned_hydraulic_parameters => null()
    type(b110_default_mvg_parameters_t), pointer :: hydraulic_parameters => null()
    type(b111_analytical_hydraulic_parameters_t), pointer :: analytical_hydraulic_parameters => null()
    type(fmr_b110_physical_parameters_t), pointer :: trusted_parameter_source => null()
    type(b110_default_mvg_provider_t), pointer :: constitutive => null()
    type(b111_analytical_hydraulic_provider_t), pointer :: analytical_constitutive => null()
    logical :: analytical_hydraulics_active = .false.
    logical :: extended_hydraulics_active = .false.
    logical :: extended_pdi_vapor_active = .false.
    logical :: hysteresis_active = .false.
    type(b111_hysteresis_parameters_t), allocatable :: hysteresis_parameters
    type(b111_linear_table_provider_t), pointer :: linear_table_constitutive => null()
    type(b111_linear_table_parameters_t), allocatable :: linear_table_parameters
    type(b111_legacy_hydraulic_provider_t), pointer :: extended_legacy => null()
    type(b111_extended_hydraulic_parameters_t), pointer :: extended_parameters => null()
    type(b111_extended_hydraulic_provider_t), pointer :: extended_constitutive => null()
    type(b110_direct_retention_provider_t), pointer :: direct_retention_constitutive => null()
    logical :: direct_retention_active = .false.
    integer :: direct_retention_slot = 0
    type(b110_source_sink_provider_t), pointer :: source_sink => null()
    type(b110_root_sink_provider_t), pointer :: root_sink => null()
    class(top_boundary_provider_t), pointer :: top_boundary => null()
    type(reference_richards_legacy_solver_t) :: solver
    type(reference_richards_legacy_workspace_t) :: workspace
    type(fmr_rossfast_solver_selection_binding_t) :: soil_water_selection
    real(real64), pointer :: qdra(:,:) => null()
    logical :: drainage_response_active = .false.
    logical :: drainage_qbot_smooth_freatic_projection = .false.
    type(fmr_drainage_response_level_parameters_t), allocatable :: drainage_response_levels(:)
    type(fmr_drainage_response_level_control_t), allocatable :: drainage_response_controls(:)
    type(fmr_drainage_response_diagnostics_t) :: drainage_response_diagnostics
    type(drainage_distribution_parameters_t), allocatable :: drainage_trial_distribution
    integer :: drainage_response_evaluations = 0
    logical :: drainage_response_window_exchange_available = .false.
    real(real64) :: drainage_response_window_signed_exchange_native = 0.0_real64
    real(real64), pointer :: qssdi(:) => null()
    real(real64), pointer :: qrot(:) => null()
    real(real64), pointer :: qrot_zero(:) => null()
    ! Disposable worker inputs/scratch, not accepted oxygen continuation state.
    real(real64), allocatable :: qrot_unmodified(:)
    type(micro_de_willigen_parameters_t), allocatable :: micro_de_willigen
    integer::micro_maximum_drought=0,micro_combined_stress_mode=1
    type(micro_matric_flux_table_t), allocatable :: micro_tables(:)
    integer, allocatable :: micro_horizon_first_node(:)
    real(real64), allocatable :: micro_root_length_density(:)
    integer :: micro_rooted_nodes = 0
    type(root_compensation_config_t) :: root_compensation
    type(frost_low_air_drainage_config_t) :: frost_low_air_drainage
    type(frost_drainage_config_t) :: frost_drainage
    logical :: frost_divdra_active = .false.
    type(frost_divdra_parameters_t) :: frost_divdra
    type(frost_divdra_parameters_t), allocatable :: frost_divdra_levels(:)
    real(real64) :: frost_divdra_scalar_cm_per_day = 0.0_real64
    real(real64), allocatable :: frost_divdra_scalars_cm_per_day(:)
    logical :: frost_response_drainage_active = .false.
    logical :: frost_low_air_response_drainage_active = .false.
    logical :: frost_tabulated_response_drainage_active = .false.
    logical :: frost_analytic_response_drainage_active = .false.
    logical :: frost_empirical_response_drainage_active = .false.
    logical :: frost_extended_response_drainage_active = .false.
    logical :: frost_highest_response_drainage_active = .false.
    real(real64),allocatable :: unfrozen_drainage_flux(:,:)
    type(frost_bottom_config_t) :: frost_bottom
    type(root_frost_config_t) :: root_frost
    real(real64) :: root_frost_head_budget_cm=0.0_real64
    real(real64) :: root_frost_temperature_budget_c=0.0_real64
    real(real64) :: root_potential_transpiration = 0.0_real64
    real(real64) :: root_drought_reduction_total = 0.0_real64
    real(real64), allocatable :: root_potential_sink(:)
    type(root_walsum_geometry_t), allocatable :: root_walsum_geometry
    type(fmr_bartholomeus_parameters_t), allocatable :: bartholomeus
    type(crop_bartholomeus_input_t), allocatable :: crop_oxygen
    real(real64), allocatable :: projection_zero_direction(:)
    integer :: bottom_mode = 7
    logical :: prescribed_groundwater_active = .false.
    logical :: swbotb3_explicit_active = .false.
    logical :: profile_groundwater_projection = .false.
    real(real64) :: swbotb3_explicit_hdrain_cm = 0.0_real64
    real(real64) :: swbotb3_explicit_shape_3 = 1.0_real64
    integer :: swkimpl = 0
    integer :: swkmean = 1
    logical :: weather_trial_warm_start = .false.
    logical :: weather_line_search_retry = .false.
    integer :: max_iterations = 8
    logical :: picard_conductivity_iteration = .false.
    integer :: max_backtracking = 4
    real(real64) :: min_step_duration = 1.0e-6_real64
    real(real64) :: compartment_balance_tolerance = 1.0e-12_real64
    real(real64) :: total_balance_tolerance = 1.0e-12_real64
    real(real64) :: head_abs_tolerance = 1.0e-12_real64
    real(real64) :: head_rel_tolerance = 1.0e-12_real64
    real(real64) :: ponding_tolerance = 1.0e-12_real64
    logical :: practical_richards_a2c_active = .false.
    real(real64) :: top_flux = 0.0_real64
    real(real64) :: base_top_flux = 0.0_real64
    real(real64) :: top_head = 0.0_real64
    real(real64) :: bottom_flux = 0.0_real64
    real(real64) :: bottom_head = 0.0_real64
    type(b110_legacy_swbotb2_application_control_t), allocatable :: legacy_swbotb2_control
    type(fmr_qgwl_bottom_boundary_config_t), allocatable :: legacy_swbotb4_qgwl_control
    type(fmr_pond_input_forcing_t), allocatable :: pond_input
    logical :: forcing_admitted = .false.
    logical :: state_profile_admitted = .false.
    logical :: root_extraction_active = .false.
    logical :: root_salinity_active = .false.
    logical :: reactive_solute_active=.false.,reactive_salinity_active=.false.
    type(pond_step_t)::reactive_supply
    type(mobile_dispersion_physics_t), allocatable :: mobile_dispersion
    real(real64) :: solute_tscf = 0.0_real64
    real(real64) :: saltmax_mg_cm3 = 0.0_real64
    real(real64) :: saltslope_cm3_mg = 0.0_real64
    real(real64) :: salt_temporal_tolerance_mg_cm2 = 0.0_real64
    real(real64) :: temporal_tolerance_cm = 0.0_real64
    type(water_flux_temporal_policy_t) :: water_flux_temporal
    integer(int64) :: solute_state_layout_id = FMR_SOLUTE_STATE_LAYOUT_NONE
    type(fmr_base_salt_temporal_policy_t) :: base_salt_temporal_policy
    type(fmr_c_drain_salt_forcing_t) :: c_drain_salt_forcing
    type(fmr_soil_salt_boundary_forcing_t) :: soil_salt_boundary_forcing
    logical :: macropore_active = .false.
    type(fmr_macropore_physical_config_t), allocatable :: macropore_config
    type(fmr_macropore_top_input_forcing_t) :: macropore_top_input_forcing
    type(macropore_runtime_policy_t) :: macropore_policy
    logical :: macropore_policy_configured = .false.
    type(macropore_single_column_runtime_t) :: macropore_runtime
    type(rfm_runtime_configuration_t) :: rfm_configuration
    type(rfm_surface_forcing_t) :: rfm_surface_forcing
    logical :: trusted_prepared_default_mvg = .false.
    logical :: temporal_indicator_history_enabled = .false.
    logical :: weather_surface_active = .false.
    logical :: macropore_reduction_continuation_enabled = .false.
    logical :: temporal_indicator_budget_supplied = .false.
    logical :: temporal_indicator_budget_valid = .false.
    real(real64) :: temporal_indicator_budget = 0.0_real64
    logical :: trajectory_direction_requested = .false.
    logical :: trajectory_provenance_valid = .false.
    integer :: trajectory_worker_id = -1
    integer :: trajectory_control_coordinate = 0
    integer(int64) :: trajectory_generation_counter = 0_int64
    real(real64) :: trajectory_requested_t0 = 0.0_real64
    real(real64) :: trajectory_requested_t1 = 0.0_real64
    type(accepted_trajectory_direction_t) :: trajectory_direction
    type(soil_water_accepted_step_direction_request_t) :: trajectory_request_workspace
    logical :: snow_active = .false.
    logical :: snow_event_prepared = .false.
    real(real64) :: snow_outer_t0 = 0.0_real64
    real(real64) :: snow_outer_t1 = 0.0_real64
    real(real64) :: snow_melt_rate = 0.0_real64
    type(snow_state_t) :: snow_candidate
    type(snow_flux_result_t) :: snow_fluxes
    type(snow_diagnostics_t) :: snow_diagnostics
    logical :: soil_temperature_active = .false.
    logical :: frost_active = .false.
    type(frost_hydraulic_parameters_t) :: frost_hydraulic
    type(frost_constitutive_provider_t), pointer :: frost_constitutive => null()
    logical :: black_heat_composition_enabled = .false.
    logical :: black_evaporation_active = .false.
    type(black_evaporation_parameters_t) :: black_evaporation_parameters
    real(real64)::black_forcing_end_time=0d0
    type(fmr_black_evaporation_runtime_forcing_t) :: black_evaporation_forcing
    logical :: boesten_evaporation_active = .false.
    type(boesten_evaporation_parameters_t) :: boesten_evaporation_parameters
    type(fmr_boesten_evaporation_runtime_forcing_t) :: boesten_evaporation_forcing
    logical :: rutter_active = .false.
    type(fmr_rutter_runtime_forcing_t), allocatable :: rutter_forcing
    type(soil_temperature_parameters_t), allocatable :: soil_temperature_parameters
    type(soil_temperature_forcing_t), allocatable :: soil_temperature_forcing
    type(soil_temperature_numerical_config_t) :: soil_temperature_numerical
    type(soil_temperature_workspace_t) :: soil_temperature_workspace
    logical :: fixed_weir_surface_water_active = .false.
    logical :: fixed_weir_surface_water_configured = .false.
    type(fixed_weir_surface_water_parameters_t) :: fixed_weir_surface_water_parameters
    type(fixed_weir_surface_water_forcing_t) :: fixed_weir_surface_water_forcing
    type(fixed_weir_surface_water_numerical_config_t) :: fixed_weir_surface_water_numerical
    type(fixed_weir_surface_water_result_t) :: fixed_weir_surface_water_result
    type(fmr_bottom_thermal_carrier_t) :: bottom_thermal_carrier
    logical :: bottom_thermal_carrier_active = .false.
    logical :: bottom_thermal_carrier_valid = .true.
    type(fmr_top_sensible_boundary_carrier_t) :: top_sensible_boundary_carrier
    logical :: top_sensible_boundary_carrier_active = .false.
    logical :: top_sensible_boundary_carrier_valid = .true.
    type(fmr_serialized_physical_observation_t) :: last_observation
    logical :: accepted_water_flux_trace_enabled = .false.
    logical :: accepted_water_flux_trace_failed = .false.
    type(fmr_trace_arena_entry_t), allocatable :: trace_arena(:)
    integer(int64) :: trace_generation = 0_int64
    integer :: trace_used = 0, trace_tail = 0, trace_count = 0
  contains
    procedure :: matches_committed_parameter_identity => fmr_serialized_matches_committed_identity
    procedure :: configure_parameters => fmr_serialized_configure_parameters
    procedure :: execution_admitted => fmr_serialized_execution_admitted
    procedure :: prepare_interval => fmr_serialized_prepare_interval
    procedure :: advance => fmr_serialized_advance
    procedure :: storage => fmr_serialized_storage
    procedure :: storage_accounting_status => fmr_serialized_storage_accounting_status
    procedure :: temporal_error => fmr_serialized_temporal_identity
    procedure :: temporal_assessment => fmr_water_flux_temporal_assessment
    procedure :: attempt_context_required => fmr_serialized_attempt_context_required
    procedure :: capture_attempt_context => fmr_serialized_capture_attempt_context
    procedure :: restore_attempt_context => fmr_serialized_restore_attempt_context
    procedure :: begin_scratch_scope => fmr_serialized_begin_scratch_scope
    procedure :: end_scratch_scope => fmr_serialized_end_scratch_scope
    procedure :: accepted_trajectory_direction_snapshot => fmr_serialized_accepted_trajectory_direction_snapshot
  end type fmr_serialized_reference_model_t

  type, public :: fmr_serialized_reference_backend_t
    private
    type(fmr_serialized_reference_model_t) :: model
    type(kernel_executor_t) :: kernel
    logical :: initialized = .false.
    logical :: bottom_thermal_requested = .false.
    type(fmr_bottom_thermal_candidate_t) :: bottom_thermal_candidate
    logical :: top_sensible_boundary_requested = .false.
    type(fmr_top_sensible_boundary_candidate_t) :: top_sensible_boundary_candidate
  contains
    procedure, public :: initialize => fmr_serialized_backend_initialize
    procedure, public :: water_flux_temporal_enabled => fmr_water_flux_temporal_enabled
    procedure, public :: configure_soil_water_model => fmr_serialized_backend_configure_soil_water_model
    procedure, public :: configure_macropore_policy => fmr_serialized_backend_configure_macropore_policy
    procedure, public :: configure_base_salt_temporal_policy => fmr_configure_base_salt_temporal_policy
    procedure, public :: configure_rfm_runtime => fmr_serialized_backend_configure_rfm_runtime
    procedure, public :: run_trial => fmr_serialized_backend_run_trial
    procedure, public :: run_reference_floor_sample => fmr_serialized_backend_run_reference_floor_sample
    procedure, public :: commit_reference_floor_candidate => fmr_serialized_backend_commit_reference_floor_candidate
    procedure, public :: discard_reference_floor_candidate => fmr_serialized_backend_discard_reference_floor_candidate
    procedure, public :: observation => fmr_serialized_backend_observation
    procedure, public :: set_bottom_thermal_carrier_enabled => fmr_serialized_backend_set_bottom_thermal_carrier_enabled
    procedure, public :: bottom_thermal_snapshot => fmr_serialized_backend_bottom_thermal_snapshot
    procedure, public :: set_top_sensible_boundary_enabled => fmr_serialized_backend_set_top_sensible_boundary_enabled
    procedure, public :: top_sensible_boundary_snapshot => fmr_serialized_backend_top_sensible_boundary_snapshot
    procedure, public :: configure_fixed_weir_surface_water => fmr_serialized_backend_configure_fixed_weir_surface_water
    procedure, public :: clear_fixed_weir_surface_water => fmr_serialized_backend_clear_fixed_weir_surface_water
    procedure, public :: commit_trial_candidate => fmr_serialized_backend_commit_trial_candidate
    procedure, public :: discard_trial_candidate => fmr_serialized_backend_discard_trial_candidate
  end type fmr_serialized_reference_backend_t

  public :: prepare_fmr_b110_default_mvg
  public :: fmr_c_drain_salt_covers_interval
  public :: fmr_c_drain_salt_matches_trial
  public :: fmr_soil_salt_boundary_matches_trial
  public :: fmr_new_b110_committed_state
  public :: fmr_initialize_mobile_macro_salt_profile
  public :: fmr_initialize_mobile_salt_profile
  public :: fmr_base_salt_temporal_policy_t
  public :: fmr_mobile_dispersion_matches_hydraulic_owner
  public :: fmr_new_b110_macropore_reduction_committed_state
  public :: fmr_new_b110_temporal_indicator_committed_state
  public :: fmr_new_b110_fixed_weir_surface_water_committed_state
  public :: fmr_new_b110_black_evaporation_committed_state
  public :: fmr_new_b110_boesten_evaporation_committed_state
  public :: fmr_new_b110_boesten_macropore_committed_state
  public :: fmr_new_b110_rfm_committed_state

  public::attach_reactive_chemical
contains

  subroutine attach_reactive_chemical(water,chemical,parameters,status)
    type(kernel_committed_state_t),intent(inout)::water
    type(matrix_solute_state_t),intent(in)::chemical
    type(fmr_b110_physical_parameters_t),intent(in)::parameters
    integer,intent(out)::status
    class(transaction_state_t),allocatable::physical
    type(kernel_parameter_identity_t)::identity
    type(kernel_committed_state_t)::next
    real(real64)::clock
    logical::ok
    integer::code
    status=1
    if(.not.parameters%reactive_solute_active.or..not.chemical%ready().or..not.water%ready())return
    call water%current_time(clock,ok);if(.not.ok)return
    call water%snapshot(physical,ok);if(.not.ok)return
    select type(q=>physical)
    class is(fmr_b110_physical_state_t)
      if(allocated(q%salt))return
      if(allocated(q%reactive_solute))then
        if(.not.q%reactive_solute%same_state(chemical))return
      else
        allocate(q%reactive_solute);q%reactive_solute=chemical
      end if
    class default
      return
    end select
    call parameters%capture_identity(identity,ok);if(.not.ok)return
    call kernel_reconstruct_committed_state_trusted(next,water%current_lineage_id(),water%current_revision(), &
         physical,clock,.true.,ok,code,parameters,identity)
    if(.not.ok.or.code/=0)return
    water=next;status=0
  end subroutine attach_reactive_chemical

  logical function macro_numeric_heat_valid(p) result(ok)
    type(fmr_b110_physical_parameters_t),intent(in)::p
    ! Existing numeric endpoint heat owner in the combined MIGMAC10 layout.
    ! Other macro/thermal cross-products remain fail closed.
    ok=.false.
    if(.not.p%soil_temperature_active.or..not.p%macropore_active.or. &
       .not.p%boesten_evaporation_active.or..not.allocated(p%soil_temperature))return
    if(p%frost_active.or.p%snow_active.or. &
       p%picard_conductivity_iteration.or.p%elasticity_active.or.p%hysteresis_active)return
    if(p%root_compensation%method/=ROOT_COMP_OFF.or.p%root_salinity_active.or.p%root_frost%active)return
    if(allocated(p%bartholomeus).or.allocated(p%micro_de_willigen))return
    if(p%drainage_response_active)then
      if(.not.joint_drainage_trace_valid(p))return
    end if
    if(.not.p%soil_temperature%ready())return
    if(p%soil_temperature%node_count()/=p%active_nodes)return
    ok=p%soil_temperature%solution_mode==SOIL_TEMP_SOLUTION_NUMERIC
  end function macro_numeric_heat_valid

  logical function groundwater_oxygen_trace_scope(p) result(ok)
    type(fmr_b110_physical_parameters_t),intent(in)::p
    integer::route,waterfilm_mode
    ok=.false.
    if(p%bottom_mode/=1.or..not.p%prescribed_groundwater_active)return
    if(.not.p%root_extraction_active.or..not.p%soil_temperature_active)return
    if(.not.allocated(p%bartholomeus).or..not.allocated(p%soil_temperature))return
    if(p%soil_temperature%solution_mode/=SOIL_TEMP_SOLUTION_NUMERIC)return
    if(p%root_compensation%method/=ROOT_COMP_OFF.or.p%root_salinity_active.or.p%root_frost%active)return
    if(p%macropore_active.or.p%snow_active.or.p%frost_active.or.allocated(p%micro_de_willigen))return
    call select_fmr_bartholomeus_route(p%bartholomeus%selection,route,waterfilm_mode)
    ok=route==FMR_BARTHOLOMEUS_ACTIVE
  end function

  logical function joint_drainage_trace_valid(p) result(ok)
    type(fmr_b110_physical_parameters_t),intent(in)::p
    type(process_hydraulic_view_t)::view
    type(drainage_node_transfer_t)::nodes
    type(drainage_distribution_diagnostics_t)::d
    ok=.false.
    if(.not.p%drainage_response_active.or..not.allocated(p%drainage_trial_distribution))return
    if(.not.allocated(p%drainage_response_levels))return
    if(size(p%drainage_response_levels)/=1)return
    if(p%drainage_response_levels(1)%variant==FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS2)then
      if(.not.p%black_heat_composition_enabled.or.p%macropore_active)return
      if(.not.p%drainage_response_levels(1)%hooghoudt_prepared%is_valid)return
    else
      if(p%drainage_response_levels(1)%variant/=FMR_DRAIN_VARIANT_DRAMET3)return
      if(p%drainage_response_levels(1)%dramet3%allocation_mode/=3)return
    end if
    if(p%macropore_active)then
      if(p%bottom_mode/=3.or.p%drainage_response_levels(1)%dramet3%drain_type/=1)return
    end if
    select case(p%bottom_mode)
    case(1)
      if(.not.p%prescribed_groundwater_active.or.p%drainage_qbot_smooth_freatic_projection)return
    case(2)
      if(.not.p%drainage_qbot_smooth_freatic_projection)return
    case(3)
      ! Native implicit Cauchy uses the same existing profile-based CALCGWL
      ! view below, without enabling prescribed-flux directional projection.
      if(p%drainage_qbot_smooth_freatic_projection.or.p%swbotb3_explicit_active)return
    case default
      return
    end select
    if(p%frost_active.or.p%snow_active)return
    if(p%soil_temperature_active)then
      if(.not.allocated(p%soil_temperature))return
      if(p%soil_temperature%solution_mode/=SOIL_TEMP_SOLUTION_NUMERIC)return
    end if
    if(p%root_salinity_active.or.p%root_frost%active)return
    if(p%root_compensation%method/=ROOT_COMP_OFF)then
      if(.not.p%black_heat_composition_enabled.or.p%root_compensation%method/=ROOT_COMP_JARVIS)return
    end if
    if(allocated(p%micro_de_willigen).and..not.p%reactive_solute_active)return
    if(allocated(p%bartholomeus))then
      if(.not.groundwater_oxygen_trace_scope(p).and..not.p%reactive_solute_active)return
    end if
    call distribute_single_level_signed_divdra(p%drainage_trial_distribution,view,0d0,nodes,d)
    if(d%status/=DRAIN_DIST_OK)return
    if(p%drainage_trial_distribution%active_nodes/=p%active_nodes)return
    if(.not.allocated(p%dz).or..not.allocated(p%z).or..not.allocated(p%cofgen))return
    if(any(p%drainage_trial_distribution%dz/=p%dz))return
    if(any(p%drainage_trial_distribution%zbotcp/=p%z-.5_real64*p%dz))return
    if(any(p%drainage_trial_distribution%saturated_conductivity/=p%cofgen(3,:)))return
    ok=.true.
  end function

  subroutine fmr_b110_capture_parameter_identity(self,identity,available)
    class(fmr_b110_physical_parameters_t), intent(in) :: self
    type(kernel_parameter_identity_t), intent(out) :: identity
    logical, intent(out) :: available
    integer :: i
    real(real64) :: bottom
    identity=kernel_parameter_identity_t()
    available=.false.
    if(self%parameter_set_id<=0_int64.or.self%active_nodes<1) return
    if(.not.allocated(self%z).or..not.allocated(self%dz)) return
    if(size(self%z)/=self%active_nodes.or.size(self%dz)/=self%active_nodes) return
    if(.not.all(ieee_is_finite(self%z)).or..not.all(ieee_is_finite(self%dz))) return
    if(any(self%dz<=0.0_real64)) return
    bottom=0.0_real64
    do i=1,self%active_nodes
      if(self%z(i)/=bottom-0.5_real64*self%dz(i)) return
      bottom=bottom-self%dz(i)
      if(.not.ieee_is_finite(bottom)) return
    end do
    identity%parameter_set_id=self%parameter_set_id
    identity%active_nodes=self%active_nodes
    identity%heat_enabled=self%soil_temperature_active
    identity%z=self%z
    identity%dz=self%dz
    identity%valid=.true.
    available=.true.
  end subroutine

  logical function fmr_b110_matches_physical_identity(self,state) result(ok)
    class(fmr_b110_physical_parameters_t), intent(in) :: self
    class(transaction_state_t), intent(in) :: state
    ok=.false.
    select type(state)
    class is(fmr_b110_physical_state_t)
      if(state%active_nodes/=self%active_nodes.or.state%active_nodes<=0) return
      if(.not.allocated(state%pressure_head).or..not.allocated(state%water_content)) return
      if(size(state%pressure_head)/=self%active_nodes.or. &
           size(state%water_content)/=self%active_nodes) return
      if(allocated(state%soil_temperature).neqv.self%soil_temperature_active) return
      ok=.true.
    class default
      return
    end select
  end function

  pure logical function fmr_frost_divdra_configuration_valid(parameters) result(ok)
    type(fmr_b110_physical_parameters_t), intent(in) :: parameters
    integer :: n, i, level
    real(real64) :: bottom
    ok=.true.
    if(.not.parameters%frost_divdra_active)then
      ok=.not.allocated(parameters%frost_divdra_levels);return
    end if
    ok=.false.
    if(.not.parameters%frost_active.or..not.parameters%soil_temperature_active)return
    if(.not.parameters%frost_drainage%active.or..not.parameters%frost_drainage%valid())return
    if(parameters%bottom_mode/=2.or.parameters%frost_bottom%active.or.parameters%frost_low_air_drainage%active)return
    if(parameters%drainage_response_active.or.parameters%frost_response_drainage_active)return
    if(parameters%drainage_qbot_smooth_freatic_projection)return
    if(allocated(parameters%drainage_response_levels))return
    if(parameters%root_extraction_active.or.parameters%root_frost%active.or.parameters%root_salinity_active)return
    if(parameters%root_compensation%method/=ROOT_COMP_OFF.or.allocated(parameters%bartholomeus))return
    if(parameters%macropore_active.or.parameters%snow_active.or.parameters%elasticity_active)return
    if(parameters%direct_retention_active.or.parameters%ksatexm_extension_active.or.parameters%tabulated_hydraulics_active)return
    if(parameters%prepared_default_mvg_available)then
      if(parameters%prepared_default_mvg%elastic_storage_active)return
    end if
    if(.not.valid_frost_divdra_parameters(parameters%frost_divdra))return
    n=parameters%active_nodes
    if(parameters%frost_divdra%distribution%active_nodes/=n)return
    if(.not.allocated(parameters%dz).or..not.allocated(parameters%z).or..not.allocated(parameters%node_distance))return
    if(.not.allocated(parameters%cofgen))return
    if(size(parameters%dz)/=n.or.size(parameters%z)/=n.or.size(parameters%node_distance)/=n)return
    if(size(parameters%cofgen,1)<24.or.size(parameters%cofgen,2)/=n)return
    if(any(.not.ieee_is_finite(parameters%z)).or.any(.not.ieee_is_finite(parameters%node_distance)))return
    if(any(parameters%frost_divdra%distribution%dz/=parameters%dz))return
    if(any(parameters%frost_divdra%distribution%saturated_conductivity/=parameters%cofgen(3,:)))return
    if(allocated(parameters%frost_divdra_levels))then
      if(.not.valid_multilevel_frost_divdra(parameters%frost_divdra_levels))return
      do level=1,size(parameters%frost_divdra_levels)
        if(parameters%frost_divdra_levels(level)%distribution%active_nodes/=n)return
        if(any(parameters%frost_divdra_levels(level)%distribution%dz/=parameters%dz))return
        if(any(parameters%frost_divdra_levels(level)%distribution%zbotcp/= &
             parameters%frost_divdra%distribution%zbotcp))return
        if(any(parameters%frost_divdra_levels(level)%distribution%saturated_conductivity/=parameters%cofgen(3,:)))return
      end do
    end if
    bottom=0.0_real64
    do i=1,n
      if(parameters%z(i)/=bottom-0.5_real64*parameters%dz(i))return
      bottom=bottom-parameters%dz(i)
      if(parameters%frost_divdra%distribution%zbotcp(i)/=bottom)return
      if(i==1)then
        if(parameters%node_distance(i)/=-parameters%z(i))return
      else
        if(parameters%node_distance(i)/=parameters%z(i-1)-parameters%z(i))return
      end if
    end do
    ok=.true.
  end function fmr_frost_divdra_configuration_valid

  pure logical function fmr_frost_divdra_forcing_valid(active,forcing) result(ok)
    logical, intent(in) :: active
    type(fmr_b110_physical_forcing_t), intent(in) :: forcing
    real(real64) :: scalar
    ok=.false.;scalar=forcing%frost_divdra_scalar_cm_per_day
    if(.not.ieee_is_finite(scalar))return
    if(.not.active)then
      ok=scalar==0.0_real64.and..not.allocated(forcing%frost_divdra_scalars_cm_per_day);return
    end if
    if(allocated(forcing%frost_divdra_scalars_cm_per_day))then
      if(scalar/=0.0_real64)return
      if(size(forcing%frost_divdra_scalars_cm_per_day)<2.or. &
           size(forcing%frost_divdra_scalars_cm_per_day)>FROST_DIVDRA_MAX_LEVELS)return
      if(any(.not.ieee_is_finite(forcing%frost_divdra_scalars_cm_per_day)))return
      if(any(abs(forcing%frost_divdra_scalars_cm_per_day)>1.e6_real64))return
      if(any(abs(forcing%frost_divdra_scalars_cm_per_day)>0.0_real64.and. &
           abs(forcing%frost_divdra_scalars_cm_per_day)<=1.e-10_real64))return
    end if
    if(abs(scalar)>1.e6_real64)return
    if(scalar/=0.0_real64.and.abs(scalar)<=1.e-10_real64)return
    if(allocated(forcing%legacy_swbotb2_control).or.allocated(forcing%legacy_swbotb4_qgwl_control))return
    if(allocated(forcing%legacy_swbotb3_implicit_control).or.allocated(forcing%legacy_swbotb5_control))return
    if(allocated(forcing%drainage_flux_by_level).or.allocated(forcing%drainage_response_controls))return
    if(allocated(forcing%soil_salt_boundary).or.allocated(forcing%c_drain_salt).or.allocated(forcing%crop_oxygen))return
    if(.not.allocated(forcing%subsurface_irrigation_source).or..not.allocated(forcing%root_extraction_sink))return
    if(any(.not.ieee_is_finite(forcing%subsurface_irrigation_source)))return
    if(any(.not.ieee_is_finite(forcing%root_extraction_sink)))return
    if(.not.ieee_is_finite(forcing%bottom_flux))return
    if(any(forcing%subsurface_irrigation_source/=0.0_real64).or.any(forcing%root_extraction_sink/=0.0_real64))return
    ok=.true.
  end function fmr_frost_divdra_forcing_valid

  pure logical function fmr_frost_divdra_pair_valid(parameters,forcing) result(ok)
    type(fmr_b110_physical_parameters_t),intent(in)::parameters
    type(fmr_b110_physical_forcing_t),intent(in)::forcing
    ok=.false.
    if(.not.fmr_frost_divdra_configuration_valid(parameters))return
    if(.not.fmr_frost_divdra_forcing_valid(parameters%frost_divdra_active,forcing))return
    if(allocated(parameters%frost_divdra_levels).neqv.allocated(forcing%frost_divdra_scalars_cm_per_day))return
    if(allocated(parameters%frost_divdra_levels))then
      if(size(parameters%frost_divdra_levels)/=size(forcing%frost_divdra_scalars_cm_per_day))return
    end if
    ok=.true.
  end function fmr_frost_divdra_pair_valid

  pure logical function fmr_frost_response_drainage_configuration_valid(parameters) result(ok)
    type(fmr_b110_physical_parameters_t),intent(in)::parameters
    integer :: level
    logical :: has_table, has_analytic, has_empirical, has_extended
    real(real64) :: analytic_depth
    ok=.true.
    if(.not.parameters%frost_response_drainage_active)then
      ok=.not.parameters%frost_low_air_response_drainage_active.and. &
           .not.parameters%frost_tabulated_response_drainage_active.and. &
           .not.parameters%frost_analytic_response_drainage_active.and. &
           .not.parameters%frost_empirical_response_drainage_active.and. &
           .not.parameters%frost_extended_response_drainage_active.and. &
           .not.parameters%frost_highest_response_drainage_active
      return
    end if
    ok=.false.
    if(.not.parameters%frost_drainage%active.or..not.parameters%drainage_response_active)return
    if(parameters%drainage_qbot_smooth_freatic_projection)return
    if(parameters%frost_low_air_drainage%active.neqv.parameters%frost_low_air_response_drainage_active)return
    if(.not.allocated(parameters%drainage_response_levels))return
    if(size(parameters%drainage_response_levels)<1)return
    if(parameters%frost_low_air_response_drainage_active)then
      if(.not.parameters%frost_low_air_drainage%valid())return
      if(size(parameters%frost_low_air_drainage%drain_depth_cm)/=size(parameters%drainage_response_levels))return
    end if
    if(parameters%frost_empirical_response_drainage_active)then
      if(parameters%frost_tabulated_response_drainage_active.or.parameters%frost_analytic_response_drainage_active)return
    end if
    if(parameters%frost_highest_response_drainage_active)then
      if(parameters%frost_extended_response_drainage_active.or.parameters%frost_tabulated_response_drainage_active.or. &
           parameters%frost_analytic_response_drainage_active.or.parameters%frost_empirical_response_drainage_active)return
      if(size(parameters%drainage_response_levels)/=1)return
      if(parameters%drainage_response_levels(1)%variant/=FMR_DRAIN_VARIANT_EXTENDED_SIGNED)return
    end if
    if(parameters%frost_extended_response_drainage_active)then
      if(parameters%frost_tabulated_response_drainage_active.or.parameters%frost_analytic_response_drainage_active.or. &
           parameters%frost_empirical_response_drainage_active)return
      if(size(parameters%drainage_response_levels)/=1)return
      if(parameters%drainage_response_levels(1)%variant/=FMR_DRAIN_VARIANT_EXTENDED_SIGNED)return
    end if
    has_table=.false.;has_analytic=.false.;has_empirical=.false.;has_extended=.false.
    do level=1,size(parameters%drainage_response_levels)
      if(parameters%frost_empirical_response_drainage_active)then
        if(parameters%drainage_response_levels(level)%variant/=FMR_DRAIN_VARIANT_LINEAR.and. &
             parameters%drainage_response_levels(level)%variant/=FMR_DRAIN_VARIANT_EMPIRICAL_INTERFLOW)return
      end if
      select case(parameters%drainage_response_levels(level)%variant)
      case(FMR_DRAIN_VARIANT_LINEAR)
        if(.not.ieee_is_finite(parameters%drainage_response_levels(level)%linear%drainage_resistance))return
        if(parameters%drainage_response_levels(level)%linear%drainage_resistance<=0._real64)return
      case(FMR_DRAIN_VARIANT_TABULATED)
        if(.not.parameters%frost_tabulated_response_drainage_active)return
        if(.not.valid_tabulated_drainage_parameters(parameters%drainage_response_levels(level)%tabulated))return
        ! Keep the existing evaluator's representation-dependent depth-zero
        ! singleton outside the selected runtime before any solver call.
        if(size(parameters%drainage_response_levels(level)%tabulated%groundwater_depth)==1)then
          if(parameters%drainage_response_levels(level)%tabulated%groundwater_depth(1)<=0._real64)return
        end if
        has_table=.true.
      case(FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS1)
        if(.not.parameters%frost_analytic_response_drainage_active)return
        if(.not.valid_hooghoudt_ipos1_parameters(parameters%drainage_response_levels(level)%hooghoudt_ipos1))return
        analytic_depth=parameters%drainage_response_levels(level)%hooghoudt_ipos1%drain_bottom_level
        has_analytic=.true.
      case(FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS2)
        if(.not.parameters%frost_analytic_response_drainage_active)return
        if(.not.valid_hooghoudt_ipos2_parameters(parameters%drainage_response_levels(level)%hooghoudt_ipos2))return
        if(.not.valid_hooghoudt_prepared(parameters%drainage_response_levels(level)%hooghoudt_prepared))return
        analytic_depth=parameters%drainage_response_levels(level)%hooghoudt_prepared%drain_bottom_level
        has_analytic=.true.
      case(FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS3)
        if(.not.parameters%frost_analytic_response_drainage_active)return
        if(.not.valid_hooghoudt_ipos3_parameters(parameters%drainage_response_levels(level)%hooghoudt_ipos3))return
        if(.not.valid_hooghoudt_prepared(parameters%drainage_response_levels(level)%hooghoudt_prepared))return
        analytic_depth=parameters%drainage_response_levels(level)%hooghoudt_prepared%drain_bottom_level
        has_analytic=.true.
      case(FMR_DRAIN_VARIANT_ERNST_IPOS4)
        if(.not.parameters%frost_analytic_response_drainage_active)return
        if(.not.valid_ernst_ipos4_prepared(parameters%drainage_response_levels(level)%ernst_ipos4_prepared))return
        analytic_depth=parameters%drainage_response_levels(level)%ernst_ipos4_prepared%drain_bottom_level
        has_analytic=.true.
      case(FMR_DRAIN_VARIANT_ERNST_IPOS5)
        if(.not.parameters%frost_analytic_response_drainage_active)return
        if(.not.valid_ernst_ipos5_prepared(parameters%drainage_response_levels(level)%ernst_ipos5_prepared))return
        analytic_depth=parameters%drainage_response_levels(level)%ernst_ipos5_prepared%drain_bottom_level
        has_analytic=.true.
      case(FMR_DRAIN_VARIANT_EMPIRICAL_INTERFLOW)
        if(.not.parameters%frost_empirical_response_drainage_active)return
        if(level/=size(parameters%drainage_response_levels))return
        if(.not.valid_empirical_interflow_parameters(parameters%drainage_response_levels(level)%empirical))return
        has_empirical=.true.
      case(FMR_DRAIN_VARIANT_EXTENDED_SIGNED)
        if(.not.parameters%frost_extended_response_drainage_active.and. &
             .not.parameters%frost_highest_response_drainage_active)return
        if(.not.valid_extended_drainage_parameters(parameters%drainage_response_levels(level)%extended))return
        if(parameters%drainage_response_levels(level)%extended%drain_type/=EXT_DRAIN_TUBE.and. &
             parameters%drainage_response_levels(level)%extended%drain_type/=EXT_DRAIN_OPEN_CHANNEL)return
        if(parameters%frost_highest_response_drainage_active)then
          if(.not.parameters%drainage_response_levels(level)%extended%highest_level)return
          select case(parameters%drainage_response_levels(level)%extended%highest_surface_mode)
          case(EXT_DRAIN_TOP_SURFACE_RESISTANCE,EXT_DRAIN_TOP_POWER_INTERFLOW)
          case default
            return
          end select
        else
          ! B14's selected ordinary profile remains highest-level excluding.
          if(parameters%drainage_response_levels(level)%extended%highest_level)return
          if(parameters%drainage_response_levels(level)%extended%highest_surface_mode/=EXT_DRAIN_TOP_NONE)return
        end if
        analytic_depth=parameters%drainage_response_levels(level)%extended%zbotdr_cm
        if(analytic_depth>=0._real64)return
        has_extended=.true.
      case default
        return
      end select
      if(parameters%frost_low_air_response_drainage_active)then
        select case(parameters%drainage_response_levels(level)%variant)
        case(FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS1,FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS2, &
             FMR_DRAIN_VARIANT_HOOGHOUDT_IPOS3,FMR_DRAIN_VARIANT_ERNST_IPOS4,FMR_DRAIN_VARIANT_ERNST_IPOS5, &
             FMR_DRAIN_VARIANT_EXTENDED_SIGNED)
          if(analytic_depth/=parameters%frost_low_air_drainage%drain_depth_cm(level))return
        end select
      end if
    end do
    if(parameters%frost_tabulated_response_drainage_active.and..not.has_table)return
    if(parameters%frost_analytic_response_drainage_active.and..not.has_analytic)return
    ok=.true.
    if(parameters%frost_empirical_response_drainage_active.and..not.has_empirical)ok=.false.
    if(parameters%frost_extended_response_drainage_active.and..not.has_extended)ok=.false.
    if(parameters%frost_highest_response_drainage_active.and..not.has_extended)ok=.false.
  end function fmr_frost_response_drainage_configuration_valid

  pure logical function fmr_mobile_dispersion_matches_hydraulic_owner(parameters)result(ok)
    type(fmr_b110_physical_parameters_t),intent(in)::parameters
    integer::n
    real(real64),parameter::tol=1024.0_real64*epsilon(1.0_real64)
    ok=.false.;n=parameters%active_nodes
    if(.not.allocated(parameters%mobile_dispersion))return
    if(.not.parameters%mobile_dispersion%valid(n))return
    if(.not.allocated(parameters%dz).or..not.allocated(parameters%node_distance).or. &
      .not.allocated(parameters%cofgen))return
    if(size(parameters%dz)/=n.or.size(parameters%node_distance)/=n.or. &
      size(parameters%cofgen,1)<2.or.size(parameters%cofgen,2)/=n)return
    if(any(.not.ieee_is_finite(parameters%dz)).or.any(parameters%dz<=0.0_real64).or. &
      any(.not.ieee_is_finite(parameters%node_distance)).or.any(parameters%node_distance<=0.0_real64).or. &
      any(.not.ieee_is_finite(parameters%cofgen(2,:))))return
    associate(p=>parameters%mobile_dispersion)
      ok=all(abs(p%theta_sat_left-parameters%cofgen(2,1:n-1))<=tol).and. &
        all(abs(p%face_distance_cm-parameters%node_distance(2:n))<=tol*max(1.0_real64,maxval(parameters%node_distance)))
      ok=ok.and.all(abs(p%face_left_weight-.5_real64*parameters%dz(2:n)/parameters%node_distance(2:n))<=tol)
      ok=ok.and.all(abs(p%face_right_weight-.5_real64*parameters%dz(1:n-1)/parameters%node_distance(2:n))<=tol)
    end associate
  end function

  pure logical function fmr_c_drain_salt_covers_interval(forcing, t0, t1) result(valid)
    type(fmr_c_drain_salt_forcing_t), intent(in) :: forcing
    real(real64), intent(in) :: t0, t1
    valid = .false.
    if (.not. forcing%available) return
    if (forcing%unit_id /= FMR_C_DRAIN_UNIT_MG_CM3) return
    if (forcing%source_id <= 0_int64 .or. forcing%revision < 0_int64) return
    if (.not. ieee_is_finite(forcing%concentration_mg_cm3) .or. forcing%concentration_mg_cm3 < 0.0_real64) return
    if (.not. ieee_is_finite(forcing%valid_t0) .or. .not. ieee_is_finite(forcing%valid_t1)) return
    if (.not. ieee_is_finite(t0) .or. .not. ieee_is_finite(t1) .or. t1 <= t0) return
    valid = forcing%valid_t0 <= t0 .and. forcing%valid_t1 >= t1 .and. forcing%valid_t1 > forcing%valid_t0
  end function fmr_c_drain_salt_covers_interval

  pure logical function fmr_c_drain_salt_matches_trial(forcing, forcing_handle, t0, t1) result(valid)
    type(fmr_c_drain_salt_forcing_t), intent(in) :: forcing
    integer(int64), intent(in) :: forcing_handle
    real(real64), intent(in) :: t0, t1
    valid = .false.
    if (forcing_handle <= 0_int64 .or. forcing%source_id /= forcing_handle) return
    valid = fmr_c_drain_salt_covers_interval(forcing, t0, t1)
  end function fmr_c_drain_salt_matches_trial

  pure logical function fmr_soil_salt_boundary_matches_trial(forcing, forcing_handle, t0, t1, active_domains) result(valid)
    type(fmr_soil_salt_boundary_forcing_t), intent(in) :: forcing
    integer(int64), intent(in) :: forcing_handle
    real(real64), intent(in) :: t0, t1
    integer, intent(in), optional :: active_domains
    integer :: nd

    valid = .false.
    if (.not. forcing%available .or. forcing%unit_id /= FMR_C_DRAIN_UNIT_MG_CM3) return
    if (forcing_handle <= 0_int64 .or. forcing%source_id /= forcing_handle .or. forcing%revision < 0_int64) return
    if (.not. all(ieee_is_finite([forcing%matrix_top_mg_cm3, forcing%matrix_bottom_mg_cm3, &
         forcing%valid_t0, forcing%valid_t1, t0, t1]))) return
    if (min(forcing%matrix_top_mg_cm3, forcing%matrix_bottom_mg_cm3) < 0.0_real64) return
    if (t1 <= t0 .or. forcing%valid_t1 <= forcing%valid_t0 .or. forcing%valid_t0 > t0 .or. forcing%valid_t1 < t1) return
    if (present(active_domains)) then
      nd = active_domains
      if (nd <= 0 .or. .not. allocated(forcing%macropore_top_mg_cm3) .or. &
          .not. allocated(forcing%macropore_bottom_mg_cm3)) return
      if (size(forcing%macropore_top_mg_cm3) /= nd .or. size(forcing%macropore_bottom_mg_cm3) /= nd) return
      if (any(.not. ieee_is_finite(forcing%macropore_top_mg_cm3)) .or. &
          any(.not. ieee_is_finite(forcing%macropore_bottom_mg_cm3))) return
      if (any(forcing%macropore_top_mg_cm3 < 0.0_real64) .or. &
          any(forcing%macropore_bottom_mg_cm3 < 0.0_real64)) return
    else
      if (allocated(forcing%macropore_top_mg_cm3) .or. allocated(forcing%macropore_bottom_mg_cm3)) return
    end if
    valid = .true.
  end function fmr_soil_salt_boundary_matches_trial

  subroutine prepare_fmr_b110_default_mvg(parameters, prepared)
    type(fmr_b110_physical_parameters_t), intent(inout) :: parameters
    logical, intent(out) :: prepared
    integer :: i
    logical :: direct_hit

    prepared = .false.
    parameters%prepared_default_mvg_available = .false.
    parameters%prepared_default_mvg = b110_default_mvg_parameters_t()
    parameters%prepared_direct_retention_slot = 0

    if (parameters%active_nodes <= 0) return
    if (.not. allocated(parameters%cofgen)) return
    if (size(parameters%cofgen,1) < 24 .or. size(parameters%cofgen,2) /= parameters%active_nodes) return

    if (parameters%elasticity_active) then
      if (parameters%ksatexm_extension_active .or. parameters%direct_retention_active .or. &
          parameters%tabulated_hydraulics_active .or. parameters%hysteresis_active .or. &
          parameters%conductivity_power_tail_active .or. allocated(parameters%hydraulic_model_kind)) return
      if (any(.not. ieee_is_finite(parameters%cofgen(24,:)))) return
      if (any(parameters%cofgen(24,:) < 0.0_real64)) return
    end if

    if (parameters%ksatexm_extension_active) then
      do i = 1, parameters%active_nodes
        if (parameters%cofgen(10,i) > parameters%cofgen(3,i)) then
          if (.not. ieee_is_finite(parameters%cofgen(10,i)) .or. parameters%cofgen(10,i) <= 0.0_real64) return
          if (.not. ieee_is_finite(parameters%cofgen(11,i)) .or. parameters%cofgen(11,i) < 0.0_real64 .or. &
              parameters%cofgen(11,i) >= 1.0_real64) return
          if (.not. ieee_is_finite(parameters%cofgen(12,i)) .or. parameters%cofgen(12,i) < 0.0_real64) return
        end if
      end do
    end if

    if (parameters%elasticity_active) then
      call initialize_b110_default_mvg_parameters(parameters%prepared_default_mvg, parameters%cofgen, &
           enable_ksatexm_extension=parameters%ksatexm_extension_active, &
           enable_elastic_storage=.true., specific_elastic_storage_input=parameters%cofgen(24,:), &
           enable_conductivity_power_tail=parameters%conductivity_power_tail_active)
    else
      call initialize_b110_default_mvg_parameters(parameters%prepared_default_mvg, parameters%cofgen, &
           enable_ksatexm_extension=parameters%ksatexm_extension_active, &
           enable_conductivity_power_tail=parameters%conductivity_power_tail_active)
    end if
    parameters%prepared_default_mvg_available = .true.

    if (parameters%direct_retention_active) then
      if (parameters%bottom_mode /= 5 .or. parameters%swkimpl /= 0 .or. &
          parameters%tabulated_hydraulics_active .or. parameters%hysteresis_active .or. &
          parameters%ksatexm_extension_active .or. parameters%elasticity_active) return
      if (parameters%active_nodes > 1) then
        if (any(parameters%prepared_default_mvg%cofgen(:,2:parameters%active_nodes) /= &
             spread(parameters%prepared_default_mvg%cofgen(:,1),2,parameters%active_nodes-1))) return
      end if
      call acquire_b110_direct_retention_slot(parameters%prepared_default_mvg, &
           parameters%prepared_direct_retention_slot, prepared, direct_hit)
      if (.not. prepared) return
    end if
    prepared = .true.
  end subroutine prepare_fmr_b110_default_mvg

  logical function prepared_default_mvg_structurally_compatible(parameters) result(compatible)
    type(fmr_b110_physical_parameters_t), intent(in) :: parameters
    compatible = .false.
    if (.not. parameters%prepared_default_mvg_available) return
    if (.not. allocated(parameters%cofgen)) return
    if (.not. allocated(parameters%prepared_default_mvg%cofgen)) return
    if (parameters%active_nodes <= 0) return
    if (size(parameters%cofgen,1) < 24 .or. size(parameters%cofgen,2) /= parameters%active_nodes) return
    if (parameters%prepared_default_mvg%active_nodes /= parameters%active_nodes) return
    if (parameters%prepared_default_mvg%ksatexm_extension_enabled .neqv. parameters%ksatexm_extension_active) return
    if (parameters%prepared_default_mvg%elastic_storage_active .neqv. parameters%elasticity_active) return
    if (parameters%prepared_default_mvg%conductivity_power_tail_enabled .neqv. &
        parameters%conductivity_power_tail_active) return
    if (parameters%elasticity_active) then
      if (.not. allocated(parameters%prepared_default_mvg%specific_elastic_storage)) return
      if (size(parameters%prepared_default_mvg%specific_elastic_storage) /= parameters%active_nodes) return
    else
      if (allocated(parameters%prepared_default_mvg%specific_elastic_storage)) return
    end if
    if (size(parameters%prepared_default_mvg%cofgen,1) /= 42) return
    if (size(parameters%prepared_default_mvg%cofgen,2) /= parameters%active_nodes) return
    compatible = .true.
  end function prepared_default_mvg_structurally_compatible

  logical function prepared_default_mvg_compatible(parameters) result(compatible)
    type(fmr_b110_physical_parameters_t), intent(in) :: parameters
    compatible = prepared_default_mvg_structurally_compatible(parameters)
    if (.not. compatible) return
    if (.not. all(parameters%prepared_default_mvg%cofgen(1:24,:) == parameters%cofgen(1:24,:))) compatible = .false.
    if (compatible .and. parameters%elasticity_active) then
      if (.not. all(parameters%prepared_default_mvg%specific_elastic_storage == parameters%cofgen(24,:))) &
           compatible = .false.
    end if
  end function prepared_default_mvg_compatible

  subroutine copy_b110_physical_state(source, target)
    class(fmr_b110_physical_state_t), intent(in) :: source
    class(fmr_b110_physical_state_t), intent(inout) :: target
    target%active_nodes = source%active_nodes
    if (allocated(target%pressure_head)) deallocate(target%pressure_head)
    if (allocated(source%pressure_head)) then
      allocate(target%pressure_head(size(source%pressure_head)))
      target%pressure_head = source%pressure_head
    end if
    if (allocated(target%water_content)) deallocate(target%water_content)
    if (allocated(source%water_content)) then
      allocate(target%water_content(size(source%water_content)))
      target%water_content = source%water_content
    end if
    target%ponding_depth = source%ponding_depth
    target%groundwater_level = source%groundwater_level
    if (allocated(target%snow)) deallocate(target%snow)
    if (allocated(source%snow)) then
      allocate(target%snow)
      target%snow = source%snow
    end if
    if (allocated(target%soil_temperature)) deallocate(target%soil_temperature)
    if (allocated(source%soil_temperature)) then
      allocate(target%soil_temperature)
      target%soil_temperature = source%soil_temperature
    end if
    if (allocated(target%macropore)) deallocate(target%macropore)
    if (allocated(source%macropore)) then
      allocate(target%macropore)
      target%macropore = source%macropore
    end if
    if (allocated(target%salt)) deallocate(target%salt)
    if (allocated(source%salt)) then
      allocate(target%salt)
      target%salt = source%salt
    end if
    if (allocated(target%rutter)) deallocate(target%rutter)
    if (allocated(source%rutter)) then
      allocate(target%rutter)
      target%rutter = source%rutter
    end if
    if(allocated(target%micro_drought_factor_carry))deallocate(target%micro_drought_factor_carry)
    if(allocated(source%micro_drought_factor_carry))target%micro_drought_factor_carry=source%micro_drought_factor_carry
    if(allocated(target%reactive_solute))deallocate(target%reactive_solute)
    if(allocated(source%reactive_solute))target%reactive_solute=source%reactive_solute
    if (allocated(target%hysteresis)) deallocate(target%hysteresis)
    if (allocated(source%hysteresis)) then
      allocate(target%hysteresis)
      target%hysteresis = source%hysteresis
    end if
  end subroutine copy_b110_physical_state

  logical function fmr_mobile_salt_ready(self,active_nodes,active_domains) result(ready)
    class(fmr_mobile_salt_component_t), intent(in) :: self
    integer, intent(in) :: active_nodes
    integer, intent(in), optional :: active_domains
    ready = .false.
    if ((self%cdrain_source_id == 0_int64 .and. self%cdrain_revision /= -1_int64) .or. &
        (self%cdrain_source_id /= 0_int64 .and. &
        (self%cdrain_source_id < 0_int64 .or. self%cdrain_revision < 0_int64))) return
    if (active_nodes <= 0) return
    if (.not. allocated(self%mass_mg_cm2)) return
    if (size(self%mass_mg_cm2) /= active_nodes) return
    if (.not. all(ieee_is_finite(self%mass_mg_cm2)) .or. any(self%mass_mg_cm2 < 0.0_real64)) return
    if (present(active_domains)) then
      if (active_domains <= 0 .or. .not. allocated(self%macro_mass_mg_cm2)) return
      if (any(shape(self%macro_mass_mg_cm2) /= [active_domains,active_nodes])) return
      if (.not. all(ieee_is_finite(self%macro_mass_mg_cm2))) return
      if (any(self%macro_mass_mg_cm2 < 0.0_real64)) return
    else if (allocated(self%macro_mass_mg_cm2)) then
      ! A domain-resolved payload cannot be validated without its declared layout.
      return
    end if
    ready = .true.
  end function fmr_mobile_salt_ready

  subroutine fmr_b110_state_clone(self, copy)
    class(fmr_b110_physical_state_t), intent(in) :: self
    class(transaction_state_t), allocatable, intent(out) :: copy
    allocate(fmr_b110_physical_state_t :: copy)
    select type (typed_copy => copy)
    type is (fmr_b110_physical_state_t)
      call copy_b110_physical_state(self, typed_copy)
    end select
  end subroutine fmr_b110_state_clone

  subroutine fmr_b110_macropore_reduction_state_clone(self, copy)
    class(fmr_b110_macropore_reduction_state_t), intent(in) :: self
    class(transaction_state_t), allocatable, intent(out) :: copy
    allocate(fmr_b110_macropore_reduction_state_t :: copy)
    select type (typed_copy => copy)
    type is (fmr_b110_macropore_reduction_state_t)
      call copy_b110_physical_state(self, typed_copy)
      typed_copy%reduction_continuation = self%reduction_continuation
    end select
  end subroutine fmr_b110_macropore_reduction_state_clone

  subroutine fmr_b110_rfm_state_clone(self, copy)
    class(fmr_b110_rfm_state_t), intent(in) :: self
    class(transaction_state_t), allocatable, intent(out) :: copy
    logical :: ok

    allocate(fmr_b110_rfm_state_t :: copy)
    select type (typed_copy => copy)
    type is (fmr_b110_rfm_state_t)
      call copy_b110_physical_state(self, typed_copy)
      call copy_rfm_physical_state(self%rfm, typed_copy%rfm, ok)
      if (.not. ok) error stop 'PPA-WU05-A20 RFM clone rejected valid source'
    end select
  end subroutine fmr_b110_rfm_state_clone

  subroutine fmr_b110_temporal_indicator_state_clone(self, copy)
    class(fmr_b110_temporal_indicator_state_t), intent(in) :: self
    class(transaction_state_t), allocatable, intent(out) :: copy
    real(real64), allocatable :: derivative(:)
    logical :: available, ok
    allocate(fmr_b110_temporal_indicator_state_t :: copy)
    select type (typed_copy => copy)
    type is (fmr_b110_temporal_indicator_state_t)
      call copy_b110_physical_state(self, typed_copy)
      call self%temporal_history%snapshot(derivative, available)
      if (available) then
        call typed_copy%temporal_history%replace(derivative, ok)
        if (.not. ok) error stop 'F-KT10 temporal history clone rejected valid source'
      end if
    end select
  end subroutine fmr_b110_temporal_indicator_state_clone

  subroutine fmr_b110_fixed_weir_surface_water_state_clone(self, copy)
    class(fmr_b110_fixed_weir_surface_water_state_t), intent(in) :: self
    class(transaction_state_t), allocatable, intent(out) :: copy
    allocate(fmr_b110_fixed_weir_surface_water_state_t :: copy)
    select type (typed_copy => copy)
    type is (fmr_b110_fixed_weir_surface_water_state_t)
      call copy_b110_physical_state(self, typed_copy)
      typed_copy%surface_water = self%surface_water
    end select
  end subroutine fmr_b110_fixed_weir_surface_water_state_clone

  subroutine fmr_b110_black_evaporation_state_clone(self, copy)
    class(fmr_b110_black_evaporation_state_t), intent(in) :: self
    class(transaction_state_t), allocatable, intent(out) :: copy
    allocate(fmr_b110_black_evaporation_state_t :: copy)
    select type (typed_copy => copy)
    type is (fmr_b110_black_evaporation_state_t)
      call copy_b110_physical_state(self, typed_copy)
      typed_copy%black_evaporation = self%black_evaporation
    end select
  end subroutine fmr_b110_black_evaporation_state_clone

  subroutine fmr_b110_boesten_evaporation_state_clone(self, copy)
    class(fmr_b110_boesten_evaporation_state_t), intent(in) :: self
    class(transaction_state_t), allocatable, intent(out) :: copy
    allocate(fmr_b110_boesten_evaporation_state_t :: copy)
    select type (typed_copy => copy)
    type is (fmr_b110_boesten_evaporation_state_t)
      call copy_b110_physical_state(self, typed_copy)
      typed_copy%boesten_evaporation = self%boesten_evaporation
    end select
  end subroutine fmr_b110_boesten_evaporation_state_clone

  subroutine fmr_b110_boesten_macropore_state_clone(self, copy)
    class(fmr_b110_boesten_macropore_state_t), intent(in) :: self
    class(transaction_state_t), allocatable, intent(out) :: copy
    allocate(fmr_b110_boesten_macropore_state_t :: copy)
    select type (typed_copy => copy)
    type is (fmr_b110_boesten_macropore_state_t)
      call copy_b110_physical_state(self, typed_copy)
      typed_copy%boesten_evaporation = self%boesten_evaporation
    end select
  end subroutine fmr_b110_boesten_macropore_state_clone

  logical function fmr_b110_temporal_history_available(self) result(available)
    class(fmr_b110_temporal_indicator_state_t), intent(in) :: self
    available = self%temporal_history%available(self%active_nodes)
  end function fmr_b110_temporal_history_available

  subroutine fmr_b110_temporal_history_snapshot(self, derivative, available)
    class(fmr_b110_temporal_indicator_state_t), intent(in) :: self
    real(real64), allocatable, intent(out) :: derivative(:)
    logical, intent(out) :: available
    available = self%temporal_history%available(self%active_nodes)
    if (.not. available) return
    call self%temporal_history%snapshot(derivative, available)
  end subroutine fmr_b110_temporal_history_snapshot

  subroutine fmr_initialize_mobile_salt_profile(state, node_thickness_cm, concentration_mg_cm3, status)
    type(fmr_b110_physical_state_t),intent(inout)::state
    real(real64),intent(in)::node_thickness_cm(:),concentration_mg_cm3(:)
    integer,intent(out)::status
    type(mobile_salt_state_t)::initialized
    status=MACRO_SALT_INVALID
    if(allocated(state%salt).or.allocated(state%macropore))return
    if(.not.allocated(state%water_content))return
    if(state%active_nodes/=size(state%water_content))return
    call initialize_mobile_salt_state(node_thickness_cm,state%water_content,concentration_mg_cm3,initialized,status)
    if(status/=SOLUTE_OK)return
    allocate(state%salt)
    call move_alloc(initialized%mass_mg_cm2,state%salt%mass_mg_cm2)
  end subroutine

  subroutine fmr_configure_base_salt_temporal_policy(self,policy,ok)
    class(fmr_serialized_reference_backend_t),intent(inout)::self
    type(fmr_base_salt_temporal_policy_t),intent(in)::policy
    logical,intent(out)::ok
    self%model%base_salt_temporal_policy=fmr_base_salt_temporal_policy_t()
    ok=policy%valid()
    if(ok)self%model%base_salt_temporal_policy=policy
  end subroutine

  subroutine fmr_initialize_mobile_macro_salt_profile(state, node_thickness_cm, matrix_concentration_mg_cm3, &
       macro_concentration_mg_cm3, status, matrix_area_fraction)
    type(fmr_b110_physical_state_t), intent(inout) :: state
    real(real64), intent(in) :: node_thickness_cm(:), matrix_concentration_mg_cm3(:)
    real(real64), intent(in) :: macro_concentration_mg_cm3(:,:)
    integer, intent(out) :: status
    real(real64), intent(in), optional :: matrix_area_fraction(:)
    type(mobile_macro_salt_state_t) :: initialized
    real(real64), allocatable :: matrix_storage_thickness(:)

    status = MACRO_SALT_INVALID
    ! Existing inventory is authoritative, particularly after warm restart.
    if (allocated(state%salt)) return
    if (.not. allocated(state%water_content) .or. .not. allocated(state%macropore)) return
    if (.not. state%macropore%ready()) return
    if (state%active_nodes /= size(state%water_content) .or. &
        state%macropore%num_nodes /= state%active_nodes) return
    matrix_storage_thickness=node_thickness_cm
    if (present(matrix_area_fraction)) then
      if (size(matrix_area_fraction)/=size(node_thickness_cm)) return
      if (any(.not.ieee_is_finite(matrix_area_fraction)).or.any(matrix_area_fraction<=0.0_real64).or. &
          any(matrix_area_fraction>1.0_real64)) return
      matrix_storage_thickness=node_thickness_cm*matrix_area_fraction
    end if
    call initialize_mobile_macro_salt_state(matrix_storage_thickness, state%water_content, &
         state%macropore%water_domain_cp, matrix_concentration_mg_cm3, macro_concentration_mg_cm3, initialized, status)
    if (status /= MACRO_SALT_OK) return
    allocate(state%salt)
    call move_alloc(initialized%matrix_mass_mg_cm2, state%salt%mass_mg_cm2)
    call move_alloc(initialized%macro_mass_mg_cm2, state%salt%macro_mass_mg_cm2)
  end subroutine fmr_initialize_mobile_macro_salt_profile

  subroutine fmr_new_b110_committed_state(committed, lineage_id, state, initial_time, ok, initial_rutter_storage_cm, parameters)
    type(kernel_committed_state_t), intent(out) :: committed
    integer(int64), intent(in) :: lineage_id
    type(fmr_b110_physical_state_t), intent(in) :: state
    real(real64), intent(in) :: initial_time
    logical, intent(out) :: ok
    real(real64), intent(in), optional :: initial_rutter_storage_cm
    type(fmr_b110_physical_parameters_t), intent(in), optional :: parameters
    type(kernel_parameter_identity_t) :: checked_identity
    logical :: certified
    class(transaction_state_t), allocatable :: carrier
    integer :: rutter_status
    if(present(parameters)) then
      ok=.false.
      call parameters%capture_identity(checked_identity,certified)
      if(.not.certified) return
      if(state%active_nodes/=checked_identity%active_nodes) return
      if(allocated(state%soil_temperature).neqv.checked_identity%heat_enabled) return
    end if
    allocate(fmr_b110_physical_state_t :: carrier)
    select type (typed_carrier => carrier)
    type is (fmr_b110_physical_state_t)
      call copy_b110_physical_state(state, typed_carrier)
      if (present(initial_rutter_storage_cm)) then
        if (allocated(typed_carrier%rutter)) deallocate(typed_carrier%rutter)
        allocate(typed_carrier%rutter)
        call initialize_rutter_canopy_state(initial_rutter_storage_cm, typed_carrier%rutter, rutter_status)
        if (rutter_status /= RUTTER_WINDOW_OK) then
          ok = .false.
          return
        end if
      end if
    end select
    if(present(parameters)) then
      call committed%initialize(lineage_id, carrier, ok, initial_time, parameters)
    else
      call committed%initialize(lineage_id, carrier, ok, initial_time)
    end if
  end subroutine fmr_new_b110_committed_state

  subroutine fmr_new_b110_macropore_reduction_committed_state(committed,lineage_id,state,reduction,initial_time,ok)
    type(kernel_committed_state_t),intent(out)::committed
    integer(int64),intent(in)::lineage_id
    type(fmr_b110_physical_state_t),intent(in)::state
    type(macropore_reduction_continuation_t),intent(in)::reduction
    real(real64),intent(in)::initial_time
    logical,intent(out)::ok
    class(transaction_state_t),allocatable::carrier

    ok=.false.
    if(.not.reduction%valid())return
    allocate(fmr_b110_macropore_reduction_state_t :: carrier)
    select type(typed_carrier=>carrier)
    type is(fmr_b110_macropore_reduction_state_t)
      call copy_b110_physical_state(state,typed_carrier)
      typed_carrier%reduction_continuation=reduction
    end select
    call committed%initialize(lineage_id,carrier,ok,initial_time)
  end subroutine fmr_new_b110_macropore_reduction_committed_state

  subroutine fmr_new_b110_rfm_committed_state(committed, lineage_id, state, rfm_state, initial_time, ok)
    type(kernel_committed_state_t), intent(out) :: committed
    integer(int64), intent(in) :: lineage_id
    type(fmr_b110_physical_state_t), intent(in) :: state
    type(rfm_physical_state_t), intent(in) :: rfm_state
    real(real64), intent(in) :: initial_time
    logical, intent(out) :: ok
    class(transaction_state_t), allocatable :: carrier
    logical :: copied

    ok = .false.
    if (.not. rfm_state%ready()) return
    if (allocated(state%macropore) .or. allocated(state%snow) .or. allocated(state%soil_temperature)) return

    allocate(fmr_b110_rfm_state_t :: carrier)
    select type (typed_carrier => carrier)
    type is (fmr_b110_rfm_state_t)
      call copy_b110_physical_state(state, typed_carrier)
      call copy_rfm_physical_state(rfm_state, typed_carrier%rfm, copied)
      if (.not. copied) return
    end select
    call committed%initialize(lineage_id, carrier, ok, initial_time)
  end subroutine fmr_new_b110_rfm_committed_state

  subroutine fmr_new_b110_temporal_indicator_committed_state(committed, lineage_id, state, initial_time, ok, &
                                                              initial_right_derivative)
    type(kernel_committed_state_t), intent(out) :: committed
    integer(int64), intent(in) :: lineage_id
    type(fmr_b110_physical_state_t), intent(in) :: state
    real(real64), intent(in) :: initial_time
    logical, intent(out) :: ok
    real(real64), intent(in), optional :: initial_right_derivative(:)
    class(transaction_state_t), allocatable :: carrier
    logical :: seeded

    ok = .false.
    allocate(fmr_b110_temporal_indicator_state_t :: carrier)
    select type (typed_carrier => carrier)
    type is (fmr_b110_temporal_indicator_state_t)
      call copy_b110_physical_state(state, typed_carrier)
      call typed_carrier%temporal_history%clear()
      if (present(initial_right_derivative)) then
        if (state%active_nodes <= 0 .or. size(initial_right_derivative) /= state%active_nodes) return
        call typed_carrier%temporal_history%replace(initial_right_derivative, seeded)
        if (.not. seeded) return
      end if
    end select
    call committed%initialize(lineage_id, carrier, ok, initial_time)
  end subroutine fmr_new_b110_temporal_indicator_committed_state

  subroutine fmr_new_b110_fixed_weir_surface_water_committed_state(committed, lineage_id, state, initial_time, ok)
    type(kernel_committed_state_t), intent(out) :: committed
    integer(int64), intent(in) :: lineage_id
    type(fmr_b110_fixed_weir_surface_water_state_t), intent(in) :: state
    real(real64), intent(in) :: initial_time
    logical, intent(out) :: ok
    class(transaction_state_t), allocatable :: carrier

    ok = .false.
    if (.not. ieee_is_finite(state%surface_water%storage)) return
    allocate(fmr_b110_fixed_weir_surface_water_state_t :: carrier)
    select type (typed_carrier => carrier)
    type is (fmr_b110_fixed_weir_surface_water_state_t)
      call copy_b110_physical_state(state, typed_carrier)
      typed_carrier%surface_water = state%surface_water
    end select
    call committed%initialize(lineage_id, carrier, ok, initial_time)
  end subroutine fmr_new_b110_fixed_weir_surface_water_committed_state

  subroutine fmr_new_b110_black_evaporation_committed_state(committed, lineage_id, state, black_state, initial_time, ok, parameters)
    type(kernel_committed_state_t), intent(out) :: committed
    integer(int64), intent(in) :: lineage_id
    type(fmr_b110_physical_state_t), intent(in) :: state
    type(black_evaporation_state_t), intent(in) :: black_state
    real(real64), intent(in) :: initial_time
    logical, intent(out) :: ok
    type(fmr_b110_physical_parameters_t),intent(in),optional::parameters
    class(transaction_state_t), allocatable :: carrier

    ok = .false.
    if (.not. ieee_is_finite(black_state%ldwet) .or. black_state%ldwet < 0.0_real64) return
    allocate(fmr_b110_black_evaporation_state_t :: carrier)
    select type (typed_carrier => carrier)
    type is (fmr_b110_black_evaporation_state_t)
      call copy_b110_physical_state(state, typed_carrier)
      typed_carrier%black_evaporation = black_state
    end select
    call committed%initialize(lineage_id, carrier, ok, initial_time, parameters)
  end subroutine fmr_new_b110_black_evaporation_committed_state

  subroutine fmr_new_b110_boesten_evaporation_committed_state(committed, lineage_id, state, boesten_state, initial_time, ok, parameters)
    type(kernel_committed_state_t), intent(out) :: committed
    integer(int64), intent(in) :: lineage_id
    type(fmr_b110_physical_state_t), intent(in) :: state
    type(boesten_evaporation_state_t), intent(in) :: boesten_state
    real(real64), intent(in) :: initial_time
    logical, intent(out) :: ok
    type(fmr_b110_physical_parameters_t),intent(in),optional::parameters
    class(transaction_state_t), allocatable :: carrier

    ok = .false.
    if (.not. ieee_is_finite(boesten_state%spev) .or. boesten_state%spev < 0.0_real64 .or. &
        .not. ieee_is_finite(boesten_state%saev) .or. boesten_state%saev < 0.0_real64) return
    allocate(fmr_b110_boesten_evaporation_state_t :: carrier)
    select type (typed_carrier => carrier)
    type is (fmr_b110_boesten_evaporation_state_t)
      call copy_b110_physical_state(state, typed_carrier)
      typed_carrier%boesten_evaporation = boesten_state
    end select
    call committed%initialize(lineage_id, carrier, ok, initial_time, parameters)
  end subroutine fmr_new_b110_boesten_evaporation_committed_state

  subroutine fmr_new_b110_boesten_macropore_committed_state(committed, lineage_id, state, boesten_state, initial_time, ok)
    type(kernel_committed_state_t), intent(out) :: committed
    integer(int64), intent(in) :: lineage_id
    type(fmr_b110_physical_state_t), intent(in) :: state
    type(boesten_evaporation_state_t), intent(in) :: boesten_state
    real(real64), intent(in) :: initial_time
    logical, intent(out) :: ok
    class(transaction_state_t), allocatable :: carrier

    ok = .false.
    if (.not. allocated(state%macropore) .or. .not. state%macropore%ready()) return
    if (state%macropore%num_nodes /= state%active_nodes) return
    if (.not. ieee_is_finite(boesten_state%spev) .or. boesten_state%spev < 0.0_real64 .or. &
        .not. ieee_is_finite(boesten_state%saev) .or. boesten_state%saev < 0.0_real64) return
    allocate(fmr_b110_boesten_macropore_state_t :: carrier)
    select type (typed_carrier => carrier)
    type is (fmr_b110_boesten_macropore_state_t)
      call copy_b110_physical_state(state, typed_carrier)
      typed_carrier%boesten_evaporation = boesten_state
    end select
    call committed%initialize(lineage_id, carrier, ok, initial_time)
  end subroutine fmr_new_b110_boesten_macropore_committed_state

  logical function state_matches_numerical_continuation_layout(state, temporal_history_enabled, &
                                                               macropore_reduction_enabled, &
                                                               fixed_weir_surface_water_active, &
                                                               black_evaporation_active, &
                                                               boesten_evaporation_active, macropore_active, rutter_active, &
                                                               hysteresis_active) result(matches)
    class(transaction_state_t), intent(in) :: state
    logical, intent(in) :: temporal_history_enabled, macropore_reduction_enabled, fixed_weir_surface_water_active
    logical, intent(in) :: black_evaporation_active, boesten_evaporation_active, macropore_active, rutter_active
    logical, intent(in) :: hysteresis_active
    if (black_evaporation_active .and. boesten_evaporation_active) then
      matches = .false.
      return
    end if
    select type (state)
    type is (fmr_b110_macropore_reduction_state_t)
      matches = macropore_reduction_enabled .and. .not. temporal_history_enabled .and. &
           .not. fixed_weir_surface_water_active .and. .not. black_evaporation_active .and. &
           .not. boesten_evaporation_active .and. state%reduction_continuation%valid()
    type is (fmr_b110_temporal_indicator_state_t)
      matches = temporal_history_enabled .and. .not. macropore_reduction_enabled .and. &
           .not. fixed_weir_surface_water_active .and. &
           .not. black_evaporation_active .and. .not. boesten_evaporation_active .and. .not. rutter_active
    type is (fmr_b110_fixed_weir_surface_water_state_t)
      matches = .not. temporal_history_enabled .and. .not. macropore_reduction_enabled .and. &
           fixed_weir_surface_water_active .and. &
           .not. black_evaporation_active .and. .not. boesten_evaporation_active .and. .not. rutter_active
    type is (fmr_b110_black_evaporation_state_t)
      matches = .not. temporal_history_enabled .and. .not. macropore_reduction_enabled .and. &
           .not. fixed_weir_surface_water_active .and. black_evaporation_active .and. .not. boesten_evaporation_active .and. &
           (allocated(state%rutter).eqv.rutter_active)
    type is (fmr_b110_boesten_evaporation_state_t)
      matches = .not. temporal_history_enabled .and. .not. macropore_reduction_enabled .and. &
           .not. fixed_weir_surface_water_active .and. .not. black_evaporation_active .and. boesten_evaporation_active .and. &
           .not. macropore_active .and. .not. allocated(state%macropore) .and. .not. rutter_active
    type is (fmr_b110_boesten_macropore_state_t)
      matches = .not. temporal_history_enabled .and. .not. macropore_reduction_enabled .and. &
           .not. fixed_weir_surface_water_active .and. .not. black_evaporation_active .and. boesten_evaporation_active .and. &
           macropore_active .and. allocated(state%macropore) .and. state%macropore%ready() .and. &
           state%macropore%num_nodes == state%active_nodes .and. (allocated(state%rutter) .eqv. rutter_active)
    type is (fmr_b110_physical_state_t)
      matches = .not. temporal_history_enabled .and. .not. macropore_reduction_enabled .and. &
           .not. fixed_weir_surface_water_active .and. &
           .not. black_evaporation_active .and. .not. boesten_evaporation_active .and. &
           (allocated(state%rutter) .eqv. rutter_active) .and. &
           (allocated(state%hysteresis) .eqv. hysteresis_active)
    class default
      matches = .false.
    end select
  end function state_matches_numerical_continuation_layout

  subroutine clear_snow_preparation(model)
    type(fmr_serialized_reference_model_t), intent(inout) :: model
    model%snow_active = .false.
    model%soil_temperature_active = .false.
    model%black_evaporation_active = .false.
    model%boesten_evaporation_active = .false.
    model%snow_event_prepared = .false.
    model%state_profile_admitted = .false.
    model%snow_outer_t0 = 0.0_real64
    model%snow_outer_t1 = 0.0_real64
    model%snow_melt_rate = 0.0_real64
    model%snow_candidate = snow_state_t()
    model%snow_fluxes = snow_flux_result_t()
    model%snow_diagnostics = snow_diagnostics_t()
  end subroutine clear_snow_preparation

  subroutine prepare_snow_outer_event(model, parameters, committed, forcing, t0, t1)
    type(fmr_serialized_reference_model_t), intent(inout) :: model
    type(fmr_b110_physical_parameters_t), intent(in) :: parameters
    type(kernel_committed_state_t), intent(in) :: committed
    type(fmr_b110_physical_forcing_t), intent(in) :: forcing
    real(real64), intent(in) :: t0, t1
    class(transaction_state_t), allocatable :: snapshot
    logical :: available
    call clear_snow_preparation(model)
    if(allocated(parameters%bartholomeus)) then
      if(.not.valid_fmr_bartholomeus_parameters(parameters%bartholomeus,parameters%active_nodes)) return
    else
      if(allocated(forcing%crop_oxygen)) return
    end if
    model%snow_active = parameters%snow_active
    model%soil_temperature_active = parameters%soil_temperature_active
    model%black_evaporation_active = parameters%black_evaporation_active
    model%boesten_evaporation_active = parameters%boesten_evaporation_active
    model%macropore_active = parameters%macropore_active
    model%snow_outer_t0 = t0
    model%snow_outer_t1 = t1
    if (model%fixed_weir_surface_water_active .and. parameters%snow_active) return
    call committed%snapshot(snapshot, available)
    if (.not. available) return
    if (.not. state_matches_numerical_continuation_layout(snapshot, model%temporal_indicator_history_enabled, &
                                                           model%macropore_reduction_continuation_enabled, &
                                                           model%fixed_weir_surface_water_active, &
                                                           model%black_evaporation_active, &
                                                           model%boesten_evaporation_active, model%macropore_active, &
                                                           model%rutter_active, parameters%hysteresis_active)) then
      write(0,'(a,7(1x,l1))') 'HYST_PROFILE_REJECT_DEBUG', model%temporal_indicator_history_enabled, &
           model%macropore_reduction_continuation_enabled, model%fixed_weir_surface_water_active, &
           model%black_evaporation_active, model%boesten_evaporation_active, &
           model%rutter_active, parameters%hysteresis_active
      select type (dbg => snapshot)
      type is (fmr_b110_physical_state_t)
        write(0,'(a,2(1x,l1))') 'HYST_PROFILE_STATE_DEBUG',allocated(dbg%hysteresis),allocated(dbg%rutter)
      class default
        write(0,'(a)') 'HYST_PROFILE_DIFFERENT_TYPE'
      end select
      return
    end if
    select type (physical => snapshot)
    class is (fmr_b110_physical_state_t)
      if (parameters%snow_active) then
        if (.not. allocated(parameters%snow) .or. .not. allocated(forcing%snow) .or. &
            .not. allocated(physical%snow)) return
        call evaluate_snow_reference_call(parameters%snow, physical%snow%process, forcing%snow, t0, t1, &
             model%snow_candidate, model%snow_fluxes, model%snow_diagnostics)
        if (model%snow_diagnostics%status /= SNOW_OK .or. .not. model%snow_diagnostics%mass%available) return
        model%snow_event_prepared = .true.
        model%snow_melt_rate = model%snow_fluxes%melt / (t1 - t0)
      else
        if (allocated(parameters%snow) .or. allocated(forcing%snow) .or. allocated(physical%snow)) return
      end if
      if (parameters%soil_temperature_active) then
        if (parameters%snow_active) return
        if (.not. allocated(parameters%soil_temperature) .or. .not. allocated(forcing%soil_temperature) .or. &
            .not. allocated(physical%soil_temperature)) return
        if (.not. parameters%soil_temperature%ready() .or. .not. physical%soil_temperature%ready()) return
        if (parameters%soil_temperature%node_count() /= parameters%active_nodes .or. &
            physical%soil_temperature%node_count() /= parameters%active_nodes) return
      else
        if (allocated(parameters%soil_temperature) .or. allocated(forcing%soil_temperature) .or. &
            allocated(physical%soil_temperature)) return
      end if
      model%state_profile_admitted = .true.
    class default
      return
    end select
  end subroutine prepare_snow_outer_event

  subroutine fmr_serialized_backend_initialize(self, top_boundary,water_flux_temporal)
    class(fmr_serialized_reference_backend_t), target, intent(inout) :: self
    class(top_boundary_provider_t), target, intent(in) :: top_boundary
    type(water_flux_temporal_policy_t),intent(in),optional::water_flux_temporal
    logical :: selection_ok
    integer :: selection_status
    self%initialized = .false.
    self%model%water_flux_temporal=water_flux_temporal_policy_t()
    if(present(water_flux_temporal))self%model%water_flux_temporal=water_flux_temporal
    call self%model%soil_water_selection%configure('', selection_ok, selection_status)
    if (.not. selection_ok) return
    self%model%top_boundary => top_boundary
    self%model%temporal_indicator_history_enabled = .false.
    self%model%macropore_reduction_continuation_enabled = .false.
    self%model%temporal_indicator_budget_supplied = .false.
    self%model%temporal_indicator_budget_valid = .false.
    self%model%temporal_indicator_budget = 0.0_real64
    self%model%bottom_thermal_carrier_active = .false.
    self%model%bottom_thermal_carrier_valid = .true.
    self%bottom_thermal_requested = .false.
    call configure_trajectory_direction(self%model%trajectory_direction, .false.)
    call self%model%bottom_thermal_carrier%clear()
    self%model%trusted_prepared_default_mvg = .false.
    nullify(self%model%trusted_parameter_source)
    nullify(self%model%hydraulic_parameters)
    call self%bottom_thermal_candidate%clear()
    self%model%top_sensible_boundary_carrier_active = .false.
    self%model%top_sensible_boundary_carrier_valid = .true.
    self%top_sensible_boundary_requested = .false.
    call self%model%top_sensible_boundary_carrier%clear()
    call self%top_sensible_boundary_candidate%clear()
    call self%clear_fixed_weir_surface_water()
    self%model%macropore_active = .false.
    if (allocated(self%model%macropore_config)) deallocate(self%model%macropore_config)
    self%model%macropore_policy = macropore_runtime_policy_t()
    self%model%base_salt_temporal_policy = fmr_base_salt_temporal_policy_t()
    if(allocated(self%model%mobile_dispersion))deallocate(self%model%mobile_dispersion)
    self%model%macropore_policy_configured = .false.
    call self%model%rfm_configuration%clear()
    call self%kernel%bind_model(self%model)
    self%initialized = .true.
  end subroutine fmr_serialized_backend_initialize

  logical function fmr_water_flux_temporal_enabled(self) result(enabled)
    class(fmr_serialized_reference_backend_t),intent(in)::self
    enabled=self%model%water_flux_temporal%enabled
  end function

  subroutine fmr_serialized_backend_configure_soil_water_model(self, requested_model_key, ok, status, &
                                                                asset_root, material_id)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    character(len=*), intent(in) :: requested_model_key
    logical, intent(out) :: ok
    integer, intent(out) :: status
    character(len=*), intent(in), optional :: asset_root, material_id

    ok = .false.
    status = FMR_ROSSFAST_BIND_INTERNAL_ERROR
    if (.not. self%initialized) return
    self%initialized = .false.
    if (present(asset_root)) then
      if (present(material_id)) then
        call self%model%soil_water_selection%configure(requested_model_key, ok, status, &
             asset_root=asset_root, material_id=material_id)
      else
        call self%model%soil_water_selection%configure(requested_model_key, ok, status, asset_root=asset_root)
      end if
    else if (present(material_id)) then
      call self%model%soil_water_selection%configure(requested_model_key, ok, status, material_id=material_id)
    else
      call self%model%soil_water_selection%configure(requested_model_key, ok, status)
    end if
    self%initialized = ok
  end subroutine fmr_serialized_backend_configure_soil_water_model

  subroutine fmr_serialized_backend_configure_macropore_policy(self, policy, ok)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    type(macropore_runtime_policy_t), intent(in) :: policy
    logical, intent(out) :: ok

    ok = .false.
    if (.not. self%initialized) return
    if (.not. policy%valid()) return
    if (.not. policy%enabled) return
    self%model%macropore_policy = policy
    self%model%macropore_policy_configured = .true.
    ok = .true.
  end subroutine fmr_serialized_backend_configure_macropore_policy

  subroutine fmr_serialized_backend_configure_rfm_runtime(self, config, ok)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    type(rfm_runtime_configuration_t), intent(in) :: config
    logical, intent(out) :: ok

    ok = .false.
    if (.not. self%initialized) return
    if (.not. config%valid()) return
    self%model%rfm_configuration = config
    ok = self%model%rfm_configuration%valid()
  end subroutine fmr_serialized_backend_configure_rfm_runtime

  subroutine fmr_serialized_backend_set_bottom_thermal_carrier_enabled(self, enabled)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    logical, intent(in) :: enabled
    self%bottom_thermal_requested = enabled
    call self%bottom_thermal_candidate%clear()
    call self%model%bottom_thermal_carrier%clear()
    self%model%bottom_thermal_carrier_active = .false.
    self%model%bottom_thermal_carrier_valid = .true.
  end subroutine fmr_serialized_backend_set_bottom_thermal_carrier_enabled

  function fmr_serialized_backend_bottom_thermal_snapshot(self) result(candidate)
    class(fmr_serialized_reference_backend_t), intent(in) :: self
    type(fmr_bottom_thermal_candidate_t) :: candidate
    call self%bottom_thermal_candidate%copy_to(candidate)
  end function fmr_serialized_backend_bottom_thermal_snapshot

  subroutine fmr_serialized_backend_set_top_sensible_boundary_enabled(self, enabled)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    logical, intent(in) :: enabled
    self%top_sensible_boundary_requested = enabled
    call self%top_sensible_boundary_candidate%clear()
    call self%model%top_sensible_boundary_carrier%clear()
    self%model%top_sensible_boundary_carrier_active = .false.
    self%model%top_sensible_boundary_carrier_valid = .true.
  end subroutine fmr_serialized_backend_set_top_sensible_boundary_enabled

  function fmr_serialized_backend_top_sensible_boundary_snapshot(self) result(candidate)
    class(fmr_serialized_reference_backend_t), intent(in) :: self
    type(fmr_top_sensible_boundary_candidate_t) :: candidate
    call self%top_sensible_boundary_candidate%copy_to(candidate)
  end function fmr_serialized_backend_top_sensible_boundary_snapshot

  subroutine fmr_serialized_backend_configure_fixed_weir_surface_water(self, parameters, forcing, numerical, ok)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    type(fixed_weir_surface_water_parameters_t), intent(in) :: parameters
    type(fixed_weir_surface_water_forcing_t), intent(in) :: forcing
    type(fixed_weir_surface_water_numerical_config_t), intent(in) :: numerical
    logical, intent(out) :: ok
    logical :: parameters_ok

    call self%clear_fixed_weir_surface_water()
    ok = .false.
    if (.not. self%initialized) return
    call validate_fixed_weir_surface_water_parameters(parameters, parameters_ok)
    if (.not. parameters_ok) return
    if (.not. ieee_is_finite(forcing%secondary_drainage_rate) .or. &
        .not. ieee_is_finite(forcing%supply_capacity_rate)) return
    if (forcing%secondary_drainage_rate < 0.0_real64 .or. forcing%supply_capacity_rate < 0.0_real64) return
    if (numerical%max_bisection_iterations <= 0 .or. &
        .not. ieee_is_finite(numerical%rating_storage_abs_tolerance) .or. &
        .not. ieee_is_finite(numerical%rating_storage_rel_tolerance)) return
    if (numerical%rating_storage_abs_tolerance <= 0.0_real64 .or. &
        numerical%rating_storage_rel_tolerance < 0.0_real64) return

    self%model%fixed_weir_surface_water_parameters = parameters
    self%model%fixed_weir_surface_water_forcing = forcing
    self%model%fixed_weir_surface_water_numerical = numerical
    self%model%fixed_weir_surface_water_result = fixed_weir_surface_water_result_t()
    self%model%fixed_weir_surface_water_configured = .true.
    self%model%fixed_weir_surface_water_active = .true.
    ok = .true.
  end subroutine fmr_serialized_backend_configure_fixed_weir_surface_water

  subroutine fmr_serialized_backend_clear_fixed_weir_surface_water(self)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    self%model%fixed_weir_surface_water_active = .false.
    self%model%fixed_weir_surface_water_configured = .false.
    self%model%fixed_weir_surface_water_parameters = fixed_weir_surface_water_parameters_t()
    self%model%fixed_weir_surface_water_forcing = fixed_weir_surface_water_forcing_t()
    self%model%fixed_weir_surface_water_numerical = fixed_weir_surface_water_numerical_config_t()
    self%model%fixed_weir_surface_water_result = fixed_weir_surface_water_result_t()
  end subroutine fmr_serialized_backend_clear_fixed_weir_surface_water

  logical function fmr_serialized_rossfast_parameter_matches(actual, expected) result(matches)
    real(real64), intent(in) :: actual, expected
    real(real64) :: tolerance
    tolerance = 64.0_real64 * epsilon(1.0_real64) * max(1.0_real64, abs(expected))
    matches = ieee_is_finite(actual) .and. abs(actual - expected) <= tolerance
  end function fmr_serialized_rossfast_parameter_matches

  logical function fmr_serialized_rossfast_preflight(self, template, parameters, forcing, config, t0, t1) result(ok)
    class(fmr_serialized_reference_backend_t), intent(in) :: self
    type(fmr_template_t), intent(in) :: template
    type(fmr_b110_physical_parameters_t), intent(in) :: parameters
    type(fmr_b110_physical_forcing_t), intent(in) :: forcing
    type(canonical_numerical_config_t), intent(in) :: config
    real(real64), intent(in) :: t0, t1
    type(rossfast_d3r_material_t) :: material
    character(len=3) :: material_id
    real(real64) :: duration, tolerance, expected_m
    logical :: found, duration_admitted
    integer :: i, index

    ok = .false.
    if (.not. self%model%soil_water_selection%execution_ready()) return
    if (.not. self%model%soil_water_selection%uses_rossfast()) then
      ok = self%model%soil_water_selection%uses_reference()
      return
    end if
    if (template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_BASE .or. &
        template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_NONE) return
    if (config%transaction%temporal_mode /= TX_TEMPORAL_MODEL_CERTIFICATE) return
    if (config%transaction%retry_scale /= ROSSFAST_D3R_RETRY_SCALE .or. &
        config%transaction%max_retries /= ROSSFAST_D3R_MAX_FULL_INDEX) return
    if (.not. ieee_is_finite(config%transaction%mass_tolerance) .or. &
        config%transaction%mass_tolerance <= 0.0_real64 .or. &
        config%transaction%mass_tolerance > ROSSFAST_D3R_HARD_MASS_TOL_CM) return
    if (config%accepted_trajectory_direction%requested) return
    if (self%bottom_thermal_requested .or. self%top_sensible_boundary_requested .or. &
        self%model%fixed_weir_surface_water_active) return
    if (parameters%active_nodes /= ROSSFAST_D3R_N_CELLS .or. parameters%bottom_mode /= 2) return
    if (.not. allocated(parameters%dz) .or. size(parameters%dz) /= ROSSFAST_D3R_N_CELLS) return
    if (any(.not. ieee_is_finite(parameters%dz)) .or. any(parameters%dz /= ROSSFAST_D3R_DZ_CM)) return
    if (.not. allocated(parameters%cofgen) .or. size(parameters%cofgen,1) < 9 .or. &
        size(parameters%cofgen,2) /= ROSSFAST_D3R_N_CELLS) return
    if (parameters%root_extraction_active .or. parameters%macropore_active .or. parameters%snow_active .or. &
        parameters%hysteresis_active .or. parameters%tabulated_hydraulics_active .or. &
        parameters%elasticity_active .or. parameters%frost_active .or. parameters%soil_temperature_active .or. &
        parameters%drainage_response_active) return
    if (parameters%swkimpl /= 0 .or. parameters%swsophy /= 0) return
    if (.not. allocated(forcing%drainage_flux_by_level) .or. &
        .not. allocated(forcing%subsurface_irrigation_source) .or. .not. allocated(forcing%root_extraction_sink)) return
    if (any(.not. ieee_is_finite(forcing%drainage_flux_by_level)) .or. &
        any(.not. ieee_is_finite(forcing%subsurface_irrigation_source)) .or. &
        any(.not. ieee_is_finite(forcing%root_extraction_sink))) return
    if (any(forcing%drainage_flux_by_level /= 0.0_real64) .or. &
        any(forcing%subsurface_irrigation_source /= 0.0_real64) .or. &
        any(forcing%root_extraction_sink /= 0.0_real64)) return
    if (allocated(forcing%drainage_response_controls) .or. allocated(forcing%snow) .or. &
        allocated(forcing%soil_temperature)) return
    select type (top_boundary => self%model%top_boundary)
    type is (fixed_flux_top_boundary_provider_t)
      continue
    class default
      return
    end select

    material_id = self%model%soil_water_selection%selected_material_id()
    call rossfast_d3r_material_from_id(material_id, material, found)
    if (.not. found) return
    expected_m = 1.0_real64 - 1.0_real64 / material%n
    do i = 1, ROSSFAST_D3R_N_CELLS
      if (.not. fmr_serialized_rossfast_parameter_matches(parameters%cofgen(1,i), material%theta_r)) return
      if (.not. fmr_serialized_rossfast_parameter_matches(parameters%cofgen(2,i), material%theta_s)) return
      if (.not. fmr_serialized_rossfast_parameter_matches(parameters%cofgen(3,i), material%ksatfit_cm_per_day)) return
      if (.not. fmr_serialized_rossfast_parameter_matches(parameters%cofgen(4,i), material%alpha_per_cm)) return
      if (.not. fmr_serialized_rossfast_parameter_matches(parameters%cofgen(5,i), material%lambda)) return
      if (.not. fmr_serialized_rossfast_parameter_matches(parameters%cofgen(6,i), material%n)) return
      if (.not. fmr_serialized_rossfast_parameter_matches(parameters%cofgen(7,i), expected_m)) return
      if (.not. fmr_serialized_rossfast_parameter_matches(parameters%cofgen(9,i), material%h_enpr_cm)) return
    end do

    if (.not. ieee_is_finite(t0) .or. .not. ieee_is_finite(t1) .or. t1 <= t0) return
    duration_admitted = .false.
    do index = 0, ROSSFAST_D3R_MAX_FULL_INDEX
      duration = rossfast_d3r_full_duration_for_index(index)
      tolerance = 2.0_real64 * max(spacing(t0), spacing(t1), spacing(duration))
      if (abs((t1 - t0) - duration) <= tolerance) then
        duration_admitted = .true.
        exit
      end if
    end do
    if (.not. duration_admitted) return
    ok = .true.
  end function fmr_serialized_rossfast_preflight

  subroutine fmr_serialized_backend_commit_reference_floor_candidate(self, committed, candidate, diagnostics, &
                                                                       did_commit, status)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    type(kernel_committed_state_t), intent(inout) :: committed
    type(kernel_reference_floor_candidate_t), intent(inout) :: candidate
    type(kernel_diagnostics_t), intent(inout) :: diagnostics
    logical, intent(out) :: did_commit
    integer, intent(out) :: status

    did_commit = .false.
    status = KERNEL_STATUS_NOT_ADMITTED
    if (.not. self%initialized) return
    call self%kernel%commit_reference_floor_candidate(committed, candidate, diagnostics, did_commit, status)
  end subroutine fmr_serialized_backend_commit_reference_floor_candidate

  subroutine fmr_serialized_backend_discard_reference_floor_candidate(self, candidate, diagnostics)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    type(kernel_reference_floor_candidate_t), intent(inout) :: candidate
    type(kernel_diagnostics_t), intent(inout) :: diagnostics

    if (.not. self%initialized) return
    call self%kernel%discard_reference_floor_candidate(candidate, diagnostics)
  end subroutine fmr_serialized_backend_discard_reference_floor_candidate

  subroutine fmr_serialized_backend_commit_trial_candidate(self, committed, candidate, diagnostics, did_commit, status)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    type(kernel_committed_state_t), intent(inout) :: committed
    type(kernel_candidate_state_t), intent(inout) :: candidate
    type(kernel_diagnostics_t), intent(inout) :: diagnostics
    logical, intent(out) :: did_commit
    integer, intent(out) :: status

    did_commit = .false.
    status = KERNEL_STATUS_NOT_ADMITTED
    if (.not. self%initialized) return
    call fmr_commit_candidate(self%kernel, committed, candidate, diagnostics, did_commit, status)
  end subroutine fmr_serialized_backend_commit_trial_candidate

  subroutine fmr_serialized_backend_discard_trial_candidate(self, candidate, diagnostics)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    type(kernel_candidate_state_t), intent(inout) :: candidate
    type(kernel_diagnostics_t), intent(inout) :: diagnostics

    if (.not. self%initialized) return
    call fmr_discard_candidate(self%kernel, candidate, diagnostics)
  end subroutine fmr_serialized_backend_discard_trial_candidate

  subroutine fmr_serialized_backend_run_reference_floor_sample(self, column, template, parameters, committed, &
                                                                 forcing, t0, t1, mass_tolerance, result, candidate, &
                                                                 diagnostics)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    type(fmr_logical_column_t), intent(in) :: column
    type(fmr_template_t), intent(in) :: template
    type(fmr_b110_physical_parameters_t), intent(in) :: parameters
    type(kernel_committed_state_t), intent(in) :: committed
    type(fmr_b110_physical_forcing_t), intent(in) :: forcing
    real(real64), intent(in) :: t0, t1, mass_tolerance
    type(kernel_reference_floor_result_t), intent(out) :: result
    type(kernel_reference_floor_candidate_t), intent(out) :: candidate
    type(kernel_diagnostics_t), intent(out) :: diagnostics

    result = kernel_reference_floor_result_t()
    result%requested_t0 = t0
    result%requested_t1 = t1
    diagnostics = kernel_diagnostics_t()

    call self%bottom_thermal_candidate%clear()
    call self%model%bottom_thermal_carrier%clear()
    self%model%bottom_thermal_carrier_active = .false.
    self%model%bottom_thermal_carrier_valid = .true.
    call self%top_sensible_boundary_candidate%clear()
    call self%model%top_sensible_boundary_carrier%clear()
    self%model%top_sensible_boundary_carrier_active = .false.
    self%model%top_sensible_boundary_carrier_valid = .true.
    self%model%temporal_indicator_history_enabled = .false.
    self%model%temporal_indicator_budget_supplied = .false.
    self%model%temporal_indicator_budget_valid = .false.
    self%model%temporal_indicator_budget = 0.0_real64
    call configure_trajectory_direction(self%model%trajectory_direction, .false.)
    self%model%trajectory_direction_requested = .false.
    self%model%trajectory_provenance_valid = .false.
    self%model%trajectory_worker_id = -1

    if (.not. self%initialized .or. column%backend_id /= FMR_BACKEND_SERIALIZED_REFERENCE .or. &
        template%compatible_backend_id /= FMR_BACKEND_SERIALIZED_REFERENCE .or. &
        column%template_id /= template%template_id .or. column%column_id <= 0_int64) then
      result%status = KERNEL_REFERENCE_FLOOR_STATUS_NOT_ADMITTED
      diagnostics%admission_rejections = 1
      return
    end if
    if (.not. self%model%soil_water_selection%uses_reference()) then
      result%status = KERNEL_REFERENCE_FLOOR_STATUS_NOT_ADMITTED
      diagnostics%admission_rejections = 1
      return
    end if

    if (template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_BASE .or. &
        template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_NONE .or. &
        self%model%fixed_weir_surface_water_active .or. self%bottom_thermal_requested .or. &
        self%top_sensible_boundary_requested .or. parameters%snow_active .or. &
        parameters%soil_temperature_active .or. parameters%root_extraction_active .or. &
        parameters%macropore_active .or. parameters%drainage_response_active .or. &
        parameters%drainage_qbot_smooth_freatic_projection .or. &
        (parameters%bottom_mode /= 2 .and. parameters%bottom_mode /= 5)) then
      result%status = KERNEL_REFERENCE_FLOOR_STATUS_NOT_ADMITTED
      diagnostics%admission_rejections = 1
      return
    end if

    call prepare_snow_outer_event(self%model, parameters, committed, forcing, t0, t1)
    if (.not. self%model%state_profile_admitted) then
      result%status = KERNEL_REFERENCE_FLOOR_STATUS_NOT_ADMITTED
      diagnostics%admission_rejections = 1
      return
    end if

    call self%kernel%sample_reference_floor_interval(parameters, committed, forcing, t0, t1, mass_tolerance, &
         result, candidate, diagnostics)
  end subroutine fmr_serialized_backend_run_reference_floor_sample

  subroutine fmr_serialized_backend_run_trial(self, column, template, parameters, committed, forcing, config, &
                                               t0, t1, checkpoint, result, candidate, diagnostics, &
                                               trusted_prepared_parameters, trace_accepted_water_flux_substeps,trace_accepted_soil_n_heat)
    class(fmr_serialized_reference_backend_t), intent(inout) :: self
    type(fmr_logical_column_t), intent(in) :: column
    type(fmr_template_t), intent(in) :: template
    type(fmr_b110_physical_parameters_t), target, intent(in) :: parameters
    type(kernel_committed_state_t), intent(in) :: committed
    type(fmr_b110_physical_forcing_t), intent(in) :: forcing
    type(canonical_numerical_config_t), intent(in) :: config
    real(real64), intent(in) :: t0, t1
    type(kernel_checkpoint_t), intent(in) :: checkpoint
    type(kernel_result_t), intent(out) :: result
    type(kernel_candidate_state_t), intent(out) :: candidate
    type(kernel_diagnostics_t), intent(out) :: diagnostics
    logical, intent(in), optional :: trusted_prepared_parameters
    logical, intent(in), optional :: trace_accepted_water_flux_substeps
    logical, intent(in), optional :: trace_accepted_soil_n_heat
    logical :: anchored_ceiling
    real(real64) :: previous_selector_cursor,accepted_width,endpoint_margin
    logical :: soil_n_heat_trace
    logical :: bottom_thermal_ok, top_sensible_ok, soil_salt_boundary_ok
    integer :: salt_active_domains
    logical :: rutter_snapshot_available
    logical :: composed_rutter_boesten_macro,composed_rutter_black
    integer :: rutter_prepare_status
    real(real64) :: rutter_source_origin, rutter_sink_total, rutter_scale,rutter_min_net_wetting,rutter_capacity_export
    real(real64) :: rutter_rain_amount, rutter_total_input, rutter_surface_output, rutter_storage_change, rutter_residual
    type(fmr_b110_physical_forcing_t) :: trial_forcing
    type(canonical_numerical_config_t) :: trial_config
    type(rutter_source_state_t) :: rutter_accepted_state, rutter_candidate_state,rutter_capacity_state
    type(rutter_source_trial_t) :: rutter_trial
    type(rutter_interval_result_t) :: rutter_result
    type(rutter_diagnostics_t) :: rutter_diagnostics
    class(transaction_state_t), allocatable :: accepted_snapshot

    if(self%model%water_flux_temporal%enabled)then
      if(.not.water_flux_trial_admitted(self,parameters,forcing,template,config))then
        call reject_backend_trial(result,candidate,diagnostics)
        return
      end if
    end if

    call self%bottom_thermal_candidate%clear()
    call self%model%bottom_thermal_carrier%clear()
    self%model%bottom_thermal_carrier_active = .false.
    self%model%bottom_thermal_carrier_valid = .true.
    call self%top_sensible_boundary_candidate%clear()
    call self%model%top_sensible_boundary_carrier%clear()
    self%model%top_sensible_boundary_carrier_active = .false.
    self%model%top_sensible_boundary_carrier_valid = .true.
    self%model%temporal_indicator_history_enabled = .false.
    self%model%temporal_indicator_budget_supplied = .false.
    self%model%temporal_indicator_budget_valid = .false.
    self%model%temporal_indicator_budget = 0.0_real64
    self%model%trajectory_worker_id = -1
    self%model%trajectory_provenance_valid = .false.
    self%model%accepted_water_flux_trace_enabled = .false.
    if (present(trace_accepted_water_flux_substeps)) &
         self%model%accepted_water_flux_trace_enabled = trace_accepted_water_flux_substeps
    if (allocated(self%model%trace_arena)) deallocate(self%model%trace_arena)
    self%model%trace_generation = self%model%trace_generation + 1_int64
    self%model%trace_used = 0
    self%model%trace_tail = 0
    self%model%trace_count = 0
    soil_n_heat_trace=.false.
    if(present(trace_accepted_soil_n_heat))soil_n_heat_trace=trace_accepted_soil_n_heat
    if(soil_n_heat_trace)then
      if(.not.self%model%accepted_water_flux_trace_enabled.or..not.parameters%soil_temperature_active.or. &
         parameters%frost_active.or.(template%optional_state_layout_id/=FMR_OPTIONAL_STATE_LAYOUT_RESTRICTED_SOIL_TEMPERATURE.and. &
         .not.(template%optional_state_layout_id==FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_EVAPORATION.and. &
         parameters%boesten_evaporation_active).and. &
         .not.((template%optional_state_layout_id==FMR_OPTIONAL_STATE_LAYOUT_BLACK_EVAPORATION.or. &
         template%optional_state_layout_id==FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BLACK).and. &
         parameters%black_heat_composition_enabled.and.parameters%black_evaporation_active)).or. &
         template%solute_state_layout_id/=FMR_SOLUTE_STATE_LAYOUT_NONE)then
        call reject_backend_trial(result,candidate,diagnostics)
        return
      end if
    end if
    if (self%model%accepted_water_flux_trace_enabled) then
      if (parameters%snow_active .or. (parameters%drainage_response_active.and. &
          .not.joint_drainage_trace_valid(parameters)) .or. &
          (parameters%soil_temperature_active.and.template%solute_state_layout_id/=FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED.and. &
           .not.soil_n_heat_trace.and..not.(macro_numeric_heat_valid(parameters).and. &
             template%optional_state_layout_id==FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BOESTEN_MACROPORE)) .or. &
          (parameters%black_evaporation_active.and..not.parameters%black_heat_composition_enabled) .or. (parameters%boesten_evaporation_active.and. &
          (template%optional_state_layout_id/=FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_EVAPORATION.or. &
           parameters%macropore_active.or.allocated(forcing%rutter)).and. &
           .not.(parameters%macropore_active.and. &
             (template%optional_state_layout_id==FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_MACROPORE.or. &
              template%optional_state_layout_id==FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BOESTEN_MACROPORE).and. &
             template%solute_state_layout_id==FMR_SOLUTE_STATE_LAYOUT_NONE)) .or. (parameters%frost_active.and.(.not.parameters%root_frost%active.or. &
          .not.parameters%root_salinity_active.or.parameters%frost_bottom%active.or.parameters%frost_drainage%active.or. &
          template%solute_state_layout_id/=FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED)) .or. &
          self%model%rfm_configuration%enabled .or. &
          self%model%fixed_weir_surface_water_active) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
    end if
    self%model%accepted_water_flux_trace_failed = .false.
    if (column%column_id > 0_int64 .and. column%column_id <= int(huge(0), int64)) then
      self%model%trajectory_worker_id = int(column%column_id)
      self%model%trajectory_provenance_valid = self%model%trajectory_worker_id > 0
    end if
    if (.not. self%initialized .or. column%backend_id /= FMR_BACKEND_SERIALIZED_REFERENCE .or. &
        template%compatible_backend_id /= FMR_BACKEND_SERIALIZED_REFERENCE .or. &
        column%template_id /= template%template_id .or. column%column_id <= 0_int64) then
      call reject_backend_trial(result, candidate, diagnostics)
      return
    end if
    if(allocated(parameters%mobile_dispersion).and.template%solute_state_layout_id/=FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED)then
      call reject_backend_trial(result,candidate,diagnostics)
      return
    end if
    if (template%solute_state_layout_id /= FMR_SOLUTE_STATE_LAYOUT_NONE) then
      if (.not. allocated(forcing%c_drain_salt)) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      if (.not. fmr_c_drain_salt_matches_trial(forcing%c_drain_salt, column%forcing_handle, t0, t1)) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      if (.not. allocated(forcing%soil_salt_boundary)) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      select case (template%solute_state_layout_id)
      case (FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED)
        soil_salt_boundary_ok = fmr_soil_salt_boundary_matches_trial(forcing%soil_salt_boundary, &
             column%forcing_handle, t0, t1)
      case (FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED_MACROPORE)
        soil_salt_boundary_ok = .false.
        if (parameters%macropore_active .and. allocated(parameters%macropore)) then
          salt_active_domains = parameters%macropore%geometry%num_domains
          soil_salt_boundary_ok = fmr_soil_salt_boundary_matches_trial(forcing%soil_salt_boundary, &
               column%forcing_handle, t0, t1, salt_active_domains)
        end if
      case default
        soil_salt_boundary_ok = .false.
      end select
      if (.not. soil_salt_boundary_ok) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      if (config%transaction%temporal_mode /= TX_TEMPORAL_EXTERNAL_FULL_HALF .or. &
          parameters%snow_active .or. (parameters%frost_active.and.(.not.parameters%root_frost%active.or. &
          .not.parameters%root_salinity_active.or.parameters%frost_bottom%active.or.parameters%frost_drainage%active.or. &
          template%solute_state_layout_id/=FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED)) .or. parameters%drainage_response_active .or. &
          parameters%black_evaporation_active .or. parameters%boesten_evaporation_active .or. &
          self%model%rfm_configuration%enabled .or. self%model%fixed_weir_surface_water_active) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      if(allocated(parameters%mobile_dispersion))then
        if(template%solute_state_layout_id/=FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED.or. &
          .not.fmr_mobile_dispersion_matches_hydraulic_owner(parameters).or. &
          .not.self%model%base_salt_temporal_policy%transport%valid())then
          call reject_backend_trial(result,candidate,diagnostics)
          return
        end if
      end if
      if (template%solute_state_layout_id == FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED) then
        if (parameters%macropore_active .or. config%transaction%temporal_tolerance /= 1.0_real64 .or. &
            .not. self%model%base_salt_temporal_policy%valid() .or. &
            template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_NONE) then
          call reject_backend_trial(result, candidate, diagnostics)
          return
        end if
      else
        if (.not.parameters%macropore_active.or..not.allocated(parameters%macropore).or. &
            parameters%soil_temperature_active.or. &
            .not.ieee_is_finite(parameters%salt_temporal_tolerance_mg_cm2).or. &
            parameters%salt_temporal_tolerance_mg_cm2<=0.0_real64) then
          call reject_backend_trial(result, candidate, diagnostics)
          return
        end if
        if (.not.allocated(parameters%macropore%matrix_area_fraction)) then
          call reject_backend_trial(result,candidate,diagnostics)
          return
        end if
        if (parameters%macropore%shrinkage%enabled.or. &
            any(.not.ieee_is_finite(parameters%macropore%matrix_area_fraction)).or. &
            any(parameters%macropore%matrix_area_fraction<=0.0_real64).or. &
            any(parameters%macropore%matrix_area_fraction>1.0_real64)) then
          call reject_backend_trial(result,candidate,diagnostics)
          return
        end if
      end if
    else if (parameters%root_salinity_active) then
      call reject_backend_trial(result, candidate, diagnostics)
      return
    end if
    if (.not. fmr_solute_state_layout_known(template%solute_state_layout_id)) then
      call reject_backend_trial(result, candidate, diagnostics)
      return
    end if
    composed_rutter_black=template%optional_state_layout_id==FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BLACK
    composed_rutter_boesten_macro = &
         template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BOESTEN_MACROPORE
    self%model%rutter_active = template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_RUTTER .or. &
         composed_rutter_boesten_macro.or.composed_rutter_black
    if (self%model%rutter_active) then
      ! Preserve the independently qualified layouts; no combined Rutter/salt profile.
      if (template%solute_state_layout_id /= FMR_SOLUTE_STATE_LAYOUT_NONE) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      if(composed_rutter_black)then
        if(.not.parameters%black_evaporation_active.or..not.parameters%black_heat_composition_enabled.or. &
           .not.parameters%soil_temperature_active.or.parameters%macropore_active.or.parameters%snow_active.or. &
           parameters%boesten_evaporation_active.or.parameters%bottom_mode/=2.or. &
           template%numerical_continuation_layout_id/=FMR_NUMERICAL_CONTINUATION_NONE)then
          call reject_backend_trial(result,candidate,diagnostics);return
        end if
      else
      if (template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_NONE .or. &
          parameters%root_compensation%method /= ROOT_COMP_OFF .or. &
          parameters%snow_active .or. (parameters%soil_temperature_active.and. &
            .not.(composed_rutter_boesten_macro.and.macro_numeric_heat_valid(parameters))) .or. &
          (parameters%macropore_active .neqv. composed_rutter_boesten_macro) .or. &
          parameters%black_evaporation_active .or. &
          (parameters%boesten_evaporation_active .neqv. composed_rutter_boesten_macro) .or. &
          (parameters%drainage_response_active.and. &
           .not.(composed_rutter_boesten_macro.and.macro_numeric_heat_valid(parameters))) .or. &
          parameters%elasticity_active .or. &
          parameters%direct_retention_active .or. allocated(parameters%bartholomeus) .or. &
          (parameters%bottom_mode /= 2 .and. parameters%bottom_mode /= 7 .and. &
           .not.(composed_rutter_boesten_macro.and.parameters%bottom_mode==3.and. &
             .not.parameters%swbotb3_explicit_active)) .or. &
          .not. self%model%soil_water_selection%uses_reference()) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
    end if
    end if
    if(.not.fmr_frost_divdra_pair_valid(parameters,forcing))then
      call reject_backend_trial(result,candidate,diagnostics)
      return
    end if
    if (.not. fmr_serialized_rossfast_preflight(self, template, parameters, forcing, config, t0, t1)) then
      call reject_backend_trial(result, candidate, diagnostics)
      return
    end if
    if (self%model%fixed_weir_surface_water_active) then
      if (parameters%drainage_response_active) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      if (.not. self%model%fixed_weir_surface_water_configured .or. &
          template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_FIXED_WEIR_SURFACE_WATER .or. &
          template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_NONE .or. &
          config%transaction%temporal_mode /= TX_TEMPORAL_EXTERNAL_FULL_HALF .or. parameters%snow_active) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
    else if (template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_FIXED_WEIR_SURFACE_WATER) then
      call reject_backend_trial(result, candidate, diagnostics)
      return
    end if
    self%model%macropore_reduction_continuation_enabled = .false.
    select case (template%numerical_continuation_layout_id)
    case (FMR_NUMERICAL_CONTINUATION_NONE)
      self%model%temporal_indicator_history_enabled = .false.
    case (FMR_NUMERICAL_CONTINUATION_RICHARDS_TEMPORAL_HISTORY)
      self%model%temporal_indicator_history_enabled = .true.
    case (FMR_NUMERICAL_CONTINUATION_MACROPORE_REDUCTION)
      self%model%temporal_indicator_history_enabled = .false.
      self%model%macropore_reduction_continuation_enabled = .true.
    case default
      call reject_backend_trial(result, candidate, diagnostics)
      return
    end select
    if (.not. fmr_optional_state_layout_known(template%optional_state_layout_id)) then
      result = kernel_result_t()
      result%status = KERNEL_STATUS_NOT_ADMITTED
      candidate = kernel_candidate_state_t()
      diagnostics = kernel_diagnostics_t()
      diagnostics%admission_rejections = 1
      return
    end if
    if (template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_RFM) then
      if (.not. self%model%rfm_configuration%valid() .or. parameters%macropore_active .or. &
          template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_NONE .or. &
          .not. self%model%soil_water_selection%uses_reference()) then
        call reject_backend_trial(result,candidate,diagnostics)
        return
      end if
    end if
    if (parameters%macropore_active) then
      if ((template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_MACROPORE .and. &
           template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_MACROPORE .and. &
           template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BOESTEN_MACROPORE) .or. &
          (template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_NONE .and. &
           template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_MACROPORE_REDUCTION) .or. &
          (template%numerical_continuation_layout_id == FMR_NUMERICAL_CONTINUATION_MACROPORE_REDUCTION .and. &
           .not. self%model%macropore_policy%source_reduction_retry_enabled) .or. &
          config%transaction%temporal_mode /= TX_TEMPORAL_EXTERNAL_FULL_HALF) then
        result = kernel_result_t()
        result%status = KERNEL_STATUS_NOT_ADMITTED
        candidate = kernel_candidate_state_t()
        diagnostics = kernel_diagnostics_t()
        diagnostics%admission_rejections = 1
        return
      end if
    else if (template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_MACROPORE .or. &
             template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_MACROPORE .or. &
             template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BOESTEN_MACROPORE) then
      result = kernel_result_t()
      result%status = KERNEL_STATUS_NOT_ADMITTED
      candidate = kernel_candidate_state_t()
      diagnostics = kernel_diagnostics_t()
      diagnostics%admission_rejections = 1
      return
    end if
    if (parameters%black_evaporation_active) then
      if (parameters%boesten_evaporation_active .or. &
          (template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_BLACK_EVAPORATION.and. &
           .not.composed_rutter_black) .or. &
          parameters%snow_active .or. (parameters%soil_temperature_active.and..not.parameters%black_heat_composition_enabled) .or. &
          template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_NONE) then
        result = kernel_result_t()
        result%status = KERNEL_STATUS_NOT_ADMITTED
        candidate = kernel_candidate_state_t()
        diagnostics = kernel_diagnostics_t()
        diagnostics%admission_rejections = 1
        return
      end if
    else if (parameters%boesten_evaporation_active) then
      if ((template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_EVAPORATION .and. &
           template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_MACROPORE .and. &
           template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BOESTEN_MACROPORE) .or. &
          parameters%snow_active .or. (parameters%soil_temperature_active.and. &
          template%optional_state_layout_id/=FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_EVAPORATION.and. &
          .not.(composed_rutter_boesten_macro.and.macro_numeric_heat_valid(parameters))) .or. &
          template%numerical_continuation_layout_id /= FMR_NUMERICAL_CONTINUATION_NONE) then
        result = kernel_result_t()
        result%status = KERNEL_STATUS_NOT_ADMITTED
        candidate = kernel_candidate_state_t()
        diagnostics = kernel_diagnostics_t()
        diagnostics%admission_rejections = 1
        return
      end if
    else if (template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_BLACK_EVAPORATION .or. &
             template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_EVAPORATION .or. &
             template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_BOESTEN_MACROPORE .or. &
             template%optional_state_layout_id == FMR_OPTIONAL_STATE_LAYOUT_RUTTER_BOESTEN_MACROPORE) then
      result = kernel_result_t()
      result%status = KERNEL_STATUS_NOT_ADMITTED
      candidate = kernel_candidate_state_t()
      diagnostics = kernel_diagnostics_t()
      diagnostics%admission_rejections = 1
      return
    else if (parameters%soil_temperature_active) then
      if (template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_RESTRICTED_SOIL_TEMPERATURE .or. &
          parameters%snow_active) then
        result = kernel_result_t()
        result%status = KERNEL_STATUS_NOT_ADMITTED
        candidate = kernel_candidate_state_t()
        diagnostics = kernel_diagnostics_t()
        diagnostics%admission_rejections = 1
        return
      end if
    else if (parameters%snow_active) then
      if (template%optional_state_layout_id /= FMR_OPTIONAL_STATE_LAYOUT_SNOW) then
        result = kernel_result_t()
        result%status = KERNEL_STATUS_NOT_ADMITTED
        candidate = kernel_candidate_state_t()
        diagnostics = kernel_diagnostics_t()
        diagnostics%admission_rejections = 1
        return
      end if
    end if
    call prepare_snow_outer_event(self%model, parameters, committed, forcing, t0, t1)
    if (self%bottom_thermal_requested .and. parameters%soil_temperature_active .and. &
        self%model%state_profile_admitted .and. config%max_committed_substeps <= ishft(huge(0), -1)) then
      call self%model%bottom_thermal_carrier%initialize(2 * config%max_committed_substeps, bottom_thermal_ok)
      self%model%bottom_thermal_carrier_active = bottom_thermal_ok
      self%model%bottom_thermal_carrier_valid = bottom_thermal_ok
    end if
    if (self%top_sensible_boundary_requested .and. parameters%soil_temperature_active .and. &
        self%model%state_profile_admitted .and. config%max_committed_substeps <= ishft(huge(0), -1)) then
      call self%model%top_sensible_boundary_carrier%initialize(2 * config%max_committed_substeps, top_sensible_ok)
      self%model%top_sensible_boundary_carrier_active = top_sensible_ok
      self%model%top_sensible_boundary_carrier_valid = top_sensible_ok
    end if
    anchored_ceiling=self%model%macropore_policy%anchored_cauchy_step_ceiling
    previous_selector_cursor=t0
    if(anchored_ceiling)then
      if(.not.(composed_rutter_boesten_macro.and.macro_numeric_heat_valid(parameters).and. &
         self%model%accepted_water_flux_trace_enabled.and.allocated(forcing%legacy_swbotb3_implicit_control)))then
        call reject_backend_trial(result,candidate,diagnostics)
        return
      end if
      if(.not.allocated(forcing%rutter))then
        call reject_backend_trial(result,candidate,diagnostics)
        return
      end if
      if(.not.forcing%rutter%matrix_source_area_partition)then
        call reject_backend_trial(result,candidate,diagnostics)
        return
      end if
    end if
    trial_forcing = forcing
    trial_config = config
    self%model%weather_surface_active = allocated(forcing%weather_surface)
    if (self%model%weather_surface_active) then
      ! This composition has no smooth dynamic-top history certificate.
      ! Use the existing full/half transaction with the same requested cm budget.
      if (allocated(forcing%pond_input).or.config%accepted_trajectory_direction%requested.or. &
          template%solute_state_layout_id/=FMR_SOLUTE_STATE_LAYOUT_NONE.or. &
          parameters%bottom_mode/=7.or.parameters%elasticity_active.or.parameters%hysteresis_active.or. &
          parameters%swkmean/=1.or.parameters%ksatexm_extension_active.or.parameters%conductivity_power_tail_active.or. &
          allocated(parameters%micro_de_willigen).or.allocated(parameters%bartholomeus)) then
        call reject_backend_trial(result,candidate,diagnostics)
        return
      end if
      if (config%transaction%temporal_mode==TX_TEMPORAL_MODEL_CERTIFICATE) then
        if (.not.config%model_temporal_indicator_budget_available.or. &
            .not.ieee_is_finite(config%model_temporal_indicator_budget)) then
          call reject_backend_trial(result,candidate,diagnostics)
          return
        end if
        if (config%model_temporal_indicator_budget<=0.0_real64) then
          call reject_backend_trial(result,candidate,diagnostics)
          return
        end if
        trial_config%transaction%temporal_mode=TX_TEMPORAL_EXTERNAL_FULL_HALF
        trial_config%transaction%temporal_tolerance=config%model_temporal_indicator_budget
      end if
      allocate(trial_forcing%pond_input,source=forcing%weather_surface)
      self%model%accepted_water_flux_trace_enabled=.true.
    end if
    if (self%model%rutter_active) then
      if (.not. allocated(forcing%rutter) .or. .not. forcing%rutter%source_window%valid()) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      if(forcing%rutter%matrix_source_area_partition)then
        if(.not.(composed_rutter_boesten_macro.and.macro_numeric_heat_valid(parameters).and. &
          self%model%accepted_water_flux_trace_enabled))then
          call reject_backend_trial(result,candidate,diagnostics)
          return
        end if
      end if
      call committed%snapshot(accepted_snapshot, rutter_snapshot_available)
      if (.not. rutter_snapshot_available) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      select type (rutter_physical => accepted_snapshot)
      class is (fmr_b110_physical_state_t)
        if (.not. allocated(rutter_physical%rutter)) then
          call reject_backend_trial(result, candidate, diagnostics)
          return
        end if
        rutter_accepted_state = rutter_physical%rutter
      class default
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end select
      if(composed_rutter_black)then
        call rutter_accepted_state%capacity_candidate(forcing%rutter%process%canopy_storage_capacity_cm, &
             rutter_capacity_state,rutter_capacity_export,rutter_prepare_status)
        if(rutter_prepare_status/=RUTTER_WINDOW_OK)then
          call reject_backend_trial(result,candidate,diagnostics);return
        end if
        rutter_accepted_state=rutter_capacity_state
      end if
      if (.not. rutter_accepted_state%source_window_initialized()) then
        if (abs(t0 - forcing%rutter%source_window%start_time()) > &
            64.0_real64 * epsilon(1.0_real64) * max(1.0_real64, abs(t0))) then
          call reject_backend_trial(result, candidate, diagnostics)
          return
        end if
        call initialize_rutter_source_state(forcing%rutter%source_window, rutter_accepted_state%canopy_storage(), &
             rutter_accepted_state, rutter_prepare_status)
        if (rutter_prepare_status /= RUTTER_WINDOW_OK) then
          call reject_backend_trial(result, candidate, diagnostics)
          return
        end if
      end if
      rutter_source_origin = rutter_accepted_state%accepted_until()
      if (abs(rutter_source_origin - t0) > 64.0_real64 * epsilon(1.0_real64) * &
          max(1.0_real64, abs(t0), abs(rutter_source_origin))) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      call prepare_rutter_source_trial(forcing%rutter%source_window, rutter_accepted_state, t1, &
           forcing%rutter%process, rutter_result, rutter_trial, rutter_diagnostics, rutter_prepare_status)
      if (rutter_prepare_status /= RUTTER_WINDOW_OK .or. rutter_diagnostics%status /= RUTTER_OK .or. &
          .not. rutter_diagnostics%result_produced) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      call accept_rutter_source_trial(forcing%rutter%source_window, rutter_accepted_state, rutter_trial, &
           rutter_candidate_state, rutter_prepare_status)
      if (rutter_prepare_status /= RUTTER_WINDOW_OK) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      rutter_rain_amount = forcing%rutter%source_window%aggregate_value() * (t1 - t0) / &
           (forcing%rutter%source_window%end_time() - forcing%rutter%source_window%start_time())
      rutter_total_input = rutter_rain_amount + forcing%rutter%process%surface_irrigation_cm_per_day * (t1 - t0)
      rutter_surface_output = (rutter_result%net_rain_cm_per_day + &
           rutter_result%net_surface_irrigation_cm_per_day) * (t1 - t0)
      rutter_storage_change = rutter_candidate_state%canopy_storage() - rutter_accepted_state%canopy_storage()
      rutter_residual = rutter_total_input - rutter_surface_output - &
           rutter_result%reservoir_outflow_cm_per_day * (t1 - t0) - rutter_storage_change
      if (.not. ieee_is_finite(rutter_residual) .or. &
          abs(rutter_residual) > 1024.0_real64 * epsilon(1.0_real64) * &
          max(1.0_real64, abs(rutter_total_input), abs(rutter_surface_output), &
              abs(rutter_storage_change), abs(rutter_result%reservoir_outflow_cm_per_day * (t1 - t0)))) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      rutter_sink_total = sum(forcing%root_extraction_sink)
      if(allocated(forcing%substep_root).or.allocated(parameters%micro_de_willigen))then
        ! Plain substep uptake owns the sink. Give it the canopy-adjusted demand,
        ! without requiring a second precomputed extraction source.
        if(any(forcing%root_extraction_sink/=0.0_real64))then
          call reject_backend_trial(result,candidate,diagnostics)
          return
        end if
        if(allocated(trial_forcing%substep_root)) &
          trial_forcing%substep_root%request%potential_transpiration=rutter_result%potential_transpiration_cm_per_day
      else
      if (.not. ieee_is_finite(rutter_sink_total) .or. rutter_sink_total < 0.0_real64) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      if (rutter_sink_total <= tiny(1.0_real64)) then
        if (rutter_result%potential_transpiration_cm_per_day > tiny(1.0_real64)) then
          call reject_backend_trial(result, candidate, diagnostics)
          return
        end if
        rutter_scale = 0.0_real64
      else
        rutter_scale = rutter_result%potential_transpiration_cm_per_day / rutter_sink_total
      end if
      if (.not. ieee_is_finite(rutter_scale) .or. rutter_scale < 0.0_real64) then
        call reject_backend_trial(result, candidate, diagnostics)
        return
      end if
      trial_forcing%root_extraction_sink = forcing%root_extraction_sink * rutter_scale
      end if
      trial_forcing%root_potential_transpiration = rutter_result%potential_transpiration_cm_per_day
      if(composed_rutter_black)then
        ! Rutter cannot intercept more than the canopy-covered fraction.
        ! This lower bound therefore certifies that Black's reset repeats in
        ! every child trial, independent of canopy filling/emptying events.
        ! Pass the incumbent sustained-wetting metadata to its existing
        ! temporal policy; keep the endpoint history bound and tolerances.
        rutter_min_net_wetting=forcing%rutter%source_window%aggregate_value()/ &
             (forcing%rutter%source_window%end_time()-forcing%rutter%source_window%start_time())* &
             (1.0_real64-forcing%rutter%process%vegetation_cover_fraction)
        if(forcing%rutter%process%surface_irrigation_is_intercepted)then
          rutter_min_net_wetting=rutter_min_net_wetting+forcing%rutter%process%surface_irrigation_cm_per_day* &
               (1.0_real64-forcing%rutter%process%vegetation_cover_fraction)
        else
          rutter_min_net_wetting=rutter_min_net_wetting+forcing%rutter%process%surface_irrigation_cm_per_day
        end if
        trial_forcing%black_evaporation%wetting_reset_each_trial= &
             rutter_min_net_wetting>forcing%black_evaporation%significant_wetting_cm
        trial_forcing%black_evaporation%wetting_reset_each_trial= &
             trial_forcing%black_evaporation%wetting_reset_each_trial.or. &
             full_canopy_wetting_persists(forcing%rutter,rutter_accepted_state, &
                  forcing%black_evaporation%significant_wetting_cm)
      end if
      trial_forcing%rutter%prepared = .true.
      trial_forcing%rutter%result = rutter_result
      trial_forcing%rutter%candidate_state = rutter_candidate_state
    end if
    self%model%trusted_prepared_default_mvg = .false.
    nullify(self%model%trusted_parameter_source)
    if (present(trusted_prepared_parameters)) then
      if (trusted_prepared_parameters .and. prepared_default_mvg_structurally_compatible(parameters)) then
        self%model%trusted_prepared_default_mvg = .true.
        self%model%trusted_parameter_source => parameters
      end if
    end if
    self%model%solute_state_layout_id = template%solute_state_layout_id
    self%model%temporal_tolerance_cm = config%transaction%temporal_tolerance
    self%model%c_drain_salt_forcing = fmr_c_drain_salt_forcing_t()
    self%model%soil_salt_boundary_forcing = fmr_soil_salt_boundary_forcing_t()
    if (allocated(forcing%c_drain_salt)) self%model%c_drain_salt_forcing = forcing%c_drain_salt
    if (allocated(forcing%soil_salt_boundary)) self%model%soil_salt_boundary_forcing = forcing%soil_salt_boundary
    ! Warm numerical history is local to this immutable external interval.
    call clear_reference_trial_guess(self%model%workspace)
    if (allocated(forcing%legacy_swbotb5_control)) then
      call fmr_trial_from_checkpoint(self%kernel, parameters, committed, trial_forcing, trial_config, t0, t1, checkpoint, &
           result, candidate, diagnostics, target_selector=select_hbot5_proposal)
    else if (allocated(forcing%legacy_swbotb3_implicit_control)) then
      call fmr_trial_from_checkpoint(self%kernel, parameters, committed, trial_forcing, trial_config, t0, t1, checkpoint, &
           result, candidate, diagnostics, target_selector=select_cauchy3_proposal)
    else
      call fmr_trial_from_checkpoint(self%kernel, parameters, committed, trial_forcing, trial_config, t0, t1, checkpoint, &
           result, candidate, diagnostics)
    end if
    if (associated(self%model%constitutive)) nullify(self%model%constitutive%parameters)
    nullify(self%model%hydraulic_parameters)
    nullify(self%model%trusted_parameter_source)
    self%model%trusted_prepared_default_mvg = .false.
    if (self%model%accepted_water_flux_trace_enabled .and. result%completed) then
      call materialize_accepted_water_flux_trace(self%model,t0,t1,soil_salt_boundary_ok)
      if (.not.soil_salt_boundary_ok) call reject_backend_trial(result,candidate,diagnostics)
    end if
    ! Transaction contexts have left scope after fmr_trial_from_checkpoint.
    ! The immutable public observation now owns the accepted flat trace.
    if (allocated(self%model%trace_arena)) deallocate(self%model%trace_arena)
    self%model%trace_used=0
    if (self%model%bottom_thermal_carrier_active .and. self%model%bottom_thermal_carrier_valid .and. &
        result%completed) then
      if (candidate%ready()) then
        call self%model%bottom_thermal_carrier%materialize_candidate(t0, t1, self%bottom_thermal_candidate, &
             bottom_thermal_ok)
        if (.not. bottom_thermal_ok) call self%bottom_thermal_candidate%clear()
      end if
    end if
    if (self%model%top_sensible_boundary_carrier_active .and. self%model%top_sensible_boundary_carrier_valid .and. &
        result%completed) then
      if (candidate%ready()) then
        call self%model%top_sensible_boundary_carrier%materialize_candidate(t0, t1, &
             self%top_sensible_boundary_candidate, top_sensible_ok)
        if (.not. top_sensible_ok) call self%top_sensible_boundary_candidate%clear()
      end if
    end if
    call self%model%bottom_thermal_carrier%clear()
    self%model%bottom_thermal_carrier_active = .false.
    self%model%bottom_thermal_carrier_valid = .true.
    call self%model%top_sensible_boundary_carrier%clear()
    self%model%top_sensible_boundary_carrier_active = .false.
    self%model%top_sensible_boundary_carrier_valid = .true.
  contains
    subroutine select_hbot5_proposal(cursor, requested_t1, target_t1, max_retries_cap, valid)
      real(real64), intent(in) :: cursor, requested_t1
      real(real64), intent(out) :: target_t1
      integer, intent(out) :: max_retries_cap
      logical, intent(out) :: valid
      integer :: provider_status
      target_t1 = requested_t1
      max_retries_cap = config%transaction%max_retries
      valid = .false.
      self%model%hbot5_proposal = fmr_hbot5_proposal_t()
      if (.not. allocated(self%model%legacy_swbotb5_control)) return
      call self%model%legacy_swbotb5_control%resolve(cursor,target_t1,self%model%hbot5_proposal,provider_status)
      valid = provider_status == FMR_HBOT5_OK .and. self%model%hbot5_proposal%available
    end subroutine

    subroutine select_cauchy3_proposal(cursor, requested_t1, target_t1, max_retries_cap, valid)
      real(real64), intent(in) :: cursor, requested_t1
      real(real64), intent(out) :: target_t1
      integer, intent(out) :: max_retries_cap
      logical, intent(out) :: valid
      integer :: provider_status
      target_t1 = requested_t1
      max_retries_cap = config%transaction%max_retries
      valid = .false.
      self%model%cauchy3_proposal = fmr_cauchy3_proposal_t()
      if (.not. allocated(self%model%legacy_swbotb3_implicit_control)) return
      call self%model%legacy_swbotb3_implicit_control%resolve_proposal(cursor, target_t1, &
           self%model%cauchy3_proposal, provider_status)
      valid = provider_status == FMR_CAUCHY3_OK .and. self%model%cauchy3_proposal%available
      if(valid.and.anchored_ceiling.and.cursor>previous_selector_cursor)then
        accepted_width=cursor-previous_selector_cursor
        target_t1=min(requested_t1,cursor+2.0_real64*accepted_width)
        endpoint_margin=max(config%progress_tolerance,128.0_real64*epsilon(1.0_real64)* &
          max(1.0_real64,abs(cursor),abs(requested_t1)))
        if(requested_t1-target_t1<=endpoint_margin)target_t1=requested_t1
      end if
      previous_selector_cursor=cursor
    end subroutine
  end subroutine fmr_serialized_backend_run_trial

  subroutine reject_backend_trial(result, candidate, diagnostics)
    type(kernel_result_t), intent(out) :: result
    type(kernel_candidate_state_t), intent(out) :: candidate
    type(kernel_diagnostics_t), intent(out) :: diagnostics
    result = kernel_result_t()
    result%status = KERNEL_STATUS_NOT_ADMITTED
    candidate = kernel_candidate_state_t()
    diagnostics = kernel_diagnostics_t()
    diagnostics%admission_rejections = 1
  end subroutine reject_backend_trial

  function fmr_serialized_backend_observation(self) result(obs)
    class(fmr_serialized_reference_backend_t), intent(in) :: self
    type(fmr_serialized_physical_observation_t) :: obs
    obs = self%model%last_observation
  end function fmr_serialized_backend_observation

  logical function fmr_serialized_attempt_context_required(self) result(required)
    class(fmr_serialized_reference_model_t), intent(in) :: self

    required = allocated(self%legacy_swbotb5_control) .or. allocated(self%legacy_swbotb3_implicit_control) .or. &
         self%trajectory_direction_requested .or. self%drainage_response_active .or. &
         self%accepted_water_flux_trace_enabled .or. &
         self%bottom_thermal_carrier_active .or. .not. self%bottom_thermal_carrier_valid .or. &
         self%top_sensible_boundary_carrier_active .or. .not. self%top_sensible_boundary_carrier_valid
  end function fmr_serialized_attempt_context_required

  subroutine fmr_serialized_begin_scratch_scope(self, scope)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    type(transaction_scratch_scope_t), intent(out) :: scope

    scope%token = [-1_int64, 0_int64]
    if (.not. self%accepted_water_flux_trace_enabled) return
    scope%token = [self%trace_generation, int(self%trace_used, int64)]
  end subroutine fmr_serialized_begin_scratch_scope

  subroutine fmr_serialized_end_scratch_scope(self, scope)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    type(transaction_scratch_scope_t), intent(in) :: scope
    type(fmr_trace_arena_entry_t), allocatable :: retained(:)
    integer, allocatable :: chain(:)
    integer :: watermark, cursor, live, j, index, prefix

    if (scope%token(1) < 0_int64) return
    if (scope%token(1) /= self%trace_generation .or. scope%token(2) < 0_int64 .or. &
        scope%token(2) > int(self%trace_used, int64)) error stop 'Reference trace: invalid scratch scope'
    watermark = int(scope%token(2))
    if (watermark == self%trace_used) return
    if (.not. allocated(self%trace_arena)) error stop 'Reference trace: missing scratch arena'
    if (self%trace_used > size(self%trace_arena)) error stop 'Reference trace: invalid arena extent'
    allocate(chain(self%trace_used-watermark))
    cursor = self%trace_tail
    live = 0
    do while (cursor > watermark)
      if (cursor > self%trace_used) error stop 'Reference trace: invalid scoped tail'
      if (.not. allocated(self%trace_arena(cursor)%payload)) error stop 'Reference trace: missing scoped payload'
      if (self%trace_arena(cursor)%predecessor < 0 .or. &
          self%trace_arena(cursor)%predecessor >= cursor) error stop 'Reference trace: invalid scoped predecessor'
      live = live + 1
      chain(live) = cursor
      cursor = self%trace_arena(cursor)%predecessor
    end do
    prefix = cursor
    if (prefix < 0) error stop 'Reference trace: negative scoped prefix'
    if (live == self%trace_used-watermark) return
    allocate(retained(live))
    do j = 1, live
      index = chain(live-j+1)
      call move_alloc(self%trace_arena(index)%payload, retained(j)%payload)
      retained(j)%predecessor = watermark+j-1
      if (j == 1) retained(j)%predecessor = prefix
    end do
    ! Every pre-watermark entry stays pinned for pre-existing external, sibling
    ! and surrounding-kernel checkpoints. Only this scope's private suffix dies.
    do index = watermark+1, self%trace_used
      if (allocated(self%trace_arena(index)%payload)) deallocate(self%trace_arena(index)%payload)
      self%trace_arena(index)%predecessor = 0
    end do
    do j = 1, live
      call move_alloc(retained(j)%payload, self%trace_arena(watermark+j)%payload)
      self%trace_arena(watermark+j)%predecessor = retained(j)%predecessor
    end do
    self%trace_used = watermark+live
    if (live > 0) self%trace_tail = self%trace_used
  end subroutine fmr_serialized_end_scratch_scope

  subroutine fmr_serialized_capture_attempt_context(self, context)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    class(transaction_attempt_context_t), allocatable, intent(out) :: context

    allocate(fmr_serialized_attempt_context_t :: context)
    select type (typed => context)
    type is (fmr_serialized_attempt_context_t)
      typed%hbot5_proposal = self%hbot5_proposal
      typed%cauchy3_proposal = self%cauchy3_proposal
      typed%bottom_thermal_active = self%bottom_thermal_carrier_active
      typed%bottom_thermal_valid = self%bottom_thermal_carrier_valid
      call self%bottom_thermal_carrier%copy_to(typed%bottom_thermal_carrier)
      typed%top_sensible_boundary_active = self%top_sensible_boundary_carrier_active
      typed%top_sensible_boundary_valid = self%top_sensible_boundary_carrier_valid
      call self%top_sensible_boundary_carrier%copy_to(typed%top_sensible_boundary_carrier)
      typed%drainage_response_window_exchange_available = self%drainage_response_window_exchange_available
      typed%drainage_response_window_signed_exchange_native = self%drainage_response_window_signed_exchange_native
      typed%trajectory_direction = self%trajectory_direction
      typed%accepted_water_flux_trace_failed = self%accepted_water_flux_trace_failed
      typed%trace_generation = self%trace_generation
      typed%trace_tail = self%trace_tail
      typed%trace_count = self%trace_count
    end select
  end subroutine fmr_serialized_capture_attempt_context

  subroutine fmr_serialized_restore_attempt_context(self, context)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    class(transaction_attempt_context_t), intent(in) :: context

    select type (typed => context)
    type is (fmr_serialized_attempt_context_t)
      self%hbot5_proposal = typed%hbot5_proposal
      self%cauchy3_proposal = typed%cauchy3_proposal
      self%bottom_thermal_carrier_active = typed%bottom_thermal_active
      self%bottom_thermal_carrier_valid = typed%bottom_thermal_valid
      call self%bottom_thermal_carrier%restore_from(typed%bottom_thermal_carrier)
      self%top_sensible_boundary_carrier_active = typed%top_sensible_boundary_active
      self%top_sensible_boundary_carrier_valid = typed%top_sensible_boundary_valid
      call self%top_sensible_boundary_carrier%restore_from(typed%top_sensible_boundary_carrier)
      self%drainage_response_window_exchange_available = typed%drainage_response_window_exchange_available
      self%drainage_response_window_signed_exchange_native = typed%drainage_response_window_signed_exchange_native
      self%trajectory_direction = typed%trajectory_direction
      self%accepted_water_flux_trace_failed = typed%accepted_water_flux_trace_failed
      if (typed%trace_generation /= self%trace_generation .or. &
          typed%trace_tail < 0 .or. typed%trace_tail > self%trace_used .or. &
          typed%trace_count < 0 .or. typed%trace_count > self%trace_used) &
           error stop 'Reference trace: stale or invalid attempt context'
      self%trace_tail = typed%trace_tail
      self%trace_count = typed%trace_count
    class default
      self%hbot5_proposal = fmr_hbot5_proposal_t()
      self%cauchy3_proposal = fmr_cauchy3_proposal_t()
      self%bottom_thermal_carrier_active = .false.
      self%bottom_thermal_carrier_valid = .false.
      call self%bottom_thermal_carrier%clear()
      self%top_sensible_boundary_carrier_active = .false.
      self%top_sensible_boundary_carrier_valid = .false.
      call self%top_sensible_boundary_carrier%clear()
      self%drainage_response_window_exchange_available = .false.
      self%drainage_response_window_signed_exchange_native = 0.0_real64
      self%accepted_water_flux_trace_failed = .true.
      self%trace_tail=0
      self%trace_count=0
      call configure_trajectory_direction(self%trajectory_direction, .false.)
    end select
  end subroutine fmr_serialized_restore_attempt_context

  logical function fmr_serialized_execution_admitted(self, parameters, numerical_config)
    class(fmr_serialized_reference_model_t), intent(in) :: self
    class(kernel_parameters_t), intent(in) :: parameters
    type(canonical_numerical_config_t), intent(in) :: numerical_config
    logical :: ok
    integer :: oxygen_route,waterfilm_mode
    ok = associated(self%top_boundary) .and. numerical_config%max_committed_substeps > 0 .and. &
         self%state_profile_admitted
    if (self%fixed_weir_surface_water_active) then
      ok = ok .and. self%fixed_weir_surface_water_configured .and. .not. self%temporal_indicator_history_enabled .and. &
           numerical_config%transaction%temporal_mode == TX_TEMPORAL_EXTERNAL_FULL_HALF
    end if
    select type (parameters)
    type is (fmr_b110_physical_parameters_t)
      ok = ok .and. parameters%parameter_set_id > 0_int64 .and. parameters%active_nodes > 0 .and. &
           allocated(parameters%z) .and. allocated(parameters%dz) .and. allocated(parameters%node_distance) .and. &
           allocated(parameters%cofgen)
      if(parameters%reactive_solute_active)then
        ok=ok.and.self%accepted_water_flux_trace_enabled.and.parameters%soil_temperature_active.and. &
          .not.parameters%macropore_active.and..not.parameters%snow_active.and..not.parameters%frost_active.and. &
          self%solute_state_layout_id==FMR_SOLUTE_STATE_LAYOUT_NONE.and..not.parameters%root_salinity_active
      else
        ok=ok.and..not.parameters%reactive_salinity_active
      end if
      if (parameters%picard_conductivity_iteration) then
        ! Bounded numerical successor; no implied admission of other physics.
        ok = ok .and. self%soil_water_selection%uses_reference() .and. &
             parameters%swkimpl == 0 .and. parameters%swkmean == 1 .and. parameters%swsophy == 0 .and. &
             (parameters%bottom_mode == 2 .or. &
              (parameters%bottom_mode == 3.and..not.parameters%swbotb3_explicit_active)) .and. &
             parameters%max_iterations == 64 .and. &
             numerical_config%transaction%temporal_mode == TX_TEMPORAL_EXTERNAL_FULL_HALF .and. &
             .not. numerical_config%accepted_trajectory_direction%requested .and. &
             .not. numerical_config%retain_accepted_step_proposal .and. &
             .not. self%temporal_indicator_history_enabled .and. .not. self%fixed_weir_surface_water_active .and. &
             .not. self%rutter_active .and. .not. self%rfm_configuration%enabled .and. &
             .not. self%bottom_thermal_carrier_active .and. .not. self%top_sensible_boundary_carrier_active .and. &
             .not. allocated(parameters%hydraulic_model_kind) .and. .not. allocated(parameters%linear_hydraulic_table) .and. &
             .not. parameters%tabulated_hydraulics_active .and. .not. parameters%direct_retention_active .and. &
             .not. parameters%ksatexm_extension_active .and. .not. parameters%conductivity_power_tail_active .and. &
             .not. parameters%extended_model6_active .and. .not. parameters%pdi_vapor_active .and. &
             .not. parameters%elasticity_active .and. .not. parameters%hysteresis_active .and. &
             .not. parameters%macropore_active .and. .not. parameters%snow_active .and. &
             (.not.parameters%soil_temperature_active.or.self%accepted_water_flux_trace_enabled) .and. &
             .not. parameters%frost_active .and. &
             (.not.parameters%drainage_response_active.or. &
              (self%accepted_water_flux_trace_enabled.and.joint_drainage_trace_valid(parameters))) .and. &
             .not. parameters%black_evaporation_active .and. &
             .not. parameters%practical_richards_a2c_active .and. &
             .not. parameters%root_salinity_active .and. .not. parameters%root_frost%active .and. &
             .not. allocated(parameters%bartholomeus) .and. .not. allocated(parameters%micro_de_willigen) .and. &
             parameters%root_compensation%method == ROOT_COMP_OFF
      end if
      if (parameters%prepared_default_mvg%continuous_saturation_conductivity) then
        ! A prepared continuous curve has an explicit bounded owner. Weather
        ! uses its own private selection; native bottom2 selects Picard only.
        ok = ok .and. parameters%prepared_default_mvg_available .and. &
             prepared_default_mvg_compatible(parameters) .and. parameters%picard_conductivity_iteration
      end if
      if (ok) ok = size(parameters%z) == parameters%active_nodes .and. &
           size(parameters%dz) == parameters%active_nodes .and. &
           size(parameters%node_distance) == parameters%active_nodes .and. &
           size(parameters%cofgen,1) >= 24 .and. size(parameters%cofgen,2) == parameters%active_nodes
      if (allocated(parameters%hydraulic_model_kind)) then
        ok = ok .and. size(parameters%hydraulic_model_kind) == parameters%active_nodes .and. &
             all(parameters%hydraulic_model_kind == B111_HYD_EXPONENTIAL .or. &
                 parameters%hydraulic_model_kind == B111_HYD_BIMODAL_MVG .or. &
                 parameters%hydraulic_model_kind == B111_HYD_BIMODAL_MVG_WCK .or. &
                 (parameters%hydraulic_model_kind >= 5 .and. parameters%hydraulic_model_kind <= 11)) .and. &
             self%soil_water_selection%uses_reference() .and. parameters%swkimpl == 0 .and. &
             .not. parameters%direct_retention_active .and. .not. parameters%ksatexm_extension_active .and. &
             .not. parameters%conductivity_power_tail_active .and. .not. parameters%elasticity_active .and. &
             .not. parameters%hysteresis_active .and. .not. parameters%tabulated_hydraulics_active .and. &
             .not. parameters%frost_active .and. .not. parameters%macropore_active .and. &
             .not. parameters%root_extraction_active .and. .not. parameters%drainage_response_active .and. &
             .not. parameters%black_evaporation_active .and. .not. parameters%boesten_evaporation_active .and. &
             (parameters%soil_temperature_active .eqv. parameters%pdi_vapor_active) .and. &
             .not. parameters%snow_active .and. &
             .not. self%rfm_configuration%enabled .and. .not. self%fixed_weir_surface_water_active
      end if
      if (parameters%conductivity_power_tail_active) then
        ! HYD-POWER is admitted first as a narrow default-MvG / Reference-Richards
        ! constitutive extension. Broader optional-physics compositions require
        ! separate evidence and therefore fail closed here.
        ok = ok .and. .not. allocated(parameters%hydraulic_model_kind) .and. &
             self%soil_water_selection%uses_reference() .and. parameters%swkimpl == 0 .and. &
             .not. parameters%direct_retention_active .and. .not. parameters%ksatexm_extension_active .and. &
             .not. parameters%elasticity_active .and. .not. parameters%hysteresis_active .and. &
             .not. parameters%tabulated_hydraulics_active .and. .not. parameters%frost_active .and. &
             .not. parameters%macropore_active .and. .not. parameters%root_extraction_active .and. &
             .not. parameters%drainage_response_active .and. .not. parameters%black_evaporation_active .and. &
             .not. parameters%boesten_evaporation_active .and. .not. parameters%soil_temperature_active .and. &
             .not. parameters%snow_active .and. .not. self%rfm_configuration%enabled .and. &
             .not. self%fixed_weir_surface_water_active .and. &
             all(ieee_is_finite(parameters%cofgen(22:23,:))) .and. &
             all(parameters%cofgen(22,:) < 0.0_real64) .and. &
             all(parameters%cofgen(22,:) <= parameters%cofgen(9,:)) .and. &
             all(parameters%cofgen(23,:) > 0.0_real64)
      end if
      if (allocated(parameters%linear_hydraulic_table)) then
        ok = ok .and. parameters%tabulated_hydraulics_active .and. &
             .not. allocated(parameters%hydraulic_model_kind) .and. &
             .not. parameters%conductivity_power_tail_active .and. .not. parameters%pdi_vapor_active .and. &
             .not. parameters%hysteresis_active .and. .not. parameters%soil_temperature_active .and. &
             .not. parameters%direct_retention_active .and. .not. parameters%ksatexm_extension_active .and. &
             .not. parameters%elasticity_active .and. .not. parameters%frost_active .and. &
             .not. parameters%macropore_active .and. .not. parameters%snow_active .and. &
             .not. parameters%root_extraction_active .and. .not. parameters%drainage_response_active .and. &
             self%soil_water_selection%uses_reference() .and. parameters%swkimpl == 0
      else
        ok = ok .and. .not. parameters%tabulated_hydraulics_active
      end if
      if (parameters%macropore_active) then
        ! Admission precedes configure_parameters(). Validate the immutable
        ! production config from the parameter carrier here; configure_parameters
        ! materializes the model-owned copy only after this gate succeeds.
        ok = ok .and. allocated(parameters%macropore) .and. self%macropore_policy_configured .and. &
             self%macropore_policy%valid() .and. self%macropore_policy%enabled .and. &
             self%soil_water_selection%uses_reference() .and. &
             .not. parameters%snow_active .and. &
             (.not.parameters%soil_temperature_active.or. &
               (self%rutter_active.and.macro_numeric_heat_valid(parameters))) .and. &
             .not. parameters%black_evaporation_active .and. &
             (.not.parameters%drainage_response_active.or. &
               (self%rutter_active.and.macro_numeric_heat_valid(parameters).and.self%accepted_water_flux_trace_enabled)) .and. &
             .not. self%fixed_weir_surface_water_active .and. &
             parameters%macropore%valid_for_nodes(parameters%active_nodes)
      else
        ok = ok .and. .not. allocated(parameters%macropore)
      end if
      ok = ok .and. (parameters%bottom_mode == 7 .or. parameters%bottom_mode == -2 .or. parameters%bottom_mode == 5 .or. &
           parameters%bottom_mode == 2 .or. parameters%bottom_mode == 3 .or. parameters%bottom_mode == 8 .or. &
           (parameters%bottom_mode==1.and.parameters%prescribed_groundwater_active)) .and. &
           parameters%swkimpl == 0 .and. parameters%swsophy == 0 .and. &
           (.not. parameters%tabulated_hydraulics_active .or. allocated(parameters%linear_hydraulic_table))
      if(parameters%prescribed_groundwater_active)then
        ! Fixed-geometry source-table water. Existing process owners retain
        ! their own checks below, including required accepted trace composition.
        ok=ok.and.parameters%bottom_mode==1.and.self%soil_water_selection%uses_reference().and. &
          parameters%swkmean==1.and..not.parameters%macropore_active.and..not.parameters%snow_active.and. &
          .not.parameters%frost_active.and..not.parameters%black_evaporation_active.and. &
          .not.parameters%hysteresis_active.and..not.parameters%elasticity_active.and. &
          .not.parameters%weather_trial_warm_start.and..not.parameters%picard_conductivity_iteration
      end if
      if (parameters%hysteresis_active) then
        ok = ok .and. parameters%bottom_mode == 2 .and. &
             allocated(parameters%hysteresis_parameters) .and. &
             (parameters%hysteresis_initial_mode == 1 .or. parameters%hysteresis_initial_mode == 2) .and. &
             .not. allocated(parameters%hydraulic_model_kind) .and. &
             .not. parameters%tabulated_hydraulics_active .and. &
             .not. parameters%conductivity_power_tail_active .and. &
             .not. parameters%pdi_vapor_active .and. &
             .not. parameters%soil_temperature_active .and. &
             .not. parameters%frost_active .and. .not. parameters%macropore_active .and. &
             .not. parameters%root_extraction_active .and. .not. parameters%drainage_response_active
        if (ok) ok = parameters%hysteresis_parameters%active_nodes == parameters%active_nodes
      else
        ok = ok .and. .not. allocated(parameters%hysteresis_parameters)
      end if
       if (parameters%bottom_mode == 3) then
         if (parameters%swbotb3_explicit_active) then
           ok = ok .and. ieee_is_finite(parameters%swbotb3_explicit_hdrain_cm) .and. &
                ieee_is_finite(parameters%swbotb3_explicit_shape_3) .and. &
                parameters%swbotb3_explicit_shape_3 >= 0.0_real64 .and. &
                parameters%swbotb3_explicit_shape_3 <= 1.0_real64 .and. parameters%prepared_default_mvg_available
         end if
         ! Admission precedes configure_parameters()/prepare_interval(). The
         ! immutable forcing-owned Cauchy control is therefore validated in
         ! prepare_interval, not through stale model-local state here.
         ok = ok .and. self%soil_water_selection%uses_reference()
       end if
       if (parameters%elasticity_active) then
         ok = ok .and. self%soil_water_selection%uses_reference() .and. &
              .not. parameters%ksatexm_extension_active .and. .not. parameters%direct_retention_active .and. &
              parameters%prepared_default_mvg_available .and. &
              parameters%prepared_default_mvg%elastic_storage_active .and. &
              allocated(parameters%prepared_default_mvg%specific_elastic_storage)
         if (ok) ok = size(parameters%prepared_default_mvg%specific_elastic_storage) == parameters%active_nodes
         if (ok) ok = all(ieee_is_finite(parameters%prepared_default_mvg%specific_elastic_storage))
         if (ok) ok = all(parameters%prepared_default_mvg%specific_elastic_storage >= 0.0_real64)
       end if
      if (parameters%direct_retention_active) then
        ok = ok .and. self%soil_water_selection%uses_reference() .and. &
             parameters%bottom_mode == 5 .and. parameters%swkimpl == 0 .and. &
             .not. parameters%ksatexm_extension_active .and. parameters%prepared_default_mvg_available .and. &
             parameters%prepared_direct_retention_slot > 0
      end if
      if (parameters%snow_active) then
        ok = ok .and. allocated(parameters%snow) .and. self%snow_event_prepared .and. &
             .not. self%fixed_weir_surface_water_active
      else
        ok = ok .and. .not. allocated(parameters%snow) .and. .not. self%snow_event_prepared
      end if
      if (parameters%soil_temperature_active) then
        ok = ok .and. .not. parameters%snow_active .and. self%soil_temperature_active .and. &
             allocated(parameters%soil_temperature)
        if (ok) ok = parameters%soil_temperature%ready() .and. &
             parameters%soil_temperature%node_count() == parameters%active_nodes
      else
        ok = ok .and. .not. allocated(parameters%soil_temperature) .and. .not. self%soil_temperature_active
      end if
      if (parameters%frost_active) then
        ok = ok .and. parameters%frost_hydraulic%valid() .and. parameters%frost_hydraulic%active .and. &
             parameters%soil_temperature_active .and. self%soil_temperature_active .and. &
             self%soil_water_selection%uses_reference() .and. .not. parameters%snow_active .and. &
             parameters%bottom_mode == 2 .and. &
             (.not. parameters%root_extraction_active .or. parameters%root_frost%active) .and. &
             .not. parameters%macropore_active .and. &
             (.not.parameters%drainage_response_active.or.parameters%frost_response_drainage_active).and. &
             .not. parameters%black_evaporation_active .and. .not. parameters%boesten_evaporation_active .and. &
             .not. self%rfm_configuration%enabled .and. .not. self%fixed_weir_surface_water_active .and. &
             .not. self%bottom_thermal_carrier_active .and. .not. self%top_sensible_boundary_carrier_active .and. &
             .not. self%trajectory_direction_requested .and. .not. self%temporal_indicator_history_enabled
      else
        ok = ok .and. .not. parameters%frost_hydraulic%active
      end if
      ok=ok.and.fmr_frost_response_drainage_configuration_valid(parameters)
      ok=ok.and.fmr_frost_divdra_configuration_valid(parameters)
      if(parameters%frost_low_air_drainage%active)then
        ok=ok.and.parameters%frost_low_air_drainage%valid().and.parameters%frost_drainage%active
      end if
      if(parameters%frost_drainage%active)then
        ok=ok.and.parameters%frost_drainage%valid().and.parameters%frost_active.and. &
             numerical_config%transaction%temporal_mode==TX_TEMPORAL_EXTERNAL_FULL_HALF.and. &
             .not.parameters%frost_bottom%active.and..not.parameters%root_extraction_active.and. &
             .not.parameters%root_frost%active.and..not.parameters%root_salinity_active.and. &
             (.not.parameters%drainage_response_active.or.parameters%frost_response_drainage_active).and. &
             .not.self%base_salt_temporal_policy%enabled.and. &
             .not.parameters%elasticity_active.and..not.parameters%direct_retention_active.and. &
             .not.allocated(parameters%bartholomeus)
      end if
      if(parameters%frost_bottom%active) then
        ok=ok.and.parameters%frost_bottom%valid().and.parameters%frost_active.and. &
             (.not.parameters%root_extraction_active.or.parameters%root_frost%active).and. &
             .not.parameters%root_salinity_active.and..not.self%base_salt_temporal_policy%enabled.and. &
             .not.parameters%elasticity_active.and..not.parameters%direct_retention_active.and. &
             .not.allocated(parameters%bartholomeus)
      end if
      if(parameters%root_frost%active) then
        ok=ok.and.parameters%frost_active.and.parameters%root_extraction_active.and. &
             parameters%root_frost%rooted_nodes>=0.and.parameters%root_frost%rooted_nodes<=parameters%active_nodes
        ok=ok.and.ieee_is_finite(parameters%root_frost_head_budget_cm).and. &
             ieee_is_finite(parameters%root_frost_temperature_budget_c).and. &
             parameters%root_frost_head_budget_cm>0.0_real64.and.parameters%root_frost_temperature_budget_c>0.0_real64
        if(parameters%root_salinity_active) then
          ok=ok.and.self%base_salt_temporal_policy%enabled.and. &
               self%solute_state_layout_id==FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED.and. &
               .not.parameters%frost_bottom%active.and..not.parameters%frost_drainage%active.and..not.parameters%macropore_active
        else
          ok=ok.and..not.self%base_salt_temporal_policy%enabled
        end if
        ! Actual negative-temperature Bartholomeus composition is separate scope.
        ok=ok.and..not.allocated(parameters%bartholomeus)
      end if
      if (parameters%black_evaporation_active) then
        ok = ok .and. .not. parameters%boesten_evaporation_active .and. self%black_evaporation_active .and. &
             .not. self%boesten_evaporation_active .and. allocated(parameters%black_evaporation) .and. &
             .not. allocated(parameters%boesten_evaporation) .and. self%soil_water_selection%uses_reference() .and. &
             .not. parameters%snow_active .and. &
             (.not.parameters%soil_temperature_active.or.parameters%black_heat_composition_enabled) .and. &
             .not. self%fixed_weir_surface_water_active .and. &
             (.not.parameters%drainage_response_active.or.parameters%black_heat_composition_enabled) .and. &
             (.not.parameters%root_extraction_active.or.parameters%black_heat_composition_enabled) .and. parameters%bottom_mode /= 5
        if(parameters%black_heat_composition_enabled)then
          ok=ok.and.parameters%soil_temperature_active.and.allocated(parameters%soil_temperature).and. &
            .not.parameters%macropore_active.and.parameters%bottom_mode==2.and.self%accepted_water_flux_trace_enabled
          if(ok)ok=parameters%soil_temperature%solution_mode==SOIL_TEMP_SOLUTION_NUMERIC
        end if
        if (ok) ok = ieee_is_finite(parameters%black_evaporation%cofred) .and. &
             parameters%black_evaporation%cofred >= 0.0_real64
      else if (parameters%boesten_evaporation_active) then
        ok = ok .and. .not. self%black_evaporation_active .and. self%boesten_evaporation_active .and. &
             .not. allocated(parameters%black_evaporation) .and. allocated(parameters%boesten_evaporation) .and. &
             self%soil_water_selection%uses_reference() .and. .not. parameters%snow_active .and. &
             (.not.parameters%soil_temperature_active.or.self%accepted_water_flux_trace_enabled.or. &
               (self%rutter_active.and.macro_numeric_heat_valid(parameters))) .and. &
             .not. self%fixed_weir_surface_water_active .and. &
             (.not.parameters%drainage_response_active.or. &
              (self%accepted_water_flux_trace_enabled.and.joint_drainage_trace_valid(parameters))) .and. &
             parameters%bottom_mode /= 5
        if (ok) ok = ieee_is_finite(parameters%boesten_evaporation%cofred) .and. &
             parameters%boesten_evaporation%cofred > 0.0_real64 .and. parameters%boesten_evaporation%cofred <= 1.0_real64
        if(parameters%root_extraction_active)then
          ! New plain joint trace route only. Preserve the older water-only
          ! exclusion and do not implicitly qualify compensation/oxygen variants.
          ok=ok.and.self%accepted_water_flux_trace_enabled.and. &
            parameters%root_compensation%method==ROOT_COMP_OFF.and. &
            .not.parameters%root_salinity_active.and..not.parameters%root_frost%active.and. &
            (.not.allocated(parameters%bartholomeus).or.groundwater_oxygen_trace_scope(parameters)).and. &
            .not.allocated(parameters%micro_de_willigen)
        end if
      else
        ok = ok .and. .not. allocated(parameters%black_evaporation) .and. .not. self%black_evaporation_active .and. &
             .not. allocated(parameters%boesten_evaporation) .and. .not. self%boesten_evaporation_active
      end if
      if (parameters%drainage_response_active) then
        ok = ok .and. allocated(parameters%drainage_response_levels) .and. &
             .not. self%fixed_weir_surface_water_active
        if (ok) ok = size(parameters%drainage_response_levels) > 0
      else
        ok = ok .and. .not. allocated(parameters%drainage_response_levels) .and. &
             .not. parameters%drainage_qbot_smooth_freatic_projection
      end if
      if (parameters%drainage_qbot_smooth_freatic_projection) then
        ok = ok .and. parameters%drainage_response_active .and. parameters%bottom_mode == 2 .and. &
             (.not.parameters%root_extraction_active.or. &
              (self%accepted_water_flux_trace_enabled.and.joint_drainage_trace_valid(parameters))) .and. &
             .not. parameters%macropore_active
      end if
      if(allocated(parameters%drainage_trial_distribution)) &
        ok=ok.and.self%accepted_water_flux_trace_enabled.and.joint_drainage_trace_valid(parameters)
      if(allocated(parameters%mobile_dispersion))then
        ok=ok.and.fmr_mobile_dispersion_matches_hydraulic_owner(parameters).and..not.parameters%macropore_active
      end if
      if (parameters%root_salinity_active) then
        ! Ordered validation: Fortran may evaluate comparisons even when a
        ! preceding finite predicate is false. Reject before comparing NaNs.
        if(.not.all(ieee_is_finite([parameters%solute_tscf,parameters%saltmax_mg_cm3,parameters%saltslope_cm3_mg])))then
          ok=.false.
          return
        end if
        ok = ok .and. parameters%root_extraction_active .and. &
             (parameters%root_compensation%method == ROOT_COMP_JARVIS .or. &
              parameters%root_compensation%method == ROOT_COMP_WALSUM) .and. &
             ieee_is_finite(parameters%solute_tscf) .and. parameters%solute_tscf >= 0.0_real64 .and. &
             parameters%solute_tscf <= 10.0_real64 .and. ieee_is_finite(parameters%saltmax_mg_cm3) .and. &
             parameters%saltmax_mg_cm3 >= 0.0_real64 .and. parameters%saltmax_mg_cm3 <= 100.0_real64 .and. &
             ieee_is_finite(parameters%saltslope_cm3_mg) .and. parameters%saltslope_cm3_mg >= 0.0_real64 .and. &
             parameters%saltslope_cm3_mg <= 1.0_real64
      end if
      if(allocated(parameters%bartholomeus)) then
        ok=ok .and. valid_fmr_bartholomeus_parameters(parameters%bartholomeus,parameters%active_nodes)
        call select_fmr_bartholomeus_route(parameters%bartholomeus%selection,oxygen_route,waterfilm_mode)
        if(oxygen_route==FMR_BARTHOLOMEUS_ACTIVE) then
          ok=ok .and. parameters%root_extraction_active .and. parameters%soil_temperature_active .and. &
               self%soil_water_selection%uses_reference() .and. &
               (parameters%bottom_mode==2 .or. parameters%bottom_mode==7.or. &
                (groundwater_oxygen_trace_scope(parameters).and.self%accepted_water_flux_trace_enabled)) .and. &
               .not.parameters%direct_retention_active .and. .not.parameters%elasticity_active .and. &
               .not.parameters%macropore_active .and. .not.parameters%snow_active .and. &
               (.not.parameters%drainage_response_active.or. &
                ((groundwater_oxygen_trace_scope(parameters).or.parameters%reactive_solute_active).and. &
                 self%accepted_water_flux_trace_enabled.and.joint_drainage_trace_valid(parameters))).and..not.self%fixed_weir_surface_water_active
          ok=ok .and. parameters%bartholomeus%soil%initial_hysteresis_branch==0
          ok=ok .and. matches_bartholomeus_hydraulic_owner(parameters%bartholomeus,parameters%cofgen,parameters%dz)
        end if
      end if
      if (allocated(parameters%micro_de_willigen)) then
        if(parameters%reactive_solute_active)then
          ok=ok.and.parameters%root_extraction_active.and.self%soil_water_selection%uses_reference().and. &
            numerical_config%transaction%temporal_mode==TX_TEMPORAL_EXTERNAL_FULL_HALF.and. &
            self%accepted_water_flux_trace_enabled.and..not.self%temporal_indicator_history_enabled.and. &
            parameters%root_compensation%method==ROOT_COMP_OFF.and..not.parameters%root_frost%active.and. &
            .not.parameters%macropore_active.and..not.parameters%snow_active.and..not.parameters%frost_active
          ok=ok.and.parameters%micro_maximum_drought>=0.and.parameters%micro_maximum_drought<=1.and. &
            parameters%micro_combined_stress_mode>=1.and.parameters%micro_combined_stress_mode<=2
        else
        ok = ok .and. parameters%root_extraction_active .and. &
             self%soil_water_selection%uses_reference() .and. &
             numerical_config%transaction%temporal_mode == TX_TEMPORAL_MODEL_CERTIFICATE .and. &
             self%temporal_indicator_history_enabled .and. &
             (parameters%bottom_mode == 2 .or. parameters%bottom_mode == 7) .and. &
             parameters%root_compensation%method == ROOT_COMP_OFF .and. &
             parameters%micro_de_willigen%oxygen_mode == 0 .and. &
             .not. parameters%root_salinity_active .and. .not. parameters%root_frost%active .and. &
             .not. allocated(parameters%bartholomeus) .and. .not. self%rutter_active .and. &
             .not. parameters%macropore_active .and. .not. parameters%snow_active .and. &
             .not. parameters%frost_active .and. .not. parameters%soil_temperature_active .and. &
             .not. parameters%elasticity_active .and. .not. parameters%direct_retention_active .and. &
             .not. parameters%ksatexm_extension_active .and. .not. parameters%hysteresis_active .and. &
             .not. parameters%tabulated_hydraulics_active .and. .not. parameters%drainage_response_active .and. &
             .not. self%fixed_weir_surface_water_active
        end if
        if (allocated(parameters%micro_horizon_first_node)) then
          ok = ok .and. fmr_micro_horizon_map_valid(parameters%micro_horizon_first_node,parameters%active_nodes)
        end if
      else
        ok = ok .and. .not. allocated(parameters%micro_horizon_first_node)
      end if
    class default
      ok = .false.
    end select
    fmr_serialized_execution_admitted = ok
  end function fmr_serialized_execution_admitted

  logical function fmr_serialized_matches_committed_identity(self,identity,state) result(ok)
    class(fmr_serialized_reference_model_t), intent(in) :: self
    type(kernel_parameter_identity_t), intent(in) :: identity
    class(transaction_state_t), intent(in) :: state
    ok=fmr_b110_certified_candidate_layout_matches(identity,state)
  end function

  logical function fmr_b110_certified_candidate_layout_matches(identity,state) result(ok)
    type(kernel_parameter_identity_t), intent(in) :: identity
    class(transaction_state_t), intent(in) :: state
    ok=.false.
    if(.not.identity%valid.or.identity%active_nodes<=0.or.identity%parameter_set_id<=0_int64) return
    if(.not.allocated(identity%z).or..not.allocated(identity%dz)) return
    if(size(identity%z)/=identity%active_nodes.or.size(identity%dz)/=identity%active_nodes) return
    select type(state)
    class is(fmr_b110_physical_state_t)
      if(state%active_nodes/=identity%active_nodes) return
      if(.not.allocated(state%pressure_head).or..not.allocated(state%water_content)) return
      if(size(state%pressure_head)/=identity%active_nodes.or. &
           size(state%water_content)/=identity%active_nodes) return
      if(allocated(state%soil_temperature).neqv.identity%heat_enabled) return
      if(.not.all(ieee_is_finite(state%pressure_head))) return
      if(.not.all(ieee_is_finite(state%water_content))) return
      if(identity%heat_enabled) then
        block
          type(soil_temperature_field_view_t) :: field
          integer :: field_status
          call build_soil_temperature_field_view(state%soil_temperature,field,field_status)
          if(field_status/=SOIL_TEMP_OK) return
          if(field%active_nodes/=identity%active_nodes) return
          if(.not.all(ieee_is_finite(field%temperature_c))) return
        end block
      end if
      ok=.true.
    class default
      return
    end select
  end function

  subroutine fmr_serialized_configure_parameters(self, parameters)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    class(kernel_parameters_t), intent(in) :: parameters
    integer :: n
    logical :: micro_tables_ok
    select type (parameters)
    type is (fmr_b110_physical_parameters_t)
      n = parameters%active_nodes
      if (.not. associated(self%soil_parameters)) allocate(self%soil_parameters)
      if (.not. associated(self%owned_hydraulic_parameters)) allocate(self%owned_hydraulic_parameters)
      nullify(self%hydraulic_parameters)
      if (.not. associated(self%analytical_hydraulic_parameters)) allocate(self%analytical_hydraulic_parameters)
      if (.not. associated(self%constitutive)) allocate(self%constitutive)
      if (.not. associated(self%analytical_constitutive)) allocate(self%analytical_constitutive)
      if (.not. associated(self%extended_legacy)) allocate(self%extended_legacy)
      if (.not. associated(self%extended_parameters)) allocate(self%extended_parameters)
      if (.not. associated(self%extended_constitutive)) allocate(self%extended_constitutive)
      if (.not. associated(self%linear_table_constitutive)) allocate(self%linear_table_constitutive)
      if (.not. associated(self%direct_retention_constitutive)) allocate(self%direct_retention_constitutive)
      if (.not. associated(self%source_sink)) allocate(self%source_sink)
      if (.not. associated(self%root_sink)) allocate(self%root_sink)

      self%soil_parameters%parameter_set_id = parameters%parameter_set_id
      self%soil_parameters%active_nodes = n
      if (allocated(self%soil_parameters%z)) then
        if (size(self%soil_parameters%z) /= n) deallocate(self%soil_parameters%z)
      end if
      if (allocated(self%soil_parameters%dz)) then
        if (size(self%soil_parameters%dz) /= n) deallocate(self%soil_parameters%dz)
      end if
      if (allocated(self%soil_parameters%node_distance)) then
        if (size(self%soil_parameters%node_distance) /= n) deallocate(self%soil_parameters%node_distance)
      end if
      if (.not. allocated(self%soil_parameters%z)) allocate(self%soil_parameters%z(n))
      if (.not. allocated(self%soil_parameters%dz)) allocate(self%soil_parameters%dz(n))
      if (.not. allocated(self%soil_parameters%node_distance)) allocate(self%soil_parameters%node_distance(n))
      self%soil_parameters%z = parameters%z
      self%soil_parameters%dz = parameters%dz
      self%soil_parameters%node_distance = parameters%node_distance
      if (.not.self%weather_surface_active.and.self%trusted_prepared_default_mvg .and. associated(self%trusted_parameter_source) .and. &
          prepared_default_mvg_structurally_compatible(parameters)) then
        self%hydraulic_parameters => self%trusted_parameter_source%prepared_default_mvg
      else
        if (prepared_default_mvg_compatible(parameters)) then
          self%owned_hydraulic_parameters = parameters%prepared_default_mvg
        else
          if (parameters%elasticity_active) then
            call initialize_b110_default_mvg_parameters(self%owned_hydraulic_parameters, parameters%cofgen, &
                 enable_ksatexm_extension=parameters%ksatexm_extension_active, &
                 enable_elastic_storage=.true., specific_elastic_storage_input=parameters%cofgen(24,:), &
                 enable_conductivity_power_tail=parameters%conductivity_power_tail_active)
          else
            call initialize_b110_default_mvg_parameters(self%owned_hydraulic_parameters, parameters%cofgen, &
                 enable_ksatexm_extension=parameters%ksatexm_extension_active, &
                 enable_conductivity_power_tail=parameters%conductivity_power_tail_active)
          end if
        end if
        self%owned_hydraulic_parameters%continuous_saturation_conductivity=self%weather_surface_active
        if (parameters%prepared_default_mvg_available) &
          self%owned_hydraulic_parameters%continuous_saturation_conductivity = &
            self%owned_hydraulic_parameters%continuous_saturation_conductivity.or. &
            parameters%prepared_default_mvg%continuous_saturation_conductivity
        self%hydraulic_parameters => self%owned_hydraulic_parameters
      end if
      self%hysteresis_active = parameters%hysteresis_active
      if (allocated(self%hysteresis_parameters)) deallocate(self%hysteresis_parameters)
      if (self%hysteresis_active) then
        if (.not. allocated(parameters%hysteresis_parameters)) error stop 'hysteresis requires parameters'
        self%hysteresis_parameters = parameters%hysteresis_parameters
      end if
      self%extended_pdi_vapor_active = parameters%pdi_vapor_active
      self%extended_hydraulics_active = .false.
      if (allocated(parameters%hydraulic_model_kind)) &
        self%extended_hydraulics_active = any(parameters%hydraulic_model_kind == 5 .or. &
             (parameters%hydraulic_model_kind >= 7 .and. parameters%hydraulic_model_kind <= 11) .or. &
             (parameters%hydraulic_model_kind == 6 .and. parameters%extended_model6_active))
      self%analytical_hydraulics_active = allocated(parameters%hydraulic_model_kind) .and. &
                                         .not. self%extended_hydraulics_active
      if (self%analytical_hydraulics_active) then
        call initialize_b111_analytical_hydraulic_parameters(self%analytical_hydraulic_parameters, &
             parameters%hydraulic_model_kind, parameters%cofgen)
      end if
      if (self%extended_hydraulics_active) then
        block
          integer :: hyd_status
          call initialize_b111_extended_hydraulic_parameters(self%extended_parameters, &
               parameters%hydraulic_model_kind, parameters%cofgen, hyd_status, parameters%pdi_vapor_active)
          if (hyd_status /= B111_EXT_OK) error stop 'extended hydraulic model parameters invalid'
        end block
      end if
      if (allocated(self%linear_table_parameters)) deallocate(self%linear_table_parameters)
      if (allocated(parameters%linear_hydraulic_table)) self%linear_table_parameters = parameters%linear_hydraulic_table
      self%direct_retention_active = parameters%direct_retention_active
      self%direct_retention_slot = parameters%prepared_direct_retention_slot
      self%bottom_mode = parameters%bottom_mode
      self%prescribed_groundwater_active=parameters%prescribed_groundwater_active
      self%swbotb3_explicit_active = parameters%swbotb3_explicit_active
      self%profile_groundwater_projection = parameters%profile_groundwater_projection
      self%swbotb3_explicit_hdrain_cm = parameters%swbotb3_explicit_hdrain_cm
      self%swbotb3_explicit_shape_3 = parameters%swbotb3_explicit_shape_3
      self%swkimpl = parameters%swkimpl
      self%picard_conductivity_iteration = parameters%picard_conductivity_iteration
      self%swkmean = parameters%swkmean
      self%max_iterations = parameters%max_iterations
      self%weather_trial_warm_start = parameters%weather_trial_warm_start
      self%weather_line_search_retry = parameters%weather_line_search_retry
      self%max_backtracking = parameters%max_backtracking
      self%min_step_duration = parameters%min_step_duration
      self%practical_richards_a2c_active = parameters%practical_richards_a2c_active
      self%compartment_balance_tolerance = parameters%compartment_balance_tolerance
      self%total_balance_tolerance = parameters%total_balance_tolerance
      self%head_abs_tolerance = parameters%head_abs_tolerance
      self%head_rel_tolerance = parameters%head_rel_tolerance
      if (self%practical_richards_a2c_active) then
        self%compartment_balance_tolerance = FMR_PRACTICAL_RICHARDS_A2C_TOL
        self%total_balance_tolerance = FMR_PRACTICAL_RICHARDS_A2C_TOL
        self%head_abs_tolerance = FMR_PRACTICAL_RICHARDS_A2C_TOL
        self%head_rel_tolerance = FMR_PRACTICAL_RICHARDS_A2C_TOL
      end if
      self%ponding_tolerance = parameters%ponding_tolerance
      self%root_extraction_active = parameters%root_extraction_active
      self%root_salinity_active = parameters%root_salinity_active
      self%reactive_solute_active=parameters%reactive_solute_active
      self%reactive_salinity_active=parameters%reactive_salinity_active
      if (allocated(self%micro_de_willigen)) deallocate(self%micro_de_willigen)
      if (allocated(self%micro_tables)) deallocate(self%micro_tables)
      if (allocated(self%micro_horizon_first_node)) deallocate(self%micro_horizon_first_node)
      if (allocated(parameters%micro_de_willigen)) then
        self%micro_de_willigen = parameters%micro_de_willigen
        self%micro_maximum_drought=parameters%micro_maximum_drought
        self%micro_combined_stress_mode=parameters%micro_combined_stress_mode
        if (allocated(parameters%micro_horizon_first_node)) then
          self%micro_horizon_first_node = parameters%micro_horizon_first_node
          call fmr_build_micro_mvg_tables(self%hydraulic_parameters, self%micro_tables, micro_tables_ok, &
               self%micro_horizon_first_node)
        else
          call fmr_build_micro_mvg_tables(self%hydraulic_parameters, self%micro_tables, micro_tables_ok)
        end if
      end if
      if(allocated(self%mobile_dispersion))deallocate(self%mobile_dispersion)
      if(allocated(parameters%mobile_dispersion))self%mobile_dispersion=parameters%mobile_dispersion
      self%solute_tscf = parameters%solute_tscf
      self%saltmax_mg_cm3 = parameters%saltmax_mg_cm3
      self%saltslope_cm3_mg = parameters%saltslope_cm3_mg
      self%salt_temporal_tolerance_mg_cm2 = parameters%salt_temporal_tolerance_mg_cm2
      self%root_compensation = parameters%root_compensation
      self%frost_low_air_drainage = parameters%frost_low_air_drainage
      self%frost_drainage = parameters%frost_drainage
      self%frost_divdra_active = parameters%frost_divdra_active
      self%frost_divdra = parameters%frost_divdra
      if(allocated(self%frost_divdra_levels))deallocate(self%frost_divdra_levels)
      if(allocated(parameters%frost_divdra_levels))self%frost_divdra_levels=parameters%frost_divdra_levels
      self%frost_response_drainage_active = parameters%frost_response_drainage_active
      self%frost_low_air_response_drainage_active = parameters%frost_low_air_response_drainage_active
      self%frost_tabulated_response_drainage_active = parameters%frost_tabulated_response_drainage_active
      self%frost_analytic_response_drainage_active = parameters%frost_analytic_response_drainage_active
      self%frost_empirical_response_drainage_active = parameters%frost_empirical_response_drainage_active
      self%frost_extended_response_drainage_active = parameters%frost_extended_response_drainage_active
      self%frost_highest_response_drainage_active = parameters%frost_highest_response_drainage_active
      self%frost_bottom = parameters%frost_bottom
      self%root_frost = parameters%root_frost
      self%root_frost_head_budget_cm=parameters%root_frost_head_budget_cm
      self%root_frost_temperature_budget_c=parameters%root_frost_temperature_budget_c
      if (self%root_compensation%method < ROOT_COMP_OFF .or. self%root_compensation%method > ROOT_COMP_WALSUM) return
      if (self%root_compensation%method /= ROOT_COMP_OFF .and. .not. self%root_extraction_active) return
      if(self%root_compensation%stressor==ROOT_COMP_FROST.and..not.self%root_frost%active) return
      if(allocated(self%bartholomeus)) deallocate(self%bartholomeus)
      if(allocated(parameters%bartholomeus)) self%bartholomeus=parameters%bartholomeus
      self%macropore_active = parameters%macropore_active
      if (allocated(self%macropore_config)) deallocate(self%macropore_config)
      if (parameters%macropore_active .and. allocated(parameters%macropore)) then
        allocate(self%macropore_config)
        self%macropore_config = parameters%macropore
        if(self%macropore_config%variable_surface_conductivity)then
          if(.not.self%macropore_config%surface_pond_inflow_enabled)return
          if(self%macropore_config%geometry%top_node/=1)return
        end if
      end if
      self%snow_active = parameters%snow_active
      self%soil_temperature_active = parameters%soil_temperature_active
      self%frost_active = parameters%frost_active
      self%frost_hydraulic = parameters%frost_hydraulic
      if (self%frost_active) then
        if (.not. associated(self%frost_constitutive)) allocate(self%frost_constitutive)
      end if
      self%black_heat_composition_enabled = parameters%black_heat_composition_enabled
      self%black_evaporation_active = parameters%black_evaporation_active
      self%black_evaporation_parameters = black_evaporation_parameters_t()
      if (parameters%black_evaporation_active .and. allocated(parameters%black_evaporation)) then
        self%black_evaporation_parameters = parameters%black_evaporation
      end if
      self%boesten_evaporation_active = parameters%boesten_evaporation_active
      self%boesten_evaporation_parameters = boesten_evaporation_parameters_t()
      if (parameters%boesten_evaporation_active .and. allocated(parameters%boesten_evaporation)) then
        self%boesten_evaporation_parameters = parameters%boesten_evaporation
      end if
      self%drainage_response_active = parameters%drainage_response_active
      if(allocated(self%drainage_trial_distribution))deallocate(self%drainage_trial_distribution)
      if(allocated(parameters%drainage_trial_distribution)) &
        self%drainage_trial_distribution=parameters%drainage_trial_distribution
      self%drainage_qbot_smooth_freatic_projection = parameters%drainage_qbot_smooth_freatic_projection
      if (allocated(self%drainage_response_levels)) deallocate(self%drainage_response_levels)
      if (parameters%drainage_response_active .and. allocated(parameters%drainage_response_levels)) then
        allocate(self%drainage_response_levels(size(parameters%drainage_response_levels)))
        self%drainage_response_levels = parameters%drainage_response_levels
      end if
      if (allocated(self%soil_temperature_parameters)) deallocate(self%soil_temperature_parameters)
      if (parameters%soil_temperature_active) then
        allocate(self%soil_temperature_parameters)
        self%soil_temperature_parameters = parameters%soil_temperature
      end if
    class default
      error stop 'F-MR06 serialized backend: unexpected parameter type'
    end select
  end subroutine fmr_serialized_configure_parameters

  subroutine fmr_serialized_prepare_interval(self, forcing, interval, config)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    class(canonical_forcing_t), intent(in) :: forcing
    type(canonical_interval_t), intent(in) :: interval
    type(canonical_numerical_config_t), intent(in) :: config
    integer :: n, drainage_preflight_status
    real(real64) :: black_values(9), boesten_values(9), rutter_values(14), time_tol, weather_balance_rate
    if (allocated(self%pond_input)) deallocate(self%pond_input)
    if (allocated(self%substep_root)) deallocate(self%substep_root)
    self%substep_root_diagnostics = root_water_uptake_diagnostics_t()
    self%forcing_admitted = .false.
    if(allocated(self%crop_oxygen)) deallocate(self%crop_oxygen)
    self%hbot5_proposal = fmr_hbot5_proposal_t()
    self%cauchy3_proposal = fmr_cauchy3_proposal_t()
    if (allocated(self%legacy_swbotb5_control)) deallocate(self%legacy_swbotb5_control)
    if (allocated(self%legacy_swbotb3_implicit_control)) deallocate(self%legacy_swbotb3_implicit_control)
    self%macropore_top_input_forcing = fmr_macropore_top_input_forcing_t()
    self%rfm_surface_forcing = rfm_surface_forcing_t()
    self%drainage_response_evaluations = 0
    self%drainage_response_diagnostics = fmr_drainage_response_diagnostics_t()
    self%drainage_response_window_exchange_available = self%drainage_response_active
    self%drainage_response_window_signed_exchange_native = 0.0_real64
    self%last_observation = fmr_serialized_physical_observation_t()
    self%last_observation%drainage_response_active = self%drainage_response_active
    self%last_observation%practical_richards_a2c_active = self%practical_richards_a2c_active
    self%last_observation%picard_conductivity_iteration = self%picard_conductivity_iteration
    self%last_observation%practical_richards_head_abs_tolerance = self%head_abs_tolerance
    self%last_observation%practical_richards_head_rel_tolerance = self%head_rel_tolerance
    self%last_observation%practical_richards_compartment_balance_tolerance = self%compartment_balance_tolerance
    self%last_observation%practical_richards_total_balance_tolerance = self%total_balance_tolerance
    if(self%weather_surface_active)then
      ! Stop Newton only after its rate residual is compatible with the outer
      ! transaction's depth gate. configure_parameters restores caller values
      ! before every interval, so this tightening never accumulates across runs.
      if(.not.associated(self%soil_parameters))return
      if(.not.ieee_is_finite(config%transaction%mass_tolerance))return
      if(config%transaction%mass_tolerance<=0.0_real64.or.interval%t1<=interval%t0)return
      weather_balance_rate=config%transaction%mass_tolerance/ &
        (16.0_real64*real(self%soil_parameters%active_nodes,real64)*(interval%t1-interval%t0))
      self%compartment_balance_tolerance=min(self%compartment_balance_tolerance,weather_balance_rate)
      self%total_balance_tolerance=min(self%total_balance_tolerance, &
        real(self%soil_parameters%active_nodes,real64)*weather_balance_rate)
    end if
    self%last_observation%temporal_indicator_enabled = self%temporal_indicator_history_enabled
    self%last_observation%fixed_weir_surface_water_active = self%fixed_weir_surface_water_active
    self%last_observation%black_evaporation_active = self%black_evaporation_active
    self%last_observation%boesten_evaporation_active = self%boesten_evaporation_active
    self%trajectory_direction_requested = config%accepted_trajectory_direction%requested
    self%trajectory_control_coordinate = config%accepted_trajectory_direction%control_coordinate
    self%trajectory_requested_t0 = interval%t0
    self%trajectory_requested_t1 = interval%t1
    call configure_trajectory_direction(self%trajectory_direction, &
         self%trajectory_direction_requested .and. self%trajectory_provenance_valid)
    self%temporal_indicator_budget_supplied = config%model_temporal_indicator_budget_available
    self%temporal_indicator_budget_valid = .false.
    if (self%temporal_indicator_budget_supplied) then
      self%temporal_indicator_budget = config%model_temporal_indicator_budget
      if (ieee_is_finite(self%temporal_indicator_budget)) then
        self%temporal_indicator_budget_valid = self%temporal_indicator_budget > 0.0_real64
      end if
    else
      self%temporal_indicator_budget = 0.0_real64
    end if
    self%last_observation%temporal_head_budget_supplied = self%temporal_indicator_budget_supplied
    self%last_observation%temporal_head_budget_valid = self%temporal_indicator_budget_valid
    self%last_observation%temporal_head_budget = self%temporal_indicator_budget
    if (.not. self%temporal_indicator_history_enabled) then
      self%last_observation%temporal_certificate_unavailable_reason = 'history-service-disabled'
    else if (.not. self%temporal_indicator_budget_supplied) then
      self%last_observation%temporal_certificate_unavailable_reason = 'budget-not-supplied'
    else if (.not. self%temporal_indicator_budget_valid) then
      self%last_observation%temporal_certificate_unavailable_reason = 'budget-invalid'
    else
      self%last_observation%temporal_certificate_unavailable_reason = 'indicator-not-evaluated'
    end if
    if (interval%t1 <= interval%t0 .or. config%max_committed_substeps <= 0) return
    if (.not. associated(self%soil_parameters)) return
    n = self%soil_parameters%active_nodes
    select type (forcing)
    type is (fmr_b110_physical_forcing_t)
      if(self%reactive_solute_active.neqv.allocated(forcing%reactive_supply))return
      if(self%reactive_solute_active)self%reactive_supply=forcing%reactive_supply
      if(allocated(self%macropore_config))then
        if(self%macropore_config%variable_surface_conductivity.and..not.forcing%experimental_process_combinations)return
        if(self%macropore_config%rate_template%limiter%conservative_storage_bounds.and. &
           .not.forcing%experimental_process_combinations)return
      end if
      if (.not. allocated(forcing%subsurface_irrigation_source) .or. .not. allocated(forcing%root_extraction_sink)) return
      if (size(forcing%subsurface_irrigation_source) /= n .or. size(forcing%root_extraction_sink) /= n) return
      if (allocated(forcing%substep_root)) then
        if (.not.self%root_extraction_active) return
        if (forcing%substep_root%parameters%active_nodes /= n) return
        if (any(forcing%root_extraction_sink /= 0.0_real64)) return
        if (allocated(self%micro_de_willigen)) return
        if(allocated(self%bartholomeus))then
          if(.not.self%prescribed_groundwater_active.or..not.self%accepted_water_flux_trace_enabled)return
          if(forcing%substep_root%parameters%empirical_oxygen_enabled)return
          if(.not.allocated(forcing%crop_oxygen))return
          if(.not.allocated(forcing%crop_oxygen%root_density_kg_m3))return
          if(size(forcing%crop_oxygen%root_density_kg_m3)/=forcing%substep_root%request%rooted_nodes)return
        end if
        if (self%root_salinity_active.or.self%root_frost%active) return
        if(self%root_compensation%method/=ROOT_COMP_OFF)then
          if(.not.self%black_heat_composition_enabled.or.self%root_compensation%method/=ROOT_COMP_JARVIS)return
          if(.not.forcing%substep_root%parameters%empirical_oxygen_enabled)return
        end if
        ! Numeric heat uses the same hydraulic Feddes trial-beginning view.
        ! Admit it only on the joint accepted-trace route, with chemistry
        ! outside the water state; admitted Picard uses this same hydraulic view.
        if (self%soil_temperature_active) then
          if (.not.self%accepted_water_flux_trace_enabled.or. &
              self%solute_state_layout_id/=FMR_SOLUTE_STATE_LAYOUT_NONE) return
          if(self%soil_temperature_parameters%solution_mode/=SOIL_TEMP_SOLUTION_NUMERIC)return
        end if
        if (self%frost_active.or.self%snow_active) return
        if (self%rutter_active.or.self%macropore_active)then
          if(.not.(self%rutter_active.and.self%soil_temperature_active.and.self%accepted_water_flux_trace_enabled.and. &
             ((self%macropore_active.and.self%boesten_evaporation_active).or. &
              (self%black_evaporation_active.and..not.self%macropore_active))))return
          if(forcing%substep_root%parameters%empirical_oxygen_enabled.and. &
             .not.(forcing%experimental_empirical_oxygen.or.forcing%experimental_process_combinations))return
        end if
        if (self%rfm_configuration%enabled.or.allocated(forcing%macropore_top_input)) return
        if (self%swkimpl /= 0) return
        if (allocated(forcing%root_potential_sink)) return
        if(allocated(forcing%crop_oxygen).and..not.allocated(self%bartholomeus))return
        if(forcing%root_drought_reduction_total/=0.0_real64)return
        if(self%rutter_active)then
          if(forcing%root_potential_transpiration/=forcing%substep_root%request%potential_transpiration)return
        else
          if(forcing%root_potential_transpiration/=0.0_real64)return
        end if
        self%substep_root = forcing%substep_root
      end if
      if (allocated(self%micro_de_willigen)) then
        if (.not. self%root_extraction_active .or. .not. allocated(self%micro_tables)) return
        if (.not. allocated(forcing%micro_root_length_density)) return
        if (size(forcing%micro_root_length_density) /= n) return
        if (forcing%micro_rooted_nodes < 0 .or. forcing%micro_rooted_nodes > n) return
        if (any(.not. ieee_is_finite(forcing%micro_root_length_density))) return
        if (any(forcing%micro_root_length_density < 0.0_real64)) return
        if (any(forcing%root_extraction_sink /= 0.0_real64)) return
        if (allocated(forcing%root_potential_sink) .or. forcing%root_drought_reduction_total /= 0.0_real64) return
        if (self%root_compensation%method /= ROOT_COMP_OFF.or.self%root_salinity_active.or.self%root_frost%active)return
        if(.not.self%reactive_solute_active)then
          if(allocated(self%bartholomeus).or.self%rutter_active)return
          if(self%micro_de_willigen%oxygen_mode/=0)return
        end if
        if (forcing%micro_rooted_nodes > 1 .and. .not. allocated(self%micro_horizon_first_node)) then
          if (any(self%hydraulic_parameters%cofgen(1:24,2:forcing%micro_rooted_nodes) /= &
              spread(self%hydraulic_parameters%cofgen(1:24,1),2,forcing%micro_rooted_nodes-1))) return
        end if
        self%micro_rooted_nodes = forcing%micro_rooted_nodes
        self%micro_root_length_density = forcing%micro_root_length_density
      else
        if (allocated(forcing%micro_root_length_density) .or. forcing%micro_rooted_nodes /= 0) return
        if (allocated(self%micro_root_length_density)) deallocate(self%micro_root_length_density)
        self%micro_rooted_nodes = 0
      end if
      if (self%rutter_active) then
        if (.not. allocated(forcing%rutter) .or. .not. forcing%rutter%prepared .or. &
            .not. forcing%rutter%source_window%valid()) return
        if (allocated(forcing%snow) .or. &
            (allocated(forcing%black_evaporation).and..not.self%black_evaporation_active) .or. &
            (allocated(forcing%boesten_evaporation) .and. .not. self%boesten_evaporation_active) .or. &
            allocated(forcing%rfm_surface) .or. &
            allocated(forcing%macropore_top_input) .or. self%snow_active .or. &
            forcing%top_flux /= 0.0_real64) return
        time_tol = 64.0_real64 * epsilon(1.0_real64) * &
             max(1.0_real64, abs(interval%t0), abs(interval%t1))
        if (interval%t0 < forcing%rutter%source_window%start_time() - time_tol .or. &
            interval%t1 > forcing%rutter%source_window%end_time() + time_tol) return
        rutter_values = [forcing%rutter%process%surface_irrigation_cm_per_day, &
             forcing%rutter%process%vegetation_cover_fraction, &
             forcing%rutter%process%canopy_storage_capacity_cm, &
             forcing%rutter%process%interception_evaporation_capacity_cm_per_day, &
             forcing%rutter%process%potential_transpiration_dry_cm_per_day, &
             forcing%rutter%process%potential_transpiration_wet_cm_per_day, &
             forcing%rutter%snowmelt_rate_cm_per_day, forcing%rutter%runon_rate_cm_per_day, &
             forcing%rutter%potential_bare_soil_evaporation_cm_per_day, &
             forcing%rutter%potential_pond_evaporation_cm_per_day, forcing%rutter%ponding_max_cm, &
             forcing%rutter%runoff_resistance_day, forcing%rutter%runoff_exponent, interval%t1-interval%t0]
        if (any(.not. ieee_is_finite(rutter_values))) return
        if (forcing%rutter%process%vegetation_cover_fraction < 0.0_real64 .or. &
            forcing%rutter%process%vegetation_cover_fraction > 1.0_real64 .or. &
            forcing%rutter%process%canopy_storage_capacity_cm < 0.0_real64 .or. &
            forcing%rutter%process%interception_evaporation_capacity_cm_per_day < 0.0_real64 .or. &
            forcing%rutter%process%potential_transpiration_dry_cm_per_day < 0.0_real64 .or. &
            forcing%rutter%process%potential_transpiration_wet_cm_per_day < 0.0_real64 .or. &
            forcing%rutter%snowmelt_rate_cm_per_day /= 0.0_real64 .or. forcing%rutter%runon_rate_cm_per_day < 0.0_real64 .or. &
            forcing%rutter%potential_bare_soil_evaporation_cm_per_day < 0.0_real64 .or. &
            forcing%rutter%potential_pond_evaporation_cm_per_day < 0.0_real64 .or. &
            forcing%rutter%ponding_max_cm < 0.0_real64 .or. forcing%rutter%runoff_resistance_day < 0.0_real64 .or. &
            forcing%rutter%runoff_exponent <= 0.0_real64) return
        if (allocated(self%rutter_forcing)) deallocate(self%rutter_forcing)
        allocate(self%rutter_forcing)
        self%rutter_forcing = forcing%rutter
      else
        if (allocated(forcing%rutter)) return
        if (allocated(self%rutter_forcing)) deallocate(self%rutter_forcing)
      end if
      if(.not.fmr_frost_divdra_forcing_valid(self%frost_divdra_active,forcing))return
      self%frost_divdra_scalar_cm_per_day=forcing%frost_divdra_scalar_cm_per_day
      if(allocated(self%frost_divdra_scalars_cm_per_day))deallocate(self%frost_divdra_scalars_cm_per_day)
      if(allocated(self%frost_divdra_levels).neqv.allocated(forcing%frost_divdra_scalars_cm_per_day))return
      if(allocated(self%frost_divdra_levels))then
        if(size(forcing%frost_divdra_scalars_cm_per_day)/=size(self%frost_divdra_levels))return
        self%frost_divdra_scalars_cm_per_day=forcing%frost_divdra_scalars_cm_per_day
      end if
      if(self%frost_divdra_active)then
        ! A scalar owner is mutually exclusive with every materialized nodal owner.
        if(abs(forcing%bottom_flux)>1.e6_real64)return
      else if (self%drainage_response_active) then
        if (allocated(forcing%drainage_flux_by_level) .or. .not. allocated(self%drainage_response_levels) .or. &
            .not. allocated(forcing%drainage_response_controls)) return
        drainage_preflight_status = fmr_drainage_response_configuration_status(self%drainage_response_levels, &
             forcing%drainage_response_controls, n)
        self%drainage_response_diagnostics%status = drainage_preflight_status
        self%last_observation%drainage_response = self%drainage_response_diagnostics
        if (drainage_preflight_status /= FMR_DRAIN_BIND_OK) return
        ! Native OWLTAB is ordinary-only; the existing frost contracts retain
        ! their explicitly qualified response families and endpoint semantics.
        if(any(self%drainage_response_levels%variant==FMR_DRAIN_VARIANT_DRAMET3))then
          if(self%frost_active.or.self%frost_response_drainage_active) return
        end if
        if(self%frost_low_air_response_drainage_active)then
          if(.not.self%frost_low_air_drainage%valid())return
          if(size(self%frost_low_air_drainage%drain_depth_cm)/=size(self%drainage_response_levels))return
        end if
        if(self%frost_response_drainage_active)then
          if(allocated(forcing%soil_salt_boundary).or.allocated(forcing%c_drain_salt))return
          if(any(forcing%subsurface_irrigation_source/=0._real64).or.any(forcing%root_extraction_sink/=0._real64))return
        end if
      else
        if (.not. allocated(forcing%drainage_flux_by_level) .or. allocated(forcing%drainage_response_controls)) return
        if (size(forcing%drainage_flux_by_level,1) <= 0 .or. size(forcing%drainage_flux_by_level,2) /= n) return
        if (self%frost_active .and. .not.self%frost_drainage%active.and.any(forcing%drainage_flux_by_level /= 0.0_real64)) return
        if(self%frost_low_air_drainage%active)then
          if(.not.allocated(self%frost_low_air_drainage%drain_depth_cm))return
          if(size(self%frost_low_air_drainage%drain_depth_cm)/=size(forcing%drainage_flux_by_level,1))return
        end if
        ! Legacy FrozenBounds can replace a prescribed qbot under a deep frozen
        ! profile. Until that boundary view is separately admitted, this slice
        ! is limited to a zero prescribed qbot where the boundary is invariant.
        if (self%frost_active .and. .not.self%frost_bottom%active.and..not.self%frost_drainage%active .and. forcing%bottom_flux /= 0.0_real64) return
        if(self%frost_bottom%active.or.self%frost_drainage%active)then
          if(allocated(forcing%soil_salt_boundary).or.allocated(forcing%c_drain_salt))return
        end if
      end if
      if (any(.not. ieee_is_finite(forcing%root_extraction_sink))) return
      if(self%root_frost%active) then
        if(self%root_salinity_active.and.any(forcing%subsurface_irrigation_source/=0.0_real64)) return
        if(self%root_frost%rooted_nodes<0.or.self%root_frost%rooted_nodes>n) return
        if(any(forcing%root_extraction_sink(self%root_frost%rooted_nodes+1:)/=0.0_real64)) return
        if(self%root_compensation%method/=ROOT_COMP_OFF) then
          if(.not.allocated(forcing%root_potential_sink)) return
          if(size(forcing%root_potential_sink)/=n) return
          if(any(.not.ieee_is_finite(forcing%root_potential_sink))) return
          if(any(forcing%root_potential_sink<forcing%root_extraction_sink)) return
          if(any(forcing%root_potential_sink(self%root_frost%rooted_nodes+1:)/=0.0_real64)) return
        end if
      end if
      if (self%root_compensation%method /= ROOT_COMP_OFF) then
        if (.not. ieee_is_finite(forcing%root_potential_transpiration) .or. forcing%root_potential_transpiration < 0.0_real64) return
        if (.not. ieee_is_finite(forcing%root_drought_reduction_total) .or. forcing%root_drought_reduction_total < 0.0_real64) return
      end if
      if (self%root_salinity_active .and. self%root_compensation%method == ROOT_COMP_WALSUM) then
        block
          real(real64) :: geometry_alpha
          integer :: deepest_root_node, geometry_status
          ! Validate the crop owner's support before stress can mask a sink.
          if (.not. allocated(forcing%root_walsum_geometry) .or. .not. allocated(forcing%root_potential_sink)) return
          if (size(forcing%root_potential_sink) /= n) return
          if (any(.not. ieee_is_finite(forcing%root_potential_sink))) return
          if (any(forcing%root_potential_sink < 0.0_real64)) return
          call evaluate_walsum_geometry(forcing%root_walsum_geometry,self%soil_parameters%dz, &
               geometry_alpha,deepest_root_node,geometry_status)
          if (geometry_status /= ROOT_COMP_OK) return
          if (any(forcing%root_potential_sink(deepest_root_node+1:) /= 0.0_real64)) return
          if (any(forcing%root_extraction_sink(deepest_root_node+1:) /= 0.0_real64)) return
        end block
      end if
      if(allocated(self%bartholomeus)) then
        block
          integer :: oxygen_route,waterfilm_mode
          call select_fmr_bartholomeus_route(self%bartholomeus%selection,oxygen_route,waterfilm_mode)
          if(oxygen_route==FMR_BARTHOLOMEUS_ACTIVE) then
            if(.not.allocated(forcing%crop_oxygen)) return
            if(.not.valid_crop_bartholomeus_input(forcing%crop_oxygen,n)) return
            self%crop_oxygen=forcing%crop_oxygen
          else if(oxygen_route/=FMR_BARTHOLOMEUS_DISABLED) then
            return
          end if
        end block
      else
        if(allocated(forcing%crop_oxygen)) return
      end if
      if (self%root_extraction_active) then
        if (any(forcing%root_extraction_sink < 0.0_real64)) return
      else
        if (any(abs(forcing%root_extraction_sink) > 0.0_real64)) return
      end if
      if (allocated(forcing%legacy_swbotb5_control)) then
        if (self%bottom_mode /= 5 .or. .not. self%soil_water_selection%uses_reference()) return
        if (allocated(forcing%legacy_swbotb3_implicit_control) .or. allocated(forcing%legacy_swbotb2_control) .or. &
            allocated(forcing%legacy_swbotb4_qgwl_control)) return
        if (.not. forcing%legacy_swbotb5_control%ready()) return
        allocate(self%legacy_swbotb5_control)
        self%legacy_swbotb5_control = forcing%legacy_swbotb5_control
      end if
      if (allocated(forcing%legacy_swbotb3_implicit_control)) then
        if (self%bottom_mode /= 3 .or. .not. self%soil_water_selection%uses_reference()) return
        if (allocated(forcing%legacy_swbotb5_control) .or. allocated(forcing%legacy_swbotb2_control) .or. &
            allocated(forcing%legacy_swbotb4_qgwl_control)) return
        if (.not. forcing%legacy_swbotb3_implicit_control%ready()) return
        allocate(self%legacy_swbotb3_implicit_control)
        self%legacy_swbotb3_implicit_control = forcing%legacy_swbotb3_implicit_control
      end if
      if (self%bottom_mode == 3 .and. .not. allocated(self%legacy_swbotb3_implicit_control)) return
      if (allocated(forcing%legacy_swbotb4_qgwl_control)) then
        if (allocated(forcing%legacy_swbotb2_control)) return
        if (self%bottom_mode /= 2 .or. .not. self%soil_water_selection%uses_reference()) return
        if (.not. allocated(self%legacy_swbotb4_qgwl_control)) allocate(self%legacy_swbotb4_qgwl_control)
        self%legacy_swbotb4_qgwl_control = forcing%legacy_swbotb4_qgwl_control
      else if (allocated(self%legacy_swbotb4_qgwl_control)) then
        deallocate(self%legacy_swbotb4_qgwl_control)
      end if
      if (allocated(forcing%legacy_swbotb2_control)) then
        if (self%bottom_mode /= 2 .or. .not. self%soil_water_selection%uses_reference()) return
        if (.not. forcing%legacy_swbotb2_control%ready()) return
        if (.not. allocated(self%legacy_swbotb2_control)) allocate(self%legacy_swbotb2_control)
        self%legacy_swbotb2_control = forcing%legacy_swbotb2_control
      else if (allocated(self%legacy_swbotb2_control)) then
        deallocate(self%legacy_swbotb2_control)
      end if
      if (self%snow_active) then
        if (.not. self%snow_event_prepared .or. .not. allocated(forcing%snow)) return
        if (.not. same_real_bits(interval%t0, self%snow_outer_t0) .or. .not. same_real_bits(interval%t1, self%snow_outer_t1)) return
      else
        if (allocated(forcing%snow)) return
      end if
      if (self%soil_temperature_active) then
        if (.not. allocated(forcing%soil_temperature)) return
        if (.not. allocated(self%soil_temperature_forcing)) allocate(self%soil_temperature_forcing)
        self%soil_temperature_forcing = forcing%soil_temperature
        if (self%frost_active) then
          if (self%soil_temperature_parameters%solution_mode/=SOIL_TEMP_SOLUTION_NUMERIC .or. &
              self%soil_temperature_forcing%top_boundary_mode/=SOIL_TEMP_TOP_PRESCRIBED_TEMPERATURE .or. &
              self%soil_temperature_forcing%bottom_boundary_mode/=SOIL_TEMP_BOTTOM_ZERO_HEAT_FLUX .or. &
              self%soil_temperature_forcing%snow_water_storage_cm/=0.0_real64) return
        end if
      else
        if (allocated(forcing%soil_temperature)) return
        if (allocated(self%soil_temperature_forcing)) deallocate(self%soil_temperature_forcing)
      end if

      self%black_evaporation_forcing = fmr_black_evaporation_runtime_forcing_t()
      if (self%black_evaporation_active) then
        if (.not. allocated(forcing%black_evaporation)) return
        if (forcing%top_flux /= 0.0_real64) return
        black_values = [forcing%black_evaporation%precipitation_rate_cm_per_day, &
             forcing%black_evaporation%irrigation_rate_cm_per_day, &
             forcing%black_evaporation%snowmelt_rate_cm_per_day, &
             forcing%black_evaporation%runon_rate_cm_per_day, &
             forcing%black_evaporation%potential_bare_soil_evaporation_cm_per_day, &
             forcing%black_evaporation%potential_pond_evaporation_cm_per_day, &
             forcing%black_evaporation%ponding_max_cm, forcing%black_evaporation%runoff_resistance_day, &
             forcing%black_evaporation%runoff_exponent]
        if (.not. all(ieee_is_finite(black_values))) return
        if (any(black_values(1:8) < 0.0_real64)) return
        if (forcing%black_evaporation%runoff_exponent /= 1.0_real64) return
        if (forcing%black_evaporation%snowmelt_rate_cm_per_day /= 0.0_real64 .or. &
            forcing%black_evaporation%runon_rate_cm_per_day /= 0.0_real64) return
        if (forcing%black_evaporation%wetting_reset_event) then
          if (.not. ieee_is_finite(forcing%black_evaporation%wetting_event_time)) return
          if (.not. same_real_bits(forcing%black_evaporation%wetting_event_time, interval%t0)) return
        end if
        self%black_evaporation_forcing = forcing%black_evaporation
        self%black_forcing_end_time=interval%t1
      else
        if (allocated(forcing%black_evaporation)) return
      end if

      self%boesten_evaporation_forcing = fmr_boesten_evaporation_runtime_forcing_t()
      if (self%boesten_evaporation_active) then
        if (.not. allocated(forcing%boesten_evaporation)) return
        if (allocated(forcing%black_evaporation)) return
        if (forcing%top_flux /= 0.0_real64) return
        boesten_values = [forcing%boesten_evaporation%precipitation_rate_cm_per_day, &
             forcing%boesten_evaporation%irrigation_rate_cm_per_day, &
             forcing%boesten_evaporation%snowmelt_rate_cm_per_day, &
             forcing%boesten_evaporation%runon_rate_cm_per_day, &
             forcing%boesten_evaporation%potential_bare_soil_evaporation_cm_per_day, &
             forcing%boesten_evaporation%potential_pond_evaporation_cm_per_day, &
             forcing%boesten_evaporation%ponding_max_cm, forcing%boesten_evaporation%runoff_resistance_day, &
             forcing%boesten_evaporation%runoff_exponent]
        if (.not. all(ieee_is_finite(boesten_values))) return
        if (any(boesten_values(1:8) < 0.0_real64)) return
        if (forcing%boesten_evaporation%runoff_exponent /= 1.0_real64) then
          if (.not.forcing%experimental_process_combinations) return
          if (forcing%boesten_evaporation%runoff_exponent < 0.5_real64.or. &
              forcing%boesten_evaporation%runoff_exponent > 2.0_real64) return
        end if
        ! Runon is an admitted shared-surface source for the B1.11 dynamic
        ! top boundary. It must not be reclassified as direct macropore input.
        ! Snowmelt remains outside this bounded Boesten envelope here.
        if (forcing%boesten_evaporation%snowmelt_rate_cm_per_day /= 0.0_real64) return
        self%boesten_evaporation_forcing = forcing%boesten_evaporation
      else
        if (allocated(forcing%boesten_evaporation)) return
      end if

      if(self%frost_divdra_active)then
        if(allocated(self%drainage_response_controls))deallocate(self%drainage_response_controls)
        if(allocated(self%unfrozen_drainage_flux))deallocate(self%unfrozen_drainage_flux)
        if(allocated(self%frost_divdra_levels))then
          if(associated(self%qdra))deallocate(self%qdra)
          allocate(self%qdra(size(self%frost_divdra_levels),n))
        end if
        if(associated(self%qdra))then
          if(.not.allocated(self%frost_divdra_levels))then
            if(size(self%qdra,1)/=1.or.size(self%qdra,2)/=n)deallocate(self%qdra)
          end if
        end if
        if(.not.associated(self%qdra))allocate(self%qdra(1,n))
        self%qdra=0.0_real64
      else if (self%drainage_response_active) then
        if (associated(self%qdra)) then
          if (size(self%qdra,1) /= size(self%drainage_response_levels) .or. size(self%qdra,2) /= n) then
            deallocate(self%qdra)
          end if
        end if
        if (.not. associated(self%qdra)) allocate(self%qdra(size(self%drainage_response_levels),n))
        self%qdra = 0.0_real64
        if (allocated(self%drainage_response_controls)) then
          if (size(self%drainage_response_controls) /= size(forcing%drainage_response_controls)) &
               deallocate(self%drainage_response_controls)
        end if
        if (.not. allocated(self%drainage_response_controls)) &
             allocate(self%drainage_response_controls(size(forcing%drainage_response_controls)))
        self%drainage_response_controls = forcing%drainage_response_controls
      else
        if (allocated(self%drainage_response_controls)) deallocate(self%drainage_response_controls)
        if (associated(self%qdra)) then
          if (size(self%qdra,1) /= size(forcing%drainage_flux_by_level,1) .or. size(self%qdra,2) /= n) then
            deallocate(self%qdra)
          end if
        end if
        if (.not. associated(self%qdra)) allocate(self%qdra(size(forcing%drainage_flux_by_level,1),n))
        self%qdra = forcing%drainage_flux_by_level
        if(allocated(self%unfrozen_drainage_flux))deallocate(self%unfrozen_drainage_flux)
        if(self%frost_drainage%active)self%unfrozen_drainage_flux=forcing%drainage_flux_by_level
      end if

      if (associated(self%qssdi)) then
        if (size(self%qssdi) /= n) deallocate(self%qssdi)
      end if
      if (.not. associated(self%qssdi)) allocate(self%qssdi(n))

      if (associated(self%qrot)) then
        if (size(self%qrot) /= n) deallocate(self%qrot)
      end if
      if (.not. associated(self%qrot)) allocate(self%qrot(n))

      if (associated(self%qrot_zero)) then
        if (size(self%qrot_zero) /= n) deallocate(self%qrot_zero)
      end if
      if (.not. associated(self%qrot_zero)) allocate(self%qrot_zero(n))

      self%qssdi = forcing%subsurface_irrigation_source
      self%qrot = forcing%root_extraction_sink
      self%root_potential_transpiration = forcing%root_potential_transpiration
      self%root_drought_reduction_total = forcing%root_drought_reduction_total
      if(allocated(self%root_walsum_geometry)) deallocate(self%root_walsum_geometry)
      if(allocated(forcing%root_walsum_geometry)) self%root_walsum_geometry=forcing%root_walsum_geometry
      if(allocated(self%root_potential_sink)) deallocate(self%root_potential_sink)
      if(allocated(forcing%root_potential_sink)) self%root_potential_sink=forcing%root_potential_sink
      if(allocated(self%crop_oxygen) .or. self%root_compensation%method /= ROOT_COMP_OFF .or. self%root_frost%active) then
        self%qrot_unmodified=forcing%root_extraction_sink
      else
        if(allocated(self%qrot_unmodified)) deallocate(self%qrot_unmodified)
      end if
      self%qrot_zero = 0.0_real64

      if (self%drainage_qbot_smooth_freatic_projection) then
        if (allocated(self%projection_zero_direction)) then
          if (size(self%projection_zero_direction) /= n) deallocate(self%projection_zero_direction)
        end if
        if (.not. allocated(self%projection_zero_direction)) allocate(self%projection_zero_direction(n))
        self%projection_zero_direction = 0.0_real64
      else if (allocated(self%projection_zero_direction)) then
        deallocate(self%projection_zero_direction)
      end if
      if (self%rfm_configuration%enabled) then
        if (.not. self%rfm_configuration%valid()) return
        if (.not. allocated(forcing%rfm_surface)) return
        if (.not. forcing%rfm_surface%valid()) return
        if (self%macropore_active .or. self%snow_active .or. self%black_evaporation_active .or. &
            self%boesten_evaporation_active .or. self%fixed_weir_surface_water_active) return
        if (allocated(forcing%macropore_top_input)) return
        self%rfm_surface_forcing = forcing%rfm_surface
      else
        if (allocated(forcing%rfm_surface)) return
      end if

      if (allocated(forcing%macropore_top_input)) then
        if (.not. self%macropore_active) return
        if (.not. forcing%macropore_top_input%valid()) return
        if (forcing%macropore_top_input%supplied) then
          if (self%snow_active .or. self%black_evaporation_active .or. &
              self%fixed_weir_surface_water_active) return
        end if
        self%macropore_top_input_forcing = forcing%macropore_top_input
      end if
      if (allocated(forcing%pond_input)) then
        if (.not.all(ieee_is_finite([forcing%pond_input%rain_rate_cm_day, &
            forcing%pond_input%irrigation_rate_cm_day,forcing%pond_input%runon_rate_cm_day, &
            forcing%pond_input%potential_pond_evaporation_cm_day,forcing%pond_input%ponding_max_cm, &
            forcing%pond_input%runoff_resistance_day,forcing%top_flux, &
            forcing%pond_input%potential_bare_soil_evaporation_cm_day]))) return
        if (min(forcing%pond_input%rain_rate_cm_day,forcing%pond_input%irrigation_rate_cm_day)<0.0_real64.or. &
            max(forcing%pond_input%rain_rate_cm_day,forcing%pond_input%irrigation_rate_cm_day, &
            forcing%pond_input%runon_rate_cm_day)>5.e5_real64.or. &
            min(forcing%pond_input%runon_rate_cm_day,forcing%pond_input%potential_pond_evaporation_cm_day, &
            forcing%pond_input%ponding_max_cm,forcing%pond_input%runoff_resistance_day, &
            forcing%pond_input%potential_bare_soil_evaporation_cm_day)<0.0_real64) return
        if (forcing%top_flux/=0.0_real64.or.self%snow_active.or.self%black_evaporation_active.or. &
            self%boesten_evaporation_active.or.self%rutter_active.or.self%macropore_active.or. &
            self%rfm_configuration%enabled.or.self%fixed_weir_surface_water_active) return
        if (allocated(forcing%snow).or.allocated(forcing%black_evaporation).or. &
            allocated(forcing%boesten_evaporation).or.allocated(forcing%rutter).or. &
            allocated(forcing%rfm_surface).or.allocated(forcing%macropore_top_input)) return
        if (self%swkimpl/=0.or.self%analytical_hydraulics_active.or.self%direct_retention_active) return
        if (.not.self%soil_water_selection%uses_reference()) return
        if (self%temporal_indicator_history_enabled.and..not.self%weather_surface_active) return
        if (config%transaction%temporal_mode/=TX_TEMPORAL_EXTERNAL_FULL_HALF) return
        allocate(self%pond_input,source=forcing%pond_input)
      end if
      self%base_top_flux = forcing%top_flux
      self%top_flux = forcing%top_flux
      if (self%snow_active) self%top_flux = self%base_top_flux - self%snow_melt_rate
      self%top_head = forcing%top_head
      self%bottom_flux = forcing%bottom_flux
      self%bottom_head = forcing%bottom_head
      self%forcing_admitted = .true.
    class default
      return
    end select
  end subroutine fmr_serialized_prepare_interval

  subroutine fmr_serialized_accepted_trajectory_direction_snapshot(self, interval, result)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    type(canonical_interval_t), intent(in) :: interval
    type(accepted_trajectory_direction_result_t), intent(out) :: result
    logical :: finalized

    result = accepted_trajectory_direction_result_t()
    if (.not. self%trajectory_direction_requested) return
    if (.not. self%trajectory_provenance_valid) then
      result%requested = .true.
      result%worker_id = self%trajectory_worker_id
      result%control_coordinate = self%trajectory_control_coordinate
      result%origin_t0 = self%trajectory_requested_t0
      result%accepted_t1 = self%trajectory_requested_t0
      result%route = 'worker-provenance-unavailable'
      return
    end if
    if (.not. same_real_bits(interval%t0, self%trajectory_requested_t0) .or. &
        .not. same_real_bits(interval%t1, self%trajectory_requested_t1)) then
      result%requested = .true.
      result%worker_id = self%trajectory_worker_id
      result%control_coordinate = self%trajectory_control_coordinate
      result%origin_t0 = self%trajectory_requested_t0
      result%accepted_t1 = self%trajectory_direction%current_t1
      result%route = 'canonical-window-mismatch'
      return
    end if
    call finalize_trajectory_direction(self%trajectory_direction, interval%t0, interval%t1, finalized)
    call publish_accepted_trajectory_direction(self%trajectory_direction, result)
  end subroutine fmr_serialized_accepted_trajectory_direction_snapshot

  subroutine populate_snow_observation(self)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    self%last_observation%snow_active = self%snow_active
    self%last_observation%snow_event_prepared = self%snow_event_prepared
    self%last_observation%snow_melt_rate = self%snow_melt_rate
    if (self%snow_active) then
      self%last_observation%snow_status = self%snow_diagnostics%status
      self%last_observation%snow_fluxes = self%snow_fluxes
      self%last_observation%snow_mass = self%snow_diagnostics%mass
    end if
  end subroutine populate_snow_observation

  subroutine populate_fixed_weir_surface_water_observation(self)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    self%last_observation%fixed_weir_surface_water_active = self%fixed_weir_surface_water_active
    if (.not. self%fixed_weir_surface_water_active) return
    self%last_observation%fixed_weir_surface_water_status = self%fixed_weir_surface_water_result%status
    self%last_observation%fixed_weir_surface_water_storage = self%fixed_weir_surface_water_result%candidate_state%storage
    self%last_observation%fixed_weir_surface_water_level = self%fixed_weir_surface_water_result%water_level
    self%last_observation%fixed_weir_surface_water_supply_rate = self%fixed_weir_surface_water_result%supply_rate
    self%last_observation%fixed_weir_surface_water_discharge_rate = self%fixed_weir_surface_water_result%discharge_rate
    self%last_observation%fixed_weir_surface_water_mass_residual = self%fixed_weir_surface_water_result%mass_residual
    self%last_observation%fixed_weir_surface_water_rating_residual = &
         self%fixed_weir_surface_water_result%rating_storage_residual
    self%last_observation%fixed_weir_surface_water_iterations = self%fixed_weir_surface_water_result%bisection_iterations
    self%last_observation%fixed_weir_surface_water_route = self%fixed_weir_surface_water_result%route
  end subroutine populate_fixed_weir_surface_water_observation

  subroutine evaluate_temporal_history_service(self, state, request, solve_result, outcome, ok)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    class(transaction_state_t), intent(inout) :: state
    type(soil_water_solve_request_t), intent(in) :: request
    type(soil_water_solve_result_t), intent(in) :: solve_result
    type(trial_outcome_t), intent(inout) :: outcome
    logical, intent(out) :: ok
    type(soil_water_temporal_indicator_request_t) :: indicator_request
    type(soil_water_temporal_indicator_result_t) :: indicator_result
    real(real64), allocatable :: previous_derivative(:)
    real(real64) :: normalized_indicator
    type(fmr_mode7_head_envelope_assessment_t) :: head_envelope
    logical :: previous_available, replaced
    integer :: n
    ok = .false.
    n = request%parameters%active_nodes
    previous_available = .false.
    select type (physical => state)
    type is (fmr_b110_temporal_indicator_state_t)
      call physical%temporal_history%snapshot(previous_derivative, previous_available)
      if (previous_available) previous_available = size(previous_derivative) == n .and. all(ieee_is_finite(previous_derivative))
    class default
      return
    end select
    indicator_request%previous_right_derivative_available = previous_available
    if (previous_available) then
      allocate(indicator_request%previous_right_derivative(n))
      indicator_request%previous_right_derivative = previous_derivative
    end if
    call self%solver%evaluate_temporal_indicator(request, solve_result, indicator_request, self%workspace, indicator_result)
    self%last_observation%temporal_indicator_enabled = .true.
    self%last_observation%temporal_previous_derivative_available = previous_available
    self%last_observation%temporal_indicator_status = indicator_result%status
    self%last_observation%temporal_indicator_available = indicator_result%available
    self%last_observation%temporal_indicator_route = indicator_result%route
    self%last_observation%temporal_head_inf_bound = indicator_result%head_inf_bound
    self%last_observation%temporal_head_budget_supplied = self%temporal_indicator_budget_supplied
    self%last_observation%temporal_head_budget_valid = self%temporal_indicator_budget_valid
    self%last_observation%temporal_head_budget = self%temporal_indicator_budget
    self%last_observation%temporal_certificate_available = .false.
    self%last_observation%temporal_normalized_indicator = 0.0_real64
    self%last_observation%temporal_additional_tridiagonal_solves = indicator_result%additional_tridiagonal_solves
    self%last_observation%temporal_additional_full_nonlinear_solves = indicator_result%additional_full_nonlinear_solves
    outcome%linear_solves = outcome%linear_solves + indicator_result%additional_tridiagonal_solves
    if (indicator_result%additional_full_nonlinear_solves /= 0) return
    if (.not. allocated(indicator_result%current_right_derivative)) return
    if (size(indicator_result%current_right_derivative) /= n) return
    if (any(.not. ieee_is_finite(indicator_result%current_right_derivative))) return
    select type (physical => state)
    type is (fmr_b110_temporal_indicator_state_t)
      call physical%temporal_history%replace(indicator_result%current_right_derivative, replaced)
      if (.not. replaced) return
    class default
      return
    end select
    self%last_observation%temporal_current_derivative_available = .true.

    if (.not. previous_available) then
      self%last_observation%temporal_certificate_unavailable_reason = 'history-unavailable'
    else if (.not. self%temporal_indicator_budget_supplied) then
      self%last_observation%temporal_certificate_unavailable_reason = 'budget-not-supplied'
    else if (.not. self%temporal_indicator_budget_valid) then
      self%last_observation%temporal_certificate_unavailable_reason = 'budget-invalid'
    else if (.not. indicator_result%available) then
      self%last_observation%temporal_certificate_unavailable_reason = 'indicator-unavailable'
    else if (.not. ieee_is_finite(indicator_result%head_inf_bound) .or. indicator_result%head_inf_bound < 0.0_real64) then
      self%last_observation%temporal_certificate_unavailable_reason = 'indicator-invalid'
    else
      if (request%boundary%bottom_mode == 7) then
        call assess_fmr_mode7_temporal_head_envelope(indicator_result%head_inf_bound, &
             self%temporal_indicator_budget, head_envelope)
        if (head_envelope%status == FMR_MODE7_HEAD_ENVELOPE_OK .and. head_envelope%complete) then
          normalized_indicator = head_envelope%normalized_error
        else
          normalized_indicator = huge(0.0_real64)
        end if
      else
        normalized_indicator = indicator_result%head_inf_bound / self%temporal_indicator_budget
      end if
      if (ieee_is_finite(normalized_indicator) .and. normalized_indicator >= 0.0_real64) then
        outcome%temporal_certificate_available = .true.
        outcome%temporal_indicator = normalized_indicator
        self%last_observation%temporal_certificate_available = .true.
        self%last_observation%temporal_normalized_indicator = normalized_indicator
        self%last_observation%temporal_certificate_unavailable_reason = 'available'
      else
        self%last_observation%temporal_certificate_unavailable_reason = 'normalized-indicator-invalid'
      end if
    end if
    ok = .true.
  end subroutine evaluate_temporal_history_service

  subroutine fmr_serialized_advance(self, state, t0, t1, outcome)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    class(transaction_state_t), intent(inout) :: state
    real(real64), intent(in) :: t0, t1
    type(trial_outcome_t), intent(out) :: outcome
    type(b110_default_mvg_parameters_t), target :: scan_parameters
    real(real64), allocatable :: scan_cofgen(:,:)
    type(soil_water_solve_request_t) :: request
    type(soil_water_solve_result_t) :: solve_result
    type(macropore_runtime_result_t) :: macropore_result
    type(mobile_macro_salt_receipt_t) :: salt_receipt
    type(soil_water_accepted_step_direction_result_t) :: direction_result
    type(trajectory_step_token_t) :: direction_token
    type(process_hydraulic_view_t) :: hydraulic_start, hydraulic_end
    type(soil_temperature_state_t) :: soil_temperature_trial
    type(soil_temperature_result_t) :: soil_temperature_result
    type(soil_temperature_diagnostics_t) :: soil_temperature_diagnostics
    type(soil_temperature_field_view_t) :: oxygen_thermal, frost_thermal
    type(root_water_uptake_flux_result_t) :: oxygen_base,oxygen_final
    type(micro_de_willigen_result_t) :: micro_result
    real(real64),allocatable :: oxygen_w_root(:),oxygen_factors(:),frost_factors(:),root_frost_factors(:)
    real(real64),allocatable :: salinity_cml(:),salinity_alpha(:),salinity_sink(:),salinity_node_loss(:),root_after_oxygen(:),salinity_storage_thickness(:)
    real(real64),allocatable :: trace_macro_water_start(:,:)
    real(real64) :: atmospheric_ctop,salinity_loss_total,salinity_loss_rate
    integer :: oxygen_route,waterfilm_mode,oxygen_status,oxygen_nodes,salinity_status,salt_status
    logical :: publish_root_result
    type(black_evaporation_forcing_t) :: black_process_forcing
    type(black_evaporation_result_t) :: black_result
    type(boesten_evaporation_forcing_t) :: boesten_process_forcing
    type(boesten_evaporation_result_t) :: boesten_result
    type(rutter_interval_result_t) :: rutter_process_result
    type(rutter_source_state_t)::rutter_local_base,rutter_local_candidate,rutter_local_limited
    type(rutter_source_trial_t)::rutter_local_trial
    type(rutter_diagnostics_t)::rutter_local_diagnostics
    real(real64)::rutter_local_input,rutter_local_output,rutter_local_residual,rutter_local_storage, &
         rutter_local_capacity_export,rutter_local_start_cm
    integer::rutter_local_status
    type(root_water_uptake_request_t) :: substep_root_request
    type(fmr_macropore_top_input_forcing_t) :: macro_top_input_trial
    type(rfm_matrix_source_provider_t), target :: rfm_source_provider
    type(rfm_live_trial_prepare_result_t) :: rfm_live
    type(soil_water_top_boundary_result_t) :: rfm_preflight
    real(real64), allocatable, target :: rfm_source_rate(:)
    real(real64), allocatable :: rfm_node_depth_cm(:)
    type(b110_dynamic_top_boundary_solver_provider_t), target :: black_top_provider, boesten_top_provider, rfm_top_provider, &
         rutter_top_provider
    real(real64), allocatable :: drainage_sink_direction(:)
    type(b110_smooth_freatic_projection_diagnostics_t) :: projection_diagnostics
    real(real64) :: step_duration, bottom_temperature_start_c
    real(real64) :: macropore_accepted_top_cm, macropore_rapid_outflow_cm
    real(real64) :: surface_external_exchange_cm
    real(real64) :: macropore_pond_requested_cm, macropore_pond_accepted_cm, macropore_pond_returned_cm
    real(real64) :: rfm_preferential_input_cm, rfm_deep_receipt_cm
    real(real64) :: step_drainage_exchange
    real(real64) :: fixed_top_conductivity
    real(real64) :: projected_groundwater_level, ignored_groundwater_direction
    real(real64) :: candidate_projected_groundwater_level, drainage_groundwater_direction
    logical :: context_ok, snow_event_applied_this_call, temporal_history_ok, hydraulic_view_ok, rfm_source_ok
    logical :: direct_retention_ok, rutter_trial_prepared, drainage_level_present
    real(real64) :: rutter_previous_ponding
    logical :: bottom_temperature_start_available, fixed_top_conductivity_ok
    logical :: trajectory_begin_ok, trajectory_request_ok, trajectory_stage_ok, trajectory_accept_ok
    logical :: trajectory_solver_used, rossfast_certificate_available, drainage_direction_available
    real(real64) :: rossfast_temporal_indicator, effective_bottom_flux
    real(real64) :: cauchy3_q4, cauchy3_q4_sample_t1900, low3_qbot, low3_gwlmean, low3_cvalprof
    real(real64), allocatable :: low3_ztop(:), low3_zbot(:), low3_ksat(:)
    integer :: effective_bottom_mode, swbotb2_status, swbotb4_status, cauchy3_status, low3_status, low3_i
    logical :: low3_k_ok
    type(b111_profile_groundwater_projection_t) :: profile_projection
    type(fmr_qgwl_bottom_boundary_result_t) :: swbotb4_result
    integer :: soil_temperature_status, bottom_temperature_status, drainage_direction_status, candidate_projection_status
    type(frost_bottom_result_t) :: frost_bottom_result
    integer :: frost_status, frost_provider_status
    character(len=64) :: drainage_direction_route
    outcome = trial_outcome_t()
    macropore_accepted_top_cm = 0.0_real64
    macropore_rapid_outflow_cm = 0.0_real64
    macropore_pond_requested_cm = 0.0_real64
    macropore_pond_accepted_cm = 0.0_real64
    macropore_pond_returned_cm = 0.0_real64
    rfm_preferential_input_cm = 0.0_real64
    rfm_deep_receipt_cm = 0.0_real64
    self%last_observation = fmr_serialized_physical_observation_t()
    self%last_observation%practical_richards_a2c_active = self%practical_richards_a2c_active
    self%last_observation%picard_conductivity_iteration = self%picard_conductivity_iteration
    self%last_observation%practical_richards_head_abs_tolerance = self%head_abs_tolerance
    self%last_observation%practical_richards_head_rel_tolerance = self%head_rel_tolerance
    self%last_observation%practical_richards_compartment_balance_tolerance = self%compartment_balance_tolerance
    self%last_observation%practical_richards_total_balance_tolerance = self%total_balance_tolerance
    self%last_observation%soil_temperature_active = self%soil_temperature_active
    self%last_observation%frost_hydraulic_active = self%frost_active
    self%last_observation%black_evaporation_active = self%black_evaporation_active
    self%last_observation%boesten_evaporation_active = self%boesten_evaporation_active
    self%fixed_weir_surface_water_result = fixed_weir_surface_water_result_t()
    black_result = black_evaporation_result_t()
    boesten_result = boesten_evaporation_result_t()
    self%last_observation%temporal_indicator_enabled = self%temporal_indicator_history_enabled
    self%last_observation%temporal_head_budget_supplied = self%temporal_indicator_budget_supplied
    self%last_observation%temporal_head_budget_valid = self%temporal_indicator_budget_valid
    self%last_observation%temporal_head_budget = self%temporal_indicator_budget
    bottom_temperature_start_c = 0.0_real64
    bottom_temperature_start_available = .false.
    frost_status = FROST_EFFECT_OK
    frost_provider_status = FROST_PROVIDER_OK
    trajectory_begin_ok = .false.
    trajectory_request_ok = .false.
    trajectory_stage_ok = .false.
    trajectory_accept_ok = .false.
    trajectory_solver_used = .false.
    drainage_direction_available = .true.
    drainage_direction_status = FMR_QBOT_DRAIN_DIRECTION_OK
    candidate_projection_status = FMR_QBOT_DRAIN_DIRECTION_OK
    drainage_direction_route = 'not-required'
    if (.not. self%temporal_indicator_history_enabled) then
      self%last_observation%temporal_certificate_unavailable_reason = 'history-service-disabled'
    else if (.not. self%temporal_indicator_budget_supplied) then
      self%last_observation%temporal_certificate_unavailable_reason = 'budget-not-supplied'
    else if (.not. self%temporal_indicator_budget_valid) then
      self%last_observation%temporal_certificate_unavailable_reason = 'budget-invalid'
    else
      self%last_observation%temporal_certificate_unavailable_reason = 'indicator-not-evaluated'
    end if
    call populate_snow_observation(self)
    ! Re-enter from the ORIGINAL base root sink for every sibling/retry/step.
    ! qrot is worker scratch. Reducing its previous value would create history.
    if(allocated(self%crop_oxygen)) then
      if(.not.allocated(self%qrot_unmodified) .or. .not.associated(self%qrot)) return
      if(size(self%qrot_unmodified)/=size(self%qrot)) return
      self%qrot=self%qrot_unmodified
    end if
    call populate_fixed_weir_surface_water_observation(self)
    self%last_observation%drainage_response_active = self%drainage_response_active
    self%last_observation%drainage_qbot_projection_active = self%drainage_qbot_smooth_freatic_projection
    snow_event_applied_this_call = .false.
    if (.not. self%forcing_admitted .or. .not. associated(self%soil_parameters) .or. &
        .not. associated(self%hydraulic_parameters) .or. .not. associated(self%constitutive) .or. &
        .not. associated(self%source_sink) .or. .not. associated(self%top_boundary)) return
    if (self%root_extraction_active .and. .not. associated(self%root_sink)) return
    if (.not. state_matches_numerical_continuation_layout(state, self%temporal_indicator_history_enabled, &
                                                           self%macropore_reduction_continuation_enabled, &
                                                           self%fixed_weir_surface_water_active, &
                                                           self%black_evaporation_active, &
                                                           self%boesten_evaporation_active, self%macropore_active, &
                                                           self%rutter_active, self%hysteresis_active)) return
    step_duration = t1 - t0
    if (step_duration <= 0.0_real64) return
    rutter_trial_prepared = .false.
    rutter_previous_ponding = 0.0_real64
    if (self%rutter_active) then
      if (.not. allocated(self%rutter_forcing) .or. .not. self%rutter_forcing%prepared) return
      select type (rutter_physical => state)
      class is (fmr_b110_physical_state_t)
        if (.not. allocated(rutter_physical%rutter)) return
        rutter_previous_ponding = rutter_physical%ponding_depth
      class default
        return
      end select
      if(self%black_evaporation_active)then
        select type(q=>state)
        class is(fmr_b110_physical_state_t)
          rutter_local_base=q%rutter
        end select
        rutter_local_start_cm=rutter_local_base%canopy_storage()
        call rutter_local_base%capacity_candidate(self%rutter_forcing%process%canopy_storage_capacity_cm, &
             rutter_local_limited,rutter_local_capacity_export,rutter_local_status)
        if(rutter_local_status/=RUTTER_WINDOW_OK)return
        rutter_local_base=rutter_local_limited
        if(.not.rutter_local_base%source_window_initialized())then
          if(abs(t0-self%rutter_forcing%source_window%start_time())> &
             64.0_real64*epsilon(1.0_real64)*max(1.0_real64,abs(t0)))return
          call initialize_rutter_source_state(self%rutter_forcing%source_window,rutter_local_base%canopy_storage(), &
               rutter_local_base,rutter_local_status)
          if(rutter_local_status/=RUTTER_WINDOW_OK)return
        end if
        if(abs(rutter_local_base%accepted_until()-t0)>64.0_real64*epsilon(1.0_real64)*max(1.0_real64,abs(t0)))return
        call prepare_rutter_source_trial(self%rutter_forcing%source_window,rutter_local_base,t1, &
             self%rutter_forcing%process,rutter_process_result,rutter_local_trial,rutter_local_diagnostics,rutter_local_status)
        if(rutter_local_status/=RUTTER_WINDOW_OK.or..not.rutter_local_diagnostics%result_produced)return
        call accept_rutter_source_trial(self%rutter_forcing%source_window,rutter_local_base,rutter_local_trial, &
             rutter_local_candidate,rutter_local_status)
        if(rutter_local_status/=RUTTER_WINDOW_OK)return
        rutter_local_input=self%rutter_forcing%source_window%aggregate_value()*step_duration/ &
             (self%rutter_forcing%source_window%end_time()-self%rutter_forcing%source_window%start_time())+ &
             self%rutter_forcing%process%surface_irrigation_cm_per_day*step_duration
        rutter_local_output=(rutter_process_result%net_rain_cm_per_day+ &
             rutter_process_result%net_surface_irrigation_cm_per_day+rutter_process_result%reservoir_outflow_cm_per_day)*step_duration+ &
             rutter_local_capacity_export
        rutter_local_storage=rutter_local_candidate%canopy_storage()-rutter_local_start_cm
        rutter_local_residual=rutter_local_input-rutter_local_output-rutter_local_storage
        if(abs(rutter_local_residual)>1024.0_real64*epsilon(1.0_real64)* &
             max(1.0_real64,abs(rutter_local_input),abs(rutter_local_output),abs(rutter_local_storage)))return
        if(allocated(self%micro_de_willigen))self%root_potential_transpiration=rutter_process_result%potential_transpiration_cm_per_day
      else
        rutter_process_result = self%rutter_forcing%result
      end if
      self%last_observation%rutter_net_rain_rate_cm_per_day = rutter_process_result%net_rain_cm_per_day
      self%last_observation%rutter_net_irrigation_rate_cm_per_day = &
           rutter_process_result%net_surface_irrigation_cm_per_day
      call bind_b110_dynamic_top_boundary_solver_provider(rutter_top_provider, self%soil_parameters, &
           self%hydraulic_parameters, self%swkmean, rutter_previous_ponding, step_duration, &
           rutter_process_result%net_rain_cm_per_day, rutter_process_result%net_surface_irrigation_cm_per_day, &
           self%rutter_forcing%snowmelt_rate_cm_per_day, self%rutter_forcing%runon_rate_cm_per_day, &
           self%rutter_forcing%potential_bare_soil_evaporation_cm_per_day, &
           self%rutter_forcing%potential_pond_evaporation_cm_per_day, self%rutter_forcing%ponding_max_cm, &
           self%rutter_forcing%runoff_resistance_day, self%rutter_forcing%runoff_exponent)
      rutter_trial_prepared = .true.
    end if
    effective_bottom_mode = self%bottom_mode
    effective_bottom_flux = self%bottom_flux
    if (allocated(self%legacy_swbotb4_qgwl_control)) then
      select type (physical_control => state)
      class is (fmr_b110_physical_state_t)
        call fmr_evaluate_legacy_qgwl_bottom_boundary(self%legacy_swbotb4_qgwl_control, &
             physical_control%groundwater_level, swbotb4_result, swbotb4_status)
        if (swbotb4_status /= FMR_QGWL_OK .or. .not. swbotb4_result%available) return
        effective_bottom_mode = 2
        effective_bottom_flux = swbotb4_result%qbot_cm_per_day
      class default
        return
      end select
    end if
    if (allocated(self%legacy_swbotb2_control)) then
      select type (physical_control => state)
      class is (fmr_b110_physical_state_t)
        if (physical_control%active_nodes <= 0 .or. .not. allocated(physical_control%pressure_head)) return
        if (size(physical_control%pressure_head) < physical_control%active_nodes) return
        call self%legacy_swbotb2_control%evaluate(t0, t1, &
             physical_control%pressure_head(physical_control%active_nodes), effective_bottom_mode, &
             effective_bottom_flux, swbotb2_status)
        if (swbotb2_status /= B110_SWBOTB2_OK) return
      class default
        return
      end select
    end if
    if (allocated(self%linear_table_parameters)) then
      block
        integer :: table_status
        call bind_b111_linear_table_provider(self%linear_table_constitutive, self%linear_table_parameters, &
             step_duration, table_status)
        if (table_status /= B111_LINEAR_TABLE_OK) return
      end block
    end if
    if (self%hysteresis_active) then
      select type (physical => state)
      class is (fmr_b110_physical_state_t)
        if (.not. allocated(physical%hysteresis)) return
        scan_cofgen = self%hydraulic_parameters%cofgen
        scan_cofgen(1,:) = physical%hysteresis%theta_r_scan
        scan_cofgen(2,:) = physical%hysteresis%theta_s_scan
        scan_cofgen(4,:) = physical%hysteresis%alpha_active
        call initialize_b110_default_mvg_parameters(scan_parameters, scan_cofgen)
        call bind_b110_default_mvg_provider(self%constitutive, scan_parameters, step_duration)
      class default
        return
      end select
    end if
    if (self%extended_hydraulics_active) then
      block
        integer :: hyd_status
        call bind_b110_default_mvg_provider(self%constitutive, self%hydraulic_parameters, step_duration)
        call configure_b111_legacy_hydraulic_provider(self%extended_legacy, &
             self%hydraulic_parameters%cofgen, self%extended_parameters%model, hyd_status)
        if (hyd_status /= B111_LEGACY_HYD_OK) return
        call bind_b111_legacy_hydraulic_provider(self%extended_legacy, self%constitutive, step_duration, hyd_status)
        if (hyd_status /= B111_LEGACY_HYD_OK) return
        if (self%extended_pdi_vapor_active) then
          select type (physical => state)
          class is (fmr_b110_physical_state_t)
            if (.not. allocated(physical%soil_temperature)) return
            block
              type(soil_temperature_field_view_t) :: thermal
              call build_soil_temperature_field_view(physical%soil_temperature, thermal, hyd_status)
              if (hyd_status /= SOIL_TEMP_OK) return
              call bind_b111_extended_hydraulic_provider(self%extended_constitutive, self%extended_parameters, &
                   self%extended_legacy, hyd_status, thermal%temperature_c)
            end block
          class default
            return
          end select
        else
          call bind_b111_extended_hydraulic_provider(self%extended_constitutive, self%extended_parameters, &
               self%extended_legacy, hyd_status)
        end if
        if (hyd_status /= B111_EXT_OK) return
      end block
    else if (self%hysteresis_active) then
      continue ! scanning provider already bound to trial-local parameters
    else if (self%analytical_hydraulics_active) then
      call bind_b111_analytical_hydraulic_provider(self%analytical_constitutive, self%analytical_hydraulic_parameters)
    else if (self%direct_retention_active) then
      call bind_b110_direct_retention_provider(self%direct_retention_constitutive, self%hydraulic_parameters, &
           step_duration, self%direct_retention_slot, direct_retention_ok)
      if (.not. direct_retention_ok) return
    else
      call bind_b110_default_mvg_provider(self%constitutive, self%hydraulic_parameters, step_duration)
    end if
    request%parameters => self%soil_parameters
    request%step_duration = step_duration
    if (self%black_evaporation_active .or. self%boesten_evaporation_active .or. self%rfm_configuration%enabled .or. &
        self%rutter_active) then
      request%boundary%top_mode = FSI_TOP_MODE_DYNAMIC_PROVIDER
    else
      request%boundary%top_mode = FSI_TOP_MODE_EXPLICIT_FLUX
      request%boundary%top_flux = self%top_flux
    end if
    request%boundary%bottom_mode = effective_bottom_mode
    request%physical%prescribed_groundwater_active=self%prescribed_groundwater_active
    request%boundary%top_head = self%top_head
    request%boundary%bottom_flux = effective_bottom_flux
    request%boundary%bottom_head = self%bottom_head
    if (allocated(self%legacy_swbotb3_implicit_control)) then
      if (.not. self%cauchy3_proposal%covers(t0,t1)) return
      call self%legacy_swbotb3_implicit_control%resolve_q4(t0, t1, cauchy3_q4, cauchy3_q4_sample_t1900, cauchy3_status)
      if (cauchy3_status /= FMR_CAUCHY3_OK) return
      if (self%swbotb3_explicit_active) then
        if (.not.self%profile_groundwater_projection) return
        select type (low3_physical => state)
        class is (fmr_b110_physical_state_t)
          if (low3_physical%active_nodes /= self%soil_parameters%active_nodes .or. &
              .not. allocated(low3_physical%pressure_head)) return
          call evaluate_b111_profile_groundwater_projection(self%soil_parameters%z,self%soil_parameters%node_distance, &
               low3_physical%pressure_head,low3_physical%ponding_depth,profile_projection)
        class default
          return
        end select
        if(.not.profile_projection%valid.or..not.profile_projection%level_present)return
        allocate(low3_ztop(self%soil_parameters%active_nodes), low3_zbot(self%soil_parameters%active_nodes), &
                 low3_ksat(self%soil_parameters%active_nodes))
        do low3_i=1,self%soil_parameters%active_nodes
          low3_ztop(low3_i)=self%soil_parameters%z(low3_i)+0.5_real64*self%soil_parameters%dz(low3_i)
          low3_zbot(low3_i)=self%soil_parameters%z(low3_i)-0.5_real64*self%soil_parameters%dz(low3_i)
          call evaluate_b110_default_mvg_conductivity(self%hydraulic_parameters,low3_i,0.0_real64,low3_ksat(low3_i),low3_k_ok)
          if(.not.low3_k_ok)return
        end do
        call evaluate_b111_explicit_cauchy_profile_flux(profile_projection%level_cm, &
             self%swbotb3_explicit_hdrain_cm,self%swbotb3_explicit_shape_3,self%cauchy3_proposal%aquifer_total_head_cm, &
             self%legacy_swbotb3_implicit_control%external_resistance_days(),low3_ztop,low3_zbot,self%soil_parameters%dz, &
             low3_ksat,cauchy3_q4,low3_qbot,low3_gwlmean, &
             low3_cvalprof,low3_status)
        if(low3_status/=B111_EXPLICIT_CAUCHY_OK)return
        request%boundary%bottom_mode = 2
        request%boundary%bottom_flux = low3_qbot
        self%last_observation%cauchy3_explicit_active = .true.
        self%last_observation%cauchy3_explicit_qbot_cm_per_day = low3_qbot
        self%last_observation%cauchy3_explicit_gwlmean_cm = low3_gwlmean
        self%last_observation%cauchy3_explicit_profile_resistance_day = low3_cvalprof
      else
        request%boundary%bottom_mode = 3
        request%boundary%bottom_head = self%cauchy3_proposal%aquifer_total_head_cm
        request%boundary%bottom_flux = cauchy3_q4
        request%boundary%bottom_external_resistance_days = &
             self%legacy_swbotb3_implicit_control%external_resistance_days()
        request%boundary%bottom_include_half_cell = self%legacy_swbotb3_implicit_control%half_cell_enabled()
      end if
      self%last_observation%cauchy3_proposal_available = .true.
      self%last_observation%cauchy3_proposed_t0 = self%cauchy3_proposal%t0
      self%last_observation%cauchy3_proposed_t1 = self%cauchy3_proposal%original_t1
      self%last_observation%cauchy3_head_sample_t1900 = self%cauchy3_proposal%legacy_head_sample_t1900
      self%last_observation%cauchy3_sine_phase_day = self%cauchy3_proposal%sine_phase_day
      self%last_observation%cauchy3_aquifer_head_cm = self%cauchy3_proposal%aquifer_total_head_cm
      self%last_observation%cauchy3_q4_sample_t1900 = cauchy3_q4_sample_t1900
      self%last_observation%cauchy3_q4_cm_per_day = cauchy3_q4
    end if
    if (allocated(self%legacy_swbotb5_control)) then
      if (.not. self%hbot5_proposal%covers(t0,t1)) return
      request%boundary%bottom_head = self%hbot5_proposal%pressure_head_cm
      self%last_observation%hbot5_proposal_available = .true.
      self%last_observation%hbot5_proposed_t0 = self%hbot5_proposal%t0
      self%last_observation%hbot5_proposed_t1 = self%hbot5_proposal%original_t1
      self%last_observation%hbot5_sample_t1900 = self%hbot5_proposal%legacy_sample_t1900
      self%last_observation%hbot5_pressure_head_cm = self%hbot5_proposal%pressure_head_cm
    end if
    request%numerical%consistent_provider_conductivity=self%weather_surface_active
    request%numerical%reuse_trial_head=self%weather_surface_active.and.self%weather_trial_warm_start
    request%numerical%abort_failed_line_search=self%weather_surface_active.and.self%weather_line_search_retry
    request%numerical%max_iterations = self%max_iterations
    request%numerical%max_backtracking = self%max_backtracking
    request%numerical%conductivity_implicit_mode = self%swkimpl
    request%numerical%picard_conductivity_iteration = self%picard_conductivity_iteration
    request%numerical%conductivity_mean_method = self%swkmean
    request%numerical%min_step_duration = self%min_step_duration
    request%numerical%compartment_balance_tolerance = max(self%compartment_balance_tolerance, &
         FMR_REFERENCE_BALANCE_FLOOR_DEPTH_CM / step_duration)
    request%numerical%total_balance_tolerance = max(self%total_balance_tolerance, &
         FMR_REFERENCE_BALANCE_FLOOR_DEPTH_CM / step_duration)
    self%last_observation%effective_reference_compartment_balance_tolerance = &
         request%numerical%compartment_balance_tolerance
    self%last_observation%effective_reference_total_balance_tolerance = &
         request%numerical%total_balance_tolerance
    request%numerical%head_abs_tolerance = self%head_abs_tolerance
    request%numerical%head_rel_tolerance = self%head_rel_tolerance
    request%numerical%ponding_tolerance = self%ponding_tolerance
    if (self%macropore_active .and. allocated(self%macropore_config)) then
      if (allocated(self%macropore_config%matrix_area_fraction)) &
           request%physical%matrix_area_fraction = self%macropore_config%matrix_area_fraction
    end if
    select type (physical => state)
    class is (fmr_b110_physical_state_t)
      if (physical%active_nodes /= self%soil_parameters%active_nodes .or. .not. allocated(physical%pressure_head) .or. &
          .not. allocated(physical%water_content)) return
      if(self%reactive_solute_active.neqv.allocated(physical%reactive_solute))return
      if(self%reactive_solute_active)then
        if(.not.physical%reactive_solute%ready().or.allocated(physical%salt))return
      end if
      if (allocated(self%micro_de_willigen)) then
        if (.not. allocated(self%micro_root_length_density) .or. .not. allocated(self%micro_tables)) return
        if (size(physical%pressure_head) /= physical%active_nodes) return
        if(self%rutter_active)self%root_potential_transpiration=rutter_process_result%potential_transpiration_cm_per_day
        call evaluate_micro_de_willigen(self%micro_de_willigen, physical%pressure_head, self%soil_parameters%dz, &
             self%micro_root_length_density, spread(1.0_real64,1,physical%active_nodes), &
             self%micro_rooted_nodes, self%root_potential_transpiration, self%micro_tables, micro_result)
        if (micro_result%status /= MICRO_DW_OK) return
        self%qrot = micro_result%root_extraction_sink
        self%root_potential_sink = micro_result%potential_root_sink
        self%root_drought_reduction_total = max(0.0_real64, &
             self%root_potential_transpiration-micro_result%actual_uptake_total)
      end if
      if (self%snow_active) then
        if (.not. allocated(physical%snow) .or. .not. self%snow_event_prepared) return
        if (.not. physical%snow%event_applied .or. .not. same_real_bits(physical%snow%event_t0, self%snow_outer_t0)) then
          physical%snow%process = self%snow_candidate
          physical%snow%event_applied = .true.
          physical%snow%event_t0 = self%snow_outer_t0
          snow_event_applied_this_call = .true.
        end if
      else
        if (allocated(physical%snow)) return
      end if
      request%base_state%active_nodes = physical%active_nodes
      allocate(request%base_state%pressure_head(physical%active_nodes), request%base_state%water_content(physical%active_nodes))
      request%base_state%pressure_head = physical%pressure_head
      request%base_state%water_content = physical%water_content
      request%base_state%ponding_depth = physical%ponding_depth
      request%base_state%groundwater_level = physical%groundwater_level
      if (self%macropore_active) then
        if (.not. allocated(physical%macropore) .or. .not. allocated(self%macropore_config)) return
        if (.not. physical%macropore%ready()) return
      else
        if (allocated(physical%macropore)) return
      end if

      if (self%black_evaporation_active) then
        select type (black_physical => state)
        type is (fmr_b110_black_evaporation_state_t)
          black_process_forcing = black_evaporation_forcing_t()
          black_process_forcing%potential_bare_soil_evaporation = &
               self%black_evaporation_forcing%potential_bare_soil_evaporation_cm_per_day
          black_process_forcing%surface_is_ponded = &
               black_physical%ponding_depth > BLACK_EVAP_PONDING_CLASSIFICATION_CM
          black_process_forcing%wetting_reset_event = self%black_evaporation_forcing%wetting_reset_event .and. &
               same_real_bits(t0, self%black_evaporation_forcing%wetting_event_time)
          black_process_forcing%wetting_reset_event=black_process_forcing%wetting_reset_event.or. &
               self%black_evaporation_forcing%wetting_reset_each_trial
          if(self%rutter_active)then
            if(.not.ieee_is_finite(self%black_evaporation_forcing%significant_wetting_cm))return
            if(self%black_evaporation_forcing%significant_wetting_cm<0.0_real64)return
            black_process_forcing%wetting_reset_event=rutter_process_result%net_rain_cm_per_day+ &
                 rutter_process_result%net_surface_irrigation_cm_per_day>self%black_evaporation_forcing%significant_wetting_cm
          end if
          call evaluate_black_evaporation_reduction(self%black_evaporation_parameters, &
               black_physical%black_evaporation, black_process_forcing, step_duration, black_result)
          self%last_observation%black_evaporation_evaluated = black_result%status == BLACK_EVAP_AVAILABLE
          self%last_observation%black_wetting_reset_applied = black_result%wetting_reset_applied
          self%last_observation%black_ponding_reset_applied = black_result%ponding_reset_applied
          self%last_observation%black_empirical_demand = black_result%empirical_bare_soil_evaporation_demand
          self%last_observation%black_candidate_ldwet = black_result%candidate_state%ldwet
          if (black_result%status /= BLACK_EVAP_AVAILABLE) return
          call evaluate_b110_default_mvg_conductivity(self%hydraulic_parameters, 1, &
               black_physical%pressure_head(1), fixed_top_conductivity, fixed_top_conductivity_ok)
          if (.not. fixed_top_conductivity_ok) return
          call bind_b110_dynamic_top_boundary_solver_provider(black_top_provider, self%soil_parameters, &
               self%hydraulic_parameters, self%swkmean, black_physical%ponding_depth, step_duration, &
               self%black_evaporation_forcing%precipitation_rate_cm_per_day, &
               self%black_evaporation_forcing%irrigation_rate_cm_per_day, &
               self%black_evaporation_forcing%snowmelt_rate_cm_per_day, &
               self%black_evaporation_forcing%runon_rate_cm_per_day, &
               black_result%empirical_bare_soil_evaporation_demand, &
               self%black_evaporation_forcing%potential_pond_evaporation_cm_per_day, &
               self%black_evaporation_forcing%ponding_max_cm, &
               self%black_evaporation_forcing%runoff_resistance_day, &
               self%black_evaporation_forcing%runoff_exponent, fixed_top_conductivity)
          request%evaluation%dynamic_top_boundary => black_top_provider
        class default
          return
        end select
      end if

      if (self%boesten_evaporation_active) then
        select type (boesten_physical => state)
        class is (fmr_b110_boesten_evaporation_state_t)
          boesten_process_forcing = boesten_evaporation_forcing_t()
          boesten_process_forcing%potential_bare_soil_evaporation = &
               self%boesten_evaporation_forcing%potential_bare_soil_evaporation_cm_per_day
          if (self%rutter_active) then
            boesten_process_forcing%wetting_rate = rutter_process_result%net_rain_cm_per_day + &
                 rutter_process_result%net_surface_irrigation_cm_per_day
          else
            boesten_process_forcing%wetting_rate = self%boesten_evaporation_forcing%precipitation_rate_cm_per_day + &
                 self%boesten_evaporation_forcing%irrigation_rate_cm_per_day
          end if
          self%last_observation%boesten_wetting_rate_cm_per_day = boesten_process_forcing%wetting_rate
          boesten_process_forcing%surface_is_ponded = &
               boesten_physical%ponding_depth > BOESTEN_EVAP_PONDING_CLASSIFICATION_CM
          call evaluate_boesten_evaporation_reduction(self%boesten_evaporation_parameters, &
               boesten_physical%boesten_evaporation, boesten_process_forcing, step_duration, boesten_result)
          self%last_observation%boesten_evaporation_evaluated = boesten_result%status == BOESTEN_EVAP_AVAILABLE
          self%last_observation%boesten_ponding_reset_applied = boesten_result%ponding_reset_applied
          self%last_observation%boesten_empirical_demand = boesten_result%empirical_bare_soil_evaporation_demand
          self%last_observation%boesten_candidate_spev = boesten_result%candidate_state%spev
          self%last_observation%boesten_candidate_saev = boesten_result%candidate_state%saev
          if (boesten_result%status /= BOESTEN_EVAP_AVAILABLE) return
          call evaluate_b110_default_mvg_conductivity(self%hydraulic_parameters, 1, &
               boesten_physical%pressure_head(1), fixed_top_conductivity, fixed_top_conductivity_ok)
          if (.not. fixed_top_conductivity_ok) return
          call bind_b110_dynamic_top_boundary_solver_provider(boesten_top_provider, self%soil_parameters, &
               self%hydraulic_parameters, self%swkmean, boesten_physical%ponding_depth, step_duration, &
               self%boesten_evaporation_forcing%precipitation_rate_cm_per_day, &
               self%boesten_evaporation_forcing%irrigation_rate_cm_per_day, &
               self%boesten_evaporation_forcing%snowmelt_rate_cm_per_day, &
               self%boesten_evaporation_forcing%runon_rate_cm_per_day, &
               boesten_result%empirical_bare_soil_evaporation_demand, &
               self%boesten_evaporation_forcing%potential_pond_evaporation_cm_per_day, &
               self%boesten_evaporation_forcing%ponding_max_cm, &
               self%boesten_evaporation_forcing%runoff_resistance_day, &
               self%boesten_evaporation_forcing%runoff_exponent, fixed_top_conductivity)
          boesten_top_provider%matrix_source_area_partition = self%macropore_top_input_forcing%supplied
          ! Boesten is valid without macropores. The optional configuration is
          ! allocated only for active macropores; Fortran does not guarantee
          ! short-circuit evaluation of a combined ALLOCATED/.AND. condition.
          if (allocated(self%macropore_config)) then
            if(self%macropore_config%surface_pond_inflow_enabled)then
              boesten_top_provider%macropore_pond_donor_active=.true.
              if(self%macropore_config%variable_surface_conductivity) &
                boesten_top_provider%macropore_polygon_diameter= &
                self%macropore_config%geometry%characteristic_diameter(self%macropore_config%geometry%top_node)
              boesten_top_provider%macropore_pond_threshold=self%macropore_config%surface_pond_threshold_cm
              boesten_top_provider%macropore_surface_conductivity= &
                   self%macropore_config%surface_macropore_conductivity_cm_per_day
            end if
          end if
          request%evaluation%dynamic_top_boundary => boesten_top_provider
        class default
          return
        end select
      end if

      if(self%frost_response_drainage_active)then
        ! Generate from this original trial-start view before applying frost.
        call build_process_hydraulic_view(request%base_state,hydraulic_start,hydraulic_view_ok)
        if(.not.hydraulic_view_ok)return
        call evaluate_fmr_drainage_response_bottom_lumped(self%drainage_response_levels,self%drainage_response_controls, &
             hydraulic_start,self%qdra,self%drainage_response_diagnostics)
        self%drainage_response_evaluations=self%drainage_response_evaluations+1
        self%last_observation%drainage_response_evaluations=self%drainage_response_evaluations
        self%last_observation%drainage_response=self%drainage_response_diagnostics
        if(self%drainage_response_diagnostics%status/=FMR_DRAIN_BIND_OK)return
        self%unfrozen_drainage_flux=self%qdra
      end if

      if (self%soil_temperature_active) then
        if (.not. allocated(physical%soil_temperature) .or. .not. allocated(self%soil_temperature_parameters) .or. &
            .not. allocated(self%soil_temperature_forcing)) return
        if (self%frost_active) then
          call build_soil_temperature_field_view(physical%soil_temperature, frost_thermal, soil_temperature_status)
          if (soil_temperature_status /= SOIL_TEMP_OK) then
            self%last_observation%frost_hydraulic_status = soil_temperature_status
            return
          end if
          allocate(frost_factors(frost_thermal%active_nodes))
          call evaluate_frost_hydraulic_factor(self%frost_hydraulic, frost_thermal%temperature_c, &
               frost_factors, frost_status)
          self%last_observation%frost_hydraulic_executed = .true.
          self%last_observation%frost_hydraulic_status = frost_status
          if (frost_status /= FROST_EFFECT_OK) return
          self%last_observation%frost_factor_min = minval(frost_factors)
          self%last_observation%frost_factor_max = maxval(frost_factors)
          if(self%frost_divdra_active)then
            if(allocated(physical%salt))return
            call build_process_hydraulic_view(request%base_state,hydraulic_start,hydraulic_view_ok)
            if(.not.hydraulic_view_ok)return
            call evaluate_legacy_bracketed_frost_geometry(frost_thermal%temperature_c, &
                 self%soil_temperature_forcing%prescribed_surface_temperature_c, &
                 self%frost_hydraulic%reduction_start_c,self%frost_hydraulic%reduction_end_c, &
                 self%soil_parameters%z,self%soil_parameters%node_distance,self%last_observation%frost_divdra_geometry)
            self%last_observation%frost_divdra_raw_scalar=self%frost_divdra_scalar_cm_per_day
            self%last_observation%frost_divdra_start_gwl=hydraulic_start%groundwater_level
            if(.not.self%last_observation%frost_divdra_geometry%available)return
            if(allocated(self%frost_divdra_levels))then
              call compose_multilevel_signed_frost_divdra(self%frost_divdra_levels,hydraulic_start,frost_factors, &
                   self%last_observation%frost_divdra_geometry%deepest_node, &
                   self%last_observation%frost_divdra_geometry%bottom_depth_cm, &
                   physical%water_content,self%hydraulic_parameters%cofgen(2,:), &
                   self%frost_divdra_scalars_cm_per_day,effective_bottom_flux,self%last_observation%frost_multilevel_divdra)
              self%last_observation%frost_divdra_executed=.true.
              if(.not.self%last_observation%frost_multilevel_divdra%available)return
              self%qdra=self%last_observation%frost_multilevel_divdra%final_nodal_sink
              request%boundary%bottom_flux=self%last_observation%frost_multilevel_divdra%final_bottom
            else
            call compose_single_level_signed_frost_divdra(self%frost_divdra,hydraulic_start,frost_factors, &
                 self%last_observation%frost_divdra_geometry%deepest_node, &
                 self%last_observation%frost_divdra_geometry%bottom_depth_cm, &
                 physical%water_content,self%hydraulic_parameters%cofgen(2,:), &
                 self%frost_divdra_scalar_cm_per_day,effective_bottom_flux,self%last_observation%frost_divdra)
            self%last_observation%frost_divdra_executed=.true.
            if(.not.self%last_observation%frost_divdra%available)return
            self%qdra(1,:)=self%last_observation%frost_divdra%final_nodal_sink
            request%boundary%bottom_flux=self%last_observation%frost_divdra%final_bottom
            end if
          else if(self%frost_drainage%active)then
            if(allocated(physical%salt).or..not.allocated(self%unfrozen_drainage_flux))return
            if(self%frost_low_air_drainage%active)then
              call compose_legacy_bracketed_frost_drainage(frost_thermal%temperature_c, &
                   self%soil_temperature_forcing%prescribed_surface_temperature_c,self%frost_hydraulic%reduction_start_c, &
                   self%frost_hydraulic%reduction_end_c,physical%water_content,self%hydraulic_parameters%cofgen(2,:), &
                   self%soil_parameters%dz,frost_factors,self%soil_parameters%z,self%soil_parameters%node_distance, &
                   self%frost_low_air_drainage%drain_depth_cm,self%unfrozen_drainage_flux,effective_bottom_flux, &
                   self%qdra,self%last_observation%frost_low_air_drainage)
              self%last_observation%frost_drainage_executed=.true.
              self%last_observation%frost_drainage=self%last_observation%frost_low_air_drainage%drainage
              if(.not.self%last_observation%frost_low_air_drainage%available)return
              request%boundary%bottom_flux=self%last_observation%frost_low_air_drainage%final_bottom_flux
            else
            call compose_legacy_normal_frost_drainage(.true.,frost_thermal%temperature_c, &
                 self%frost_hydraulic%reduction_end_c,physical%water_content,self%hydraulic_parameters%cofgen(2,:), &
                 self%soil_parameters%dz,frost_factors,self%unfrozen_drainage_flux,self%qdra, &
                 self%last_observation%frost_drainage)
            self%last_observation%frost_drainage_executed=.true.
            if(self%last_observation%frost_drainage%status/=FROST_DRAIN_OK)return
            end if
          end if
          if(self%frost_bottom%active)then
            if(allocated(physical%salt))return
            call compose_legacy_no_drain_frost_bottom(.true.,frost_thermal%temperature_c, &
                 self%frost_hydraulic%reduction_end_c,physical%water_content,self%hydraulic_parameters%cofgen(2,:), &
                 self%soil_parameters%dz,frost_factors,effective_bottom_flux,frost_bottom_result)
            self%last_observation%frost_bottom_executed=.true.
            self%last_observation%frost_bottom=frost_bottom_result
            if(frost_bottom_result%status/=FROST_BOTTOM_OK.or..not.frost_bottom_result%available)return
            request%boundary%bottom_flux=frost_bottom_result%final_flux
          end if
        end if
        if (self%bottom_thermal_carrier_active) then
          call soil_temperature_at_node(physical%soil_temperature, physical%active_nodes, bottom_temperature_start_c, &
               bottom_temperature_status)
          bottom_temperature_start_available = bottom_temperature_status == SOIL_TEMP_OK
        end if
      else
        if (allocated(physical%soil_temperature)) return
      end if
      if ((self%soil_temperature_active.or.self%drainage_response_active.or.self%rfm_configuration%enabled).and. &
          .not.self%frost_response_drainage_active) then
        call build_process_hydraulic_view(request%base_state, hydraulic_start, hydraulic_view_ok)
        if (.not. hydraulic_view_ok) return
      end if
      if (self%root_compensation%method /= ROOT_COMP_OFF .or. self%root_frost%active) then
        if (.not. allocated(self%qrot_unmodified)) return
        self%qrot = self%qrot_unmodified
      end if
      if (allocated(self%substep_root)) then
        substep_root_request=self%substep_root%request
        if(self%rutter_active)substep_root_request%potential_transpiration=rutter_process_result%potential_transpiration_cm_per_day
        block
          type(root_water_uptake_flux_result_t) :: roots, compensated
          type(root_compensation_diagnostics_t)::compensated_diagnostics
          integer::compensated_status
          ! Always rebuild from THIS full/half/retry base, never a previous trial.
          call build_process_hydraulic_view(request%base_state, hydraulic_start, hydraulic_view_ok)
          if (.not.hydraulic_view_ok) return
          call evaluate_macro_feddes_drought_uptake(self%substep_root%parameters, hydraulic_start, &
               substep_root_request, roots, self%substep_root_diagnostics)
          if (self%substep_root_diagnostics%status /= ROOT_UPTAKE_OK) return
          if(self%root_compensation%method/=ROOT_COMP_OFF)then
            call compose_jarvis_root_uptake(self%root_compensation,substep_root_request%potential_transpiration,roots, &
              self%substep_root_diagnostics%drought_reduction_total,self%substep_root_diagnostics%oxygen_reduction_total, &
              compensated,compensated_diagnostics,compensated_status)
            if(compensated_status/=ROOT_COMP_OK)return
            self%substep_root_diagnostics%drought_reduction_total=compensated_diagnostics%drought_reduction_total
            self%substep_root_diagnostics%oxygen_reduction_total=compensated_diagnostics%oxygen_reduction_total
            roots=compensated
          end if
          self%qrot = roots%root_extraction_sink
        end block
      end if
      if(allocated(self%bartholomeus)) then
        call select_fmr_bartholomeus_route(self%bartholomeus%selection,oxygen_route,waterfilm_mode)
        if(oxygen_route==FMR_BARTHOLOMEUS_ACTIVE) then
          if(.not.allocated(self%crop_oxygen) .or. .not.allocated(physical%soil_temperature)) return
          call build_soil_temperature_field_view(physical%soil_temperature,oxygen_thermal,oxygen_status)
          if(oxygen_status/=SOIL_TEMP_OK) return
          oxygen_nodes=size(self%crop_oxygen%root_density_kg_m3)
          allocate(oxygen_w_root(oxygen_nodes))
          oxygen_w_root=1.0_real64/self%bartholomeus%specific_root_length_m_kg
          atmospheric_ctop=672.0_real64/(8.314472_real64*(self%crop_oxygen%air_temperature_c+273.0_real64))
          ! A source substep-root request owns THIS sibling's drought sink.
          ! Preserve the incumbent prescribed-sink route otherwise.
          if(allocated(self%micro_de_willigen).and.self%reactive_solute_active)then
            oxygen_base%root_extraction_sink=self%root_potential_sink
            oxygen_base%actual_uptake_total=sum(self%root_potential_sink)
          else if(allocated(self%substep_root))then
            oxygen_base%root_extraction_sink=self%qrot
            oxygen_base%actual_uptake_total=sum(self%qrot)
          else
            oxygen_base%root_extraction_sink=self%qrot_unmodified
            oxygen_base%actual_uptake_total=sum(self%qrot_unmodified)
          end if
          call fmr_apply_bartholomeus_to_root_sink(self%bartholomeus%selection,hydraulic_start,oxygen_thermal, &
               self%bartholomeus%soil,self%bartholomeus%crop,oxygen_w_root, &
               self%crop_oxygen%root_density_kg_m3,atmospheric_ctop,oxygen_base,oxygen_final,oxygen_status,oxygen_factors)
          self%last_observation%bartholomeus_executed=.true.
          self%last_observation%bartholomeus_status=oxygen_status
          self%last_observation%root_oxygen_base_uptake=oxygen_base%actual_uptake_total
          if(oxygen_status/=FMR_BARTHOLOMEUS_EXEC_OK) return
          if(oxygen_nodes>0)self%last_observation%deepest_root_oxygen_factor=oxygen_factors(oxygen_nodes)
          self%qrot=oxygen_final%root_extraction_sink
          self%last_observation%root_oxygen_final_uptake=oxygen_final%actual_uptake_total
          self%last_observation%root_oxygen_final_sink=oxygen_final%root_extraction_sink
        else if(oxygen_route/=FMR_BARTHOLOMEUS_DISABLED) then
          return
        end if
      end if
      if(self%root_frost%active) then
        block
          type(root_water_uptake_flux_result_t)::root_base,root_final
          real(real64)::frost_loss
          integer::root_status
          root_base%root_extraction_sink=self%qrot
          root_base%actual_uptake_total=sum(self%qrot)
          call compose_legacy_zero_root_frost(self%root_frost,frost_thermal%temperature_c, &
               root_base,root_final,root_frost_factors,frost_loss,root_status)
          self%last_observation%root_frost_executed=.true.
          self%last_observation%root_frost_status=root_status
          if(root_status/=ROOT_FROST_OK) return
          self%last_observation%root_frost_loss=frost_loss
          self%last_observation%root_frost_final_sink=root_final%root_extraction_sink
          self%qrot=root_final%root_extraction_sink
        end block
      end if
      salinity_loss_total = 0.0_real64
      if(self%reactive_salinity_active)then
        if(.not.allocated(physical%reactive_solute).or..not.allocated(self%root_potential_sink))return
        call physical%reactive_solute%root_salinity_view(t0,physical%water_content,self%soil_parameters%dz, &
             self%root_potential_sink,self%saltmax_mg_cm3,self%saltslope_cm3_mg,salinity_cml,salinity_alpha, &
             salinity_sink,salinity_node_loss,salinity_loss_rate,salinity_status)
        if(salinity_status/=SALINITY_OK)return
        root_after_oxygen=self%qrot
        if(.not.allocated(self%micro_de_willigen))self%qrot=self%qrot*salinity_alpha
        self%last_observation%root_salinity_executed=.true.
        self%last_observation%root_salinity_status=salinity_status
        self%last_observation%root_salinity_alpha=salinity_alpha
        self%last_observation%root_salinity_cml_mg_cm3=salinity_cml
        self%last_observation%root_salinity_base_uptake=sum(root_after_oxygen)
        self%last_observation%root_salinity_final_uptake=sum(self%qrot)
      end if
      if (self%root_salinity_active) then
        if (.not. allocated(physical%salt) .or. .not. allocated(self%root_potential_sink)) return
        if (self%macropore_active) then
          if (.not. allocated(physical%macropore)) return
          if (.not. physical%salt%ready(physical%active_nodes, physical%macropore%num_domains)) return
        else
          if (allocated(physical%macropore)) return
          if (.not. physical%salt%ready(physical%active_nodes)) return
        end if
        salinity_storage_thickness=self%soil_parameters%dz
        if(self%macropore_active)salinity_storage_thickness= &
             self%soil_parameters%dz*self%macropore_config%matrix_area_fraction
        call evaluate_mobile_root_salinity_sink(physical%salt%mass_mg_cm2,physical%water_content, &
             salinity_storage_thickness, &
             self%saltmax_mg_cm3,self%saltslope_cm3_mg,self%root_potential_sink,salinity_cml,salinity_alpha, &
             salinity_sink,salinity_node_loss,salinity_loss_rate,salinity_status)
        self%last_observation%root_salinity_executed = .true.
        self%last_observation%root_salinity_status = salinity_status
        if (salinity_status /= SALINITY_OK) return
        if (.not. associated(self%qrot) .or. size(self%qrot) /= size(salinity_alpha)) return
        root_after_oxygen = self%qrot
        if (.not. allocated(oxygen_factors)) then
          allocate(oxygen_factors(size(self%qrot)))
          oxygen_factors = 1.0_real64
        end if
        self%qrot = self%qrot * salinity_alpha
        self%last_observation%root_salinity_base_uptake = sum(root_after_oxygen)
        self%last_observation%root_salinity_final_uptake = sum(self%qrot)
        self%last_observation%root_salinity_alpha = salinity_alpha
        self%last_observation%root_salinity_cml_mg_cm3 = salinity_cml
      end if
      if(allocated(self%micro_de_willigen).and.self%reactive_solute_active)then
        block
          real(real64),allocatable::combined(:),oxygen(:),salinity(:)
          real(real64)::optimal_actual
          type(micro_de_willigen_result_t)::coupled,optimal
          integer::code
          if(.not.allocated(physical%micro_drought_factor_carry))then
            allocate(physical%micro_drought_factor_carry);physical%micro_drought_factor_carry=0d0
          end if
          allocate(oxygen(physical%active_nodes),salinity(physical%active_nodes));oxygen=1d0;salinity=1d0
          if(allocated(oxygen_factors))oxygen=oxygen_factors
          if(allocated(salinity_alpha))salinity=salinity_alpha
          if(self%micro_combined_stress_mode==1)then
            combined=oxygen*salinity
          else
            combined=min(oxygen,salinity)
          end if
          call evaluate_micro_de_willigen(self%micro_de_willigen,physical%pressure_head,self%soil_parameters%dz, &
               self%micro_root_length_density,combined,self%micro_rooted_nodes,self%root_potential_transpiration, &
               self%micro_tables,coupled)
          if(coupled%status/=MICRO_DW_OK)return
          optimal_actual=micro_result%actual_uptake_total
          call attribute_micro_root_stress_losses(self%soil_parameters%dz,self%micro_root_length_density,oxygen,salinity, &
               self%micro_rooted_nodes,self%root_potential_transpiration,coupled%actual_uptake_total, &
               self%micro_maximum_drought,optimal_actual,self%last_observation%micro_drought_loss, &
               self%last_observation%micro_oxygen_loss,self%last_observation%micro_salinity_loss, &
               self%last_observation%micro_drought_factor,code, &
               previous_drought_factor=physical%micro_drought_factor_carry)
          if(code/=MICRO_DW_OK)return
          physical%micro_drought_factor_carry=self%last_observation%micro_drought_factor
          self%qrot=coupled%root_extraction_sink
          self%root_potential_sink=coupled%potential_root_sink
          self%root_drought_reduction_total=self%last_observation%micro_drought_loss
        end block
      end if
      if (self%root_compensation%method /= ROOT_COMP_OFF.and..not.allocated(self%substep_root)) then
        block
          type(root_water_uptake_flux_result_t) :: compensation_base, compensation_final
          type(root_water_uptake_diagnostics_t) :: compensation_base_diagnostics
          type(root_compensation_diagnostics_t) :: compensation_diagnostics
          real(real64) :: oxygen_reduction_total, frost_reduction_total
          integer :: compensation_status,attribution_status
          compensation_base%root_extraction_sink = self%qrot
          compensation_base%actual_uptake_total = sum(self%qrot)
          compensation_base_diagnostics%drought_reduction_total = self%root_drought_reduction_total
          oxygen_reduction_total = sum(self%qrot_unmodified)-compensation_base%actual_uptake_total
          frost_reduction_total=0.0_real64
          if(self%root_frost%active) then
            if(.not.allocated(self%root_potential_sink)) return
            if(abs(sum(self%root_potential_sink)-self%root_potential_transpiration)> &
                 256.0_real64*epsilon(1.0_real64)*max(1.0_real64,self%root_potential_transpiration)) return
            if(.not.allocated(oxygen_factors)) then
              allocate(oxygen_factors(size(self%qrot)));oxygen_factors=1.0_real64
            end if
            if(self%root_salinity_active) then
              call attribute_root_stress_losses(self%root_potential_sink,self%qrot_unmodified,oxygen_factors, &
                   compensation_base_diagnostics%drought_reduction_total,oxygen_reduction_total,attribution_status, &
                   salinity_factor=salinity_alpha,salinity_loss=salinity_loss_total, &
                   frost_factor=root_frost_factors,frost_loss=frost_reduction_total)
            else
            call attribute_root_stress_losses(self%root_potential_sink,self%qrot_unmodified,oxygen_factors, &
                 compensation_base_diagnostics%drought_reduction_total,oxygen_reduction_total,attribution_status, &
                 frost_factor=root_frost_factors,frost_loss=frost_reduction_total)
            end if
            if(attribution_status/=ROOT_COMP_OK) return
          else if(self%root_salinity_active) then
            oxygen_reduction_total = sum(self%qrot_unmodified)-sum(root_after_oxygen)
            if (.not. allocated(self%root_potential_sink)) return
            if (abs(sum(self%root_potential_sink)-self%root_potential_transpiration) > &
                256.0_real64*epsilon(1.0_real64)*max(1.0_real64,self%root_potential_transpiration)) return
            call attribute_root_stress_losses(self%root_potential_sink,self%qrot_unmodified,oxygen_factors, &
                 compensation_base_diagnostics%drought_reduction_total,oxygen_reduction_total,attribution_status, &
                 salinity_factor=salinity_alpha,salinity_loss=salinity_loss_total)
            if (attribution_status /= ROOT_COMP_OK) return
          else if(allocated(oxygen_factors).and.self%root_drought_reduction_total>0.0_real64) then
            ! Mixed stress requires the existing drought owner's potential nodes.
            ! Scalar sequential losses do not reproduce B1.11 apportionment.
            if(.not.allocated(self%root_potential_sink)) return
            if(abs(sum(self%root_potential_sink)-self%root_potential_transpiration)> &
                 256.0_real64*epsilon(1.0_real64)*max(1.0_real64,self%root_potential_transpiration)) return
            call attribute_root_stress_losses(self%root_potential_sink,self%qrot_unmodified,oxygen_factors, &
                 compensation_base_diagnostics%drought_reduction_total,oxygen_reduction_total,attribution_status)
            if(attribution_status/=ROOT_COMP_OK) return
          end if
          call apply_root_uptake_compensation(self%root_compensation,self%root_potential_transpiration, &
               compensation_base,compensation_base_diagnostics,oxygen_reduction_total,compensation_final, &
               compensation_diagnostics,compensation_status,self%root_walsum_geometry,self%soil_parameters%dz, &
               salinity_reduction_total=salinity_loss_total,frost_reduction_total=frost_reduction_total)
          self%last_observation%root_compensation_executed=.true.
          self%last_observation%root_compensation_status=compensation_status
          self%last_observation%root_compensation_base_uptake=compensation_base%actual_uptake_total
          if(compensation_status/=ROOT_COMP_EXEC_OK) return
          self%last_observation%root_compensation_drought_loss=compensation_diagnostics%drought_reduction_total
          self%last_observation%root_compensation_oxygen_loss=compensation_diagnostics%oxygen_reduction_total
          self%last_observation%root_compensation_frost_loss=compensation_diagnostics%frost_reduction_total
          self%last_observation%root_salinity_reduction_total=compensation_diagnostics%salinity_reduction_total
          self%qrot=compensation_final%root_extraction_sink
          self%last_observation%root_compensation_final_uptake=compensation_final%actual_uptake_total
          self%last_observation%root_compensation_final_sink=compensation_final%root_extraction_sink
        end block
      end if
    class default
      return
    end select

    if (self%drainage_response_active.and..not.self%frost_response_drainage_active) then
      drainage_level_present=.true.
      if(allocated(self%drainage_trial_distribution))then
        call evaluate_b111_profile_groundwater_projection(self%soil_parameters%z,self%soil_parameters%node_distance, &
          hydraulic_start%pressure_head,hydraulic_start%ponding_depth,profile_projection)
        if(.not.profile_projection%valid)return
        drainage_level_present=profile_projection%level_present
        if(drainage_level_present)then
          hydraulic_start%groundwater_level=profile_projection%level_cm
          self%last_observation%drainage_qbot_projection_available=.true.
          self%last_observation%drainage_projected_groundwater_level=profile_projection%level_cm
        else
          ! Typed absence is not a fictitious water table. In drainage-only
          ! scope no saturated reservoir exists from which to remove water.
          self%qdra=0.0_real64
          self%drainage_response_diagnostics=fmr_drainage_response_diagnostics_t()
          self%drainage_response_diagnostics%status=FMR_DRAIN_BIND_OK
        end if
      else if (self%drainage_qbot_smooth_freatic_projection) then
        if (.not. allocated(self%projection_zero_direction) .or. &
            size(self%projection_zero_direction) /= hydraulic_start%active_nodes) return
        call evaluate_b110_smooth_freatic_projection(self%bottom_mode, .false., self%soil_parameters%z, &
             self%soil_parameters%node_distance, hydraulic_start%pressure_head, self%projection_zero_direction, &
             projected_groundwater_level, ignored_groundwater_direction, projection_diagnostics)
        if (projection_diagnostics%status /= B110_GWL_PROJECTION_OK .or. &
            .not. projection_diagnostics%value_defined) return
        hydraulic_start%groundwater_level = projected_groundwater_level
        request%base_state%groundwater_level = projected_groundwater_level
        self%last_observation%drainage_qbot_projection_available = .true.
        self%last_observation%drainage_projected_groundwater_level = projected_groundwater_level
      end if
      if(drainage_level_present)then
      if(any(self%drainage_response_levels%variant==FMR_DRAIN_VARIANT_DRAMET3))then
        ! t1 belongs to this actual full/half/retry trial. The channel resolver
        ! maps it to the immutable legacy epoch; it owns no advancing clock.
        call evaluate_fmr_drainage_response_bottom_lumped(self%drainage_response_levels,self%drainage_response_controls, &
             hydraulic_start,self%qdra,self%drainage_response_diagnostics,substep_t1=t1)
      else
      call evaluate_fmr_drainage_response_bottom_lumped(self%drainage_response_levels, self%drainage_response_controls, &
           hydraulic_start, self%qdra, self%drainage_response_diagnostics)
      end if
      self%drainage_response_evaluations = self%drainage_response_evaluations + 1
      self%last_observation%drainage_response_evaluations = self%drainage_response_evaluations
      self%last_observation%drainage_response = self%drainage_response_diagnostics
      if (self%drainage_response_diagnostics%status /= FMR_DRAIN_BIND_OK) return
      if(allocated(self%drainage_trial_distribution))then
        block
          type(drainage_node_transfer_t)::partition
          type(drainage_distribution_diagnostics_t)::diagnostic
          ! The existing response owns the scalar. DIVDRA owns its nodal
          ! partition. Exactly this qdra reaches Richards and its accepted trace.
          call distribute_single_level_signed_divdra(self%drainage_trial_distribution,hydraulic_start, &
            sum(self%qdra),partition,diagnostic)
          if(diagnostic%status/=DRAIN_DIST_OK)return
          self%qdra(1,:)=partition%soil_to_drain_rate
        end block
      end if
      end if
    end if

    if (self%root_extraction_active) then
      if (.not. associated(self%qrot_zero) .or. size(self%qrot_zero) /= size(self%qrot)) return
      call bind_b110_source_sink_provider(self%source_sink, self%qdra, self%qssdi, self%qrot_zero)
      call bind_b110_root_sink_provider(self%root_sink, self%qrot)
    else
      call bind_b110_source_sink_provider(self%source_sink, self%qdra, self%qssdi, self%qrot)
    end if
    if (self%frost_active) then
      if (.not. allocated(frost_factors)) return
      if (self%direct_retention_active) then
        call bind_frost_constitutive_provider(self%frost_constitutive, self%direct_retention_constitutive, &
             frost_factors, frost_provider_status)
      else
        call bind_frost_constitutive_provider(self%frost_constitutive, self%constitutive, frost_factors, &
             frost_provider_status)
      end if
      if (frost_provider_status /= FROST_PROVIDER_OK) then
        self%last_observation%frost_hydraulic_status = -frost_provider_status
        return
      end if
      request%evaluation%constitutive => self%frost_constitutive
    else if (allocated(self%linear_table_parameters)) then
      request%evaluation%constitutive => self%linear_table_constitutive
    else if (self%extended_hydraulics_active) then
      request%evaluation%constitutive => self%extended_constitutive
    else if (self%analytical_hydraulics_active) then
      request%evaluation%constitutive => self%analytical_constitutive
    else if (self%direct_retention_active) then
      request%evaluation%constitutive => self%direct_retention_constitutive
    else
      request%evaluation%constitutive => self%constitutive
    end if

    if (self%rfm_configuration%enabled) then
      if (self%direct_retention_active) return
      if (.not. self%soil_water_selection%uses_reference()) return
      select type (rfm_physical => state)
      type is (fmr_b110_rfm_state_t)
        if (.not. rfm_physical%rfm%ready()) return
        call bind_b110_dynamic_top_boundary_solver_provider(rfm_top_provider, self%soil_parameters, &
             self%hydraulic_parameters, self%swkmean, rfm_physical%ponding_depth, step_duration, &
             self%rfm_surface_forcing%precipitation_rate_cm_per_day, self%rfm_surface_forcing%irrigation_rate_cm_per_day, &
             self%rfm_surface_forcing%snowmelt_rate_cm_per_day, self%rfm_surface_forcing%runon_rate_cm_per_day, &
             self%rfm_surface_forcing%potential_bare_soil_evaporation_cm_per_day, &
             self%rfm_surface_forcing%potential_pond_evaporation_cm_per_day, self%rfm_surface_forcing%ponding_max_cm, &
             self%rfm_surface_forcing%runoff_resistance_day, self%rfm_surface_forcing%runoff_exponent)
        call rfm_top_provider%evaluate(rfm_physical%pressure_head(1), rfm_physical%water_content(1), &
             rfm_physical%ponding_depth, request%boundary, rfm_preflight)
        allocate(rfm_node_depth_cm(rfm_physical%active_nodes)); rfm_node_depth_cm=abs(self%soil_parameters%z)
        call prepare_rfm_live_trial(rfm_physical%rfm,self%rfm_configuration,self%rfm_surface_forcing,hydraulic_start, &
             self%constitutive,rfm_preflight,rfm_node_depth_cm,self%soil_parameters%dz,step_duration, &
             max(self%compartment_balance_tolerance,FMR_REFERENCE_BALANCE_FLOOR_DEPTH_CM),rfm_live)
        if(.not.rfm_live%valid)return
        rfm_source_rate=rfm_live%candidate%matrix_source_rate_per_day
        call bind_rfm_matrix_source_provider(rfm_source_provider,self%source_sink,rfm_source_rate,rfm_source_ok)
        if(.not.rfm_source_ok)return
        request%evaluation%source_sink=>rfm_source_provider
        rfm_preferential_input_cm=rfm_live%surface%preferential_supply_cm_per_day*step_duration
        rfm_deep_receipt_cm=rfm_live%candidate%deep_receipt_cm
        call bind_b110_dynamic_top_boundary_solver_provider(rfm_top_provider,self%soil_parameters,self%hydraulic_parameters, &
             self%swkmean,rfm_physical%ponding_depth,step_duration,rfm_live%surface%matrix_supply_cm_per_day, &
             0.0_real64,0.0_real64,0.0_real64,0.0_real64,0.0_real64,self%rfm_surface_forcing%ponding_max_cm, &
             self%rfm_surface_forcing%runoff_resistance_day,self%rfm_surface_forcing%runoff_exponent)
        request%evaluation%dynamic_top_boundary=>rfm_top_provider
      class default
        return
      end select
    else
      request%evaluation%source_sink=>self%source_sink
    end if
    if (self%root_extraction_active) request%evaluation%root_sink => self%root_sink
    if (self%rutter_active) then
      if (.not. rutter_trial_prepared) return
      if (self%boesten_evaporation_active) then
        call bind_b110_dynamic_top_boundary_solver_provider(rutter_top_provider, self%soil_parameters, &
             self%hydraulic_parameters, self%swkmean, rutter_previous_ponding, step_duration, &
             rutter_process_result%net_rain_cm_per_day, rutter_process_result%net_surface_irrigation_cm_per_day, &
             self%rutter_forcing%snowmelt_rate_cm_per_day, self%rutter_forcing%runon_rate_cm_per_day, &
             boesten_result%empirical_bare_soil_evaporation_demand, &
             self%rutter_forcing%potential_pond_evaporation_cm_per_day, self%rutter_forcing%ponding_max_cm, &
             self%rutter_forcing%runoff_resistance_day, self%rutter_forcing%runoff_exponent)
      end if
      if(self%black_evaporation_active)then
        call bind_b110_dynamic_top_boundary_solver_provider(rutter_top_provider,self%soil_parameters, &
             self%hydraulic_parameters,self%swkmean,rutter_previous_ponding,step_duration, &
             rutter_process_result%net_rain_cm_per_day,rutter_process_result%net_surface_irrigation_cm_per_day, &
             self%rutter_forcing%snowmelt_rate_cm_per_day,self%rutter_forcing%runon_rate_cm_per_day, &
             black_result%empirical_bare_soil_evaporation_demand,self%rutter_forcing%potential_pond_evaporation_cm_per_day, &
             self%rutter_forcing%ponding_max_cm,self%rutter_forcing%runoff_resistance_day,self%rutter_forcing%runoff_exponent)
      end if
      if(self%black_evaporation_active)rutter_top_provider%implicit_conductivity=.true.
      if(self%macropore_active.and.self%soil_temperature_active)then
        ! This existing provider evaluates candidate-head conductivity. Supply
        ! its already implemented total-flux derivative when the pond/head
        ! regime becomes active; a missing Jacobian is not a valid fallback.
        rutter_top_provider%implicit_conductivity=.true.
        rutter_top_provider%matrix_source_area_partition=self%rutter_forcing%matrix_source_area_partition
        if(self%macropore_config%surface_pond_inflow_enabled)then
          rutter_top_provider%macropore_pond_donor_active=.true.
          if(self%macropore_config%variable_surface_conductivity) &
            rutter_top_provider%macropore_polygon_diameter= &
            self%macropore_config%geometry%characteristic_diameter(self%macropore_config%geometry%top_node)
          rutter_top_provider%macropore_pond_threshold=self%macropore_config%surface_pond_threshold_cm
          rutter_top_provider%macropore_surface_conductivity= &
            self%macropore_config%surface_macropore_conductivity_cm_per_day
        end if
      end if
      request%evaluation%dynamic_top_boundary => rutter_top_provider
    else if (.not. self%black_evaporation_active .and. .not. self%boesten_evaporation_active) then
      request%evaluation%top_boundary => self%top_boundary
    end if

    if (allocated(self%pond_input)) then
      ! Rebind from this sibling/retry's actual water owner, never from a saved depth.
      select type (physical => state)
      type is (fmr_b110_physical_state_t)
      type is (fmr_b110_temporal_indicator_state_t)
      class default
        return
      end select
      if (.not.ieee_is_finite(request%base_state%ponding_depth)) return
      if (request%base_state%ponding_depth<0.0_real64.or.request%base_state%ponding_depth>1.e6_real64) return
      call evaluate_b110_default_mvg_conductivity(self%hydraulic_parameters,1, &
           request%base_state%pressure_head(1),fixed_top_conductivity,fixed_top_conductivity_ok)
      if (.not.fixed_top_conductivity_ok) return
      call bind_b110_dynamic_top_boundary_solver_provider(rfm_top_provider,self%soil_parameters, &
           self%hydraulic_parameters,self%swkmean,request%base_state%ponding_depth,step_duration, &
           self%pond_input%rain_rate_cm_day,self%pond_input%irrigation_rate_cm_day, &
           0.0_real64,self%pond_input%runon_rate_cm_day, &
           self%pond_input%potential_bare_soil_evaporation_cm_day, &
           self%pond_input%potential_pond_evaporation_cm_day,self%pond_input%ponding_max_cm, &
           self%pond_input%runoff_resistance_day,1.0_real64,fixed_top_conductivity, &
           implicit_pond_evaporation=self%pond_input%implicit_pond_evaporation, &
           implicit_conductivity=self%weather_surface_active)
      request%boundary%top_mode=FSI_TOP_MODE_DYNAMIC_PROVIDER
      nullify(request%evaluation%top_boundary)
      request%evaluation%dynamic_top_boundary=>rfm_top_provider
    end if

    if (self%soil_water_selection%uses_rossfast()) then
      context_ok = .true.
    else
      call bind_b110_serialized_legacy_context(request, context_ok)
    end if
    if (.not. context_ok) return

    if (self%trajectory_direction_requested .and. self%trajectory_provenance_valid) then
      if (.not. allocated(self%trajectory_direction%pressure_head_direction)) then
        if (self%trajectory_generation_counter >= huge(self%trajectory_generation_counter)) then
          self%trajectory_provenance_valid = .false.
        else
          self%trajectory_generation_counter = self%trajectory_generation_counter + 1_int64
          call begin_or_continue_trajectory(self%trajectory_direction, self%trajectory_worker_id, t0, t1, &
               self%trajectory_control_coordinate, self%soil_parameters%active_nodes, trajectory_begin_ok, &
               generation_seed=self%trajectory_generation_counter)
        end if
      else
        call begin_or_continue_trajectory(self%trajectory_direction, self%trajectory_worker_id, t0, t1, &
             self%trajectory_control_coordinate, self%soil_parameters%active_nodes, trajectory_begin_ok)
      end if
      if (trajectory_begin_ok) then
        call build_trajectory_step_request(self%trajectory_direction, t0, t1, self%trajectory_request_workspace, direction_token, &
             trajectory_request_ok)
      end if
    end if

    if (trajectory_request_ok .and. self%trajectory_request_workspace%requested .and. &
        self%drainage_qbot_smooth_freatic_projection) then
      call compose_fmr_qbot_drainage_sink_direction(self%soil_parameters, request%base_state, &
           self%trajectory_request_workspace%incoming_pressure_head, self%drainage_response_diagnostics, drainage_sink_direction, &
           drainage_groundwater_direction, drainage_direction_status, drainage_direction_route)
      drainage_direction_available = drainage_direction_status == FMR_QBOT_DRAIN_DIRECTION_OK
      if (drainage_direction_available) then
        call move_alloc(drainage_sink_direction, self%trajectory_request_workspace%incoming_sink_direction)
      end if
    end if

    if (self%macropore_active) then
      if (self%soil_water_selection%uses_rossfast() .or. trajectory_request_ok) return
      macro_top_input_trial = self%macropore_top_input_forcing
      if (self%rutter_active) then
        macro_top_input_trial%supplied = .true.
        macro_top_input_trial%net_rain_rate_cm_per_day = rutter_process_result%net_rain_cm_per_day
        macro_top_input_trial%net_irrigation_rate_cm_per_day = rutter_process_result%net_surface_irrigation_cm_per_day
        macro_top_input_trial%melt_rate_cm_per_day = self%rutter_forcing%snowmelt_rate_cm_per_day
      end if
      self%last_observation%macropore_top_rain_rate_cm_per_day = macro_top_input_trial%net_rain_rate_cm_per_day
      self%last_observation%macropore_top_irrigation_rate_cm_per_day = &
           macro_top_input_trial%net_irrigation_rate_cm_per_day
      select type (physical_macro => state)
      type is (fmr_b110_macropore_reduction_state_t)
        if(self%accepted_water_flux_trace_enabled.or. &
           self%solute_state_layout_id==FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED_MACROPORE)then
          if(allocated(physical_macro%macropore%water_domain_cp))then
            trace_macro_water_start=physical_macro%macropore%water_domain_cp
          else
            self%accepted_water_flux_trace_failed=.true.
          end if
        end if
        if (self%macropore_config%covering_parameters_available) then
          call self%macropore_runtime%execute(self%solver, self%workspace, request, physical_macro%macropore, &
               self%macropore_config%geometry, self%macropore_config%rate_template, &
               self%macropore_config%history_template, self%macropore_policy, macropore_result, &
               top_input=macro_top_input_trial, reduction_accepted=physical_macro%reduction_continuation, &
               covering_minimum_polygon_diameter_cm=self%macropore_config%covering_minimum_polygon_diameter_cm, &
               covering_ksat_cm_per_day=self%macropore_config%covering_ksat_cm_per_day, &
               shrinkage_config=self%macropore_config%shrinkage, &
               matrix_area_fraction=self%macropore_config%matrix_area_fraction)
        else
          call self%macropore_runtime%execute(self%solver, self%workspace, request, physical_macro%macropore, &
               self%macropore_config%geometry, self%macropore_config%rate_template, &
               self%macropore_config%history_template, self%macropore_policy, macropore_result, &
               top_input=macro_top_input_trial, reduction_accepted=physical_macro%reduction_continuation, &
               shrinkage_config=self%macropore_config%shrinkage, &
               matrix_area_fraction=self%macropore_config%matrix_area_fraction)
        end if
        if(macropore_result%status==MACRO_RUNTIME_CONVERGED) &
             physical_macro%reduction_continuation=macropore_result%reduction_candidate
      class is (fmr_b110_physical_state_t)
        if(self%accepted_water_flux_trace_enabled.or. &
           self%solute_state_layout_id==FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED_MACROPORE)then
          if(allocated(physical_macro%macropore%water_domain_cp))then
            trace_macro_water_start=physical_macro%macropore%water_domain_cp
          else
            self%accepted_water_flux_trace_failed=.true.
          end if
        end if
        if (self%macropore_config%covering_parameters_available) then
          call self%macropore_runtime%execute(self%solver, self%workspace, request, physical_macro%macropore, &
               self%macropore_config%geometry, self%macropore_config%rate_template, &
               self%macropore_config%history_template, self%macropore_policy, macropore_result, &
               top_input=macro_top_input_trial, &
               covering_minimum_polygon_diameter_cm=self%macropore_config%covering_minimum_polygon_diameter_cm, &
               covering_ksat_cm_per_day=self%macropore_config%covering_ksat_cm_per_day, &
               shrinkage_config=self%macropore_config%shrinkage, &
               matrix_area_fraction=self%macropore_config%matrix_area_fraction)
        else
          call self%macropore_runtime%execute(self%solver, self%workspace, request, physical_macro%macropore, &
               self%macropore_config%geometry, self%macropore_config%rate_template, &
               self%macropore_config%history_template, self%macropore_policy, macropore_result, &
               top_input=macro_top_input_trial, &
               shrinkage_config=self%macropore_config%shrinkage, &
               matrix_area_fraction=self%macropore_config%matrix_area_fraction)
        end if
      class default
        return
      end select
      solve_result = macropore_result%matrix_result
      macropore_pond_requested_cm=macropore_result%pond_requested_top_input_cm
      macropore_pond_accepted_cm=macropore_result%pond_accepted_top_input_cm
      macropore_pond_returned_cm=macropore_result%pond_returned_surface_cm
      if (macropore_pond_requested_cm>0.0_real64) then
        if(macropore_pond_accepted_cm<0.0_real64 .or. macropore_pond_returned_cm<0.0_real64 .or. &
           abs(macropore_pond_accepted_cm+macropore_pond_returned_cm-macropore_pond_requested_cm)>1.0e-10_real64)return
        if(macropore_pond_accepted_cm>macropore_result%accepted_top_input_cm+1.0e-10_real64 .or. &
           macropore_pond_returned_cm>macropore_result%returned_surface_cm+1.0e-10_real64)return
        ! All capacity-rejected top water returns to the shared surface donor.
        ! Only the pond-derived accepted share is internal surface-to-macropore
        ! redistribution; direct accepted atmospheric macro input remains an
        ! external inflow in the transaction ledger below.
        solve_result%candidate_state%ponding_depth=solve_result%candidate_state%ponding_depth+ &
             macropore_result%returned_surface_cm
      end if
      self%last_observation%macropore_top_input_active = macro_top_input_trial%supplied
      self%last_observation%macropore_requested_top_cm = macropore_result%requested_top_input_cm
      self%last_observation%macropore_accepted_top_cm = macropore_result%accepted_top_input_cm
      self%last_observation%macropore_returned_surface_cm = macropore_result%returned_surface_cm
      self%last_observation%macropore_pond_requested_cm = macropore_pond_requested_cm
      self%last_observation%macropore_pond_accepted_cm = macropore_pond_accepted_cm
      self%last_observation%macropore_pond_returned_cm = macropore_pond_returned_cm
      self%last_observation%macropore_rapid_drain_active = self%macropore_config%rate_template%rapid%enabled
      self%last_observation%macropore_rapid_outflow_cm = macropore_result%rapid_external_outflow_cm
      self%last_observation%macropore_inner_richards_exchange_used = macropore_result%inner_richards_exchange_used
      self%last_observation%macropore_matrix_source_area_partition_used = &
           macropore_result%matrix_source_area_partition_used
      self%last_observation%macropore_inner_initial_exchange_rate_cm_per_day = &
           macropore_result%inner_initial_exchange_rate_cm_per_day
      self%last_observation%macropore_inner_final_exchange_rate_cm_per_day = &
           macropore_result%inner_final_exchange_rate_cm_per_day
      macropore_accepted_top_cm = macropore_result%accepted_top_input_cm-macropore_pond_accepted_cm
      macropore_rapid_outflow_cm = macropore_result%rapid_external_outflow_cm
      if (.not. ieee_is_finite(macropore_accepted_top_cm) .or. macropore_accepted_top_cm < 0.0_real64) return
      if (.not. ieee_is_finite(macropore_rapid_outflow_cm) .or. macropore_rapid_outflow_cm < 0.0_real64) return
      if (macropore_result%status /= MACRO_RUNTIME_CONVERGED) then
        ! A rejected inner solve consumed real work before this early return.
        ! Preserve its diagnostics even though its physical state is rolled back.
        self%last_observation%solver_executed = solve_result%diagnostics%headcalc_calls>0
        self%last_observation%solver_status = solve_result%status
        self%last_observation%solver_diagnostics = solve_result%diagnostics
        outcome%nonlinear_iterations = solve_result%diagnostics%nonlinear_iterations
        outcome%internal_retries = solve_result%diagnostics%internal_retries
        outcome%headcalc_calls = solve_result%diagnostics%headcalc_calls
        outcome%jacobian_builds = solve_result%diagnostics%jacobian_builds
        outcome%linear_solves = solve_result%diagnostics%linear_solves
        outcome%backtracking_attempts = solve_result%diagnostics%backtracking_attempts
        outcome%alternative_solver_calls = solve_result%diagnostics%alternative_solver_calls
        outcome%workspace_full_resets = solve_result%diagnostics%workspace_full_resets
        outcome%workspace_zeroed_bytes = solve_result%diagnostics%workspace_zeroed_bytes
        if(self%macropore_policy%anchored_cauchy_step_ceiling) &
          call diagnose_macro_rejection(t0,t1,macropore_result)
        if (macropore_result%status == MACRO_RUNTIME_RETRY) solve_result%retry_advised = .true.
        return
      end if
    else if (self%soil_water_selection%uses_rossfast()) then
      call self%soil_water_selection%solve(request, solve_result)
    else if (trajectory_request_ok) then
      if (self%drainage_qbot_smooth_freatic_projection .and. .not. drainage_direction_available) then
        call self%solver%solve(request, self%workspace, solve_result)
        direction_result = soil_water_accepted_step_direction_result_t()
        direction_result%status = SW_STEP_DIRECTION_UNAVAILABLE
        direction_result%control_coordinate = self%trajectory_request_workspace%control_coordinate
        direction_result%route = drainage_direction_route
      else
        call solve_with_accepted_step_direction(self%solver, request, self%workspace, self%trajectory_request_workspace, &
             solve_result, direction_result)
        trajectory_solver_used = .true.
      end if
      call stage_trajectory_step_result(self%trajectory_direction, direction_token, direction_result, trajectory_stage_ok)
    else
      call self%solver%solve(request, self%workspace, solve_result)
    end if

    self%last_observation%solver_executed = .true.
    self%last_observation%solver_status = solve_result%status
    self%last_observation%top_flux = solve_result%top_flux
    self%last_observation%bottom_flux = solve_result%bottom_flux
    self%last_observation%solver_diagnostics = solve_result%diagnostics
    self%last_observation%solver_equation_residual_available = .false.
    call populate_snow_observation(self)
    outcome%nonlinear_iterations = solve_result%diagnostics%nonlinear_iterations
    outcome%internal_retries = solve_result%diagnostics%internal_retries
    if (self%soil_water_selection%uses_rossfast()) then
      outcome%headcalc_calls = 0
    else
      outcome%headcalc_calls = solve_result%diagnostics%headcalc_calls
    end if
    outcome%jacobian_builds = solve_result%diagnostics%jacobian_builds
    outcome%linear_solves = solve_result%diagnostics%linear_solves
    outcome%backtracking_attempts = solve_result%diagnostics%backtracking_attempts
    outcome%alternative_solver_calls = solve_result%diagnostics%alternative_solver_calls
    outcome%workspace_full_resets = solve_result%diagnostics%workspace_full_resets
    if(self%macropore_policy%anchored_cauchy_step_ceiling) &
      call diagnose_macro_step(t0,t1,solve_result%status)
    outcome%workspace_zeroed_bytes = solve_result%diagnostics%workspace_zeroed_bytes
    if (trajectory_solver_used) then
      outcome%linear_solves = outcome%linear_solves + direction_result%additional_tridiagonal_backsolves
      outcome%jacobian_builds = outcome%jacobian_builds + direction_result%additional_jacobian_builds
      outcome%headcalc_calls = outcome%headcalc_calls + direction_result%additional_full_nonlinear_solves
    end if
    if (solve_result%status /= SW_SOLVE_CONVERGED) return
    if (self%hysteresis_active) then
      select type (physical => state)
      class is (fmr_b110_physical_state_t)
        if (.not. allocated(physical%hysteresis) .or. .not. allocated(self%hysteresis_parameters)) return
        block
          type(b111_hysteresis_transition_t), allocatable :: transitions(:)
          integer :: status_hyst, i_hyst
          allocate(transitions(self%soil_parameters%active_nodes))
          call advance_b111_hysteresis_accepted(self%hysteresis_parameters, physical%hysteresis, &
               solve_result%candidate_state%pressure_head, solve_result%candidate_state%water_content, &
               transitions, status_hyst)
          if (status_hyst /= B111_HYST_OK) return
          do i_hyst=1,size(transitions)
            if (transitions(i_hyst)%head_reconstruction_required) &
              solve_result%candidate_state%pressure_head(i_hyst)=transitions(i_hyst)%corrected_head
          end do
        end block
      class default
        return
      end select
    end if
    if (self%solute_state_layout_id /= FMR_SOLUTE_STATE_LAYOUT_NONE) then
      select type (salt_physical => state)
      class is (fmr_b110_physical_state_t)
        if(self%solute_state_layout_id==FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED)then
          call advance_fmr_mobile_salt_step(self,salt_physical,request,solve_result,t0,t1,salt_receipt,salt_status)
        else
          call advance_fmr_mobile_macro_salt_step(self,salt_physical,request,solve_result,macropore_result, &
               trace_macro_water_start,t0,t1,salt_receipt,salt_status)
        end if
        if (salt_status /= MACRO_SALT_OK) then
          self%last_observation%salt_transport_executed = .true.
          self%last_observation%salt_transport_status = salt_status
          return
        end if
        self%last_observation%salt_transport_executed = .true.
        self%last_observation%salt_transport_status = salt_status
        self%last_observation%salt_transport_closure_mg_cm2 = salt_receipt%closure_error_mg_cm2
        self%last_observation%salt_root_uptake_mg_cm2 = sum(salt_receipt%root_solute_uptake_mg_cm2)
        self%last_observation%salt_qdra_signed_out_mg_cm2 = salt_receipt%qdra_signed_out_mg_cm2
      class default
        return
      end select
    end if
    if(allocated(self%drainage_trial_distribution))then
      call evaluate_b111_profile_groundwater_projection(self%soil_parameters%z,self%soil_parameters%node_distance, &
        solve_result%candidate_state%pressure_head,solve_result%candidate_state%ponding_depth,profile_projection)
      if(.not.profile_projection%valid)return
      ! CALCGWL's historical absent diagnostic sentinel; never passed to the
      ! response law. The next trial again evaluates the typed profile view.
      solve_result%candidate_state%groundwater_level=999.0_real64
      if(profile_projection%level_present)solve_result%candidate_state%groundwater_level=profile_projection%level_cm
    else if (self%drainage_qbot_smooth_freatic_projection) then
      call project_fmr_qbot_smooth_groundwater_level(self%soil_parameters, solve_result%candidate_state, &
           candidate_projected_groundwater_level, candidate_projection_status, projection_diagnostics)
      if (candidate_projection_status /= FMR_QBOT_DRAIN_DIRECTION_OK) return
      solve_result%candidate_state%groundwater_level = candidate_projected_groundwater_level
    end if
    if (self%soil_water_selection%uses_rossfast()) then
      call self%soil_water_selection%temporal_certificate_snapshot(rossfast_certificate_available, &
           rossfast_temporal_indicator)
      if (.not. rossfast_certificate_available .or. .not. ieee_is_finite(rossfast_temporal_indicator) .or. &
          rossfast_temporal_indicator < 0.0_real64) return
      outcome%temporal_certificate_available = .true.
      outcome%temporal_indicator = rossfast_temporal_indicator
      self%last_observation%temporal_certificate_available = .true.
      self%last_observation%temporal_normalized_indicator = rossfast_temporal_indicator
      self%last_observation%temporal_indicator_route = 'rossfast-model-certificate'
      self%last_observation%temporal_certificate_unavailable_reason = 'available'
    else if (self%temporal_indicator_history_enabled.and.self%weather_surface_active) then
      ! Preserve truthful numerical continuation on the actually selected sibling.
      select type(physical=>state)
      type is(fmr_b110_temporal_indicator_state_t)
        call physical%temporal_history%replace( &
          (solve_result%candidate_state%pressure_head-request%base_state%pressure_head)/step_duration,temporal_history_ok)
        if(.not.temporal_history_ok)return
      class default
        return
      end select
      self%last_observation%temporal_indicator_route='weather-surface-full-half'
      self%last_observation%temporal_certificate_unavailable_reason='external-full-half'
    else if (self%temporal_indicator_history_enabled) then
      call evaluate_temporal_history_service(self, state, request, solve_result, outcome, temporal_history_ok)
      if (.not. temporal_history_ok) return
    end if

    if (self%black_evaporation_active) then
      select type (black_physical => state)
      type is (fmr_b110_black_evaporation_state_t)
        if (black_result%status /= BLACK_EVAP_AVAILABLE) return
        black_physical%black_evaporation = black_result%candidate_state
      class default
        return
      end select
    end if

    if (self%boesten_evaporation_active) then
      select type (boesten_physical => state)
      class is (fmr_b110_boesten_evaporation_state_t)
        if (boesten_result%status /= BOESTEN_EVAP_AVAILABLE) return
        boesten_physical%boesten_evaporation = boesten_result%candidate_state
        if(allocated(self%drainage_trial_distribution).and. &
           solve_result%candidate_state%ponding_depth>BOESTEN_EVAP_PONDING_CLASSIFICATION_CM)then
          block
            type(boesten_evaporation_result_t)::wet_endpoint
            ! New event-complete composition: the physical endpoint is wet,
            ! even if the trial began dry. Reuse the existing process reset.
            ! Do not recompute any accepted water flux or evaporation demand.
            boesten_process_forcing%surface_is_ponded=.true.
            call evaluate_boesten_evaporation_reduction(self%boesten_evaporation_parameters, &
              boesten_physical%boesten_evaporation,boesten_process_forcing,step_duration,wet_endpoint)
            if(wet_endpoint%status/=BOESTEN_EVAP_AVAILABLE)return
            boesten_physical%boesten_evaporation=wet_endpoint%candidate_state
            self%last_observation%boesten_ponding_reset_applied=.true.
            self%last_observation%boesten_candidate_spev=wet_endpoint%candidate_state%spev
            self%last_observation%boesten_candidate_saev=wet_endpoint%candidate_state%saev
          end block
        end if
      class default
        return
      end select
    end if

    if (self%fixed_weir_surface_water_active) then
      select type (physical => state)
      type is (fmr_b110_fixed_weir_surface_water_state_t)
        call evaluate_restricted_fixed_weir_surface_water(self%fixed_weir_surface_water_parameters, &
             self%fixed_weir_surface_water_numerical, physical%surface_water, &
             self%fixed_weir_surface_water_forcing, step_duration, self%fixed_weir_surface_water_result)
        call populate_fixed_weir_surface_water_observation(self)
        if (self%fixed_weir_surface_water_result%status /= FIXED_WEIR_AVAILABLE) return
      class default
        return
      end select
    end if
    select type (physical => state)
    class is (fmr_b110_physical_state_t)
      if (self%soil_temperature_active) then
        call build_process_hydraulic_view(solve_result%candidate_state, hydraulic_end, hydraulic_view_ok)
        if (.not. hydraulic_view_ok) return
        call trial_restricted_soil_temperature(self%soil_temperature_parameters, self%soil_temperature_numerical, &
             self%soil_temperature_forcing, hydraulic_start, hydraulic_end, physical%soil_temperature, t0, t1, &
             self%soil_temperature_workspace, soil_temperature_trial, soil_temperature_result, soil_temperature_diagnostics)
        self%last_observation%soil_temperature_executed = .true.
        self%last_observation%soil_temperature_status = soil_temperature_result%status
        self%last_observation%soil_temperature_energy_accounting_complete = soil_temperature_diagnostics%energy_accounting_complete
        self%last_observation%soil_temperature_energy_residual_j_cm2 = soil_temperature_result%energy_residual_j_cm2
        self%last_observation%soil_temperature_top_heat_flux_j_cm2_day = &
             soil_temperature_result%top_heat_flux_into_soil_j_cm2_day
        self%last_observation%soil_temperature_bottom_heat_flux_j_cm2_day = &
             soil_temperature_result%bottom_heat_flux_into_soil_j_cm2_day
        self%last_observation%soil_temperature_storage_change_j_cm2 = soil_temperature_result%sensible_storage_change_j_cm2
        self%last_observation%soil_temperature_boundary_energy_j_cm2 = soil_temperature_result%boundary_energy_into_soil_j_cm2
        if (soil_temperature_result%status /= SOIL_TEMP_OK .or. .not. soil_temperature_result%produced) return
        call commit_soil_temperature_state(physical%soil_temperature, soil_temperature_trial, soil_temperature_status)
        if (soil_temperature_status /= SOIL_TEMP_OK) then
          self%last_observation%soil_temperature_status = soil_temperature_status
          return
        end if
      else
        if (allocated(physical%soil_temperature)) return
      end if
      if (self%macropore_active) then
        if (.not. allocated(physical%macropore)) return
        physical%macropore = macropore_result%macropore_candidate
      end if
      physical%active_nodes = solve_result%candidate_state%active_nodes
      physical%pressure_head = solve_result%candidate_state%pressure_head
      physical%water_content = solve_result%candidate_state%water_content
      physical%ponding_depth = solve_result%candidate_state%ponding_depth
      physical%groundwater_level = solve_result%candidate_state%groundwater_level
      if (self%rutter_active) then
        if (.not. rutter_trial_prepared .or. .not. allocated(physical%rutter)) return
        if(self%black_evaporation_active)then
          physical%rutter=rutter_local_candidate
        else
          physical%rutter = self%rutter_forcing%candidate_state
        end if
      end if
      if(self%rfm_configuration%enabled)then
        select type(rfm_physical=>state)
        type is(fmr_b110_rfm_state_t)
          call copy_rfm_physical_state(rfm_live%candidate%candidate_rfm,rfm_physical%rfm,rfm_source_ok)
          if(.not.rfm_source_ok)return
        class default
          return
        end select
      end if
    class default
      return
    end select
    if (self%fixed_weir_surface_water_active) then
      select type (physical => state)
      type is (fmr_b110_fixed_weir_surface_water_state_t)
        physical%surface_water = self%fixed_weir_surface_water_result%candidate_state
      class default
        return
      end select
    end if
    ! The transaction ledger owns exchanges across the outer model boundary.
    ! In dynamic-top mode qtop is the internal surface-to-matrix exchange, while
    ! ponding is committed storage. Reconstruct the accepted external surface
    ! exchange from the final surface storage change and qtop; HeadCalc has
    ! already enforced the independent pond-balance equation.
    surface_external_exchange_cm = -solve_result%top_flux*step_duration
    if (request%boundary%top_mode == FSI_TOP_MODE_DYNAMIC_PROVIDER) then
      ! Final pond storage already contains any capacity return. Add the
      ! accepted pond-to-macropore transfer back when reconstructing the outer
      ! surface exchange, because that accepted share moved internally from
      ! pond storage into macropore storage and is not an external macro input.
      surface_external_exchange_cm = solve_result%candidate_state%ponding_depth - &
           request%base_state%ponding_depth - solve_result%top_flux*step_duration + &
           macropore_pond_accepted_cm
    end if
    if (self%snow_active) surface_external_exchange_cm = -self%base_top_flux*step_duration
    if (.not. ieee_is_finite(surface_external_exchange_cm)) return
    call account_external_fluxes(self, step_duration, surface_external_exchange_cm, solve_result%bottom_flux, &
         snow_event_applied_this_call, macropore_accepted_top_cm, macropore_rapid_outflow_cm, &
         outcome%mass_in, outcome%mass_out)
    if(self%rutter_active.and.self%black_evaporation_active)then
      ! Replace the signed net soil/pond surface receipt by the actual outer
      ! canopy/surface ledger. Canopy is an incumbent stock in this layout.
      if(.not.rutter_trial_prepared)return
      if(self%workspace%converged_surface_result%status/=SW_TOP_BOUNDARY_AVAILABLE)return
      if(.not.self%workspace%converged_surface_result%runoff_resolved)return
      outcome%mass_in=outcome%mass_in-max(0.0_real64,surface_external_exchange_cm)+rutter_local_input+ &
           self%rutter_forcing%runon_rate_cm_per_day*step_duration
      outcome%mass_out=outcome%mass_out-max(0.0_real64,-surface_external_exchange_cm)+ &
           (rutter_process_result%reservoir_outflow_cm_per_day+ &
            self%workspace%converged_surface_result%bare_soil_evaporation+ &
            self%workspace%converged_surface_result%ponded_water_evaporation)*step_duration+ &
            self%workspace%converged_surface_result%runoff_depth+rutter_local_capacity_export
    end if

    if(self%rfm_configuration%enabled)then
      outcome%mass_in=outcome%mass_in+rfm_preferential_input_cm
      outcome%mass_out=outcome%mass_out+rfm_deep_receipt_cm
    end if
    if(self%frost_divdra_active)then
      ! This is provenance of the existing nodal accounting above, not a second ledger.
      self%last_observation%frost_divdra_trial_duration=step_duration
      self%last_observation%frost_divdra_signed_exchange_native=sum(self%qdra)*step_duration
      self%last_observation%frost_divdra_mass_accounted_in_trial=.true.
    end if
    if (self%drainage_response_active) then
      self%last_observation%drainage_response_mass_accounted_in_trial = .true.
      step_drainage_exchange = self%drainage_response_diagnostics%aggregate%signed_soil_to_drain_rate * step_duration
      ! Raw generation diagnostics remain proposal provenance. The accepted
      ! receipt follows the same final nodes as the one solver sink/ledger.
      if(self%frost_response_drainage_active)step_drainage_exchange=self%last_observation%frost_drainage%total_rate*step_duration
      self%last_observation%drainage_response_signed_exchange_native = step_drainage_exchange
      if (self%drainage_response_window_exchange_available .and. ieee_is_finite(step_drainage_exchange)) then
        self%drainage_response_window_signed_exchange_native = &
             self%drainage_response_window_signed_exchange_native + step_drainage_exchange
        if (.not. ieee_is_finite(self%drainage_response_window_signed_exchange_native)) then
          self%drainage_response_window_exchange_available = .false.
          self%drainage_response_window_signed_exchange_native = 0.0_real64
        end if
      else
        self%drainage_response_window_exchange_available = .false.
      end if
      self%last_observation%drainage_response_window_exchange_available = &
           self%drainage_response_window_exchange_available
      self%last_observation%drainage_response_window_signed_exchange_native = &
           self%drainage_response_window_signed_exchange_native
    end if
    outcome%bottom_outward_exchange_native = -solve_result%bottom_flux * step_duration
    outcome%terminal_bottom_outward_flux_native = -solve_result%bottom_flux
    if (.not. ieee_is_finite(outcome%bottom_outward_exchange_native) .or. &
        .not. ieee_is_finite(outcome%terminal_bottom_outward_flux_native)) then
      outcome%bottom_outward_exchange_native = 0.0_real64
      outcome%terminal_bottom_outward_flux_native = 0.0_real64
      return
    end if
    publish_root_result=self%root_compensation%method/=ROOT_COMP_OFF.or.self%root_frost%active
    if(allocated(self%bartholomeus)) then
      call select_fmr_bartholomeus_route(self%bartholomeus%selection,oxygen_route,waterfilm_mode)
      publish_root_result=publish_root_result.or.oxygen_route==FMR_BARTHOLOMEUS_ACTIVE
    end if
    if((self%root_extraction_active.and.publish_root_result).or.self%water_flux_temporal%enabled) then
      if(.not.associated(self%qrot))return
      outcome%actual_transpiration_amount=sum(self%qrot)*step_duration
      if(.not.ieee_is_finite(outcome%actual_transpiration_amount).or.outcome%actual_transpiration_amount<0.0_real64) return
      outcome%actual_transpiration_available=.true.
    end if
    outcome%bottom_interface_exchange_available = .true.
    outcome%mass_accounting_complete = .true.
    outcome%missing_mass_contribution_mask = TX_MASS_MISSING_NONE
    if (self%bottom_thermal_carrier_active .and. self%bottom_thermal_carrier_valid) then
      call record_bottom_thermal_sample(self, state, t0, t1, outcome%bottom_outward_exchange_native, &
           bottom_temperature_start_c, bottom_temperature_start_available)
    end if
    if (self%top_sensible_boundary_carrier_active .and. self%top_sensible_boundary_carrier_valid) then
      call record_top_sensible_boundary_sample(self, t0, t1, solve_result%top_flux * step_duration)
    end if
    if (trajectory_stage_ok) then
      call accept_trajectory_step(self%trajectory_direction, trajectory_accept_ok)
    end if
    if (self%accepted_water_flux_trace_enabled) then
      if (self%macropore_active) then
        if (.not. allocated(macropore_result%exchange_rate_node) .or. &
            .not. allocated(macropore_result%exchange_rate_domain_cp) .or. &
            .not. allocated(macropore_result%vertical_flux%vertical_face_rate) .or. &
            .not. allocated(macropore_result%external_outflow_rate_domain_cp)) then
          self%accepted_water_flux_trace_failed = .true.
        else if (.not. append_accepted_water_flux_substep(self,request,solve_result,t0,t1, &
             macropore_result%exchange_rate_node,macropore_result%exchange_rate_domain_cp,trace_macro_water_start, &
             macropore_result%macropore_candidate%water_domain_cp, &
             macropore_result%vertical_flux%vertical_face_rate,salt_receipt=salt_receipt,macro_receipt=macropore_result)) then
          self%accepted_water_flux_trace_failed = .true.
        end if
      else if (.not. append_accepted_water_flux_substep(self,request,solve_result,t0,t1,salt_receipt=salt_receipt)) then
        self%accepted_water_flux_trace_failed = .true.
      end if
    end if
    if(self%rutter_active.and.self%black_evaporation_active)then
      if(.not.self%accepted_water_flux_trace_enabled.or.self%accepted_water_flux_trace_failed)return
      if(self%trace_tail<1.or..not.allocated(self%trace_arena))return
      if(.not.allocated(self%trace_arena(self%trace_tail)%payload))return
      associate(step=>self%trace_arena(self%trace_tail)%payload)
        step%rutter_reservoir_available=.true.
        step%rutter_canopy_start_cm=rutter_local_start_cm
        step%rutter_canopy_end_cm=rutter_local_candidate%canopy_storage()
        step%rutter_gross_rain_rate_cm_day=self%rutter_forcing%source_window%aggregate_value()/ &
             (self%rutter_forcing%source_window%end_time()-self%rutter_forcing%source_window%start_time())
        step%rutter_gross_irrigation_rate_cm_day=self%rutter_forcing%process%surface_irrigation_cm_per_day
        step%rutter_evaporation_cm=rutter_process_result%reservoir_outflow_cm_per_day*step_duration+rutter_local_capacity_export
        step%rutter_reservoir_residual_cm=rutter_local_residual
      end associate
    end if
    if(self%reactive_solute_active)then
      if(.not.self%accepted_water_flux_trace_enabled.or.self%accepted_water_flux_trace_failed)return
      if(self%trace_tail<1.or..not.allocated(self%trace_arena))return
      select type(physical=>state)
      class is(fmr_b110_physical_state_t)
        block
          type(matrix_solute_receipt_t)::receipt
          type(pond_step_t)::supply
          type(soil_temperature_field_view_t)::heat
          real(real64),allocatable::temperature(:)
          integer::code
          if(.not.allocated(physical%reactive_solute))return
          if(.not.allocated(physical%soil_temperature))return
          call build_soil_temperature_field_view(physical%soil_temperature,heat,code)
          if(code/=SOIL_TEMP_OK)return
          supply=self%reactive_supply;supply%t0=t0;supply%t1=t1
          if(.not.allocated(self%trace_arena(self%trace_tail)%payload))return
          associate(step=>self%trace_arena(self%trace_tail)%payload)
            supply%rain_rate=step%converged_rain_rate_cm_day
            supply%irrigation_rate=step%converged_irrigation_rate_cm_day
            supply%runon_rate=step%converged_runon_rate_cm_day
            call consume_reactive_thermal_substep(physical%reactive_solute,step,supply,heat%temperature_c,receipt)
            if(receipt%status/=MATRIX_OK)then
              block
                character(8)::diagnostic
                integer::envstatus
                call get_environment_variable('SWAP5_DIAG_REACTIVE',diagnostic,status=envstatus)
                if(envstatus==0.and.trim(diagnostic)=='1') &
                  write(0,*)'REACTIVE_STEP_REJECT',t0,t1,receipt%status,receipt%process_status
              end block
              return
            end if
            step%reactive_chemical_available=.true.
            step%chemical_mass_before=receipt%mass_before;step%chemical_mass_after=receipt%mass_after
            step%chemical_external_in=receipt%external_in;step%chemical_external_out=receipt%external_out
            step%chemical_decay_out=receipt%decay_out;step%chemical_residual=receipt%residual
          end associate
        end block
      class default
        return
      end select
    end if
    outcome%solver_ok = .true.
  end subroutine fmr_serialized_advance

  subroutine advance_fmr_mobile_salt_step(self,physical,request,solve_result,t0,t1,receipt,status)
    class(fmr_serialized_reference_model_t),intent(inout)::self
    type(fmr_b110_physical_state_t),intent(inout)::physical
    type(soil_water_solve_request_t),intent(in)::request
    type(soil_water_solve_result_t),intent(in)::solve_result
    real(real64),intent(in)::t0,t1
    type(mobile_macro_salt_receipt_t),intent(out)::receipt
    integer,intent(out)::status
    type(mobile_salt_state_t)::committed_salt,candidate_salt
    type(mobile_salt_fluxes_t)::matrix_receipt
    type(mobile_transport_receipt_t)::transport_receipt
    real(real64),allocatable::faces(:),net_source(:),qdra_rate(:,:),qssdi_rate(:)
    real(real64)::closure,dt
    integer::n,face_status
    status=MACRO_SALT_INVALID;receipt=mobile_macro_salt_receipt_t()
    if(.not.allocated(physical%salt).or.allocated(physical%macropore))return
    n=physical%active_nodes;dt=t1-t0
    if(.not.physical%salt%ready(n).or.dt<=0.0_real64)return
    if(.not.associated(self%soil_parameters).or..not.associated(self%qrot).or. &
       .not.associated(self%qssdi).or..not.associated(self%qdra))return
    if(.not.allocated(request%base_state%water_content).or. &
       .not.allocated(solve_result%candidate_state%water_content))return
    if(size(request%base_state%water_content)/=n.or.size(solve_result%candidate_state%water_content)/=n)return
    ! No surface salt store exists in this bounded soil-interface contract.
    if(request%base_state%ponding_depth/=0.0_real64.or.solve_result%candidate_state%ponding_depth/=0.0_real64)return
    if(any(request%base_state%water_content<=tiny(0.0_real64)))return
    if(physical%salt%cdrain_source_id/=0_int64.and. &
       physical%salt%cdrain_source_id/=self%c_drain_salt_forcing%source_id)return
    net_source=self%qssdi-sum(self%qdra,dim=1)-self%qrot
    call reconstruct_interval_water_face_flux(self%soil_parameters%dz,request%base_state%water_content, &
         solve_result%candidate_state%water_content,net_source,-solve_result%top_flux,-solve_result%bottom_flux,dt, &
         max(1.0e-12_real64,self%compartment_balance_tolerance/dt),faces,closure,face_status)
    if(face_status/=WATER_FACE_FLUX_OK)return
    qdra_rate=self%qdra
    qssdi_rate=self%qssdi
    committed_salt%mass_mg_cm2=physical%salt%mass_mg_cm2
    committed_salt%concentration_mg_cm3=physical%salt%mass_mg_cm2/ &
         (request%base_state%water_content*self%soil_parameters%dz)
    if(allocated(self%mobile_dispersion))then
      call advance_mobile_advection_dispersion(committed_salt,self%soil_parameters%dz,request%base_state%water_content, &
        solve_result%candidate_state%water_content,faces,self%qrot,self%soil_salt_boundary_forcing%matrix_top_mg_cm3, &
        self%soil_salt_boundary_forcing%matrix_bottom_mg_cm3,self%solute_tscf,dt,self%mobile_dispersion, &
        self%base_salt_temporal_policy%transport,qdra_rate,qssdi_rate,self%c_drain_salt_forcing%concentration_mg_cm3, &
        .true.,candidate_salt,transport_receipt,status, &
        top_outflow_carries_solute=self%soil_salt_boundary_forcing%matrix_top_outflow_carries_solute)
      if(status/=SOLUTE_OK)return
      matrix_receipt=transport_receipt%balance
      self%last_observation%salt_internal_substeps=transport_receipt%substeps
    else
      call advance_mobile_salt_trial(committed_salt,self%soil_parameters%dz,request%base_state%water_content, &
         solve_result%candidate_state%water_content,faces,self%qrot,self%soil_salt_boundary_forcing%matrix_top_mg_cm3, &
         self%soil_salt_boundary_forcing%matrix_bottom_mg_cm3,self%solute_tscf,dt,candidate_salt,matrix_receipt,status, &
         qdra_rate=qdra_rate,qssdi_rate=qssdi_rate,cdrain_mg_cm3=self%c_drain_salt_forcing%concentration_mg_cm3, &
         cdrain_available=.true., &
         top_outflow_carries_solute=self%soil_salt_boundary_forcing%matrix_top_outflow_carries_solute)
      self%last_observation%salt_internal_substeps=1
    end if
    if(status/=SOLUTE_OK)return
    physical%salt%mass_mg_cm2=candidate_salt%mass_mg_cm2
    physical%salt%cdrain_source_id=self%c_drain_salt_forcing%source_id
    physical%salt%cdrain_revision=self%c_drain_salt_forcing%revision
    receipt%matrix_top_input_mg_cm2=matrix_receipt%top_input_mg_cm2
    receipt%matrix_top_output_mg_cm2=matrix_receipt%top_output_mg_cm2
    receipt%matrix_bottom_input_mg_cm2=matrix_receipt%bottom_input_mg_cm2
    receipt%matrix_bottom_output_mg_cm2=matrix_receipt%bottom_output_mg_cm2
    allocate(receipt%macro_top_input_mg_cm2(0),receipt%macro_top_output_mg_cm2(0), &
         receipt%macro_bottom_input_mg_cm2(0),receipt%macro_bottom_output_mg_cm2(0), &
         receipt%macro_to_matrix_mg_cm2(0,n),receipt%matrix_to_macro_mg_cm2(0,n))
    if(allocated(self%mobile_dispersion))then
      receipt%root_solute_uptake_mg_cm2=transport_receipt%root_by_node_mg_cm2
    else
      receipt%root_solute_uptake_mg_cm2=self%solute_tscf*self%qrot*committed_salt%concentration_mg_cm3*dt
    end if
    receipt%qdra_signed_out_mg_cm2=matrix_receipt%qdra_signed_out_mg_cm2
    receipt%closure_error_mg_cm2=matrix_receipt%closure_error_mg_cm2
  end subroutine

  subroutine advance_fmr_mobile_macro_salt_step(self, physical, request, solve_result, macropore_result, &
       macro_water_start, t0, t1, receipt, status)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    type(fmr_b110_physical_state_t), intent(inout) :: physical
    type(soil_water_solve_request_t), intent(in) :: request
    type(soil_water_solve_result_t), intent(in) :: solve_result
    type(macropore_runtime_result_t), intent(in) :: macropore_result
    real(real64), intent(in) :: macro_water_start(:,:), t0, t1
    type(mobile_macro_salt_receipt_t), intent(out) :: receipt
    integer, intent(out) :: status

    type(mobile_macro_salt_state_t) :: committed_salt, candidate_salt
    real(real64), allocatable :: matrix_faces(:), net_source(:), matrix_storage_thickness(:)
    real(real64) :: closure, dt
    integer :: face_status, n, nd

    receipt = mobile_macro_salt_receipt_t()
    status = MACRO_SALT_INVALID
    if (.not. allocated(physical%salt) .or. .not. allocated(physical%macropore)) return
    if (.not. associated(self%soil_parameters) .or. &
        .not. allocated(self%soil_salt_boundary_forcing%macropore_top_mg_cm3) .or. &
        .not. allocated(self%soil_salt_boundary_forcing%macropore_bottom_mg_cm3)) return
    if (.not. associated(self%qrot) .or. .not. associated(self%qssdi) .or. .not. associated(self%qdra)) return
    if (.not. allocated(request%base_state%water_content) .or. &
        .not. allocated(solve_result%candidate_state%water_content)) return
    if (.not. allocated(macropore_result%exchange_rate_node) .or. &
        .not. allocated(macropore_result%exchange_rate_domain_cp) .or. &
        .not. allocated(macropore_result%vertical_flux%vertical_face_rate) .or. &
        .not. allocated(macropore_result%macropore_candidate%water_domain_cp)) return
    ! This binding has no salt pools for accepted/returned macropore surface
    ! water, covering, or rapid drainage. Keep those routes explicitly closed.
    if (macropore_result%requested_top_input_cm /= 0.0_real64 .or. &
        macropore_result%accepted_top_input_cm /= 0.0_real64 .or. &
        macropore_result%returned_surface_cm /= 0.0_real64 .or. &
        macropore_result%covered_internal_transfer_cm /= 0.0_real64 .or. &
        macropore_result%rapid_external_outflow_cm /= 0.0_real64) return

    n = physical%active_nodes
    nd = physical%macropore%num_domains
    dt = t1 - t0
    if (n <= 0 .or. nd <= 0 .or. dt <= 0.0_real64) return
    if (.not. physical%salt%ready(n, nd)) return
    if (size(self%soil_parameters%dz) /= n .or. size(self%qrot) /= n .or. size(self%qssdi) /= n .or. &
        size(self%qdra, 2) /= n .or. any(shape(macro_water_start) /= [nd,n]) .or. &
        any(shape(macropore_result%exchange_rate_domain_cp) /= [nd,n]) .or. &
        any(shape(macropore_result%vertical_flux%vertical_face_rate) /= [nd,n+1]) .or. &
        any(shape(macropore_result%macropore_candidate%water_domain_cp) /= [nd,n])) return
    if (physical%salt%cdrain_source_id /= 0_int64 .and. &
        physical%salt%cdrain_source_id /= self%c_drain_salt_forcing%source_id) return

    net_source = self%qssdi - sum(self%qdra, dim=1) - self%qrot + macropore_result%exchange_rate_node
    matrix_storage_thickness=self%soil_parameters%dz*self%macropore_config%matrix_area_fraction
    call reconstruct_interval_water_face_flux(matrix_storage_thickness, request%base_state%water_content, &
         solve_result%candidate_state%water_content, net_source, -solve_result%top_flux, -solve_result%bottom_flux, &
         dt, max(1.0e-12_real64, self%compartment_balance_tolerance / dt), matrix_faces, closure, face_status)
    if (face_status /= WATER_FACE_FLUX_OK) return

    committed_salt%matrix_mass_mg_cm2 = physical%salt%mass_mg_cm2
    committed_salt%macro_mass_mg_cm2 = physical%salt%macro_mass_mg_cm2
    call advance_mobile_macro_salt_trial(committed_salt, matrix_storage_thickness, &
         request%base_state%water_content, solve_result%candidate_state%water_content, macro_water_start, &
         macropore_result%macropore_candidate%water_domain_cp, matrix_faces, &
         macropore_result%vertical_flux%vertical_face_rate, macropore_result%exchange_rate_domain_cp, self%qrot, &
         self%soil_salt_boundary_forcing%matrix_top_mg_cm3, self%soil_salt_boundary_forcing%matrix_bottom_mg_cm3, &
         self%soil_salt_boundary_forcing%macropore_top_mg_cm3, self%soil_salt_boundary_forcing%macropore_bottom_mg_cm3, &
         self%solute_tscf, dt, candidate_salt, receipt, status, qdra_rate=self%qdra, qssdi_rate=self%qssdi, &
         cdrain_mg_cm3=self%c_drain_salt_forcing%concentration_mg_cm3, cdrain_available=.true.)
    if (status /= MACRO_SALT_OK) return
    physical%salt%mass_mg_cm2 = candidate_salt%matrix_mass_mg_cm2
    physical%salt%macro_mass_mg_cm2 = candidate_salt%macro_mass_mg_cm2
    physical%salt%cdrain_source_id = self%c_drain_salt_forcing%source_id
    physical%salt%cdrain_revision = self%c_drain_salt_forcing%revision
  end subroutine advance_fmr_mobile_macro_salt_step

  logical function append_accepted_water_flux_substep(self,request,solve_result,t0,t1,macropore_exchange, &
       macropore_exchange_domain,macropore_water_start,macropore_water_end,macropore_vertical_face_rate,salt_receipt, &
       macro_receipt) result(ok)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    type(soil_water_solve_request_t), intent(in) :: request
    type(soil_water_solve_result_t), intent(in) :: solve_result
    real(real64), intent(in) :: t0,t1
    real(real64), intent(in), optional :: macropore_exchange(:)
    real(real64), intent(in), optional :: macropore_exchange_domain(:,:)
    real(real64), intent(in), optional :: macropore_water_start(:,:),macropore_water_end(:,:)
    real(real64), intent(in), optional :: macropore_vertical_face_rate(:,:)
    type(mobile_macro_salt_receipt_t), intent(in), optional :: salt_receipt
    type(macropore_runtime_result_t),intent(in),optional :: macro_receipt
    type(fmr_trace_arena_entry_t), allocatable :: grown(:)
    type(fmr_water_flux_substep_trace_t) :: step
    real(real64)::macro_return_to_pond,macro_requested_rate
    real(real64),allocatable::covering_sink(:)
    integer :: n, prior, capacity, index
    logical :: matrix_sources_partitioned

    ok = .false.
    if (.not. associated(self%qssdi) .or. .not. associated(self%qdra) .or. .not. associated(self%qrot)) return
    n = request%base_state%active_nodes
    if (n <= 0 .or. size(self%qssdi) /= n .or. size(self%qdra,2) /= n .or. size(self%qrot) /= n) return
    if (solve_result%status /= SW_SOLVE_CONVERGED .or. solve_result%candidate_state%active_nodes /= n) return
    if (.not. allocated(solve_result%candidate_state%water_content) .or. &
        .not. allocated(request%base_state%water_content)) return
    if (size(solve_result%candidate_state%water_content) /= n .or. size(request%base_state%water_content) /= n) return
    if (.not. ieee_is_finite(t0) .or. .not. ieee_is_finite(t1) .or. t1 <= t0) return
    if (.not. ieee_is_finite(solve_result%top_flux) .or. .not. ieee_is_finite(solve_result%bottom_flux)) return
    if (any(.not. ieee_is_finite(self%qssdi)) .or. any(.not. ieee_is_finite(self%qrot)) .or. &
        any(.not. ieee_is_finite(self%qdra))) return

    allocate(step%matrix_area_fraction(n));step%matrix_area_fraction=1.0_real64
    if(self%macropore_active)step%matrix_area_fraction=self%macropore_config%matrix_area_fraction
    macro_return_to_pond=0.0_real64;macro_requested_rate=0.0_real64
    if(present(macro_receipt))then
      macro_requested_rate=macro_receipt%pond_requested_top_input_cm/(t1-t0)
      if(macro_receipt%pond_requested_top_input_cm>0.0_real64) &
        macro_return_to_pond=macro_receipt%returned_surface_cm
    end if
    step%macropore_surface_return_cm=macro_return_to_pond
    step%t0 = t0
    step%t1 = t1
    step%top_flux = solve_result%top_flux
    step%bottom_flux = solve_result%bottom_flux
    ! Accepted observation only; never infer storage from default zero values.
    step%pond_start_cm = request%base_state%ponding_depth
    step%pond_end_cm = solve_result%candidate_state%ponding_depth
    if (.not.all(ieee_is_finite([step%pond_start_cm,step%pond_end_cm]))) return
    if (min(step%pond_start_cm,step%pond_end_cm)<0.0_real64) return
    step%pond_storage_available = .true.
    ! Publish only explicitly available final-converged numerical provenance.
    ! These diagnostics must not be consumed as complete gross solute receipts.
    if (self%soil_water_selection%uses_reference() .and. &
        self%workspace%converged_surface_result%status == SW_TOP_BOUNDARY_AVAILABLE .and. &
        self%workspace%converged_surface_result%runoff_resolved) then
      if (.not.all(ieee_is_finite([self%workspace%converged_surface_result%ponded_water_evaporation, &
          self%workspace%converged_surface_result%runoff_depth, &
          self%workspace%converged_surface_result%bare_soil_evaporation]))) return
      if (self%workspace%converged_surface_result%ponded_water_evaporation < 0.0_real64 .or. &
          self%workspace%converged_surface_result%runoff_depth < 0.0_real64 .or. &
          self%workspace%converged_surface_result%bare_soil_evaporation < 0.0_real64) return
      if (abs(self%workspace%converged_surface_result%candidate_ponding_depth+macro_return_to_pond-step%pond_end_cm) > &
          128.0_real64*epsilon(1.0_real64)*max(1.0_real64,abs(step%pond_end_cm))) return
      ! HeadCalc's final dynamic-top balance, checked again at the accepted
      ! transaction carrier rather than trusting a Newton candidate receipt.
      ! qtop is signed (upward positive); runoff is a depth in cm.
      if (.not.ieee_is_finite(self%workspace%converged_surface_result%net_potential_surface_flux)) return
      if (abs(step%pond_end_cm-step%pond_start_cm-macro_return_to_pond - &
          self%workspace%converged_surface_result%net_potential_surface_flux*(t1-t0) + &
          self%workspace%converged_surface_result%runoff_depth - step%top_flux*(t1-t0)) > &
          1.0e-8_real64*max(1.0_real64,abs(step%pond_start_cm),abs(step%pond_end_cm), &
          abs(step%top_flux*(t1-t0)), &
          abs(self%workspace%converged_surface_result%net_potential_surface_flux*(t1-t0)))) return
      step%converged_surface_available = .true.
      step%converged_surface_net_potential_cm_day=self%workspace%converged_surface_result%net_potential_surface_flux
      step%converged_soil_evaporation_cm_day = self%workspace%converged_surface_result%bare_soil_evaporation
      ! Same accepted observation, retained under both existing API names.
      step%converged_bare_soil_evaporation_cm_day = step%converged_soil_evaporation_cm_day
      step%converged_pond_evaporation_cm_day = self%workspace%converged_surface_result%ponded_water_evaporation
      step%converged_runoff_depth_cm = self%workspace%converged_surface_result%runoff_depth
      if (self%workspace%gross_surface_sources_available) then
        if (.not.all(ieee_is_finite([self%workspace%precipitation_rate_cm_day, &
            self%workspace%irrigation_rate_cm_day, &
            self%workspace%snowmelt_rate_cm_day, &
            self%workspace%runon_rate_cm_day]))) return
        if (min(self%workspace%precipitation_rate_cm_day, &
            self%workspace%irrigation_rate_cm_day, &
            self%workspace%snowmelt_rate_cm_day, &
            self%workspace%runon_rate_cm_day) < 0.0_real64) return
        ! For an unpartitioned dynamic upper boundary, the net potential
        ! must equal its separately supplied gross sources minus actual
        ! evaporation. This is an independent consistency gate on the
        ! converged provider receipt, never an inference from qtop.
        ! The inner macro solve owns candidate geometry; the outer request is
        ! a detached input and does not acquire its candidate fraction. Read
        ! source-partition ownership from the actual bound boundary provider.
        matrix_sources_partitioned=request%boundary%matrix_source_area_partition.and. &
          request%boundary%macropore_surface_area_fraction>=0.0_real64
        if(associated(request%evaluation%dynamic_top_boundary))then
          select type(top=>request%evaluation%dynamic_top_boundary)
          type is(b110_dynamic_top_boundary_solver_provider_t)
            matrix_sources_partitioned=top%matrix_source_area_partition
          end select
        end if
        if (.not.matrix_sources_partitioned) then
          if (.not.ieee_is_finite(self%workspace%converged_surface_result%bare_soil_evaporation)) return
          if (self%workspace%converged_surface_result%bare_soil_evaporation < 0.0_real64) return
          if (abs(self%workspace%converged_surface_result%net_potential_surface_flux - &
              (self%workspace%precipitation_rate_cm_day + &
               self%workspace%irrigation_rate_cm_day + &
               self%workspace%snowmelt_rate_cm_day + &
               self%workspace%runon_rate_cm_day - &
               self%workspace%converged_surface_result%bare_soil_evaporation - &
               self%workspace%converged_surface_result%ponded_water_evaporation-macro_requested_rate)) > &
              1024.0_real64*epsilon(1.0_real64)*max(1.0_real64, &
              abs(self%workspace%converged_surface_result%net_potential_surface_flux), &
              self%workspace%precipitation_rate_cm_day + &
              self%workspace%irrigation_rate_cm_day + &
              self%workspace%snowmelt_rate_cm_day + &
              self%workspace%runon_rate_cm_day)) return
        end if
        step%converged_gross_sources_available = .true.
        step%converged_rain_rate_cm_day = self%workspace%precipitation_rate_cm_day
        step%converged_irrigation_rate_cm_day = self%workspace%irrigation_rate_cm_day
        step%converged_snowmelt_rate_cm_day = self%workspace%snowmelt_rate_cm_day
        step%converged_runon_rate_cm_day = self%workspace%runon_rate_cm_day
      end if
    end if
    step%water_start = request%base_state%water_content
    step%water_end = solve_result%candidate_state%water_content
    step%subsurface_source = self%qssdi
    step%drainage_sink = sum(self%qdra,dim=1)
    step%drainage_sink_by_level = self%qdra
    step%root_sink = self%qrot
    if (allocated(self%substep_root)) then
      if (self%substep_root_diagnostics%status /= ROOT_UPTAKE_OK) return
      step%substep_root_available = .true.
      step%root_pressure_head_start = request%base_state%pressure_head
      step%root_potential_cm_day = self%substep_root_diagnostics%potential_uptake_total
      step%root_drought_reduction_cm_day = self%substep_root_diagnostics%drought_reduction_total
      step%root_oxygen_reduction_cm_day = self%substep_root_diagnostics%oxygen_reduction_total
      if(self%last_observation%bartholomeus_executed)then
        step%deepest_root_oxygen_factor=self%last_observation%deepest_root_oxygen_factor
        step%root_oxygen_reduction_cm_day=step%root_oxygen_reduction_cm_day+ &
          self%last_observation%root_oxygen_base_uptake-self%last_observation%root_oxygen_final_uptake
      end if
    end if
    if(allocated(self%micro_de_willigen).and.self%reactive_solute_active)then
      step%substep_root_available=.true.
      step%root_pressure_head_start=request%base_state%pressure_head
      step%root_potential_cm_day=self%root_potential_transpiration
      step%root_drought_reduction_cm_day=self%last_observation%micro_drought_loss
      step%root_oxygen_reduction_cm_day=self%last_observation%micro_oxygen_loss
      step%root_salinity_reduction_cm_day=self%last_observation%micro_salinity_loss
      step%rootzone_drought_uptake_factor=self%last_observation%micro_drought_factor
      step%deepest_root_oxygen_factor=self%last_observation%deepest_root_oxygen_factor
      step%potential_root_sink=self%root_potential_sink
      step%root_sink_reduction=max(0d0,self%root_potential_sink-self%qrot)
    end if
    allocate(step%macropore_matrix_exchange(n))
    allocate(step%macropore_matrix_exchange_domain(0,n))
    allocate(step%macropore_water_start(0,n),step%macropore_water_end(0,n))
    allocate(step%macropore_vertical_face_rate(0,n+1))
    allocate(step%macropore_external_outflow_rate(0,n),step%covered_top_input_domain_cm(0))
    step%macropore_matrix_exchange = 0.0_real64
    if(present(macropore_exchange_domain))then
      if(size(macropore_exchange_domain,2)/=n .or. size(macropore_exchange_domain,1)<=0 .or. &
         any(.not.ieee_is_finite(macropore_exchange_domain)))return
      if(.not.present(macropore_exchange))return
      if(.not.present(macropore_water_start).or..not.present(macropore_water_end))return
      if(.not.present(macropore_vertical_face_rate))return
      if(any(shape(macropore_water_start)/=shape(macropore_exchange_domain)) .or. &
         any(shape(macropore_water_end)/=shape(macropore_exchange_domain)))return
      if(any(shape(macropore_vertical_face_rate)/= &
           [size(macropore_exchange_domain,1),size(macropore_exchange_domain,2)+1]))return
      if(any(.not.ieee_is_finite(macropore_water_start)).or.any(.not.ieee_is_finite(macropore_water_end)))return
      if(any(.not.ieee_is_finite(macropore_vertical_face_rate)))return
      if(any(macropore_water_start<0.0_real64).or.any(macropore_water_end<0.0_real64))return
      if(.not.present(macro_receipt))return
      step%macropore_top_node=self%macropore_config%geometry%top_node
      step%covered_donor_node=macro_receipt%covered_donor_node
      step%covered_top_input_domain_cm=spread(0.0_real64,1,size(macropore_exchange_domain,1))
      if(allocated(macro_receipt%covered_top_input_domain_cm)) &
        step%covered_top_input_domain_cm=macro_receipt%covered_top_input_domain_cm
      if(size(step%covered_top_input_domain_cm)/=size(macropore_exchange_domain,1))return
      if(any(.not.ieee_is_finite(step%covered_top_input_domain_cm)).or. &
         any(step%covered_top_input_domain_cm<0.0_real64))return
      if(abs(sum(step%covered_top_input_domain_cm)-macro_receipt%covered_internal_transfer_cm)>1.0e-12_real64)return
      allocate(covering_sink(n));covering_sink=0.0_real64
      if(step%macropore_top_node>1)then
        if(step%macropore_top_node>n.or.step%covered_donor_node/=step%macropore_top_node-1)return
        covering_sink(step%covered_donor_node)=sum(step%covered_top_input_domain_cm)/(t1-t0)
      else
        if(step%covered_donor_node/=0.or.any(step%covered_top_input_domain_cm/=0.0_real64))return
      end if
      if(maxval(abs(sum(macropore_exchange_domain,dim=1)-covering_sink-macropore_exchange))> &
         1.0e-12_real64*max(1.0_real64,maxval(abs(macropore_exchange))))return
      step%macropore_matrix_exchange=macropore_exchange
      step%macropore_matrix_exchange_domain=macropore_exchange_domain
      step%macropore_water_start=macropore_water_start
      step%macropore_water_end=macropore_water_end
      step%macropore_vertical_face_rate=macropore_vertical_face_rate
      if(.not.present(macro_receipt))return
      if(.not.allocated(macro_receipt%external_outflow_rate_domain_cp))return
      step%macropore_external_outflow_rate=macro_receipt%external_outflow_rate_domain_cp
      step%macropore_surface_receipt_available=.true.
      step%macropore_requested_cm=macro_receipt%requested_top_input_cm
      step%macropore_accepted_cm=macro_receipt%accepted_top_input_cm
      step%macropore_returned_cm=macro_receipt%returned_surface_cm
      step%macropore_pond_requested_cm=macro_receipt%pond_requested_top_input_cm
      step%macropore_pond_accepted_cm=macro_receipt%pond_accepted_top_input_cm
      step%macropore_pond_returned_cm=macro_receipt%pond_returned_surface_cm
      step%macropore_external_top_cm=macro_receipt%accepted_top_input_cm-macro_receipt%pond_accepted_top_input_cm
      step%macropore_rapid_outflow_cm=macro_receipt%rapid_external_outflow_cm
      if(.not.fmr_macropore_trace_receipt_valid(step,n))return

      if(.not.fmr_macropore_trace_cell_balance_valid(step,n))return
    end if
    if (present(macropore_exchange)) then
      if (size(macropore_exchange) /= n .or. any(.not. ieee_is_finite(macropore_exchange))) return
      step%macropore_matrix_exchange = macropore_exchange
    end if
    step%net_node_source = step%subsurface_source - step%drainage_sink - step%root_sink + &
         step%macropore_matrix_exchange
    if (any(.not. ieee_is_finite(step%water_start)) .or. any(.not. ieee_is_finite(step%water_end)) .or. &
        any(.not. ieee_is_finite(step%net_node_source))) return

    prior = 0
    if (self%solute_state_layout_id /= FMR_SOLUTE_STATE_LAYOUT_NONE) then
      if (.not. present(salt_receipt)) return
      if (.not. allocated(salt_receipt%root_solute_uptake_mg_cm2)) return
      allocate(step%salt_receipt)
      step%salt_receipt = salt_receipt
    end if
    capacity=0
    if(allocated(self%trace_arena))capacity=size(self%trace_arena)
    if(self%trace_used==capacity)then
      allocate(grown(max(16,2*capacity)))
      do index=1,self%trace_used
        grown(index)%predecessor=self%trace_arena(index)%predecessor
        call move_alloc(self%trace_arena(index)%payload,grown(index)%payload)
      end do
      call move_alloc(grown,self%trace_arena)
    end if
    self%trace_used=self%trace_used+1
    index=self%trace_used
    allocate(self%trace_arena(index)%payload)
    self%trace_arena(index)%payload=step
    self%trace_arena(index)%predecessor=self%trace_tail
    self%trace_tail=index
    self%trace_count=self%trace_count+1
    ok = .true.
  end function append_accepted_water_flux_substep

  logical function fmr_macropore_trace_receipt_valid(step,n) result(ok)
    type(fmr_water_flux_substep_trace_t),intent(in)::step
    integer,intent(in)::n
    integer::nd,top_node
    real(real64)::dt,amounts(8),tol,covered
    real(real64),allocatable::matrix_exchange(:)
    ok=.false.
    if(.not.allocated(step%matrix_area_fraction).or..not.allocated(step%macropore_external_outflow_rate).or. &
       .not.allocated(step%macropore_matrix_exchange_domain).or..not.allocated(step%macropore_vertical_face_rate))return
    if(size(step%matrix_area_fraction)/=n)return
    if(any(.not.ieee_is_finite(step%matrix_area_fraction)))return
    if(any(step%matrix_area_fraction<=0.0_real64).or.any(step%matrix_area_fraction>1.0_real64))return
    nd=size(step%macropore_matrix_exchange_domain,1)
    if(any(shape(step%macropore_external_outflow_rate)/=[nd,n]).or. &
       any(shape(step%macropore_vertical_face_rate)/=[nd,n+1]))return
    if(any(.not.ieee_is_finite(step%macropore_vertical_face_rate)))return
    if(any(.not.ieee_is_finite(step%macropore_external_outflow_rate)))return
    if(any(step%macropore_external_outflow_rate<0.0_real64))return
    amounts=[step%macropore_requested_cm,step%macropore_accepted_cm,step%macropore_returned_cm, &
      step%macropore_pond_requested_cm,step%macropore_pond_accepted_cm,step%macropore_pond_returned_cm, &
      step%macropore_external_top_cm,step%macropore_rapid_outflow_cm]
    if(any(.not.ieee_is_finite(amounts)))return
    if(any(amounts<0.0_real64))return
    if(nd==0)then
      ok=.not.step%macropore_surface_receipt_available.and.all(amounts==0.0_real64);return
    end if
    if(.not.step%macropore_surface_receipt_available)return
    top_node=step%macropore_top_node
    if(top_node<1.or.top_node>n.or..not.allocated(step%covered_top_input_domain_cm))return
    if(size(step%covered_top_input_domain_cm)/=nd)return
    if(any(.not.ieee_is_finite(step%covered_top_input_domain_cm)).or.any(step%covered_top_input_domain_cm<0.0_real64))return
    covered=sum(step%covered_top_input_domain_cm)
    if(top_node==1)then
      if(step%covered_donor_node/=0.or.covered/=0.0_real64)return
    else
      if(step%covered_donor_node/=top_node-1.or.any(amounts(1:7)/=0.0_real64))return
      if(.not.allocated(step%macropore_water_start).or..not.allocated(step%macropore_water_end))return
      if(any(shape(step%macropore_water_start)/=[nd,n]).or.any(shape(step%macropore_water_end)/=[nd,n]))return
      if(any(step%macropore_water_start(:,:top_node-1)/=0.0_real64).or. &
         any(step%macropore_water_end(:,:top_node-1)/=0.0_real64).or. &
         any(step%macropore_vertical_face_rate(:,:top_node-1)/=0.0_real64))return
    end if
    dt=step%t1-step%t0
    if(.not.ieee_is_finite(dt).or.dt<=0.0_real64)return
    if(.not.allocated(step%macropore_matrix_exchange))return
    if(size(step%macropore_matrix_exchange)/=n.or.any(.not.ieee_is_finite(step%macropore_matrix_exchange_domain)).or. &
       any(.not.ieee_is_finite(step%macropore_matrix_exchange)))return
    matrix_exchange=sum(step%macropore_matrix_exchange_domain,dim=1)
    if(top_node>1)then
      matrix_exchange(step%covered_donor_node)=matrix_exchange(step%covered_donor_node)-covered/dt
      if(any(step%macropore_matrix_exchange_domain(:,:top_node-1)/=0.0_real64).or. &
         any(step%macropore_external_outflow_rate(:,:top_node-1)/=0.0_real64))return
    end if
    if(maxval(abs(matrix_exchange-step%macropore_matrix_exchange))> &
       1.0e-12_real64*max(1.0_real64,maxval(abs(matrix_exchange))))return
    tol=1.0e-10_real64
    if(abs(amounts(1)-amounts(2)-amounts(3))>tol.or.abs(amounts(4)-amounts(5)-amounts(6))>tol)return
    if(amounts(5)>amounts(2)+tol.or.amounts(6)>amounts(3)+tol)return
    if(abs(amounts(7)+amounts(5)-amounts(2))>tol)return
    if(abs(sum(step%macropore_vertical_face_rate(:,top_node))*dt-amounts(2)-covered)>tol)return
    if(abs(sum(step%macropore_external_outflow_rate)*dt-amounts(8))>tol)return
    ok=.true.
  end function fmr_macropore_trace_receipt_valid

  logical function fmr_macropore_trace_cell_balance_valid(step,n) result(ok)
    type(fmr_water_flux_substep_trace_t),intent(in)::step
    integer,intent(in)::n
    integer::k,nd
    real(real64)::dt,rate_scale,storage_scale,roundoff_cm
    ok=.false.
    if(.not.fmr_macropore_trace_receipt_valid(step,n))return
    k=step%macropore_top_node;dt=step%t1-step%t0
    nd=size(step%macropore_matrix_exchange_domain,1)
    if(nd<=0.or..not.allocated(step%macropore_water_start).or..not.allocated(step%macropore_water_end))return
    if(any(shape(step%macropore_water_start)/=[nd,n]).or.any(shape(step%macropore_water_end)/=[nd,n]))return
    if(any(.not.ieee_is_finite(step%macropore_water_start)).or.any(.not.ieee_is_finite(step%macropore_water_end)))return
    ! No macro control volume exists above k; its entry face belongs to cell k.
    ! Test the same rate certificate in depth units. Subtracting stored stocks
    ! has a finite representation error independent of dt; division by a short
    ! rain event must not turn that sub-ulp depth into a false physical failure.
    ! Eight elementary operations bound the explicit roundoff floor. The rate
    ! threshold and all solver/transaction mass gates remain unchanged.
    rate_scale=max(1.0_real64,maxval(abs(step%macropore_vertical_face_rate)), &
      maxval(abs(step%macropore_matrix_exchange_domain)))
    storage_scale=max(1.0_real64,maxval(abs(step%macropore_water_start)),maxval(abs(step%macropore_water_end)))
    roundoff_cm=8.0_real64*epsilon(1.0_real64)*storage_scale
    if(maxval(abs(step%macropore_water_end(:,k:n)-step%macropore_water_start(:,k:n)-dt* &
      (step%macropore_vertical_face_rate(:,k:n)-step%macropore_vertical_face_rate(:,k+1:n+1)- &
       step%macropore_matrix_exchange_domain(:,k:n)-step%macropore_external_outflow_rate(:,k:n))))> &
       1.0e-12_real64*rate_scale*dt+roundoff_cm)return
    ok=.true.
  end function fmr_macropore_trace_cell_balance_valid

  subroutine materialize_accepted_water_flux_trace(self,t0,t1,ok)
    class(fmr_serialized_reference_model_t),intent(inout)::self
    real(real64),intent(in)::t0,t1
    logical,intent(out)::ok
    type(fmr_water_flux_substep_trace_t),allocatable::steps(:)
    integer::i,cursor,previous
    ok=.false.
    if(self%accepted_water_flux_trace_failed.or.self%trace_count<=0)return
    if(.not.allocated(self%trace_arena))return
    allocate(steps(self%trace_count))
    cursor=self%trace_tail
    do i=self%trace_count,1,-1
      if(cursor<=0.or.cursor>self%trace_used)return
      if(.not.allocated(self%trace_arena(cursor)%payload))return
      steps(i)=self%trace_arena(cursor)%payload
      previous=self%trace_arena(cursor)%predecessor
      ! Strictly decreasing indices exclude cycles and foreign branch links.
      if(previous<0.or.previous>=cursor)return
      cursor=previous
    end do
    if(cursor/=0)return
    if(.not.accepted_water_flux_trace_covers(steps,t0,t1))return
    call move_alloc(steps,self%last_observation%accepted_water_flux_substeps)
    self%last_observation%accepted_water_flux_trace_available=.true.
    ok=.true.
  end subroutine materialize_accepted_water_flux_trace

  logical function accepted_water_flux_trace_covers(steps,t0,t1) result(ok)
    type(fmr_water_flux_substep_trace_t), intent(in) :: steps(:)
    real(real64), intent(in) :: t0,t1
    real(real64) :: cursor,tolerance
    integer :: i,n

    ok = .false.
    if (size(steps) <= 0 .or. .not. ieee_is_finite(t0) .or. .not. ieee_is_finite(t1) .or. t1 <= t0) return
    cursor = t0
    tolerance = 128.0_real64*epsilon(1.0_real64)*max(1.0_real64,abs(t0),abs(t1))
    do i=1,size(steps)
      n = 0
      if (allocated(steps(i)%water_start)) n=size(steps(i)%water_start)
      if (n <= 0 .or. .not. allocated(steps(i)%water_end) .or. &
          .not. allocated(steps(i)%subsurface_source) .or. .not. allocated(steps(i)%drainage_sink) .or. &
          .not. allocated(steps(i)%drainage_sink_by_level) .or. .not. allocated(steps(i)%root_sink) .or. .not. allocated(steps(i)%macropore_matrix_exchange) .or. &
          .not. allocated(steps(i)%macropore_matrix_exchange_domain) .or. &
          .not. allocated(steps(i)%macropore_water_start) .or. .not. allocated(steps(i)%macropore_water_end) .or. &
          .not. allocated(steps(i)%macropore_vertical_face_rate) .or. &
          .not. allocated(steps(i)%net_node_source)) return
      if (size(steps(i)%water_end)/=n .or. size(steps(i)%subsurface_source)/=n .or. &
          size(steps(i)%drainage_sink)/=n .or. size(steps(i)%drainage_sink_by_level,2)/=n .or. &
          size(steps(i)%drainage_sink_by_level,1)<=0 .or. size(steps(i)%root_sink)/=n .or. &
          size(steps(i)%macropore_matrix_exchange)/=n .or. &
          size(steps(i)%macropore_matrix_exchange_domain,2)/=n .or. &
          size(steps(i)%net_node_source)/=n) return
      if(any(.not.ieee_is_finite(steps(i)%drainage_sink_by_level)))return
      if(maxval(abs(sum(steps(i)%drainage_sink_by_level,dim=1)-steps(i)%drainage_sink))> &
           1.0e-12_real64*max(1.0_real64,maxval(abs(steps(i)%drainage_sink))))return
      if(any(shape(steps(i)%macropore_water_start)/=shape(steps(i)%macropore_matrix_exchange_domain)) .or. &
         any(shape(steps(i)%macropore_water_end)/=shape(steps(i)%macropore_matrix_exchange_domain)))return
      if(any(shape(steps(i)%macropore_vertical_face_rate)/= &
           [size(steps(i)%macropore_matrix_exchange_domain,1),n+1]))return
      if(any(.not.ieee_is_finite(steps(i)%macropore_water_start)) .or. &
         any(.not.ieee_is_finite(steps(i)%macropore_water_end)) .or. &
         any(steps(i)%macropore_water_start<0.0_real64) .or. any(steps(i)%macropore_water_end<0.0_real64))return
      if(any(.not.ieee_is_finite(steps(i)%macropore_vertical_face_rate)))return
      if(.not.fmr_macropore_trace_receipt_valid(steps(i),n))return
      if(size(steps(i)%macropore_matrix_exchange_domain,1)>0)then
        ! Cross-cell donor/domain identities are checked by the same receipt
        ! validator used when each accepted substep was appended.
        if(.not.fmr_macropore_trace_cell_balance_valid(steps(i),n))return
      else if(any(abs(steps(i)%macropore_matrix_exchange)>1.0e-14_real64))then
        return
      end if
      if (.not. ieee_is_finite(steps(i)%t0) .or. .not. ieee_is_finite(steps(i)%t1) .or. &
          steps(i)%t1 <= steps(i)%t0 .or. abs(steps(i)%t0-cursor)>tolerance) return
      cursor = steps(i)%t1
    end do
    ok = abs(cursor-t1) <= tolerance
  end function accepted_water_flux_trace_covers

  subroutine record_bottom_thermal_sample(self, state, t0, t1, outward_exchange, start_temperature_c, &
                                          start_temperature_available)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    class(transaction_state_t), intent(in) :: state
    real(real64), intent(in) :: t0, t1, outward_exchange, start_temperature_c
    logical, intent(in) :: start_temperature_available
    real(real64) :: end_temperature_c
    integer :: temperature_status
    logical :: appended

    if (.not. self%bottom_thermal_carrier_active .or. .not. self%bottom_thermal_carrier_valid) return
    appended = .false.
    if (outward_exchange > 0.0_real64) then
      if (.not. start_temperature_available) then
        self%bottom_thermal_carrier_valid = .false.
        return
      end if
      select type (physical => state)
      class is (fmr_b110_physical_state_t)
        if (.not. allocated(physical%soil_temperature)) then
          self%bottom_thermal_carrier_valid = .false.
          return
        end if
        call soil_temperature_at_node(physical%soil_temperature, physical%active_nodes, end_temperature_c, temperature_status)
        if (temperature_status /= SOIL_TEMP_OK) then
          self%bottom_thermal_carrier_valid = .false.
          return
        end if
      class default
        self%bottom_thermal_carrier_valid = .false.
        return
      end select
      call self%bottom_thermal_carrier%append_local(t0, t1, outward_exchange, start_temperature_c, end_temperature_c, appended)
    else if (outward_exchange < 0.0_real64) then
      call self%bottom_thermal_carrier%append_external_incomplete(t0, t1, outward_exchange, appended)
    else
      call self%bottom_thermal_carrier%append_zero(t0, t1, appended)
    end if
    if (.not. appended) self%bottom_thermal_carrier_valid = .false.
  end subroutine record_bottom_thermal_sample

  subroutine record_top_sensible_boundary_sample(self, t0, t1, top_exchange_native)
    class(fmr_serialized_reference_model_t), intent(inout) :: self
    real(real64), intent(in) :: t0, t1, top_exchange_native
    logical :: appended

    if (.not. self%top_sensible_boundary_carrier_active .or. &
        .not. self%top_sensible_boundary_carrier_valid) return
    call self%top_sensible_boundary_carrier%append(t0, t1, top_exchange_native, &
         self%last_observation%soil_temperature_energy_accounting_complete, &
         self%last_observation%soil_temperature_boundary_energy_j_cm2, &
         self%last_observation%soil_temperature_storage_change_j_cm2, &
         self%last_observation%soil_temperature_energy_residual_j_cm2, appended)
    if (.not. appended) self%top_sensible_boundary_carrier_valid = .false.
  end subroutine record_top_sensible_boundary_sample

  subroutine account_external_fluxes(self, step_duration, surface_external_exchange_cm, bottom_flux, &
                                     snow_event_applied, macropore_accepted_top_cm, macropore_rapid_outflow_cm, &
                                     total_in, total_out)
    class(fmr_serialized_reference_model_t), intent(in) :: self
    real(real64), intent(in) :: step_duration, surface_external_exchange_cm, bottom_flux, macropore_accepted_top_cm, &
         macropore_rapid_outflow_cm
    logical, intent(in) :: snow_event_applied
    real(real64), intent(out) :: total_in, total_out
    integer :: i, level
    real(real64) :: value
    total_in = max(0.0_real64, surface_external_exchange_cm) + max(0.0_real64, bottom_flux) * step_duration + &
         macropore_accepted_top_cm
    total_out = max(0.0_real64, -surface_external_exchange_cm) + max(0.0_real64, -bottom_flux) * step_duration + &
         macropore_rapid_outflow_cm
    do i = 1, size(self%qssdi)
      value = self%qssdi(i) * step_duration
      if (value >= 0.0_real64) then
        total_in = total_in + value
      else
        total_out = total_out - value
      end if
    end do
    if (self%fixed_weir_surface_water_active) then
      total_in = total_in + self%fixed_weir_surface_water_result%supply_rate * step_duration
      total_out = total_out + self%fixed_weir_surface_water_result%discharge_rate * step_duration
    else
      do level = 1, size(self%qdra,1)
        do i = 1, size(self%qdra,2)
          value = self%qdra(level,i) * step_duration
          if (value >= 0.0_real64) then
            total_out = total_out + value
          else
            total_in = total_in - value
          end if
        end do
      end do
    end if
    do i = 1, size(self%qrot)
      value = self%qrot(i) * step_duration
      if (value >= 0.0_real64) then
        total_out = total_out + value
      else
        total_in = total_in - value
      end if
    end do
    if (self%snow_active .and. snow_event_applied) then
      total_in = total_in + self%snow_diagnostics%mass%snowfall_external_in + self%snow_diagnostics%mass%rain_external_in
      total_out = total_out + self%snow_diagnostics%mass%sublimation_external_out
    end if
  end subroutine account_external_fluxes

  real(real64) function fmr_serialized_storage(self, state) result(value)
    class(fmr_serialized_reference_model_t), intent(in) :: self
    class(transaction_state_t), intent(in) :: state
    if (.not. associated(self%soil_parameters)) error stop 'F-MR06 storage requested before parameter binding'
    select type (physical => state)
    type is (fmr_b110_rfm_state_t)
      if (.not. allocated(physical%water_content)) error stop 'PPA-WU05-A20 RFM matrix storage incomplete'
      if (allocated(physical%macropore) .or. allocated(physical%snow) .or. allocated(physical%soil_temperature)) &
           error stop 'PPA-WU05-A20 RFM carrier mixed optional state'
      if (.not. physical%rfm%ready()) error stop 'PPA-WU05-A20 RFM fast storage incomplete'
      value = sum(self%soil_parameters%dz * physical%water_content) + physical%ponding_depth + &
           physical%rfm%storage_cm()
    type is (fmr_b110_fixed_weir_surface_water_state_t)
      if (.not. self%fixed_weir_surface_water_active) error stop 'F-PM08D7 inactive model with fixed-weir state'
      if (.not. allocated(physical%water_content)) error stop 'F-MR06 physical storage state incomplete'
      if (allocated(physical%snow)) error stop 'F-PM08D7 fixed-weir state may not carry snow'
      value = sum(self%soil_parameters%dz * physical%water_content) + physical%ponding_depth + &
           physical%surface_water%storage
    class is (fmr_b110_physical_state_t)
      if (self%fixed_weir_surface_water_active) error stop 'F-PM08D7 active model missing fixed-weir state'
      if (.not. allocated(physical%water_content)) error stop 'F-MR06 physical storage state incomplete'
      if (self%macropore_active) then
        if (.not. allocated(self%macropore_config)) error stop 'F-MR06 active macropore config missing'
        if (.not. allocated(self%macropore_config%matrix_area_fraction)) error stop 'F-MR06 active macropore area fraction missing'
        value = sum(self%soil_parameters%dz * physical%water_content * self%macropore_config%matrix_area_fraction) + &
             physical%ponding_depth
      else
        value = sum(self%soil_parameters%dz * physical%water_content) + physical%ponding_depth
      end if
      if (self%macropore_active) then
        if (.not. allocated(physical%macropore) .or. .not. physical%macropore%ready()) &
             error stop 'F-MR06 active macropore storage state incomplete'
        value = value + sum(physical%macropore%water_domain_cp)
      end if
      if(self%rutter_active.and.self%black_evaporation_active)then
        if(.not.allocated(physical%rutter))error stop 'Black/Rutter physical canopy storage missing'
        if(.not.ieee_is_finite(physical%rutter%canopy_storage()))error stop 'Black/Rutter nonfinite canopy storage'
        value=value+physical%rutter%canopy_storage()
      end if
      if (self%snow_active) then
        if (.not. allocated(physical%snow)) error stop 'F-MR06 active snow storage state incomplete'
        value = value + physical%snow%process%snow_water_storage
      end if
    class default
      error stop 'F-MR06 physical storage type mismatch'
    end select
  end function fmr_serialized_storage

  subroutine fmr_serialized_storage_accounting_status(self, state, complete, missing_mask)
    class(fmr_serialized_reference_model_t), intent(in) :: self
    class(transaction_state_t), intent(in) :: state
    logical, intent(out) :: complete
    integer(int64), intent(out) :: missing_mask
    complete = .false.
    missing_mask = TX_MASS_MISSING_UNSPECIFIED
    if (.not. associated(self%soil_parameters)) return
    select type (physical => state)
    type is (fmr_b110_rfm_state_t)
      complete = physical%active_nodes == self%soil_parameters%active_nodes .and. &
           allocated(physical%pressure_head) .and. allocated(physical%water_content) .and. &
           .not. allocated(physical%macropore) .and. .not. allocated(physical%snow) .and. &
           .not. allocated(physical%soil_temperature) .and. physical%rfm%ready()
      if (complete) complete = size(physical%pressure_head) == physical%active_nodes .and. &
           size(physical%water_content) == physical%active_nodes
    type is (fmr_b110_fixed_weir_surface_water_state_t)
      if (.not. self%fixed_weir_surface_water_active) return
      complete = physical%active_nodes == self%soil_parameters%active_nodes .and. allocated(physical%pressure_head) .and. &
           allocated(physical%water_content) .and. .not. allocated(physical%snow) .and. &
           ieee_is_finite(physical%surface_water%storage)
      if (complete) complete = size(physical%pressure_head) == physical%active_nodes .and. &
           size(physical%water_content) == physical%active_nodes
    class is (fmr_b110_physical_state_t)
      if (self%fixed_weir_surface_water_active) return
      complete = physical%active_nodes == self%soil_parameters%active_nodes .and. allocated(physical%pressure_head) .and. &
           allocated(physical%water_content) .and. allocated(self%soil_parameters%dz)
      if (complete) complete = size(self%soil_parameters%dz) == self%soil_parameters%active_nodes
      if (complete) complete = size(physical%pressure_head) == physical%active_nodes .and. &
           size(physical%water_content) == physical%active_nodes
      if (complete .and. self%macropore_active) then
        complete = allocated(self%macropore_config)
        if (complete) complete = allocated(self%macropore_config%matrix_area_fraction)
        if (complete) complete = size(self%macropore_config%matrix_area_fraction) == physical%active_nodes
        if (complete) complete = allocated(physical%macropore)
        if (complete) complete = physical%macropore%ready() .and. &
             physical%macropore%num_nodes == physical%active_nodes
      end if
      if (complete .and. .not. self%macropore_active) complete = .not. allocated(physical%macropore)
      if(complete)complete=allocated(physical%reactive_solute).eqv.self%reactive_solute_active
      if(complete.and.self%reactive_solute_active)complete=physical%reactive_solute%ready()
      if(complete.and.self%rutter_active.and.self%black_evaporation_active)then
        complete=allocated(physical%rutter)
        if(complete)complete=ieee_is_finite(physical%rutter%canopy_storage())
        if(complete)complete=physical%rutter%canopy_storage()>=0.0_real64
      end if
      if (complete .and. self%snow_active) complete = allocated(physical%snow)
      if (complete .and. .not. self%snow_active) complete = .not. allocated(physical%snow)
      if (complete .and. self%soil_temperature_active) then
        complete = allocated(self%soil_temperature_parameters)
        if (complete) complete = self%soil_temperature_parameters%ready()
        if (complete) complete = self%soil_temperature_parameters%node_count() == physical%active_nodes
        if (complete) complete = allocated(physical%soil_temperature)
        if (complete) complete = physical%soil_temperature%ready() .and. &
             physical%soil_temperature%node_count() == physical%active_nodes
      end if
      if (complete .and. .not. self%soil_temperature_active) complete = .not. allocated(physical%soil_temperature)
    class default
      complete = .false.
    end select
    if (complete) missing_mask = TX_MASS_MISSING_NONE
  end subroutine fmr_serialized_storage_accounting_status

  logical function water_flux_trial_admitted(self,p,f,t,c) result(ok)
    class(fmr_serialized_reference_backend_t),intent(in)::self
    type(fmr_b110_physical_parameters_t),intent(in)::p
    type(fmr_b110_physical_forcing_t),intent(in)::f
    type(fmr_template_t),intent(in)::t
    type(canonical_numerical_config_t),intent(in)::c
    ok=.false.
    if(.not.self%model%water_flux_temporal%valid())return
    if(c%transaction%temporal_mode/=TX_TEMPORAL_EXTERNAL_FULL_HALF)return
    if(.not.ieee_is_finite(c%transaction%temporal_tolerance))return
    if(c%transaction%temporal_tolerance<=0.0_real64.or.c%transaction%temporal_tolerance>0.001_real64)return
    if(t%optional_state_layout_id/=FMR_OPTIONAL_STATE_LAYOUT_BASE.or. &
      t%solute_state_layout_id/=FMR_SOLUTE_STATE_LAYOUT_NONE.or. &
      t%numerical_continuation_layout_id/=FMR_NUMERICAL_CONTINUATION_NONE)return
    if(p%active_nodes/=4.or.p%bottom_mode/=2.or.p%swkimpl/=0.or.p%swsophy/=0)return
    if(.not.allocated(p%dz))return
    if(size(p%dz)/=4)return
    if(.not.all(ieee_is_finite(p%dz)))return
    if(any(p%dz<=0.0_real64).or.any(p%dz>30.0_real64))return
    if(abs(sum(p%dz)-30.0_real64)>1.e-12_real64)return
    if(p%picard_conductivity_iteration.or.p%soil_temperature_active.or.p%frost_active.or. &
      p%snow_active.or.p%macropore_active.or.p%hysteresis_active.or.p%elasticity_active.or. &
      p%root_salinity_active.or.p%root_frost%active.or.p%drainage_response_active.or. &
      p%boesten_evaporation_active.or.p%black_evaporation_active.or.p%tabulated_hydraulics_active.or. &
      p%direct_retention_active.or.p%extended_model6_active.or.p%conductivity_power_tail_active.or. &
      p%pdi_vapor_active.or.p%ksatexm_extension_active.or.p%practical_richards_a2c_active)return
    if(p%root_compensation%method/=ROOT_COMP_OFF.or.allocated(p%bartholomeus).or.allocated(p%micro_de_willigen))return
    if(self%model%fixed_weir_surface_water_active.or.self%model%rfm_configuration%enabled)return
    if(allocated(f%legacy_swbotb2_control).or.allocated(f%rutter).or.allocated(f%weather_surface))return
    if(.not.allocated(f%pond_input))return
    if(f%pond_input%implicit_pond_evaporation)return
    ok=.true.
  end function

  subroutine diagnose_macro_rejection(t0,t1,r)
    real(real64),intent(in)::t0,t1
    type(macropore_runtime_result_t),intent(in)::r
    integer::env_status
    character(8)::setting
    call get_environment_variable('SWAP5_DIAG_MACRO_TEMPORAL',setting,status=env_status)
    if(env_status/=0.or.trim(setting)/='1')return
    write(error_unit,*) 'MACRO_REJECT',t0,t1,r%status,r%matrix_result%status, &
      r%outer_iterations,r%final_relative_exchange_change,r%internal_exchange_residual_cm, &
      r%macro_balance_residual_cm,r%matrix_result%diagnostics%nonlinear_iterations
    flush(error_unit)
  end subroutine diagnose_macro_rejection

  subroutine diagnose_macro_step(t0,t1,status_code)
    real(real64),intent(in)::t0,t1
    integer,intent(in)::status_code
    integer,save::calls=0
    integer::env_status
    character(8)::setting
    real::cpu
    call get_environment_variable('SWAP5_DIAG_MACRO_TEMPORAL',setting,status=env_status)
    if(env_status/=0.or.trim(setting)/='1')return
    calls=calls+1
    if(calls>20.and.mod(calls,128)/=0.and.t1-t0>=1.e-7_real64)return
    call cpu_time(cpu)
    write(error_unit,*) 'MACRO_STEP',calls,t0,t1,status_code,cpu
    flush(error_unit)
  end subroutine diagnose_macro_step

  ! Opt-in observation only; never modifies candidates or acceptance policy.
  subroutine diagnose_macro_temporal(full_state,half_state,dt,value)
    class(transaction_state_t),intent(in)::full_state,half_state
    real(real64),intent(in)::dt,value
    integer,save::calls=0
    logical,save::initialized=.false.,enabled=.false.
    character(8)::setting
    integer::status,j
    if(.not.initialized)then
      call get_environment_variable('SWAP5_DIAG_MACRO_TEMPORAL',setting,status=status)
      enabled=status==0.and.trim(setting)=='1'
      initialized=.true.
    end if
    if(.not.enabled)return
    calls=calls+1
    if(calls>20.and.mod(calls,256)/=0.and.dt>=1.e-7_real64)return
    select type(f=>full_state)
    class is(fmr_b110_physical_state_t)
      select type(h=>half_state)
      class is(fmr_b110_physical_state_t)
        if(.not.allocated(f%macropore).or..not.allocated(h%macropore))return
        j=maxloc(abs(f%pressure_head-h%pressure_head),dim=1)
        write(error_unit,*) 'MACRO_TEMPORAL',calls,dt,value,' head_node ',j, &
          f%pressure_head(j),h%pressure_head(j),' pond ',f%ponding_depth,h%ponding_depth, &
          ' gwl ',f%groundwater_level,h%groundwater_level,' stocks ', &
          maxval(abs(f%macropore%water_domain_cp-h%macropore%water_domain_cp)), &
          ' volume ',maxval(abs(f%macropore%volume_domain_cp-h%macropore%volume_domain_cp)), &
          ' dynamic ',maxval(abs(f%macropore%dynamic_volume_cp-h%macropore%dynamic_volume_cp))
        write(error_unit,*) 'MACRO_TOPOLOGY',f%macropore%icp_bottom_domain,h%macropore%icp_bottom_domain
        if(allocated(h%rutter))write(error_unit,*) 'MACRO_ENDPOINT',h%rutter%accepted_until(), &
          f%water_content(j),h%water_content(j)
        flush(error_unit)
      end select
    end select
  end subroutine diagnose_macro_temporal

  real(real64) function fmr_water_flux_temporal_assessment(self,full_state,half_state,full_outcome, &
      half1_outcome,half2_outcome,attempt_dt) result(value)
    class(fmr_serialized_reference_model_t),intent(in)::self
    class(transaction_state_t),intent(in)::full_state,half_state
    type(trial_outcome_t),intent(in)::full_outcome,half1_outcome,half2_outcome
    real(real64),intent(in)::attempt_dt
    logical::available
    real(real64)::normalized
    if(.not.self%water_flux_temporal%enabled)then
      value=self%temporal_error(full_state,half_state)
      if(self%macropore_policy%anchored_cauchy_step_ceiling) &
        call diagnose_macro_temporal(full_state,half_state,attempt_dt,value)
      return
    end if
    value=huge(0.0_real64)
    if(.not.associated(self%soil_parameters))return
    if(.not.allocated(self%soil_parameters%dz))return
    select type(full=>full_state)
    type is(fmr_b110_physical_state_t)
      select type(half=>half_state)
      type is(fmr_b110_physical_state_t)
        if(full%active_nodes/=half%active_nodes)return
        if(.not.allocated(full%pressure_head).or..not.allocated(half%pressure_head).or. &
          .not.allocated(full%water_content).or..not.allocated(half%water_content))return
        if(size(full%pressure_head)/=full%active_nodes)return
        call evaluate_water_flux_temporal_difference(self%water_flux_temporal,self%soil_parameters%dz, &
          full%pressure_head,half%pressure_head,full%water_content,half%water_content, &
          full%ponding_depth,half%ponding_depth,full%groundwater_level,half%groundwater_level, &
          [full_outcome%actual_transpiration_available,half1_outcome%actual_transpiration_available, &
            half2_outcome%actual_transpiration_available], &
          [full_outcome%actual_transpiration_amount,half1_outcome%actual_transpiration_amount, &
            half2_outcome%actual_transpiration_amount], &
          [full_outcome%mass_out,half1_outcome%mass_out,half2_outcome%mass_out],attempt_dt,normalized,available)
        if(available)value=normalized*self%temporal_tolerance_cm
      end select
    end select
  end function

  logical function full_canopy_wetting_persists(forcing,state,significant_wetting) result(persists)
    type(fmr_rutter_runtime_forcing_t),intent(in)::forcing
    type(rutter_source_state_t),intent(in)::state
    real(real64),intent(in)::significant_wetting
    real(real64)::rain,covered_input,evaporation,capacity,storage,duration
    persists=.false.
    duration=forcing%source_window%end_time()-forcing%source_window%start_time()
    capacity=forcing%process%canopy_storage_capacity_cm
    storage=state%canopy_storage()
    evaporation=forcing%process%interception_evaporation_capacity_cm_per_day
    if(.not.all(ieee_is_finite([duration,capacity,storage,evaporation,significant_wetting])))return
    if(duration<=0.0_real64.or.capacity<0.0_real64.or.storage<0.0_real64.or.evaporation<0.0_real64)return
    ! Identical full-canopy predicate to the incumbent Rutter event owner.
    ! For fin>=fout, full storage is invariant and intercepted inflow=fout.
    if(capacity-storage>1.0e-10_real64)return
    rain=forcing%source_window%aggregate_value()/duration
    covered_input=rain
    if(forcing%process%surface_irrigation_is_intercepted) &
      covered_input=covered_input+forcing%process%surface_irrigation_cm_per_day
    covered_input=covered_input*forcing%process%vegetation_cover_fraction
    if(covered_input<evaporation)return
    persists=rain+forcing%process%surface_irrigation_cm_per_day-evaporation>significant_wetting
  end function full_canopy_wetting_persists

  real(real64) function fmr_serialized_temporal_identity(self, full_state, half_state) result(value)
    class(fmr_serialized_reference_model_t), intent(in) :: self
    class(transaction_state_t), intent(in) :: full_state, half_state
    logical :: same
    real(real64)::endpoint,history_bound
    logical::sustained_wetting
    if(self%prescribed_groundwater_active.and..not.self%boesten_evaporation_active)then
      ! Reuse the existing mixed Richards head/storage/Darcy-exchange metric.
      ! The former exact-identity gate cannot assess an evolving water table.
      value=fmr_weather_surface_temporal_error(self,full_state,half_state)
      return
    end if
    ! Only the new explicit accepted-trace Black composition uses this metric.
    ! C*abs(sqrt(Lfull)-sqrt(Lhalf)) bounds all future dry evaporation-depth
    ! disagreement from LDWET. A sustained wetting reset erases that memory at
    ! the next trial; at the forcing endpoint it must again satisfy the bound.
    if(self%black_evaporation_active.and.self%accepted_water_flux_trace_enabled)then
      value=huge(0.0_real64)
      if(.not.allocated(self%trace_arena).or.self%trace_tail<=0)return
      if(.not.allocated(self%trace_arena(self%trace_tail)%payload))return
      endpoint=self%trace_arena(self%trace_tail)%payload%t1
      select type(full=>full_state)
      type is(fmr_b110_black_evaporation_state_t)
        select type(half=>half_state)
        type is(fmr_b110_black_evaporation_state_t)
          if(.not.all(ieee_is_finite([full%black_evaporation%ldwet,half%black_evaporation%ldwet])))return
          if(min(full%black_evaporation%ldwet,half%black_evaporation%ldwet)<0d0)return
          value=fmr_weather_surface_temporal_error(self,full,half)
          block
            character(8)::setting
            integer::status,j
            integer,save::calls=0
            call get_environment_variable('SWAP5_DIAG_BLACK_TEMPORAL',setting,status=status)
            if(status==0.and.trim(setting)=='1')then
              calls=calls+1
              if(calls<=24.or.mod(calls,1000)==0)then
                j=maxloc(abs(full%pressure_head-half%pressure_head),dim=1)
                write(error_unit,*)'BLACK_TEMPORAL',calls,endpoint,value, &
                  maxval(abs(full%pressure_head-half%pressure_head)), &
                  full%groundwater_level,half%groundwater_level,full%black_evaporation%ldwet,half%black_evaporation%ldwet
                write(error_unit,*)'BLACK_HEAD_CONTACT',calls,j,full%pressure_head(j),half%pressure_head(j), &
                  full%water_content(j),half%water_content(j),full%pressure_head(1),half%pressure_head(1), &
                  full%ponding_depth,half%ponding_depth
                flush(error_unit)
              end if
            end if
          end block
          sustained_wetting=self%black_evaporation_forcing%wetting_reset_each_trial
          if(self%rutter_active)then
            if(.not.allocated(full%rutter).or..not.allocated(half%rutter))return
            ! A canopy can fill inside the outer forcing interval. Once BOTH
            ! candidates occupy the invariant full-canopy regime, subsequent
            ! constant-forcing trials reset Black before using its dry memory.
            ! Retain the memory bound at the forcing endpoint, where the next
            ! forcing may be dry; all hydraulic/canopy errors remain controlled.
            sustained_wetting=sustained_wetting.or.( &
              full_canopy_wetting_persists(self%rutter_forcing,full%rutter, &
                self%black_evaporation_forcing%significant_wetting_cm).and. &
              full_canopy_wetting_persists(self%rutter_forcing,half%rutter, &
                self%black_evaporation_forcing%significant_wetting_cm))
          end if
          if(.not.sustained_wetting.or.same_real_bits(endpoint,self%black_forcing_end_time))then
            history_bound=self%black_evaporation_parameters%cofred* &
              abs(sqrt(full%black_evaporation%ldwet)-sqrt(half%black_evaporation%ldwet))
            value=max(value,history_bound)
          end if
          if(self%rutter_active)then
            if(.not.allocated(full%rutter).or..not.allocated(half%rutter))return
            value=max(value,abs(full%rutter%canopy_storage()-half%rutter%canopy_storage()))
          end if
        end select
      end select
      return
    end if
    ! New plain-Boesten accepted-trace composition. The older water-only
    ! certificate/identity route below remains unchanged. Persistent process
    ! history contributes to the error budget as well as the hydraulic state.
    if(self%boesten_evaporation_active.and.self%accepted_water_flux_trace_enabled.and..not.self%macropore_active)then
      value=huge(0.0_real64)
      select type(full=>full_state)
      type is(fmr_b110_boesten_evaporation_state_t)
        select type(half=>half_state)
        type is(fmr_b110_boesten_evaporation_state_t)
          if(.not.all(ieee_is_finite([full%boesten_evaporation%spev,full%boesten_evaporation%saev, &
            half%boesten_evaporation%spev,half%boesten_evaporation%saev])))return
          value=fmr_pond_input_temporal_error(full,half)
          if(self%prescribed_groundwater_active) &
            value=max(value,fmr_weather_surface_temporal_error(self,full,half))
          if(self%picard_conductivity_iteration.and.associated(self%hydraulic_parameters))then
            if(self%hydraulic_parameters%continuous_saturation_conductivity) &
              value=fmr_weather_surface_temporal_error(self,full,half)
          end if
          value=max(value, &
            abs(full%boesten_evaporation%spev-half%boesten_evaporation%spev), &
            abs(full%boesten_evaporation%saev-half%boesten_evaporation%saev))
        end select
      end select
      return
    end if
    if(allocated(self%pond_input))then
      if(self%weather_surface_active)then
        value=fmr_weather_surface_temporal_error(self,full_state,half_state)
        return
      end if
      if(self%picard_conductivity_iteration.and.associated(self%hydraulic_parameters))then
        if(self%hydraulic_parameters%continuous_saturation_conductivity)then
          value=fmr_weather_surface_temporal_error(self,full_state,half_state)
          return
        end if
      end if
      value=fmr_pond_input_temporal_error(full_state,half_state)
      return
    end if
    if(self%frost_divdra_active)then
      value=fmr_frost_divdra_temporal_error(self,full_state,half_state)
      return
    end if
    if(self%frost_low_air_drainage%active)then
      value=fmr_frost_low_air_drainage_temporal_error(self,full_state,half_state)
      return
    end if
    if(self%frost_drainage%active)then
      value=fmr_frost_drainage_temporal_error(self,full_state,half_state)
      return
    end if
    if(self%frost_bottom%active)then
      value=fmr_frost_bottom_temporal_error(self,full_state,half_state)
      if(self%root_frost%active)value=max(value,fmr_root_frost_temporal_error(self,full_state,half_state))
      return
    end if
    if(self%root_frost%active) then
      value=fmr_root_frost_temporal_error(self,full_state,half_state)
      ! Both owners retain their existing independent acceptance budgets.
      if(self%root_salinity_active)value=max(value,fmr_base_salt_physical_temporal_error(self,full_state,half_state))
      return
    end if
    if (self%bottom_mode /= 7 .and. self%bottom_mode /= -2 .and. self%bottom_mode /= 5 .and. &
        self%bottom_mode /= 2 .and. self%bottom_mode /= 8 .and. &
        .not.(self%bottom_mode==1.and.self%prescribed_groundwater_active).and. &
        .not.(self%bottom_mode==3.and.self%rutter_active.and.self%macropore_active)) then
      value = huge(0.0_real64)
      return
    end if

    select type (full => full_state)
    type is (fmr_b110_rfm_state_t)
      value = huge(0.0_real64)
      select type (half => half_state)
      type is (fmr_b110_rfm_state_t)
        if (base_physical_states_identical(full,half) .and. full%rfm%same_values(half%rfm)) value = 0.0_real64
      class default
      end select
      return
    class default
    end select

    if (self%fixed_weir_surface_water_active) then
      value = huge(0.0_real64)
      select type (full => full_state)
      type is (fmr_b110_fixed_weir_surface_water_state_t)
        select type (half => half_state)
        type is (fmr_b110_fixed_weir_surface_water_state_t)
          same = base_physical_states_identical(full, half)
          if (same .and. ieee_is_finite(full%surface_water%storage) .and. &
              ieee_is_finite(half%surface_water%storage)) then
            value = abs(full%surface_water%storage - half%surface_water%storage)
          end if
        class default
          return
        end select
      class default
        return
      end select
      return
    end if

    if (self%macropore_active) then
      value = fmr_macropore_physical_temporal_error(self, full_state, half_state)
      return
    end if

    if(self%solute_state_layout_id==FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED)then
      value=fmr_base_salt_physical_temporal_error(self,full_state,half_state)
      return
    end if
    if (self%rutter_active) then
      value = fmr_rutter_temporal_error(self, full_state, half_state)
      return
    end if

    same = .false.
    select type (full => full_state)
    class is (fmr_b110_physical_state_t)
      select type (half => half_state)
      class is (fmr_b110_physical_state_t)
        if (full%active_nodes == half%active_nodes .and. allocated(full%pressure_head) .and. allocated(half%pressure_head) .and. &
            allocated(full%water_content) .and. allocated(half%water_content)) then
          same = size(full%pressure_head) == size(half%pressure_head) .and. size(full%water_content) == size(half%water_content)
          if (same) same = all(full%pressure_head == half%pressure_head) .and. all(full%water_content == half%water_content) .and. &
                           full%ponding_depth == half%ponding_depth .and. full%groundwater_level == half%groundwater_level
          if (same) same = allocated(full%snow) .eqv. allocated(half%snow)
          if (same) same = allocated(full%soil_temperature) .eqv. allocated(half%soil_temperature)
          if (same) same = allocated(full%macropore) .eqv. allocated(half%macropore)
          if (same .and. allocated(full%macropore)) same = full%macropore%same_values(half%macropore)
          ! F-MR39 deliberately does not introduce a new combined water/thermal
          ! timestep tolerance. Thermal temporal refinement remains qualified by
          ! F-VQ58; the existing Richards temporal acceptance route is preserved.
          if (same .and. allocated(full%snow)) then
            same = full%snow%process%snow_water_storage == half%snow%process%snow_water_storage .and. &
                   full%snow%process%liquid_water_storage == half%snow%process%liquid_water_storage .and. &
                   full%snow%event_applied .eqv. half%snow%event_applied .and. full%snow%event_t0 == half%snow%event_t0
          end if
        end if
      end select
    end select
    if (same) then
      value = 0.0_real64
    else
      value = huge(0.0_real64)
    end if
  end function fmr_serialized_temporal_identity

  ! Mixed Richards states are differential in theta but algebraic in h once
  ! saturated. Across that event use equivalent water depths, including every
  ! face exchange. Unsaturated head differences keep the original cm budget.
  real(real64) function fmr_weather_surface_temporal_error(self,full_state,half_state) result(value)
    class(fmr_serialized_reference_model_t),intent(in)::self
    class(transaction_state_t),intent(in)::full_state,half_state
    real(real64),allocatable::kf(:),kh(:)
    real(real64)::dt,qf,qh,d,storage_error,head_error,mean_full,mean_half,pressure_scale
    logical::ok
    integer::n,i
    value=huge(0.0_real64)
    if(.not.associated(self%soil_parameters).or..not.associated(self%hydraulic_parameters).or. &
       .not.associated(self%constitutive))return
    ! temporal_error follows the actual second sibling; its provider owns dt/2.
    dt=2.0_real64*self%constitutive%step_duration
    if(.not.ieee_is_finite(dt).or.dt<=0.0_real64)return
    select type(full=>full_state)
    class is(fmr_b110_physical_state_t)
      select type(half=>half_state)
      class is(fmr_b110_physical_state_t)
        n=full%active_nodes
        if(n<1.or.n>4096.or.half%active_nodes/=n)return
        if(self%soil_parameters%active_nodes/=n)return
        if(.not.allocated(self%soil_parameters%dz).or..not.allocated(self%soil_parameters%node_distance))return
        if(size(self%soil_parameters%dz)/=n.or.size(self%soil_parameters%node_distance)<n)return
        if(.not.allocated(full%pressure_head).or..not.allocated(half%pressure_head).or. &
           .not.allocated(full%water_content).or..not.allocated(half%water_content))return
        if(size(full%pressure_head)/=n.or.size(half%pressure_head)/=n.or. &
           size(full%water_content)/=n.or.size(half%water_content)/=n)return
        if(any(full%water_content<0.0_real64).or.any(half%water_content<0.0_real64).or. &
           any(full%water_content>1.0_real64).or.any(half%water_content>1.0_real64))return
        if(any(.not.ieee_is_finite(full%pressure_head)).or.any(.not.ieee_is_finite(half%pressure_head)).or. &
           any(.not.ieee_is_finite(full%water_content)).or.any(.not.ieee_is_finite(half%water_content)))return
        if(.not.all(ieee_is_finite([full%ponding_depth,half%ponding_depth, &
           full%groundwater_level,half%groundwater_level])))return
        if(min(full%ponding_depth,half%ponding_depth)<0.0_real64)return
        allocate(kf(n),kh(n));head_error=0.0_real64
        do i=1,n
          pressure_scale=1.0_real64
          if(self%black_evaporation_active.and.self%rutter_active.and.self%accepted_water_flux_trace_enabled)then
            ! Original Hupsel dry fronts have ill-conditioned pressure tails.
            ! Use the existing experimental absolute/relative head defect with
            ! a one-cm absolute floor. Storage and every Darcy exchange retain
            ! their absolute water-depth certificates and original tolerance.
            pressure_scale=max(1.0_real64,abs(full%pressure_head(i)),abs(half%pressure_head(i)))
          end if
          if(max(full%pressure_head(i),half%pressure_head(i))<0.0_real64) &
            head_error=max(head_error,abs(full%pressure_head(i)-half%pressure_head(i))/pressure_scale)
          call evaluate_b110_default_mvg_conductivity(self%hydraulic_parameters,i,full%pressure_head(i),kf(i),ok)
          if(.not.ok)return
          call evaluate_b110_default_mvg_conductivity(self%hydraulic_parameters,i,half%pressure_head(i),kh(i),ok)
          if(.not.ok)return
        end do
        storage_error=sum(abs(full%water_content-half%water_content)*self%soil_parameters%dz)
        value=max(head_error,storage_error,abs(full%ponding_depth-half%ponding_depth))
        if(allocated(self%drainage_trial_distribution))then
          ! GWL is a derived diagnostic with a discrete absent sentinel, not
          ! an independent storage. Control the actual drainage exchange in cm.
          value=max(value,trial_drainage_exchange_error(self,full,half,dt))
        else
          value=max(value,abs(full%groundwater_level-half%groundwater_level))
        end if
        ! Free bottom and interior Darcy exchanges, in cm over this whole trial.
        if(self%bottom_mode==7)value=max(value,dt*abs(kf(n)-kh(n)))
        do i=2,n
          d=self%soil_parameters%node_distance(i)
          mean_full=.5_real64*(kf(i-1)+kf(i));mean_half=.5_real64*(kh(i-1)+kh(i))
          if(self%swkmean==2)then
            mean_full=(self%soil_parameters%dz(i-1)*kf(i-1)+self%soil_parameters%dz(i)*kf(i))/ &
              (self%soil_parameters%dz(i-1)+self%soil_parameters%dz(i))
            mean_half=(self%soil_parameters%dz(i-1)*kh(i-1)+self%soil_parameters%dz(i)*kh(i))/ &
              (self%soil_parameters%dz(i-1)+self%soil_parameters%dz(i))
          end if
          qf=mean_full*((full%pressure_head(i-1)-full%pressure_head(i))/d+1.0_real64)
          qh=mean_half*((half%pressure_head(i-1)-half%pressure_head(i))/d+1.0_real64)
          value=max(value,dt*abs(qf-qh))
        end do
        if(max(full%ponding_depth,half%ponding_depth)>0.0_real64.or. &
           max(full%pressure_head(1),half%pressure_head(1))>=0.0_real64)then
          d=.5_real64*self%soil_parameters%dz(1)
          qf=.5_real64*(self%hydraulic_parameters%cofgen(3,1)+kf(1))* &
            ((full%ponding_depth-full%pressure_head(1))/d+1.0_real64)
          qh=.5_real64*(self%hydraulic_parameters%cofgen(3,1)+kh(1))* &
            ((half%ponding_depth-half%pressure_head(1))/d+1.0_real64)
          value=max(value,dt*abs(qf-qh))
        end if
        if(.not.ieee_is_finite(value))value=huge(0.0_real64)
      end select
    end select
  end function

  real(real64) function trial_drainage_exchange_error(self,full,half,dt) result(error)
    class(fmr_serialized_reference_model_t),intent(in)::self
    class(fmr_b110_physical_state_t),intent(in)::full,half
    real(real64),intent(in)::dt
    real(real64),allocatable::qfull(:),qhalf(:)
    real(real64)::endpoint
    logical::ok
    error=huge(0.0_real64)
    if(.not.allocated(self%trace_arena).or.self%trace_tail<=0)return
    if(self%trace_tail>size(self%trace_arena))return
    if(.not.allocated(self%trace_arena(self%trace_tail)%payload))return
    endpoint=self%trace_arena(self%trace_tail)%payload%t1
    call partition(full,qfull,ok);if(.not.ok)return
    call partition(half,qhalf,ok);if(.not.ok)return
    error=dt*sum(abs(qfull-qhalf))
  contains
    subroutine partition(state,q,ok)
      class(fmr_b110_physical_state_t),intent(in)::state
      real(real64),allocatable,intent(out)::q(:)
      logical,intent(out)::ok
      type(b111_profile_groundwater_projection_t)::projection
      type(process_hydraulic_view_t)::view
      type(fmr_drainage_response_diagnostics_t)::response
      type(drainage_node_transfer_t)::nodes
      type(drainage_distribution_diagnostics_t)::distribution
      real(real64)::lumped(1,state%active_nodes)
      ok=.false.;allocate(q(state%active_nodes));q=0.0_real64
      call evaluate_b111_profile_groundwater_projection(self%soil_parameters%z,self%soil_parameters%node_distance, &
        state%pressure_head,state%ponding_depth,projection)
      if(.not.projection%valid)return
      if(projection%level_present)then
        view%active_nodes=state%active_nodes;view%pressure_head=state%pressure_head;view%water_content=state%water_content
        view%ponding_depth=state%ponding_depth;view%groundwater_level=projection%level_cm
        call evaluate_fmr_drainage_response_bottom_lumped(self%drainage_response_levels,self%drainage_response_controls, &
          view,lumped,response,substep_t1=endpoint)
        if(response%status/=FMR_DRAIN_BIND_OK)return
        call distribute_single_level_signed_divdra(self%drainage_trial_distribution,view,sum(lumped),nodes,distribution)
        if(distribution%status/=DRAIN_DIST_OK)return
        q=nodes%soil_to_drain_rate
      end if
      ok=.true.
    end subroutine
  end function

  ! New opt-in domain only. Existing identity and certificate routes are unchanged.
  real(real64) function fmr_pond_input_temporal_error(full_state,half_state) result(value)
    class(transaction_state_t),intent(in)::full_state,half_state
    logical::available
    value=huge(0.0_real64)
    select type(full=>full_state)
    class is(fmr_b110_physical_state_t)
      select type(half=>half_state)
      class is(fmr_b110_physical_state_t)
        if(full%active_nodes/=half%active_nodes)return
        if(.not.allocated(full%pressure_head).or..not.allocated(half%pressure_head).or. &
           .not.allocated(full%water_content).or..not.allocated(half%water_content))return
        if(size(full%pressure_head)/=full%active_nodes)return
        call evaluate_pond_water_temporal_difference(full%pressure_head,half%pressure_head, &
             full%water_content,half%water_content,full%ponding_depth,half%ponding_depth, &
             full%groundwater_level,half%groundwater_level,value,available)
      end select
    end select
  end function fmr_pond_input_temporal_error

  real(real64) function fmr_root_frost_temporal_error(self,full_state,half_state) result(value)
    class(fmr_serialized_reference_model_t),intent(in)::self
    class(transaction_state_t),intent(in)::full_state,half_state
    real(real64),allocatable::tf(:),th(:)
    real(real64)::head_error,temperature_error
    integer::status,n
    value=huge(0.0_real64)
    if(self%root_frost_head_budget_cm<=0.0_real64.or.self%root_frost_temperature_budget_c<=0.0_real64) return
    select type(full=>full_state)
    type is(fmr_b110_physical_state_t)
      select type(half=>half_state)
      type is(fmr_b110_physical_state_t)
        n=full%active_nodes
        if(n<=0.or.half%active_nodes/=n) return
        if(.not.allocated(full%pressure_head).or..not.allocated(half%pressure_head)) return
        if(.not.allocated(full%water_content).or..not.allocated(half%water_content)) return
        if(size(full%pressure_head)/=n.or.size(half%pressure_head)/=n) return
        if(size(full%water_content)/=n.or.size(half%water_content)/=n) return
        if(any(.not.ieee_is_finite(full%pressure_head)).or.any(.not.ieee_is_finite(half%pressure_head))) return
        if(any(.not.ieee_is_finite(full%water_content)).or.any(.not.ieee_is_finite(half%water_content))) return
        if(.not.all(ieee_is_finite([full%ponding_depth,half%ponding_depth,full%groundwater_level,half%groundwater_level]))) return
        if(.not.allocated(full%soil_temperature).or..not.allocated(half%soil_temperature)) return
        call copy_soil_temperature_profile(full%soil_temperature,tf,status)
        if(status/=SOIL_TEMP_OK) return
        call copy_soil_temperature_profile(half%soil_temperature,th,status)
        if(status/=SOIL_TEMP_OK) return
        if(size(tf)/=n.or.size(th)/=n) return
        if(any(.not.ieee_is_finite(tf)).or.any(.not.ieee_is_finite(th))) return
        ! A full/half disagreement across the empirical cutoff requires refinement.
        if(any((tf(:self%root_frost%rooted_nodes)<0.0_real64).neqv. &
             (th(:self%root_frost%rooted_nodes)<0.0_real64))) return
        head_error=max(maxval(abs(full%pressure_head-half%pressure_head)), &
             abs(full%ponding_depth-half%ponding_depth),abs(full%groundwater_level-half%groundwater_level))
        temperature_error=maxval(abs(tf-th))
        value=max(head_error/self%root_frost_head_budget_cm,temperature_error/self%root_frost_temperature_budget_c)
      end select
    end select
  end function fmr_root_frost_temporal_error

  real(real64) function fmr_frost_divdra_temporal_error(self,full_state,half_state) result(value)
    class(fmr_serialized_reference_model_t),intent(in)::self
    class(transaction_state_t),intent(in)::full_state,half_state
    type(frost_divdra_result_t)::bf,bh
    type(frost_multilevel_divdra_result_t)::mf,mh
    type(frost_geometry_result_t)::gf,gh
    real(real64),allocatable::tf(:),th(:)
    real(real64)::head_error,temperature_error
    integer::status
    value=huge(0.0_real64)
    if(self%frost_drainage%head_budget_cm<=0.0_real64.or.self%frost_drainage%temperature_budget_c<=0.0_real64)return
    select type(full=>full_state)
    type is(fmr_b110_physical_state_t)
      select type(half=>half_state)
      type is(fmr_b110_physical_state_t)
        call regenerate(full,bf,gf,tf,status,mf)
        if(status/=0)return
        call regenerate(half,bh,gh,th,status,mh)
        if(status/=0)return
        if(bf%low_air.neqv.bh%low_air)return
        if(bf%blocked.neqv.bh%blocked)return
        if(allocated(self%frost_divdra_levels))then
          if(any(mf%blocked.neqv.mh%blocked))return
          if(mf%net_policy_applied.neqv.mh%net_policy_applied)return
        end if
        if(gf%deepest_node/=gh%deepest_node)return
        head_error=max(maxval(abs(full%pressure_head-half%pressure_head)), &
             abs(full%ponding_depth-half%ponding_depth),abs(full%groundwater_level-half%groundwater_level))
        temperature_error=maxval(abs(tf-th))
        value=max(head_error/self%frost_drainage%head_budget_cm,temperature_error/self%frost_drainage%temperature_budget_c)
      end select
    end select
  contains
    subroutine regenerate(physical,result,geometry,temperature,status,multilevel)
      type(fmr_b110_physical_state_t),intent(in)::physical
      type(frost_divdra_result_t),intent(out)::result
      type(frost_geometry_result_t),intent(out)::geometry
      real(real64),allocatable,intent(out)::temperature(:)
      integer,intent(out)::status
      type(frost_multilevel_divdra_result_t),intent(out)::multilevel
      type(process_hydraulic_view_t)::view
      real(real64),allocatable::factor(:)
      integer::n
      status=1;n=self%soil_parameters%active_nodes
      multilevel=frost_multilevel_divdra_result_t()
      if(physical%active_nodes/=n)return
      if(.not.allocated(physical%pressure_head).or..not.allocated(physical%water_content))return
      if(size(physical%pressure_head)/=n.or.size(physical%water_content)/=n)return
      if(.not.allocated(physical%soil_temperature).or..not.allocated(self%soil_temperature_forcing))return
      call copy_soil_temperature_profile(physical%soil_temperature,temperature,status)
      if(status/=SOIL_TEMP_OK)return
      status=1
      if(size(temperature)/=n)return
      allocate(factor(n))
      call evaluate_frost_hydraulic_factor(self%frost_hydraulic,temperature,factor,status)
      if(status/=FROST_EFFECT_OK)return
      status=1
      call evaluate_legacy_bracketed_frost_geometry(temperature, &
           self%soil_temperature_forcing%prescribed_surface_temperature_c, &
           self%frost_hydraulic%reduction_start_c,self%frost_hydraulic%reduction_end_c, &
           self%soil_parameters%z,self%soil_parameters%node_distance,geometry)
      if(.not.geometry%available)return
      view%active_nodes=n;view%pressure_head=physical%pressure_head;view%water_content=physical%water_content
      view%ponding_depth=physical%ponding_depth;view%groundwater_level=physical%groundwater_level
      if(allocated(self%frost_divdra_levels))then
        call compose_multilevel_signed_frost_divdra(self%frost_divdra_levels,view,factor,geometry%deepest_node, &
             geometry%bottom_depth_cm,physical%water_content,self%hydraulic_parameters%cofgen(2,:), &
             self%frost_divdra_scalars_cm_per_day,self%bottom_flux,multilevel)
        result=frost_divdra_result_t();result%available=multilevel%available;result%low_air=multilevel%low_air
        if(multilevel%available)then
          result%blocked=any(multilevel%blocked);status=0
        end if
        return
      end if
      call compose_single_level_signed_frost_divdra(self%frost_divdra,view,factor,geometry%deepest_node, &
           geometry%bottom_depth_cm,physical%water_content,self%hydraulic_parameters%cofgen(2,:), &
           self%frost_divdra_scalar_cm_per_day,self%bottom_flux,result)
      if(result%available)status=0
    end subroutine regenerate
  end function fmr_frost_divdra_temporal_error

  real(real64) function fmr_frost_low_air_drainage_temporal_error(self,full_state,half_state) result(value)
    class(fmr_serialized_reference_model_t),intent(in)::self
    class(transaction_state_t),intent(in)::full_state,half_state
    real(real64),allocatable::tf(:),th(:),ff(:),fh(:)
    type(frost_low_air_drainage_result_t)::bf,bh
    real(real64),allocatable::final_flux(:,:),proposal_full(:,:),proposal_half(:,:)
    type(process_hydraulic_view_t)::view_full,view_half
    type(fmr_drainage_response_diagnostics_t)::generated_full,generated_half
    real(real64)::head_error,temperature_error
    integer::status,n
    value=huge(0.0_real64)
    if(self%frost_drainage%head_budget_cm<=0.0_real64.or.self%frost_drainage%temperature_budget_c<=0.0_real64) return
    select type(full=>full_state)
    type is(fmr_b110_physical_state_t)
      select type(half=>half_state)
      type is(fmr_b110_physical_state_t)
        n=full%active_nodes
        if(n<=0.or.half%active_nodes/=n) return
        if(.not.allocated(full%pressure_head).or..not.allocated(half%pressure_head)) return
        if(.not.allocated(full%water_content).or..not.allocated(half%water_content)) return
        if(size(full%pressure_head)/=n.or.size(half%pressure_head)/=n) return
        if(size(full%water_content)/=n.or.size(half%water_content)/=n) return
        if(any(.not.ieee_is_finite(full%pressure_head)).or.any(.not.ieee_is_finite(half%pressure_head))) return
        if(any(.not.ieee_is_finite(full%water_content)).or.any(.not.ieee_is_finite(half%water_content))) return
        if(.not.all(ieee_is_finite([full%ponding_depth,half%ponding_depth,full%groundwater_level,half%groundwater_level]))) return
        if(.not.allocated(full%soil_temperature).or..not.allocated(half%soil_temperature)) return
        call copy_soil_temperature_profile(full%soil_temperature,tf,status)
        if(status/=SOIL_TEMP_OK) return
        call copy_soil_temperature_profile(half%soil_temperature,th,status)
        if(status/=SOIL_TEMP_OK) return
        if(size(tf)/=n.or.size(th)/=n) return
        if(any(.not.ieee_is_finite(tf)).or.any(.not.ieee_is_finite(th))) return
        allocate(ff(n),fh(n))
        call evaluate_frost_hydraulic_factor(self%frost_hydraulic,tf,ff,status)
        if(status/=FROST_EFFECT_OK)return
        call evaluate_frost_hydraulic_factor(self%frost_hydraulic,th,fh,status)
        if(status/=FROST_EFFECT_OK)return
        if(.not.allocated(self%unfrozen_drainage_flux).or..not.allocated(self%soil_temperature_forcing))return
        if(.not.self%frost_low_air_drainage%valid())return
        allocate(final_flux(size(self%unfrozen_drainage_flux,1),n))
        if(self%frost_low_air_response_drainage_active)then
          proposal_full=self%unfrozen_drainage_flux;proposal_half=self%unfrozen_drainage_flux
          ! Terminal views carry their own GWL; no last-trial generated scratch
          ! is silently used as the proposal for both full and half endpoints.
          view_full%active_nodes=n;view_full%pressure_head=full%pressure_head
          view_full%water_content=full%water_content;view_full%ponding_depth=full%ponding_depth
          view_full%groundwater_level=full%groundwater_level
          view_half%active_nodes=n;view_half%pressure_head=half%pressure_head
          view_half%water_content=half%water_content;view_half%ponding_depth=half%ponding_depth
          view_half%groundwater_level=half%groundwater_level
          call evaluate_fmr_drainage_response_bottom_lumped(self%drainage_response_levels,self%drainage_response_controls, &
               view_full,proposal_full,generated_full)
          if(generated_full%status/=FMR_DRAIN_BIND_OK)return
          call evaluate_fmr_drainage_response_bottom_lumped(self%drainage_response_levels,self%drainage_response_controls, &
               view_half,proposal_half,generated_half)
          if(generated_half%status/=FMR_DRAIN_BIND_OK)return
        end if
        if(self%frost_low_air_response_drainage_active)then
        call compose_legacy_bracketed_frost_drainage(tf,self%soil_temperature_forcing%prescribed_surface_temperature_c, &
             self%frost_hydraulic%reduction_start_c,self%frost_hydraulic%reduction_end_c, &
             full%water_content,self%hydraulic_parameters%cofgen(2,:),self%soil_parameters%dz,ff, &
             self%soil_parameters%z,self%soil_parameters%node_distance,self%frost_low_air_drainage%drain_depth_cm, &
             proposal_full,self%bottom_flux,final_flux,bf)
        call compose_legacy_bracketed_frost_drainage(th,self%soil_temperature_forcing%prescribed_surface_temperature_c, &
             self%frost_hydraulic%reduction_start_c,self%frost_hydraulic%reduction_end_c, &
             half%water_content,self%hydraulic_parameters%cofgen(2,:),self%soil_parameters%dz,fh, &
             self%soil_parameters%z,self%soil_parameters%node_distance,self%frost_low_air_drainage%drain_depth_cm, &
             proposal_half,self%bottom_flux,final_flux,bh)
        else
        call compose_legacy_bracketed_frost_drainage(tf,self%soil_temperature_forcing%prescribed_surface_temperature_c, &
             self%frost_hydraulic%reduction_start_c,self%frost_hydraulic%reduction_end_c, &
             full%water_content,self%hydraulic_parameters%cofgen(2,:),self%soil_parameters%dz,ff, &
             self%soil_parameters%z,self%soil_parameters%node_distance,self%frost_low_air_drainage%drain_depth_cm, &
             self%unfrozen_drainage_flux,self%bottom_flux,final_flux,bf)
        call compose_legacy_bracketed_frost_drainage(th,self%soil_temperature_forcing%prescribed_surface_temperature_c, &
             self%frost_hydraulic%reduction_start_c,self%frost_hydraulic%reduction_end_c, &
             half%water_content,self%hydraulic_parameters%cofgen(2,:),self%soil_parameters%dz,fh, &
             self%soil_parameters%z,self%soil_parameters%node_distance,self%frost_low_air_drainage%drain_depth_cm, &
             self%unfrozen_drainage_flux,self%bottom_flux,final_flux,bh)
        end if
        if(.not.bf%available.or..not.bh%available)return
        if(bf%low_air_branch.neqv.bh%low_air_branch)return
        if(bf%bottom_blocked.neqv.bh%bottom_blocked)return
        if(any(bf%blocked_level.neqv.bh%blocked_level))return
        head_error=max(maxval(abs(full%pressure_head-half%pressure_head)), &
             abs(full%ponding_depth-half%ponding_depth),abs(full%groundwater_level-half%groundwater_level))
        temperature_error=maxval(abs(tf-th))
        value=max(head_error/self%frost_drainage%head_budget_cm,temperature_error/self%frost_drainage%temperature_budget_c)
      end select
    end select
  end function fmr_frost_low_air_drainage_temporal_error

  real(real64) function fmr_frost_drainage_temporal_error(self,full_state,half_state) result(value)
    class(fmr_serialized_reference_model_t),intent(in)::self
    class(transaction_state_t),intent(in)::full_state,half_state
    real(real64),allocatable::tf(:),th(:),ff(:),fh(:)
    type(frost_bottom_result_t)::bf,bh
    real(real64)::head_error,temperature_error
    integer::status,n
    value=huge(0.0_real64)
    if(self%frost_drainage%head_budget_cm<=0.0_real64.or.self%frost_drainage%temperature_budget_c<=0.0_real64) return
    select type(full=>full_state)
    type is(fmr_b110_physical_state_t)
      select type(half=>half_state)
      type is(fmr_b110_physical_state_t)
        n=full%active_nodes
        if(n<=0.or.half%active_nodes/=n) return
        if(.not.allocated(full%pressure_head).or..not.allocated(half%pressure_head)) return
        if(.not.allocated(full%water_content).or..not.allocated(half%water_content)) return
        if(size(full%pressure_head)/=n.or.size(half%pressure_head)/=n) return
        if(size(full%water_content)/=n.or.size(half%water_content)/=n) return
        if(any(.not.ieee_is_finite(full%pressure_head)).or.any(.not.ieee_is_finite(half%pressure_head))) return
        if(any(.not.ieee_is_finite(full%water_content)).or.any(.not.ieee_is_finite(half%water_content))) return
        if(.not.all(ieee_is_finite([full%ponding_depth,half%ponding_depth,full%groundwater_level,half%groundwater_level]))) return
        if(.not.allocated(full%soil_temperature).or..not.allocated(half%soil_temperature)) return
        call copy_soil_temperature_profile(full%soil_temperature,tf,status)
        if(status/=SOIL_TEMP_OK) return
        call copy_soil_temperature_profile(half%soil_temperature,th,status)
        if(status/=SOIL_TEMP_OK) return
        if(size(tf)/=n.or.size(th)/=n) return
        if(any(.not.ieee_is_finite(tf)).or.any(.not.ieee_is_finite(th))) return
        allocate(ff(n),fh(n))
        call evaluate_frost_hydraulic_factor(self%frost_hydraulic,tf,ff,status)
        if(status/=FROST_EFFECT_OK)return
        call evaluate_frost_hydraulic_factor(self%frost_hydraulic,th,fh,status)
        if(status/=FROST_EFFECT_OK)return
        call compose_legacy_no_drain_frost_bottom(.true.,tf,self%frost_hydraulic%reduction_end_c, &
             full%water_content,self%hydraulic_parameters%cofgen(2,:),self%soil_parameters%dz,ff,self%bottom_flux,bf)
        call compose_legacy_no_drain_frost_bottom(.true.,th,self%frost_hydraulic%reduction_end_c, &
             half%water_content,self%hydraulic_parameters%cofgen(2,:),self%soil_parameters%dz,fh,self%bottom_flux,bh)
        if(.not.bf%available.or..not.bh%available)return
        ! Excluded low-air branch is rejected at both terminal candidates as well.
        if(bf%blocked.or.bh%blocked)return
        head_error=max(maxval(abs(full%pressure_head-half%pressure_head)), &
             abs(full%ponding_depth-half%ponding_depth),abs(full%groundwater_level-half%groundwater_level))
        temperature_error=maxval(abs(tf-th))
        value=max(head_error/self%frost_drainage%head_budget_cm,temperature_error/self%frost_drainage%temperature_budget_c)
      end select
    end select
  end function fmr_frost_drainage_temporal_error

  real(real64) function fmr_frost_bottom_temporal_error(self,full_state,half_state) result(value)
    class(fmr_serialized_reference_model_t),intent(in)::self
    class(transaction_state_t),intent(in)::full_state,half_state
    real(real64),allocatable::tf(:),th(:),ff(:),fh(:)
    type(frost_bottom_result_t)::bf,bh
    real(real64)::head_error,temperature_error
    integer::status,n
    value=huge(0.0_real64)
    if(self%frost_bottom%head_budget_cm<=0.0_real64.or.self%frost_bottom%temperature_budget_c<=0.0_real64) return
    select type(full=>full_state)
    type is(fmr_b110_physical_state_t)
      select type(half=>half_state)
      type is(fmr_b110_physical_state_t)
        n=full%active_nodes
        if(n<=0.or.half%active_nodes/=n) return
        if(.not.allocated(full%pressure_head).or..not.allocated(half%pressure_head)) return
        if(.not.allocated(full%water_content).or..not.allocated(half%water_content)) return
        if(size(full%pressure_head)/=n.or.size(half%pressure_head)/=n) return
        if(size(full%water_content)/=n.or.size(half%water_content)/=n) return
        if(any(.not.ieee_is_finite(full%pressure_head)).or.any(.not.ieee_is_finite(half%pressure_head))) return
        if(any(.not.ieee_is_finite(full%water_content)).or.any(.not.ieee_is_finite(half%water_content))) return
        if(.not.all(ieee_is_finite([full%ponding_depth,half%ponding_depth,full%groundwater_level,half%groundwater_level]))) return
        if(.not.allocated(full%soil_temperature).or..not.allocated(half%soil_temperature)) return
        call copy_soil_temperature_profile(full%soil_temperature,tf,status)
        if(status/=SOIL_TEMP_OK) return
        call copy_soil_temperature_profile(half%soil_temperature,th,status)
        if(status/=SOIL_TEMP_OK) return
        if(size(tf)/=n.or.size(th)/=n) return
        if(any(.not.ieee_is_finite(tf)).or.any(.not.ieee_is_finite(th))) return
        allocate(ff(n),fh(n))
        call evaluate_frost_hydraulic_factor(self%frost_hydraulic,tf,ff,status)
        if(status/=FROST_EFFECT_OK)return
        call evaluate_frost_hydraulic_factor(self%frost_hydraulic,th,fh,status)
        if(status/=FROST_EFFECT_OK)return
        call compose_legacy_no_drain_frost_bottom(.true.,tf,self%frost_hydraulic%reduction_end_c, &
             full%water_content,self%hydraulic_parameters%cofgen(2,:),self%soil_parameters%dz,ff,self%bottom_flux,bf)
        call compose_legacy_no_drain_frost_bottom(.true.,th,self%frost_hydraulic%reduction_end_c, &
             half%water_content,self%hydraulic_parameters%cofgen(2,:),self%soil_parameters%dz,fh,self%bottom_flux,bh)
        if(.not.bf%available.or..not.bh%available)return
        if(bf%blocked.neqv.bh%blocked)return
        head_error=max(maxval(abs(full%pressure_head-half%pressure_head)), &
             abs(full%ponding_depth-half%ponding_depth),abs(full%groundwater_level-half%groundwater_level))
        temperature_error=maxval(abs(tf-th))
        value=max(head_error/self%frost_bottom%head_budget_cm,temperature_error/self%frost_bottom%temperature_budget_c)
      end select
    end select
  end function fmr_frost_bottom_temporal_error

  real(real64) function fmr_base_salt_physical_temporal_error(self,full_state,half_state) result(value)
    class(fmr_serialized_reference_model_t),intent(in)::self
    class(transaction_state_t),intent(in)::full_state,half_state
    type(soil_temperature_field_view_t)::full_thermal,half_thermal
    integer::n,status
    value=huge(0.0_real64)
    if(.not.self%base_salt_temporal_policy%valid().or..not.associated(self%soil_parameters))return
    if(self%temporal_tolerance_cm/=1.0_real64)return
    select type(full=>full_state)
    class is(fmr_b110_physical_state_t)
      select type(half=>half_state)
      class is(fmr_b110_physical_state_t)
        n=full%active_nodes
        if(n<=0.or.half%active_nodes/=n.or.size(self%soil_parameters%dz)/=n)return
        if(.not.allocated(full%pressure_head).or..not.allocated(half%pressure_head).or. &
           .not.allocated(full%water_content).or..not.allocated(half%water_content).or. &
           .not.allocated(full%salt).or..not.allocated(half%salt))return
        if(allocated(full%macropore).or.allocated(half%macropore).or. &
           allocated(full%snow).or.allocated(half%snow))return
        if(.not.full%salt%ready(n).or..not.half%salt%ready(n))return
        if(allocated(full%soil_temperature).neqv.allocated(half%soil_temperature))return
        if(allocated(full%soil_temperature))then
          call build_soil_temperature_field_view(full%soil_temperature,full_thermal,status)
          if(status/=0)return
          call build_soil_temperature_field_view(half%soil_temperature,half_thermal,status)
          if(status/=0)return
          value=fmr_base_salt_normalized_error(self%base_salt_temporal_policy,self%soil_parameters%dz, &
               full%pressure_head,half%pressure_head,full%water_content,half%water_content, &
               full%salt%mass_mg_cm2,half%salt%mass_mg_cm2,full%ponding_depth,half%ponding_depth, &
               full%groundwater_level,half%groundwater_level,full_thermal%temperature_c,half_thermal%temperature_c)
        else
          value=fmr_base_salt_normalized_error(self%base_salt_temporal_policy,self%soil_parameters%dz, &
               full%pressure_head,half%pressure_head,full%water_content,half%water_content, &
               full%salt%mass_mg_cm2,half%salt%mass_mg_cm2,full%ponding_depth,half%ponding_depth, &
               full%groundwater_level,half%groundwater_level)
        end if
      end select
    end select
  end function
  real(real64) function fmr_rutter_temporal_error(self, full_state, half_state) result(value)
    class(fmr_serialized_reference_model_t), intent(in) :: self
    class(transaction_state_t), intent(in) :: full_state, half_state
    integer :: i, n
    real(real64) :: local_error

    value = huge(0.0_real64)
    select type (full => full_state)
    type is (fmr_b110_physical_state_t)
      select type (half => half_state)
      type is (fmr_b110_physical_state_t)
        if (.not. allocated(full%rutter) .or. .not. allocated(half%rutter)) return
        if (.not. full%rutter%same_source_candidate(half%rutter)) return
        if (full%active_nodes <= 0 .or. full%active_nodes /= half%active_nodes) return
        if (.not. allocated(full%pressure_head) .or. .not. allocated(half%pressure_head) .or. &
            .not. allocated(full%water_content) .or. .not. allocated(half%water_content)) return
        n = full%active_nodes
        if (size(full%pressure_head) /= n .or. size(half%pressure_head) /= n .or. &
            size(full%water_content) /= n .or. size(half%water_content) /= n) return
        if (.not. associated(self%soil_parameters)) return
        if (.not. allocated(self%soil_parameters%dz)) return
        if (size(self%soil_parameters%dz) /= n) return
        value = 0.0_real64
        do i = 1, n
          local_error = abs(full%pressure_head(i) - half%pressure_head(i))
          value = max(value, local_error)
        end do
        value = max(value, abs(full%ponding_depth - half%ponding_depth))
      class default
        return
      end select
    class default
      return
    end select
  end function fmr_rutter_temporal_error

  real(real64) function fmr_macropore_physical_temporal_error(self, full_state, half_state) result(value)
    class(fmr_serialized_reference_model_t), intent(in) :: self
    class(transaction_state_t), intent(in) :: full_state, half_state
    integer :: n

    value = huge(0.0_real64)
    if (.not. self%macropore_active .or. .not. associated(self%soil_parameters)) return

    select type (full => full_state)
    class is (fmr_b110_physical_state_t)
      select type (half => half_state)
      class is (fmr_b110_physical_state_t)
        if (full%active_nodes /= half%active_nodes .or. full%active_nodes /= self%soil_parameters%active_nodes) return
        n = full%active_nodes
        if (n <= 0) return
        if (.not. allocated(full%pressure_head) .or. .not. allocated(half%pressure_head) .or. &
            .not. allocated(full%water_content) .or. .not. allocated(half%water_content)) return
        if (size(full%pressure_head) /= n .or. size(half%pressure_head) /= n .or. &
            size(full%water_content) /= n .or. size(half%water_content) /= n) return
        if (.not. allocated(full%macropore) .or. .not. allocated(half%macropore)) return
        if (.not. full%macropore%ready() .or. .not. half%macropore%ready()) return
        if (full%macropore%num_nodes /= n .or. half%macropore%num_nodes /= n .or. &
            full%macropore%num_domains /= half%macropore%num_domains) return
        ! ICpBtDm is discrete topology, not a continuous centimetre-scale
        ! coordinate. A full/half topology mismatch therefore fails closed.
        if (any(full%macropore%icp_bottom_domain /= half%macropore%icp_bottom_domain)) return

        value = 0.0_real64
        value = max(value, maxval(abs(full%pressure_head-half%pressure_head)))
        value = max(value, abs(full%ponding_depth-half%ponding_depth))
        value = max(value, abs(full%groundwater_level-half%groundwater_level))
        if (allocated(self%macropore_config) .and. allocated(self%macropore_config%matrix_area_fraction)) then
          value = max(value, maxval(abs((full%water_content-half%water_content)*self%soil_parameters%dz * &
               self%macropore_config%matrix_area_fraction)))
        else
          value = max(value, maxval(abs((full%water_content-half%water_content)*self%soil_parameters%dz)))
        end if
        value = max(value, maxval(abs(full%macropore%water_domain_cp-half%macropore%water_domain_cp)))
        value = max(value, maxval(abs(full%macropore%volume_domain_cp-half%macropore%volume_domain_cp)))
        value = max(value, maxval(abs(full%macropore%dynamic_volume_cp-half%macropore%dynamic_volume_cp)))
        if (self%solute_state_layout_id == FMR_SOLUTE_STATE_LAYOUT_MOBILE_DISSOLVED_MACROPORE) then
          if (.not. allocated(full%salt) .or. .not. allocated(half%salt)) then
            value = huge(0.0_real64)
            return
          end if
          if (.not. full%salt%ready(n, full%macropore%num_domains) .or. &
              .not. half%salt%ready(n, half%macropore%num_domains) .or. &
              .not. ieee_is_finite(self%salt_temporal_tolerance_mg_cm2) .or. &
              self%salt_temporal_tolerance_mg_cm2 <= 0.0_real64 .or. &
              .not. ieee_is_finite(self%temporal_tolerance_cm) .or. self%temporal_tolerance_cm <= 0.0_real64) then
            value = huge(0.0_real64)
            return
          end if
          value = max(value, maxval(abs(full%salt%mass_mg_cm2-half%salt%mass_mg_cm2)) / &
               self%salt_temporal_tolerance_mg_cm2 * self%temporal_tolerance_cm)
          value = max(value, maxval(abs(full%salt%macro_mass_mg_cm2-half%salt%macro_mass_mg_cm2)) / &
               self%salt_temporal_tolerance_mg_cm2 * self%temporal_tolerance_cm)
        end if
      class default
        return
      end select
    class default
      return
    end select
  end function fmr_macropore_physical_temporal_error

  logical function base_physical_states_identical(full, half) result(same)
    class(fmr_b110_physical_state_t), intent(in) :: full, half
    same = .false.
    if (full%active_nodes /= half%active_nodes) return
    if (.not. allocated(full%pressure_head) .or. .not. allocated(half%pressure_head)) return
    if (.not. allocated(full%water_content) .or. .not. allocated(half%water_content)) return
    if (size(full%pressure_head) /= size(half%pressure_head) .or. &
        size(full%water_content) /= size(half%water_content)) return
    same = all(full%pressure_head == half%pressure_head) .and. &
         all(full%water_content == half%water_content) .and. &
         full%ponding_depth == half%ponding_depth .and. &
         full%groundwater_level == half%groundwater_level
    if (.not. same) return
    same = allocated(full%snow) .eqv. allocated(half%snow)
    if (same .and. allocated(full%snow)) then
      same = full%snow%process%snow_water_storage == half%snow%process%snow_water_storage .and. &
           full%snow%process%liquid_water_storage == half%snow%process%liquid_water_storage .and. &
           (full%snow%event_applied .eqv. half%snow%event_applied) .and. &
           full%snow%event_t0 == half%snow%event_t0
    end if
  end function base_physical_states_identical

  pure elemental logical function same_real_bits(a, b) result(same)
    real(real64), intent(in) :: a, b
    same = transfer(a, 0_int64) == transfer(b, 0_int64)
  end function same_real_bits


  subroutine b110_swbotb2_initialize_sine(self, canonical_origin_time, legacy_t1900_origin, &
                                           calendar_year_start_t1900, sinave, sinamp, sinmax, status)
    class(b110_legacy_swbotb2_application_control_t), intent(inout) :: self
    real(real64), intent(in) :: canonical_origin_time, legacy_t1900_origin
    real(real64), intent(in) :: calendar_year_start_t1900(:)
    real(real64), intent(in) :: sinave, sinamp, sinmax
    integer, intent(out) :: status

    call clear_control(self)
    status = B110_SWBOTB2_INVALID_CONTROL
    if (.not. ieee_is_finite(canonical_origin_time) .or. .not. ieee_is_finite(legacy_t1900_origin)) return
    if (.not. ieee_is_finite(sinave) .or. .not. ieee_is_finite(sinamp) .or. .not. ieee_is_finite(sinmax)) return
    if (sinave < -10.0_real64 .or. sinave > 10.0_real64) return
    if (sinamp < -10.0_real64 .or. sinamp > 10.0_real64) return
    if (sinmax < 0.0_real64 .or. sinmax > 366.0_real64) return
    if (size(calendar_year_start_t1900) < 2) return
    if (any(.not. ieee_is_finite(calendar_year_start_t1900))) return
    if (.not. strictly_increasing(calendar_year_start_t1900)) return

    self%sw2 = B110_SWBOTB2_SINE
    self%canonical_origin_time = canonical_origin_time
    self%legacy_t1900_origin = legacy_t1900_origin
    self%sinave = sinave
    self%sinamp = sinamp
    self%sinmax = sinmax
    allocate(self%calendar_year_start_t1900(size(calendar_year_start_t1900)))
    self%calendar_year_start_t1900 = calendar_year_start_t1900
    self%initialized = .true.
    status = B110_SWBOTB2_OK
  end subroutine b110_swbotb2_initialize_sine

  subroutine b110_swbotb2_initialize_table(self, canonical_origin_time, legacy_t1900_origin, &
                                            table_t1900, table_qbot, status)
    class(b110_legacy_swbotb2_application_control_t), intent(inout) :: self
    real(real64), intent(in) :: canonical_origin_time, legacy_t1900_origin
    real(real64), intent(in) :: table_t1900(:), table_qbot(:)
    integer, intent(out) :: status

    call clear_control(self)
    status = B110_SWBOTB2_INVALID_CONTROL
    if (.not. ieee_is_finite(canonical_origin_time) .or. .not. ieee_is_finite(legacy_t1900_origin)) return
    if (size(table_t1900) <= 0 .or. size(table_t1900) /= size(table_qbot)) return
    if (any(.not. ieee_is_finite(table_t1900)) .or. any(.not. ieee_is_finite(table_qbot))) return
    if (size(table_t1900) > 1) then
      if (.not. strictly_increasing(table_t1900)) return
    end if
    if (any(table_qbot < -100.0_real64) .or. any(table_qbot > 100.0_real64)) return

    self%sw2 = B110_SWBOTB2_TABLE
    self%canonical_origin_time = canonical_origin_time
    self%legacy_t1900_origin = legacy_t1900_origin
    allocate(self%table_t1900(size(table_t1900)), self%table_qbot(size(table_qbot)))
    self%table_t1900 = table_t1900
    self%table_qbot = table_qbot
    self%initialized = .true.
    status = B110_SWBOTB2_OK
  end subroutine b110_swbotb2_initialize_table

  logical function b110_swbotb2_ready(self) result(ok)
    class(b110_legacy_swbotb2_application_control_t), intent(in) :: self

    ok = self%initialized .and. ieee_is_finite(self%canonical_origin_time) .and. &
         ieee_is_finite(self%legacy_t1900_origin)
    if (.not. ok) return

    select case (self%sw2)
    case (B110_SWBOTB2_SINE)
      ok = allocated(self%calendar_year_start_t1900)
      if (.not. ok) return
      ok = size(self%calendar_year_start_t1900) >= 2 .and. &
           all(ieee_is_finite(self%calendar_year_start_t1900)) .and. &
           strictly_increasing(self%calendar_year_start_t1900) .and. &
           ieee_is_finite(self%sinave) .and. ieee_is_finite(self%sinamp) .and. ieee_is_finite(self%sinmax) .and. &
           self%sinave >= -10.0_real64 .and. self%sinave <= 10.0_real64 .and. &
           self%sinamp >= -10.0_real64 .and. self%sinamp <= 10.0_real64 .and. &
           self%sinmax >= 0.0_real64 .and. self%sinmax <= 366.0_real64
    case (B110_SWBOTB2_TABLE)
      ok = allocated(self%table_t1900) .and. allocated(self%table_qbot)
      if (.not. ok) return
      ok = size(self%table_t1900) > 0 .and. size(self%table_t1900) == size(self%table_qbot) .and. &
           all(ieee_is_finite(self%table_t1900)) .and. all(ieee_is_finite(self%table_qbot)) .and. &
           all(self%table_qbot >= -100.0_real64) .and. all(self%table_qbot <= 100.0_real64)
      if (ok .and. size(self%table_t1900) > 1) ok = strictly_increasing(self%table_t1900)
    case default
      ok = .false.
    end select
  end function b110_swbotb2_ready

  subroutine b110_swbotb2_evaluate(self, substep_t0, substep_t1, bottom_pressure_head_cm, &
                                    effective_bottom_mode, bottom_flux, status)
    class(b110_legacy_swbotb2_application_control_t), intent(in) :: self
    real(real64), intent(in) :: substep_t0, substep_t1, bottom_pressure_head_cm
    integer, intent(out) :: effective_bottom_mode
    real(real64), intent(out) :: bottom_flux
    integer, intent(out) :: status

    real(real64) :: legacy_start_t1900, legacy_end_t1900, legacy_t, twopi, freq
    integer :: iyear

    effective_bottom_mode = 0
    bottom_flux = 0.0_real64
    status = B110_SWBOTB2_INVALID_CONTROL
    if (.not. self%ready()) return
    if (.not. ieee_is_finite(substep_t0) .or. .not. ieee_is_finite(substep_t1) .or. &
        substep_t1 <= substep_t0 .or. .not. ieee_is_finite(bottom_pressure_head_cm)) return

    ! Exact B1.11 BoundBottom guard. Internal -2 is derived from the current
    ! trial-start state and is deliberately not persisted as application state.
    if (bottom_pressure_head_cm < B110_SWBOTB2_DRY_HEAD_CM) then
      effective_bottom_mode = -2
      status = B110_SWBOTB2_OK
      return
    end if

    effective_bottom_mode = 2
    legacy_start_t1900 = self%legacy_t1900_origin + (substep_t0 - self%canonical_origin_time)
    legacy_end_t1900 = self%legacy_t1900_origin + (substep_t1 - self%canonical_origin_time)
    if (.not. ieee_is_finite(legacy_start_t1900) .or. .not. ieee_is_finite(legacy_end_t1900)) then
      effective_bottom_mode = 0
      status = B110_SWBOTB2_INVALID_CONTROL
      return
    end if

    select case (self%sw2)
    case (B110_SWBOTB2_SINE)
      iyear = containing_year(self%calendar_year_start_t1900, legacy_start_t1900)
      if (iyear <= 0) then
        effective_bottom_mode = 0
        status = B110_SWBOTB2_TIME_NOT_COVERED
        return
      end if
      legacy_t = legacy_start_t1900 - self%calendar_year_start_t1900(iyear)
      twopi = 8.0_real64 * atan(1.0_real64)
      freq = twopi / 365.0_real64
      bottom_flux = self%sinave + self%sinamp * cos(freq * (legacy_t - self%sinmax))
    case (B110_SWBOTB2_TABLE)
      bottom_flux = afgen_pairs(self%table_t1900, self%table_qbot, legacy_end_t1900)
    case default
      effective_bottom_mode = 0
      status = B110_SWBOTB2_INVALID_CONTROL
      return
    end select

    if (.not. ieee_is_finite(bottom_flux)) then
      effective_bottom_mode = 0
      bottom_flux = 0.0_real64
      status = B110_SWBOTB2_INVALID_CONTROL
      return
    end if
    status = B110_SWBOTB2_OK
  end subroutine b110_swbotb2_evaluate

  subroutine clear_control(self)
    class(b110_legacy_swbotb2_application_control_t), intent(inout) :: self

    self%initialized = .false.
    self%sw2 = 0
    self%canonical_origin_time = 0.0_real64
    self%legacy_t1900_origin = 0.0_real64
    self%sinave = 0.0_real64
    self%sinamp = 0.0_real64
    self%sinmax = 0.0_real64
    if (allocated(self%calendar_year_start_t1900)) deallocate(self%calendar_year_start_t1900)
    if (allocated(self%table_t1900)) deallocate(self%table_t1900)
    if (allocated(self%table_qbot)) deallocate(self%table_qbot)
  end subroutine clear_control

  pure logical function strictly_increasing(values) result(ok)
    real(real64), intent(in) :: values(:)
    integer :: i

    ok = .true.
    do i = 2, size(values)
      if (values(i) <= values(i-1)) then
        ok = .false.
        return
      end if
    end do
  end function strictly_increasing

  pure integer function containing_year(year_starts, value) result(index)
    real(real64), intent(in) :: year_starts(:), value
    integer :: i

    index = 0
    do i = 1, size(year_starts) - 1
      if (value >= year_starts(i) .and. value < year_starts(i+1)) then
        index = i
        return
      end if
    end do
  end function containing_year

  pure real(real64) function afgen_pairs(x_table, y_table, x) result(value)
    real(real64), intent(in) :: x_table(:), y_table(:), x
    real(real64) :: slope
    integer :: i

    if (x <= x_table(1) .or. size(x_table) == 1) then
      value = y_table(1)
      return
    end if
    do i = 2, size(x_table)
      if (x <= x_table(i)) then
        slope = (y_table(i) - y_table(i-1)) / (x_table(i) - x_table(i-1))
        value = y_table(i-1) + (x - x_table(i-1)) * slope
        return
      end if
    end do
    value = y_table(size(y_table))
  end function afgen_pairs

end module mod_fmr_serialized_reference_backend
