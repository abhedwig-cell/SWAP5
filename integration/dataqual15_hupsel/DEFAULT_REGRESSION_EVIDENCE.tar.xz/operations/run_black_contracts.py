from pathlib import Path
import json,re,subprocess,hashlib,time
ROOT=Path('/workspace/scratch/c3166a264227/SWAP5-hupsel-default-regressions');OUT=ROOT.parent/'dq15-hupsel-default-black-cf2bd2f';OUT.mkdir(exist_ok=False);FC=ROOT.parent/'toolchain/root/usr/bin/x86_64-linux-gnu-gfortran-13'
drivers=[ROOT/p for p in ['tests/fapp/test_ppa_wu04a_black_process.f90','tests/fapp/test_ppa_wu04a_black_runtime.f90','tests/fapp/test_ppa_wu01_production_application_bootstrap.f90','tests/fapp/test_ppa_wu03_common_forcing_adapter.f90','tests/f-app08/test_rutter_output_binding.f90','tests/physics/test_ppa_micro03_runtime.f90','tests/fapp/test_ppa_root_hyd01_sink_equivalence.f90']]
context=ROOT/'tests/fsi/fsi04_real_headcalc_stubs.f90';mapping={}
for p in [*ROOT.glob('src/**/*.f90'),context]:
 for name in re.findall(r'^\s*module\s+(\w+)\s*$',p.read_text(),re.M|re.I):assert name.lower() not in mapping;mapping[name.lower()]=p
ordered=[];seen=set();active=set()
def visit(p):
 if p in seen:return
 assert p not in active,p;active.add(p)
 for name in re.findall(r'^\s*use\s*(?:,\s*(?:non_)?intrinsic\s*::\s*|::\s*)?(\w+)',p.read_text(),re.M|re.I):
  if name.lower() in ['iso_fortran_env','iso_c_binding','ieee_arithmetic','ieee_exceptions','omp_lib']:continue
  q=mapping[name.lower()]
  if q!=p:visit(q)
 active.remove(p);seen.add(p);ordered.append(p)
for p in drivers:visit(p)
ordered=[p for p in ordered if p not in drivers];ordered.append(ROOT/'src/legacy/b1_10_port/headcalc.f90')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
report=dict(candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),scientific_source='cf2bd2f',scope='existing native contracts only; historic PR diff allowlists not admission gates',provider_count=len(ordered),compiler=subprocess.check_output([FC,'--version'],text=True).splitlines()[0],source_sha256={str(p.relative_to(ROOT)):sha(p) for p in ordered+drivers},events=[],outputs={})
def run(cmd,build,category):
 t=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=build,capture_output=True,text=True);idx=len(report['events']);(OUT/f'{idx:04d}.stdout').write_text(p.stdout);(OUT/f'{idx:04d}.stderr').write_text(p.stderr);report['events'].append(dict(command=list(map(str,cmd)),category=category,seconds=time.monotonic()-t,returncode=p.returncode));(OUT/'RESULT.json').write_text(json.dumps(report,indent=2));assert p.returncode==0,p.stderr[-3000:]+p.stdout[-3000:];return p.stdout
for opt in ['O0','O2']:
 build=OUT/opt;build.mkdir();flags=['-'+opt,'-std=f2008','-ffree-line-length-none','-Wall','-Wextra','-fopenmp','-fcheck=all','-fbacktrace','-ffpe-trap=invalid,zero,overflow','-J'+str(build),'-I'+str(build)];objects=[]
 for i,p in enumerate(ordered):
  obj=build/f'{i}.o';run([FC,*flags,'-c',p,'-o',obj],build,'compile');objects.append(obj)
 report['outputs'][opt]={}
 for p in drivers:
  obj=build/(p.stem+'.o');run([FC,*flags,'-c',p,'-o',obj],build,'compile_driver');exe=build/p.stem;run([FC,'-fopenmp',*objects,obj,'-o',exe],build,'link');text=run([exe],build,'native');report['outputs'][opt][str(p.relative_to(ROOT))]=text;print(opt,p.name,'PASS',flush=True)
assert report['outputs']['O0']==report['outputs']['O2'],'O0/O2 output drift'
assert all(sha(ROOT/p)==h for p,h in report['source_sha256'].items())
report['status']='EXISTING_NATIVE_BLACK_RUTTER_BOOTSTRAP_COMMONFORCING_MICRO_ROOT_PRESERVATION_PASS';report['cost_seconds']={k:sum(e['seconds'] for e in report['events'] if e['category']==k) for k in {e['category'] for e in report['events']}};(OUT/'RESULT.json').write_text(json.dumps(report,indent=2));print(report['status'],report['cost_seconds'])
