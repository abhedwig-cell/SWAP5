from pathlib import Path
import subprocess,json,hashlib,time,struct,zlib
ROOT=Path.cwd();OUT=ROOT.parent/'dq15-hupsel-combined-18475bc';OUT.mkdir(exist_ok=False);BASE=ROOT.parent/'dq15-hupsel-default-thermal-cf2bd2f';prior=json.loads((BASE/'result.json').read_text());FC=ROOT.parent/'toolchain/root/usr/bin/x86_64-linux-gnu-gfortran-13';REF=subprocess.check_output(['git','rev-parse','18475bc'],cwd=ROOT,text=True).strip();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert prior['status']=='FOCUSED_PHYSICAL_PASS_REFINEMENT_ASSESSMENT_PENDING_NOT_ADMITTED'
inputs={};changed=[]
for p,h in prior['inputs'].items():
 raw=subprocess.check_output(['git','show',REF+':'+p],cwd=ROOT);inputs[p]=hashlib.sha256(raw).hexdigest()
 if inputs[p]!=h:changed.append(p)
assert changed==['src/runtime/mod_fmr_serialized_reference_backend.f90'],changed
source=OUT/'source/mod_fmr_serialized_reference_backend.f90';source.parent.mkdir();source.write_bytes(subprocess.check_output(['git','show',REF+':'+changed[0]],cwd=ROOT))
r=dict(scientific_source=REF,compiler=prior['compiler'],status='RUNNING',inputs=inputs,changed_providers=changed,inherited_provider_manifest_sha256=sha(BASE/'result.json'),events=[],results={},inherited_objects={})
def run(cmd,wd,kind):
 t=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=wd,capture_output=True,text=True);i=len(r['events']);(OUT/f'{i:03d}.stdout').write_text(p.stdout);(OUT/f'{i:03d}.stderr').write_text(p.stderr);r['events'].append(dict(command=list(map(str,cmd)),category=kind,returncode=p.returncode,seconds=time.monotonic()-t));(OUT/'RESULT.json').write_text(json.dumps(r,indent=2));assert p.returncode==0,p.stdout[-2000:]+p.stderr[-2000:];return p.stdout
for opt in ['O0','O2']:
 b=OUT/opt;b.mkdir();old=BASE/opt;oldexe=old/'thermal';assert sha(oldexe)==prior['executables'][opt]
 ce=next(e for e in prior['events'] if e['category']=='compile' and Path(e['command'][-3]).name==source.name and Path(e['command'][-1]).parent==old);cmd=ce['command'][:];oldbackend=Path(cmd[-1]);cmd[-3]=str(source);cmd[-1]=str(b/'backend.o');cmd=[('-J'+str(b) if x.startswith('-J') else x) for x in cmd];run(cmd,b,'compile')
 assert (b/'mod_fmr_serialized_reference_backend.mod').read_bytes()==(old/'mod_fmr_serialized_reference_backend.mod').read_bytes(),'public ABI changed'
 le=next(e for e in prior['events'] if e['category']=='link' and Path(e['command'][-1])==oldexe);link=le['command'][:];r['inherited_objects'][opt]={x:sha(x) for x in link if x.endswith('.o') and Path(x)!=oldbackend};link=[str(b/'backend.o') if Path(x)==oldbackend else x for x in link];link[-1]=str(b/'thermal');run(link,b,'link');exe=b/'thermal';r.setdefault('executables',{})[opt]=sha(exe)
 case=b/'case';case.mkdir();checkpoint=case/'restart.bin';full=case/'full.bin';resumed=case/'resumed.bin';results={}
 for mode,endpoint in [('full',full),('split',full),('resume',resumed)]:
  text=run([exe,'rutter-'+mode,checkpoint,endpoint,2,1.0],case,'native');assert 'BLACK_RUTTER_HEAT_REACTIVE_MASS_RESTART=PASS' in text;results[mode]=text
 assert full.read_bytes()==resumed.read_bytes();results['endpoint_sha256']=sha(full);original=checkpoint.read_bytes();assert original[:8]==b'S5PT0004'
 for label,raw in [('truncated',original[:-12]),('crc',original[:20]+bytes([original[20]^1])+original[21:])]:
  p=case/(label+'.bin');p.write_bytes(raw);text=run([exe,'rutter-reject',p,case/'reject',2,1.0],case,'native');assert 'THERMAL_INVALID_RESTART=PASS' in text
 for mode in ['reject-id','reject-heat','reject-chemical']:
  text=run([exe,'rutter-'+mode,checkpoint,case/'reject',2,1.0],case,'native');assert 'THERMAL_INVALID_RESTART=PASS' in text
 n,history,physical_id,count=struct.unpack_from('=iiqi',original,148);assert n==4 and history==0 and count>0;micro=168+8*count+8*(3*n+2)+8;canopy=micro+12;progress=canopy+12;params=progress+44
 changes={'canopy_nan':(canopy+4,struct.pack('=d',float('nan'))),'canopy_negative':(canopy+4,struct.pack('=d',-1.0)),'rutter_clock':(progress+36,struct.pack('=d',.0005)),'rutter_clock_nan':(progress+36,struct.pack('=d',float('nan'))),'source_aggregate_nan':(progress+28,struct.pack('=d',float('nan'))),'canopy_cover_invalid':(params+4,struct.pack('=d',2.0)),'micro_carry_nan':(micro+4,struct.pack('=d',float('nan'))),'unexpected_micro_carry':(micro,struct.pack('=i',1))}
 for label,(offset,replacement) in changes.items():
  raw=bytearray(original);raw[offset:offset+len(replacement)]=replacement;raw[-4:]=struct.pack('=I',zlib.crc32(raw[:-4]));p=case/(label+'.bin');p.write_bytes(raw);text=run([exe,'rutter-reject',p,case/'reject',2,1.0],case,'native');assert 'THERMAL_INVALID_RESTART=PASS' in text
 results['negative_count']=13;r['results'][opt]=results;print(opt,'combined PASS',flush=True)
assert r['results']['O0']==r['results']['O2'];r['status']='COMBINED_18475BC_O0_O2_EXACT_RESTART_13_NEGATIVES_PASS_NOT_ADMITTED';r['cost_seconds']={k:sum(e['seconds'] for e in r['events'] if e['category']==k) for k in {e['category'] for e in r['events']}};(OUT/'RESULT.json').write_text(json.dumps(r,indent=2));print(r['status'])
