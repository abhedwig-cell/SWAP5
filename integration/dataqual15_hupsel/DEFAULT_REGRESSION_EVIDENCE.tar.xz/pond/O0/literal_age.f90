module historical_surface_oracle
 use iso_fortran_env,only:real64
 implicit none
contains
 subroutine literal_surface(initial,rain,rc,irr,ic,qtop,pond,dtsolu,cpond,transfer,remaining)
 real(real64),intent(in)::initial,rain,rc,irr,ic,qtop,pond,dtsolu
 real(real64),intent(out)::cpond,transfer,remaining
 real(real64)::csurf,nird,cirr,nraidt,cpre,cfluxt,ArMpSs,isqtop
 csurf=initial;nird=irr;cirr=ic;nraidt=rain;cpre=rc;ArMpSs=0
            csurf = (nird*cirr + nraidt*cpre)*dtsolu + csurf   ! mg cm-2
            if (qtop < -1.d-6) then
               cpond  = csurf / (pond-qtop*dtsolu)             ! mg cm-3
               cfluxt = qtop*(1.0d0-ArMpSs)*cpond*dtsolu       ! mg cm-2
               csurf  = csurf + cfluxt                         ! mg cm-2
               isqtop = qtop*(1.0d0-ArMpSs)*cpond              ! mg cm-2 d-1
            else
               cpond  = 0.0d0
               cfluxt = 0.0d0
            end if
 transfer=-cfluxt;remaining=csurf
 end subroutine
end module
