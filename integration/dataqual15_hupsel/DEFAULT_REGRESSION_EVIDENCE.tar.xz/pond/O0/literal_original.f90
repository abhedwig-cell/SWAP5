module b111_literal_oracle
 use iso_fortran_env,only:real64
 use mod_b111_reactive_solute_substep,only:b111_reactive_solute_substep_forcing_t
 implicit none
contains
 subroutine literal_step(f,cml,cmsy_mass,decay_out,ext_in,ext_out)
 type(b111_reactive_solute_substep_forcing_t),intent(in)::f
 real(real64),intent(inout)::cml(:),cmsy_mass(:)
 real(real64),intent(out)::decay_out,ext_in,ext_out
 integer::numnod,i,level,nrlevs,swhea
 real(real64)::csurf,pond,qtop,ArMpSs,nird,cirr,nraidt,cpre,cpond,isqtop
 real(real64)::dtsolu,cfluxt,cfluxb,cmlav,dispr,cseep,ftemp,gampar,ftheta,rtheta,bexp,decact,ctrans,cref,frexp,tscf,crot,cdrtot,cdrain,isqdra,sqdra,imsqdra,qbot,sqbot,imsqbot,dectot,imdectot,rottot,imrottot
 real(real64)::tsoil(size(cml)),theta(size(cml)),dz(size(cml)),q(size(cml)+1),inpola(size(cml)+1),inpolb(size(cml)),thetav(size(cml)),dispr1(size(cml)),vpore2(size(cml)),disnod(size(cml)+1),decpotfdepth(size(cml)),bdenskfcref(size(cml)),bdenskf(size(cml)),qrot(size(cml)),cmsy(size(cml)),imqsol(size(cml)+1),qdra(size(f%qdra_cm_day,1),size(cml))
 numnod=size(cml);nrlevs=size(f%qdra_cm_day,1)
 tsoil=f%temperature_c;theta=f%theta;dz=f%dz_cm;q=f%q_face_up_cm_day;qdra=f%qdra_cm_day
 qrot=f%root_sink_cm_day;tscf=f%tscf;cdrain=f%cdrain_mg_cm3;cseep=f%cseep_mg_cm3
 dtsolu=f%dt_day;cref=f%cref_mg_cm3;frexp=f%frexp;swhea=0
 if(f%temperature_active)swhea=1
 gampar=f%gampar(1);rtheta=f%rtheta(1);bexp=f%bexp(1)
 bdenskf=f%bulk_density*f%kf;bdenskfcref=bdenskf*cref
 decpotfdepth=f%decpot*f%fdepth
 cmsy=cmsy_mass/dz
 inpola=0;inpolb=0;disnod=1;thetav=0;dispr1=0;vpore2=0
 inpola(2:numnod)=f%face_left_weight;inpolb(1:numnod-1)=f%face_right_weight
 disnod(2:numnod)=f%face_distance_cm
 do i=1,numnod-1
 thetav(i)=inpola(i+1)*theta(i)+inpolb(i)*theta(i+1)
 vpore2(i)=(abs(q(i+1))/thetav(i))**2
 dispr1(i)=f%molecular_diffusion_cm2_day*thetav(i)**2.33d0/f%theta_sat_left(i)**2+f%dispersivity_cm(i)*abs(q(i+1))/thetav(i)
 end do
 imqsol=0;
 csurf=0;pond=0;qtop=f%q_face_up_cm_day(1);ArMpSs=0
 nird=f%irrigation_rate_cm_day;cirr=f%irrigation_c_mg_cm3
 nraidt=f%rain_rate_cm_day;cpre=f%rain_c_mg_cm3
dectot=0;imdectot=0;rottot=0;imrottot=0
 isqdra=0;sqdra=0;imsqdra=0;sqbot=0;imsqbot=0;qbot=q(numnod+1)
            csurf = (nird*cirr + nraidt*cpre)*dtsolu + csurf   ! mg cm-2
            if (qtop < -1.d-6) then
               cpond  = csurf / (pond-qtop*dtsolu)             ! mg cm-3
               cfluxt = qtop*(1.0d0-ArMpSs)*cpond*dtsolu       ! mg cm-2
               csurf  = csurf + cfluxt                         ! mg cm-2
               isqtop = qtop*(1.0d0-ArMpSs)*cpond              ! mg cm-2 d-1
            else
               cpond  = 0.0d0
               cfluxt = 0.0d0
            end if
            do i = 1, numnod

! ---          convective and dispersive fluxes
               if (i < numnod) then
                  cmlav = inpola(i+1) * cml(i) + inpolb(i) * cml(i+1)
                  !thetav = inpola(i+1)*theta(i)+inpolb(i)*theta(i+1)
                  !vpore = abs(q(i+1))/thetav
                  !diffus = ddif*(thetav**2.33d0)/(thetsl(layer(i))**2)
                  !dispr = diffus + ldis(layer(i)) * vpore + 0.5d0 * dtsolu*vpore*vpore
                  dispr = dispr1(i) + 0.5d0 * dtsolu*vpore2(i)
                  cfluxb = (q(i+1)*cmlav + thetav(i) * dispr * (cml(i+1)-cml(i))/disnod(i+1))*dtsolu
               else
                  if (q(i+1) > 0.0d0) then
                     cfluxb = q(i+1)*cseep*dtsolu
                  else
                     cfluxb = q(i+1)*cml(i)*dtsolu
                  end if
               end if
               
               if (i > 1) imqsol(i) = imqsol(i) + cfluxb

! ---          solute decomposition
               if (swhea > 0) then
                  if (tsoil(i) < 35.0d0) then
                     ftemp = exp(gampar*(tsoil(i)-20.0d0))
                  else
                     ftemp = exp(gampar*15.0d0)
                  end if
               else
                 ftemp = 0.0d0
               end if
               ftheta = min(1.0d0,(theta(i)/rtheta)**bexp)
               decact = decpotfdepth(i) * ftemp * ftheta
               ctrans = decact*theta(i)*cml(i) + decact*bdenskfcref(i)*((cml(i)/cref)**frexp)
               dectot = dectot + ctrans*dtsolu*dz(i)
               imdectot = imdectot + ctrans*dtsolu*dz(i)

! ---          solute uptake by plant roots
               crot   = tscf*qrot(i)*cml(i)/dz(i)
               rottot = rottot + tscf*qrot(i)*cml(i)*dtsolu
               imrottot = imrottot + tscf*qrot(i)*cml(i)*dtsolu

! ---          lateral drainage
               cdrtot = 0.0d0
               do level = 1, nrlevs
                  if (qdra(level,i) > 0.0d0) then
                     cdrtot = cdrtot+qdra(level,i)*cml(i)/dz(i)
                  else
                     cdrtot = cdrtot+qdra(level,i)*cdrain/dz(i)
                  end if
               end do

! ---          cumulative amount of solutes to lateral drainage
               isqdra = isqdra + cdrtot*dz(i)*dtsolu
               sqdra  = sqdra + cdrtot*dz(i)*dtsolu
               imsqdra  = imsqdra + cdrtot*dz(i)*dtsolu

! ---          conservation equation for the substance
               cmsy(i) = cmsy(i) + (cfluxb-cfluxt) / dz(i) + (-ctrans-crot-cdrtot) * dtsolu

               ! since bottom boundary condition is treated explicitly we MUST calculate sqbot here (before CML is recalculated)
               ! this prevents errors in sbaldev
               if (i == numnod) then
                  ! --- flux through bottom of soil profile
                  if (qbot > 0.0d0) then
                     sqbot = sqbot + qbot*cseep*dtsolu
                     imsqbot = imsqbot + qbot*cseep*dtsolu
                  else
                     sqbot = sqbot + qbot*cml(numnod)*dtsolu
                     imsqbot = imsqbot + qbot*cml(numnod)*dtsolu
                  end if
               end if
                     cml(i) = cmsy(i) / (theta(i) + bdenskf(i))
               cfluxt = cfluxb
 end do
 cmsy_mass=cmsy*dz
 decay_out=dectot
 ext_in=(nird*cirr+nraidt*cpre)*dtsolu;ext_out=dectot+rottot
 do i=1,numnod
 do level=1,nrlevs
 if(qdra(level,i)>0)then
 ! Drain receipts can be evaluated from the literal mass balance, below.
 end if
 end do
 end do
 ! Signed sum is authoritative for the total balance; tests separately check
 ! production positive and negative boundary receipts in contract scenarios.
 ext_out=ext_out+sqdra-sqbot
 end subroutine
end module
