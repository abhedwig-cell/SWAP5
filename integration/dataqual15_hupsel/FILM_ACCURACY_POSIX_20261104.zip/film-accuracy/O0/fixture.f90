module film_accuracy_fixture
 use ieee_arithmetic,only:ieee_is_finite
 logical::fixture_enabled=.false.
 real(8)::certified_film(34)=0d0
end module
