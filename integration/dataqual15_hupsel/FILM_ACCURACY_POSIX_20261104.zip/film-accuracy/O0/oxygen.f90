! File VersionID:
!   $Id: oxygenstress.f90 378 2018-05-08 13:50:52Z heine003 $
!
! ----------------------------------------------------------------------

! ## MH: December 2017
! Changes to optimize performance of routine OxygenStress.
! In summary:
!  * certain repeatedly calculated constants have been predefined as constant parameters for further use:
!        Fac3230 = 32.0d0/30.0d0
!        d_o2inwater_ref = 1.0d-5*1.2d0/(100.0d0*100.0d0)
!        SecsPerDay = 24.0d0*3600.0d0
!        Tref3 = 1.0d0/(293.0d0**3)
!        pi4 = 4.0d0*pi
!        h1        =   25000.0d0
!        h2        =  762500.0d0
!        h3        = 1500000.0d0
!        log10h1   = dlog10(h1)
!        log10h2   = dlog10(h2)
!        log10h3   = dlog10(h3)
!        log10h3h2 = log10h3 - log10h2
!        FourThird = 4.0d0/3.0d0
!  * Since division is slower than multiplication, where relevant changes were made; e.g. /10.0 = 0.1*
!  * Other change: ()**0.5 replaced by sqrt()
!  * For the calculation of d_soil, constant properties per node were repeatedly calcuated.
!        New: this has been done only once (routine calc_ini_pars) and these properties were stored
!             for all nodes (1..numnod)
!  * From a profiling analysis it became evident that the numerical integration in the routine 
!    waterfilmthickness was a high-demanding CPU unit.
!        The originally chosen method, trapezoidal rule, is straightforward and robust. 
!        If we assume that our function is sufficiently smooth and has no singularities (also not at the end points)
!        then it is better to use the Romberg Integration method (see Press et al., 1987, Numerical Recipes). 
!        This method takes "many, many fewer" function evaluations than the trapezoidal rule alone, 
!        even though the Romberg method makes use of the trapezoidal rule itself.
!        Implementation of this method decreased the CPU time drastically for a loam case study.
!        Currently both methods are still present in the code, and can be switched by a logical parameter flag
!        that is defined in the subroutine waterfilmthickness: 
!           flUseQromb = .TRUE. (use Romberg integration; else use orginal trapezoidal integration)
!  * Function FUNC makes use of the derivative of the water retention curve. The equation provided in
!    Bartholomeus et al. (2008; J. Hydrol 360:147-165; their appendix A.4) can be further simplified given by:
!        C = (sat_water_cont - res_water_cont) * alpha * ( (ax)**(gen_n - 1.d0) ) * ( ( 1.d0 + axn )**(-gen_m - 1.d0) )* gen_m*gen_n
!           where ax = alpha*x and axn = (alpha*x)**gen_n
!    Therefore, initially three constants per node are calculated ands stored for later use:
!        Capac_term(i) = (WCs-WCr)*Alpha*N*M
!        Nmin1(i)      = N-1
!        Mplus1(i)     = M+1
!  * Two constants initially set in Calc_ini_pars: shape_factor_microbialr, shape_factor_rootr
!  * An alternative solution for function SOLVE has been implemented: using ZBREND from Numerical Recipes (Press et al., 1987).
!        In function SOLVE the programmer can switch between original approach (Newton-Raphson) or 
!        the new approach (ZBREND) via a logical parameter (useZBREND). 
!        New method resulted in negligable differences, but is somewhat faster.
!        For the implementation of the ZBREND method with the required defintion of a function (myfunc)
!        it was helpful to move a large number of variables into a module (O2_pars). In this way it was
!        prevented to carry-over a large number of arguments from SOLVE to ZBREND to myfunc.
!        In principle, O2_pars can also bue used in other routines/functions resulting in less arguments
!        in their calls. This has not yet been implemented.
    
module O2_pars
   
   use MOD_arrays,          only: macp
   use MOD_grid,            only: ztopcp
   use MOD_cropdevelopment, only: q10_microbial, specific_resp_humus, rootradius_m
   
   real(8), save :: w_root,w_root_z0
   real(8), save :: soil_temp
   real(8), save :: sat_water_cont,gas_filled_porosity
   real(8), save :: d_o2inwater,d_root,perc_org_mat,soil_density
   real(8), save :: d_soil   
   real(8), save :: depth

   real(8), dimension(macp), save :: c_top        ! Oxygen concentration at top of compartment(kg/m3)

   real(8), save :: r_microbial_z0
   real(8), save :: waterfilm_thickness,bunsencoeff
   real(8), save :: c_min_micro,c_macro,ctopnode
   
   ! microbial respiration calculated from organic matter content in actual soil compartment; keep this value fixed
   real(8), parameter :: shape_factor_microbialr = 0.9d0 ! shape factor
   real(8), parameter :: shape_factor_rootr = 0.9d0      ! shape factor for exponential decrease of root respiration rate with depth [0..1.0 -, R]
   
end module O2_pars

! ## MH      subroutine OxygenStress(node,rwu_factor,ResultsOxStr) 
      subroutine OxygenStress(node,rwu_factor) 
! ----------------------------------------------------------------------
!     Last modified      : January 2014              
!     Purpose            : calculates oxygen stress according to Bartholomeus et al. (2008)
! ----------------------------------------------------------------------
      use film_accuracy_fixture, only: fixture_enabled, certified_film
      use MOD_arrays,            only: macp, matab
      use MOD_grid,              only: layer, numnod, dz
      use atmosphere_interface,  only: tav
      use plant_interface,       only: max_resp_factor
      use MOD_MvG,               only: swsophy, iHWCKmodel, cofgen, numtablay, sptab
      use variables,             only: THETA, H, DIMOCA

      use O2_pars,               only: w_root,w_root_z0, soil_temp, sat_water_cont,gas_filled_porosity, d_o2inwater,d_root,        &
                                       perc_org_mat,soil_density,depth, waterfilm_thickness,                                       &
                                       bunsencoeff, c_min_micro, c_macro,ctopnode,r_microbial_z0, d_soil, c_top

      use MOD_cropdevelopment,   only: q10_microbial, specific_resp_humus, srl, wroot_node_top
      use MOD_texture_orgmat,    only: orgmat, psand, bdens
      use MOD_SoilTemperature,   only: tsoil
      
      implicit none
      integer, intent(in)        :: node
      real(8), intent(out)       :: rwu_factor
      
! --- local
      integer                    :: glit,lay,i,j
      real(8)                    :: resp_factor,xi,accuracy
      real(8)                    :: theta0
      real(8)                    :: matric_potential
      real(8)                    :: air_temp,alpha,d_gassfreeair,gen_n,o2_atmosphere,percentage_sand,surface_tension_water
      real(8)                    :: SOLVE
      real(8)                    :: soilphystab(7,matab)
      real(8)                    :: diff_water_cap_actual
      integer                    :: numrec_tab

      !real(8) rd_noddrz
! ## MH : why ResultsOxStr as argument andlocally stored, whereas ResultsOxygenStress was already globally defined in varibles ???
! ## MH      real(8) ResultsOxStr(19,macp)    ! result oxygen stress; tabulated for each model compartment
! ## MH : calcluations ResultsOxStr disabled because it is never used anywhere in SWAP
! ## MH : alternative use switch (flag) to choose whether or not to calculate ResultsOxStr (for debugging purposes)
      
      real(8), dimension(macp)   :: d_soil_term1, d_soil_term2, gfp100
      real(8), dimension(macp)   :: Capac_term, Nmin1, Mplus1
      logical                    :: ini = .TRUE.
      
!     save values of locals
      save
      !save   waterfilm_thickness,r_microbial_z0,d_soil
      !save   d_soil_term1, d_soil_term2, ini, gfp100

!## MH : some initial calculations      
      if (ini) then
         if (iHWCKmodel(layer(node)) == 3) then
            call swap_error ('oxygenstress', 'Combination of OXYGENSTRESS and bi-modal MvG (iHWCKmodel=3) is not (yet) possible!')
         end if
         call calc_ini_pars (numnod)
         ini = .FALSE.
      end if
!## MH: end

! --- initialize
      c_min_micro = 0.1d0
      c_macro = 0.2d0
      resp_factor = 1.d0

! --- soil layer in SWAP
      lay = layer(node)

! --- dry weight of root per unit length of root [kg/m]
      w_root = 1.d0 / srl

! --- extract a number of variables from Swap forlocal use in module OxygenStress

! --- set soil density [kg m-3]      
      soil_density = bdens(lay) 
! --- set parameter n of soil hydraulic functions           
      gen_n = cofgen(6,node) 
! --- set saturated water content [-]      
      sat_water_cont = cofgen(2,node) 
! --- set parameter alpha [1/Pa] of soil hydraulic functions, so divide main swap alpha by 100     ## MH: =0.01* 
      alpha = 0.01d0 * cofgen(4,node)
! --- set percentage organic matter [%]
      perc_org_mat = orgmat(lay) * 100.0d0 
! --- set percentage sand in % of total soil            
      percentage_sand = (psand(lay) * (1.d0 - orgmat(lay))) * 100.0d0 
! --- get soil moisture content as defined in further calculations within this routine [-]      
      theta0 = theta(node) 
! --- gas filled porosity      
      gas_filled_porosity = dmax1(0.d0, sat_water_cont - theta0)
      if (h(node) >= 0.0d0) gas_filled_porosity = 0.d0     ! be sure when saturated that gas_filled_porosity = 0

! --- thickness of the soil compartment [m]     ## MH: =0.01* 
      depth = 0.01d0 * dz(node)
! --- temperature in the soil compartment [K]
      soil_temp = tsoil(node) + 273.d0  
! --- dry weight of roots at nodal depth
      w_root_z0 = wroot_node_top(node)

! --- Calculate matric potential [Pa]
       matric_potential = -100.0d0 * h(node)          
! --- if gas filled porosity = 0, then root water uptake = 0. Store results and go to end of routine.
      if (gas_filled_porosity < 1.d-4) then
         rwu_factor = 0.d0
         c_macro = 0.d0
         c_top(node+1) = C_macro
      else   ! (if (gas_filled_porosity < 1.0d-6)) 
        
! --- In case of tabular soil hydraulic functions
        if (swsophy == 1) then
! --- Get tabular soil hydraulic function for node
          do i = 1, 7
            do j = 1, numtablay(lay)  !check this
              soilphystab(i,j) = sptab(i,node,j)
            end do
          end do
! --- Get differential water capacity at actual node, (/L --> /Pa)
          diff_water_cap_actual = 0.01d0 * dimoca(node)
          numrec_tab = j-1
        end if

! --- atmosphere oxygen concentration [kg/m3] according to general gas law
        if (node == 1) then
! ---   atmospheric temperature [K]      
          air_temp = tav + 273.d0
          o2_atmosphere = (672.d0) / (8.314472d0 * air_temp)
! ---   PLAATS O2_atmosphere IN DE VECTOR VOOR C_TOP 
          c_top(1) = o2_atmosphere
        end if    

! --- Calculate temperature dependent parameters
        call TEMP_DEPENDENT_PARAMETERS (d_o2inwater,d_root,             &
            d_gassfreeair,surface_tension_water,bunsencoeff,soil_temp)

! --- Calculate diffusivity Dsoil
!## MH: d_soil_term1, d_soil_term2 and gfp100 were initially calculated and stored per node
        d_soil = d_gassfreeair * d_soil_term1(node) * ((gas_filled_porosity / gfp100(node))**d_soil_term2(node))
!## MH: end
        
! --- Calculate the thickness of the water film that surrounds the roots      
        call waterfilmthickness (waterfilm_thickness,                   &
          matric_potential,Capac_term(node),Nmin1(node),Mplus1(node),   &
             alpha,gen_n,surface_tension_water,glit,                    &
                soilphystab,diff_water_cap_actual,numrec_tab)

        if(fixture_enabled)waterfilm_thickness=certified_film(node)
! --- Calculate microbial respiration rate
        call microbial_resp (r_microbial_z0,soil_temp,perc_org_mat,     &
            soil_density,percentage_sand,matric_potential,              &
               specific_resp_humus,q10_microbial)

! --- Calculate sink term variable
! --- Define input for the solving procedure
        xi = 0.5d0 * max_resp_factor
        accuracy = 1.d-4
        ctopnode = c_top(node)

! --- Calculate actual respiration factor from the solving procedure
        resp_factor =  SOLVE(xi,accuracy)

! --- PLAATS C_MACRO IN DE VECTOR VOOR C_TOP. BEREKENDE WAARDE IS INPUT VOOR VOLGENDE COMPARTIMENT
       c_top(node+1) = C_macro

! --- Calculate the sink term (Root Water Uptake) variable due to oxygen stress.
! --- The decrease in root water uptake is assumed proportional to the decrease
! --- in respiration (given by the maximum and actual respiration factor).

! RB 20140106 start if statement added; if max_resp_factor = 1 then no stress so rwufactor = 1        
          if (max_resp_factor > 1.0d0) then
            rwu_factor = (resp_factor - 1.d0) / (max_resp_factor - 1.d0)
          else
! Ruud Bartholomeus: 19-12-2017
! Wat betreft zuurstofstress als er geen enkele groei van de wortels meer is:
! -  De lineaire afname van RWU met afname van groeirespiratie van de wortels moeten we handhaven. Rwu_factor = 1 als groeirespiratie is optimaal, rwu_factor = 0 als geen groeirespiratie.
! -  Als er geen groeirespiratie van de wortels meer is, maar wel groei van bovengrondse delen is er nog wel transpiratie en dus wateropname van de wortels
! -  Als er geen groeirespiratie van de wortels meer nodig is, maar er wel voldoende zuurstof is voor onderhoudsrespiratie, dan functioneren de wortels dus zoals het moet en nemen ook water op. Als er onvoldoende zuurstof is voor onderhoudsrespiratie van de wortels, dan sterven deze. Ze nemen dan geen water op. 
! -  Voorstel voor verbetering in de code: 
!        o  Als max_resp_factor = 1 en resp_factor < 1 DAN rwu_factor = 0
!        o  Hier zit dus geen geleidelijke afname: onvoldoende zuurstof voor onderhoud = stop 

             if (resp_factor < 1.d0) then
               rwu_factor = 0.d0      !## MH: suggested by RB 19-12-2017: rwu_factor = 0  : orignal code before 19-12-2017: rwu_factor = 1.0d0
            else
               rwu_factor = 1.d0
            end if
          end if
! RB 20140106 end if statement added

          if (rwu_factor > 1.d0) then
             rwu_factor = 1.d0
          end if
          if (rwu_factor < 0.d0) then
              rwu_factor = 0.d0
          end if
      
      end if !if (gas_filled_porosity < 1.0d-6) !RB20131216 goto removed
      
      return
      
   contains
   
   subroutine calc_ini_pars (numnod)
!## MH : these constant can be calculated only once at initial call to OxygenStress
!## MH : results are stored and saved per node
!## MH : since it is part of subroutine OxygenStress (via the previous statement "contains")
!## MH : the output variables are known at this level and not need to be part of the list of arguments
   use MOD_MvG,               only: watcon
   use MOD_cropdevelopment,   only: campbell_h100, campbell_h500, gfp_h100
   implicit none
   integer, intent(in)        :: numnod
   integer                    :: i
   real(8)                    :: log10h100, log10h500
   real(8)                    :: theta100, theta500, campbell_b
   
   log10h100 = dlog10(-campbell_h100)
   log10h500 = dlog10(-campbell_h500)
   
   do i = 1, numnod
! --- get theta at h=-100 cm and at h=-500 cm; for diffusion coef
      theta100 = watcon(i,campbell_h100)
      theta500  = watcon(i,campbell_h500)
      campbell_b = (log10h500-log10h100) / (dlog10(theta100)-dlog10(theta500))
      
      theta100 = watcon(i,gfp_h100)
      sat_water_cont = cofgen(2,i)
      gfp100(i) = sat_water_cont - theta100
      
      d_soil_term1(i) = 2.0d0*(gfp100(i)**3)+0.04d0*gfp100(i)
      d_soil_term2(i) = 2.0d0+3.0d0/campbell_b
!     for use in FUNC
!     cofgen(x,i): x = 1...12
!     1 = thetar; 2 = thetas, 3 = Ksatfit; 4 = alpha; 5 = lambda; 6 = n; 7 = m (=1-1/n); 
!     8 = dummy; 9 = h_enpr; 10 = Ksatexm; 11 = relsatthr; 12 = Ksatthr
!     Calculate (sat_water_cont - res_water_cont) * alpha * gen_m * gen_n
      Capac_term(i)   = (cofgen(2,i) - cofgen(1,i)) * 0.01d0*cofgen(4,i) * cofgen(6,i) * cofgen(7,i)
      Nmin1(i)        = cofgen(6,i) - 1.0d0
      Mplus1(i)       = cofgen(7,i) + 1.0d0 
   end do
   return
   end subroutine calc_ini_pars
   

   end subroutine OxygenStress

! --- End of main module OxygenStress ---------------------------------------------------------------------------------------
      
      subroutine TEMP_DEPENDENT_PARAMETERS (d_o2inwater,d_root,         &
         d_gassfreeair,surface_tension_water,bunsencoeff,soil_temp)

      implicit none
      real(8), intent(in)     :: soil_temp
      real(8), intent(out)    :: d_o2inwater,d_root,d_gassfreeair
      real(8), intent(out)    :: surface_tension_water,bunsencoeff
!     ## MH: d_o2inwater_ref = 24.0d0*3600.0d0*((1.0d-5*1.2d0/(100.0d0*100.0d0))
      real(8), parameter      :: d_o2inwater_ref = 1.0d-5*1.2d0/(100.0d0*100.0d0)
      real(8), parameter      :: SecsPerDay = 24.0d0*3600.0d0
!     ## MH: Tref3 = 1/(293.0d0**3)
      real(8), parameter      :: Tref3 = 1.0d0/(293.0d0**3)
      
! --- Calculate parameters that depend on temperature
! --- diffusion coefficient for oxygen in water [m2/d] Lango et al 1996
!     ## MH:
      d_o2inwater = SecsPerDay*(d_o2inwater_ref * dexp(0.026d0*(soil_temp-273.0d0)))
! --- diffusion coefficient for oxygen in root tissue [m2/d]
! --- scaled to d_o2inwater, according the value given by
! --- van noordwijk & de willigen 1987 at 293 k
      d_root = 0.4d0*d_o2inwater
! --- diffusion coefficient for oxygen in free air [m2/d]
! --- hirschfelder et al 1964 molecular theory of gases and liquids
!     ## MH: Tref3 = 1/(293.0d0**3)
      d_gassfreeair = 1.74528d0 * (soil_temp**3)*Tref3
! --- surface tension of water [n/m] eotvos rule
      surface_tension_water = 0.07275d0 *                               &
                            ( 1.0d0 - 0.002d0 * (soil_temp - 291.0d0 ) )
! --- bunsen solubility coeff for oxygen Lango et al 1996
!## MH     &         (1413.d0*(exp(-144.397d0+7775.18d0*(soil_temp**(-1.d0))  &
      bunsencoeff =                                                     &
               (1413.d0*(dexp(-144.397d0+7775.18d0/soil_temp            &
                    +18.3977d0*dlog(soil_temp)+0.0094437d0*soil_temp))) &
                    *273.15d0/soil_temp 
      return
      end subroutine TEMP_DEPENDENT_PARAMETERS

      real(8) function FUNC(x,Capac_term,Nmin1,Mplus1,alpha,gen_n,      &
                            surface_tension_water)

      use parameters, only: pi
      
      implicit none
      real(8), intent(in)     :: x
      real(8), intent(in)     :: Capac_term,Nmin1,Mplus1
      real(8), intent(in)     :: alpha,gen_n,surface_tension_water
      real(8), parameter      :: pi4 = 4.d0*pi         ! ## MH
      real(8)                 :: ax, axn                          ! ## MH
! --- function needed for calculation of length density of gas filled pores in
! ---   subroutine 'water film thickness'                                          
      ax  = alpha * x
      axn = ax**gen_n
      func= Capac_term * ax**Nmin1 * ( ( 1.d0 + axn )**(-Mplus1) ) /    &
            (pi4 * surface_tension_water**2/x**2)
     !!!!! func= -(( -(sat_water_cont - res_water_cont) * alpha *            &    
     !!!!!&      ( (ax)**(gen_n - 1.d0) ) *                                  &
     !!!!!&      ( ( 1.d0 + axn )**(gen_m - 1.d0) )*                         &
     !!!!!&      gen_m*gen_n ) /                                             &
     !!!!!&      (((( axn ) + 1.d0 )**gen_m)**2) ) /                         &
     !!!!!&      (pi4*(((surface_tension_water**2)/(x**2))))
     !!! func= -( -(sat_water_cont - res_water_cont) * alpha *            &    
     !!!&      ( (ax)**(gen_n - 1.d0) ) *                                  &
     !!!&      ( ( 1.d0 + axn )**(-gen_m - 1.d0) )*                        &
     !!!&      gen_m*gen_n ) /                                             &
     !!!&      (pi4*(((surface_tension_water**2)/(x**2))))
      return
      end function FUNC

      real(8) function FUNCtab(x,diff_water_cap,surface_tension_water)

      use parameters, only: pi
      implicit none
      real(8), intent(in)     :: x
      real(8), intent(in)     :: diff_water_cap,surface_tension_water
      real(8), parameter      :: pi4 = 4.0d0*pi         ! ## MH
! --- function needed for calculation of length density of gas filled pores in
! ---   subroutine 'water film thickness'                                          
      functab= diff_water_cap / (pi4*(surface_tension_water**2)/(x**2))
      return
      end function FUNCtab    

!## MH: Romberg could be a better (=faster) method; ask Ruud if he considered this
      subroutine TRAPZD(a,b,s,n,Capac_term,Nmin1,Mplus1,alpha,gen_n,    &
                        surface_tension_water,glit)
     
      implicit none
      integer, intent(in)     :: n
      real(8), intent(in)     :: a,b
      real(8), intent(in)     :: Capac_term,Nmin1,Mplus1
      real(8), intent(in)     :: alpha,gen_n,surface_tension_water
      integer, intent(inout)  :: glit
      real(8), intent(inout)  :: s
      real(8) FUNC
! --- procedure from numerical recipes. calculate integral numerically
! --- Needed for procedure 'water film thickness'                                
! --- programs calling trapzd must provide a function
! --- func(x:real(8)):real(8)which is to be integrated. they must
! --- also define the variable
! --- var glit: integer;
! --- in the main routine. *)
!RB20140312 sum replaced by mysum
      integer                 :: j
      real(8)                 :: x,tnm,mysum,del
     
! ---  initialize j
      j=0
      if (n == 1) then
         s = 0.5d0*(b-a)*(func(a,Capac_term,Nmin1,Mplus1,alpha,gen_n,surface_tension_water)  &
                        + func(b,Capac_term,Nmin1,Mplus1,alpha,gen_n,surface_tension_water))
         glit = 1
      else
         tnm = dble(glit)
         del = (b-a)/tnm
         x = a+0.5d0*del
         mysum = 0.0d0
         do while (j < glit) 
            mysum = mysum+func(x,Capac_term,Nmin1,Mplus1,alpha,gen_n,surface_tension_water)
            x = x+del
            j = j + 1
         end do
         s = 0.5d0*(s+(b-a)*mysum/tnm)
         glit = 2*glit
      end if
      return
      end subroutine TRAPZD

      subroutine TRAPZDtab(a,b,s,n,diff_water_cap,                      &
                           surface_tension_water,glit)
     
      implicit none
      integer, intent(in)     :: n
      real(8), intent(in)     :: a,b
      real(8), intent(in)     :: diff_water_cap
      real(8), intent(in)     :: surface_tension_water
      integer, intent(inout)  :: glit
      real(8), intent(inout)  :: s
      real(8) functab
! --- procedure from numerical recipes. calculate integral numerically
! --- Needed for procedure 'water film thickness'                                
! --- programs calling trapzd must provide a function
! --- func(x:real(8)):real(8)which is to be integrated. they must
! --- also define the variable
! --- var glit: integer;
! --- in the main routine. *)
!RB20140312 sum replaced by mysum
      integer                 :: j
      real(8)                 :: x,tnm,mysum,del
! ---  initialize j
      j=0
      if (n == 1) then
         s = 0.5d0*(b-a)*(functab(a,diff_water_cap, surface_tension_water)  &
                         +functab(b,diff_water_cap, surface_tension_water))
         glit = 1
      else
         tnm = dble(glit)
         del = (b-a)/tnm
         x = a+0.5d0*del
         mysum = 0.0d0
         do while (j < glit) 
            mysum = mysum+functab(x,diff_water_cap,surface_tension_water)
            x = x+del
            j = j + 1
         end do
         s = 0.5d0*(s+(b-a)*mysum/tnm)
         glit = 2*glit
      end if
      return
      end subroutine TRAPZDtab

      subroutine waterfilmthickness (waterfilm_thickness,               &
         matric_potential,Capac_term, Nmin1, Mplus1,                    &
            alpha,gen_n,surface_tension_water,glit,                     &
               soilphystab,diff_water_cap_actual,numrec_tab)
! --- calculate water film thickness. method according to simojoki 2000
      use MOD_arrays, only: matab
      use parameters, only: pi
      use MOD_MvG,    only: swsophy
      use doln
      implicit none

      integer, intent(in)     :: numrec_tab
      real(8), intent(in)     :: matric_potential
      real(8), intent(in)     :: alpha,gen_n,surface_tension_water,Capac_term, Nmin1, Mplus1
      real(8), intent(in)     :: soilphystab(7,matab)
      real(8), intent(in)     :: diff_water_cap_actual
      integer, intent(inout)  :: glit    
      real(8), intent(out)    :: waterfilm_thickness

      integer                 :: i,ii
      real(8)                 :: new,old,s
      real(8)                 :: length_density_gas_pores, length_density_gas_pores_sub
      real(8)                 :: lowlim,upplim,diff_water_cap,htab
      logical, parameter      :: flUseQromb = .TRUE. !## MH: (use Romberg integration; else use orginal trapezoidal integration)
      
      save s

!     Extremely dry; to prevent problems in integration below (observed for coarse sand) we set waterfilm_thickness to som low value
!        This will ensure no oxygen related stress (?)
      if (matric_potential > 1.0d7) then
         waterfilm_thickness = 1.0d-8
         return
      end if
      
      if (swsophy == 0) then
! --- calculate length density air filled (gas) pores. [number per m2]
! --- subroutine trapdz is used to solve the integral defined in
! --- function 'func'.
        i = 1
        if (flUseQromb) then
           call QROMBD(1.d-10,matric_potential,s,Capac_term,            &
               Nmin1,Mplus1,alpha,gen_n,surface_tension_water,glit)
        else
           call TRAPZD(1.d-10,matric_potential,s,i,Capac_term,          &
               Nmin1,Mplus1,alpha,gen_n,surface_tension_water,glit)
        end if
        new = s
        old = new + new

        do while (dabs(new-old) > 0.00001d0*new) 
          i = i + 1
          if (flUseQromb) then
            call QROMBD(1.d-10,matric_potential,s,Capac_term,           &
               Nmin1,Mplus1,alpha,gen_n,surface_tension_water,glit)
          else
            call TRAPZD(1.d-10,matric_potential,s,i,Capac_term,         &
               Nmin1,Mplus1,alpha,gen_n,surface_tension_water,glit)
          end if
          old = new
          new = s
        end do
! --- result from trapzd and func:      
        length_density_gas_pores = new
! --- calculated water film thickness [m]
        waterfilm_thickness = 2.d0 *                                    &
         ( ( dsqrt( 1.0d0 / ( pi * length_density_gas_pores ) ) )       &  ! ## MH: replaced ()**0.5 by dsqrt()
         - 2.0d0 * surface_tension_water / matric_potential )
      end if
      !!!!sptab(1,node,ii) = soilphystab(1,ii)
      if (swsophy == 1) then
          ii = numrec_tab !34  !run over points in soil hydraulic table
! --- lower value of matric potential for integration interval
         lowlim = 0.000001d0 !-100*soilphystab(1,ii) !initial value should be zero !RB20140725, very close to zero, otherwise/0 in functab
! --- upper value of matric potential for integration interval
         if (do_ln_trans) then
            upplim = -100.d0*0.5d0*(-(dexp(-soilphystab(1,ii))-1.0d0) - (dexp(-soilphystab(1,ii-1))-1.0d0)) !middle of points 1 and 2
         else
            upplim = -100.d0*0.5d0*(soilphystab(1,ii)+soilphystab(1,ii-1)) !middle of points 1 and 2
         end if
         upplim = MIN(upplim, matric_potential) !upplim can be higher than matpot          
! --- initialize length density gas filled pores
         length_density_gas_pores = 0.0d0 !initial value
! --- start loop, i.e. run over full integration interval;
! --- in each loop, the length density of gas filled pores of that interval is calculated;
! --- The sum of all loops gives the total length density.
! --- The integration interval runs from 0 to the matric potential at the actual node
         do while ((upplim < matric_potential) .AND. (ii > 2)) !adjusted RB20150714 ii > 2 added
            if (do_ln_trans) then
               htab = -(dexp(-soilphystab(1,ii))-1.0d0)
               diff_water_cap = 0.01d0*soilphystab(4,ii)/(-htab+1.0d0) !at matric potential centre of lowlim and upplim, except for first point
            else
               diff_water_cap = 0.01d0*soilphystab(4,ii) !at matric potential centre of lowlim and upplim, except for first point
            end if
            if (flUseQromb) then
               call QROMBDtab(lowlim,upplim,s,diff_water_cap,           & !n=1 as integral is over a linear function, i.e. convergence is reached after one step
                              surface_tension_water,glit)
            else
               call TRAPZDtab(lowlim,upplim,s,1,diff_water_cap,         & !n=1 as integral is over a linear function, i.e. convergence is reached after one step
                              surface_tension_water,glit)
            end if
            length_density_gas_pores_sub = s
            length_density_gas_pores = length_density_gas_pores +       &
                                       length_density_gas_pores_sub
            ii = ii - 1
            lowlim = upplim
!##MH            upplim=-100.d0*0.5d0*(soilphystab(1,ii)+soilphystab(1,ii-1))
            if (do_ln_trans) then
               upplim = -100.d0*0.5d0*(-(dexp(-soilphystab(1,ii))-1.0d0) - (dexp(-soilphystab(1,ii-1))-1.0d0)) !middle of points 1 and 2
            else
               upplim = -100.d0*0.5d0*(soilphystab(1,ii)+soilphystab(1,ii-1)) !middle of points 1 and 2
            end if
          end do
! --- in the last step (upplim >= matric_potential), always use the differential water capacity corresponding to the actual matric_potential of the node
          diff_water_cap = diff_water_cap_actual 
          upplim = MIN(upplim, matric_potential)
          if (flUseQromb) then
            call QROMBDtab(lowlim,upplim,s,diff_water_cap,              & !n=1 as integral is over a linear function, i.e. convergence is reached after one step
                           surface_tension_water,glit)
          else
            call TRAPZDtab(lowlim,upplim,s,1,diff_water_cap,            &  ! n=1 as integral is over a linear function, i.e. convergence is reached after one step
                           surface_tension_water,glit)
          end if
          length_density_gas_pores_sub = s
          length_density_gas_pores = length_density_gas_pores +         &
                                     length_density_gas_pores_sub
! --- calculated water film thickness [m]
          waterfilm_thickness = 2.0d0 *                                 &
           ( ( dsqrt( 1.d0 / ( pi * length_density_gas_pores ) ) )      &  ! ## MH: replaced ()**0.5 by dsqrt()
             - 2.d0 * surface_tension_water / matric_potential )
      end if
      !ResultsOxStr(7,node) = waterfilm_thickness !RB20140115
      return
      end subroutine waterfilmthickness

      subroutine microbial_resp (r_microbial_z0,soil_temp,perc_org_mat, &
         soil_density,percentage_sand,matric_potential,                 &
            specific_resp_humus,q10_microbial)
! --- Calculate microbial respiration rate, based on available amount of
! --- organic matter, soil moisture and temperature

      implicit none
      real(8), intent(in)     :: soil_temp,perc_org_mat
      real(8), intent(in)     :: soil_density,percentage_sand,matric_potential
      real(8), intent(in)     :: specific_resp_humus,q10_microbial
      real(8), intent(out)    :: r_microbial_z0

      real(8)                 :: f_moisture_humus,t_humus,carbon_humuspools
      real(8)                 :: saturated_matric_potential

!     ## MH : define constants
      real(8), parameter      :: h1        =   25000.0d0
      real(8), parameter      :: h2        =  762500.0d0
      real(8), parameter      :: h3        = 1500000.0d0
      real(8), parameter      :: log10h1   = dlog10(h1)
      real(8), parameter      :: log10h2   = dlog10(h2)
      real(8), parameter      :: log10h3   = dlog10(h3)
      real(8), parameter      :: log10h3h2 = log10h3 - log10h2
!     ## MH: end

! --- humus temperature [K]
      t_humus = soil_temp
! --- available amount of organic carbon [kg/m3]            ## MH: /100 = *0.01
      carbon_humuspools = 0.48d0 * ( 0.01d0*perc_org_mat ) *soil_density
! --- saturated matric potential [pa] calculated according to cosby et al. 1984
! --- * 100: cm -> pa
      saturated_matric_potential =(10.d0**(-0.0131d0*percentage_sand+   &
                                  1.88d0))*100.0d0
! --- reduction function for soil moisture:
      if ( matric_potential < saturated_matric_potential) then
         f_moisture_humus = 0.5d0
      end if
      if (( matric_potential >= saturated_matric_potential)           &
                            .AND. (matric_potential < h1)) then
         f_moisture_humus = 1.d0 - 0.5d0 *                              &
                            ((log10h1-dlog10(matric_potential))/        &
                            (log10h1-                                   &
                            dlog10(saturated_matric_potential) ) )
      end if
      if ((matric_potential >= h1)                                    &
                          .AND. (matric_potential <= h2)) then
         f_moisture_humus = 1.0d0
      end if
      if ((matric_potential > h2)                                    &
                          .AND. (matric_potential <= h3)) then
         f_moisture_humus = 1.d0 -                                      &
                           ((dlog10(matric_potential)-log10h2)/         &
                           ( log10h3h2 ) )
      end if
      if (matric_potential > h3) then
         f_moisture_humus = 0.0d0
      end if
! --- microbial respiration rate at soil surface [kg/m3/d]
      r_microbial_z0 = specific_resp_humus * carbon_humuspools *        &
                   ( q10_microbial**( 0.1d0*(t_humus-298.d0) ) )        &
                   * f_moisture_humus
      return
      end subroutine microbial_resp

      subroutine MICRO (c_mroot,w_root,f_senes,q10_root,                &
                       soil_temp,sat_water_cont,gas_filled_porosity,    &
                       d_o2inwater,d_root,perc_org_mat,soil_density,    &
                       specific_resp_humus,q10_microbial,depth,         &
                       shape_factor_microbialr,rootradius_m,             &
                       waterfilm_thickness,bunsencoeff,                 &
                       c_min_micro, resp_factor)
! --- calculate minimum oxygen concentration in the gas phase of the soil
! --- that is needed to provide all cells within a plant root with a
! --- sufficient amount of oxygen.                                                                     *)

      use parameters, only: pi
      
      implicit none
      real(8), intent(in)  :: c_mroot,w_root,f_senes,q10_root,soil_temp
      real(8), intent(in)  :: sat_water_cont,gas_filled_porosity
      real(8), intent(in)  :: d_o2inwater,d_root,perc_org_mat,soil_density
      real(8), intent(in)  :: specific_resp_humus,q10_microbial,depth
      real(8), intent(in)  :: shape_factor_microbialr,rootradius_m
      real(8), intent(in)  :: waterfilm_thickness,bunsencoeff
      real(8), intent(in)  :: resp_factor
      real(8), intent(out) :: c_min_micro

      real(8)              :: r_mref,r_mroot,waterfilm_porosity,d_waterfilm,lambda
      real(8)              :: r_waterfilm_lengthroot,alpha_alpha
      real(8)              :: f_moisture_humus,t_humus,carbon_humuspools
      real(8)              :: c_min_micro_interphase

      real(8)              :: r_microbial_volumetric_wf ,r_microbial_z0_wf
      real(8), parameter   :: FourThird = 4.0d0/3.0d0      ! ## MH

! --- calc respiration per unit length of root [kg/m/d]
      r_mref = c_mroot * w_root * resp_factor

      r_mroot = f_senes * r_mref *                                      &
                ( q10_root ** ( 0.1d0*(soil_temp - 298.d0 ) ) )
! --- calc porosity of water film [-]
      waterfilm_porosity = ( sat_water_cont - gas_filled_porosity ) /   &
                      ( 1.0d0 - gas_filled_porosity )
      waterfilm_porosity = max(0.075d0,waterfilm_porosity) !RB20180507, set minimum value for very dry conditions
! --- calc diffusion coeff of water film [m2/d]
      d_waterfilm = d_o2inwater * ( waterfilm_porosity**FourThird )
! --- calc ratio of d_root and d_waterfilm, input for c_min_micro_interphase
      lambda = d_root / d_waterfilm
! --- start microbial respiration rate in water film
! --- temperature humus [k]
      t_humus = soil_temp
! --- amount of carbon in humus [kg/m3]
      carbon_humuspools = 0.48d0 * (0.01d0*perc_org_mat) * soil_density
! --- reduction factor for moisture [-] (saturation)
      f_moisture_humus = 0.5d0
! --- microbial respiration rate at soil surface [kg/m3/d]
      r_microbial_z0_wf = specific_resp_humus * carbon_humuspools *     &
                       ( q10_microbial**( 0.1d0*(t_humus-298.d0) ) ) *  &
                       f_moisture_humus
! --- volumetric microbial resp rate at depth z [kg/m3/d]
      r_microbial_volumetric_wf = r_microbial_z0_wf*                    &
                                dexp(-depth/shape_factor_microbialr)
! --- respiration rate in water film per unit length of root [kg/m/d]
      r_waterfilm_lengthroot = pi *                                     &
                           ( (rootradius_m + waterfilm_thickness)**2 -   &
                           rootradius_m**2 )*r_microbial_volumetric_wf
! --- end microbial respiration rate in water film*)

! --- calculation procedure following de willigen & van noordwijk 1983
! --- p.220-221
! --- ratio of rhizosphere respiration to total respiration [-]
      alpha_alpha = r_waterfilm_lengthroot /                            &
                    (r_waterfilm_lengthroot+r_mroot)
! --- volumetric respiration rate of the root + rhizosphere, but attributed
! ---   to the root (following de willigen & van noordwijk 1983) [kg/m3/d]
      c_min_micro_interphase = ((r_waterfilm_lengthroot + r_mroot)/     &
                (2.d0*pi*d_root)) *                                     &
                ( 0.5d0 + ( ( lambda - 1.d0 ) * alpha_alpha / 2.d0 ) +  &
                lambda * dlog(1.d0 + waterfilm_thickness / rootradius_m)-&
                ( lambda * alpha_alpha *                                &
                ( 1.d0 + waterfilm_thickness / rootradius_m )**2 ) *     &
                dlog(1.d0 + waterfilm_thickness / rootradius_m ) /       &
                ( ( waterfilm_thickness / rootradius_m ) *               &
                (2.d0 + waterfilm_thickness / rootradius_m) )  )

      c_min_micro = c_min_micro_interphase/bunsencoeff
! --- end calculation procedure following de willigen & van noordwijk 1983*)
      return
      end subroutine MICRO

      subroutine MACRO (c_macro,depth,resp_factor,                      &
                 c_mroot,w_root_z0,f_senes,q10_root,soil_temp,ctop,     &
                 shape_factor_microbialr,shape_factor_rootr,            &
                 r_microbial_z0,d_soil)
     
! --- calculate oxygen concentration in the soil at a specific depth with respect
! --- to the soil surface. diffusion from atmosphere into soil is considered,
! --- including microbial and root respiration.

      implicit none
      real(8), intent(in)  :: depth, resp_factor, d_soil
      real(8), intent(in)  :: c_mroot,w_root_z0,f_senes,q10_root,soil_temp,ctop
      real(8), intent(in)  :: shape_factor_microbialr,shape_factor_rootr,r_microbial_z0
      real(8), intent(out) :: c_macro

      real(8)              :: dum,r_mref_z0,r_mroot_z0,l,lnew,lnew_initial,fi,fi_a
      integer              :: counterMacro, counterMacroSub
      character(len=200)   :: message

! --- reference respiration at soil surface per unit volume of roots [kg/m3] *)
      r_mref_z0 = c_mroot * w_root_z0 * resp_factor

! --- respiration at soil surface per unit volume of roots [kg/m3]
      r_mroot_z0 = f_senes * r_mref_z0 * (q10_root**(0.1d0*(soil_temp - 298.d0)))

! --- calculate oxygen concentration at certain depth (c_macro [kg/m3]
! --- in the soil. method according to cook 1995
! --- calculate criterium (dum) to switch to specific equation (if then else)
      dum = (( shape_factor_microbialr**2) * r_microbial_z0 /d_soil)+   &
            (( shape_factor_rootr**2 ) * r_mroot_z0 / d_soil)
! --- as z goes to infinity, the oxygen concentration asymptotically approaches
! ---    a constant non-zero value
      if (dum < ctop) then
         c_macro = ctop -                                               &
           ( (shape_factor_microbialr**2) * r_microbial_z0 / d_soil)*   &
           ( 1.d0- dexp( - depth / shape_factor_microbialr ) ) -        &
           ( (shape_factor_rootr**2) * r_mroot_z0 / d_soil ) *          &
           ( 1.d0- dexp( - depth / shape_factor_rootr ) )
! --- at z = l the oxygen concentration goes to zero. find l through
! ---    newton-raphson method
      else
         counterMacro = 0
         counterMacroSub = 0
         lnew_initial = 0.1d0 !initialize
         fi = 1.d0 !initialize
             fi_a = 1.d0 !initialize
         lnew = lnew_initial
         do while ((dabs(fi) > 1.d-8) .AND.                            &
                       (dabs(fi_a) > 0.d0) .AND.                       &
                   (lnew > 1.d-4))
            counterMacro = counterMacro + 1
            counterMacroSub = counterMacroSub + 1
            l = lnew
            fi = ctop -                                                 &
               ((shape_factor_microbialr**2)*r_microbial_z0/d_soil)*    &
               ( 1.d0- (l/shape_factor_microbialr)*                     &
               dexp( - l / shape_factor_microbialr ) -                  &
               dexp( - l / shape_factor_microbialr ) ) -                &
               ( (shape_factor_rootr**2) * r_mroot_z0 / d_soil ) *      &
               (1.d0-(l/shape_factor_rootr)*                            &
               dexp(-l/shape_factor_rootr )-                            &
               dexp( - l / shape_factor_rootr ) )
! --- derivative of fi to l
            fi_a = -r_microbial_z0/d_soil*l*                            &
                   dexp(-l/shape_factor_microbialr)-                    &
                   r_mroot_z0/d_soil*l*dexp(-l/shape_factor_rootr)
               
            if (dabs(fi_a) > dmax1(tiny(1.0d0), dabs(fi)/huge(1.0d0))) then
               lnew = dabs(l - (fi / fi_a))
            else
               ! Force a controlled restart instead of risking overflow in fi/fi_a.
               lnew = huge(1.0d0)
            end if
            
! --- for convergence --> depends on initial value of lnew
            if (lnew > 1.d3  .OR.  counterMacroSub > 100) then
               !restart do while loop with new lnew_initial value
               lnew_initial = lnew_initial + 0.1d0
               lnew = lnew_initial
               counterMacroSub = 0
            end if
! ---       fatal error if too many iterations --> 
            if (counterMacro > 1d6) then
              message = 'Too much iterations for macroscopic oxygen diffusion.'
              call swap_error ('oxygenstress', message)
            end if            
         end do
        
         if (depth < l) then
            c_macro = ctop -                                            &
               ((shape_factor_microbialr**2)*r_microbial_z0/d_soil )*   &
               ( 1.d0- (depth/shape_factor_microbialr)*                 &
               dexp( - l / shape_factor_microbialr ) -                  &
               dexp( - depth / shape_factor_microbialr ) ) -            &
               ( (shape_factor_rootr**2) * r_mroot_z0 / d_soil ) *      &
               ( 1.d0- (depth/shape_factor_rootr)*                      &
               dexp( - l / shape_factor_rootr ) -                       &
               dexp( - depth / shape_factor_rootr ) )
         else
            c_macro = 0.0d0
         end if
      end if
      return
      end subroutine MACRO

      real(8) function SOLVE (xi,accuracy)
     
      use plant_interface, only: max_resp_factor, q10_root, c_mroot, f_senes
      use O2_pars
      
      implicit none
      real(8), intent(in)     :: accuracy
      real(8), intent(inout)  :: xi
      
      real(8)                 :: xiplus1,ximin1
      real(8)                 :: delta
      real(8)                 :: xx,fxi,xiplusdelta,ximindelta,fxiplusdelta,fximindelta,dfxi
      integer                 :: counterSolve
      character(len=200)      :: message

!      logical, parameter :: UseZBREND = .FALSE.
      logical, parameter :: UseZBREND = .TRUE.
      real(8)  :: a, b, Dif_a, Dif_b, ZBREND, myfunc
      external :: myfunc
      
      if (UseZBREND) then
! ## MH: start 
         a     = 0.0d0 ! 1.0d-6
         Dif_a = myfunc(a)
         b     = max_resp_factor
         Dif_b = myfunc(b)
      
         if (Dif_a*Dif_b < 0.0d0) then
            SOLVE = ZBREND (myFUNC,a,b,Dif_a,Dif_b,accuracy)
            return
         else
            ! same sign
            if (Dif_a > 0.0d0) then
               ! c_macro is thus always larger than c_min_micro, so there is no oxygen problem; xx should thus be > 0
               xx = max_resp_factor
            else
               ! c_macro is thus always less than c_min_micro, so there is 100% oxygen problem; xx should thus be 0
               xx = 0.0d0
            end if

            ! calculate c_macro for given resp_factor = xx
            call MACRO (c_macro,depth,xx,                               &
                 c_mroot,w_root_z0,f_senes,q10_root,soil_temp,ctopnode, &
                 shape_factor_microbialr,shape_factor_rootr,            &
                 r_microbial_z0,d_soil)
            SOLVE = xx
            return
         end if
         return
! ## MH: end

      else !## MH: (not use ZBREND; i.e. use original Newton-Raphson approach)
      
! --- iterative procedure to find the RESPIRATION FACTOR for which holds !RB20131106
! --- that c_macro = c_micro. reference value = c_micro
! --- Newton-Raphson method

! --- speed up simulations: cut of if ctop = 0 and if waterfilm_thickness is extremely high (due to very low gas filled porosity)     !RB20140826
      if (dabs(ctopnode) < 1.0d-6 .OR.                               &
          waterfilm_thickness > 1.d0) then 
         xx = 0.d0
         C_macro = 0.0d0
         SOLVE = xx
         return
      end if

      delta= 1.d-8
      fxi = 100.d0
      counterSolve = 1
      do while (fxi > accuracy)
         call MICRO (c_mroot,w_root,f_senes,q10_root,soil_temp,         &
                       sat_water_cont,gas_filled_porosity,              &
                       d_o2inwater,d_root,perc_org_mat,soil_density,    &
                       specific_resp_humus,q10_microbial,depth,         &
                       shape_factor_microbialr,rootradius_m,            &
                       waterfilm_thickness,bunsencoeff,                 &
                       c_min_micro, xi)
         call MACRO (c_macro,depth,xi,                                  &
                 c_mroot,w_root_z0,f_senes,q10_root,soil_temp,ctopnode,     &
                 shape_factor_microbialr,shape_factor_rootr,            &
                 r_microbial_z0,d_soil)
         fxi = dabs(C_min_micro-C_macro)
         xiplusdelta = xi + delta
         ximindelta = xi - delta
         
         if (dabs(xiplusdelta-ximindelta) < 1.d-20) then !if (dabs(xiplusdelta-ximindelta) < 1.d-12) then !if (xiplusdelta == ximindelta) then 
            xiplusdelta = xi + 1.d-6
            ximindelta = xi - 1.d-6
         end if
         
         call MICRO (c_mroot,w_root,f_senes,q10_root,soil_temp,         &
                       sat_water_cont,gas_filled_porosity,              &
                       d_o2inwater,d_root,perc_org_mat,soil_density,    &
                       specific_resp_humus,q10_microbial,depth,         &
                       shape_factor_microbialr,rootradius_m,            &
                       waterfilm_thickness,bunsencoeff,                 &
                       c_min_micro, xiplusdelta)
         call MACRO (c_macro,depth,xiplusdelta,                         &
                 c_mroot,w_root_z0,f_senes,q10_root,soil_temp,ctopnode, &
                 shape_factor_microbialr,shape_factor_rootr,            &
                 r_microbial_z0,d_soil)
     
         fxiplusdelta = dabs(C_min_micro-C_macro)
         call MICRO (c_mroot,w_root,f_senes,q10_root,soil_temp,         &
                       sat_water_cont,gas_filled_porosity,              &
                       d_o2inwater,d_root,perc_org_mat,soil_density,    &
                       specific_resp_humus,q10_microbial,depth,         &
                       shape_factor_microbialr,rootradius_m,            &
                       waterfilm_thickness,bunsencoeff,                 &
                       c_min_micro, ximindelta)
         call MACRO (c_macro,depth,ximindelta,                          &
                 c_mroot,w_root_z0,f_senes,q10_root,soil_temp,ctopnode, &
                 shape_factor_microbialr,shape_factor_rootr,            &
                 r_microbial_z0,d_soil)    
     
         fximindelta = dabs(C_min_micro-C_macro)  

         dfxi = (fxiplusdelta - fximindelta) / (xiplusdelta-ximindelta)
         
        if (dabs(dfxi) < 1.d-20) then !if (dabs(dfxi) < 1.d-15) then !RB20140312
          xiplus1 = xi
        else
          xiplus1 = max(1.0d-8,(xi - fxi/dfxi)) !xiplus1 = max(1.0d-6,(xi - fxi/dfxi)) !RB20131106, never lt 0
        end if

      !prevent endless sign change without conversion !RB20140827
      if (mod(counterSolve,2)>1.d-12) then !if even than store xi
        ximin1 = xi
      end if
!D      write(*,*) counterSolve,xi,ximin1,xiplus1 !DEBUG
      if (dabs(xiplus1-ximin1) < 1.d-6) then  !no change in xi value, than take average of both values between which is iterated
        xx = (xi+xiplus1)*0.5d0
        call MACRO (c_macro,depth,xx,                                   &
             c_mroot,w_root_z0,f_senes,q10_root,soil_temp,ctopnode,         &
             shape_factor_microbialr,shape_factor_rootr,                &
             r_microbial_z0,d_soil)     
        SOLVE = xx
        return
      end if

! --- speed up simulations: cut of if RWU_factor will be >1 or <1e-6 (=0)       
         if (xi < 1.0d-6 .AND. xi > 0.0d0) then !RB20131106 greater than 0 is required
            xx = 0.d0
            C_macro = 0.0d0
            SOLVE = xx
            return
         end if
         if (xi > max_resp_factor) then
            xx = max_resp_factor
            call MACRO (c_macro,depth,xx,                               &
                 c_mroot,w_root_z0,f_senes,q10_root,soil_temp,ctopnode,     &
                 shape_factor_microbialr,shape_factor_rootr,            &
                 r_microbial_z0,d_soil)     
            SOLVE = xx
            return
         end if
      
         xi = xiplus1
         
! ---    error if max iterations reached--> 
         counterSolve = counterSolve + 1
         if (counterSolve > 100) then
           message = 'Max iterations for solver oxygen stress reached.'
           call swap_error ('oxygenstress', message)
           return          
        end if            
      end do
      xx = xi
      SOLVE = xx
      return

      end if ! (UseZBREND)

      end function SOLVE

! ----------------------------------------------------------------------
      subroutine OxygenReproFunction (OxygenSlope,OxygenIntercept,      &
         theta,thetas,tsoil,node,z,dz,rwu_factor)
! ----------------------------------------------------------------------
!     date               : January 2010
!     purpose            : Calculate oxygen stress according to reproduction function
! ----------------------------------------------------------------------
      use MOD_arrays, only: macp
      use MOD_grid,   only: zbotcp
      implicit none

! --- global
      integer, intent(in)  :: node
      real(8), intent(in)  :: OxygenSlope(6),OxygenIntercept(6),theta(macp),thetas(macp)
      real(8), intent(in)  :: tsoil(macp),z(macp),dz(macp)
      real(8), intent(out) :: rwu_factor

! --- local
      integer i
      real(8) intercept,slope,sum_porosity
      real(8) gas_filled_porosity
      real(8) soil_temp,depth_ss,mean_gas_filled_porosity

      gas_filled_porosity = dmax1(0.0d0, thetas(node) - theta(node))
      soil_temp = tsoil(node) + 273.d0
      depth_ss = -z(node) * 0.01d0

      if (gas_filled_porosity < 1.d-10) then
         rwu_factor = 0.d0 
         return
      end if

! --- mean gas filled porosity
      sum_porosity = 0.0d0
      do i = 1,node
        sum_porosity = sum_porosity +                                   &
                       (thetas(i) - theta(i)) * dz(i)
      end do
      mean_gas_filled_porosity = sum_porosity /(-zbotcp(node))

      intercept = OxygenIntercept(1)*soil_temp**2 +                     &
                  OxygenIntercept(2)*depth_ss**2 +                      &
                  OxygenIntercept(3)*soil_temp +                        &
                  OxygenIntercept(4)*depth_ss +                         &
                  OxygenIntercept(5)*soil_temp*depth_ss +               &
                  OxygenIntercept(6)

      slope = OxygenSlope(1)*soil_temp**2 +                             &
              OxygenSlope(2)*depth_ss**2 +                              &
              OxygenSlope(3)*soil_temp +                                &
              OxygenSlope(4)*depth_ss +                                 &
              OxygenSlope(5)*soil_temp*depth_ss +                       &
              OxygenSlope(6)

! --- Calculate the sink term (Root Water Uptake) variable due to oxygen stress.
      rwu_factor = intercept + slope*mean_gas_filled_porosity
      if (rwu_factor > 1.d0) then
         rwu_factor = 1.d0
      end if
      if (rwu_factor < 0.d0) then
         rwu_factor = 0.d0
      end if
      return

   end subroutine OxygenReproFunction

   
!-----------------------------------------------------------------------*
! From W.H. Press, B.P. Flannery, S.A. Teukolsky and W.T. Vettering,    *
! 1986. Numerical recipes. The art of scientific computing. Cambridge   *
! University Press, Cambridge, 818 pp.                                  *
! real(8) version                                              *
!-----------------------------------------------------------------------*
!      SUBROUTINE QROMBD (FUNC,A,B,SS)
      SUBROUTINE QROMBD (a,b,ss,Capac_term,Nmin1,Mplus1,                &
                         alpha,gen_n,surface_tension_water,glit)

      IMPLICIT NONE
      real(8), intent(in)        :: a,b
      real(8), intent(in)        :: Capac_term,Nmin1,Mplus1
      real(8), intent(in)        :: alpha,gen_n,surface_tension_water
      integer, intent(inout)     :: glit
      real(8), intent(inout)     :: ss

      INTEGER                    :: J,L
      integer, parameter         :: JMAX  = 20              ! 100
      integer, parameter         :: JMAXP = JMAX + 1
      integer, parameter         :: K     =  5
      integer, parameter         :: KM    = K - 1
      real(8), parameter         :: EPS   = 1.0d-5            ! 1.0D-8
      REAL(8), DIMENSION(JMAXP)  :: S, H
      REAL(8)                    :: DSS
!      REAL(8)                    :: FUNC
!      EXTERNAL  FUNC

      H(1) = 1.D0; s(1) = 0.0d0
      DO J = 1, JMAX
!        CALL TRAPZDD (FUNC,A,B,S(J),J)
        CALL TRAPZD (a,b,s(j),j,Capac_term,Nmin1,Mplus1,                &
                     alpha,gen_n,surface_tension_water,glit)
        IF (J >= K) THEN
          L = J - KM
!          CALL POLINTD (H(L),S(L),K,0.D0,SS,DSS)
          CALL POLINTD (H(L:J),S(L:J),K,0.D0,SS,DSS)
          IF (DABS(DSS) < EPS*DABS(SS)) RETURN
        END IF
        S(J+1) = S(J)
        H(J+1) = 0.25D0*H(J)
      END DO
!      PAUSE 'Too many steps.'
      write (*,*) 'QROMBD Too many steps.'
      !read (*,*)
   END SUBROUTINE QROMBD

!-----------------------------------------------------------------------*
! From W.H. Press, B.P. Flannery, S.A. Teukolsky and W.T. Vettering,    *
! 1986. Numerical recipes. The art of scientific computing. Cambridge   *
! University Press, Cambridge, 818 pp.                                  *
! real(8) version                                              *
!-----------------------------------------------------------------------*
      SUBROUTINE QROMBDtab (a,b,ss,dif_water_cap,surface_tension_water,glit)

      IMPLICIT NONE
      real(8), intent(in)     :: a,b
      real(8), intent(in)     :: dif_water_cap, surface_tension_water
      integer, intent(inout)  :: glit
      real(8), intent(inout)  :: ss

      INTEGER                    :: J,L
      integer, parameter         :: JMAX  = 100
      integer, parameter         :: JMAXP = JMAX + 1
      integer, parameter         :: K     =  5
      integer, parameter         :: KM    = K - 1
      real(8), parameter         :: EPS   = 1.0d-5            ! 1.0D-10
      REAL(8), DIMENSION(JMAXP)  :: S, H
      REAL(8)                    :: DSS
!      REAL(8)                    :: FUNC
!      EXTERNAL  FUNC

      H(1) = 1.D0; s(1) = 0.0d0
      DO J = 1, JMAX
!        CALL TRAPZDD (FUNC,A,B,S(J),J)
        CALL TRAPZDtab (a,b,s(j),j,dif_water_cap,surface_tension_water,glit)
        IF (J >= K) THEN
          L = J - KM
!          CALL POLINTD (H(L),S(L),K,0.D0,SS,DSS)
          CALL POLINTD (H(L:J),S(L:J),K,0.D0,SS,DSS)
          IF (DABS(DSS) < EPS*DABS(SS)) RETURN
        END IF
        S(J+1) = S(J)
        H(J+1) = 0.25D0*H(J)
      END DO
!      PAUSE 'Too many steps.'
      write (*,*) 'QROMBDtab Too many steps.'
      read (*,*)
   END  SUBROUTINE QROMBDtab

!-----------------------------------------------------------------------*
! From W.H. Press, B.P. Flannery, S.A. Teukolsky and W.T. Vettering,    *
! 1986. Numerical recipes. The art of scientific computing. Cambridge   *
! University Press, Cambridge, 818 pp.                                  *
! real(8) version                                              *
!-----------------------------------------------------------------------*
      SUBROUTINE POLINTD (XA,YA,N,X,Y,DY)

      IMPLICIT NONE
      integer, intent(in)                 :: N
      real(8), intent(in)                 :: X
      real(8), dimension(N), intent(in)   :: XA,YA
      real(8), intent(out)                :: Y,DY
      INTEGER, PARAMETER                  :: NMAX = 10
      INTEGER                             :: NS,I,M
      REAL(8)                             :: DIF,DIFT,HO,HP,DEN,W
      REAL(8), DIMENSION(NMAX)            ::C,D

      NS=1
      DIF=DABS(X-XA(1))
      DO I=1,N
        DIFT=DABS(X-XA(I))
        IF (DIFT < DIF) THEN
          NS=I
          DIF=DIFT
        END IF
        C(I)=YA(I)
        D(I)=YA(I)
      END DO
      Y=YA(NS)
      NS=NS-1
      DO M=1,N-1
        DO I=1,N-M
          HO=XA(I)-X
          HP=XA(I+M)-X
          W=C(I+1)-D(I)
          DEN=HO-HP
          if (.NOT.(DABS(DEN) > 0.D0)) then
!             PAUSE 'NR_POLINTD: DEN = 0'
             write (*,*) 'NR_POLINTD: DEN = 0'
             read (*,*)
          end if
          DEN=W/DEN
          D(I)=HP*DEN
          C(I)=HO*DEN
        END DO
        IF (2*NS < N-M) then
          DY=C(NS+1)
        ELSE
          DY=D(NS)
          NS=NS-1
        END IF
        Y=Y+DY
      END DO
      RETURN
   END SUBROUTINE POLINTD

   real(8) function myfunc(x)
   
   use plant_interface, only: q10_root, c_mroot, f_senes
   use O2_pars

   implicit none
   real(8), intent(in) :: x
      call MICRO (c_mroot,w_root,f_senes,q10_root,soil_temp,            &
                       sat_water_cont,gas_filled_porosity,              &
                       d_o2inwater,d_root,perc_org_mat,soil_density,    &
                       specific_resp_humus,q10_microbial,depth,         &
                       shape_factor_microbialr,rootradius_m,            &
                       waterfilm_thickness,bunsencoeff,                 &
                       c_min_micro,x)
      call MACRO (c_macro,depth,x,                                      &
                 c_mroot,w_root_z0,f_senes,q10_root,soil_temp,ctopnode, &
                 shape_factor_microbialr,shape_factor_rootr,            &
                 r_microbial_z0,d_soil)
      myfunc = c_macro - c_min_micro
   end function myfunc
   
   !     Adapted: initial FA and FB are input
      real(8) FUNCTION ZBREND (FUNC,X1,X2,FA,FB,TOL)
      IMPLICIT NONE
      real(8), intent(in)     :: X1,X2,TOL
      real(8), intent(inout)  :: FA,FB
      integer, parameter      :: ITMAX = 100
      INTEGER                 :: ITER
      real(8), parameter      :: EPS=3.D-16
      real(8)                 :: A,B,FC,C,D,E,XM,TOL1,P,Q,R,S
      real(8)                 :: FUNC
      A=X1
      B=X2
!      FA=FUNC(A)
!      FB=FUNC(B)
!      IF (FB*FA > 0.D0) PAUSE 'Root must be bracketed for ZBREND.'
      FC=FB
      DO 11 ITER=1,ITMAX
        if (FB*FC > 0.D0) THEN
          C=A
          FC=FA
          D=B-A
          E=D
        end if
        if (DABS(FC) < DABS(FB)) THEN
          A=B
          B=C
          C=A
          FA=FB
          FB=FC
          FC=FA
        end if
        TOL1=2.D0*EPS*DABS(B)+0.5D0*TOL
        XM=.5D0*(C-B)
        if (DABS(XM) <= TOL1 .OR. .NOT.(DABS(FB) > 0.D0)) then
          ZBREND=B
          RETURN
        end if
        if (DABS(E) >= TOL1 .AND. DABS(FA) > DABS(FB)) THEN
          S=FB/FA
          if (.NOT.(DABS(A - C) > 0.0D0)) THEN
            P=2.D0*XM*S
            Q=1.D0-S
          ELSE
            Q=FA/FC
            R=FB/FC
            P=S*(2.D0*XM*Q*(Q-R)-(B-A)*(R-1.D0))
            Q=(Q-1.D0)*(R-1.D0)*(S-1.D0)
          end if
          if (P > 0.D0) Q=-Q
          P=DABS(P)
          if (2.D0*P < DMIN1(3.D0*XM*Q-DABS(TOL1*Q),DABS(E*Q))) THEN
            E=D
            D=P/Q
          ELSE
            D=XM
            E=D
          end if
        ELSE
          D=XM
          E=D
        end if
        A=B
        FA=FB
        if (DABS(D) > TOL1) THEN
          B=B+D
        ELSE
          B=B+SIGN(TOL1,XM)
        end if
        FB=FUNC(B)
11    CONTINUE
!      PAUSE 'ZBREND exceeding maximum iterations.'
      write (*,*) 'ZBREND exceeding maximum iterations.'
      read (*,*)
      ZBREND=B
      RETURN
      END FUNCTION ZBREND
