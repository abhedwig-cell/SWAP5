program probe
 use iso_fortran_env,only:real64
 use ieee_arithmetic
 use mod_bartholomeus_waterfilm
 use mod_bartholomeus_waterfilm_independent
 implicit none
 type(BartholomeusWaterfilmMvgInput)::p
 real(real64)::x,y
 logical::ok
 character(32)::mode
 p=BartholomeusWaterfilmMvgInput(3.12441743964870123e-05_real64,3.48770000000000024e-01_real64,1.25858374667289463e+00_real64,2.16450000000000003e-04_real64,1.34877000000000002e+00_real64,7.21501817053718519e-02_real64)
 x=2.90803898070565083e+04_real64
 call get_command_argument(1,mode)
 select case(trim(mode))
 case('nan-head');x=ieee_value(0d0,ieee_quiet_nan)
 case('inf-head');x=ieee_value(0d0,ieee_positive_inf)
 case('nan-alpha');p%alpha_per_pa=ieee_value(0d0,ieee_quiet_nan)
 case('inf-sigma');p%surface_tension_water=ieee_value(0d0,ieee_negative_inf)
 case('zero-head');x=0d0
 case('dry');x=1.0000001e7_real64
 end select
 y=bartholomeus_waterfilm_mvg_independent(x,p,ok)
 write(*,'(l1,1x,es25.17e3)')ok,y
end program
