* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-05 05:58:28

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.01 cm       0.3897E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.82 cm       0.3897E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.02
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    12.01
                             Crack flux        :     0.00
                             Drainage level 1  :    32.75
=========================    ============================
Sum            :    86.58    Sum               :    83.76


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.9027E+01
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.9027E+01


Period             :  2002-01-01  until  2003-08-07 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        67.37 cm       0.2411E+02 mg/cm2
Initial :        78.01 cm       0.3897E+02 mg/cm2
            =============       =================
Change          -10.64 cm      -0.1486E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    45.02    Interception      :     4.81
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.00    Transpiration     :    14.32
Bottom flux    :     0.00    Soil evaporation  :    10.60
                             Crack flux        :     0.00
                             Drainage level 1  :    27.93
=========================    ============================
Sum            :    47.02    Sum               :    57.66


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1486E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1486E+02

