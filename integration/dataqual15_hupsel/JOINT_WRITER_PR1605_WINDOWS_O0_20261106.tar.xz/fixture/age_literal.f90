module historical_age_oracle
 use iso_fortran_env,only:real64
 use mod_b111_age_tracer_substep,only:b111_age_tracer_substep_forcing_t
 implicit none
contains
 subroutine literal_age_step(f,ageml,agemsy,production,root,drain,bottom)
 type(b111_age_tracer_substep_forcing_t),intent(in)::f
 real(real64),intent(inout)::ageml(:),agemsy(:)
 real(real64),intent(out)::production,root,drain,bottom
 integer::i,level,numnod,nrlevs,layer(size(ageml))
 real(real64)::agemlav,thetav,vpore,diffus,ddif,dispr,dtsolu,agefluxb,agefluxt,agedrain,agerot,agedrtot,ageprod,rottot,isqdra,sqdra
 real(real64)::inpola(size(ageml)+1),inpolb(size(ageml)),theta(size(ageml)),thetm1(size(ageml)),q(size(ageml)+1), &
   disnod(size(ageml)+1),ldis(size(ageml)),thetsl(size(ageml)),qrot(size(ageml)),dz(size(ageml)),qdra(size(f%qdra_cm_day,1),size(ageml))
 numnod=size(ageml);nrlevs=size(f%qdra_cm_day,1);layer=[(i,i=1,numnod)]
 inpola=0;inpolb=0;disnod=1;ldis=0;thetsl=1
 inpola(2:numnod)=f%face_left_weight;inpolb(1:numnod-1)=f%face_right_weight
 disnod(2:numnod)=f%face_distance_cm;ldis(1:numnod-1)=f%dispersivity_cm;thetsl(1:numnod-1)=f%theta_sat_left
 theta=f%theta;thetm1=f%theta_previous;dz=f%dz_cm;q=f%q_face_up_cm_day;qrot=f%root_sink_cm_day;qdra=f%qdra_cm_day
 dtsolu=f%dt_day;ddif=f%molecular_diffusion_cm2_day;agedrain=f%drain_age_day
 agefluxt=0;rottot=0;isqdra=0;sqdra=0
 production=sum(.5d0*(theta+thetm1)*dz)*dtsolu
            do i = 1, numnod

! ---          convective and dispersive fluxes
               if (i < numnod) then
                  Agemlav  = inpola(i+1) * Ageml(i) + inpolb(i) * Ageml(i+1)
                  thetav   = inpola(i+1)*theta(i)+inpolb(i)*theta(i+1)
                  vpore    = abs(q(i+1))/thetav
                  diffus   = ddif*(thetav**2.33d0)/(thetsl(layer(i))**2)
                  dispr    = diffus + ldis(layer(i)) * vpore + 0.5d0 * dtsolu*vpore*vpore
                  Agefluxb = (q(i+1)*Agemlav +thetav * dispr * (Ageml(i+1)-Ageml(i))/disnod(i+1))*dtsolu
               else
                  if (q(i+1) > 0.0d0) then
                     Agefluxb = q(i+1)*Agedrain*dtsolu
                  else
                     Agefluxb = q(i+1)*Ageml(i)*dtsolu
                  end if
               end if

! ---          Age tracer uptake by plant roots
               Agerot = qrot(i)*Ageml(i)/dz(i)
               rottot = rottot + qrot(i)*Ageml(i)*dtsolu

! ---          Age tracer uptake by soil evaporation ???
!               Ageevp = evso??*Ageml(i)/dz(i)

! ---          lateral drainage
               Agedrtot = 0.0d0
               do level = 1, nrlevs
                  if (qdra(level,i) > 0.0d0) then
                     Agedrtot = Agedrtot+qdra(level,i)*Ageml(i)/dz(i)
                  else
                     Agedrtot = Agedrtot+qdra(level,i)*Agedrain/dz(i)
                  end if
               end do

! ---          cumulative amount of solutes to lateral drainage
               isqdra = isqdra + Agedrtot*dz(i)*dtsolu
               sqdra  = sqdra  + Agedrtot*dz(i)*dtsolu

! ---          zero order production
               AgeProd = 1.0d0 * 0.5d0*(theta(i)+thetm1(i))

! ---          conservation equation for the substance
               Agemsy(i) = Agemsy(i) + (Agefluxb-Agefluxt) / dz(i) + (-Agerot-Agedrtot+AgeProd) * dtsolu
               Ageml(i)  = Agemsy(i) / theta(i)

!              make top flux next compartment equal to current bottom flux
               Agefluxt = Agefluxb

 end do
 root=rottot;drain=sqdra;bottom=agefluxb
 end subroutine
end module
