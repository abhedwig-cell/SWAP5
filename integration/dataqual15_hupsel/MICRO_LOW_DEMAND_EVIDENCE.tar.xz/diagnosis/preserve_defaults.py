from pathlib import Path
import subprocess,json,hashlib,time
ROOT=Path.cwd();base=ROOT.parent;OUT=base/'dq15-hupsel-1058-default-preservation';OUT.mkdir(exist_ok=False);B=base/'dq15-hupsel-default-black-cf2bd2f';prior=json.loads((B/'RESULT.json').read_text());FC=base/'toolchain/root/usr/bin/x86_64-linux-gnu-gfortran-13';REF=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();inputs={};changed=[]
for p,h in prior['source_sha256'].items():
 raw=subprocess.check_output(['git','show',REF+':'+p],cwd=ROOT);inputs[p]=hashlib.sha256(raw).hexdigest()
 if inputs[p]!=h:changed.append(p)
assert set(changed)=={'src/runtime/mod_fmr_serialized_reference_backend.f90','src/process/mod_root_micro_de_willigen_process.f90'},changed
report=dict(scientific_source=REF,status='RUNNING',inputs=inputs,changed_providers=changed,baseline_report_sha256=sha(B/'RESULT.json'),events=[],outputs={})
def run(cmd,wd,category):
 t=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=wd,capture_output=True,text=True);i=len(report['events']);(OUT/f'{i:03d}.stdout').write_text(p.stdout);(OUT/f'{i:03d}.stderr').write_text(p.stderr);report['events'].append(dict(command=list(map(str,cmd)),category=category,returncode=p.returncode,seconds=time.monotonic()-t));(OUT/'RESULT.json').write_text(json.dumps(report,indent=2));assert p.returncode==0,p.stdout[-2000:]+p.stderr[-2000:];return p.stdout
for opt in ['O0','O2']:
 d=OUT/opt;d.mkdir();old=B/opt;replacements={}
 for src in changed:
  e=next(e for e in prior['events'] if e['category']=='compile' and Path(e['command'][-3]).name==Path(src).name and Path(e['command'][-1]).parent==old);cmd=e['command'][:];original=cmd[-1];obj=d/(Path(src).stem+'.o');cmd[-3]=str(ROOT/src);cmd[-1]=str(obj);cmd=[('-J'+str(d) if x.startswith('-J') else x) for x in cmd];run(cmd,d,'compile');replacements[original]=str(obj);name=Path(src).stem+'.mod';assert (d/name).read_bytes()==(old/name).read_bytes()
 report['outputs'][opt]={}
 for driver,expected in prior['outputs'][opt].items():
  name=Path(driver).stem;oldexe=old/name;e=next(e for e in prior['events'] if e['category']=='link' and Path(e['command'][-1])==oldexe);link=[replacements.get(x,x) for x in e['command']];link[-1]=str(d/name);run(link,d,'link');text=run([d/name],d,'native');assert text==expected,'baseline output drift '+driver;report['outputs'][opt][driver]=text
 print(opt,'all7existingnativecontractsEXACT',flush=True)
assert report['outputs']['O0']==report['outputs']['O2'];report['status']='AD51BC8_EXISTING7_DEFAULT_CONTRACTS_EXACT_PRESERVATION_PASS';report['cost_seconds']={k:sum(e['seconds'] for e in report['events'] if e['category']==k) for k in {e['category'] for e in report['events']}};(OUT/'RESULT.json').write_text(json.dumps(report,indent=2));print(report['status'])
