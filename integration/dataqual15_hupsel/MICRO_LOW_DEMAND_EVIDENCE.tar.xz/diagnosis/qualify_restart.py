from pathlib import Path
import subprocess,shutil,time,json,hashlib,csv
ROOT=Path.cwd();base=ROOT.parent;OUT=base/'dq15-hupsel-1058-restart-O2';OUT.mkdir(exist_ok=False);exe=base/'dq15-hupsel-1058-corrected-O2/swap5_corrected';incoming=base/'dq15-hupsel-rotation-cross-source566-q-O2';events=[]
for label,start,stop in [('prefix',incoming/'checkpoint.bin',1078),('resume',OUT/'prefix/checkpoint.bin',1097)]:
 d=OUT/label;d.mkdir()
 for n in ['input.nml','swap.swp','283.met','swap.dra','maize.crp','potato.crp','grass.crp']:shutil.copy2(incoming/n,d/n)
 cmd=[str(exe),'input.nml',str(start),str(stop),'swap.swp','maize.crp'];t=time.monotonic();p=subprocess.run(cmd,cwd=d,capture_output=True,text=True);(d/'stdout').write_text(p.stdout);(d/'stderr').write_text(p.stderr);events.append(dict(command=cmd,seconds=time.monotonic()-t,returncode=p.returncode));assert p.returncode==0,p.stdout+p.stderr
full=base/'dq15-hupsel-1058-corrected-O2/run';identity={n:(full/n).read_bytes()==(OUT/'resume'/n).read_bytes() for n in ['checkpoint.bin','state.csv','endpoint.csv','restart.bin']};assert all(identity.values());a=list(csv.DictReader((full/'budget.csv').open()));b=list(csv.DictReader((OUT/'resume/budget.csv').open()));assert [r for r in a if float(r['t0_day'])>=1077]==b
r=dict(scientific_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),status='ORIGINAL_1058_TO1096_SPLIT1077_FRESH_PROCESS_EXACT',events=events,identity=identity,resumed_budget_rows=len(b),checkpoint_sha256=hashlib.sha256((OUT/'resume/checkpoint.bin').read_bytes()).hexdigest());(OUT/'RESULT.json').write_text(json.dumps(r,indent=2));print(r)
