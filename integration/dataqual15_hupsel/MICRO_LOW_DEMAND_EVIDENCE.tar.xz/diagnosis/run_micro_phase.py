from pathlib import Path
import subprocess,json,time,sys
ROOT=Path.cwd();base=ROOT.parent;OUT=base/'dq15-hupsel-1058-phase';B=base/'dq15-hupsel-rotation-current-q-O2';j=json.loads((B/'BUILD.json').read_text());FC=base/'toolchain/root/usr/bin/x86_64-linux-gnu-gfortran-13';old=None
for obj in j['object_sha256']:
 if ' T __mod_root_micro_de_willigen_process_MOD_evaluate_micro_de_willigen' in subprocess.run(['nm',obj],capture_output=True,text=True).stdout:old=obj
assert old;flags=[('-J'+str(OUT) if x.startswith('-J') else x) for x in j['flags']];cmd=[FC,*flags,'-c',OUT/'source/mod_root_micro_de_willigen_process.f90','-o',OUT/'micro.o'];p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True);(OUT/'micro-compile.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr;assert (OUT/'mod_root_micro_de_willigen_process.mod').read_bytes()==(B/'mod_root_micro_de_willigen_process.mod').read_bytes()
link=json.loads((OUT/'RESULT.json').read_text())['link'];link=[str(OUT/'micro.o') if x==old else x for x in link];link[-1]=str(OUT/'swap5_micro_phase');p=subprocess.run(link,capture_output=True,text=True);assert p.returncode==0,p.stderr
run=OUT/('run-micro-'+(sys.argv[1] if len(sys.argv)>1 else '2'));run.mkdir(exist_ok=True)
import shutil
for n in ['input.nml','swap.swp','283.met','swap.dra','maize.crp','potato.crp','grass.crp']:shutil.copy2(OUT/'run'/n,run/n)
cmd=[str(OUT/'swap5_micro_phase'),'input.nml',str(base/'dq15-hupsel-rotation-cross-source566-q-O2/checkpoint.bin'),'1097','swap.swp','maize.crp'];t=time.monotonic();p=subprocess.run(cmd,cwd=run,capture_output=True,text=True);(run/'stdout').write_text(p.stdout);(run/'stderr').write_text(p.stderr);(run/'RESULT.json').write_text(json.dumps(dict(command=cmd,link=link,returncode=p.returncode,seconds=time.monotonic()-t),indent=2));print(p.stderr[-6500:])
