from pathlib import Path
import json,subprocess,hashlib,shutil,time
ROOT=Path.cwd();base=ROOT.parent;OUT=base/'dq15-hupsel-1058-phase';B=base/'dq15-hupsel-rotation-current-q-O2';j=json.loads((B/'BUILD.json').read_text());FC=base/'toolchain/root/usr/bin/x86_64-linux-gnu-gfortran-13';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();old=None
for obj in j['object_sha256']:
 if ' T __mod_fmr_serialized_reference_backend_MOD_fmr_serialized_advance' in subprocess.run(['nm',obj],capture_output=True,text=True).stdout:old=obj
assert old;flags=[('-J'+str(OUT) if x.startswith('-J') else x) for x in j['flags']];cmd=[FC,*flags,'-c',OUT/'source/mod_fmr_serialized_reference_backend.f90','-o',OUT/'backend.o'];p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True);(OUT/'compile.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr
assert (OUT/'mod_fmr_serialized_reference_backend.mod').read_bytes()==(B/'mod_fmr_serialized_reference_backend.mod').read_bytes()
# Identify the original linker event from its recorded exact object manifest.
events=json.loads((B/'EVENTS.json').read_text());link=next(e['command'][:] for e in events if e['label']=='link');assert all(sha(o)==h for o,h in j['object_sha256'].items());link=[str(OUT/'backend.o') if x==old else x for x in link];link[-1]=str(OUT/'swap5_phase');p=subprocess.run(link,capture_output=True,text=True);assert p.returncode==0,p.stderr
run=OUT/'run';run.mkdir(exist_ok=True);incoming=base/'dq15-hupsel-rotation-cross-source566-q-O2'
for n in ['input.nml','swap.swp','283.met','swap.dra','maize.crp','potato.crp','grass.crp']:shutil.copy2(incoming/n,run/n)
cmd=[str(OUT/'swap5_phase'),'input.nml',str(incoming/'checkpoint.bin'),'1097','swap.swp','maize.crp'];t=time.monotonic();p=subprocess.run(cmd,cwd=run,capture_output=True,text=True);(run/'stdout').write_text(p.stdout);(run/'stderr').write_text(p.stderr);(OUT/'RESULT.json').write_text(json.dumps(dict(command=cmd,link=link,returncode=p.returncode,seconds=time.monotonic()-t,incoming_sha256=sha(incoming/'checkpoint.bin'),source_sha256=sha(OUT/'source/mod_fmr_serialized_reference_backend.f90')),indent=2));print(p.stdout[-1800:],p.stderr[-6500:])
