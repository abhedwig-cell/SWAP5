import json,pathlib,subprocess,shutil,sys,gzip,os
root=pathlib.Path(__file__).resolve().parent.parent;out=root/'dq15-hupsel-backend-phase';bundle=root/'dq15-hupsel-rotation-current-i-O2';j=json.loads((bundle/'BUILD.json').read_text());fc=str(root/'toolchain/root/usr/bin/x86_64-linux-gnu-gfortran-13');flags=[x if not x.startswith('-J') else '-J'+str(out) for x in j['flags']];cmd=[fc,*flags,'-c',str(out/'instrumented_backend.f90'),'-o',str(out/'backend.o')];print('reuse exact diagnostic object',flush=True)
assert gzip.decompress((bundle/'mod_fmr_serialized_reference_backend.mod').read_bytes()).splitlines()[1:]==gzip.decompress((out/'mod_fmr_serialized_reference_backend.mod').read_bytes()).splitlines()[1:]
e=json.loads((bundle/'EVENTS.json').read_text());link=next(x['command'] for x in e if x['label']=='link');link=[str(out/'backend.o') if x.endswith('/dq15-hupsel-rotation-current-e-O2/191.o') else x for x in link];link=[str(root/'dq15-hupsel-microcap-O2-bounded/micro.o') if x.endswith('/dq15-hupsel-rotation-current-e-O2/88.o') else x for x in link];link[-1]=str(out/'swap5_diagnostic');p=subprocess.run(link,capture_output=True,text=True);assert p.returncode==0
run=out/('run'+(sys.argv[1] if len(sys.argv)>1 else '2'));run.mkdir(exist_ok=True);src=root/'dq15-hupsel-microcap-O2-bounded/diagnose548';
for name in ['input.nml','swap.swp','283.met','swap.dra','maize.crp','potato.crp','grass.crp']:shutil.copy2(src/name,run/name)
cmd=[str(out/'swap5_diagnostic'),'input.nml',str(src/'checkpoint.bin'),'550','swap.swp','maize.crp'];
try:p=subprocess.run(cmd,cwd=run,capture_output=True,text=True,timeout=5,env=dict(os.environ,SWAP5_DIAG_REACTIVE="1",SWAP5_DIAG_BLACK_TEMPORAL="1"))
except subprocess.TimeoutExpired as e:
 (run/'stderr').write_bytes(e.stderr or b'');(run/'stdout').write_bytes(e.stdout or b'');print('CENSORED5SECONDS');raise SystemExit(0)
(run/'stderr').write_text(p.stderr);(run/'stdout').write_text(p.stdout);print('native',p.returncode,p.stderr[-6000:])
