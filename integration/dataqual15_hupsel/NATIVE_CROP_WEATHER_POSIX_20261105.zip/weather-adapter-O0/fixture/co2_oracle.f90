subroutine b111_co2_response(co2,eff,amax,tra,factors)
use iso_fortran_env,only:real64
implicit none
integer,parameter::macroptb=6
real(real64),intent(in)::co2,eff(6),amax(6),tra(6)
real(real64),intent(out)::factors(3)
real(real64)::co2efftb(6),co2amaxtb(6),co2tratb(6),fco2amax,fco2eff,fco2tra,b111_co2_afgen
co2efftb=eff;co2amaxtb=amax;co2tratb=tra
               fco2amax = b111_co2_afgen(co2amaxtb, macroptb, co2)
               fco2eff = b111_co2_afgen(co2efftb, macroptb ,co2)
            fco2tra = b111_co2_afgen(co2tratb, macroptb, co2)
factors=[fco2eff,fco2amax,fco2tra]
end subroutine
   real(8) function b111_co2_afgen (table, iltab, x)

      ! ------------------------------------------------------------------
      ! source  : kees rappoldt, 1/86
      ! purpose : linear interpolation in table with length iltab for a 
      !           given value of the independent variable x.
      ! ------------------------------------------------------------------
      
      implicit none
      
      ! global
      integer, intent(in) :: iltab
      real(8), intent(in) :: table(iltab), x
      
      ! local
      integer :: i
      real(8) :: slope
      
      ! ------------------------------------------------------------------
      
      if (table(1) >= x)  goto 40
      do i = 3,iltab-1,2
        if (table(i) >= x) goto 30
        if (table(i) < table(i-2)) goto 20
      end do
      
      ! table fully filled, argument larger then last x in table
      b111_co2_afgen = table(iltab)
      return
      
      ! table partly filled, argument larger then last x in table
 20   b111_co2_afgen = table(i-1)
      return
      ! argument between first and last x in table, interpolation
 30   slope = (table(i+1)-table(i-1))/(table(i)-table(i-2))
      b111_co2_afgen = table(i-1) + (x-table(i-2))*slope
      return
 
      ! argument less or equal to first x in table
 40   b111_co2_afgen = table(2)
      return

   end function b111_co2_afgen
