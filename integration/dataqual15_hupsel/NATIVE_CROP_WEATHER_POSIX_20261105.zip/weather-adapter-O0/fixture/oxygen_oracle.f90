subroutine b111_root_sink(n,noddrz,upper,enabled,h,ptra,cumdens_top,limits,qrot)
use iso_fortran_env,only:real64
implicit none
integer,intent(in)::n,noddrz,upper
logical,intent(in)::enabled
real(real64),intent(in)::h(n),ptra,cumdens_top(noddrz+1),limits(8)
real(real64),intent(out)::qrot(n)
real(real64)::hlim3l,hlim3h,hlim4,adcrl,adcrh,hlim1,hlim2u,hlim2l,hlim2,hlim3,alpdry,alpwet,alpsol,alpfrs
integer::node,botcom(1)
hlim3l=limits(1);hlim3h=limits(2);hlim4=limits(3);adcrl=limits(4);adcrh=limits(5)
hlim1=limits(6);hlim2u=limits(7);hlim2l=limits(8);botcom(1)=upper
qrot=0.0_real64
if(noddrz==0.or.ptra<1.e-10_real64)return
   do node = 1,noddrz
      qrot(node) = (cumdens_top(node + 1)-cumdens_top(node)) * ptra
   end do

   if (ptra < adcrl) then
      hlim3 = hlim3l
   else if (ptra <= adcrh) then
      hlim3 = hlim3h + ((adcrh - ptra) / (adcrh - adcrl)) * (hlim3l - hlim3h)
   else
      hlim3 = hlim3h
   end if

do node=1,noddrz
alpwet=1.0_real64;alpdry=1.0_real64;alpsol=1.0_real64;alpfrs=1.0_real64
if(enabled)then
            if (node > botcom(1)) then
               hlim2 = hlim2l
            else
               hlim2 = hlim2u
            end if
            if (h(node) <= hlim1 .AND. h(node) > hlim2) then
               alpwet = (hlim1 - h(node)) / (hlim1 - hlim2)
            end if
            if (h(node) > hlim1) then
               alpwet = 0.0d0
            end if

end if
      if (h(node) < hlim4) then
         alpdry = 0.0d0
      else if (h(node) <= hlim3) then
         alpdry = (hlim4 - h(node)) / (hlim4 - hlim3)
      end if

       qrot(node)    = qrot(node) * alpwet * alpdry * alpsol * alpfrs
end do
end subroutine
