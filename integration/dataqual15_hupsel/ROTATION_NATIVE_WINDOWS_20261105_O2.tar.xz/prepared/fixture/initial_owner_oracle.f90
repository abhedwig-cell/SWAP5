subroutine b111_initial_owner_oracle(tdwi,fr0,fl0,fs0,fo0,sla0,ssa,spa,result)
use iso_fortran_env, only: real64
implicit none
real(real64),intent(in)::tdwi,fr0,fl0,fs0,fo0,sla0,ssa,spa
real(real64),intent(out)::result(10)
type params
 real(real64)::tdwi,ssa,spa
 real(real64)::frtb(2),fltb(2),fstb(2),fotb(2),slatb(2)
end type
type states
 real(real64)::wrt,wst,wlv,wso,dwrt,dwst,dwlv,lasum,laiexp,lai
 real(real64)::sla(1),lvage(1),lv(1)
 integer::ilv
end type
type(params)::p
type(states)::s
real(real64)::dvs,tsum,atmin7(7),vern,fr,fs,fl,fo,tadw
integer::nofd,macroptb
logical::fl_start_cropemergence,fl_anthesis,fl_vernalised
p%tdwi=tdwi;p%ssa=ssa;p%spa=spa
p%frtb=[0.0_real64,fr0];p%fltb=[0.0_real64,fl0]
p%fstb=[0.0_real64,fs0];p%fotb=[0.0_real64,fo0];p%slatb=[0.0_real64,sla0]
fl_start_cropemergence=.true.;macroptb=2
      if (fl_start_cropemergence) then
         
         ! running average low temperature 
         nofd = 0
         atmin7 = 0.d0

         ! phenology
         dvs = 0.d0
         tsum = 0.d0
         fl_anthesis = .FALSE.
      
         ! vernalisation
         vern = 0.d0
         fl_vernalised = .FALSE.
         
         ! specific leaf area
         s%sla(1) = afgen (p%slatb, macroptb, dvs)
         s%ilv = 1
         s%lvage(1) = 0.0d0
      
         ! biomass
         fr = afgen (p%frtb, macroptb, dvs)
         fl = afgen (p%fltb, macroptb, dvs)
         fs = afgen (p%fstb, macroptb, dvs)
         fo = afgen (p%fotb, macroptb, dvs)
         
         s%wrt = fr * p%tdwi
         tadw = (1.0d0 - fr) * p%tdwi
         s%wst = fs * tadw
         s%wlv = fl * tadw
         s%wso = fo * tadw

         s%dwrt = 0.d0
         s%dwst = 0.d0
         s%dwlv = 0.d0
         
         ! leaf area index
         s%lasum = s%wlv * s%sla(1)

         s%lv(1) = s%wlv
         s%laiexp = s%lasum
         s%lai = s%lasum + p%ssa * s%wst + p%spa * s%wso
         
      end if

result=[s%wrt,s%wst,s%lv(1),s%wso,s%laiexp,s%sla(1),s%lvage(1),dvs,tsum,s%lai]
contains
function afgen(table,n,x) result(value)
integer,intent(in)::n
real(real64),intent(in)::table(n),x
real(real64)::value
value=table(2)
end function
end subroutine
