subroutine literal_crop_exchange(Ndemand,dvs,lai,rd,tcsf_in,LaiCritNupt,supply)
 use iso_fortran_env,only:real64
 use wofost_soil_declarations
 use MOD_texture_orgmat,only:bdens
 implicit none
 real(real64),intent(in)::Ndemand,dvs,lai,rd,tcsf_in,LaiCritNupt
 real(real64),intent(out)::supply
 real(real64)::ProdRate0,ProducPot,ProducAct,TCSF,FactNuptJuvenil,Nsupply
 real(real64)::cNH4_t_Ndemand_rate_limited,cNH4_av_Ndemand_rate_limited,cNH4_t_Nsupply_rate_limited,cNH4_av_Nsupply_rate_limited
 real(real64)::cNO3_t_Ndemand_rate_limited,cNO3_av_Ndemand_rate_limited,cNO3_t_Nsupply_rate_limited,cNO3_av_Nsupply_rate_limited
 real(real64)::Nsupply_Ndemand_rate_limited,Nsupply_Nsupply_rate_limited
 logical::FlNuptJuvenil,fl_cropcalendar
 TCSF_N=tcsf_in;fl_cropcalendar=.true.
! Mineralisation, but Nminer is negative in case of immobilisation
      ProdRate0 = Nminer / dt_WSN


! Crop uptake
      FactNuptJuvenil = 0.d0
      FlNuptJuvenil = .FALSE.
      if (fl_cropcalendar  .AND. dvs <  1.d0 .AND. LaiCritNupt > 1.0d-02 .AND. lai < LaiCritNupt) then
         FactNuptJuvenil = ( LaiCritNupt - lai ) / LaiCritNupt
         FlNuptJuvenil = .TRUE.
      end if


      if (FlNuptJuvenil) then
         ProducPot = ProdRate0 - FactNuptJuvenil * Ndemand / dz_WSN 
         TCSF = TCSF_N * (0.5 * (WFrac_t + WFrac_t0) + bdens(1) * SorpCoef) / (0.5d0 * (WFrac_t + WFrac_t0)) * (1.0d0 - FactNuptJuvenil)
!        limitation for rooting depth
         TCSF = TCSF * max(1.0d0, (0.01d0 * rd/dz_WSN))
         call Wofost_SoilWaterN(dz_WSN, dt_WSN, WFrac_t, WFrac_t0,      &
                       Wflux_out, Wflux_transp,Wflux_inBot, Wflux_inTop,&
                       Wflux_inLat, TCSF, RateConNitrif, ProducPot,     &
                       ProducAct, SorpCoef, cNH4N_seep,cNH4N_top,&
                       cNH4N_lat, cNH4_t0, cNH4_t, cNH4_av)
         if ( cNH4_t >= 0.0d0) then
            NsupplyNH4N = TCSF*Wflux_transp *cNH4_av / dz_WSN           &
                         + ProdRate0 - ProducAct                        ! kg/m3
         else
            ProducPot = ProdRate0 
            TCSF = TCSF_N * (0.5 * (WFrac_t + WFrac_t0) + bdens(1) * SorpCoef) / (0.5d0 * (WFrac_t + WFrac_t0))
            TCSF = TCSF * max(1.d0, (0.01d0 * rd / dz_WSN))
            call Wofost_SoilWaterN(dz_WSN, dt_WSN, WFrac_t, WFrac_t0,   &
                       Wflux_out, Wflux_transp,Wflux_inBot, Wflux_inTop,&
                       Wflux_inLat, TCSF, RateConNitrif, ProducPot,     &
                       ProducAct, SorpCoef, cNH4N_seep,cNH4N_top,&
                       cNH4N_lat, cNH4_t0, cNH4_t, cNH4_av)
            NsupplyNH4N = TCSF*Wflux_transp *cNH4_av / dz_WSN
         end if

      else

!     NH4N demand rate limiting
         ProducPot = ProdRate0 - Ndemand / dz_WSN                       ! kg/m3
         TCSF = 0.d0
         call Wofost_SoilWaterN(dz_WSN, dt_WSN, WFrac_t, WFrac_t0,      &
                       Wflux_out, Wflux_transp,Wflux_inBot, Wflux_inTop,&
                       Wflux_inLat, TCSF, RateConNitrif, ProducPot,     &
                       ProducAct, SorpCoef, cNH4N_seep,cNH4N_top,&
                       cNH4N_lat, cNH4_t0, cNH4_t, cNH4_av)
          cNH4_t_Ndemand_rate_limited  = cNH4_t
          cNH4_av_Ndemand_rate_limited = cNH4_av
          Nsupply_Ndemand_rate_limited = ProdRate0 - ProducAct

         ! NH4N supply rate limiting
         ProducPot = ProdRate0 
         TCSF = TCSF_N * (0.5 * (WFrac_t + WFrac_t0) + bdens(1) * SorpCoef) / (0.5d0 * (WFrac_t + WFrac_t0))

         ! limitation for rooting depth
         TCSF = TCSF * max(1.0d0, (0.01d0 * rd / dz_WSN))
         call Wofost_SoilWaterN(dz_WSN, dt_WSN, WFrac_t, WFrac_t0,      &
                       Wflux_out, Wflux_transp,Wflux_inBot, Wflux_inTop,&
                       Wflux_inLat, TCSF, RateConNitrif, ProducPot,     &
                       ProducAct, SorpCoef, cNH4N_seep,cNH4N_top,&
                       cNH4N_lat, cNH4_t0, cNH4_t, cNH4_av)
         cNH4_t_Nsupply_rate_limited  = cNH4_t
         cNH4_av_Nsupply_rate_limited = cNH4_av
         Nsupply_Nsupply_rate_limited = TCSF * Wflux_transp * cNH4_av / dz_WSN ! kg/m3

         if (cNH4_t_Ndemand_rate_limited < cNH4_t_Nsupply_rate_limited) then
            cNH4_t = cNH4_t_Nsupply_rate_limited
            cNH4_av = cNH4_av_Nsupply_rate_limited
            NsupplyNH4N = Nsupply_Nsupply_rate_limited
         else
            cNH4_t = cNH4_t_Ndemand_rate_limited
            cNH4_av = cNH4_av_Ndemand_rate_limited
            NsupplyNH4N = Nsupply_Ndemand_rate_limited
         end if

      end if

!     nitrification
      ProdRate0 = 0.5d0 * (WFrac_t + WFrac_t0) * RateConNitrif * cNH4_av

      if (FlNuptJuvenil) then
         ProducPot = ProdRate0 - FactNuptJuvenil * ( Ndemand /dz_WSN -  &
                                                           NsupplyNH4N )
         TCSF      = TCSF_N * (1.0d0 - FactNuptJuvenil)
!        limitation for rooting depth
         TCSF      = TCSF * max(1.0d0, (0.01d0*rd/dz_WSN))
         call Wofost_SoilWaterN(dz_WSN, dt_WSN, WFrac_t, WFrac_t0,      &
                       Wflux_out, Wflux_transp,Wflux_inBot, Wflux_inTop,&
                       Wflux_inLat, TCSF, RateConDenitr, ProducPot,     &
                       ProducAct,0.0d0, cNO3N_seep, cNO3N_top,          &
                       CNO3N_lat, cNO3_t0, cNO3_t, cNO3_av)
         if (cNO3_t >= 0.0d0) then
            NsupplyNO3N = TCSF * Wflux_transp * cNO3_av / dz_WSN +      &
                          ProdRate0 -ProducAct
         else
            ProducPot = ProdRate0
            TCSF      = TCSF_N
            TCSF      = TCSF * max(1.0d0, (0.01d0*rd/dz_WSN))
            call Wofost_SoilWaterN(dz_WSN, dt_WSN, WFrac_t, WFrac_t0,   &
                       Wflux_out, Wflux_transp,Wflux_inBot, Wflux_inTop,&
                       Wflux_inLat, TCSF, RateConDenitr, ProducPot,     &
                       ProducAct,0.0d0, cNO3N_seep, cNO3N_top,          &
                       CNO3N_lat, cNO3_t0, cNO3_t, cNO3_av)
            NsupplyNO3N = TCSF * Wflux_transp * cNO3_av / dz_WSN       
         end if
      else


!        NO3N demand rate limiting
         ProducPot = ProdRate0 - ( Ndemand /dz_WSN - NsupplyNH4N )
         TCSF       = 0.0d0
         call Wofost_SoilWaterN(dz_WSN, dt_WSN, WFrac_t, WFrac_t0,      &
                       Wflux_out, Wflux_transp,Wflux_inBot, Wflux_inTop,&
                       Wflux_inLat, TCSF, RateConDenitr, ProducPot,     &
                       ProducAct, 0.0d0, cNO3N_seep, cNO3N_top,         &
                       CNO3N_lat, cNO3_t0, cNO3_t, cNO3_av)
         cNO3_t_Ndemand_rate_limited  = cNO3_t
         cNO3_av_Ndemand_rate_limited = cNO3_av
         Nsupply_Ndemand_rate_limited = ProdRate0 -ProducAct 

!        NO3N supply rate limiting
         ProducPot = ProdRate0
         TCSF      = TCSF_N
!        limitation for rooting depth
         TCSF      = TCSF * max(1.0d0, (0.01d0*rd/dz_WSN))
         call Wofost_SoilWaterN(dz_WSN, dt_WSN, WFrac_t, WFrac_t0,      &
                       Wflux_out, Wflux_transp,Wflux_inBot, Wflux_inTop,&
                       Wflux_inLat, TCSF, RateConDenitr, ProducPot,     &
                       ProducAct, 0.0d0, cNO3N_seep, cNO3N_top,         &
                       CNO3N_lat, cNO3_t0, cNO3_t, cNO3_av)
         cNO3_t_Nsupply_rate_limited  = cNO3_t
         cNO3_av_Nsupply_rate_limited = cNO3_av
         Nsupply_Nsupply_rate_limited = TCSF *Wflux_transp *cNO3_av /   &
                                                                 dz_WSN ! kg/m3 

         if (cNO3_t_Ndemand_rate_limited < cNO3_t_Nsupply_rate_limited) then
            cNO3_t      = cNO3_t_Nsupply_rate_limited
            cNO3_av     = cNO3_av_Nsupply_rate_limited
            NsupplyNO3N = Nsupply_Nsupply_rate_limited
         else
            cNO3_t      = cNO3_t_Ndemand_rate_limited
            cNO3_av     = cNO3_av_Ndemand_rate_limited
            NsupplyNO3N = Nsupply_Ndemand_rate_limited
         end if
      end if

      Nsupply = ( NsupplyNH4N + NsupplyNO3N ) * dz_WSN                  ! kg/m2


 supply=Nsupply
end subroutine
