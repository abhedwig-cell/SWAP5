subroutine b111_task2_oracle(sw_prep,sw_sow,sw_germ,fl_prep,fl_sow,fl_germ,delay_prep,delay_sow,tsumgerm)
use iso_fortran_env, only: real64
implicit none
integer,intent(in)::sw_prep,sw_sow,sw_germ
logical,intent(out)::fl_prep,fl_sow,fl_germ
integer,intent(out)::delay_prep,delay_sow
real(real64),intent(out)::tsumgerm
logical::fl_start_croprotation
fl_start_croprotation=.true.
delay_prep=0;delay_sow=0;tsumgerm=0.0_real64


         if (fl_start_croprotation) then

            fl_prep = .TRUE.
            if (sw_prep == 1) then
               fl_prep = .FALSE.
               delay_prep = 0
            end if

         end if



         if (fl_start_croprotation) then

            fl_sow = .TRUE.
            if (sw_sow == 1) then
               fl_sow = .FALSE.
               delay_sow = 0
            end if

         end if
         


         if (fl_start_croprotation) then

            fl_germ = .TRUE.
            if (sw_germ >= 1) then
               fl_germ = .FALSE.
               tsumgerm = 0.d0
            end if

         end if

end subroutine
