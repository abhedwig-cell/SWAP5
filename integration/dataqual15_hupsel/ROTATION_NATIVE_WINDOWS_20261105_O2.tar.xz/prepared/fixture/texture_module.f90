module MOD_texture_orgmat
 use iso_fortran_env,only:real64
 real(real64)::bdens(1)
end module
