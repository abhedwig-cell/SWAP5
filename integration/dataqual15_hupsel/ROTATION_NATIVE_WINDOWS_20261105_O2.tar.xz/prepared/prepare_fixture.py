from pathlib import Path
import gzip,hashlib,sys,base64,io,tarfile
source=Path('tests/qualification/ppa-wu05-migmac10-canonical-20261006/b111-andelst_meteo.999.gz')
data=gzip.decompress(source.read_bytes())
build=Path(sys.argv[1]);build.joinpath('weather.999').write_bytes(data)
build.joinpath('backup.999').write_bytes(data)
# Verified corrected B1.11 source member, already admitted by MC-IRR01.
archive=base64.b64decode(Path('integration/audits/evidence/SWAP431_B111_AUTHORITY.tar.gz.b64').read_bytes())
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as donor:
    meteo=donor.extractfile('SWAP/MOD_meteo.f90').read()
    crop=donor.extractfile('SWAP/MOD_cropdevelopment.f90').read()
    wofost=donor.extractfile('SWAP/wofost.f90').read()
assert hashlib.sha256(meteo).hexdigest()=='99fbf7ad4d90f71cc86012e8e1c9970ef4ca40ea879f0f0622a02a0c33be4c9f'
statement=b'         tav = (tmx+tmn)*0.5d0'
assert meteo.splitlines().count(statement)==1
build.joinpath('daily_meteo_oracle.f90').write_bytes(
    b'function b111_daily_tav(tmin,tmax) result(tav)\nuse iso_fortran_env, only: real64\nimplicit none\n'
    b'real(real64),intent(in)::tmin,tmax\nreal(real64)::tmn,tmx,tav\ntmn=tmin\ntmx=tmax\n'+statement+b'\nend function\n')
print('CROP_FILE_WEATHER_B111_METEO_SHA256='+hashlib.sha256(meteo).hexdigest())
# Literal authenticated astronomy body and constants: independent compile.
text=meteo.decode().replace('\r\n','\n')
body=text.split('      ! declination and solar constant for this day',1)[1].split('      if (present(dayl)) then',1)[0]
build.joinpath('astro_oracle.f90').write_text("""subroutine b111_astro_oracle(iday,lat,rad,solar)
use iso_fortran_env,only:real64
implicit none
integer,intent(in)::iday
real(real64),intent(in)::lat,rad
real(real64),intent(out)::solar(6)
real(real64),parameter::pi=3.141592653589793238462643383279502884197d0,radial=pi/180.d0,angle=-4.d0
real(real64)::dec,sc,aob,aob_corr,angot,dsinb,frdif
real(real64)::atmtr_,dayl_,daylp_,sinld_,cosld_,difpp_,dsinbe_
"""+body+"solar=[dayl_,daylp_,sinld_,cosld_,difpp_,dsinbe_]\nend subroutine\n")


# Independent arithmetic oracle: compile the literal authenticated source
# case(3), not a translated copy of the new owner implementation. Caller
# provides the actual accepted soil sample and existing owner temperature sum.
assert hashlib.sha256(crop).hexdigest()=='aef69feef8561c1b9e52cff5a217a6155f949a039769e5d793df3038f86e4210'
text=crop.decode().replace('\r\n','\n')
routine=text.split('   subroutine germination (task)',1)[1].split('   end subroutine germination',1)[0]
body=routine.split('      case (3)',1)[1].split('      case default',1)[0]
coefficients='\n'.join(line for line in routine.splitlines() if line.strip().startswith(('cgerm =','bgerm =')))
assert len(coefficients.splitlines())==2
header="""subroutine b111_germination_oracle(sw_germ,tsumgerm,tsumemeopt,tbasem,teffmx,tav, &
  sampled_head,hdrygerm,hwetgerm,agerm,fl_germ)
use iso_fortran_env, only: real64
implicit none
integer,intent(in)::sw_germ
real(real64),intent(inout)::tsumgerm
real(real64),intent(in)::tsumemeopt,tbasem,teffmx,tav,sampled_head,hdrygerm,hwetgerm,agerm
logical,intent(out)::fl_germ
real(real64)::tsumemesub,h_avg,pF_avg,cgerm,bgerm,dvs,zgerm
zgerm=0.0_real64
"""
footer="""contains
function h_average(depth) result(head)
real(real64),intent(in)::depth
real(real64)::head
head=sampled_head
end function
end subroutine
"""
build.joinpath('crop_germination_oracle.f90').write_text(header+coefficients+'\n'+body+footer)
print('CROP_FILE_WEATHER_B111_CROP_SHA256='+hashlib.sha256(crop).hexdigest())
# Compile the source task2 flag/counter branches unchanged. The sowing-node
# search is qualified separately by the existing certified geometry owner.
branches=[]
for name in ('preparation','sowing','germination'):
    routine=text.split('   subroutine '+name+' (task)',1)[1].split('   end subroutine '+name,1)[0]
    branch=routine.split('      case (2)',1)[1].split('         return',1)[0]
    if name=='sowing':
        branch=branch.split('         ! determine compartment',1)[0]
    branches.append(branch)
build.joinpath('task2_oracle.f90').write_text('''subroutine b111_task2_oracle(sw_prep,sw_sow,sw_germ,fl_prep,fl_sow,fl_germ,delay_prep,delay_sow,tsumgerm)
use iso_fortran_env, only: real64
implicit none
integer,intent(in)::sw_prep,sw_sow,sw_germ
logical,intent(out)::fl_prep,fl_sow,fl_germ
integer,intent(out)::delay_prep,delay_sow
real(real64),intent(out)::tsumgerm
logical::fl_start_croprotation
fl_start_croprotation=.true.
delay_prep=0;delay_sow=0;tsumgerm=0.0_real64
'''+''.join(branches)+'end subroutine\n')
for name,header in (
 ('preparation','''subroutine b111_prep3_oracle(sampled_head,h_prep,delay_prep,max_delay_prep,delay_sow,fl_prep)
use iso_fortran_env, only: real64
implicit none
real(real64),intent(in)::sampled_head,h_prep
integer,intent(inout)::delay_prep,delay_sow
integer,intent(in)::max_delay_prep
logical,intent(out)::fl_prep
real(real64)::dh_prep,dvs,z_prep
z_prep=0.0_real64
'''),
 ('sowing','''subroutine b111_sow3_oracle(sampled_head,h_sow,soil_temperature,tempsow,delay_sow,max_delay_sow,fl_sow)
use iso_fortran_env, only: real64
implicit none
real(real64),intent(in)::sampled_head,h_sow,soil_temperature,tempsow
integer,intent(inout)::delay_sow
integer,intent(in)::max_delay_sow
logical,intent(out)::fl_sow
real(real64)::dh_sow,dtempsow,dvs,z_sow,tsoil(1)
integer::nodsow
z_sow=0.0_real64;nodsow=1;tsoil(1)=soil_temperature
''')):
    routine=text.split('   subroutine '+name+' (task)',1)[1].split('   end subroutine '+name,1)[0]
    body=routine.split('      case (3)',1)[1].split('         return',1)[0]
    footer='''contains
function h_average(depth) result(head)
real(real64),intent(in)::depth
real(real64)::head
head=sampled_head
end function
end subroutine
'''
    build.joinpath(name+'_oracle.f90').write_text(header+body+footer)

assert hashlib.sha256(wofost).hexdigest()=='3f7daf222835c9b4b395feaa665614e8aef88a03125cdec9e0776ca793c6271b'
legacy=wofost.decode().replace('\r\n','\n')
init=legacy.split('   subroutine initialize_wofost (s)',1)[1].split('   end subroutine initialize_wofost',1)[0]
body=init[init.index('      if (fl_start_cropemergence) then'):init.index('      return')]
header="""subroutine b111_initial_owner_oracle(tdwi,fr0,fl0,fs0,fo0,sla0,ssa,spa,result)
use iso_fortran_env, only: real64
implicit none
real(real64),intent(in)::tdwi,fr0,fl0,fs0,fo0,sla0,ssa,spa
real(real64),intent(out)::result(10)
type params
 real(real64)::tdwi,ssa,spa
 real(real64)::frtb(2),fltb(2),fstb(2),fotb(2),slatb(2)
end type
type states
 real(real64)::wrt,wst,wlv,wso,dwrt,dwst,dwlv,lasum,laiexp,lai
 real(real64)::sla(1),lvage(1),lv(1)
 integer::ilv
end type
type(params)::p
type(states)::s
real(real64)::dvs,tsum,atmin7(7),vern,fr,fs,fl,fo,tadw
integer::nofd,macroptb
logical::fl_start_cropemergence,fl_anthesis,fl_vernalised
p%tdwi=tdwi;p%ssa=ssa;p%spa=spa
p%frtb=[0.0_real64,fr0];p%fltb=[0.0_real64,fl0]
p%fstb=[0.0_real64,fs0];p%fotb=[0.0_real64,fo0];p%slatb=[0.0_real64,sla0]
fl_start_cropemergence=.true.;macroptb=2
"""
footer="""result=[s%wrt,s%wst,s%lv(1),s%wso,s%laiexp,s%sla(1),s%lvage(1),dvs,tsum,s%lai]
contains
function afgen(table,n,x) result(value)
integer,intent(in)::n
real(real64),intent(in)::table(n),x
real(real64)::value
value=table(2)
end function
end subroutine
"""
build.joinpath('initial_owner_oracle.f90').write_text(header+body+footer)
print('CROP_FILE_WEATHER_B111_WOFOST_SHA256='+hashlib.sha256(wofost).hexdigest())


# Preserve all authentic input bytes for the positive production run. The
# negatives deliberately retain TAV while changing the underlying record.
lines=data.decode().splitlines(keepends=True)
for i,line in enumerate(lines):
    fields=line.split()
    if len(fields)==12 and fields[1:4]==['20','1','1999']:
        fields[5]='4.2';fields[6]='6.7'
        lines[i]=' '.join(fields)+'\n'
        break
else: raise AssertionError('missing authoritative historical record')
build.joinpath('altered.999').write_text(''.join(lines))
build.joinpath('bad.999').write_text("'ANDE-M' 20 1 1999 1 2 3 4 5 /\n")
print('CROP_FILE_WEATHER_INPUT_SHA256='+hashlib.sha256(data).hexdigest())
assert hashlib.sha256(data).hexdigest()=='ba5c1f880f6166842ed292c18fd12a142cfda4158002f9487fd1420e734e7b72'
# The admitted B110 bridge requires the linked grid and typed runtime
# geometry to agree. Declare a consistent physical 30cm qualification grid,
# as in the existing B19 current-source builder, without changing HeadCalc.
stub=Path('tests/fsi/fsi04_real_headcalc_stubs.f90').read_text()
replacements={
 '[-0.25d0, -0.75d0, -1.50d0, -2.50d0]':'[-2.5d0, -7.5d0, -15.0d0, -25.0d0]',
 '[0.50d0, 0.50d0, 1.00d0, 1.00d0]':'[5.0d0, 5.0d0, 10.0d0, 10.0d0]',
 'disnod(numnod+1) = 1.0d0':'disnod(numnod+1) = [2.5d0, 5.0d0, 7.5d0, 10.0d0, 5.0d0]',
}
for old,new in replacements.items():
    assert stub.count(old)==1
    stub=stub.replace(old,new)
build.joinpath('grid_stubs.f90').write_text(stub)