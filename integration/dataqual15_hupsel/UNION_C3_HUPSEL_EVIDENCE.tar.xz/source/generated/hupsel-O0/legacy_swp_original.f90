module legacy_swp_context
 implicit none
 integer::unit_swp=71,unit_err=0,swcrop=0,swsolu=1,numlay=0
 character(1024)::swpfilnam
 logical::fl_initialize=.false.
end module
module mod_swp_original_chemistry
 use legacy_swp_context
 implicit none
 integer::nconc,ncseep,swbotbc,swbr,swsba=0,swsp,swdc
 real(8)::cpre,cdrain,cseep,ddif,tscf,frexp,cref,gampar,rtheta,bexp,daquif,poros,kfsat,decsat
 real(8),allocatable::cmltb(:),cseeptab(:),kf(:),ldis(:),decpot(:),fdepth(:)
contains
      subroutine read_solute_CDE

      use legacy_swp_context, only: unit_swp, swpfilnam, unit_err, fl_initialize, swcrop
!      use MOD_texture_orgmat, only: bdens
      use legacy_swp_context, only: numlay

      implicit none

      integer :: i, lay
      real(8), dimension(:), allocatable :: z_ini, s_ini
      real(8), dimension(:), allocatable :: dates, cseeparr
      character(len=200) :: message
      
      ! functions
      logical                             :: rdinqr, rdinar

! =================================================================
!     Section solute transport
      call rdinit(unit_swp, unit_err, swpfilnam)

      if (swsolu == 1) then

!        if (.NOT. allocated(bdens)) call swap_error ('read_solute_CDE', 'BDENS not allocated')

! ---   top boundary and initial condition
        call rdsdor ('cpre',  0.0d0,100.0d0,cpre)
        call rdsdor ('cdrain',0.0d0,100.0d0,cdrain)

!       bottom condition with 3 options:
!       SWBOTBC = 0: lateral (cdrain as input), bottom set to lateral (cseep=cdrain)
!       SWBOTBC = 1: separate input of bottom conc as cseep
!       SWBOTBC = 2: separate input of dynamic bottom conc as (datec,cseeparr)
        swbotbc = 0
        if (rdinqr('swbotbc')) then
          call rdsinr ('swbotbc',0,2,swbotbc)
        end if
        if (swbotbc == 0) then
          cseep = cdrain
        else if (swbotbc == 1) then
          call rdsdor ('cseep',0.0d0,100.0d0,cseep)
        else if (swbotbc == 2) then
          if (.NOT. rdinqr('datec')) call swap_error ('read_solute_CDE', 'Variable DATEC not present in file '//trim(swpfilnam))
          call rdinne('datec', ncseep)
          allocate(dates(ncseep))
          allocate(cseeparr(ncseep))
          if (allocated(cseeptab)) deallocate(cseeptab); allocate(cseeptab(2*ncseep))
          call rdftim ('datec',dates,ncseep,ncseep)
          call rdfdor ('cseeparr',0.0d0,100.0d0,cseeparr,ncseep,ncseep)
          do i = 1, ncseep
            cseeptab(i*2)   = cseeparr(i)
            cseeptab(i*2-1) = dates(i)
          end do
          ncseep = ncseep * 2 ! save total length of cseeptab
          deallocate(dates)
          deallocate(cseeparr)
        end if

        if (.NOT. fl_initialize) then
          
           ! old procedure (deprecated)
           if (rdinqr('cml')) then
             
              message = 'Usage of ZC and CML are deprecated, use CMLTB instead'
              call swap_warning('read_solute_CDE', message)
            
              call rdinne ('cml',nconc)
              allocate(z_ini(nconc)); allocate(s_ini(nconc))
              if (allocated(cmltb)) deallocate(cmltb); allocate(cmltb(nconc*2)); cmltb = 0.d0
           
              call rdfdor ('zc',-1.0d5,0.0d0,z_ini,nconc,nconc)
              call rdfdor ('cml',0.0d0,1.0d3,s_ini,nconc,nconc)
           
              do i = 1, nconc
                 cmltb(i*2) = s_ini(i)
                 cmltb(i*2-1) = dabs(z_ini(i))
              end do
              nconc = nconc*2
             
              deallocate(z_ini, s_ini)
           
           ! new procedure
           else
              
              if (.NOT. rdinqr('cmltb')) call swap_error ('read_solute_CDE', 'Variable CMLTB not present in file '//trim(swpfilnam))
              call rdinne ('cmltb',nconc)
              if (allocated(cmltb)) deallocate(cmltb); allocate(cmltb(nconc)); cmltb = 0.d0
              call rdadortb('cmltb', -1.0d5, 0.0d0, 0.0d0, 1.0d3, cmltb, nconc, .TRUE.)
           
           end if
          
        end if

! ---   diffusion, dispersion and solute uptake by roots
        call rdsdor ('ddif',0.0d0,10.0d0,ddif)
        if (rdinar('ldis')) then
          call rdfdor ('ldis',0.0d0,100.d0,ldis,numlay,numlay)
        else
          call rdsdor ('ldis',0.0d0,100.d0,ldis(1)); if (numlay > 1) ldis(2:numlay) = ldis(1)
        end if
        tscf = 0.d0
        if (swcrop == 1) call rdsdor ('tscf',0.0d0,10.0d0,tscf)

! ---   sorption
        call rdsinr ('swsp',0,1,swsp)
        if (swsp == 1) then

          call rdsdor ('frexp',0.0d0,   10.0d0,frexp)
          call rdsdor ('cref', 0.0d0, 1000.0d0,cref)
          if (rdinar('kf')) then
            call rdfdor ('kf',0.0d0,10000.0d0,kf,numlay,numlay)
          else
            call rdsdor ('kf',0.0d0,10000.0d0,kf(1)); if (numlay > 1) kf(2:numlay) = kf(1)
          end if
        else
          cref  = 1.0d0
          frexp = 1.0d0
          do lay = 1, numlay
            kf(lay) = 0.0d0
          end do
        end if

! ---   decomposition
        call rdsinr ('swdc',0,1,swdc)
        if (swdc == 1) then
          if (rdinar('decpot')) then
            call rdfdor ('decpot',0.0d0,10.0d0,decpot,numlay,numlay)
          else
            call rdsdor ('decpot',0.0d0,10.0d0,decpot(1)); if (numlay > 1) decpot(2:numlay) = decpot(1)
          end if
          call rdsdor ('gampar',0.0d0,0.5d0,gampar)
          call rdsdor ('rtheta',0.0d0,0.4d0,rtheta)
          call rdsdor ('bexp',0.0d0,2.0d0,bexp)
          if (rdinar('fdepth')) then
            call rdfdor ('fdepth',0.0d0,1.0d0,fdepth,numlay,numlay)
          else
            call rdsdor ('fdepth',0.0d0,1.0d0,fdepth(1)); if (numlay > 1) fdepth(2:numlay) = fdepth(1)
          end if
        else
          gampar = 0.0d0
          rtheta = 0.5d0
          bexp   = 0.0d0
          do lay = 1, numlay
            decpot(lay) = 0.0d0
            fdepth(lay) = 0.0d0
          end do
        end if

! ---   breakthrough
        call rdsinr ('swbr',0,1,swbr)
        if (swbr == 0) then
          daquif = 100.0d0
          poros  = 1.0d0
          kfsat  = 0.0d0
          decsat = 0.0d0
        else
          call rdsdor ('daquif',0.0d0,10000.0d0,daquif)
          call rdsdor ('poros',0.0d0,0.6d0,poros)
          call rdsdor ('kfsat',0.0d0,100.0d0,kfsat)
          call rdsdor ('decsat',0.0d0,10.0d0,decsat)
          call rdsdor ('cdraini',0.0d0,100.0d0,cdrain)
          cseep = cdrain
        end if

        if (rdinqr('swsba')) then
           call rdsinr ('swsba',0,1,swsba)
        end if

      end if

      close(unit_swp)

      end subroutine read_solute_CDE
end module
   
   subroutine afgen_2(table, iltab, x, y, ipos)
      
      ! ------------------------------------------------------------------
      ! source  : kees rappoldt, 1/86
      !           adapted to become subroutine with extra output of position
      ! purpose : linear interpolation in table with
      !           length iltab for a given value of the independent variable x.
      !           y is result, ipos is the current position in the table.
      ! ------------------------------------------------------------------
      
      implicit none

      real(8), dimension(iltab), intent(in)     :: table(iltab)
      integer,                   intent(in)     :: iltab
      real(8),                   intent(in)     :: x
      real(8),                   intent(out)    :: y
      integer,                   intent(inout)  :: ipos

      integer                                   :: i
      real(8)                                   :: slope
      
      ! ------------------------------------------------------------------
      if (ipos > 0 .AND. mod(ipos,2) == 0) call swap_error ('afgen_2', 'ipos must be zero or odd on entry')
      if (table(1) >= x)  goto 40
      do i = max(3, ipos), iltab-1, 2
        if (table(i) >= x) goto 30
        if (table(i) < table(i-2)) goto 20
      end do

      ! table fully filled, argument larger then last x in table
      y    = table(iltab)
      ipos = iltab - 1
      return

      ! table partly filled, argument larger then last x in table
20    y    = table(i-1)
      ipos = i - 2
      return

      ! argument between first and last x in table, interpolation
 30   slope = (table(i+1)-table(i-1))/(table(i)-table(i-2))
      y     = table(i-1) + (x-table(i-2))*slope
      ipos  = i - 2
      return

      ! argument less or equal to first x in table
40    y     = table(2)
      ipos  = 1
      return

   end subroutine afgen_2

   subroutine rdadortb (name,xmin,xmax,ymin,ymax,xy,ildec,flip_index)
      
      ! ------------------------------------------------------------------
      ! Reads two arrays, with y = f(x), of double precision values from a
      ! TTUTIL format data file and carries out a range check on the
      ! returned values.
      ! ------------------------------------------------------------------
   
      implicit none

      ! variables
      integer, intent(in)           :: ildec
      real(8), intent(in)           :: xmin,xmax,ymin,ymax
      character(len=*), intent(in)  :: name
      real(8), intent(out)          :: xy(ildec)
      logical, intent(in)           :: flip_index
      
      ! local variables
      integer                       :: i, ifnd
      character(len=200)            :: message
      
      ! local parameters
      character(len=1), parameter :: quote = ''''

      ! ------------------------------------------------------------------
      
      ! check specified range   
      if (xmax < xmin .OR. ymax < ymin) then
         message = 'Range not valid of identifier ' // quote // trim(name) // quote
         call swap_error ('rdadortb', message)
      end if
      
      ! reset array
      xy(:) = 0.d0
      
      ! load array without range check
      call rdadou(trim(name), xy, ildec, ifnd)
      
      ! check range
      do i = 2,ifnd,2
         if (xy(i-1) < xmin .OR. xy(i-1) > xmax) then
             write(message,'(4a,i3,3a,3(g12.5,a))') 'Range error of identifier ', quote, trim(name), '(', i-1, ')', quote, ' value =' , xy(i-1), ', range = [', xmin , ',', xmax ,']'
             call swap_error ('rdadortb', message)
         end if
         if (xy(i) < ymin .OR. xy(i) > ymax) then
             write(message,'(4a,i3,3a,3(g12.5,a))') 'Range error of identifier ', quote, trim(name), '(', i, ')', quote, ' value =' , xy(i), ', range = [', ymin , ',', ymax ,']'
             call swap_error ('rdadortb', message)
         end if
         if (flip_index) xy(i-1) = dabs(xy(i-1))
      end do

      return
   end subroutine rdadortb
