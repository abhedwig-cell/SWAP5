* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-17 10:52:34

Period             :  1900-01-01  until  2002-08-03 
Depth soil profile :  200.00 cm

            Water storage
Final   :        70.45 cm
Initial :        75.19 cm
            =============
Change           -4.73 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    49.83    Interception      :     2.53
Runon          :     2.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    20.96
Bottom flux    :     0.00    Soil evaporation  :     9.10
                             Crack flux        :     0.00
                             Drainage level 1  :    26.38
=========================    ============================
Sum            :    54.23    Sum               :    58.96
