* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:13:38

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.70 cm       0.4337E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.51 cm       0.4337E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.28
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.06
Bottom flux    :   -12.51    Soil evaporation  :    11.96
                             Crack flux        :     0.00
                             Drainage level 1  :    20.25
=========================    ============================
Sum            :    74.07    Sum               :    71.56


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.7246E-03
                             Drainage       :  0.4632E+01
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.4632E+01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.07 cm       0.2741E+02 mg/cm2
Initial :        77.70 cm       0.4337E+02 mg/cm2
            =============       =================
Change           -1.63 cm      -0.1596E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.88
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     8.00    Transpiration     :    24.40
Bottom flux    :   -14.17    Soil evaporation  :    13.95
                             Crack flux        :     0.00
                             Drainage level 1  :    22.20
=========================    ============================
Sum            :    65.81    Sum               :    67.44


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.1907E+01
                             Drainage       :  0.1405E+02
=========================    ============================
Sum         : -0.1907E+01    Sum            :  0.1405E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.56 cm       0.1404E+02 mg/cm2
Initial :        76.07 cm       0.2741E+02 mg/cm2
            =============       =================
Change           -0.51 cm      -0.1338E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :   -10.08    Soil evaporation  :    14.31
                             Crack flux        :     0.00
                             Drainage level 1  :    12.99
=========================    ============================
Sum            :    70.47    Sum               :    70.98


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.7858E+01
                             Drainage       :  0.5518E+01
=========================    ============================
Sum         : -0.7858E+01    Sum            :  0.5518E+01

