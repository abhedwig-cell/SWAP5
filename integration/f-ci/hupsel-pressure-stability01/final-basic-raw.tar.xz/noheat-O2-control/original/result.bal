* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:11:21

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        59.86 cm       0.1452E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -15.33 cm       0.1452E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :   -81.83    Soil evaporation  :    20.07
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :     4.75    Sum               :    20.07


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.3348E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.1452E+02    Sum            :  0.0000E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        58.18 cm       0.9478E-02 mg/cm2
Initial :        59.86 cm       0.1452E+02 mg/cm2
            =============       =================
Change           -1.68 cm      -0.1451E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -54.39    Soil evaporation  :    19.27
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    17.59    Sum               :    19.27


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.1451E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.1451E+02    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        56.66 cm       0.1909E-06 mg/cm2
Initial :        58.18 cm       0.9478E-02 mg/cm2
            =============       =================
Change           -1.52 cm      -0.9477E-02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -61.29    Soil evaporation  :    20.79
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    19.26    Sum               :    20.79


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.9477E-02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.9477E-02    Sum            :  0.0000E+00

