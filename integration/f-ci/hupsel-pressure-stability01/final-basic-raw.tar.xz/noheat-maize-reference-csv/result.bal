* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:11:52

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.01 cm       0.3896E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.82 cm       0.3896E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.03
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    32.76
=========================    ============================
Sum            :    86.58    Sum               :    83.76


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.9044E+01
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.9044E+01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        70.66 cm       0.2473E+02 mg/cm2
Initial :        78.01 cm       0.3896E+02 mg/cm2
            =============       =================
Change           -7.35 cm      -0.1422E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     2.76
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    36.57
Bottom flux    :     0.00    Soil evaporation  :    13.34
                             Crack flux        :     0.00
                             Drainage level 1  :    26.65
=========================    ============================
Sum            :    71.98    Sum               :    79.33


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1422E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1422E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        68.07 cm       0.1848E+02 mg/cm2
Initial :        70.66 cm       0.2473E+02 mg/cm2
            =============       =================
Change           -2.59 cm      -0.6250E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     9.03
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    49.19
Bottom flux    :     0.00    Soil evaporation  :     9.20
                             Crack flux        :     0.00
                             Drainage level 1  :    15.71
=========================    ============================
Sum            :    80.55    Sum               :    83.14


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.6250E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.6250E+01

