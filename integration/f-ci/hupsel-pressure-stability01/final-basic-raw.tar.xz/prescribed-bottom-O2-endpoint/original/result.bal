* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:12:51

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        66.05 cm       0.4533E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change           -9.14 cm       0.4533E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.28
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.06
Bottom flux    :   -27.38    Soil evaporation  :    11.96
                             Crack flux        :     0.00
                             Drainage level 1  :    17.03
=========================    ============================
Sum            :    59.20    Sum               :    68.34


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.3029E+00
                             Drainage       :  0.2365E+01
=========================    ============================
Sum         :  0.4770E+02    Sum            :  0.2365E+01

