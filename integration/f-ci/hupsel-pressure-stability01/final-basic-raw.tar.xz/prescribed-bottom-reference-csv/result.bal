* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:12:52

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        66.05 cm       0.4532E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change           -9.14 cm       0.4532E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.28
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.06
Bottom flux    :   -27.38    Soil evaporation  :    11.96
                             Crack flux        :     0.00
                             Drainage level 1  :    17.03
=========================    ============================
Sum            :    59.20    Sum               :    68.34


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.3044E+00
                             Drainage       :  0.2374E+01
=========================    ============================
Sum         :  0.4770E+02    Sum            :  0.2374E+01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        66.58 cm       0.1478E+02 mg/cm2
Initial :        66.05 cm       0.4532E+02 mg/cm2
            =============       =================
Change            0.53 cm      -0.3055E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.95
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     8.00    Transpiration     :    23.99
Bottom flux    :   -34.22    Soil evaporation  :    13.83
                             Crack flux        :     0.00
                             Drainage level 1  :     0.46
=========================    ============================
Sum            :    45.76    Sum               :    45.23


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.3018E+02
                             Drainage       :  0.3657E+00
=========================    ============================
Sum         : -0.3018E+02    Sum            :  0.3657E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        58.43 cm       0.5308E+00 mg/cm2
Initial :        66.58 cm       0.1478E+02 mg/cm2
            =============       =================
Change           -8.15 cm      -0.1424E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.32
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    31.77
Bottom flux    :   -29.73    Soil evaporation  :    13.80
                             Crack flux        :     0.00
                             Drainage level 1  :     2.09
=========================    ============================
Sum            :    50.82    Sum               :    58.97


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.1381E+02
                             Drainage       :  0.4329E+00
=========================    ============================
Sum         : -0.1381E+02    Sum            :  0.4329E+00

