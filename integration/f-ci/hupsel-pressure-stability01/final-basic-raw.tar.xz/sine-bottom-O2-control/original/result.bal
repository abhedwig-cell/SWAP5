* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:13:10

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        72.37 cm       0.4459E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change           -2.82 cm       0.4459E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.73
Bottom flux    :   -18.25    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    20.18
=========================    ============================
Sum            :    68.33    Sum               :    71.15


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.3891E-01
                             Drainage       :  0.3370E+01
=========================    ============================
Sum         :  0.4796E+02    Sum            :  0.3370E+01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        72.80 cm       0.2551E+02 mg/cm2
Initial :        72.37 cm       0.4459E+02 mg/cm2
            =============       =================
Change            0.44 cm      -0.1908E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.88
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     8.00    Transpiration     :    24.14
Bottom flux    :   -18.25    Soil evaporation  :    13.95
                             Crack flux        :     0.00
                             Drainage level 1  :    16.33
=========================    ============================
Sum            :    61.73    Sum               :    61.29


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.7791E+01
                             Drainage       :  0.1129E+02
=========================    ============================
Sum         : -0.7791E+01    Sum            :  0.1129E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        66.05 cm       0.5053E+01 mg/cm2
Initial :        72.80 cm       0.2551E+02 mg/cm2
            =============       =================
Change           -6.75 cm      -0.2046E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.13
Bottom flux    :   -18.30    Soil evaporation  :    14.24
                             Crack flux        :     0.00
                             Drainage level 1  :    11.11
=========================    ============================
Sum            :    62.25    Sum               :    69.00


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.1601E+02
                             Drainage       :  0.4442E+01
=========================    ============================
Sum         : -0.1601E+02    Sum            :  0.4442E+01

