* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:12:12

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        55.90 cm       0.4676E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -19.29 cm       0.4676E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.35
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.72
Bottom flux    :   -54.08    Soil evaporation  :    11.72
                             Crack flux        :     0.00
=========================    ============================
Sum            :    32.50    Sum               :    51.79


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.1236E+01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.4676E+02    Sum            :  0.0000E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        57.71 cm       0.3571E+01 mg/cm2
Initial :        55.90 cm       0.4676E+02 mg/cm2
            =============       =================
Change            1.81 cm      -0.4319E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     7.22
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :    12.00    Transpiration     :    22.86
Bottom flux    :   -38.33    Soil evaporation  :    13.76
                             Crack flux        :     0.00
=========================    ============================
Sum            :    45.65    Sum               :    43.84


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.4319E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.4319E+02    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        54.76 cm       0.2161E-01 mg/cm2
Initial :        57.71 cm       0.3571E+01 mg/cm2
            =============       =================
Change           -2.95 cm      -0.3549E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.75
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    27.93
Bottom flux    :   -31.19    Soil evaporation  :    12.62
                             Crack flux        :     0.00
=========================    ============================
Sum            :    49.36    Sum               :    52.31


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.3549E+01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.3549E+01    Sum            :  0.0000E+00

