* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:10:47

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.01 cm       0.3808E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.82 cm       0.3808E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.03
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    37.75
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    33.99
=========================    ============================
Sum            :    86.58    Sum               :    83.76


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.9918E+01
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.9918E+01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.38 cm       0.2058E+02 mg/cm2
Initial :        78.01 cm       0.3808E+02 mg/cm2
            =============       =================
Change           -1.63 cm      -0.1750E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     4.00    Transpiration     :    28.22
Bottom flux    :     0.00    Soil evaporation  :    14.08
                             Crack flux        :     0.00
                             Drainage level 1  :    35.31
=========================    ============================
Sum            :    75.98    Sum               :    77.61


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1750E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1750E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.03 cm       0.1300E+02 mg/cm2
Initial :        76.38 cm       0.2058E+02 mg/cm2
            =============       =================
Change           -0.34 cm      -0.7581E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    41.09
Bottom flux    :     0.00    Soil evaporation  :    14.94
                             Crack flux        :     0.00
                             Drainage level 1  :    24.86
=========================    ============================
Sum            :    80.55    Sum               :    80.89


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.7581E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.7581E+01

