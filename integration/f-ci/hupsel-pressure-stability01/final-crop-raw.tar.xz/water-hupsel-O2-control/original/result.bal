* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:09:57

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        78.02 cm
Initial :        75.19 cm
            =============
Change            2.83 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.03
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    32.75
=========================    ============================
Sum            :    86.58    Sum               :    83.75

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.38 cm
Initial :        78.02 cm
            =============
Change           -1.64 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.84
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     6.00    Transpiration     :    24.15
Bottom flux    :     0.00    Soil evaporation  :    14.02
                             Crack flux        :     0.00
                             Drainage level 1  :    34.61
=========================    ============================
Sum            :    77.98    Sum               :    79.62

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.02 cm
Initial :        76.38 cm
            =============
Change           -0.36 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.38
                             Crack flux        :     0.00
                             Drainage level 1  :    22.86
=========================    ============================
Sum            :    80.55    Sum               :    80.91
