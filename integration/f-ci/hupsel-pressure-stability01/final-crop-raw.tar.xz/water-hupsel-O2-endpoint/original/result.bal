* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:09:59

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        78.02 cm
Initial :        75.19 cm
            =============
Change            2.83 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.03
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    32.75
=========================    ============================
Sum            :    86.58    Sum               :    83.75
