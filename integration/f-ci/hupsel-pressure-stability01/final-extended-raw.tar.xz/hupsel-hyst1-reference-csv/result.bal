* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:10:13

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.85 cm       0.3892E+02 mg/cm2
Initial :        72.37 cm       0.0000E+00 mg/cm2
            =============       =================
Change            5.49 cm       0.3892E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.94
                             Crack flux        :     0.00
                             Drainage level 1  :    30.18
=========================    ============================
Sum            :    86.58    Sum               :    81.09


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.9084E+01
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.9084E+01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.99 cm       0.2022E+02 mg/cm2
Initial :        77.85 cm       0.3892E+02 mg/cm2
            =============       =================
Change           -1.86 cm      -0.1869E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.83
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     8.00    Transpiration     :    24.34
Bottom flux    :     0.00    Soil evaporation  :    13.81
                             Crack flux        :     0.00
                             Drainage level 1  :    36.86
=========================    ============================
Sum            :    79.98    Sum               :    81.84


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1869E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1869E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.30 cm       0.1310E+02 mg/cm2
Initial :        75.99 cm       0.2022E+02 mg/cm2
            =============       =================
Change           -0.69 cm      -0.7121E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :     0.00    Soil evaporation  :    14.16
                             Crack flux        :     0.00
                             Drainage level 1  :    23.41
=========================    ============================
Sum            :    80.55    Sum               :    81.24


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.7121E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.7121E+01

