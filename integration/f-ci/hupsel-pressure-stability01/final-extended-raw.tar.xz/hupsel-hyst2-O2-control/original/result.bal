* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:10:31

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.86 cm       0.3866E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.67 cm       0.3866E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    32.99
=========================    ============================
Sum            :    86.58    Sum               :    83.91


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.9336E+01
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.9336E+01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.99 cm       0.2009E+02 mg/cm2
Initial :        77.86 cm       0.3866E+02 mg/cm2
            =============       =================
Change           -1.87 cm      -0.1858E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.83
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     8.00    Transpiration     :    24.33
Bottom flux    :     0.00    Soil evaporation  :    13.82
                             Crack flux        :     0.00
                             Drainage level 1  :    36.87
=========================    ============================
Sum            :    79.98    Sum               :    81.85


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1858E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1858E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.30 cm       0.1302E+02 mg/cm2
Initial :        75.99 cm       0.2009E+02 mg/cm2
            =============       =================
Change           -0.69 cm      -0.7066E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :     0.00    Soil evaporation  :    14.19
                             Crack flux        :     0.00
                             Drainage level 1  :    23.38
=========================    ============================
Sum            :    80.55    Sum               :    81.24


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.7066E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.7066E+01

