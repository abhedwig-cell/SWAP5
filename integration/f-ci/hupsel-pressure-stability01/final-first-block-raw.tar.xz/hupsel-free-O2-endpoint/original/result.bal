* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:10:52

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        55.90 cm       0.4676E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -19.29 cm       0.4676E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.35
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.72
Bottom flux    :   -54.08    Soil evaporation  :    11.72
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    32.50    Sum               :    51.79


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.1236E+01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.4676E+02    Sum            :  0.0000E+00

