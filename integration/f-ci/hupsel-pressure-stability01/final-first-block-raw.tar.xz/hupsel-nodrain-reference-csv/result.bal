* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 12:11:18

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        79.18 cm       0.4800E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            3.99 cm       0.4800E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     3.78
Runon          :     0.00    Runoff            :    56.40
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.46
Bottom flux    :     0.00    Soil evaporation  :    21.96
                             Crack flux        :     0.00
=========================    ============================
Sum            :    86.58    Sum               :    82.60


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.0000E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        79.02 cm       0.4800E+02 mg/cm2
Initial :        79.18 cm       0.4800E+02 mg/cm2
            =============       =================
Change           -0.16 cm      -0.1421E-13 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     3.98
Runon          :     0.00    Runoff            :    42.75
SSDI           :     0.00
Irrigation     :    14.00    Transpiration     :    10.27
Bottom flux    :     0.00    Soil evaporation  :    29.14
                             Crack flux        :     0.00
=========================    ============================
Sum            :    85.98    Sum               :    86.15


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        79.07 cm       0.4800E+02 mg/cm2
Initial :        79.02 cm       0.4800E+02 mg/cm2
            =============       =================
Change            0.05 cm      -0.7105E-13 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    10.84
Runon          :     0.00    Runoff            :    24.88
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    26.50
Bottom flux    :     0.00    Soil evaporation  :    18.29
                             Crack flux        :     0.00
=========================    ============================
Sum            :    80.55    Sum               :    80.50


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.0000E+00

