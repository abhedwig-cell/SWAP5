from pathlib import Path
import subprocess,json,time,shutil,hashlib,csv
root=Path(r'C:\Users\Veldh012\AppData\Local\Temp\s5-hupsel51-fix');out=Path(r'C:\SWAP5-testing/hupsel51/comparison431');out.mkdir();provider=Path(r'C:\SWAP5-RC2/provider/build');objects=provider/'swap-obj';src=provider/'swap-selected/headcalc.f90';text=src.read_text(encoding='cp1252')
a='subroutine headcalc \n';assert text.count(a)==1;text=text.replace(a,'subroutine headcalc\n   use hybrid_step_budget, only: linear_pond_top_jacobian\n   use variables, only: rsro,rsroexp,pondmx\n   use MOD_swap_base, only: swdra,swsnow\n')
a='   if (ftoph) dFdhM(1) = dFdhM(1) + kmean(1)/disnod(1)';assert text.count(a)==1
text=text.replace(a,'''   if (ftoph) then
      if (swmacro==0.and.swdra==0.and.swbotb==6.and.swsnow==0.and.swkimpl==0.and.flrunoff.and.rsroexp==1d0.and.rsro>=1d-3) then
         dFdhM(1)=dFdhM(1)+linear_pond_top_jacobian(kmean(1)/disnod(1),dt,pond,pondmx,rsro)
      else
         dFdhM(1)=dFdhM(1)+kmean(1)/disnod(1)
      end if
   end if''')
(out/'headcalc.f90').write_text(text,encoding='cp1252');flags=['gfortran','-O2','-ffree-line-length-none','-ffp-contract=off','-march=x86-64','-mtune=generic','-I'+str(objects)];commands=[]
for cmd in [flags+['-c',str(root/'app/hybrid_water/hybrid_step_budget.f90')],flags+['-c','headcalc.f90'],['gfortran','-o','swap431-linear-pond.exe',*[str(out/'headcalc.o') if p.name=='headcalc.o' else str(p) for p in sorted(objects.glob('*.o'))],str(out/'hybrid_step_budget.o'),str(provider/'ttutil-obj/libttutil.a')]]:
 r=subprocess.run(cmd,cwd=out,capture_output=True,text=True,timeout=30);commands.append(dict(command=cmd,returncode=r.returncode));assert r.returncode==0,r.stderr
case=out/'linear-pond-control';case.mkdir();current=Path(r'C:\SWAP5-testing/hupsel51/final-qualified-O2/undrained/full/original');meta=json.loads(Path(r'C:\SWAP5-testing/hupsel51/final-qualified-O2/undrained/build/BUILD.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in meta['inputs']:shutil.copyfile(current/name,case/name)
exe=out/'swap431-linear-pond.exe';t=time.perf_counter();r=subprocess.run([str(exe),'./swap.swp'],cwd=case,capture_output=True,text=True,timeout=30);wall=time.perf_counter()-t;(out/'control.stdout').write_text(r.stdout);(out/'control.stderr').write_text(r.stderr);assert r.returncode==100,r.stderr
read=lambda p:list(csv.DictReader(s for s in p.read_text().splitlines() if s.strip() and not s.startswith('*')))
control=read(case/'result_output.csv');assert len(control)==1097 and control[-1]['DATE']=='2004-12-31'
old=Path(r'C:\SWAP5-RC2/application-acceptance/new-variants-20261116/hupsel-reactive-undrained/original431');assert all((old/n).read_bytes()==(current/n).read_bytes()==(case/n).read_bytes() for n in meta['inputs'])
raw=read(old/'result_output.csv');new=read(current/'result_output.csv');fields={}
for name,reference in [('pristine431_retained_partial',raw),('original431_with_only_coupled_tangent',control)]:
 common=min(len(reference),len(new));fields[name]=dict(compared_days=common-1,max_abs={k:max(abs(float(x[k])-float(y[k])) for x,y in zip(reference[1:common],new[1:common]) if x[k]!='-999.999' and y[k]!='-999.999') for k in ['GWL','WTOT','BALDEV','S_STOT','S_BALDEV']},day51={k:reference[51][k] for k in ['GWL','WTOT','BALDEV','S_STOT','S_BALDEV']})
record=dict(status='TARGETED_ORIGINAL_COMPARISON_COMPLETE',pristine_original_full='Retained60s timeout; first336days usable, not full reference PASS',corrected_original_control='Original program, time and loose convergence controls; only analytic coupled pond Jacobian changes; no SWAP5 strict guard, not pristine431 or independently scientifically qualified',control_full_days=1096,control_wall_seconds=wall,source_sha256=dict(pristine_headcalc=sha(src),control_headcalc=sha(out/'headcalc.f90'),tangent_helper=sha(root/'app/hybrid_water/hybrid_step_budget.f90')),control_executable_sha256=sha(exe),identical_executed_inputs_sha256={n:sha(case/n) for n in meta['inputs']},commands=commands,comparison=fields,tolerances_changed=False)
(out/'RESULT.json').write_text(json.dumps(record,indent=2));print(json.dumps(dict(seconds=wall,fields=fields)))
