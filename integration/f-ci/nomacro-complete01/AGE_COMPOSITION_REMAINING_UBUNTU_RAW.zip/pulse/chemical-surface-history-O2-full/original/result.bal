* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-17 17:12:36

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.32 cm       0.3783E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            3.13 cm       0.3783E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     2.60    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    35.12
=========================    ============================
Sum            :    89.18    Sum               :    86.05


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1017E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.1017E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.38 cm       0.1921E+02 mg/cm2
Initial :        78.32 cm       0.3783E+02 mg/cm2
            =============       =================
Change           -1.94 cm      -0.1862E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.83
Runon          :     1.40    Runoff            :     0.02
SSDI           :     0.00
Irrigation     :     8.00    Transpiration     :    24.32
Bottom flux    :     0.00    Soil evaporation  :    13.86
                             Crack flux        :     0.00
                             Drainage level 1  :    38.29
=========================    ============================
Sum            :    81.38    Sum               :    83.32


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1862E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1862E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.30 cm       0.1237E+02 mg/cm2
Initial :        76.38 cm       0.1921E+02 mg/cm2
            =============       =================
Change           -1.08 cm      -0.6841E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :     0.00    Soil evaporation  :    14.19
                             Crack flux        :     0.00
                             Drainage level 1  :    23.77
=========================    ============================
Sum            :    80.55    Sum               :    81.63


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.6841E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.6841E+01

