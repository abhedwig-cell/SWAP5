* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-17 17:12:32

Period             :  2004-12-30  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        75.30 cm
Initial :        75.62 cm
            =============
Change           -0.32 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     0.15    Interception      :     0.05
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.01
Bottom flux    :     0.00    Soil evaporation  :     0.01
                             Crack flux        :     0.00
                             Drainage level 1  :     0.43
=========================    ============================
Sum            :     0.15    Sum               :     0.50
