* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-17 15:38:08

Period             :  2002-12-29  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        78.32 cm
Initial :        76.11 cm
            =============
Change            2.21 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     3.88    Interception      :     0.00
Runon          :     0.60    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.01
                             Crack flux        :     0.00
                             Drainage level 1  :     2.26
=========================    ============================
Sum            :     4.48    Sum               :     2.27
