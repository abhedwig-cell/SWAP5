module MOD_Solute

   use MOD_arrays,        only: macp
   use MOD_swap_base,     only: swsolu
   use MOD_solute_global, only: cml,ageml

   implicit none
!   include 'arrays.fi'

   interface
      module subroutine solute_CDE(task)
         integer, intent(in) :: task
      end subroutine solute_CDE
      module subroutine calc_AgeTracer(task)
         integer, intent(in) :: task
      end subroutine calc_AgeTracer
      module subroutine hybrid_age_observe(values)
         real(8),intent(out)::values(11)
      end subroutine
      module subroutine hybrid_age_checkpoint(unit,restoring)
         integer,intent(in)::unit
         logical,intent(in)::restoring
      end subroutine
    end interface

!  solute: used in swap_csv_output
   integer   swdc               ! Switch solute decomposition (N=0;Y=1)

!  solute: used in outcsv
   real(8)                    :: imdectot           ! Intermediate amount of solute decomposition (M/L2)
   real(8)                    :: imrottot           ! Intermediate amount of solutes (M/L2) extracted by plant roots
   real(8)                    :: imsqbot            ! Intermediate amount of solutes (M/L2) passed through the soil column bottom
   real(8)                    :: imsqdra            ! Intermediate Total amount of solutes (M/L2) transported to drainage canals
   real(8)                    :: imsqirrig          ! Intermediate amount of solutes (M/L2) in irrigation water
   real(8)                    :: imsqprec           ! Intermediate amount of solutes (M/L2) in precipitation
   real(8), dimension(macp+1) :: imqsol             ! Intermediate amount of solutes (M/L2) transported over top of compartment
   real(8)                    :: sbaldev            ! Deviation in solute balance (M/L2) for intermediate period
   real(8)                    :: sdstor             ! Change in solute storage (M/L2) for intermediate period

!  solute: used in outbal, outcsv
   real(8)   sampro             ! Total amount of solutes (M/L2) in soil column

!  solute+agetracer: used in outbal, outcsv
   real(8)   rottot             ! Cumulative amount of solutes (M/L2) extracted by plant roots
   real(8)   sqdra              ! Total amount of solutes (M/L2) transported to drainage canals

!  solute: used in outvap, outcsv
   real(8), dimension(macp), save :: cmsy         ! Array with dissolved + adsorbed solute concentration (M/L3 soil volume) in mobile region

!  solute: used in outvap
   real(8)   isqbot             ! Solute flux at the bottom of the soil column (M/L2/T)

!  solute: used in outbal
   real(8)   dectot             ! Cumulative amount of solute decomposition (M/L2)
   real(8)   sqprec             ! Cumulative amount of solutes (M/L2) in precipitation
   real(8)   sqirrig            ! Cumulative amount of solutes (M/L2) in irrigation water
   real(8)   sqbot              ! Cumulative amount of solutes (M/L2) passed through the soil column bottom

!  solute+agetracer: used in outbal
   real(8)   samini             ! Total amount of solutes (M/L2) in soil profile at start of current balance period

!  solute+agetracer: used in outvap
   real(8)   isqtop             ! Solute flux through the soil top surface (M/L2/T)

   private
   public :: solute
   public :: solute_CDE, calc_AgeTracer, hybrid_age_observe, hybrid_age_checkpoint
   public :: swdc
   public :: cml, ageml
   public :: isqtop, isqbot, cmsy, samini, sampro, sqprec, sqirrig, sqbot, dectot, rottot, sqdra
   public :: imsqbot, imsqdra, imsqirrig, imsqprec, imdectot, imrottot, imqsol
   public :: sbaldev, sdstor

   contains

   subroutine solute(task)

   implicit none
   integer, intent(in) :: task

   select case (Task)
   case (1)
      if (swsolu == 1) call solute_CDE(task)
      if (swsolu == 2) call calc_AgeTracer(task)
   case (2)
      if (swsolu == 1) call solute_CDE(task)
      if (swsolu == 2) call calc_AgeTracer(task)
   case (3)
      if (swsolu == 1) call solute_CDE(task)
      if (swsolu == 2) call calc_AgeTracer(task)
   case (9)
      if (swsolu == 1) call solute_CDE(task)
      if (swsolu == 2) call calc_AgeTracer(task)
   case default
      call swap_error('Solute', 'Illegal Task option')
   end select
   end subroutine solute

end module MOD_Solute

submodule (MOD_Solute) MOD_Solute_CDE

      use MOD_swap_base, only: swcrop, swsolu, swscre, swsnow
      use MOD_grid,      only: numnod, numlay

      implicit none

! --- solute variables
      integer                            :: nconc              ! Number of initial solute concentrations as provided in the input (times 2; incl. index)
      integer                            :: ncseep             ! total length of cseeptab
      integer                            :: sba                ! Internal number of output file *.SBA with cumulative solute balance components
      integer                            :: swbotbc            ! Switch for bottom boundary condition of solute-concentration (see *.SWP input file for overview)
      integer                            :: swbr               ! Switch to consider mixed reservoir for solute breakthrough in the saturated zone: 0 = no; 1 = yes
      integer                            :: swsba              ! Switch for output file with daily solute balance *.SBA: 0 = no; 1 = yes; 1 = yes
      integer                            :: swsp               ! Switch (in case of solute transport) for simulation of sorption  0 = no; 1 = yes

      real(8)                            :: bexp               ! Exponent in decomposition reduction factor due to dryness (-)
      real(8)                            :: cdrain             ! Mean solute concentration in aquifer or drainage system (M/L3 water)
      real(8)                            :: cpond              ! Mean solute concentration (M/L3) in ponding layer on soil surface
      real(8)                            :: cpre               ! Solute concentration (M/L3) in precipitation
      real(8)                            :: cref               ! Reference solute concentration (M/L3) for Freundlich adsorption
      real(8)                            :: cseep              ! Mean solute concentration in upward seepage water at bottom of profile (M/L3 water)
      real(8)                            :: csurf              ! Total amount of solutes (M/L2) in ponding layer on soil surface
      real(8)                            :: daquif             ! Thickness of saturated aquifer (L) to calculate solute breakthrough to surface water
      real(8)                            :: ddif               ! Molecular diffusion coefficient (L2/T)
      real(8)                            :: decsat             ! Decomposition rate in aquifer (/T)
      real(8)                            :: dtsolu             ! Maximum time step (T) for accurate numerical solution of solute transport equation
      real(8)                            :: frexp              ! Array with Freundlich exponent (-) for solute adsorption
      real(8)                            :: gampar             ! Reduction factor for decomposition due to low temperatures (/C)
      real(8)                            :: kfsat              ! Linear adsorption coefficient in aquifer (L3/M)
      real(8)                            :: poros              ! Porosity of aquifer (-) to calculate solute breakthrough
      real(8)                            :: rtheta             ! Minimum volumetric water content (-) for potential decomposition
      real(8)                            :: sqsur              ! Cumulative amount of solutes (M/L2) transported to surface water
      real(8)                            :: tscf               ! Relative uptake of solutes by roots (-)
      real(8)                            :: solerr             ! Deviation in solute storage (M/L2) for cumulative period
      
      real(8), dimension(:), allocatable :: cseeptab           ! Array with Mean solute concentration in upward seepage water at bottom of profile (M/L3 water) as function of time (T)
      real(8), dimension(:), allocatable :: decpot             ! Array with Potential decomposition rate (/T) for each soil layer
      real(8), dimension(:), allocatable :: fdepth             ! Array with reduction factor for decomposition (-) for each soil layer
      real(8), dimension(:), allocatable :: kf                 ! Array with Freundlich coefficient (L3/M) for solute adsorption for each soil layer
      real(8), dimension(:), allocatable :: ldis               ! Array with Solute dispersion length (L) for each soil layer
      real(8), dimension(:), allocatable :: cmltb              ! Array with initial solute concentrations as function of soil depth
      
!save
   contains
! ----------------------------------------------------------------------
      module subroutine solute_CDE(task)
! ----------------------------------------------------------------------
!     date               : december 2007; code update: June, 2019
!     purpose            : calculation of solute concentrations
! ----------------------------------------------------------------------
      use MOD_swap_base,       only: swinco, swhea
      use MOD_texture_orgmat,  only: bdens
      use MOD_grid,            only: z, dz, layer, numnod, inpola, inpolb, disnod
      use MOD_meteo,           only: nraidt
      use MOD_drain,           only: nrlevs, qdra, qdrtot
      use MOD_swap_mp,         only: armpss
      use MOD_irrigation,      only: nird, cirr
      use variables,           only: thetsl, theta
      use variables,           only: t1900, dt
      use variables,           only: flzerointr, flzerocumu, q, dtmin, qtop, pond, qrot, qbot
      use MOD_SoilTemperature, only: tsoil

      implicit none

      integer, intent(in)                 :: task

!    local variables
      integer                             :: level,i,ipos
      real(8)                             :: cmlav,ftemp,ftheta,decact,cfluxt,cfluxb
      real(8)                             :: cdrtot,ctrans,crot,dispr,old,dummy,vpore
      real(8)                             :: isqdra,afgen
      !real(8), dimension(:), allocatable  :: tab
      real(8)                             :: tcumsol, rounderr
      real(8)                             :: sampro0
      logical                             :: differ
!     somelocal constants (to save)
      real(8), dimension(:), allocatable  :: thetav, diffus, dispr1, vpore2, ddiffwcs, bdenskf, bdenskfcref, bdenskfsatporos, decpotfdepth

      real(8), parameter                  :: rer    = 1.d-3
      real(8), parameter                  :: vsmall = 1.d-15
save
! ----------------------------------------------------------------------

      select case (task)
      case (1)

! ===    initialize Solute rate/state variables ===========================
         if (allocated(decpot))          deallocate(decpot);          allocate(decpot(numlay))
         if (allocated(fdepth))          deallocate(fdepth);          allocate(fdepth(numlay))
         if (allocated(kf))              deallocate(kf);              allocate(kf(numlay))
         if (allocated(ldis))            deallocate(ldis);            allocate(ldis(numlay))
         if (allocated(thetav))          deallocate(thetav);          allocate(thetav(numnod))
         if (allocated(diffus))          deallocate(diffus);          allocate(diffus(numnod))
         if (allocated(dispr1))          deallocate(dispr1);          allocate(dispr1(numnod))
         if (allocated(vpore2))          deallocate(vpore2);          allocate(vpore2(numnod))
         if (allocated(ddiffwcs))        deallocate(ddiffwcs);        allocate(ddiffwcs(numnod))
         if (allocated(bdenskf))         deallocate(bdenskf);         allocate(bdenskf(numnod))
         if (allocated(bdenskfcref))     deallocate(bdenskfcref);     allocate(bdenskfcref(numnod))
         if (allocated(bdenskfsatporos)) deallocate(bdenskfsatporos); allocate(bdenskfsatporos(numnod))
         if (allocated(decpotfdepth))    deallocate(decpotfdepth);    allocate(decpotfdepth(numnod))

         swbotbc            = 0
         nconc              = 0
         swsba              = 0
         sba                = 0
         swbr               = 0
         bexp               = 0.0d0
         cdrain             = 0.0d0
         !cml                = 0.0d0
         cmsy               = 0.0d0
         cpond              = 0.0d0
         cpre               = 0.0d0
         cref               = 0.0d0
         cseep              = 0.0d0
         csurf              = 0.0d0
         daquif             = 0.0d0
         ddif               = 0.0d0
         decpot             = 0.0d0
         decsat             = 0.0d0
         dectot             = 0.0d0
         imdectot           = 0.0d0
         dtsolu             = 0.0d0
         fdepth             = 0.0d0
         frexp              = 0.0d0
         gampar             = 0.0d0
         isqbot             = 0.0d0
         isqtop             = 0.0d0
         kf                 = 0.0d0
         kfsat              = 0.0d0
         ldis               = 0.0d0
         poros              = 0.0d0
         rottot             = 0.0d0
         imrottot           = 0.0d0
         rtheta             = 0.0d0
         samini             = 0.0d0
         sampro             = 0.0d0
         sampro0            = 0.0d0
         solerr             = 0.0d0
         sbaldev            = 0.0d0
         sdstor             = 0.0d0
         sqbot              = 0.0d0
         imsqbot            = 0.0d0
         sqdra              = 0.0d0
         imsqdra            = 0.0d0
         sqirrig            = 0.0d0
         imsqirrig          = 0.0d0
         sqprec             = 0.0d0
         imsqprec           = 0.0d0
         imqsol             = 0.0d0
         sqsur              = 0.0d0
         tscf               = 0.0d0
         rounderr           = 0.0d0

         ! general check (warning)
         if (maxval(dz(1:numnod)) > 5.0d0) call swap_warning('solute', 'large dz (e.g. dz > 5) is not advised')

         ! read input file
         call read_solute_CDE()

! ---    determine initial solute profile from input concentrations
         if (swinco /= 3) then
            cml = 0.d0; ipos = 0
            do i = 1, numnod
               call afgen_2(cmltb, nconc, dabs(z(i)), cml(i), ipos)
            end do
            if (allocated(cmltb)) deallocate(cmltb)
         end if

! ---    determine derived solute concentrations

         samini = 0.0d0
!         samaq = 0.0d0
         do i = 1, numnod
            bdenskf(i)         = bdens(layer(i))*kf(layer(i))
            bdenskfcref(i)     = bdenskf(i)*cref
            bdenskfsatporos(i) = bdens(layer(i))*kfsat + poros
            cmsy(i)            = (theta(i)*cml(i) + bdenskfcref(i)*(cml(i)/cref)**frexp)
            samini             = samini + cmsy(i) * dz(i)
            ddiffwcs(i)        = ddif / (thetsl(layer(i))**2)
            decpotfdepth(i)    = decpot(layer(i))*fdepth(layer(i))
         end do
         sampro  = samini
         sampro0 = samini

         ! output
         if (swsba == 1) call outsba (1)

      case (2)

! ===    calculate Solute rate variables ========================

! ---    reset cumulative solute fluxes
         if (flzerointr) then
           imsqprec  = 0.0d0
           imsqirrig = 0.0d0
           imsqbot   = 0.0d0
           imsqdra   = 0.0d0
           imdectot  = 0.0d0
           imrottot  = 0.0d0
           imqsol    = 0.0d0
           sampro0   = sampro
           rounderr  = 0.0d0
         end if
         if (flzerocumu) then
           sqprec  = 0.0d0
           sqirrig = 0.0d0
           sqbot   = 0.0d0
           sqdra   = 0.0d0
           sqsur   = 0.0d0
           dectot  = 0.0d0
           rottot  = 0.0d0
           csurf   = 0.0d0
           samini  = sampro
         end if

         isqbot = 0.0d0
         isqtop = 0.0d0
         isqdra = 0.0d0

! ---    boundary concentrations
         if (swbotbc == 2) then
           cseep = afgen (cseeptab,ncseep,t1900+dt)
         end if

! ---    determine maximum timestep
         dtsolu = dt
         do i = 1, numnod
           thetav(i) = inpola(i+1)*theta(i)+inpolb(i)*theta(i+1)
           diffus(i) = ddiffwcs(i) * thetav(i)**2.33d0
           if (i < numnod) then
               vpore     = abs(q(i+1))/thetav(i)
               dispr1(i) = diffus(i) + ldis(layer(i)) * vpore
               vpore2(i) = vpore*vpore
            end if

           dispr = diffus(i)+ldis(layer(i))*abs(q(i))/theta(i)
           if (dispr < 1.0d-8) dispr = 1.0d-8
           !dummy = dz(i)*dz(i)*theta(i)/(2.0d0*dispr)
           dummy = dz(i)*dz(i)/(2.0d0*dispr)
           !dummy = 1.2d0*dz(i)*dz(i)/(2.0d0*dispr)
           dtsolu = min(dtsolu,dummy)
         end do

         tcumsol = 0.0d0
         do while ((dt-tcumsol) > 1.0d-15)
! ---       time step and cumulative time
            dtsolu  = min(dtsolu,(dt-tcumsol))
            dtsolu  = max(dtsolu,dtmin)
            tcumsol = tcumsol + dtsolu

! ---       solute flux at soil surface
            csurf = (nird*cirr + nraidt*cpre)*dtsolu + csurf   ! mg cm-2
            if (qtop < -1.d-6) then
               cpond  = csurf / (pond-qtop*dtsolu)             ! mg cm-3
               cfluxt = qtop*(1.0d0-ArMpSs)*cpond*dtsolu       ! mg cm-2
               csurf  = csurf + cfluxt                         ! mg cm-2
               isqtop = qtop*(1.0d0-ArMpSs)*cpond              ! mg cm-2 d-1
            else
               cpond  = 0.0d0
               cfluxt = 0.0d0
            end if
            
            imqsol(1) = imqsol(1) + cfluxt

! ---       calculate mass balance for each compartment

            do i = 1, numnod

! ---          convective and dispersive fluxes
               if (i < numnod) then
                  cmlav = inpola(i+1) * cml(i) + inpolb(i) * cml(i+1)
                  !thetav = inpola(i+1)*theta(i)+inpolb(i)*theta(i+1)
                  !vpore = abs(q(i+1))/thetav
                  !diffus = ddif*(thetav**2.33d0)/(thetsl(layer(i))**2)
                  !dispr = diffus + ldis(layer(i)) * vpore + 0.5d0 * dtsolu*vpore*vpore
                  dispr = dispr1(i) + 0.5d0 * dtsolu*vpore2(i)
                  cfluxb = (q(i+1)*cmlav + thetav(i) * dispr * (cml(i+1)-cml(i))/disnod(i+1))*dtsolu
               else
                  if (q(i+1) > 0.0d0) then
                     cfluxb = q(i+1)*cseep*dtsolu
                  else
                     cfluxb = q(i+1)*cml(i)*dtsolu
                  end if
               end if
               
               if (i > 1) imqsol(i) = imqsol(i) + cfluxb

! ---          solute decomposition
               if (swhea > 0) then
                  if (tsoil(i) < 35.0d0) then
                     ftemp = exp(gampar*(tsoil(i)-20.0d0))
                  else
                     ftemp = exp(gampar*15.0d0)
                  end if
               else
                 ftemp = 0.0d0
               end if
               ftheta = min(1.0d0,(theta(i)/rtheta)**bexp)
               decact = decpotfdepth(i) * ftemp * ftheta
               ctrans = decact*theta(i)*cml(i) + decact*bdenskfcref(i)*((cml(i)/cref)**frexp)
               dectot = dectot + ctrans*dtsolu*dz(i)
               imdectot = imdectot + ctrans*dtsolu*dz(i)

! ---          solute uptake by plant roots
               crot   = tscf*qrot(i)*cml(i)/dz(i)
               rottot = rottot + tscf*qrot(i)*cml(i)*dtsolu
               imrottot = imrottot + tscf*qrot(i)*cml(i)*dtsolu

! ---          lateral drainage
               cdrtot = 0.0d0
               do level = 1, nrlevs
                  if (qdra(level,i) > 0.0d0) then
                     cdrtot = cdrtot+qdra(level,i)*cml(i)/dz(i)
                  else
                     cdrtot = cdrtot+qdra(level,i)*cdrain/dz(i)
                  end if
               end do

! ---          cumulative amount of solutes to lateral drainage
               isqdra = isqdra + cdrtot*dz(i)*dtsolu
               sqdra  = sqdra + cdrtot*dz(i)*dtsolu
               imsqdra  = imsqdra + cdrtot*dz(i)*dtsolu

! ---          conservation equation for the substance
               cmsy(i) = cmsy(i) + (cfluxb-cfluxt) / dz(i) + (-ctrans-crot-cdrtot) * dtsolu

               ! since bottom boundary condition is treated explicitly we MUST calculate sqbot here (before CML is recalculated)
               ! this prevents errors in sbaldev
               if (i == numnod) then
                  ! --- flux through bottom of soil profile
                  if (qbot > 0.0d0) then
                     sqbot = sqbot + qbot*cseep*dtsolu
                     imsqbot = imsqbot + qbot*cseep*dtsolu
                  else
                     sqbot = sqbot + qbot*cml(numnod)*dtsolu
                     imsqbot = imsqbot + qbot*cml(numnod)*dtsolu
                  end if
               end if

! ---          iteration procedure for calculation of cml
               differ = .TRUE.
               if (cmsy(i) < vsmall) then
                  rounderr = rounderr + cmsy(i) * dz(i)
                  cmsy(i) = 0.0d0
                  cml(i)  = 0.0d0
               else
                  if (abs(frexp-1.0d0) < 0.001d0) then
                     cml(i) = cmsy(i) / (theta(i) + bdenskf(i))
                  else
                     if (cml(i) < vsmall) cml(i) = vsmall
                     do while (differ)
                        old    = cml(i)
                        dummy  = bdenskf(i)*(cml(i)/cref)**(frexp-1.0d0)
                        cml(i) = cmsy(i)/(theta(i)+dummy)
                        if (abs(cml(i)-old) < rer*cml(i)) differ = .FALSE.
                     end do
                  end if
               end if

!              make top flux next compartment equal to current bottom flux
               cfluxt = cfluxb

! ---       next compartment
            end do

! ---       solute balance in aquifer for breakthrough curve
!MH:L shouldn't this be inside the do loop ???
            if (swbr == 1) then
               if (qdrtot > 0.0d0) then
                  cdrain = cdrain + dtsolu/bdenskfsatporos(i) * ( (isqdra - qdrtot*cdrain)/daquif - decsat*cdrain*bdenskfsatporos(i) )
               else
                  cdrain = cdrain + dtsolu/bdenskfsatporos(i) * ( isqdra/daquif - decsat*cdrain*bdenskfsatporos(i) )
               end if
               cseep = cdrain
            end if

! ---       flux to surface water from aquifer
            if (swbr == 1) then
               sqsur = sqsur + qdrtot*cdrain*dtsolu
            end if

! ---    continue with next solute time step
         end do

! ---    current solute flux at bottom of soil column
         if (q(numnod+1) > 0.0d0) then
           isqbot = q(numnod+1) * cseep
         else
           isqbot = q(numnod+1) * cml(numnod)
         end if

! ===    calculate solute balance components ========================

! ---    total amount in soil profile
         sampro = 0.0d0
         do i = 1, numnod
           sampro = sampro + cmsy(i) * dz(i)
         end do
         sampro = sampro + csurf
!         if (swbr == 1) samaq = cdrain*poros*daquif

! ---    add time step fluxes to total cumulative values
         sqprec    = sqprec + nraidt * cpre * dt
         imsqprec  = imsqprec + nraidt * cpre * dt
         sqirrig   = sqirrig + nird * cirr * dt
         imsqirrig = imsqirrig + nird * cirr * dt

! ---    (cumulative) solute balance
         sdstor  = sampro - sampro0
         sbaldev = sdstor - imsqprec - imsqirrig - imsqbot + imsqdra + imdectot + imrottot ! + rounderr
         solerr  = sampro - samini - sqprec - sqirrig - sqbot + sqdra + dectot + rottot ! + rounderr

!     output
      case(3)

         if (swsba == 1) call outsba (2)

!     close output
      case(9)

         if (swsba == 1) call outsba (3)

      case default
         call swap_error ('Solute', 'Illegal value for TASK')
      end select

      return
      end subroutine solute_CDE

      subroutine read_solute_CDE

      use MOD_swap_base, only: unit_swp, swpfilnam, unit_err, fl_initialize, swcrop
!      use MOD_texture_orgmat, only: bdens
      use MOD_grid,      only: numlay

      implicit none

      integer :: i, lay
      real(8), dimension(:), allocatable :: z_ini, s_ini
      real(8), dimension(:), allocatable :: dates, cseeparr
      character(len=200) :: message
      
      ! functions
      logical                             :: rdinqr, rdinar

! =================================================================
!     Section solute transport
      call rdinit(unit_swp, unit_err, swpfilnam)

      if (swsolu == 1) then

!        if (.NOT. allocated(bdens)) call swap_error ('read_solute_CDE', 'BDENS not allocated')

! ---   top boundary and initial condition
        call rdsdor ('cpre',  0.0d0,100.0d0,cpre)
        call rdsdor ('cdrain',0.0d0,100.0d0,cdrain)

!       bottom condition with 3 options:
!       SWBOTBC = 0: lateral (cdrain as input), bottom set to lateral (cseep=cdrain)
!       SWBOTBC = 1: separate input of bottom conc as cseep
!       SWBOTBC = 2: separate input of dynamic bottom conc as (datec,cseeparr)
        swbotbc = 0
        if (rdinqr('swbotbc')) then
          call rdsinr ('swbotbc',0,2,swbotbc)
        end if
        if (swbotbc == 0) then
          cseep = cdrain
        else if (swbotbc == 1) then
          call rdsdor ('cseep',0.0d0,100.0d0,cseep)
        else if (swbotbc == 2) then
          if (.NOT. rdinqr('datec')) call swap_error ('read_solute_CDE', 'Variable DATEC not present in file '//trim(swpfilnam))
          call rdinne('datec', ncseep)
          allocate(dates(ncseep))
          allocate(cseeparr(ncseep))
          if (allocated(cseeptab)) deallocate(cseeptab); allocate(cseeptab(2*ncseep))
          call rdftim ('datec',dates,ncseep,ncseep)
          call rdfdor ('cseeparr',0.0d0,100.0d0,cseeparr,ncseep,ncseep)
          do i = 1, ncseep
            cseeptab(i*2)   = cseeparr(i)
            cseeptab(i*2-1) = dates(i)
          end do
          ncseep = ncseep * 2 ! save total length of cseeptab
          deallocate(dates)
          deallocate(cseeparr)
        end if

        if (.NOT. fl_initialize) then
          
           ! old procedure (deprecated)
           if (rdinqr('cml')) then
             
              message = 'Usage of ZC and CML are deprecated, use CMLTB instead'
              call swap_warning('read_solute_CDE', message)
            
              call rdinne ('cml',nconc)
              allocate(z_ini(nconc)); allocate(s_ini(nconc))
              if (allocated(cmltb)) deallocate(cmltb); allocate(cmltb(nconc*2)); cmltb = 0.d0
           
              call rdfdor ('zc',-1.0d5,0.0d0,z_ini,nconc,nconc)
              call rdfdor ('cml',0.0d0,1.0d3,s_ini,nconc,nconc)
           
              do i = 1, nconc
                 cmltb(i*2) = s_ini(i)
                 cmltb(i*2-1) = dabs(z_ini(i))
              end do
              nconc = nconc*2
             
              deallocate(z_ini, s_ini)
           
           ! new procedure
           else
              
              if (.NOT. rdinqr('cmltb')) call swap_error ('read_solute_CDE', 'Variable CMLTB not present in file '//trim(swpfilnam))
              call rdinne ('cmltb',nconc)
              if (allocated(cmltb)) deallocate(cmltb); allocate(cmltb(nconc)); cmltb = 0.d0
              call rdadortb('cmltb', -1.0d5, 0.0d0, 0.0d0, 1.0d3, cmltb, nconc, .TRUE.)
           
           end if
          
        end if

! ---   diffusion, dispersion and solute uptake by roots
        call rdsdor ('ddif',0.0d0,10.0d0,ddif)
        if (rdinar('ldis')) then
          call rdfdor ('ldis',0.0d0,100.d0,ldis,numlay,numlay)
        else
          call rdsdor ('ldis',0.0d0,100.d0,ldis(1)); if (numlay > 1) ldis(2:numlay) = ldis(1)
        end if
        tscf = 0.d0
        if (swcrop == 1) call rdsdor ('tscf',0.0d0,10.0d0,tscf)

! ---   sorption
        call rdsinr ('swsp',0,1,swsp)
        if (swsp == 1) then

          call rdsdor ('frexp',0.0d0,   10.0d0,frexp)
          call rdsdor ('cref', 0.0d0, 1000.0d0,cref)
          if (rdinar('kf')) then
            call rdfdor ('kf',0.0d0,10000.0d0,kf,numlay,numlay)
          else
            call rdsdor ('kf',0.0d0,10000.0d0,kf(1)); if (numlay > 1) kf(2:numlay) = kf(1)
          end if
        else
          cref  = 1.0d0
          frexp = 1.0d0
          do lay = 1, numlay
            kf(lay) = 0.0d0
          end do
        end if

! ---   decomposition
        call rdsinr ('swdc',0,1,swdc)
        if (swdc == 1) then
          if (rdinar('decpot')) then
            call rdfdor ('decpot',0.0d0,10.0d0,decpot,numlay,numlay)
          else
            call rdsdor ('decpot',0.0d0,10.0d0,decpot(1)); if (numlay > 1) decpot(2:numlay) = decpot(1)
          end if
          call rdsdor ('gampar',0.0d0,0.5d0,gampar)
          call rdsdor ('rtheta',0.0d0,0.4d0,rtheta)
          call rdsdor ('bexp',0.0d0,2.0d0,bexp)
          if (rdinar('fdepth')) then
            call rdfdor ('fdepth',0.0d0,1.0d0,fdepth,numlay,numlay)
          else
            call rdsdor ('fdepth',0.0d0,1.0d0,fdepth(1)); if (numlay > 1) fdepth(2:numlay) = fdepth(1)
          end if
        else
          gampar = 0.0d0
          rtheta = 0.5d0
          bexp   = 0.0d0
          do lay = 1, numlay
            decpot(lay) = 0.0d0
            fdepth(lay) = 0.0d0
          end do
        end if

! ---   breakthrough
        call rdsinr ('swbr',0,1,swbr)
        if (swbr == 0) then
          daquif = 100.0d0
          poros  = 1.0d0
          kfsat  = 0.0d0
          decsat = 0.0d0
        else
          call rdsdor ('daquif',0.0d0,10000.0d0,daquif)
          call rdsdor ('poros',0.0d0,0.6d0,poros)
          call rdsdor ('kfsat',0.0d0,100.0d0,kfsat)
          call rdsdor ('decsat',0.0d0,10.0d0,decsat)
          call rdsdor ('cdraini',0.0d0,100.0d0,cdrain)
          cseep = cdrain
        end if

        if (rdinqr('swsba')) then
           call rdsinr ('swsba',0,1,swsba)
        end if

      end if

      close(unit_swp)

      end subroutine read_solute_CDE

! ----------------------------------------------------------------------
      subroutine outsba (task)
! ----------------------------------------------------------------------
!     date               : July 2002
!     purpose            : output of salt balance
! ---------------------------------------------------------------------
      use MOD_swap_base, only: iun_min, iun_max, project, pathwork
      use variables,     only: daynr,daycum,date,outfil,flheader
      implicit none

! --- global
      integer, intent(in) :: task

! --- local variables ------------------
      integer   getun
      character(len=300) filnam
      character(len=80)  filtext
      character(len=1)   comma
! ----------------------------------------------------------------------
      comma = ','


      select case (task)
      case (1)

! ---    open output file -------------------------------------------------
         filnam = trim(pathwork)//trim(outfil)//'.sba'
         sba = getun (iun_min, iun_max)
         call fopens(sba,filnam,'new','del')
         filtext = 'cumulative solute balance components (mg/cm2)'
         call writehead (sba,1,filnam,filtext,project)

! ---    write header in sba file
         write (sba,10)
10       format ('*',/,                                                    &
         '       Date, Day,  Dcum,      Flux top,   Root uptake, ',        &
         'Decomposition,      Drainage,   Flux bottom,       Storage,',    &
         '       Balance')

         return

      case (2)

! === write actual data =================================================

! --- write header in case of new balance period
         if (flheader) write (sba,10)

! --- write output solute balance components ----------------------------

         write(sba,15) date,comma,daynr,comma,daycum,comma,(sqprec+sqirrig),comma,rottot,comma,dectot,comma,sqdra,comma,sqbot,comma,sampro,comma,solerr

 15      format(a11,a1,i4,a1,i6,1p,6(a1,e14.5),a1,e14.2)

!     close sba file
      case(3)

         if (swsba == 1) close (sba)

      case default
         call swap_error ('outsba', 'Illegal value for Task')
      end select

      return
      end subroutine outsba

end submodule MOD_Solute_CDE

submodule (MOD_Solute) MOD_calc_AgeTracer
      use MOD_swap_base, only: swsolu
      use MOD_grid, only: dz
      use mod_solute_compartment_state,only:solute_compartment_state_t
      use mod_b111_age_tracer_substep,only:b111_age_tracer_substep_forcing_t, &
         b111_age_tracer_substep_receipt_t,advance_b111_age_tracer_substep,B111_AGE_SUBSTEP_OK
      use mod_b111_surface_age_budget,only:surface_age_request_t,surface_age_receipt_t, &
         advance_surface_age_budget,SURFACE_AGE_OK

      implicit none
! --- solute variables
      integer                                  :: nconc              ! Number of initial solute concentrations as provided in the input

      real(8)                                  :: cdrain             ! Mean solute concentration in aquifer or drainage system (M/L3 water)
      real(8)                                  :: cpre               ! Solute concentration (M/L3) in precipitation
      real(8)                                  :: cseep              ! Mean solute concentration in upward seepage water at bottom of profile (M/L3 water)
      real(8)                                  :: ddif               ! Molecular diffusion coefficient (L2/T)
      real(8)                                  :: dtsolu             ! Maximum time step (T) for accurate numerical solution of solute transport equation
      real(8)                                  :: tscf               ! Relative uptake of solutes by roots (-)
      real(8)                                  :: AgeGwl1m           ! Age (d) of groundwater in upper 1 meter of saturated zone
      real(8)                                  :: icAgeBot           ! Incremental (over output interval) age (d) of groundwater leaving bottom comp.
      real(8)                                  :: icAgeRot           ! Incremental (over output interval) age (d) of groundwater leaving by root uptake
      real(8)                                  :: icAgeSur           ! Incremental (over output interval) age (d) of groundwater leaving by surface runoff

      real(8), dimension(:), allocatable, save :: icAgeDra           ! Incremental (over output interval) age (d) of groundwater leaving bottom comp.
      real(8), dimension(:), allocatable, save :: ldis               ! Array with Solute dispersion length (L) for each soil layer
      real(8), dimension(:), allocatable, save :: agemltb            ! Array with initial age mass solute concentrations as function of soil depth

      real(8),allocatable,save::Agemsy(:)
      real(8),save::Ageirr=0d0,Agedrain=0d0,Agepre=0d0,Agepond=0d0,Agepondm1=0d0
      real(8),save::icAgeTopupw=0d0,icAgeTopdwn=0d0
      real(8),save::age_pond_stock=0d0,age_cumulative(8)=0d0
   contains
      module subroutine calc_AgeTracer(task)
! ----------------------------------------------------------------------
!     date               : Oct 2010
!     purpose            : Ageing according to Goode (1996):
!                        : "Direct simulation of groundwater age, WRR vol.32, p 289-296"
! ----------------------------------------------------------------------

      use MOD_swap_base, only: swinco
      use MOD_grid,      only: numnod, z, dz, disnod, zbotcp, ztopcp, numlay, inpola, inpolb, layer
      use MOD_meteo,     only: nraidt
      use MOD_drain,     only: nrlevs, qdra
      use MOD_swap_mp,   only: armpss
      use MOD_irrigation,only: nird, cirr
      use variables,     only: dt,runon,epd,reva
      use variables,     only: theta, thetsl, thetas
      use variables,     only: flzerocumu, q, dtmin, pondm1, qtop, pond, runots, qrot, thetm1, nodgwl, gwl
      implicit none

!     global
      integer, intent(in) :: task

!    local variables
      integer                                  :: level,i,ipos
      real(8)                                  :: Agemlav,thetav,Agefluxt,Agefluxb
      real(8)                                  :: Agedrtot,Agerot,dispr,diffus,dummy
      real(8)                                  :: vpore,isqdra
      real(8)                                  :: tcumsol
!
!      real(8)                                  :: Ageevp
      real(8)                                  :: Agesurf
      real(8)                                  :: AgeProd
      real(8)                                  :: sum0,sum1,deltaz,zzbot,zztop


      type(solute_compartment_state_t)::age_before,age_candidate
      type(b111_age_tracer_substep_forcing_t)::age_forcing
      type(b111_age_tracer_substep_receipt_t)::age_receipt
      type(surface_age_request_t)::age_surface
      type(surface_age_receipt_t)::age_surface_receipt
      real(8)::age_water_midpoint(numnod)
      logical::age_first_microstep

! ----------------------------------------------------------------------

      select case (task)
      case (1)

! ===    initialize Solute rate/state variables ===========================
         if (allocated(ldis))     deallocate(ldis);     allocate(ldis(numlay))
         !if (allocated(Ageml))    deallocate(Ageml);    allocate(Ageml(numnod))
         if (allocated(Agemsy))   deallocate(Agemsy);   allocate(Agemsy(numnod))
         if (allocated(icAgeDra)) deallocate(icAgeDra); allocate(icAgeDra(nrlevs))

         cml      = 0.0d0
         icAgeBot = 0.0d0
         icAgeDra = 0.0d0
         icAgeRot = 0.0d0
         icAgeSur = 0.0d0
         Agegwl1m = 0.0d0
         nconc    = 0
         cdrain   = 0.0d0
         cpre     = 0.0d0
         cseep    = 0.0d0
         ddif     = 0.0d0
         dtsolu   = 0.0d0
         tscf     = 0.0d0
         rottot   = 0.0d0

         ! read input file
         call read_AgeTracer()

         ! initialize for output
         call outage(1)

! ---    determine initial solute profile from input concentrations
         if (swinco /= 3) then
            ageml = 0.d0; ipos = 0
            do i = 1, numnod
               call afgen_2(agemltb, nconc, dabs(z(i)), ageml(i), ipos)
            end do
            if (allocated(agemltb)) deallocate(agemltb)
         end if

! ---    boundary conditions (ALL SET TO 0 ON INPUT)
         Agepre    = cpre
         Ageirr    = cirr
         Agedrain  = cdrain
         Agepond   = cpre
         Agepondm1 = Agepond
         age_pond_stock=Agepond*pondm1
         age_cumulative=0d0

! ---    determine derived solute concentrations
         samini = 0.0d0
         do i = 1, numnod
            Agemsy(i) = theta(i)*Ageml(i)
            samini    = samini + Agemsy(i) * dz(i)
         end do

      case (2)

! === calculate Solute rate variables ========================

! ---    reset cumulative solute fluxes
         if (flzerocumu) then
           icAgesur    = 0.0d0
           icAgetopdwn = 0.0d0
           icAgetopupw = 0.0d0
           icAgerot    = 0.0d0
           do level = 1, nrlevs
              icAgedra(level) = 0.0d0
           end do
           icAgebot = 0.0d0
         end if

         isqtop = 0.0d0
         isqdra = 0.0d0

! ---    determine maximum timestep
         dtsolu = dt
         do i = 1, numnod
           thetav = inpola(i+1)*theta(i)+inpolb(i)*theta(i+1)
           diffus = ddif * (thetav**2.33d0)/(thetsl(layer(i))**2)
           dispr  = diffus+ldis(layer(i))*abs(q(i))/theta(i)
           if (dispr < 1.0d-8) dispr = 1.0d-8
           dummy  = dz(i)*dz(i)*theta(i)/2.0d0/dispr
           dtsolu = min(dtsolu,dummy)
         end do

         age_surface=surface_age_request_t()
         age_surface%dt_day=dt
         age_surface%pond_start_cm=pondm1
         age_surface%pond_end_cm=pond
         age_surface%pond_age_stock_cm_day=age_pond_stock
         age_surface%rain_depth_cm=nraidt*dt
         age_surface%irrigation_depth_cm=nird*dt
         age_surface%runon_depth_cm=runon*dt
         age_surface%rain_age_day=Agepre
         age_surface%irrigation_age_day=Ageirr
         age_surface%soil_return_depth_cm=max(qtop,0d0)*dt
         age_surface%soil_return_age_day=0d0 ! explicit original retained-age evaporation policy
         age_surface%infiltration_depth_cm=max(-qtop,0d0)*dt
         age_surface%runoff_depth_cm=runots
         age_surface%evaporation_depth_cm=(epd+reva)*dt
         call advance_surface_age_budget(age_surface,age_surface_receipt)
         if(age_surface_receipt%status/=SURFACE_AGE_OK)then
            write(*,*)'AGE_SURFACE_REFUSED',pondm1,pond,nraidt*dt,nird*dt,runon*dt,qtop*dt,runots,epd*dt,reva*dt
            error stop 'Original host surface age budget rejected'
         end if
         age_pond_stock=age_surface_receipt%pond_end_stock_cm_day
         Agepond=age_surface_receipt%mixed_age_day
         age_cumulative(2)=age_cumulative(2)+age_surface_receipt%age_production_cm_day
         age_cumulative(3)=age_cumulative(3)+age_surface_receipt%external_age_input_cm_day
         age_cumulative(7)=age_cumulative(7)+age_surface_receipt%runoff_age_export_cm_day
         icAgesur=icAgesur+age_surface_receipt%runoff_age_export_cm_day
         icAgetopdwn=icAgetopdwn-age_surface_receipt%infiltration_age_export_cm_day
         age_water_midpoint=.5d0*(theta(1:numnod)+thetm1(1:numnod))
         age_first_microstep=.true.
         tcumsol = 0.0d0
         do while ((dt-tcumsol) > 1.0d-8)

! ---       time step and cumulative time
            dtsolu  = max(dtsolu,dtmin)
            dtsolu  = min(dtsolu,(dt-tcumsol))
            tcumsol = tcumsol + dtsolu

! ---       Real production age provider; no copied age equation.
            age_before%age_amount=Agemsy*dz(1:numnod)
            age_before%sorbed_matrix_mass=0d0*Agemsy
            age_forcing=b111_age_tracer_substep_forcing_t()
            age_forcing%dt_day=dtsolu
            age_forcing%theta=theta(1:numnod)
            age_forcing%theta_previous=theta(1:numnod)
            if(age_first_microstep)age_forcing%theta_previous=thetm1(1:numnod)
            age_forcing%production_theta_mean=age_water_midpoint
            age_forcing%dz_cm=dz(1:numnod)
            age_forcing%q_face_up_cm_day=q(1:numnod+1)
            age_forcing%root_sink_cm_day=qrot(1:numnod)
            age_forcing%qdra_cm_day=qdra(1:nrlevs,1:numnod)
            age_forcing%drain_age_day=Agedrain
            age_forcing%accepted_surface_age_available=.true.
            age_forcing%accepted_surface_age_input_cm_day= &
               age_surface_receipt%infiltration_age_export_cm_day*(dtsolu/dt)
            age_forcing%evaporative_top_retains_age=q(1)>=0d0
            age_forcing%face_left_weight=inpola(2:numnod)
            age_forcing%face_right_weight=inpolb(1:numnod-1)
            age_forcing%face_distance_cm=disnod(2:numnod)
            age_forcing%theta_sat_left=thetsl(layer(1:numnod-1))
            age_forcing%dispersivity_cm=ldis(layer(1:numnod-1))
            age_forcing%molecular_diffusion_cm2_day=ddif
            call advance_b111_age_tracer_substep(age_before,age_forcing,age_candidate,age_receipt)
            if(age_receipt%status/=B111_AGE_SUBSTEP_OK)error stop 'Original host soil age provider rejected'
            Agemsy=age_candidate%age_amount/dz(1:numnod)
            Ageml(1:numnod)=Agemsy/theta(1:numnod)
            age_first_microstep=.false.
            age_cumulative(1)=age_cumulative(1)+age_receipt%production_amount_cm_day
            age_cumulative(4)=age_cumulative(4)+age_receipt%drain_export_cm_day-age_receipt%drain_input_cm_day
            age_cumulative(5)=age_cumulative(5)+age_receipt%bottom_input_cm_day-age_receipt%bottom_export_cm_day
            age_cumulative(6)=age_cumulative(6)+age_receipt%root_export_cm_day
            age_cumulative(8)=age_cumulative(8)+age_receipt%pond_to_soil_cm_day
            rottot=rottot+age_receipt%root_export_cm_day
            sqdra=sqdra+age_receipt%drain_export_cm_day-age_receipt%drain_input_cm_day

!           age of effluent terms
            icAgetopupw = icAgetopupw + max(0.0d0,q(1)) * 0.5d0*(Ageml(1)+cml(1))*dtsolu
            do i = 1, numnod
               icAgerot = icAgerot + qrot(i)*0.5d0*(Ageml(i)+cml(i))*dtsolu
               do level = 1, nrlevs
                  icAgedra(level) = icAgedra(level) + qdra(level,i)*0.5d0*(Ageml(i)+cml(i))*dtsolu
               end do
            end do
            icAgebot = icAgebot - min(q(numnod+1),0.0d0)*0.5d0*(Ageml(numnod)+cml(numnod))*dtsolu

         end do

!        age of variable 1m-plane of groundwater
         i = nodgwl+1
         zzbot=gwl-100d0;zztop=gwl
         if(i<=numnod)then
            zzbot=zbotcp(i);zztop=ztopcp(i)
         end if
         sum0 = 0.0d0
         sum1 = 0.0d0
         do while(i <= numnod)
            if(gwl-100d0>=zzbot)exit
            if (gwl < zztop) zztop = gwl
            if (gwl-100.0d0 > zzbot) zzbot = gwl-100.0d0
            deltaz = zztop - zzbot
            sum1   = sum1 + deltaz * Ageml(i) * thetas(i)
            sum0   = sum0 + deltaz * thetas(i)
            i = i + 1
            if(i>numnod)exit
            zztop = ztopcp(i)
            zzbot = zbotcp(i)
         end do
         Agegwl1m = -9999.9d0
         if (sum0 > 1.0d-12) Agegwl1m = sum1/sum0

! ---    initial values next timestep
         Agepondm1 = Agepond

! ---    Save for output only
         do i = 1, numnod
           cml(i) = Ageml(i)
         end do

      case(3)
         ! output
         call outage(2)

      case(9)
         ! close output
         call outage(3)

      case default
         call swap_error ('AgeTracer', 'Illegal value for TASK')
      end select

      return
      end subroutine calc_AgeTracer

      subroutine read_AgeTracer
      use MOD_swap_base, only: unit_swp, swpfilnam, unit_err, fl_initialize, swsnow
      use MOD_grid,      only: numlay

      implicit none
      character(len=400) :: message

      ! local variables (ttutil)
      logical              :: rdinqr
      logical              :: rdinar

! =================================================================
!     Section Ageing according to Goode (1996):
!      "Direct simulation of groundwater age, WRR vol.32, p 289-296"
      call rdinit(unit_swp, unit_err, swpfilnam)

! ---     top and bottom boundary and initial condition
          cpre = 0.0d0
          cdrain = 0.0d0
          cseep = 0.0d0

          if (.NOT. fl_initialize) then
          
             if (.NOT. rdinqr('agemltb')) call swap_error ('read_AgeTracer', 'Variable AGEMLTB not present in file '//trim(swpfilnam))
             call rdinne ('agemltb',nconc)
             if (allocated(agemltb)) deallocate(agemltb); allocate(agemltb(nconc)); agemltb = 0.d0
             call rdadortb('agemltb', -1.0d5, 0.0d0, 0.0d0, 1.0d3, agemltb, nconc, .TRUE.)
          
          end if

! ---     diffusion, dispersion and uniform solute uptake by roots
          call rdsdor ('ddif',0.0d0,10.0d0,ddif)
          if (rdinar('ldis')) then
            call rdfdor ('ldis',0.0d0,100.d0,ldis,numlay,numlay)
          else
            call rdsdor ('ldis',0.0d0,100.d0,ldis(1))
            if (numlay > 1) ldis(2:numlay) = ldis(1)
          end if
          tscf = 1.0d0

!         warnings and errors
          message = 'simulation with Age Tracer option (swsolu = 2)'
          call swap_warning ('read_AgeTracer', message)
          if (swSnow == 1) then
            write(message,'(3a)') 'Combination of snow and Ageing is not allowed'
            call swap_error ('read_AgeTracer',message)
          end if
      close(unit_swp)

      end subroutine read_AgeTracer

      subroutine outage(task)
! ----------------------------------------------------------------------
!     date               : October 2010
!     purpose            : output of groundwater age
! ---------------------------------------------------------------------
      use MOD_swap_base,   only: iun_min, iun_max, project, pathwork
      use MOD_grid,        only: numnod, z
      use MOD_integral,    only: inqdra
      use MOD_drain,       only: nrlevs
      use variables,       only: daynr,daycum,date,outper,outfil
      implicit none

! --- global
      integer, intent(in)                      :: task

! --- local variables ------------------
      integer, save                            :: agep,agee,ageq
      integer                                  :: getun,reclngth,node,level
      character(len=300)                       :: filnam
      character(len=80)                        :: filtext
      character(len=1)                         :: comma
      real(8), dimension(:), allocatable, save :: iqdrainout   ! Cumulative (over 1 output timestep) drainage flux (L) for each drainage level
! ----------------------------------------------------------------------
      comma = ','

      select case (task)
      case (1)

! ---    open output files -------------------------------------------------
!        age of groundwater as profile
         filnam = trim(pathwork)//trim(outfil)//'.ageProfile.csv'
         agep = getun (iun_min, iun_max)
         reclngth = 50 + 12*numnod
         open(unit=agep,file=filnam,status='unknown',recl=reclngth)
         filtext = 'Groundwater age profiles (all age-values in days)'
         call writehead (agep,1,filnam,filtext,project)
!        age of groundwater in effluents: drains, transpiration, leaching, runoff
         filnam = trim(pathwork)//trim(outfil)//'.ageEffluent.csv'
         agee = getun (iun_min, iun_max)
         call fopens(agee,filnam,'new','del')
         filtext = 'Groundwater age effluent (all age-values in days)'
         call writehead (agee,1,filnam,filtext,project)
!        effluent drain water fluxes
         filnam = trim(pathwork)//trim(outfil)//'.ageEffluentqDrain.csv'
         ageq = getun (iun_min, iun_max)
         call fopens(ageq,filnam,'new','del')
         filtext = 'Drain water effluent (mm/day)'
         call writehead (ageq,1,filnam,filtext,project)

! ---    write headers of files
         write (agep,9) (z(node),node=1,numnod)
         if (numnod <= 9) then
            write (agep,10) (node,node=1,numnod)
         else
            write (agep,11) (node,node=1,9), (node,node=10,numnod)
         end if
  9      format('*',t8,' NodeDepth (cm) =,,',18(',',f7.2) ,997(',',f8.2) )
 10      format('*',/, t8,'Date,Day,Daycum',   9(',Node',i3.3) )
 11      format('*',/, t8,'Date,Day,Daycum',   9(',Node',i3.3), 1015(',Node',i4.4) )

         write (agee,'(3a)') ' Date,daynr,daycum,AgeGwl1m,AgeBottom,',     &
          'AgeRootUpt,AgeRunoff,AgeDrainSys1,AgeDrainSys2,AgeDrainSys3,',   &
          'AgeDrainSys4,AgeDrainSys5'

         write (ageq,'(3a)') ' Date,daynr,daycum,','qDrainSys1,qDrainSys2,qDrainSys3,qDrainSys4,qDrainSys5'

         if (allocated(iqdrainout)) deallocate(iqdrainout); allocate(iqdrainout(nrlevs))

         return

      case (2)

! === write actual data =================================================

!        age of groundwater as profile
         write(agep,15) date,comma,daynr,comma,daycum,(comma,cml(node),node=1,numnod)
 15      format(a11,a1,i4,a1,i6,1p,1024(a1,e10.3))

!        age of groundwater in effluents: drains, transpiration, leaching, runoff
!        and age (d) of groundwater in upper 1 meter of saturated zone
         write(agee,16) date,comma,daynr,comma,daycum,comma,AgeGwl1m,comma,&
                        icAgeBot/outper,comma,icAgeRot/outper,comma,       &
                        icAgeSur/outper,(comma,icAgeDra(level)/outper,level=1,nrlevs)
 16      format(a11,a1,i4,a1,i6,1p,9(a1,e10.3))

!        qdrain discharge-effluent (without infiltration!)
         do level = 1,nrlevs
           iqdrainout(level) = 0.0d0
            do node = 1,numnod
               if (inqdra(level,node) > 0.0d0) then
                  iqdrainout(level) = iqdrainout(level) + inqdra(level,node)
               end if
            end do
         end do
         write(ageq,16) date,comma,daynr,comma,daycum,(comma,iqdrainout(level),level=1,nrlevs)

      case (3)

! ---    close files
         close (agep)
         close (agee)
         close (ageq)

      case default
         call swap_error ('outage', 'Illegal value for Task')
      end select

      return
      end subroutine outage

module subroutine hybrid_age_observe(values)
   real(8),intent(out)::values(11)
   values=0d0
   if(.not.allocated(Agemsy))return
   values(1)=sum(Agemsy*dz(1:size(Agemsy)))
   values(2)=age_pond_stock
   values(3)=values(1)+values(2)
   values(4:11)=age_cumulative
end subroutine
module subroutine hybrid_age_checkpoint(unit,restoring)
   use ieee_arithmetic,only:ieee_is_finite
   use MOD_grid,only:numnod
   use variables,only:theta,pond
   integer,intent(in)::unit
   logical,intent(in)::restoring
   real(8)::saved_parameters(3),saved_total(3),observed(11),scale,tolerance
   integer::ios
   if(swsolu/=2.or..not.allocated(Agemsy))error stop 'Foreign original age native owner'
   if(restoring)then
      read(unit,iostat=ios)Agemsy,ageml(1:numnod),cml(1:numnod),age_pond_stock, &
         Agepond,Agepondm1,saved_parameters,age_cumulative,icAgeTopupw,icAgeTopdwn, &
         icAgeBot,icAgeRot,icAgeSur,icAgeDra,AgeGwl1m,rottot,sqdra,saved_total
      if(ios/=0)error stop 'Incomplete original age native state'
      if(.not.all(ieee_is_finite(Agemsy)).or..not.all(ieee_is_finite(ageml(1:numnod))).or. &
         .not.all(ieee_is_finite(cml(1:numnod))).or..not.all(ieee_is_finite(age_cumulative)).or. &
         .not.all(ieee_is_finite(icAgeDra)).or..not.all(ieee_is_finite(saved_total)).or. &
         .not.all(ieee_is_finite([age_pond_stock,Agepond,Agepondm1,saved_parameters, &
         icAgeTopupw,icAgeTopdwn,icAgeBot,icAgeRot,icAgeSur,AgeGwl1m,rottot,sqdra]))) &
         error stop 'Nonfinite original age native state'
      if(any(Agemsy<0d0).or.any(ageml(1:numnod)<0d0).or.any(cml(1:numnod)<0d0).or. &
         min(age_pond_stock,Agepond,Agepondm1)<0d0.or.any(Agemsy>1d12/dz(1:numnod)).or. &
         any(age_cumulative([1,2,3,6,7,8])<0d0))error stop 'Invalid original age native domain'
      if(any(abs(saved_parameters-[Ageirr,Agedrain,Agepre])>0d0)) &
         error stop 'Foreign original age native forcing'
      call hybrid_age_observe(observed)
      scale=max(1d0,maxval(abs(saved_total)),maxval(abs(observed(1:3))))
      tolerance=8192d0*epsilon(1d0)*scale
      if(any(abs(saved_total-observed(1:3))>tolerance).or. &
         any(abs(ageml(1:numnod)*theta(1:numnod)-Agemsy)*dz(1:numnod)>tolerance).or. &
         abs(pond*Agepondm1-age_pond_stock)>tolerance)error stop 'Unbalanced original age native stock'
   else
      call hybrid_age_observe(observed)
      write(unit)Agemsy,ageml(1:numnod),cml(1:numnod),age_pond_stock, &
         Agepond,Agepondm1,[Ageirr,Agedrain,Agepre],age_cumulative,icAgeTopupw,icAgeTopdwn, &
         icAgeBot,icAgeRot,icAgeSur,icAgeDra,AgeGwl1m,rottot,sqdra,observed(1:3)
   end if
end subroutine hybrid_age_checkpoint
end submodule MOD_calc_AgeTracer
