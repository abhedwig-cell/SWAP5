* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 04:11:49

Period             :  2003-12-30  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        74.47 cm
Initial :        73.20 cm
            =============
Change            1.26 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     4.17    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -4.94    Soil evaporation  :     0.10
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :     1.63    Sum               :     0.37
