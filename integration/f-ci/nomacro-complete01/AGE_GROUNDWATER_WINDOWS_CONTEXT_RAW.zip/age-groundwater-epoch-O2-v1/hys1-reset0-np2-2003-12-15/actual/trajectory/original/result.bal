* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 04:12:21

Period             :  2003-12-15  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        73.76 cm
Initial :        69.19 cm
            =============
Change            4.57 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     4.17    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -1.64    Soil evaporation  :     0.10
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :     4.93    Sum               :     0.37
