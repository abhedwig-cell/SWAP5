* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 03:42:46

Period             :  1900-01-01  until  2002-02-04 
Depth soil profile :  200.00 cm

            Water storage
Final   :        73.83 cm
Initial :        73.20 cm
            =============
Change            0.63 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     4.59    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -3.24    Soil evaporation  :     0.46
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :     1.35    Sum               :     0.72
