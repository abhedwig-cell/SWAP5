program component
use MOD_grid,only:numnod
use MOD_swap_base,only:swmacro,swsolu,swirfix,swhyst
use hybrid_age_irrigation_source_domain
use,intrinsic::ieee_arithmetic,only:ieee_value,ieee_quiet_nan
implicit none
character(500)::action,path,arg
integer::unit,layout,before(5),marker
real(8)::age
call get_command_argument(1,action);call get_command_argument(2,path)
call get_command_argument(3,arg);read(arg,*)layout
numnod=3;swmacro=0;swsolu=2;swirfix=1;swhyst=merge(2,0,layout==7)
call hybrid_age_irrigation_source_register(3)
select case(trim(action))
case('bad-nodes');numnod=0
case('bad-macro');swmacro=1
case('bad-kind');swsolu=1
case('bad-fixed');swirfix=0
case('bad-hys');swhyst=3
case('bad-layout');layout=8
case('shape-zero');call hybrid_age_irrigation_source_register(0)
case('shape-negative');call hybrid_age_irrigation_source_register(-1)
case('shape-overflow');call hybrid_age_irrigation_source_register(36601)
case('shape-change');call hybrid_age_irrigation_source_register(4)
end select
before=[numnod,swmacro,swsolu,swirfix,swhyst]
if(index(trim(action),'age-')==1)then
 select case(trim(action))
 case('age-zero');age=0d0
 case('age-positive');age=20d0
 case('age-upper');age=1000d0
 case('age-negative');age=-1d0
 case('age-overflow');age=1001d0
 case('age-nan');age=ieee_value(1d0,ieee_quiet_nan)
 end select
 call hybrid_age_irrigation_source_assert(age)
else if(trim(action)=='write'.or.index(trim(action),'bad-')==1)then
 open(newunit=unit,file=trim(path),access='stream',form='unformatted',status='new')
 call hybrid_age_irrigation_source_checkpoint(unit,.false.,layout)
 write(unit)int(z'12345678');close(unit)
else
 open(newunit=unit,file=trim(path),access='stream',form='unformatted',status='old')
 call hybrid_age_irrigation_source_checkpoint(unit,.true.,layout)
 read(unit)marker;close(unit)
 if(marker/=int(z'12345678'))error stop 'Age source domain consumed foreign stream bytes'
end if
if(any(before/=[numnod,swmacro,swsolu,swirfix,swhyst]))error stop 'Domain mutated original live flags'
write(*,'(a)')'ACTUAL_ORIGINAL_AGE_IRRIGATION_SOURCE_DOMAIN_PASS'
end program
