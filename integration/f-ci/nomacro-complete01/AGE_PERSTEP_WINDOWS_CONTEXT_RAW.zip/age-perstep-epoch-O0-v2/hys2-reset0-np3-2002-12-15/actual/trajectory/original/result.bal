* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 02:39:00

Period             :  2002-12-15  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        67.81 cm
Initial :        75.19 cm
            =============
Change           -7.37 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     8.19    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -17.91    Soil evaporation  :     0.05
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    -7.32    Sum               :     0.05
