* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 01:55:26

Period             :  1900-01-01  until  2002-02-04 
Depth soil profile :  200.00 cm

            Water storage
Final   :        75.42 cm
Initial :        75.19 cm
            =============
Change            0.23 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     4.59    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.46
                             Crack flux        :     0.00
                             Drainage level 1  :     3.91
=========================    ============================
Sum            :     4.59    Sum               :     4.36
