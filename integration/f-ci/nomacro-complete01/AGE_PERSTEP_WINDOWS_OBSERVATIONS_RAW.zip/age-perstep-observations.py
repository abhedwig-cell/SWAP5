from pathlib import Path
import hashlib,json,subprocess
e=Path('C:/Users/Veldh012/swap5-complete01-evidence');r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
n={};exec(Path('C:/Users/Veldh012/AppData/Local/Temp/s5-userrelease-api.py').read_text(encoding='utf8').split("if sys.argv[1]=='dispatch':")[0],n)
old=n['api']('actions/runs/44440065634');artifacts=n['api']('actions/runs/44440065634/artifacts')['artifacts'];assert old['status']=='completed' and old['conclusion']=='failure' and not artifacts
log=(e/'AGE_PERSTEP_PRESERVATION_V1_JOB_LOG.txt').read_bytes();assert b"ModuleNotFoundError: No module named 'user_prepare'" in log
q=dict(status='ACTUAL_WORKFLOW_ONLY_IMPORT_FAILURE_RETAINED_NO_MODELS_OR_ARTIFACTS',run=44440065634,carrier=old['head_sha'],actual_terminal_status=old['status'],actual_terminal_conclusion=old['conclusion'],original_artifact_count=0,decoded_connector_log=dict(path='AGE_PERSTEP_PRESERVATION_V1_JOB_LOG.txt',bytes=len(log),sha256=hashlib.sha256(log).hexdigest()),source_or_physical_change=False,corrected_carrier=json.loads((e/'AGE_PERSTEP_PRESERVATION_CARRIER.json').read_text(encoding='utf8')))
(e/'AGE_PERSTEP_PRESERVATION_V1_OBSERVATION.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
checks={}
for family in ('ordinary','history'):
 a=e/f'age-perstep-controls-{family}-O0-v1';b=e/f'age-perstep-controls-{family}-O0-v2';left=(a/'native/age-cumulative-reset/origin/macro.bin').read_bytes();right=(b/'native/age-cumulative-reset/origin/macro.bin').read_bytes()
 assert left==right,family
 first='\n'.join(p.read_text(encoding='utf8') for p in (a/'native/age-cumulative-reset').rglob('donor.stdout'));later='\n'.join(p.read_text(encoding='utf8') for p in (b/'native/age-cumulative-reset').rglob('donor.stderr'))
 assert 'HYBRID_READY' in first and "Inconsistent original AGE private reset flags and calendar" in later
 checks[family]=dict(exact_same_bad_native_bytes=True,bytes=len(left),sha256=hashlib.sha256(left).hexdigest(),old_initialization_accepted=True,current_error=later,old_control_root=str(a),current_control_root=str(b))
diff=subprocess.check_output(['git','diff','--name-only','14adb2da8','6805b8beb','--','app'],cwd=r,text=True).splitlines();assert diff==['app/hybrid_water/age_perstep_output.py']
q=dict(status='ACTUAL_IDENTICAL_WRONG_PRIVATE_RESET_PAYLOAD_OLD_ACCEPT_CURRENT_REFUSE',checks=checks,only_app_change=diff,old_source='14adb2da8',current_source='6805b8beb',physical_drift_claim=False,broad_inherited_defect_claim=False)
(e/'AGE_PERSTEP_PRIVATE_RESET_COMPARISON.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
q=dict(status='RETAINED_TEST_ONLY_CADENCE_POSTVALIDATOR_TUPLE_OBSERVATION',source_controller='5ffca3419',assertion='age_perstep_runtime.py:38 water export column vector compared against drain file due tuple ordering; four read-only attempts returned1 before writing backups or model data.',actual_tool_wall_seconds=[1.6653033000000002,1.7505225,1.6995752,1.6628305],measurement='Tool wall time, not isolated validator execution time; full stderr was observed in execution transcript, not captured to a separate original file.',corrected_controller='d1b21f10b',model_rebuild_or_warm_rerun=False)
(e/'AGE_PERSTEP_CADENCE_POSTVALIDATOR_V1_OBSERVATION.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print('ACTUAL_RETAINED_OBSERVATIONS_BOUND',flush=True)
