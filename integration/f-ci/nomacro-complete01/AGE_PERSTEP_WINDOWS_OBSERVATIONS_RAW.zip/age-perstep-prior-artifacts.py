from pathlib import Path
import json
n={};exec(Path('C:/Users/Veldh012/AppData/Local/Temp/s5-userrelease-api.py').read_text(encoding='utf8').split("if sys.argv[1]=='dispatch':")[0],n)
for key,run in [('cde',44426634761),('legacy',44212855459),('history',44226733764),('direct',44246149974)]:
 q=n['api']('actions/runs/'+str(run)+'/artifacts?per_page=100');print(json.dumps(dict(family=key,run=run,artifacts=[dict(name=v['name'],id=v['id'],expired=v['expired']) for v in q['artifacts']])),flush=True)
