from pathlib import Path
import hashlib,json,zipfile,sys
e=Path('C:/Users/Veldh012/swap5-complete01-evidence');p=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01')
def pack(label,roots):
 name='AGE_PERSTEP_WINDOWS_'+label+'_RAW.zip';archive=e/name;assert not archive.exists();members={};roots={root for root in roots if not any(root!=other and root.is_relative_to(other) for other in roots)}
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for root in sorted(roots):
   assert root.exists() and root.resolve().is_relative_to(e.resolve())
   for path in sorted(root.rglob('*')) if root.is_dir() else [root]:
    if not path.is_file():continue
    relative=path.relative_to(e).as_posix();assert relative not in members;raw=path.read_bytes();members[relative]=hashlib.sha256(raw).hexdigest();z.writestr(relative,raw)
 with zipfile.ZipFile(archive) as z:
  assert set(z.namelist())==set(members)
  for member,value in members.items():assert hashlib.sha256(z.read(member)).hexdigest()==value
 raw=archive.read_bytes();record=dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),member_count=len(members),members=members,all_members_forward_verified=True,producer_roots=[str(root) for root in sorted(roots)])
 if len(raw)>100*1024*1024:
  parts=[]
  for offset in range(0,len(raw),64*1024*1024):
   chunk=raw[offset:offset+64*1024*1024];part=name+f'.part{len(parts)+1:02}';assert b'\0' in chunk[:8192];(p/part).write_bytes(chunk);parts.append(dict(path=part,offset=offset,bytes=len(chunk),sha256=hashlib.sha256(chunk).hexdigest()))
  record['byte_parts']=parts
 else:assert b'\0' in raw[:8192];record['archive']=name;(p/name).write_bytes(raw)
 (p/('AGE_PERSTEP_WINDOWS_'+label+'_RAW_ARCHIVE.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(label,len(raw),len(members),flush=True)


def selected():
 covered=set();groups={}
 for opt in ('O0','O2'):
  root=e/f'age-perstep-windows-{opt}-v1';q=json.loads((root/'RESULT.json').read_text(encoding='utf8'));assert q['status']=='EIGHT_AGE_PERSTEP_SHORT_SIX_FULL_THREE_NATIVE_TWO_LIMIT_CONTEXTS_PASS';roots={root}
  for item in q['cases'].values():
   for key in ('short_root','build_root','input_root','full_root'):
    if key in item:roots.add(Path(item[key]))
  for item in [*q['controls'].values(),*q['limits'].values()]:roots.add(Path(item['root']))
  covered.update(roots);groups[opt]=roots
 preservation={e/f'age-perstep-preserve-{family}-{opt}-v{3 if opt=="O0" and family=="legacy" else 2 if opt=="O0" else 1}' for opt in ('O0','O2') for family in ('cde','legacy','history','direct')}
 for root in preservation:assert 'PRESERVED' in json.loads((root/'RESULT.json').read_text(encoding='utf8'))['status']
 covered.update(preservation);groups['PRESERVATION']=preservation
 context={e/'age-perstep-public-windows-v1',e/'age-perstep-reader-windows-v1'}
 for opt in ('O0','O2'):
  epoch=e/f'age-perstep-epoch-{opt}-v2';q=json.loads((epoch/'RESULT.json').read_text(encoding='utf8'));assert q['status']=='SIX_NONJANUARY_AGE_PERSTEP_EPOCHS_BOTH_RESET_PRIVATE_NATIVE_COLD_PASS';context.add(epoch);context.update(Path(v['root']) for v in q['cases'].values());context.add(e/f'age-perstep-year-controls-{opt}-v1')
 covered.update(context);groups['CONTEXT']=context
 return covered,groups


covered,groups=selected()
if len(sys.argv)==1 or sys.argv[1]=='selected':
 for label,roots in groups.items():pack(label,roots)
else:
 assert sys.argv[1]=='observations'
 # Snapshot only after selected CI state is terminal; never archive live metadata.
 for family in ('MAIN','PRESERVATION'):
  q=json.loads((e/f'AGE_PERSTEP_{family}_CI_STATE.json').read_text(encoding='utf8'));assert q['status']=='completed'
 retained={path for path in e.iterdir() if path.is_dir() and path.name.startswith(('age-perstep-','age-composition-baseline-')) and not path.name.startswith(('age-perstep-ubuntu-','age-perstep-source-site','age-perstep-metadata-site'))}
 retained={path for path in retained if not any(path==old or path.is_relative_to(old) for old in covered)}
 retained.update(path for path in e.iterdir() if path.is_file() and ('age-perstep' in path.name.lower() or path.name.startswith(('AGE_PERSTEP_','NEXT_AGE_PERSTEP_'))) and path.suffix in ('.json','.log','.txt','.py','.yml','.md') and not path.name.endswith('_RAW_ARCHIVE.json'))
 pack('OBSERVATIONS',retained)
