from pathlib import Path
import json,subprocess,sys,hashlib
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path.insert(0,str(r/'tests/nomacro_scheduled_subsurface'))
import age_perstep_runtime as runtime
m=runtime.m;out=Path(sys.argv[1]);path=out/'RESULT.json';raw=path.read_bytes();q=json.loads(raw)
assert q['status']=='FAILED' and q['error'].startswith("AssertionError({'result.ageProfile.csv':") and 'cold' not in q and 'age_output' not in q
phase=q['parameters']['phase'];assert phase in ('short','full')
days={'short':35,'full':1096}[phase];data=m.rows(out/'trajectory');assert len(data)==q['trajectory']['days']==q['trajectory']['budgets']['days']==days
build=Path(q['build_root']);inputs=Path(q['input_root']);project=m.e.load(inputs,original_output=True);meta,_=m.validate_bundle(build,Path(q['parameters']['reference_work']),project)
assert meta['identity']['original_output']==runtime.metadata(project)==q['original_output'] and q['trajectory']['build_sha256']==m.sha(build/'BUILD.json')
for field in ('max_water_cm','max_kernel_cm'):assert abs(q['trajectory']['budgets'][field])<=1e-10
m.check(data);assert all(row['committed'] and all(abs(row[k])<=row['age_tolerance_cm_day'] for k in ('age_soil_residual_cm_day','age_pond_residual_cm_day','age_combined_residual_cm_day')) for row in data)
actual=runtime.age_outputs(out/'trajectory',data,project)
backup=out/'RETAINED_FAILED_RESULT.json';assert not backup.exists();backup.write_bytes(raw)
q.update(age_output=actual,retained_cadence_validation_failure=dict(path=backup.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),post_validation_controller_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),post_validation_role='Actual complete existing source-bound trajectory revalidated without build/model rerun; only fresh required cold workers execute.')
windows=[(2,4),(4,8),(19,23),(30,34)]
if phase=='full':windows.extend([(199,201),(364,367),(530,532),(1094,1096)])
q['cold']=[runtime.own(build,Path(q['parameters']['reference_work']),project,out/'trajectory',data,s,e,out/f'own-{s}') for s,e in windows]
q['actual_fixed_input_cm']=sum(row['external_flux_cm'][3]+row['external_flux_cm'][5] for row in data);assert abs(q['actual_fixed_input_cm']-2.4)<=1e-10
q['maximum_age_tolerance_fraction']=max(abs(row[k])/row['age_tolerance_cm_day'] for row in data for k in ('age_soil_residual_cm_day','age_pond_residual_cm_day','age_combined_residual_cm_day'));assert q['maximum_age_tolerance_fraction']<=1
assert all(row['age_state_cm_day'][5]==0 for row in data)
q.pop('error');q['status']='ACTUAL_AGE_PERSTEP_'+phase.upper()+'_SOURCE_NATIVE_OUTPUT_PASS';path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],q['maximum_age_tolerance_fraction'],flush=True)
