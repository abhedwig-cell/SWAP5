from pathlib import Path
import json,os,subprocess,sys
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');e=Path('C:/Users/Veldh012/swap5-complete01-evidence');mode=sys.argv[1];assert mode in ('main','preservation')
def git(*args,input=None,env=None):return subprocess.check_output(['git',*args],cwd=r,input=input,env=env).decode().strip()
runtime=git('rev-parse','HEAD');assert runtime==git('rev-parse','9d86ac77b') and not git('status','--porcelain')
for opt in ('O0','O2'):
 assert json.loads((e/f'age-perstep-windows-{opt}-v1/RESULT.json').read_text())['status']=='EIGHT_AGE_PERSTEP_SHORT_SIX_FULL_THREE_NATIVE_TWO_LIMIT_CONTEXTS_PASS'
 assert json.loads((e/f'age-perstep-epoch-{opt}-v2/RESULT.json').read_text())['status']=='SIX_NONJANUARY_AGE_PERSTEP_EPOCHS_BOTH_RESET_PRIVATE_NATIVE_COLD_PASS'
workflow=(e/f'age-perstep-{mode}-workflow.yml').read_text(encoding='utf8');assert 'age_perstep_' in workflow
index=e/f'age-perstep-{mode}-carrier.index';assert not index.exists();env=os.environ.copy();env['GIT_INDEX_FILE']=str(index);git('read-tree',runtime,env=env)
path='.github/workflows/nomacro-coverage-prescribed-head.yml';blob=git('hash-object','-w','--stdin',input=workflow.encode());git('update-index','--add','--cacheinfo','100644,'+blob+','+path,env=env);tree=git('write-tree',env=env)
carrier=git('commit-tree',tree,'-p',runtime,'-m','Selected original AGE perstep '+mode+' portable carrier never merge');assert git('diff','--name-only',runtime,carrier)==path
branch='codex/nomacro-age-perstep-'+('portable01' if mode=='main' else 'preservation01');git('update-ref','refs/heads/'+branch,carrier);git('push','origin',branch)
record=dict(runtime=runtime,carrier=carrier,tree=tree,branch=branch,only_delta=path,merge=False);(e/('AGE_PERSTEP_'+('PORTABLE' if mode=='main' else 'PRESERVATION')+'_CARRIER.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps(record),flush=True)
n={};exec(Path('C:/Users/Veldh012/AppData/Local/Temp/s5-userrelease-api.py').read_text(encoding='utf8').split("if sys.argv[1]=='dispatch':")[0],n);n['api']('actions/workflows/nomacro-coverage-prescribed-head.yml/dispatches',dict(ref=branch));print('DISPATCHED',branch,flush=True)
