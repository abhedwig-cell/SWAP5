from pathlib import Path
import subprocess
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');p=r/'tests/nomacro_scheduled_subsurface'
s=(p/'perstep_domain_controls.py').read_text(encoding='utf8').replace('perstep_domain_runtime as matrix','age_perstep_runtime as matrix').replace('from perstep_output_domain import','from age_perstep_output import')
s=s.replace('"""Actual grouped ordinary/Snow per-step native, policy and transactional controls."""','"""Actual AGE per-step native/private, policy and transactional controls."""')
s=s.replace("struct.pack('<5i',1,project.nodes,0,selected['swhyst'],0)","struct.pack('<5i',1,project.nodes,0,selected['swhyst'],2)")
s=s.replace('    checks=[]\n    for attack in attacks:',"    attacks+=['age-output-day','age-output-period','age-stock-negative','age-stock-nan','age-export-negative','age-export-nan','age-total-receipt','age-cumulative-reset','age-interval-reset']\n    checks=[]\n    for attack in attacks:",1)
s=s.replace("        if attack in markers:raw[:8]=markers[attack]", """        if attack.startswith('age-'):
            age_start=pos+160+16*nreal
            if attack=='age-output-day':struct.pack_into('<i',raw,len(raw)-20,5)
            elif attack=='age-output-period':struct.pack_into('<d',raw,len(raw)-16,1.)
            elif attack=='age-stock-negative':struct.pack_into('<d',raw,age_start,-1.)
            elif attack=='age-stock-nan':struct.pack_into('<d',raw,age_start,float('nan'))
            elif attack=='age-export-negative':struct.pack_into('<d',raw,len(raw)-172,-1.)
            elif attack=='age-export-nan':struct.pack_into('<d',raw,len(raw)-172,float('nan'))
            elif attack=='age-total-receipt':struct.pack_into('<d',raw,len(raw)-44,1.)
            else:
                offset=len(raw)-(8 if attack=='age-cumulative-reset' else 4)
                struct.pack_into('<i',raw,offset,1-struct.unpack_from('<i',raw,offset)[0])
        elif attack in markers:raw[:8]=markers[attack]""")
s=s.replace("project=m.e.load(Path(cohort['input_root']),original_output=True)","project=m.e.load(Path(cohort.get('input_root',a.profile_root/'input')),original_output=True)")
s=s.replace("build=Path(cohort['build_root'])","build=Path(cohort.get('build_root',a.profile_root/'build'))")
s=s.replace("(67 if selected['swsnow'] else 43 if selected['swhyst'] else 37)","(52 if selected['swhyst'] else 46)")
s=s.replace("q['trial_phase_witness']=None if selected['swsnow'] else matrix.audit_trial_witness(full,project.start_clock)","q['trial_phase_witness']='SOURCE_BOUND_LITERAL_EXISTING_DARCY_PROVIDER_NOT_FRESH_COMPONENT_PASS'")
s=s.replace('WATER_PERSTEP_DOMAIN_NATIVE_ACTIVE_POLICY_PROVIDER_PASS','AGE_PERSTEP_NATIVE_PRIVATE_ACTIVE_POLICY_PROVIDER_PASS')
(p/'age_perstep_controls.py').write_text(s,encoding='utf8')
subprocess.run(['git','add','tests/nomacro_scheduled_subsurface/age_perstep_controls.py'],cwd=r,check=True)
subprocess.run(['git','commit','-m','Persist actual AGE perstep private/calendar refusal and transaction controls'],cwd=r,check=True)
