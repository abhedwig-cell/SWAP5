from pathlib import Path
e=Path('C:/Users/Veldh012/swap5-complete01-evidence');s=(e/'download-cde-clock.py').read_text(encoding='utf8')
s=s.replace('CDE_CLOCK','AGE_PERSTEP').replace('cde-clock','age-perstep').replace('44426634761','44440052103').replace('44426886393','44440435509').replace('01ab5d95c879ce253ed4a667bf0d525ac38d3cb4','c94b910200ab7be90960f6f0288db222a84eafe0').replace('5f0eb55a0b991ab7217e550608240552fb609570','33e8a4721a8fe5be598613b41d766ffcff05b37e')
s=s.replace('TEN_AGE_PERSTEP_SHORT_SIX_FULL_SIX_NATIVE_FOUR_LIMIT_CONTEXTS_PASS','EIGHT_AGE_PERSTEP_SHORT_SIX_FULL_THREE_NATIVE_TWO_LIMIT_CONTEXTS_PASS').replace('EIGHT_NONJANUARY_AGE_PERSTEP_EPOCHS_BOTH_RESET_NATIVE_COLD_PASS','SIX_NONJANUARY_AGE_PERSTEP_EPOCHS_BOTH_RESET_PRIVATE_NATIVE_COLD_PASS')
(e/'download-age-perstep.py').write_text(s,encoding='utf8')
