from pathlib import Path
import subprocess
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');p=r/'tests/nomacro_scheduled_subsurface'
s=(p/'cde_clock_public.py').read_text(encoding='utf8').replace('cde_clock_runtime','age_perstep_runtime').replace('cde_clock_output','age_perstep_output').replace('CDE_CLOCK','AGE_PERSTEP')
a=s.index("for name in ('ordinary-explicit");b=s.index('):',a)
s=s[:a]+"for name in ('ordinary-explicit-h0-binary','history-monthly-h2-vector','ordinary-periodic-h0-ascii','history-explicit-h1-binary','history-terminal-h2-ascii','history-periodic-h1-vector'"+s[b:]
(p/'age_perstep_public.py').write_text(s,encoding='utf8')
s=(p/'cde_clock_year_controls.py').read_text(encoding='utf8').replace('cde_clock_runtime','age_perstep_runtime').replace('EIGHT_NONJANUARY_CDE_CLOCK_EPOCHS_BOTH_RESET_NATIVE_COLD_PASS','SIX_NONJANUARY_AGE_PERSTEP_EPOCHS_BOTH_RESET_PRIVATE_NATIVE_COLD_PASS').replace('THIRTY_TWO_ACTUAL_CDE_CLOCK_POST_YEAR_COUNTER_FORGERIES_REFUSED','TWENTY_FOUR_ACTUAL_AGE_PERSTEP_POST_YEAR_COUNTER_FORGERIES_REFUSED')
(p/'age_perstep_year_controls.py').write_text(s,encoding='utf8')
subprocess.run(['git','add','tests/nomacro_scheduled_subsurface/age_perstep_public.py','tests/nomacro_scheduled_subsurface/age_perstep_year_controls.py','tests/nomacro_scheduled_subsurface/age_perstep_epoch.py'],cwd=r,check=True)
subprocess.run(['git','commit','-m','Persist actual AGE perstep public restart and independent year/private-clock cohorts'],cwd=r,check=True)
