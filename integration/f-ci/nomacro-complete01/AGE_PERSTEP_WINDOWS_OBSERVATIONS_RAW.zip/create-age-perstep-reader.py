from pathlib import Path
import subprocess
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');p=r/'tests/nomacro_scheduled_subsurface'
s=(p/'cde_clock_reader.py').read_text(encoding='utf8').replace('cde_clock_runtime','age_perstep_runtime').replace('cde_clock_output','age_perstep_output').replace('CDE_CLOCK','AGE_PERSTEP').replace('dense-cde','dense-age').replace('interval-cde','interval-age').replace('monthly-cde','monthly-age')
s=s.replace("('age',{'SWSOLU':2})","('cde',{'SWSOLU':1})")
(p/'age_perstep_reader.py').write_text(s,encoding='utf8')
subprocess.run(['git','add','tests/nomacro_scheduled_subsurface/age_perstep_reader.py'],cwd=r,check=True);subprocess.run(['git','commit','-m','Persist actual original AGE perstep reader refusals and literal inactive partitions'],cwd=r,check=True)
