from pathlib import Path
import hashlib,json,urllib.request,urllib.error,zipfile,sys
base=Path('C:/Users/Veldh012/swap5-complete01-evidence');proof=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01');n={}
exec(Path('C:/Users/Veldh012/AppData/Local/Temp/s5-userrelease-api.py').read_text().split("if sys.argv[1]=='dispatch':")[0],n)
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None
mode=sys.argv[1];assert mode in ('main','preservation')
runid=44440052103 if mode=='main' else 44440435509
carrier='c94b910200ab7be90960f6f0288db222a84eafe0' if mode=='main' else '33e8a4721a8fe5be598613b41d766ffcff05b37e'
run=n['api']('actions/runs/'+str(runid));assert run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==carrier
artifacts=n['api']('actions/runs/'+str(runid)+'/artifacts')['artifacts'];assert len(artifacts)==(2 if mode=='main' else 1)
for artifact in artifacts:
    label=artifact['name'].rsplit('-',1)[1].upper();assert label in (('O0','O2') if mode=='main' else ('PRESERVATION',))
    name=f'AGE_PERSTEP_UBUNTU_{label}_RAW.zip';archive=base/name
    if archive.exists():raw=archive.read_bytes()
    else:
        request=urllib.request.Request(artifact['archive_download_url'],headers={'Authorization':'Bearer '+n['secret'],'Accept':'application/vnd.github+json'})
        try:response=urllib.request.build_opener(NoRedirect).open(request,timeout=30)
        except urllib.error.HTTPError as error:
            if error.code!=302:raise
            response=urllib.request.urlopen(error.headers['Location'],timeout=90)
        raw=response.read();assert 'sha256:'+hashlib.sha256(raw).hexdigest()==artifact['digest'];archive.write_bytes(raw)
    assert len(raw)==artifact['size_in_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==artifact['digest']
    record=dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),origin_artifact=artifact,workflow_run=runid,carrier=carrier,workflow_conclusion='success',actual_artifact_bytes_preserved=True,all_members_forward_verified=True)
    if len(raw)>100*1024*1024:
        parts=[]
        for offset in range(0,len(raw),64*1024*1024):
            chunk=raw[offset:offset+64*1024*1024];part=name+f'.part{len(parts)+1:02}';assert b'\0' in chunk[:8192];(proof/part).write_bytes(chunk)
            parts.append(dict(path=part,offset=offset,bytes=len(chunk),sha256=hashlib.sha256(chunk).hexdigest()))
        record['byte_parts']=parts
    else:assert b'\0' in raw[:8192];(proof/name).write_bytes(raw);record['archive']=name
    target=base/('age-perstep-ubuntu-'+label if mode=='main' else 'age-perstep-ubuntu-preservation');target.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        assert all((target/name0).resolve().is_relative_to(target.resolve()) for name0 in z.namelist())
        members={name0:hashlib.sha256(z.read(name0)).hexdigest() for name0 in z.namelist() if not name0.endswith('/')};z.extractall(target)
    record.update(member_count=len(members),members=members);(proof/f'AGE_PERSTEP_UBUNTU_{label}_RAW_ARCHIVE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
    if mode=='main':
        q=json.loads((target/'RESULT.json').read_text(encoding='utf8'));assert q['status']=='EIGHT_AGE_PERSTEP_SHORT_SIX_FULL_THREE_NATIVE_TWO_LIMIT_CONTEXTS_PASS'
        assert json.loads((target/'epoch/RESULT.json').read_text(encoding='utf8'))['status']=='SIX_NONJANUARY_AGE_PERSTEP_EPOCHS_BOTH_RESET_PRIVATE_NATIVE_COLD_PASS'
    print(label,'ACTUAL_ARTIFACT_VERIFIED',artifact['id'],len(raw),len(members),flush=True)
