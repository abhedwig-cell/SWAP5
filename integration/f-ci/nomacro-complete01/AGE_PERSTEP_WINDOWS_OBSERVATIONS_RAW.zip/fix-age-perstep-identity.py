from pathlib import Path
import subprocess,json
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');e=Path('C:/Users/Veldh012/swap5-complete01-evidence')
for name in ('daily_host.py','daily_coupling.py'):
 p=r/'app/hybrid_water'/name;s=p.read_text(encoding='utf8');anchor='from age_direct_soil_source import age_identity';assert s.count(anchor)==1;p.write_text(s.replace(anchor,'from age_perstep_output import source_age_identity as age_identity',1),encoding='utf8')
p=r/'integration/f-ci/nomacro-complete01/STATUS.json';q=json.loads(p.read_text(encoding='utf8'))
q['age_perstep']['retained_v1_identity_failures']={family+'-'+opt:json.loads((e/f'age-perstep-{family}-{opt}-v1/RESULT.json').read_text(encoding='utf8')) for family in ('ordinary','history') for opt in ('O0','O2')}
q['age_perstep']['identity_correction']='Actual new AGE output owner must also bind conserved_original_age identity. Inactive AGE literal source owner delegation preserved. Initial O0/O2 ordinary resets refused by old identity selector; history built old codec before driver assertion. No model trajectories started.'
q.update(status='AGE_PERSTEP_IDENTITY_COMPOSITION_FIXED_O0_O2_RETEST_NEXT',next_action='Run four fresh ordinary/history O0/O2 actual35day source/native composition on corrected persisted source. Keep v1 failures and original builds unchanged.')
p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
subprocess.run(['git','add','app/hybrid_water/age_perstep_output.py','app/hybrid_water/daily_host.py','app/hybrid_water/daily_coupling.py','integration/f-ci/nomacro-complete01/STATUS.json'],cwd=r,check=True)
subprocess.run(['git','commit','-m','Bind actual AGE perstep source identity and retain initial composition refusals'],cwd=r,check=True)
