from pathlib import Path
import json,os,subprocess
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');e=Path('C:/Users/Veldh012/swap5-complete01-evidence')
def git(*args,input=None,env=None):return subprocess.check_output(['git',*args],cwd=r,input=input,env=env).decode().strip()
runtime=git('rev-parse','9d86ac77b');assert git('rev-parse','HEAD')==runtime and not git('status','--porcelain')
for name in ('AGE_PERSTEP_PRESERVATION_CARRIER.json','AGE_PERSTEP_PRESERVATION_CI_STATE.json'):
 source=e/name;target=e/name.replace('.json','_V1.json');assert not target.exists();target.write_bytes(source.read_bytes())
workflow=(e/'age-perstep-preservation-workflow.yml').read_text(encoding='utf8');anchor="sys.path.insert(0,'tools/solute')";assert workflow.count(anchor)==1
workflow=workflow.replace(anchor,"sys.path[:0]=['app/hybrid_water','tools/solute']",1);(e/'age-perstep-preservation-workflow-v2.yml').write_text(workflow,encoding='utf8')
index=e/'age-perstep-preservation-carrier-v2.index';assert not index.exists();env=os.environ.copy();env['GIT_INDEX_FILE']=str(index);git('read-tree',runtime,env=env)
path='.github/workflows/nomacro-coverage-prescribed-head.yml';blob=git('hash-object','-w','--stdin',input=workflow.encode());git('update-index','--add','--cacheinfo','100644,'+blob+','+path,env=env);tree=git('write-tree',env=env);carrier=git('commit-tree',tree,'-p',runtime,'-m','Actual AGE preservation provider import path correction carrier never merge');assert git('diff','--name-only',runtime,carrier)==path
branch='codex/nomacro-age-perstep-preservation02';git('update-ref','refs/heads/'+branch,carrier);git('push','origin',branch)
record=dict(runtime=runtime,carrier=carrier,tree=tree,branch=branch,only_delta=path,merge=False,retained_failed_run=44440065634,correction='Workflow adds actual app/hybrid_water directory containing user_prepare. Original v1 failed before models and artifacts; no physical/source change.');(e/'AGE_PERSTEP_PRESERVATION_CARRIER.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(json.dumps(record),flush=True)
n={};exec(Path('C:/Users/Veldh012/AppData/Local/Temp/s5-userrelease-api.py').read_text(encoding='utf8').split("if sys.argv[1]=='dispatch':")[0],n);n['api']('actions/workflows/nomacro-coverage-prescribed-head.yml/dispatches',dict(ref=branch));print('DISPATCHED',branch,flush=True)
