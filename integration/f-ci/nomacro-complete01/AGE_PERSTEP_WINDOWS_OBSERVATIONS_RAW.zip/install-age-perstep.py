from pathlib import Path
import subprocess,json
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');e=Path('C:/Users/Veldh012/swap5-complete01-evidence')
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='codex/nomacro-age-perstep01'
assert subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()=='?? app/hybrid_water/age_perstep_output.py'
(r/'app/hybrid_water/age_perstep_output.py').write_text((e/'age_perstep_output.py').read_text(encoding='utf8'),encoding='utf8')
for name,count in [('daily_host.py',2),('daily_coupling.py',1),('experimental_project.py',1)]:
 p=r/'app/hybrid_water'/name;s=p.read_text(encoding='utf8');assert s.count('import cde_clock_output')+s.count('from cde_clock_output')==count;s=s.replace('import cde_clock_output','import age_perstep_output').replace('from cde_clock_output','from age_perstep_output');p.write_text(s,encoding='utf8')
p=r/'integration/f-ci/nomacro-complete01/STATUS.json';q=json.loads(p.read_text(encoding='utf8'));q.update(status='AGE_PERSTEP_IMPLEMENTED_PERSIST_BEFORE_O0_O2',last_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),next_action='Persist bounded AGE perstep adapter and run real generated ordinary/hysteresis O0/O2 35day source/native composition. Diagnose failures before broader qualification.');q['age_perstep']['status']='IMPLEMENTED_NOT_TESTED';p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
subprocess.run(['git','add','app/hybrid_water/age_perstep_output.py','app/hybrid_water/daily_host.py','app/hybrid_water/daily_coupling.py','app/hybrid_water/experimental_project.py','integration/f-ci/nomacro-complete01/STATUS.json'],cwd=r,check=True)
subprocess.run(['git','commit','-m','Compose original AGE perstep calendar and private state with admitted Darcy guard'],cwd=r,check=True)
