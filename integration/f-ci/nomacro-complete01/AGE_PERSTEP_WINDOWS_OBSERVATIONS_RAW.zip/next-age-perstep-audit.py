from pathlib import Path
import json,hashlib,subprocess
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');e=Path('C:/Users/Veldh012/swap5-complete01-evidence')
def read(path):return json.loads(path.read_text(encoding='utf8'))
original=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider/build/swap-src/SWAP/solute.f90')
text=original.read_text(encoding='cp1252');assert "Combination of snow and Ageing is not allowed" in text
v3=read(e/'age-composition-baseline-v3/RESULT.json');v4=read(e/'age-composition-baseline-v4/RESULT.json');v5=read(e/'age-composition-baseline-v5/RESULT.json')
assert v5['status']=='THREE_ACTUAL_ORIGINAL_AGE_PROCESS_CALENDAR_READERS_PUBLIC_BUILD_OBSERVATIONS_RETAINED'
q=dict(status='NEXT_AGE_PERSTEP_SOURCE_AUDIT_ACTUAL_ORIGINAL_REFUSALS_AND_IMPLEMENTED_PARTITIONS',baseline=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),scientific_claim=False,
 historical_forbidden=dict(configuration='SWSOLU2+SWSNOW1',classification='UNSUPPORTED_BY_ORIGINAL_READER_NOT_MISSING_MIGRATION',original_source_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),original_reader_statement='Combination of snow and Ageing is not allowed',actual_observation=v3['profiles']['snow-dense']),
 already_implemented_build_only={'history-periodic':v3['profiles']['history-periodic'],'ordinary-monthly-subdaily':v4['profiles']['ordinary-monthly-subdaily'],'history-monthly-subdaily':v5['profiles']['history-monthly-subdaily']},
 actual_original_supported_public_refusals={k:v for k,v in v5['profiles'].items() if v['public_returncode']!=0},
 next_coherent_batch='AGE FLPRINTDT original requested calendars/reset0/1/NPRINTDAY1..1440 for ordinary/hysteresis0/1/2, heat1calc2 analytic/drain1/bottom5/8 without Snow/frost/aquifer. Reuse literal age providers, source and real independent Darcy trial receipt. Preserve nonselected prior selectors and implemented nonstep paths.',
 retained_observations=['v1 fixture omitted optional FLPRINTDT entry; no original model started','v2 actual original reader expressly rejects Snow+AGE','v3 history-periodic current public build succeeds; not missing implementation or runtime qualification','v4 ordinary-monthly-subdaily current build succeeds; not missing implementation or runtime qualification','v5 history-monthly-subdaily current build succeeds; two actual original perstep reset1 reader runs succeed but current public code refuses'],
 functional_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED')
assert set(q['actual_original_supported_public_refusals'])=={'ordinary-perstep','history-perstep'}
paths=['app/hybrid_water/experimental_project.py','app/hybrid_water/original_output.py','app/hybrid_water/original_output_hysteresis.py','app/hybrid_water/age_output_calendar.py','app/hybrid_water/age_output_clock.py','app/hybrid_water/perstep_output_domain.py']
q['actual_source_sha256']={p:hashlib.sha256((r/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in paths}
(e/'NEXT_AGE_PERSTEP_SOURCE_AUDIT.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(q['status'])
