from pathlib import Path
import json
e=Path('C:/Users/Veldh012/swap5-complete01-evidence');n={};exec(Path('C:/Users/Veldh012/AppData/Local/Temp/s5-userrelease-api.py').read_text(encoding='utf8').split("if sys.argv[1]=='dispatch':")[0],n)
for key,recordname in [('main','AGE_PERSTEP_PORTABLE_CARRIER.json'),('preservation','AGE_PERSTEP_PRESERVATION_CARRIER.json')]:
 c=json.loads((e/recordname).read_text(encoding='utf8'));runs=n['api']('actions/workflows/nomacro-coverage-prescribed-head.yml/runs?branch='+c['branch']+'&event=workflow_dispatch&per_page=10')['workflow_runs'];matches=[v for v in runs if v['head_sha']==c['carrier']];assert len(matches)==1,(key,len(matches));run=matches[0]
 jobs=n['api']('actions/runs/'+str(run['id'])+'/jobs?per_page=100')['jobs'];q=dict(kind=key,id=run['id'],status=run['status'],conclusion=run['conclusion'],carrier=run['head_sha'],branch=run['head_branch'],jobs=[dict(id=v['id'],name=v['name'],status=v['status'],conclusion=v['conclusion'],steps=[dict(name=s['name'],status=s['status'],conclusion=s['conclusion']) for s in v.get('steps',[])]) for v in jobs])
 (e/('AGE_PERSTEP_'+key.upper()+'_CI_STATE.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(json.dumps(q),flush=True)
