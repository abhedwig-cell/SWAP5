import pathlib,subprocess,json,sys,os
R=pathlib.Path(r"C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01")
E=pathlib.Path(r"C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600/evidence")
cleanup=r"C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py"
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();rows=[]
for case in ['vapor11-periodic-undrained6','mixed7-8-clock-undrained8']:
 for opt in ['O0','O2']:
  label='analytical-cde-calendar-'+case+'-'+opt+'-v1'
  q=json.loads(subprocess.check_output([sys.executable,'-B',cleanup,'allocate','--task','01a1e8b4-228b-75f1-8ac4-b07ca1e15713','--kind','build','--name',label,'--variant',opt,'--source-ref',source,'--recipe','analytical_cde_calendar_runtime.py actual original provider donor/kernel '+opt+' days35'],text=True));print('ALLOCATE',q,flush=True)
  build=pathlib.Path(q.get('path',q.get('directory','')));assert build.is_absolute()
  cmd=[sys.executable,'-B','tests/nomacro_drainage/analytical_cde_calendar_runtime.py','--input',str(E/'analytical-cde-calendar-drainage0-inputs-v1'/case),'--reference-work',r'C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--build-root',str(build),'--output',str(E/label),'--case',case,'--optimization',opt,'--days','35']
  p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(E/(label+'.controller.stdout.txt')).write_text(p.stdout);(E/(label+'.controller.stderr.txt')).write_text(p.stderr);rows.append(dict(case=case,optimization=opt,returncode=p.returncode,source=source));(E/'ANALYTICAL_CDE_CALENDAR_DRAINAGE0_CONTINUATION_V1.json').write_text(json.dumps(rows,indent=2)+'\n');print(case,opt,p.returncode,flush=True)
  if p.returncode:raise RuntimeError(p.stderr[-3000:])
