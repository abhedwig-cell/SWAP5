import pathlib,subprocess,json,sys,os,traceback
E=pathlib.Path(r"C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600/evidence")
N=pathlib.Path(r"C:/Users/Veldh012/swap5-implicit-conductivity-canonical01")
HEAD='e3d3c33456b330179fb5ac211a89f893d91c9152'
git=lambda *a:subprocess.check_output(['git',*a],cwd=N,text=True).strip()
assert git('status','--porcelain=v1','--untracked-files=all','--ignored')=='' and len(git('sparse-checkout','list').splitlines())==41
cases=[('SOURCE','app/hybrid_water/analytical_cde_calendar.py'),('RAW','integration/f-ci/nomacro-complete01/ANALYTICAL_CDE_CALENDAR_WINDOWS_RAW_V1.zip.part001'),('INHERITED','integration/f-ci/nomacro-complete01/INITIAL_STATE_COMPOSITION_ADMISSION_RAW_V1.zip'),('PUBLICATION','tests/publication/run_pub_p2e09_reference_threshold_freeze.sh')]
q=dict(candidate=HEAD,status='RUNNING',controls=[],model_executions=0,compiler_executions=0,never_merge=True)
def save():(E/'ANALYTICAL_CDE_CALENDAR_FINAL_NEGATIVES_OBSERVE_V3.json').write_text(json.dumps(q,indent=2)+'\n')
save()
try:
 for role,path in cases:
  branch='codex/nomacro-analytical-cde-calendar-'+role.lower()+'-negative03';git('switch','-c',branch,HEAD);assert git('rev-parse','HEAD')==HEAD and git('status','--porcelain=v1','--untracked-files=all','--ignored')==''
  target=N/path
  with target.open('ab') as f:f.write(b'\x00' if role in ('RAW','INHERITED') else b'\n# Actual committed bounded calendar negative control; never merge.\n')
  git('add','--',path);git('commit','-m','Negative control '+role+' for analytical CDE calendar public owner; never merge');head=git('rev-parse','HEAD');assert git('show','-s','--format=%P',head)==HEAD and git('diff','--name-only',HEAD,head)==path
  subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],cwd=N,check=True,capture_output=True,text=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==head
  if role=='PUBLICATION':
   selected=subprocess.run([sys.executable,'-B','tests/nomacro_drainage/frost_publication_scope.py'],cwd=N,env=dict(os.environ,GITHUB_EVENT_NAME='pull_request'),capture_output=True,text=True,timeout=1800);(E/'ANALYTICAL_CDE_CALENDAR_FINAL_PUBLICATION_SCOPE_NEGATIVE_V3.txt').write_text(selected.stdout+selected.stderr);assert selected.returncode==0 and 'PUBLICATION_REPLAY_SELECTED=true' in selected.stdout
  output=E/('ANALYTICAL_CDE_CALENDAR_FINAL_'+role+'_NEGATIVE_PUBLIC_V3')
  observed=subprocess.run([sys.executable,'-B',str(E/'ANALYTICAL_CDE_CALENDAR_PUBLIC_OBSERVE_V1.py'),'--cwd',str(N),'--output',str(output)],capture_output=True,text=True);assert observed.returncode==0,observed.stderr
  actual=json.loads(output.with_suffix('.json').read_text());assert actual['before']['head']==head and actual['before']==actual['after'] and actual['returncode']!=0 and actual['compiler_executions']==actual['model_executions']==0
  q['controls'].append(dict(role=role,branch=branch,head=head,path=path,public_returncode=actual['returncode'],seconds=actual['seconds'],actual_refusal=True));save();print(role,head,actual['seconds'],'REFUSED',flush=True)
 q['status']='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN41_PUBLIC_NEGATIVES_REFUSED'
except Exception as error:q.update(status='FAILED',error=repr(error),traceback=traceback.format_exc());raise
finally:save()
