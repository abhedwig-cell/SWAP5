* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-17 14:13:59

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.02 cm       0.4647E+02 mg/cm2
Initial :        75.19 cm       0.7519E+02 mg/cm2
            =============       =================
Change            2.83 cm      -0.2872E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.03
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    30.35
=========================    ============================
Sum            :    84.18    Sum               :    81.35


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2872E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.2872E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.36 cm       0.2615E+02 mg/cm2
Initial :        78.02 cm       0.4647E+02 mg/cm2
            =============       =================
Change           -1.65 cm      -0.2032E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.43
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    20.78
Bottom flux    :     0.00    Soil evaporation  :    13.69
                             Crack flux        :     0.00
                             Drainage level 1  :    32.74
=========================    ============================
Sum            :    71.98    Sum               :    73.63


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2032E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.2032E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.02 cm       0.1715E+02 mg/cm2
Initial :        76.36 cm       0.2615E+02 mg/cm2
            =============       =================
Change           -0.34 cm      -0.8998E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.38
                             Crack flux        :     0.00
                             Drainage level 1  :    22.84
=========================    ============================
Sum            :    80.55    Sum               :    80.89


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.8998E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.8998E+01

