"""Exact FCI93 original fixed-K native oracles, with registered Windows outputs."""
import hashlib,json,subprocess,sys,time,io,re,shlex
from contextlib import redirect_stdout
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');EV=Path(__file__).parent;W=EV.parent
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT);SHA=lambda raw:hashlib.sha256(raw).hexdigest();head=git('rev-parse','HEAD').decode().strip();out=EV/'canonical-legacy-fsi35-current-original-oracles-v2';out.mkdir();inputs=out/'immutable-inputs';inputs.mkdir();events=[];originals=[]
FKT='48336cb7f14e9246b03c23e549fe7354a93f9e6b';OWNER='5898e6616dbb6871a9f52d489038235ba1172cae';BASE='d8414c1ba11bee9f061622fd2495f631a57d2383'
for ref,path,name in [(FKT,'tests/fkt/fkt15_production_task2_stubs.f90','fkt15_stubs.f90'),(FKT,'tests/fkt/test_fkt15_production_task2.f90','fkt15_task2.f90'),(FKT,'tests/fkt/test_fkt15_production_surface_regimes.f90','fkt15_surface.f90'),(OWNER,'tests/fsi/test_fsi35_task2_dispatch_equivalence.f90','fsi35_dispatch.f90')]:
 raw=git('show',ref+':'+path);(inputs/name).write_bytes(raw);originals.append(dict(ref=ref,path=path,original_bytes=len(raw),original_sha256=SHA(raw),materialized=str(inputs/name)))
stub=inputs/'fkt15_stubs.f90';raw=stub.read_bytes();needle=b'module MOD_MvG\n  use MOD_grid, only: numnod\n  implicit none\n';assert raw.count(needle)==1 and b'integer :: swsophy = 0' not in raw;(inputs/'fkt15_stubs.original.f90').write_bytes(raw);stub.write_bytes(raw.replace(needle,needle+b'  integer :: swsophy = 0\n',1))
script=git('show',head+':tests/fci/run_fci93_non_m1_fixed_k_qualification.sh').decode();modules=re.search(r'(?ms)^MODULES=\(\n(.*?)^\)',script);assert modules;roots=[line.strip().strip('"').replace('$BUILD/fkt15_stubs.f90',str(stub)) for line in modules[1].splitlines() if line.strip()];assert len(roots)==25
helper='tests/support/augment_bartholomeus_backend_sources.py';code=git('show',BASE+':'+helper);(inputs/'original-immutable-compile-helper.py').write_bytes(code);saved=sys.argv;messages=io.StringIO()
try:
 sys.argv=[helper,'--all',*roots]
 with redirect_stdout(messages):exec(compile(code,helper,'exec'),dict(__file__=str(ROOT/helper),__name__='__main__'))
finally:sys.argv=saved
modules=messages.getvalue().splitlines();assert modules and modules[0]==str(stub) and len(modules)==len(set(modules));inventory={}
for value in modules+['src/legacy/b1_10_port/soilwater.f90']:
 path=Path(value);path=path if path.is_absolute() else ROOT/path;raw=path.read_bytes()
 if path.is_relative_to(ROOT):
  relative=path.relative_to(ROOT).as_posix();assert raw.replace(b'\r\n',b'\n')==git('show',head+':'+relative);inventory[relative]=dict(actual_raw_sha256=SHA(raw),git_blob=git('rev-parse',head+':'+relative).decode().strip())
flags=shlex.split(re.search(r'(?m)^FLAGS=\(([^\n]+)\)',script)[1]);assert flags==['-std=f2008','-ffree-line-length-none','-Wall','-Wextra','-fcheck=all','-fbacktrace','-ffpe-trap=invalid,zero,overflow','-fopenmp']
def run(label,cmd,log,native=False):
 started=time.monotonic();r=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90 if native else 180);(log/(label+'.stdout')).write_bytes(r.stdout);(log/(label+'.stderr')).write_bytes(r.stderr);events.append(dict(label=label,command=cmd,returncode=r.returncode,seconds=time.monotonic()-started,stdout=str(log/(label+'.stdout')),stderr=str(log/(label+'.stderr')),native_component=native));assert r.returncode==0,(label,r.returncode);return r.stdout
texts={}
for opt in ('O0','O2'):
 build=W/('canonical-legacy-FSI35-'+opt+'-v1');assert build.is_dir();log=out/opt;log.mkdir();common=[*flags,'-'+opt,'-J',str(build),'-I',str(build)];objects=[]
 for value in modules:
  path=Path(value);obj=build/(path.stem+'.o');run('compile-'+path.stem,['gfortran',*common,'-c',value,'-o',str(obj)],log);objects.append(str(obj))
 soil=build/'soilwater.o';run('compile-soilwater',['gfortran',*common,'-c','src/legacy/b1_10_port/soilwater.f90','-o',str(soil)],log)
 for case,input_name,required in [('task2','fkt15_task2.f90',['FKT15_ACCEPTED_TYPED_ROUTE=PASS','FKT15_ACCEPTED_SENSITIVITY=PASS','FKT15_EIGHT_WORKER_CAPSULE_ISOLATION=PASS','FKT15_RETRY_FAIL_CLOSED=PASS','FKT15_PRODUCTION_TASK2_GATE=PASS']),('surface','fkt15_surface.f90',['FKT15_PRODUCTION_SURFACE_FLUX=PASS','FKT15_PRODUCTION_ATMOSPHERIC_HEAD=PASS','FKT15_PRODUCTION_PONDED_HEAD=PASS','FKT15_PRODUCTION_SURFACE_HARD_MASS=PASS','FKT15_PRODUCTION_SURFACE_REGIMES_GATE=PASS']),('dispatch','fsi35_dispatch.f90',['FSI35_STANDALONE_WORKER_TASK2_EQUIVALENCE=PASS','FSI35_STANDALONE_USES_COMMON_SOLVER_SERVICE=PASS'])]:
  obj=build/(case+'-test.o');run(case+'-compile',['gfortran',*common,'-c',str(inputs/input_name),'-o',str(obj)],log);exe=build/(case+'-test.exe');extra=[str(soil)] if case=='dispatch' else [];run(case+'-link',['gfortran',*flags,'-'+opt,*objects,*extra,str(obj),'-o',str(exe)],log);text=run(case+'-execute',[str(exe)],log,True);assert all(mark.encode() in text for mark in required);texts[(opt,case)]=text
 assert git('rev-parse','HEAD').decode().strip()==head;print('CURRENT_ORIGINAL_FCI93_FIXED_K_TYPED_NATIVE_ORACLES_PASS',opt,len(modules),flush=True)
for case in ('task2','surface','dispatch'):assert texts[('O0',case)]==texts[('O2',case)]
q=dict(status='CURRENT_ORIGINAL_FCI93_FIXED_K_NATIVE_IMMUTABLE_ORACLES_O0_O2_PASS',actual_source=head,actual_source_inventory=inventory,actual_original_module_roots=roots,actual_transitive_compile_closure=modules,immutable_original_inputs=originals,actual_stub_interface_sha256=SHA(stub.read_bytes()),actual_original_compile_helper_sha256=SHA(code),flags=flags,events=events,compiler_driver_executions=sum(not e['native_component'] for e in events),native_component_executions=sum(e['native_component'] for e in events),SWAP_model_periods=0,canonical_source_successor_guard_still_required=True,canonical_admission=False)
with (EV/'CANONICAL_LEGACY_FSI35_CURRENT_ORIGINAL_ORACLES_V1.json').open('x') as f:json.dump(q,f,indent=2)
print(q['status'],q['compiler_driver_executions'],q['native_component_executions'])
