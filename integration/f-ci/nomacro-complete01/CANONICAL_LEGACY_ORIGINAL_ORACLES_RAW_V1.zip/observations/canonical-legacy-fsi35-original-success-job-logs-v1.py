"""Fetch full original GitHub job log after connector transport-size failure."""
import argparse,subprocess,os,http.client,json,urllib.request,urllib.parse,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--job',type=int,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root='C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01'
r=subprocess.run(['git','credential','fill'],cwd=root,input=b'protocol=https\nhost=github.com\npath=abhedwig-cell/SWAP5.git\n\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'),timeout=30)
if r.returncode:raise RuntimeError('Existing repository authentication unavailable; no credentials printed')
values=dict(line.split(b'=',1) for line in r.stdout.splitlines() if b'=' in line)
token=values.get(b'password')
if not token:raise RuntimeError('Repository credential has no API secret; no credentials printed')
connection=http.client.HTTPSConnection('api.github.com',timeout=60)
connection.request('GET','/repos/abhedwig-cell/SWAP5/actions/jobs/'+str(a.job)+'/logs',headers={'Authorization':'Bearer '+token.decode(),'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-qualified-evidence-log-preservation'})
response=connection.getresponse();status=response.status;location=response.getheader('Location');raw=response.read();connection.close()
del token,values,r
if status in (301,302,303,307,308):
 parsed=urllib.parse.urlparse(location or '')
 if parsed.scheme!='https' or not parsed.hostname:raise RuntimeError('Invalid GitHub-issued signed log redirect')
 # The second request has no repository credentials or Authorization header.
 with urllib.request.urlopen(urllib.request.Request(location,headers={'Accept-Encoding':'identity'}),timeout=120) as stream:
  if stream.status!=200:raise RuntimeError('Signed original log download failed')
  raw=stream.read();kind=stream.headers.get('Content-Type','')
else:
 if status!=200:raise RuntimeError('GitHub original log HTTP '+str(status))
 kind='API-direct'
text=raw.decode('utf8');assert 'b62b37600da90f93551aa9b384d3d32f0e4d72f6' in text
assert 'FCI93_FIXED_K_NATIVE_IMMUTABLE_ORACLE_O0_O2=PASS' in text and 'FCI93_FSI35_CURRENT_SEMANTIC_REPLAY=PASS' in text and 'FSI35_STANDALONE_WORKER_TASK2_EQUIVALENCE=PASS' in text
with a.output.open('xb') as out:out.write(raw)
print(json.dumps(dict(job_id=a.job,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),transport='Original GitHub authenticated job-log endpoint, credential-free signed second request',content_type=kind,has_actual_FSI_source_and_all_original_native_oracles_pass=True)))
