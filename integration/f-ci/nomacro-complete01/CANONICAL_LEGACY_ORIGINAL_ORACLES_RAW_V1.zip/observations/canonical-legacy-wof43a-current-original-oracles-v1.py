"""Run the exact original WOF/FVQ/CO2 component oracles in registered builds."""
import ast,hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');EV=Path(__file__).parent;W=EV.parent
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
SHA=lambda raw:hashlib.sha256(raw).hexdigest();head=git('rev-parse','HEAD').decode().strip();out=EV/'canonical-legacy-wof43a-current-original-oracles-v1';out.mkdir();events=[]
recipe=ROOT/'tests/fmig431/run_swap431_crop_co2_response.py';tree=ast.parse(recipe.read_text());body=[]
for node in tree.body:
 if isinstance(node,ast.With):break
 body.append(node)
namespace=dict(__file__=str(recipe));exec(compile(ast.Module(body=body,type_ignores=[]),str(recipe),'exec'),namespace);co2=namespace['order'];assert len(co2)==15
sources=['src/crop/mod_wofost_rate_table.f90','src/crop/mod_crop_et_canopy_view_provider.f90'];tests=['tests/fwof/test_fwof43a_crop_et_canopy_view_provider.f90','tests/fvq/test_fvq37_crop_et_canopy_view_independent.f90'];inventory={}
for path in [*map(lambda v:ROOT/v,sources+tests),*co2,recipe]:
 relative=path.relative_to(ROOT).as_posix();raw=path.read_bytes();expected=git('show',head+':'+relative);assert raw.replace(b'\r\n',b'\n')==expected;inventory[relative]=dict(actual_raw_sha256=SHA(raw),git_blob=git('rev-parse',head+':'+relative).decode().strip())
for path in [*sources,*tests,'tests/fmig431/test_swap431_crop_co2_response.f90',recipe.relative_to(ROOT).as_posix()]:assert git('show',head+':'+path)==git('show','4e55baf8ab1889d00cd8594c4dc5519d20430011:'+path)
def run(label,cmd,where):
 started=time.monotonic();r=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);(where/(label+'.stdout')).write_bytes(r.stdout);(where/(label+'.stderr')).write_bytes(r.stderr);events.append(dict(label=label,command=cmd,returncode=r.returncode,seconds=time.monotonic()-started,stdout=str(where/(label+'.stdout')),stderr=str(where/(label+'.stderr'))));assert r.returncode==0,(label,r.returncode);return r.stdout
texts={}
for opt in ('O0','O2'):
 build=W/('canonical-legacy-WOF43A-'+opt+'-v1');assert build.is_dir();log=out/opt;log.mkdir();common=['-'+opt,'-std=f2008','-ffree-line-length-none','-Wall','-Wextra','-Werror','-fcheck=all','-fbacktrace','-ffpe-trap=invalid,zero,overflow','-J',str(build),'-I',str(build)]
 for path in tests:
  name=Path(path).stem;exe=build/(name+'.exe');run(name+'-compile',['gfortran',*common,*sources,path,'-o',str(exe)],log);text=run(name+'-execute',[str(exe)],log);texts[(opt,name)]=text
  required=[b'FWO43A_CROP_ET_CANOPY_VIEW_TEST PASS'] if 'fwof' in name else [b'FVQ37_INDEPENDENT_GRID_CASES=29000',b'FVQ37_INDEPENDENT_EDGE_CASES=13',b'FVQ37_INDEPENDENT_CROP_ET_CANOPY_QUALIFICATION PASS']
  assert all(value in text.splitlines() for value in required)
 directory=build/'co2';directory.mkdir();flags=['-'+opt,'-std=f2008','-ffree-line-length-none','-fcheck=all','-fbacktrace','-ffpe-trap=invalid,zero,overflow','-J'+str(directory),'-I'+str(directory)];objects=[]
 for path in co2:
  obj=directory/(path.stem+'.o');run('co2-'+path.stem,['gfortran',*flags,'-c',str(path),'-o',str(obj)],log);objects.append(str(obj))
 exe=directory/'test.exe';run('co2-link',['gfortran',*flags,*objects,'-o',str(exe)],log);text=run('co2-execute',[str(exe)],log);assert b'SW431_CROP_CO2_RESPONSE=PASS' in text;texts[(opt,'co2')]=text
 assert git('rev-parse','HEAD').decode().strip()==head;print('ORIGINAL_CURRENT_WOF43A_FVQ37_CO2_COMPONENT_ORACLES_PASS',opt,flush=True)
for name in [Path(path).stem for path in tests]+['co2']:assert texts[('O0',name)]==texts[('O2',name)]
q=dict(status='ALL_ORIGINAL_CURRENT_WOF43A_FVQ37_29000_13_AND_CO2_O0_O2_ORACLES_PASS',actual_source=head,source_inventory=inventory,actual_original_CO2_compile_closure=[str(p.relative_to(ROOT)) for p in co2],events=events,compiler_driver_executions=38,native_component_executions=6,SWAP_model_periods=0,canonical_CI_source_reconciliation_still_required=True,canonical_admission=False)
with (EV/'CANONICAL_LEGACY_WOF43A_CURRENT_ORIGINAL_ORACLES_V1.json').open('x') as f:json.dump(q,f,indent=2)
print(q['status'])
