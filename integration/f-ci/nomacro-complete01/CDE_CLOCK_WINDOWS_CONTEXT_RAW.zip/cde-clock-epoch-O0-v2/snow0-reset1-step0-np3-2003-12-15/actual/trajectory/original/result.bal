* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 00:57:16

Period             :  2003-12-15  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        61.35 cm       0.1200E+03 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -13.83 cm       0.1200E+03 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     4.17    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     3.60
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -21.50    Soil evaporation  :     0.10
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :   -13.73    Sum               :     0.10


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.1200E+03    Root uptake    :  0.0000E+00
Bottom flux : -0.9333E-07
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.1200E+03    Sum            :  0.0000E+00

