"""Observe genuine current read-only regression and actual Git impact controls."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=W/'ci-checkout-scope07-impact-controls-v1'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
head=git('rev-parse','HEAD');assert head=='082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66'
status=git('status','--porcelain=v1','--untracked-files=all','--ignored');assert not status
observed=[]
def run(label,command,env=None):
    started=time.perf_counter();q=subprocess.run(command,cwd=R,env=env,capture_output=True,timeout=120)
    for suffix,raw in [('.stdout.txt',q.stdout),('.stderr.txt',q.stderr)]:
        with (E/('CI_CHECKOUT_SCOPE07_'+label+suffix)).open('xb') as f:f.write(raw)
    observed.append(dict(role=label,command=command,returncode=q.returncode,seconds=time.perf_counter()-started,stdout_sha256=hashlib.sha256(q.stdout).hexdigest(),stderr_sha256=hashlib.sha256(q.stderr).hexdigest()));q.check_returncode();return q
run('ORIGINAL11_UNIT_V3',[sys.executable,'-B','tests/hupsel51/test_successor.py'])
run('PROTOCOL14_LOCAL_V4',[sys.executable,'-B','tests/nomacro_drainage/ci_checkout_scope07.py','--output',str(E/'CI_CHECKOUT_SCOPE07_PROTOCOL14_LOCAL_V4.json')])
for role,base,expected in [('UNCHANGED_CURRENT_BASE','df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c',False),('GENUINE_OLDER_CHANGED_ENGINE','47124f4de18a752fc466d50e2752e843548e5fea',True)]:
    env=dict(os.environ,BASE=base,GITHUB_OUTPUT=str(D/(role+'.output')))
    q=run('HUPSEL_IMPACT_'+role+'_V2',[sys.executable,'-B','tests/nomacro_drainage/ci_checkout_scope07_hupsel_impact.py'],env)
    value=json.loads(q.stdout);assert value['actual_checkout']==head and value['actual_base']==base and value['run_models'] is expected
    assert (D/(role+'.output')).read_text()=='run_models='+str(expected).lower()+'\n'
    observed[-1]['actual_read_only_result']=value
assert git('rev-parse','HEAD')==head and git('status','--porcelain=v1','--untracked-files=all','--ignored')==status
q=dict(status='CURRENT_ORIGINAL11_AND14_WORKFLOW_PROTOCOL_AND_REAL_UNCHANGED_CHANGED_GIT_DEPENDENCY_CONTROLS_PASS',actual_observer=head,observations=observed,compiler_executions=0,model_executions=0,source_identity_projected=False)
with (E/'CI_CHECKOUT_SCOPE07_IMPACT_CONTROLS_V2.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],flush=True)
