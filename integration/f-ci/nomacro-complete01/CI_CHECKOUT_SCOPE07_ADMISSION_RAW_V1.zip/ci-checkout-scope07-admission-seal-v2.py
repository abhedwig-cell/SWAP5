"""Preserve genuine admission only after exact final-head and canonical gates."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
E=Path(__file__).resolve().parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
P=R/'integration/f-ci/nomacro-complete01'
candidate='082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66'
parent='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c'
synthetic='e2ad1538dae3fc1eefdfd9a5f4507043bdc0a9f3'
anchor='debb72039c28e136012c1cfa6cda157d25eecaee'
tree='ca63abf1777deac78cc899fcef9f02eb5fa24cee'
SHA=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((E/n).read_text())
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
api=read('CI_CHECKOUT_SCOPE07_PR1806_ACTUAL_GIT_API_V1.json')
actual=api['sha']
assert api['tree']['sha']==tree and [p['sha'] for p in api['parents']]==[parent,candidate]
for head in (candidate,synthetic,actual):
 assert git('rev-parse',head+'^{tree}')==tree
for head in (synthetic,actual):
 raw=(E/('CI_CHECKOUT_SCOPE07_PR1806_GENUINE_GIT_OBJECT_'+head+'.bin')).read_bytes()
 assert raw==subprocess.check_output(['git','cat-file','commit',head],cwd=R)
 assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==head
expected=json.loads((E/'CI_CHECKOUT_SCOPE07_CANDIDATE_PUBLIC_V5.stdout.txt').read_text())['coadmission']
assert (expected['contexts'],expected['short35_contexts'],expected['native_calendar_samples'],expected['exact_cold_windows'])==(648,602,4326,1864)
assert git('rev-parse','HEAD')==actual and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
observations={}
inputs=None
for role,version,head in [('CANDIDATE','V5',candidate),('ACTUAL_MERGE','V1',actual)]:
 for scope in ('PUBLIC','PUBLICATION'):
  label=f'CI_CHECKOUT_SCOPE07_{role}_{scope}_{version}'
  q=read(label+'.json');raw=(E/(label+'.stdout.txt')).read_bytes()
  assert q['returncode']==0 and q['before']==q['after']
  before=q['before'];assert before['head']==head and before['tree']==tree and not before['status']
  assert len(before['sparse'])==14 and len(before['original_project_files'])==56
  assert not (E/(label+'.stderr.txt')).read_bytes()
  if inputs is None:inputs=before['original_project_files']
  assert inputs==before['original_project_files']
  if scope=='PUBLIC':assert json.loads(raw)['coadmission']==expected
  else:
   assert b'PUBLICATION_REPLAY_SELECTED=false' in raw
   assert q['ordinary_python_default_dont_write_bytecode'] is False
   assert q['child_bytecode_environment_variables_absent']
  observations[label]=q['seconds']
negative=read('CI_CHECKOUT_SCOPE07_FINAL2_NEGATIVES_V1.json')
assert negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
assert negative['candidate']==candidate and len(negative['controls'])==4
assert {q['role'] for q in negative['controls']}=={'SOURCE','RAW','INHERITED','PUBLICATION'}
for q in negative['controls']:
 assert q['actual_refusal'] and q['actual_one_file_delta'] and q['exact_parent']==candidate
 assert git('show','-s','--format=%P',q['head'])==candidate
 assert git('diff','--name-only',candidate,q['head'])==q['path']
ci=read('CI_CHECKOUT_SCOPE07_PR1806_FINAL_ALL_CI_API_V2.json')
runs=ci['runs']['workflow_runs'];checks=ci['checks']['check_runs']
assert len(runs)==16 and len({x['workflow_id'] for x in runs})==14
assert all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion']=='success' for x in runs)
assert len(checks)==ci['checks']['total_count']
assert all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion'] in ('success','skipped') for x in checks)
for role in ('CO2','DVS','LRV','TIMEINT_STARTUP','TIMEINT_INVERSE','FCI_MODULAR'):
 label=f'CI_CHECKOUT_SCOPE07_PR1806_{role}_ORIGINAL_CI_V2.log'
 q=read(label+'.json');raw=(E/label).read_bytes()
 assert len(raw)==q['bytes'] and SHA(raw)==q['sha256']
 assert q['actual_source']==candidate
 assert candidate.encode() in raw and synthetic.encode() in raw
selection=read('CI_CHECKOUT_SCOPE07_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V2.json')
assert selection['actual_current_head']==candidate and selection['actual_parent']==parent and selection['unchanged_tracked_files']==1063
assert not git('diff',parent,actual,'--',*selection['unchanged_dependency_paths'])
assert len(checks)==48 and sum(x['conclusion']=='success' for x in checks)==30 and sum(x['conclusion']=='skipped' for x in checks)==18

hupsel=json.loads((E/'CI_CHECKOUT_SCOPE07_PR1806_HUPSEL_IMPACT_ORIGINAL_JOBS_V1.json').read_text())
assert len(hupsel['jobs'])==2
assert {(x['name'],x['conclusion']) for x in hupsel['jobs']}=={('dependency-impact','success'),('qualification','skipped')}
assert all(x['status']=='completed' for x in hupsel['jobs'])
hupsel_log=(E/'CI_CHECKOUT_SCOPE07_PR1806_HUPSEL_IMPACT_ORIGINAL_CI_V1.log').read_bytes()
assert b'e2ad1538dae3fc1eefdfd9a5f4507043bdc0a9f3' in hupsel_log
for expected in [b'"unchanged_scientific_tracked_files": 1883',b'"original_model_job_body_identical": true',b'"run_models": false']:
 assert expected in hupsel_log
assert not git('diff','df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c','082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66','--','app','src','tools','reference','examples','CMakeLists.txt','Makefile','pyproject.toml','requirements.txt','integration/f-ci/hupsel51-water-balance','integration/nomacro-coverage01')

name='CI_CHECKOUT_SCOPE07_ADMISSION_RAW_V1';members={}
# Science archives are already committed once, with exact byte manifests. Preserve
# the original observer/CI/failure records and actual controllers here, not copies
# of those large scientific ZIPs.
paths=[p for p in E.iterdir() if p.is_file() and p.name.startswith('CI_CHECKOUT_SCOPE07_')
       and p.suffix in ('.json','.txt','.log','.bin')]
paths += [p for p in E.iterdir() if p.is_file() and p.name.startswith('ci-checkout-scope07-') and p.suffix=='.py']
paths += [p for p in E.iterdir() if p.is_file() and p.name.startswith('CI_CHECKOUT_SCOPE07_UPSTREAM_ACTION_') and p.suffix in ('.ts','.yml')]
paths += [p for p in E.glob('CI_CHECKOUT_SCOPE07_PR1806_FCI_MODULAR_ORIGINAL_CI_V2.log.*') if p.suffix in ('.zip','.gz')]
with zipfile.ZipFile(E/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):
  raw=p.read_bytes();assert p.name not in members
  z.writestr(p.name,raw);members[p.name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(E/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,item in members.items():
  raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=(E/(name+'.zip')).read_bytes();digest=SHA(raw);parts=[];chunk=25*1024*1024
for index,offset in enumerate(range(0,len(raw),chunk),1):
 piece=raw[offset:offset+chunk];file=name+'.zip'+('.part'+str(index).zfill(3) if len(raw)>chunk else '');(P/file).write_bytes(piece);assert (P/file).read_bytes()==piece;parts.append(dict(file=file,bytes=len(piece),sha256=SHA(piece)))
manifest=dict(status='ACTUAL_CANONICAL648_ORIGINAL_PUBLIC_ORDINARY_PUB_CI_NEGATIVES_AND_SIGNED_OBJECTS_PRESERVED',
 archive=name+'.zip',bytes=len(raw),sha256=digest,
 parts=parts,members=members,
 canonical_admission=True,actual_merge=actual,qualified_candidate=candidate,source_anchor=anchor,
 whole_tree=tree,coadmission=expected,actual_public_observations=observations,
 POND_current_model_replay='NOT_SELECTED_EXISTING_PRIVATE_FROST_PATH_SELECTION_PARENT_SUCCESS_RETAINED',
 HUPSEL_current_model_replay='NOT_SELECTED_EXACT1883_SCIENTIFIC_DEPENDENCIES_AND_ORIGINAL_MODEL_JOB_UNCHANGED',
 successful_workflows=len(runs),successful_checks=sum(x['conclusion']=='success' for x in checks),
 skipped_checks=sum(x['conclusion']=='skipped' for x in checks),
 full_model_periods_replayed_for_CI_or_observer_repairs=0,unchanged_MCSOL_model_replay='NOT_SELECTED_IMPACT_1063_EXACT_DEPENDENCY_FILES',
 scientific_change_class='D_READ_ONLY_BUILD_AND_EVIDENCE_TRANSPORT',new_scientific_contexts=0,
 original_scientific_producer='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6',
 original_scientific_producer_rebound=False,
 whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',
 global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
receipt=dict(status='ACTUAL_CANONICAL648_CHECKOUT_TRANSPORT_ADMISSION_VERIFIED',PR=1806,
 actual_merge=actual,qualified_candidate=candidate,source_anchor=anchor,whole_tree=tree,
 previous_canonical=parent,ordered_parents=[parent,candidate],synthetic_merge=synthetic,
 admission_archive_sha256=digest,coadmission=expected,canonical_admission=True,
 scientific_change_class='D_READ_ONLY_BUILD_AND_EVIDENCE_TRANSPORT',new_scientific_contexts=0,
 original_scientific_producer='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6',
 original_scientific_producer_rebound=False,
 whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',
 global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
for filename,value in [(name+'.json',manifest),('CI_CHECKOUT_SCOPE07_MERGE_RECEIPT_V1.json',receipt)]:
 with (P/filename).open('x',encoding='utf8') as f:json.dump(value,f,indent=2);f.write('\n')
print(manifest['status'],len(raw),digest,len(members),flush=True)




