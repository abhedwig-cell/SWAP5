"""Freeze actual transport authority and wire the sole joint owner."""
from pathlib import Path
import json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert git('branch','--show-current')=='codex/nomacro-ci-checkout-scope07' and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
parent_name='CI_CHECKOUT_SCOPE07_CANONICAL648_PARENT_AUDIT_V1.json';parent=json.loads((E/parent_name).read_text());assert parent['actual_observer']==git('rev-parse','HEAD') and parent['result']['receipt']['coadmission']['contexts']==648
assert parent['result']['actual_parent']=='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c'
shutil.copyfile(E/parent_name,P/parent_name)
path=R/'tests/nomacro_drainage/initial_profile_age_groundwater_verify.py';s=path.read_text();before=' import frost_implicit_hys2_verify as hys2_owner\n return hys2_owner.';after=' import ci_checkout_scope07_verify as checkout_owner\n return checkout_owner.';assert s.count(before)==4;s=s.replace(before,after);compile(s,str(path),'exec');path.write_text(s,encoding='utf8',newline='\n')
path=P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json';c=json.loads(path.read_text());c.update(status='LOCAL_PROFILES_AND_GENUINE648_PARENT_PASS_JOINT_OWNER_WIRED_CURRENT_PUBLIC_CI_CANONICAL_PENDING',admission_authority_state='WIRED_SOURCE_FREEZE_AND_ACTUAL_CURRENT_GATES_PENDING',parent_admission_audit=parent_name,scientific_qualification='EXACT_ENGINE_PROGRAMS_INPUTS_AND_ORIGINAL_ACCEPTED648_EVIDENCE_INHERITED_NO_NEW_SCIENTIFIC_PASS_CLAIM')
path.write_text(json.dumps(c,indent=2)+'\n')
path=P/'STATUS.json';s=json.loads(path.read_text());s['ci_checkout_scope07'].update(status=c['status'],admission_authority_state=c['admission_authority_state'],parent_admission_audit=parent_name,scientific_qualification=c['scientific_qualification'])
s['next_action']=s['next_code_change']='Run actual frozen07 clean PUBLIC and ordinary publication, four real committed pushed controls, and selected current checkout CI. Keep original physical compiler/model producer identities; no scientific model period replay. Then actual canonical observation and receipt.'
s['recovery_point']='Actual canonical648 df00 original admission SHA686d0245 and genuine signed parent chain freshly pass.07 current43checkout-only inverses,26source/component+17complete-evidence profiles locally pass; all engine/source/program/input/evidence bytes inherit unchanged648 qualification. Joint owner now wired; current public/CI/canonical07 gates remain pending.'
path.write_text(json.dumps(s,indent=2)+'\n')
paths=[P/parent_name,R/'tests/nomacro_drainage/initial_profile_age_groundwater_verify.py',P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json',P/'STATUS.json']
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*[p.relative_to(R).as_posix() for p in paths]],cwd=R,check=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Freeze evidence-complete checkout authority on genuine canonical648'],cwd=R,check=True)
anchor=git('rev-parse','HEAD');path=R/'tests/nomacro_drainage/ci_checkout_scope07_verify.py';s=path.read_text();old="SEALED='"+'0'*40+"'";assert s.count(old)==1;s=s.replace(old,"SEALED='"+anchor+"'");path.write_text(s,encoding='utf8',newline='\n')
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',path.relative_to(R).as_posix()],cwd=R,check=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Bind actual checkout authority source anchor for current admission gates'],cwd=R,check=True)
q=dict(actual_source_anchor=anchor,actual_candidate=git('rev-parse','HEAD'),actual_tree=git('rev-parse','HEAD^{tree}'),actual_canonical_parent='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c',scientific_producer_inherited_not_rebound='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6',new_scientific_contexts=0,coadmission_contexts=648,canonical_admission=False)
with (E/'CI_CHECKOUT_SCOPE07_FROZEN_CANDIDATE_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps(q),flush=True)
