"""Persist the next transport-only batch in the same owned working checkout."""
from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';D=E/'CI_CHECKOUT_SCOPE07_DRAFT_V1'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert git('branch','--show-current')=='codex/nomacro-ci-checkout-scope07' and git('rev-parse','HEAD')=='cb712974e37e41256877d9770a0af071afe241dd'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
contract=json.loads((D/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json').read_text());paths=[]
for name in contract['files']:
 source=D/name;target=R/name;assert hashlib.sha256(subprocess.check_output(['git','show','HEAD:'+name],cwd=R)).hexdigest()==contract['files'][name]['before_lf_sha256']
 shutil.copyfile(source,target);paths.append(target)
path=R/'tests/nomacro_drainage/ci_checkout_scope07.py';assert not path.exists();shutil.copyfile(D/'tests/nomacro_drainage/ci_checkout_scope07.py',path);compile(path.read_text(),str(path),'exec');paths.append(path)
path=R/'tests/nomacro_drainage/ci_checkout_scope07.rules';path.write_text(contract['rules'],encoding='utf8',newline='\n');paths.append(path)
path=P/'CI_CHECKOUT_SCOPE07_READ_ONLY_FAILURES_V1.json';shutil.copyfile(E/path.name,path);paths.append(path)
path=P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json';path.write_text(json.dumps(contract,indent=2)+'\n');paths.append(path)
path=P/'CI_CHECKOUT_SCOPE07_UPSTREAM_ACTION_V7.yml';shutil.copyfile(E/path.name,path);paths.append(path)
path=R/'docs/development/NOMACRO_CI_CHECKOUT_SCOPE07.md'
path.write_text('''# No-macro CI checkout transport

Status: implemented; actual current CI and canonical admission pending.
This is an ACCELERATE02 build/evidence transport change. It adds no model scope,
physical equations, numerical policy, compiler flags, tolerances or state.

Thirteen selected workflows contain43 unfiltered, unsparse checkout steps.
The existing sparse LRV workflow is retained unchanged. The proposed inputs use
partial clone and a non-cone checkout that includes every source, test, reference
input, document and JSON metadata file. Only complete ZIPs and three-digit ZIP
parts directly under integration/f-ci/nomacro-complete01 are omitted from the
working directory. Their genuine Git objects remain the evidence authority;
readers retrieve and verify those exact original bytes through GitArchiveSource.
No fabricated working files or projected HEAD are introduced.

Every workflow has a complete literal inverse against its real qualified parent.
Local YAML comparison confirms all other values and all run commands stay
identical. Real Git check-rules on the16759-path qualified candidate selects
every source/input/metadata path and excludes exactly739 archive paths. These
are selection checks, not a measured CI speedup or scientific qualification.

The dependency candidate is PR1805 cb712974e37e41256877d9770a0af071afe241dd.
Its new64-context science is already independently qualified, but its canonical
admission is still pending. Original producer identities and raw evidence are
retained. No unchanged scientific model periods are replayed for this change.

The existing STATUS.json remains the recovery point. After actual PR1805
admission, reconcile its genuine merge normally, retain its original receipt,
and qualify the actual current checkout/dependency postimage and selected CI.
Historical closure remains PARTIAL, whole science NOT_QUALIFIED, global
family/gap counts UNKNOWN and fixed RC3 unchanged.
''',encoding='utf8',newline='\n');paths.append(path)
path=P/'STATUS.json';s=json.loads(path.read_text());s['branch']=s['working_branch']=s['active_branch']='codex/nomacro-ci-checkout-scope07';s['frost_implicit_hys2_year06'].update(PR=1805,qualified_candidate='cb712974e37e41256877d9770a0af071afe241dd',source_anchor='427974eb7b669856da9876ad39ba73bed5d437a5',actual_candidate_public_seconds=913.4430833002552,actual_candidate_ordinary_publication_seconds=549.4899051999673,four_real_pushed_negative_controls='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED',canonical_admission=False)
s['ci_checkout_scope07']=dict(status='IMPLEMENTED_NOT_CURRENT_CI_QUALIFIED',classification='D_READ_ONLY_BUILD_AND_EVIDENCE_TRANSPORT',contract='CI_CHECKOUT_SCOPE07_CONTRACT_V1.json',qualified_dependency_candidate=contract['qualified_dependency_candidate'],dependency_PR=1805,dependency_canonical_admission_pending=True,workflow_files=13,checkout_steps=43,engine_source_changed=False,model_periods_replayed=0,canonical_admission=False)
s['next_action']=s['next_code_change']='Run current07 literal/Git path audit and persist result. Poll existing PR1805 selected CI to terminal. Return the same checkout to actual06 candidate cb7129 before premerge closure/merge/actual canonical observations. Keep both scientific source identities original; reconcile07 with the genuine admitted648 merge normally afterward.'
s['recovery_point']='06 candidate cb7129 real clean14/56 PUBLIC913.443s and ordinaryPUB549.490s PASS, all four actual committed pushed negatives refused. PR1805 current14 admission CI still running; canonical remains47124/600. Same checkout now holds separate07 transport proposal (13workflows/43checkout steps), no source/model changes or extra checkout. Return06 before final admission; preserve07 branch.'
path.write_text(json.dumps(s,indent=2)+'\n');paths.append(path)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--sparse','--',*[p.relative_to(R).as_posix() for p in paths]],cwd=R,check=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Bound selected CI checkouts to source and explicit Git evidence transport'],cwd=R,check=True)
print('NEXT_TRANSPORT_BATCH_PERSISTED_SAME_CHECKOUT_DEPENDENCY_PR1805_CANONICAL_PENDING',git('rev-parse','HEAD'),flush=True)
