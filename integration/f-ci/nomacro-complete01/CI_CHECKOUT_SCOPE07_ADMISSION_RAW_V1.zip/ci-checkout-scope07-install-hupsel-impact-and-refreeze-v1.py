"""Install private proportional selection after both genuine observers ended."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip();SHA=lambda b:hashlib.sha256(b).hexdigest()
C='acfa84457ff50d148404b829266bfd887721be03'
assert git('rev-parse','HEAD')==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
for mode in ('PUBLIC','PUBLICATION'):
    q=json.loads((E/('CI_CHECKOUT_SCOPE07_CANDIDATE_'+mode+'_V3.json')).read_text());assert q['returncode']==0 and q['before']==q['after'] and q['before']['head']==C
proposal=json.loads((E/'CI_CHECKOUT_SCOPE07_HUPSEL_SELECTION_PROPOSAL_V1.json').read_text());workflow=proposal['workflow']
for relative in [workflow,'tests/nomacro_drainage/ci_checkout_scope07_hupsel_impact.py']:
    shutil.copyfile(E/'ci-checkout-scope07-hupsel-selection-proposal-v1'/relative,R/relative)
contract=json.loads((P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json').read_text())
contract['read_only_runtime_witnesses'][workflow]={k:proposal[k] for k in ['before_lf_sha256','proposed_lf_sha256','ordered_literal_edits']}
contract['read_only_runtime_witnesses'][workflow]['purpose']='Private exact scientific source/input/build and original model-job comparison; original scientific job commands and all criteria retained. Unchanged dependencies reuse prior qualification without full model periods.'
contract['read_only_workflow_selection_paths']=[workflow]
contract.update(workflows=14,existing_checkout_only_workflows=13,existing_checkout_only_steps=43,additional_read_only_dependency_checkout_steps=1,status='EXACT_HISTORICAL_TEST_WITNESS_AND_PRIVATE_HUPSEL_DEPENDENCY_SELECTION_CURRENT_GATES_PENDING')
(P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json').write_text(json.dumps(contract,indent=2)+'\n')
path=R/'tests/nomacro_drainage/ci_checkout_scope07.py';s=path.read_text()
a="    assert changes==set(contract['files']) and len(changes)==13"
b="    workflow_witnesses=set(contract.get('read_only_workflow_selection_paths',[]))\n    assert workflow_witnesses=={'.github/workflows/hupsel51-water-balance.yml'}\n    assert changes==set(contract['files'])|workflow_witnesses and len(changes)==14"
assert s.count(a)==1;s=s.replace(a,b)
a='    assert steps==43\n'
b='''    for path in sorted(workflow_witnesses):
        item=contract['read_only_runtime_witnesses'][path]
        before=git('show',base+':'+path);actual=(R/path).read_bytes().replace(b'\\r\\n',b'\\n')
        assert SHA(before)==item['before_lf_sha256'] and SHA(actual)==item['proposed_lf_sha256']
        assert actual==git('show','HEAD:'+path)
        text=before.decode();parts=[];cursor=0
        for edit in item['ordered_literal_edits']:
            assert edit['before']=='' and edit['base_start']==edit['base_end']>=cursor
            parts.extend((text[cursor:edit['base_start']],edit['after']));cursor=edit['base_end']
        parts.append(text[cursor:]);assert ''.join(parts).encode()==actual
        condition="    needs: dependency-impact\\n    if: needs.dependency-impact.outputs.run_models == 'true'\\n"
        heading='  qualification:\\n';original_body=text.split(heading,1)[1];current_body=actual.decode().split(heading,1)[1]
        assert current_body==condition+original_body
        observations.append(dict(path=path,before_sha256=SHA(before),actual_sha256=SHA(actual),new_read_only_checkout_steps=1,original_model_job_body_identical=True))
    assert steps==43
'''
assert s.count(a)==1;s=s.replace(a,b)
a='checkout_steps=43,complete_evidence_checkout_steps='
b='checkout_steps=43,new_read_only_dependency_checkout_steps=1,total_changed_or_added_checkout_steps=44,hupsel_original_model_job_body_preserved=True,complete_evidence_checkout_steps='
assert s.count(a)==1;s=s.replace(a,b);compile(s,str(path),'exec');path.write_text(s,encoding='utf8',newline='\n')
path=R/'tests/nomacro_drainage/ci_checkout_scope07_verify.py';s=path.read_text();a="    assert protocol['checkout_steps']==43 and protocol['fci_canonical_keeps_complete_versioned_evidence'] and not protocol['engine_source_changed']";assert s.count(a)==1;s=s.replace(a,a+"\n    assert protocol['new_read_only_dependency_checkout_steps']==1 and protocol['total_changed_or_added_checkout_steps']==44 and protocol['hupsel_original_model_job_body_preserved']");path.write_text(s,encoding='utf8',newline='\n')
cancel=json.loads((E/'CI_CHECKOUT_SCOPE07_PR1806_UNNEEDED_HUPSEL_CANCEL_V1.json').read_text());assert cancel['http_status']==202
failure=dict(status='UNNEEDED_OLD_HUPSEL_PERIOD_RUN_CANCELLED_DURING_CHECKOUT_PRIVATE_EXACT_DEPENDENCY_SELECTION_ADDED',actual_prior_candidate=C,original_cancel_record=cancel,all_model_and_compiler_steps_skipped_before_cancel=True,full_model_periods_executed=0,new_physical_source_or_inputs_changed=False,original_model_job_commands_retained=True,current_gates_require_fresh_postimage=True)
name='CI_CHECKOUT_SCOPE07_READ_ONLY_FAILURES_V4.json'
with (E/name).open('x',encoding='utf8') as f:json.dump(failure,f,indent=2);f.write('\n')
(P/name).write_text(json.dumps(failure,indent=2)+'\n')
status=json.loads((P/'STATUS.json').read_text());status['ci_checkout_scope07'].update(status=contract['status'],workflow_files=14,existing_checkout_only_workflows=13,existing_checkout_only_steps=43,new_read_only_dependency_checkout_steps=1,unnecessary_old_hupsel_run_cancelled=True,unnecessary_old_model_periods_executed=0)
status['next_action']='Verify exact current14-workflow transport plus private affected-Hupsel selection, fresh actual PUBLIC/publication and four real controls. Observe all current CI and real canonical merge. Preserve original failed/cancelled runs. Then install and qualify prepared16-case undrained Frost08 composition.'
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
path=R/'docs/development/NOMACRO_CI_CHECKOUT_SCOPE07.md';s=path.read_text();s+='\nA fourteenth workflow now receives one separate read-only dependency-selection checkout. The original Hupsel full-model job body and every command/criterion are retained byte-for-byte. Its current model periods run only when the real base-versus-current scientific source, input/build surface or original scientific job body changes. A test-only checkout witness therefore reuses prior scientific evidence; it does not claim a new Hupsel model PASS. The initially triggered old run was cancelled during checkout, before provider preparation, compilation or any model period. Existing43 checkout insertions remain26source/component and17complete-evidence; the additional private selector makes44 changed/added checkout steps in total.\n';path.write_text(s,encoding='utf8',newline='\n')
paths=[workflow,'tests/nomacro_drainage/ci_checkout_scope07_hupsel_impact.py','tests/nomacro_drainage/ci_checkout_scope07.py','tests/nomacro_drainage/ci_checkout_scope07_verify.py','integration/f-ci/nomacro-complete01/CI_CHECKOUT_SCOPE07_CONTRACT_V1.json','integration/f-ci/nomacro-complete01/'+name,'integration/f-ci/nomacro-complete01/STATUS.json','docs/development/NOMACRO_CI_CHECKOUT_SCOPE07.md']
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*paths],cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Select Hupsel model periods only for changed actual scientific dependencies'],cwd=R,check=True)
anchor=git('rev-parse','HEAD');path=R/'tests/nomacro_drainage/ci_checkout_scope07_verify.py';s=path.read_text();s,n=re.subn(r"(?m)^SEALED='[0-9a-f]{40}'$","SEALED='"+anchor+"'",s);assert n==1;path.write_text(s,encoding='utf8',newline='\n')
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',path.relative_to(R).as_posix()],cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Freeze real proportional checkout source for final admission gates'],cwd=R,check=True)
q=dict(actual_candidate=git('rev-parse','HEAD'),source_anchor=anchor,actual_tree=git('rev-parse','HEAD^{tree}'),actual_canonical_parent='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c',previous_candidate=C,PR=1806,new_scientific_contexts=0,coadmission_contexts=648,canonical_admission=False)
with (E/'CI_CHECKOUT_SCOPE07_FROZEN_CANDIDATE_V4.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps(q),flush=True)
