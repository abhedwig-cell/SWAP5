"""Fresh complete unaffected MC-SOL dependency comparison; no current model claim."""
from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d';B='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head==C
prior_path=E/'FROST_IMPLICIT_HYS2_YEAR06_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json';prior_raw=prior_path.read_bytes();prior=json.loads(prior_raw);paths=prior['unchanged_dependency_paths']
before=git('ls-tree','-r',B,'--',*paths);after=git('ls-tree','-r',C,'--',*paths)
assert before==after and len(before.splitlines())==1063 and not git('diff',B,C,'--',*paths)
assert git('ls-tree','-r',prior['actual_parent'],'--',*paths)==before
q=dict(status='UNCHANGED_MCSOL_SCIENTIFIC_MODEL_RUNNERS_INPUTS_AND_WORKFLOWS_EXACT_INHERITED_CURRENT_SHARED_AUTHORITY_SEPARATELY_SELECTED',actual_current_head=C,actual_parent=B,unchanged_dependency_paths=paths,unchanged_tracked_files=1063,canonical_git_ls_tree_raw_sha256=hashlib.sha256(before).hexdigest(),prior_exact_selection_sha256=hashlib.sha256(prior_raw).hexdigest(),original_actual_success_logs=prior['original_actual_success_logs'],current_MCSOL_model_replay='NOT_SELECTED_IMPACT',fresh_current_MCSOL_scientific_PASS_claimed=False,model_executions=0,compiler_executions=0)
assert git('rev-parse','HEAD').decode().strip()==head
with (E/'CI_CHECKOUT_SCOPE07_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],q['unchanged_tracked_files'],flush=True)
