"""Add real-source and genuine648 admission authorities, without physics changes."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage'
def put(name,s):
 compile(s,name,'exec')
 with (T/name).open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(T/'frost_implicit_hys2_metadata.py').read_text().replace('FROST_IMPLICIT_HYS2_YEAR06_','CI_CHECKOUT_SCOPE07_')
put('ci_checkout_scope07_metadata.py',s)
s=(T/'frost_implicit_hys2_inherited_custody.py').read_text().replace('47124f4de18a752fc466d50e2752e843548e5fea','df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c').replace('600','648')
put('ci_checkout_scope07_inherited_custody.py',s)
s=(T/'frost_implicit_hys2_parent_admission.py').read_text()
s=s.replace('from frost_implicit_plate_parent_admission import parent_admission as prior_admission','from frost_implicit_hys2_parent_admission import parent_admission as prior_admission')
for old,new in {
 '47124f4de18a752fc466d50e2752e843548e5fea':'df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c',
 'cb5946a6d8205462d96495a39611f72f570db58a':'cb712974e37e41256877d9770a0af071afe241dd',
 '06b31c0ea8d0bb087441be1dab0d1f1ad9236fcc':'c65c7eb92cdc82ab786f62cb96bf376404e45130',
 '413af4b36a23ba07972ec04d7ed385ea82d1d4fc46b64e42edeaab7c83a5d6e4':'686d02451f9e5f3b5f624a10fea5c464000d91abc94d46243a0c5ef3526d1b7f',
 '087fc67db3e1e58d45215522eb284e89cb6c12f1':'47124f4de18a752fc466d50e2752e843548e5fea',
 'FROST_IMPLICIT_PLATE05':'FROST_IMPLICIT_HYS2_YEAR06','PR1804':'PR1805',
 'CANONICAL600':'CANONICAL648','canonical600':'canonical648',
 'PRIOR568':'PRIOR600','prior_568_admission':'prior_600_admission',
}.items():
 assert old in s,old;s=s.replace(old,new)
put('ci_checkout_scope07_parent_admission.py',s)
s=(T/'frost_implicit_hys2_source_custody.py').read_text()
s=s.replace('from frost_implicit_plate_source_custody import DOMAINS as PARENT_DOMAINS','from frost_implicit_hys2_source_custody import DOMAINS as PARENT_DOMAINS')
s=s.replace('from frost_implicit_hys2_input_contract import source as complete_inverse','from ci_checkout_scope07 import audit as complete_inverse')
s=s.replace('47124f4de18a752fc466d50e2752e843548e5fea','df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c')
s=s.replace("COMPILER='23850bf112e4312745b056e5517b95e13e2af53b'","ENGINE_BASE=BASE")
s=s.replace("git('diff',COMPILER,'HEAD'","git('diff',ENGINE_BASE,'HEAD'")
s=s.replace("SELF='tests/nomacro_drainage/frost_implicit_hys2_verify.py'","SELF='tests/nomacro_drainage/ci_checkout_scope07_verify.py'")
s=s.replace('docs/science/NOMACRO_FROST_IMPLICIT_HYS2_YEAR06.md','docs/development/NOMACRO_CI_CHECKOUT_SCOPE07.md')
s=s.replace('frost_implicit_hys2_metadata','ci_checkout_scope07_metadata').replace('FROST_IMPLICIT_HYS2_YEAR06_CONTRACT','CI_CHECKOUT_SCOPE07_CONTRACT')
s=s.replace("before=' import frost_implicit_plate_verify as plate_owner\\n return plate_owner.'+name+'('+args+')\\n'", "before=' import frost_implicit_hys2_verify as hys2_owner\\n return hys2_owner.'+name+'('+args+')\\n'")
s=s.replace("after=' import frost_implicit_hys2_verify as hys2_owner\\n return hys2_owner.'+name+'('+args+')\\n'", "after=' import ci_checkout_scope07_verify as checkout_owner\\n return checkout_owner.'+name+'('+args+')\\n'")
s=s.replace('REAL_IMPLICIT_HYS2_BOUNDARY_HEAD','REAL_CHECKOUT_PROTOCOL_HEAD')
put('ci_checkout_scope07_source_custody.py',s)
print('CURRENT_REAL_SOURCE_FRESH_INHERITED_AND_GENUINE648_PARENT_AUTHORITIES_PREPARED_NOT_YET_WIRED')
