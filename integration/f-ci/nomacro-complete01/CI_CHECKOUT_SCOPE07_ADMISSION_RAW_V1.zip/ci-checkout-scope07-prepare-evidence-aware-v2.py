"""Refine draft profiles: frozen F-CI authority jobs keep complete evidence."""
from pathlib import Path
E=Path(__file__).resolve().parent
s=(E/'ci-checkout-scope07-prepare-proposal-v1.py').read_text()
def edit(before,after):
 global s
 assert s.count(before)==1,before;s=s.replace(before,after)
edit("BASE='cb712974e37e41256877d9770a0af071afe241dd'","BASE='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c'")
edit("assert inventory['actual_source']==BASE and inventory['unfiltered_unsparse_checkouts']==43", "assert inventory['actual_source']=='cb712974e37e41256877d9770a0af071afe241dd' and inventory['unfiltered_unsparse_checkouts']==43\nassert git('rev-parse',inventory['actual_source']+'^{tree}')==git('rev-parse',BASE+'^{tree}')")
edit("D=E/'CI_CHECKOUT_SCOPE07_DRAFT_V1'","D=E/'CI_CHECKOUT_SCOPE07_DRAFT_V2'")
edit("assert excluded and included==names-excluded", "assert excluded and included==names-excluded\nfull_rules=D/'complete-evidence.rules';full_rules.write_text('/*\\n',encoding='utf8',newline='\\n')\nfull_selected=git('sparse-checkout','check-rules','--no-cone','--rules-file',str(full_rules),'-z',input=all_raw)\nassert set(full_selected.decode().rstrip('\\0').split('\\0'))==names")
edit(" raw=git('show',BASE+':'+path);before=raw.decode();assert '\\r' not in before", " profile='complete_evidence' if path=='.github/workflows/fci-canonical.yml' else 'source_and_metadata'\n rules_for_checkout='/*\\n' if profile=='complete_evidence' else RULES\n raw=git('show',BASE+':'+path);before=raw.decode();assert '\\r' not in before")
edit("for line in RULES.splitlines()", "for line in rules_for_checkout.splitlines()")
edit("changed.append(dict(job=job_key.value,step_index=index,action=uses.value))", "changed.append(dict(job=job_key.value,step_index=index,action=uses.value,profile=profile))")
edit("config['sparse-checkout']==RULES", "config['sparse-checkout']==('/*\\n' if item['profile']=='complete_evidence' else RULES)")
edit("qualified_dependency_candidate=BASE", "qualified_dependency_candidate='cb712974e37e41256877d9770a0af071afe241dd',actual_canonical_dependency=BASE")
edit("rules=RULES,workflows=13", "rules=RULES,profiles=dict(source_and_metadata=RULES,complete_evidence='/*\\n'),fci_canonical_retains_complete_versioned_evidence=True,real_Git_complete_evidence_selection_sha256=SHA(full_selected),workflows=13")
out=E/'ci-checkout-scope07-prepare-proposal-v2.py'
with out.open('x',encoding='utf8',newline='\n') as f:f.write(s)
compile(s,str(out),'exec');print('PREPARED_CONSERVATIVE_FULL_EVIDENCE_PROFILE_FOR_FROZEN_FCI_AUTHORITIES_NO_R_MUTATION')
