"""Bind final genuine candidate082, actual16 workflows and private model skip."""
from pathlib import Path
E=Path(__file__).resolve().parent
edits=[('39d00d6b1d15dbe1132a0b6a2eb361d2459e697d','082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66'),
       ('02f5614a81957103919f29de511fb893b55bf7f8','e2ad1538dae3fc1eefdfd9a5f4507043bdc0a9f3'),
       ('c344878cd50f3e8893f9ee6b7d459041db869157','debb72039c28e136012c1cfa6cda157d25eecaee'),
       ('bacad1a1b2113d9b16824d118c08dbbe8bb7d541','ca63abf1777deac78cc899fcef9f02eb5fa24cee'),
       ("role+'_V2'","role+'_V5'"),('CANDIDATE_PUBLIC_V2.stdout','CANDIDATE_PUBLIC_V5.stdout'),
       ("('CANDIDATE','V2',candidate)","('CANDIDATE','V5',candidate)"),
       ('CI_CHECKOUT_SCOPE07_FINAL_NEGATIVES_V1','CI_CHECKOUT_SCOPE07_FINAL2_NEGATIVES_V1'),
       ('CI_CHECKOUT_SCOPE07_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1','CI_CHECKOUT_SCOPE07_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V2'),
       ('PR1806_FINAL_ALL_CI_API_V1','PR1806_FINAL_ALL_CI_API_V2'),
       ('PR1806_SYNTHETIC_OFFICIAL_GIT_API_V1','PR1806_SYNTHETIC_OFFICIAL_GIT_API_V2'),
       ('CI_CHECKOUT_SCOPE07_PREMERGE_CANONICAL_API_V1','CI_CHECKOUT_SCOPE07_PREMERGE_CANONICAL_API_V2'),
       ('ORIGINAL_CI_V1.log','ORIGINAL_CI_V2.log'),
       ('len(runs)==15','len(runs)==16'),('len(checks)==46','len(checks)==48'),
       ("sum(x['conclusion']=='success' for x in checks)==29","sum(x['conclusion']=='success' for x in checks)==30"),
       ("sum(x['conclusion']=='skipped' for x in checks)==17","sum(x['conclusion']=='skipped' for x in checks)==18"),
       ('SELECTED15_CI','SELECTED16_CI'),('fifteen selected CI','sixteen selected CI'),
       ('CI_CHECKOUT_SCOPE07_PREMERGE_CLOSURE_V1.json','CI_CHECKOUT_SCOPE07_PREMERGE_CLOSURE_V2.json')]
extra='''
hupsel=json.loads((E/'CI_CHECKOUT_SCOPE07_PR1806_HUPSEL_IMPACT_ORIGINAL_JOBS_V1.json').read_text())
assert len(hupsel['jobs'])==2
assert {(x['name'],x['conclusion']) for x in hupsel['jobs']}=={('dependency-impact','success'),('qualification','skipped')}
assert all(x['status']=='completed' for x in hupsel['jobs'])
hupsel_log=(E/'CI_CHECKOUT_SCOPE07_PR1806_HUPSEL_IMPACT_ORIGINAL_CI_V1.log').read_bytes()
assert b'e2ad1538dae3fc1eefdfd9a5f4507043bdc0a9f3' in hupsel_log
for expected in [b'"unchanged_scientific_tracked_files": 1883',b'"original_model_job_body_identical": true',b'"run_models": false']:
 assert expected in hupsel_log
assert not git('diff','df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c','082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66','--','app','src','tools','reference','examples','CMakeLists.txt','Makefile','pyproject.toml','requirements.txt','integration/f-ci/hupsel51-water-balance','integration/nomacro-coverage01')
'''
for old,new in [('ci-checkout-scope07-premerge-closure-v1.py','ci-checkout-scope07-premerge-closure-v2.py'),('ci-checkout-scope07-admission-seal-v1.py','ci-checkout-scope07-admission-seal-v2.py')]:
    s=(E/old).read_text()
    for a,b in edits:s=s.replace(a,b)
    marker="q=dict(status='" if 'premerge' in new else "name='CI_CHECKOUT_SCOPE07_ADMISSION_RAW_V1';members={}"
    assert s.count(marker)==1
    s=s.replace(marker,extra+'\n'+marker,1)
    if 'premerge' in new:
        s=s.replace("POND_current_model_replay='NOT_SELECTED_EXISTING_PRIVATE_FROST_PATH_SELECTION_PARENT_SUCCESS_RETAINED',canonical_admission=False","POND_current_model_replay='NOT_SELECTED_EXISTING_PRIVATE_FROST_PATH_SELECTION_PARENT_SUCCESS_RETAINED',HUPSEL_current_model_replay='NOT_SELECTED_EXACT1883_SCIENTIFIC_DEPENDENCIES_AND_ORIGINAL_JOB_UNCHANGED',canonical_admission=False")
    else:
        a=" POND_current_model_replay='NOT_SELECTED_EXISTING_PRIVATE_FROST_PATH_SELECTION_PARENT_SUCCESS_RETAINED',"
        assert s.count(a)==1;s=s.replace(a,a+"\n HUPSEL_current_model_replay='NOT_SELECTED_EXACT1883_SCIENTIFIC_DEPENDENCIES_AND_ORIGINAL_MODEL_JOB_UNCHANGED',")
    compile(s,new,'exec')
    with (E/new).open('x',encoding='utf8') as f:f.write(s)
    print(new)
