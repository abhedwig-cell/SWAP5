"""Prepare genuine current observer/control commands for transport qualification."""
from pathlib import Path
E=Path(__file__).resolve().parent
def put(name,s):
 compile(s,name,'exec')
 with (E/name).open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(E/'frost-implicit-hys2-year06-actual-candidate-observer-v1.py').read_text().replace('FROST_IMPLICIT_HYS2_YEAR06_CANDIDATE_','CI_CHECKOUT_SCOPE07_CANDIDATE_')
put('ci-checkout-scope07-actual-candidate-observer-v1.py',s)
s=(E/'frost-implicit-hys2-year06-real-negative-controls-v1.py').read_text()
s=s.replace('FROST_IMPLICIT_HYS2_YEAR06','CI_CHECKOUT_SCOPE07')
s=s.replace('codex/nomacro-frost-implicit-hys2-negative-','codex/nomacro-ci-checkout-negative-')
s=s.replace('codex/nomacro-frost-implicit-hys2-calendar06','codex/nomacro-ci-checkout-scope07')
s=s.replace("'SOURCE':'app/hybrid_water/frost_boundary_terminal_trial.py'","'SOURCE':'.github/workflows/swap431-crop-co2.yml'")
old="'RAW':'integration/f-ci/nomacro-complete01/'+json.loads((R/'integration/f-ci/nomacro-complete01/CI_CHECKOUT_SCOPE07_UBUNTU_O0_ORIGINAL_V1.json').read_text())['parts'][0]['file']"
assert s.count(old)==1;s=s.replace(old,"'RAW':'integration/f-ci/nomacro-complete01/FROST_IMPLICIT_HYS2_YEAR06_ADMISSION_RAW_V1.zip'")
start=s.index('    before=b"selected[');end=s.index("\n   elif role=='PUBLICATION'",start)
s=s[:start]+'''    lines=original.splitlines(keepends=True);matches=[i for i,line in enumerate(lines) if line.strip()==b'/*'];assert len(matches)==1
    at=matches[0];line=lines[at];indent=len(line)-len(line.lstrip());ending=b'\\r\\n' if line.endswith(b'\\r\\n') else b'\\n'
    lines.insert(at+1,b' '*indent+b'!/src/'+ending);changed=b''.join(lines);recipe=dict(never_merge_test_guard='Remove required actual engine source from the qualified checkout; never execute this CI configuration or models')'''+s[end:]
put('ci-checkout-scope07-real-negative-controls-v1.py',s)
print('ACTUAL_CURRENT_OBSERVER_AND_FOUR_REAL_SOURCE_RAW_INHERITED_PUBLICATION_CONTROLS_PREPARED')
