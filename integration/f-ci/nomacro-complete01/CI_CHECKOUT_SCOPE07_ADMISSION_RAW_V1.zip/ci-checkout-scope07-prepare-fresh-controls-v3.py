"""Prepare a fresh real child cohort; retain all original candidate39 controls."""
from pathlib import Path
E=Path(__file__).resolve().parent
s=(E/'ci-checkout-scope07-real-negative-controls-v1.py').read_text()
assert s.count("+role.lower()+'01'")==2
s=s.replace("+role.lower()+'01'","+role.lower()+'02'")
s=s.replace('CI_CHECKOUT_SCOPE07_FINAL_','CI_CHECKOUT_SCOPE07_FINAL2_')
s=s.replace('CURRENT2_FINAL_NEGATIVES_V1','CURRENT2_FINAL_NEGATIVES_V2')
compile(s,'fresh-real-controls-v2','exec')
with (E/'ci-checkout-scope07-real-negative-controls-v2.py').open('x',encoding='utf8') as f:f.write(s)
print('Fresh02 branches and FINAL2 evidence prepared; positive version supplied at actual execution')
