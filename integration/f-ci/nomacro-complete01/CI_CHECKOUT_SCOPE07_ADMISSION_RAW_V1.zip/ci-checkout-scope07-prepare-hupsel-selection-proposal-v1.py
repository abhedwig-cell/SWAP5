"""One private affected-model selector; retain every original scientific command."""
from pathlib import Path
import difflib,hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
BASE='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c';path='.github/workflows/hupsel51-water-balance.yml'
before=subprocess.check_output(['git','show',BASE+':'+path],cwd=R);s=before.decode()
trigger="      - 'tests/hupsel51/**'\n";assert s.count(trigger)==1
s=s.replace(trigger,trigger+"      - 'tests/nomacro_drainage/ci_checkout_scope07_hupsel_impact.py'\n",1)
impact='''  dependency-impact:
    runs-on: ubuntu-26.04
    timeout-minutes: 15
    outputs:
      run_models: ${{ steps.impact.outputs.run_models }}
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2
          filter: blob:none
          sparse-checkout-cone-mode: false
          sparse-checkout: |
            /*
            !/integration/f-ci/nomacro-complete01/*.zip
            !/integration/f-ci/nomacro-complete01/*.zip.part[0-9][0-9][0-9]
      - name: Compare actual scientific dependencies and original model commands
        id: impact
        env:
          BASE: ${{ github.event.pull_request.base.sha }}
        run: python3 -B tests/nomacro_drainage/ci_checkout_scope07_hupsel_impact.py
'''
anchor='jobs:\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+impact,1)
anchor='  qualification:\n';assert s.count(anchor)==1
condition="    needs: dependency-impact\n    if: needs.dependency-impact.outputs.run_models == 'true'\n"
s=s.replace(anchor,anchor+condition,1)
assert s.split(anchor,1)[1][len(condition):]==before.decode().split(anchor,1)[1]
edits=[]
for tag,i,j,k,l in difflib.SequenceMatcher(a=before.decode(),b=s,autojunk=False).get_opcodes():
    if tag!='equal':edits.append(dict(base_start=i,base_end=j,before=before.decode()[i:j],after=s[k:l]))
assert len(edits)==3 and all(not x['before'] for x in edits)
D=E/'ci-checkout-scope07-hupsel-selection-proposal-v1';p=D/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
target=D/'tests/nomacro_drainage/ci_checkout_scope07_hupsel_impact.py';target.parent.mkdir(parents=True,exist_ok=True);raw=(E/'ci-checkout-scope07-hupsel-impact-proposal-v1.py').read_bytes();compile(raw,str(target),'exec');target.write_bytes(raw)
q=dict(status='EXACT_PRIVATE_HUPSEL_MODEL_DEPENDENCY_SELECTION_PROPOSAL_ONLY_NOT_INSTALLED',actual_base=BASE,workflow=path,before_lf_sha256=hashlib.sha256(before).hexdigest(),proposed_lf_sha256=hashlib.sha256(s.encode()).hexdigest(),ordered_literal_edits=edits,original_scientific_job_body_and_all_commands_unchanged=True,additional_read_only_checkout_steps=1,scientific_model_runs_repeated=0)
with (E/'CI_CHECKOUT_SCOPE07_HUPSEL_SELECTION_PROPOSAL_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'])
