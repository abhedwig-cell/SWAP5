"""Prepare new07 closure controllers; never alter any executed prior controller."""
from pathlib import Path
E=Path(__file__).resolve().parent
replacements=[('FROST_IMPLICIT_HYS2_YEAR06','CI_CHECKOUT_SCOPE07'),('PR1805','PR1806'),('PR=1805','PR=1806'),
 ('cb712974e37e41256877d9770a0af071afe241dd','39d00d6b1d15dbe1132a0b6a2eb361d2459e697d'),
 ('47124f4de18a752fc466d50e2752e843548e5fea','df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c'),
 ('c65c7eb92cdc82ab786f62cb96bf376404e45130','02f5614a81957103919f29de511fb893b55bf7f8'),
 ('427974eb7b669856da9876ad39ba73bed5d437a5','c344878cd50f3e8893f9ee6b7d459041db869157'),
 ('a1c7b85e9a446cb3891cd3b115b63f9469668e7e','bacad1a1b2113d9b16824d118c08dbbe8bb7d541')]
for old,new in [('frost-implicit-hys2-year06-premerge-closure-v1.py','ci-checkout-scope07-premerge-closure-v1.py'),('frost-implicit-hys2-year06-admission-seal-v1.py','ci-checkout-scope07-admission-seal-v1.py')]:
    s=(E/old).read_text()
    for a,b in replacements:s=s.replace(a,b)
    s=s.replace("stem='CI_CHECKOUT_SCOPE07_CANDIDATE_'+role+'_V1'","stem='CI_CHECKOUT_SCOPE07_CANDIDATE_'+role+'_V2'")
    s=s.replace("CI_CHECKOUT_SCOPE07_CANDIDATE_PUBLIC_V1.stdout.txt","CI_CHECKOUT_SCOPE07_CANDIDATE_PUBLIC_V2.stdout.txt")
    s=s.replace("[('CANDIDATE','V1',candidate),('ACTUAL_MERGE','V1',actual)]","[('CANDIDATE','V2',candidate),('ACTUAL_MERGE','V1',actual)]")
    s=s.replace('len(runs)==14','len(runs)==15').replace('len(checks)==45','len(checks)==46').replace("sum(x['conclusion']=='success' for x in checks)==28","sum(x['conclusion']=='success' for x in checks)==29")
    s=s.replace('SELECTED14_CI','SELECTED15_CI').replace('fourteen selected CI','fifteen selected CI')
    s=s.replace("p.name.startswith('frost-implicit-hys2-year06-')","p.name.startswith('ci-checkout-scope07-')")
    if new.endswith('admission-seal-v1.py'):
        a="paths += [p for p in [E/'frost_implicit_hys2_metadata.py'] if p.exists()]"
        assert a in s
        s=s.replace(a,"paths += [p for p in E.iterdir() if p.is_file() and p.name.startswith('CI_CHECKOUT_SCOPE07_UPSTREAM_ACTION_') and p.suffix in ('.ts','.yml')]")
        a=" whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',"
        assert s.count(a)==2
        s=s.replace(a," scientific_change_class='D_READ_ONLY_BUILD_AND_EVIDENCE_TRANSPORT',new_scientific_contexts=0,\n original_scientific_producer='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6',\n original_scientific_producer_rebound=False,\n"+a)
        s=s.replace('ACTUAL_CANONICAL648_FROST_IMPLICIT_HYS2_BOUNDARY_ADMISSION_VERIFIED','ACTUAL_CANONICAL648_CHECKOUT_TRANSPORT_ADMISSION_VERIFIED')
    compile(s,new,'exec')
    with (E/new).open('x',encoding='utf8') as f:f.write(s)
    print(new)
