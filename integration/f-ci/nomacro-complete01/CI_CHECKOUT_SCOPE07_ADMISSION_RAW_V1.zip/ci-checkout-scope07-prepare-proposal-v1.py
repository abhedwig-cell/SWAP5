"""Prepare checkout-only literal changes and test real Git selection, outside R."""
from pathlib import Path
import fnmatch,hashlib,json,subprocess,yaml
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
BASE='cb712974e37e41256877d9770a0af071afe241dd'
git=lambda *a,**kw:subprocess.check_output(['git',*a],cwd=R,**kw)
SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==BASE and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
inventory=json.loads((E/'FROST_IMPLICIT_HYS2_YEAR06_SELECTED_CHECKOUT_OVERHEAD_AUDIT_V1.json').read_text())
assert inventory['actual_source']==BASE and inventory['unfiltered_unsparse_checkouts']==43
D=E/'CI_CHECKOUT_SCOPE07_DRAFT_V1';D.mkdir()
RULES='/*\n!/integration/f-ci/nomacro-complete01/*.zip\n!/integration/f-ci/nomacro-complete01/*.zip.part[0-9][0-9][0-9]\n'
rules=D/'rules.txt';rules.write_text(RULES,encoding='utf8',newline='\n')
all_raw=git('ls-tree','-r','--name-only','-z',BASE);names=set(all_raw.decode().rstrip('\0').split('\0'))
selected=git('sparse-checkout','check-rules','--no-cone','--rules-file',str(rules),'-z',input=all_raw)
included=set(selected.decode().rstrip('\0').split('\0'))
prefix='integration/f-ci/nomacro-complete01/'
excluded={n for n in names if n.startswith(prefix) and '/' not in n[len(prefix):] and (fnmatch.fnmatchcase(n[len(prefix):],'*.zip') or fnmatch.fnmatchcase(n[len(prefix):],'*.zip.part[0-9][0-9][0-9]'))}
assert excluded and included==names-excluded
assert all(n in included for n in names if n.startswith(('app/','src/','tools/','tests/','reference/','docs/')))
assert all(n in included for n in names if n.startswith(prefix) and n.endswith('.json'))
def mapping(node,key):
 matches=[value for name,value in node.value if name.value==key];assert len(matches)==1,key;return matches[0]
def has_mapping(node,key):
 matches=[value for name,value in node.value if name.value==key];assert len(matches)<=1;return matches[0] if matches else None
files={};checkout_count=0
for path in sorted({x['path'] for x in inventory['checkout_steps']}):
 raw=git('show',BASE+':'+path);before=raw.decode();assert '\r' not in before
 tree=yaml.compose(before);jobs=mapping(tree,'jobs');old=yaml.safe_load(before);edits=[];changed=[]
 for job_key,job_node in jobs.value:
  steps=has_mapping(job_node,'steps')
  if steps is None:continue
  for index,step in enumerate(steps.value):
   uses=has_mapping(step,'uses')
   if uses is None or not str(uses.value).startswith('actions/checkout@'):continue
   original=old['jobs'][job_key.value]['steps'][index];config=original.get('with',{})
   if config.get('filter') or config.get('sparse-checkout'):continue
   assert not {'filter','sparse-checkout','sparse-checkout-cone-mode'} & set(config)
   with_node=has_mapping(step,'with')
   if with_node is not None:
    assert isinstance(with_node,yaml.MappingNode) and not with_node.flow_style and with_node.value
    first=with_node.value[0][0];at=first.start_mark.index-first.start_mark.column;indent=first.start_mark.column;lead=''
   else:
    use_key=next(key for key,value in step.value if key.value=='uses');indent=use_key.start_mark.column+2
    at=before.find('\n',uses.end_mark.index)+1;assert at>0
    lead=' '*(indent-2)+'with:\n'
   pad=' '*indent
   add=lead+pad+'filter: blob:none\n'+pad+'sparse-checkout-cone-mode: false\n'+pad+'sparse-checkout: |\n'+''.join(pad+'  '+line+'\n' for line in RULES.splitlines())
   edits.append(dict(base_start=at,base_end=at,before='',after=add));changed.append(dict(job=job_key.value,step_index=index,action=uses.value));checkout_count+=1
 if not edits:continue
 assert len({x['base_start'] for x in edits})==len(edits)
 edits.sort(key=lambda x:x['base_start']);after=before
 for edit in reversed(edits):after=after[:edit['base_start']]+edit['after']+after[edit['base_end']:]
 parsed=yaml.safe_load(after)
 for item in changed:
  current=parsed['jobs'][item['job']]['steps'][item['step_index']];original=old['jobs'][item['job']]['steps'][item['step_index']]
  config=current['with'];assert config['filter']=='blob:none' and config['sparse-checkout-cone-mode'] is False and config['sparse-checkout']==RULES
  for key in ('filter','sparse-checkout-cone-mode','sparse-checkout'):del config[key]
  if 'with' not in original:assert not config;del current['with']
 assert parsed==old,'Whole workflow semantics changed outside explicit checkout inputs: '+path
 output=D/path;output.parent.mkdir(parents=True,exist_ok=True);output.write_text(after,encoding='utf8',newline='\n')
 files[path]=dict(before_lf_sha256=SHA(raw),proposed_lf_sha256=SHA(after.encode()),ordered_literal_edits=edits,checkout_steps=changed,all_non_checkout_yaml_values_identical=True)
assert len(files)==13 and checkout_count==43
assert git('rev-parse','HEAD').decode().strip()==BASE
q=dict(status='PROPOSED43_CHECKOUT_ONLY_EDITS_AND_REAL_GIT_FULL_SOURCE_SELECTION_PASS_NOT_CURRENT_CI_QUALIFIED',workstream='SWAP5-NOMACRO-COMPLETE01 / ACCELERATE02',classification='D_READ_ONLY_BUILD_AND_EVIDENCE_TRANSPORT',qualified_dependency_candidate=BASE,dependency_PR=1805,dependency_canonical_admission_pending=True,actual_canonical_at_start='47124f4de18a752fc466d50e2752e843548e5fea',rules=RULES,workflows=13,checkout_steps=43,files=files,actual_Git_tracked_paths=len(names),actual_Git_included_paths=len(included),only_excluded_evidence_archive_paths=sorted(excluded),real_Git_rules_input_sha256=SHA(all_raw),real_Git_rules_output_sha256=SHA(selected),all_scientific_programs_inputs_and_metadata_preserved=True,underlying_real_Git_archive_bytes_remain_authority=True,working_directory_identity_projected=False,compiler_executions=0,model_executions=0,performance_speedup_claimed=False,scientific_qualification=False,canonical_admission=False,next_action='Persist coherent checkout protocol branch. Reconcile genuine canonical648 after PR1805 completes. Preserve complete literal workflow inverses and unchanged source dependencies; qualify actual current CI without replaying unchanged scientific model periods.')
with (D/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],len(files),checkout_count,len(names),len(excluded),flush=True)
