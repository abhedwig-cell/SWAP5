"""Extend the actual Git validator for preserved complete-evidence F-CI jobs."""
from pathlib import Path
import json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=E/'CI_CHECKOUT_SCOPE07_DRAFT_V2'
s=subprocess.check_output(['git','show','634d2ecd4aa897b01806f6528eddd98cbdcf2093:tests/nomacro_drainage/ci_checkout_scope07.py'],cwd=R).decode()
before="        steps+=len(item['checkout_steps']);observations.append"
after="        expected_profile='complete_evidence' if path=='.github/workflows/fci-canonical.yml' else 'source_and_metadata'\n        assert all(x['profile']==expected_profile for x in item['checkout_steps'])\n        steps+=len(item['checkout_steps']);observations.append"
assert s.count(before)==1;s=s.replace(before,after)
before="    # These are genuine immutable Git objects"
after="""    full_rules=Path(__file__).with_name('ci_checkout_scope07_evidence.rules');full_raw=full_rules.read_bytes().replace(b'\\r\\n',b'\\n')
    assert full_raw.decode()==contract['profiles']['complete_evidence']=='/*\\n'
    assert full_raw==git('show','HEAD:'+full_rules.relative_to(R).as_posix())
    full_selected=git('sparse-checkout','check-rules','--no-cone','--rules-file',str(full_rules),'-z',input=names_raw)
    assert set(full_selected.decode().rstrip('\\0').split('\\0'))==names
    # These are genuine immutable Git objects"""
assert s.count(before)==1;s=s.replace(before,after)
before="checkout_steps=43,tracked_paths=len(names)"
after="checkout_steps=43,complete_evidence_checkout_steps=sum(x['profile']=='complete_evidence' for v in contract['files'].values() for x in v['checkout_steps']),fci_canonical_keeps_complete_versioned_evidence=True,real_Git_complete_evidence_selection_sha256=SHA(full_selected),tracked_paths=len(names)"
assert s.count(before)==1;s=s.replace(before,after)
path=D/'tests/nomacro_drainage/ci_checkout_scope07.py';path.parent.mkdir(parents=True,exist_ok=True)
with path.open('x',encoding='utf8',newline='\n') as f:f.write(s)
compile(s,str(path),'exec')
(path.parent/'ci_checkout_scope07.rules').write_text(json.loads((D/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json').read_text())['rules'],encoding='utf8',newline='\n')
(path.parent/'ci_checkout_scope07_evidence.rules').write_text('/*\n',encoding='utf8',newline='\n')
print('REAL_GIT_VALIDATOR_PREPARED_FOR_BOTH_SOURCE_ONLY_AND_COMPLETE_FROZEN_EVIDENCE_PROFILES')
