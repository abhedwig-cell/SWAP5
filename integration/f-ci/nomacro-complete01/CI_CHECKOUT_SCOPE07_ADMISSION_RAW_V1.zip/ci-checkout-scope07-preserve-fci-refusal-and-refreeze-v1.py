"""Preserve actual CI refusal and freeze exact test-only checkout inverse witness."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
SHA=lambda b:hashlib.sha256(b).hexdigest()
C='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d';BASE='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c'
assert git('rev-parse','HEAD')==C and git('branch','--show-current')=='codex/nomacro-ci-checkout-scope07'
test='tests/hupsel51/test_successor.py';helper='tests/nomacro_drainage/ci_checkout_scope07.py'
assert set(git('diff','--name-only').splitlines())=={test,helper}
name='CI_CHECKOUT_SCOPE07_PR1806_FCI_MODULAR_FAILED_CI_V1.log';raw=(E/name).read_bytes()
assert C.encode() in raw and b'02f5614a81957103919f29de511fb893b55bf7f8' in raw
assert b'ValueError: historical workflow body changed: .github/workflows/fci-canonical.yml' in raw
failed=json.loads((E/'CI_CHECKOUT_SCOPE07_PR1806_FAILED_CI_API_V1.json').read_text())
assert failed['runs']['total_count']==15 and sum(x['conclusion']=='failure' for x in failed['runs']['workflow_runs'])==1
log_record=dict(role='FCI_MODULAR',job_id=139623172434,run_id=45732727272,actual_source=C,actual_source_semantics='WORKFLOW_RUN_HEAD_SHA',actual_job_checkout='02f5614a81957103919f29de511fb893b55bf7f8',file=name,bytes=len(raw),sha256=SHA(raw),status='ORIGINAL_FAILED_CURRENT_CI_LOG_PRESERVED',storage='CONNECTOR_DECODED_UTF8_TEXT_BOM_PRESERVED_NOT_ORIGINAL_HTTP_BYTE_CLAIM')
with (E/(name+'.json')).open('x',encoding='utf8') as f:json.dump(log_record,f,indent=2);f.write('\n')
before=subprocess.check_output(['git','show',BASE+':'+test],cwd=R);after=(R/test).read_bytes().replace(b'\r\n',b'\n');assert before==subprocess.check_output(['git','show',C+':'+test],cwd=R)
edits=[];a=before.decode();b=after.decode()
for tag,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
    if tag!='equal':edits.append(dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]))
assert len(edits)==1 and edits[0]['before']==''
contract=json.loads((P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json').read_text());contract['read_only_runtime_witnesses'][test]=dict(before_lf_sha256=SHA(before),proposed_lf_sha256=SHA(after),ordered_literal_edits=edits,purpose='Exact complete current checkout-file inverse before unchanged original workflow/command negative tests; no test command, numerical assertion or historical validator weakened')
contract.update(status='ORIGINAL_FCI_WORKFLOW_ASSERTION_REFUSAL_PRESERVED_EXACT_CHECKOUT_TEST_WITNESS_FIXED_CURRENT_GATES_PENDING',historical_workflow_test_witness=test)
(P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json').write_text(json.dumps(contract,indent=2)+'\n')
failure=dict(status='ORIGINAL_ACTUAL_CI_REFUSAL_PRESERVED_CHECKOUT_TEST_WITNESS_REPAIRED_NO_MODEL_REPLAY',actual_failed_candidate=C,actual_failed_synthetic='02f5614a81957103919f29de511fb893b55bf7f8',PR=1806,failed_run=45732727272,failed_job=139623172434,log=log_record,original_API='CI_CHECKOUT_SCOPE07_PR1806_FAILED_CI_API_V1.json',corrected_local_test_command='python -B tests/hupsel51/test_successor.py',corrected_local_tests=11,corrected_local_tests_seconds=6.711,actual_uncommitted_test_sha256=SHA(after),test_commands_and_original_workflow_validator_unchanged=True,scientific_model_runs_repeated=0,current_positive_and_four_real_negative_controls_require_fresh_actual_candidate_observation=True)
name='CI_CHECKOUT_SCOPE07_READ_ONLY_FAILURES_V3.json';s=json.dumps(failure,indent=2)+'\n'
with (E/name).open('x',encoding='utf8') as f:f.write(s)
(P/name).write_text(s)
status=json.loads((P/'STATUS.json').read_text());status['ci_checkout_scope07'].update(status=contract['status'],PR=1806,prior_actual_ci_refusal=name,exact_historical_test_witness=test)
status['next_action']='Run frozen corrected actual checkout PUBLIC/publication, four fresh real controls, all selected current CI and genuine canonical observation. No old scientific model-period replay. Immediately continue bounded undrained Frost08 after actual07 receipt.'
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
doc=R/'docs/development/NOMACRO_CI_CHECKOUT_SCOPE07.md';s=doc.read_text();s+='\nThe original PR1806 modular-feedback attempt refused the checkout additions in its historical workflow unit assertion. The corrected read-only witness validates the entire current workflow SHA256, reconstructs every pinned literal checkout insertion against actual canonical648, and passes that exact parent text to the unchanged original command-mutation test. All original failure logs are retained. No model period is replayed for this assertion repair.\n';doc.write_text(s,encoding='utf8',newline='\n')
paths=[test,helper,'integration/f-ci/nomacro-complete01/CI_CHECKOUT_SCOPE07_CONTRACT_V1.json','integration/f-ci/nomacro-complete01/'+name,'integration/f-ci/nomacro-complete01/STATUS.json','docs/development/NOMACRO_CI_CHECKOUT_SCOPE07.md']
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*paths],cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Bind exact checkout inverse to unchanged historical workflow negative tests'],cwd=R,check=True)
anchor=git('rev-parse','HEAD');path=R/'tests/nomacro_drainage/ci_checkout_scope07_verify.py';s=path.read_text();s,n=re.subn(r"(?m)^SEALED='[0-9a-f]{40}'$","SEALED='"+anchor+"'",s);assert n==1;path.write_text(s,encoding='utf8',newline='\n')
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',path.relative_to(R).as_posix()],cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Bind corrected historical test witness to genuine source anchor'],cwd=R,check=True)
q=dict(actual_candidate=git('rev-parse','HEAD'),source_anchor=anchor,actual_tree=git('rev-parse','HEAD^{tree}'),actual_canonical_parent=BASE,previous_failed_candidate=C,PR=1806,new_scientific_contexts=0,coadmission_contexts=648,canonical_admission=False)
with (E/'CI_CHECKOUT_SCOPE07_FROZEN_CANDIDATE_V3.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps(q),flush=True)
