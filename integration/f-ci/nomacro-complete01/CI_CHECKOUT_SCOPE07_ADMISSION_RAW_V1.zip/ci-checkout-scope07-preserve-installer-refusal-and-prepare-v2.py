"""Preserve the pre-write hash refusal and use exact original Git bytes."""
from pathlib import Path
import json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all','--ignored'],cwd=R).strip()
q=dict(status='PRE_WRITE_INSTALLER_HASH_REFUSAL_PRESERVED_NOT_SCIENTIFIC_QUALIFICATION',controller='ci-checkout-scope07-install-checkpoint-v1.py',cause='Text helper stripped trailing LF before SHA256 comparison; initial assertion rejected before copying the first workflow.',source_modified_before_refusal=False,compiler_executions=0,model_executions=0,correction='V2 hashes original git show bytes directly without text trimming or source identity rebinding.')
with (E/'CI_CHECKOUT_SCOPE07_READ_ONLY_FAILURES_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
s=(E/'ci-checkout-scope07-install-checkpoint-v1.py').read_text();before="hashlib.sha256(git('show','HEAD:'+name).encode()).hexdigest()";after="hashlib.sha256(subprocess.check_output(['git','show','HEAD:'+name],cwd=R)).hexdigest()";assert s.count(before)==1;s=s.replace(before,after)
marker="path=P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json'"
assert s.count(marker)==1;s=s.replace(marker,"path=P/'CI_CHECKOUT_SCOPE07_READ_ONLY_FAILURES_V1.json';shutil.copyfile(E/path.name,path);paths.append(path)\n"+marker)
with (E/'ci-checkout-scope07-install-checkpoint-v2.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
compile(s,'installer-v2','exec');print('ORIGINAL_PRE_WRITE_REFUSAL_PRESERVED_V2_USES_EXACT_RAW_GIT_BYTES')
