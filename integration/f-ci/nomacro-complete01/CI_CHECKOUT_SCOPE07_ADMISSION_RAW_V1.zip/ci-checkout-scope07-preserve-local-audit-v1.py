"""Preserve actual local transport audit; no scientific or speedup promotion."""
from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
name='CI_CHECKOUT_SCOPE07_ACTUAL_LOCAL_AUDIT_V1.json';q=json.loads((E/name).read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
assert q['actual_head']==head and q['checkout_steps']==43 and len(q['excluded_archive_paths'])==739 and not q['engine_source_changed']
shutil.copyfile(E/name,P/name)
path=P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json';c=json.loads(path.read_text());c.update(status='ACTUAL_LOCAL_LITERAL43_AND_REAL_GIT_SOURCE_SELECTION_PASS_CURRENT_CI_AND_CANONICAL_PENDING',actual_local_auditor_source=head,actual_local_audit=name,local_auditor_LF_sha256=hashlib.sha256((R/'tests/nomacro_drainage/ci_checkout_scope07.py').read_bytes().replace(b'\r\n',b'\n')).hexdigest(),rules_source='tests/nomacro_drainage/ci_checkout_scope07.rules')
path.write_text(json.dumps(c,indent=2)+'\n')
path=P/'STATUS.json';s=json.loads(path.read_text());s['ci_checkout_scope07'].update(status=c['status'],actual_local_auditor_source=head,actual_local_audit=name,actual_current_CI_qualified=False,performance_speedup_claimed=False)
s['next_action']=s['next_code_change']='Preserve/push07 branch and return same checkout to actual06 candidate cb7129. Finish existing PR1805 CI, original six primary logs, final45checks and genuine premerge closure. Observe actual canonical648 at frozen real HEAD. Then reconcile07 normally to that genuine merge and qualify checkout-only actual current CI without scientific model replay.'
path.write_text(json.dumps(s,indent=2)+'\n')
paths=[P/name,P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json',P/'STATUS.json']
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*[p.relative_to(R).as_posix() for p in paths]],cwd=R,check=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Preserve actual checkout scope audit and pending canonical dependency'],cwd=R,check=True)
print('ACTUAL07_LOCAL_AUDIT_PRESERVED_NO_SCIENTIFIC_RERUN_OR_SPEEDUP_CLAIM',flush=True)
