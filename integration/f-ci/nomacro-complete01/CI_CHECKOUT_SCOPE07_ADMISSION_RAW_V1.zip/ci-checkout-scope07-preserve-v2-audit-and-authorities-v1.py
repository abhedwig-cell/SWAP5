"""Persist tested transport profiles and their unwired admission authorities."""
from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
name='CI_CHECKOUT_SCOPE07_ACTUAL_LOCAL_AUDIT_V2.json';q=json.loads((E/name).read_text())
assert q['actual_head']=='7f3e5ae83e14212498c79f6abdae3ef5f1a6b174' and q['actual_base']=='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c' and q['complete_evidence_checkout_steps']==17 and q['checkout_steps']==43
assert q['tracked_paths']==16770 and len(q['excluded_archive_paths'])==740 and q['fci_canonical_keeps_complete_versioned_evidence']
shutil.copyfile(E/name,P/name)
path=P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json';c=json.loads(path.read_text());c.update(status='LOCAL_LITERAL43_AND_BOTH_REAL_GIT_PROFILES_PASS_CURRENT_ADMISSION_PENDING',actual_local_auditor_source=q['actual_head'],actual_local_audit=name,local_auditor_LF_sha256=hashlib.sha256((R/'tests/nomacro_drainage/ci_checkout_scope07.py').read_bytes().replace(b'\r\n',b'\n')).hexdigest(),complete_evidence_checkout_steps=17,source_component_checkout_steps=26,admission_authority_state='IMPLEMENTED_NOT_YET_WIRED')
path.write_text(json.dumps(c,indent=2)+'\n')
path=P/'STATUS.json';s=json.loads(path.read_text());s['ci_checkout_scope07'].update(status=c['status'],actual_local_auditor_source=q['actual_head'],actual_local_audit=name,complete_evidence_checkout_steps=17,source_component_checkout_steps=26,admission_authority_state='IMPLEMENTED_NOT_YET_WIRED')
s['next_action']=s['next_code_change']='Audit genuine648 signed admission chain at a fixed actual HEAD. Then freeze current07 source and wire joint owner; verify exact inherited scientific dependency surface, actual public/PUB, committed negative controls and actual selected current checkout CI. Preserve original model producers and replay no unchanged scientific periods.'
path.write_text(json.dumps(s,indent=2)+'\n')
path=R/'docs/development/NOMACRO_CI_CHECKOUT_SCOPE07.md';text=path.read_text();text+='\nThe actual V2 local audit at7f3e5ae83e14212498c79f6abdae3ef5f1a6b174\npasses all43 literal inverses and both real Git selections:26source/component\ncheckout steps exclude only740archive paths from16770tracked paths;17F-CI\nsteps preserve the complete versioned evidence tree. The engine, original\nscientific programs and their qualified producer identities remain unchanged.\nCurrent public/admission and actual CI qualification are still pending.\n';path.write_text(text,encoding='utf8',newline='\n')
paths=[P/name,P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json',P/'STATUS.json',path]
paths.extend(R/'tests/nomacro_drainage'/('ci_checkout_scope07_'+suffix+'.py') for suffix in ('metadata','inherited_custody','parent_admission','source_custody','verify'))
for p in paths:
 if p.suffix=='.py':compile(p.read_text(),str(p),'exec')
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*[p.relative_to(R).as_posix() for p in paths]],cwd=R,check=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Preserve both actual checkout profile audits and genuine648 admission authorities'],cwd=R,check=True)
print('ACTUAL_V2_AND_REAL_SOURCE_AUTHORITIES_PERSISTED_NOT_YET_PUBLICLY_ADMITTED',flush=True)
