"""Reconcile genuine648 and preserve input-complete frozen authority checkouts."""
from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';D=E/'CI_CHECKOUT_SCOPE07_DRAFT_V2'
gitb=lambda *a:subprocess.check_output(['git',*a],cwd=R)
gitt=lambda *a:gitb(*a).decode().strip()
M='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c';SHA=lambda b:hashlib.sha256(b).hexdigest()
assert gitt('branch','--show-current')=='codex/nomacro-ci-checkout-scope07'
assert subprocess.run(['git','merge-base','--is-ancestor',M,'HEAD'],cwd=R).returncode==0
receipt=json.loads((P/'FROST_IMPLICIT_HYS2_YEAR06_MERGE_RECEIPT_V1.json').read_text())
assert receipt['actual_merge']==M and receipt['canonical_admission'] and receipt['coadmission']['contexts']==648
assert receipt['admission_archive_sha256']=='686d02451f9e5f3b5f624a10fea5c464000d91abc94d46243a0c5ef3526d1b7f'
assert not gitb('diff',M,'HEAD','--','app','src','tools','reference')
c=json.loads((D/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json').read_text());paths=[]
for name,item in c['files'].items():
 assert SHA(gitb('show',M+':'+name))==item['before_lf_sha256']
 shutil.copyfile(D/name,R/name);paths.append(R/name)
for name in ('ci_checkout_scope07.py','ci_checkout_scope07.rules','ci_checkout_scope07_evidence.rules'):
 target=R/'tests/nomacro_drainage'/name;shutil.copyfile(D/'tests/nomacro_drainage'/name,target);paths.append(target)
 if name.endswith('.py'):compile(target.read_text(),str(target),'exec')
c.update(status='EVIDENCE_AWARE_CHECKOUT_PROFILES_IMPLEMENTED_ACTUAL_PARENT648_LOCAL_V2_AUDIT_PENDING',actual_canonical_dependency=M,dependency_canonical_admission_pending=False,parent_admission_receipt='FROST_IMPLICIT_HYS2_YEAR06_MERGE_RECEIPT_V1.json',parent_admission_archive_sha256=receipt['admission_archive_sha256'],parent_canonical_contexts=648,actual_original_scientific_model_producer='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6',prior_local_audit='CI_CHECKOUT_SCOPE07_ACTUAL_LOCAL_AUDIT_V1.json',prior_local_auditor_source='95286aedd9',scientific_qualification='INHERITED_ONLY_AFTER_CURRENT_EXACT_ENGINE_AND_PROGRAM_DEPENDENCY_CUSTODY',actual_current_CI_qualified=False,performance_speedup_claimed=False)
doc='docs/science/NOMACRO_FROST_IMPLICIT_HYS2_YEAR06.md';before=gitb('show',M+':'+doc);text=before.decode();old='Status: bounded source/science qualified; public and canonical admission pending.'
assert text.count(old)==1
text=text.replace(old,'Status: bounded scope canonically admitted by PR1805 on\n`df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c`.',1)
text+='\nThe actual canonical PUBLIC observation passes in875.0141058seconds and ordinary\npublication in486.0042507seconds, with unchanged real HEAD/tree/working status\nand14sparse patterns/56original fixtures. The137-member original admission\narchive is9301298bytes, SHA256\n`686d02451f9e5f3b5f624a10fea5c464000d91abc94d46243a0c5ef3526d1b7f`.\nIts merge receipt owns bounded648 admission; whole historical closure remains\nPARTIAL and scientific equivalence NOT_QUALIFIED.\n'
edits=[dict(base_start=a,base_end=b,before=before.decode()[a:b],after=text[x:y]) for op,a,b,x,y in difflib.SequenceMatcher(None,before.decode(),text,autojunk=False).get_opcodes() if op!='equal']
c['read_only_runtime_witnesses']={doc:dict(before_lf_sha256=SHA(before),proposed_lf_sha256=SHA(text.encode()),ordered_literal_edits=edits,scope='ADMISSION_METADATA_ONLY_ORIGINAL_SCIENTIFIC_BODY_RETAINED')}
(R/doc).write_text(text,encoding='utf8',newline='\n');paths.append(R/doc)
path=P/'CI_CHECKOUT_SCOPE07_CONTRACT_V1.json';path.write_text(json.dumps(c,indent=2)+'\n');paths.append(path)
path=R/'docs/development/NOMACRO_CI_CHECKOUT_SCOPE07.md';s=path.read_text();s=s.replace('Only complete ZIPs and three-digit ZIP\nparts directly under integration/f-ci/nomacro-complete01 are omitted from the\nworking directory.','Source/component checkouts omit only complete ZIPs and three-digit ZIP parts\ndirectly under integration/f-ci/nomacro-complete01 from their working directory.\nF-CI canonical and frozen historical authority jobs keep the complete versioned\nevidence working tree; partial clone avoids unrelated historical blob transport.')
s=s.replace('The dependency candidate is PR1805 cb712974e37e41256877d9770a0af071afe241dd.\nIts new64-context science is already independently qualified, but its canonical\nadmission is still pending.','The dependency is actual admitted PR1805 canonical\n`df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c`, with its original64-context science\nand genuine signed admission receipt. Bounded coadmission remains648.')
s=s.replace('After actual PR1805\nadmission, reconcile its genuine merge normally, retain its original receipt,\nand qualify','Its genuine merge is reconciled normally and its original receipt is retained.\nQualify')
path.write_text(s,encoding='utf8',newline='\n');paths.append(path)
path=P/'STATUS.json';s=json.loads(path.read_text())
for name in ('canonical','canonical_head','current_canonical_sha','canonical_baseline'):s[name]=M
s['frost_implicit_hys2_year06'].update(status='ACTUAL_CANONICAL648_ADMISSION_VERIFIED',canonical_admission=True,actual_canonical=M,current_admitted_contexts=648,actual_public_seconds=875.0141058000736,actual_ordinary_publication_seconds=486.0042507001199,admission_archive='FROST_IMPLICIT_HYS2_YEAR06_ADMISSION_RAW_V1.json',admission_archive_sha256=receipt['admission_archive_sha256'])
s['ci_checkout_scope07'].update(status=c['status'],actual_canonical_dependency=M,dependency_canonical_admission_pending=False,fci_canonical_retains_complete_versioned_evidence=True,actual_current_CI_qualified=False)
s['coverage_batch_report'].update(actual_canonical=M,bounded_coadmission_contexts=648,new_current_batch_contexts=48,requalified_implicit5_contexts=16,next_implementation_batch='Finish transport-only checkout profiles with unchanged scientific source and evidence; then original undrained Frost/state compositions.')
s['completed'].append('PR1805 actualcanonicaldf00f9393ac552b0a6cab8ee84f8b8d8c06ac26c admits bounded648:14workflowsSUCCESS/45terminalchecks28success17skip, four actual committed pushed negatives refused, actualclean14/56 PUBLIC875.014106s and ordinaryPUB486.004251s PASS. Original137member admission archive9301298B SHA686d02451f9e5f3b5f624a10fea5c464000d91abc94d46243a0c5ef3526d1b7f. WholePARTIAL/NOT_QUALIFIED, familygapUNKNOWN, fixedRC3unchanged.')
s['next_action']=s['next_code_change']='Run actual07 V2 literal inverses and both real Git selection profiles. Keep frozen FCI authorities evidence-complete. Bind current source and original648 admission; qualify actual current checkout CI without unchanged scientific model replay.'
s['recovery_point']='Actual648 df00 admission sealed with originalSHA686d0245.07 normal merge retains original6 producerA4 and actual local07 auditor952; V2 limits source/component checkout data while all frozen FCI authorities retain complete evidence. Engine source unchanged; actual current07 CI/public/canonical gates pending.'
path.write_text(json.dumps(s,indent=2)+'\n');paths.append(path)
path=P/'GAP_MATRIX.json';g=json.loads(path.read_text());g['frost_implicit_hys2_year06'].update(status='ACTUAL_CANONICAL648_ADMITTED',canonical_admission=True,actual_canonical=M,admission_receipt='FROST_IMPLICIT_HYS2_YEAR06_MERGE_RECEIPT_V1.json');g['ci_checkout_scope07']=dict(classification='D_READ_ONLY_BUILD_AND_EVIDENCE_TRANSPORT',status=c['status'],workflow_files=13,checkout_steps=43,frozen_fci_authorities_evidence_complete=True,scientific_model_periods_replayed=0,performance_speedup_claimed=False,canonical_admission=False)
g['next_coherent_batches'][0]=dict(priority=1,family='CI source and evidence checkout transport',classification='D_READ_ONLY_BUILD_AND_EVIDENCE_TRANSPORT',status='Actual648 admitted. Current43-step/13-workflow inverse and evidence-aware profiles implemented; actual current07 qualification pending. Preserve all model programs and original source identities.')
g['next_coherent_batches'][2]['family']='Broader original undrained Frost/calendar/state compositions';path.write_text(json.dumps(g,indent=2)+'\n');paths.append(path)
for name in ('FROST_IMPLICIT_HYS2_YEAR06_ADMISSION_RAW_V1.json','FROST_IMPLICIT_HYS2_YEAR06_ADMISSION_RAW_V1.zip','FROST_IMPLICIT_HYS2_YEAR06_MERGE_RECEIPT_V1.json'):paths.append(P/name)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--sparse','--',*[p.relative_to(R).as_posix() for p in paths]],cwd=R,check=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Preserve canonical648 admission and retain complete frozen evidence in checkout profiles'],cwd=R,check=True)
print('GENUINE648_RECONCILED_ORIGINAL_SCIENCE_IDENTITIES_RETAINED_V2_CURRENT_PROTOCOL_READY',gitt('rev-parse','HEAD'),flush=True)
