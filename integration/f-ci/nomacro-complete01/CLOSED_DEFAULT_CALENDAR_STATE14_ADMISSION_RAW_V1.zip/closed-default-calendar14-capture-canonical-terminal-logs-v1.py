"""Capture each completed canonical push run's original HTTP metadata and UTF8 job log once."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,urllib.request,urllib.error,urllib.parse
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');SHA=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--head',required=True);p.add_argument('--synthetic',required=True);p.add_argument('--label',required=True);a=p.parse_args();assert re.fullmatch('[0-9a-f]{40}',a.head) and re.fullmatch('[0-9a-f]{40}',a.synthetic) and re.fullmatch('[A-Z0-9_]+',a.label)
assert a.head==a.synthetic and a.label=='COMPLETE'
prefix='CLOSED_DEFAULT_CALENDAR_STATE14_ACTUAL_MERGE';target=E/(prefix+'_ORIGINAL_LOG_CUSTODY_V1.json')
record=json.loads(target.read_text()) if target.exists() else dict(status='CAPTURING_TERMINAL_PR_RUNS',actual_verified_merge=a.head,actual_signed_checkout=a.synthetic,original_bytes_normalized=False,jobs=[],runs=[],skipped_jobs=[],canonical_admission=False)
assert record['actual_verified_merge']==a.head and record['actual_signed_checkout']==a.synthetic
child=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);child.check_returncode();fields=dict(v.split('=',1) for v in child.stdout.decode().splitlines() if '=' in v);headers={'Cache-Control':'no-cache','Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','Accept-Encoding':'identity','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-terminal-CI-log-custody'}
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,response_headers,newurl):return None
opener=urllib.request.build_opener(NoRedirect)
def fetch(path):
    try:
        with opener.open(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=50) as stream:return stream.read()
    except urllib.error.HTTPError as error:
        if error.code not in (301,302,303,307,308):raise
        url=error.headers['Location'];parts=urllib.parse.urlsplit(url);assert parts.scheme=='https' and (parts.hostname.endswith('.blob.core.windows.net') or parts.hostname.endswith('.actions.githubusercontent.com'))
        with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept-Encoding':'identity'}),timeout=50) as stream:return stream.read()
def once(path,raw):
    if path.exists():assert path.read_bytes()==raw
    else:path.write_bytes(raw)
save=lambda:target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
all_runs=json.loads(fetch('actions/runs?head_sha='+a.head+'&event=push&per_page=100'));assert all_runs['total_count']==len(all_runs['workflow_runs'])>=4
active=[]
for run in all_runs['workflow_runs']:
    assert run['head_sha']==a.head and run['event']=='push'
    if run['status']!='completed':active.append(dict(run_id=run['id'],name=run['name'],status=run['status']));continue
    if any(v['run_id']==run['id'] for v in record['runs']):continue
    runraw=fetch('actions/runs/'+str(run['id']));official=json.loads(runraw);assert official['status']=='completed' and official['head_sha']==a.head and official['event']=='push'
    jobsraw=fetch('actions/runs/'+str(run['id'])+'/jobs?per_page=100');jobs=json.loads(jobsraw);assert jobs['total_count']==len(jobs['jobs']) and all(v['status']=='completed' for v in jobs['jobs'])
    stem=prefix+'_RUN_'+str(run['id']);once(E/(stem+'_ORIGINAL_API_V1.json'),runraw);once(E/(stem+'_JOBS_ORIGINAL_API_V1.json'),jobsraw)
    for job in jobs['jobs']:
        assert job['head_sha']==a.head and job['run_id']==run['id']
        if job['conclusion']=='skipped':record['skipped_jobs'].append(dict(job_id=job['id'],run_id=run['id'],name=job['name'],conclusion='skipped'));continue
        jobraw=fetch('actions/jobs/'+str(job['id']));jobapi=json.loads(jobraw);assert jobapi['status']=='completed' and jobapi['head_sha']==a.head and jobapi['run_id']==run['id']
        log=fetch('actions/jobs/'+str(job['id'])+'/logs');log.decode('utf8',errors='strict');assert not log.startswith(b'PK')
        name=prefix+'_JOB_'+str(job['id']);once(E/(name+'_ORIGINAL_CI_V1.log'),log);once(E/(name+'_ORIGINAL_API_V1.json'),jobraw);once(E/(name+'_RUN_ORIGINAL_API_V1.json'),runraw)
        record['jobs'].append(dict(job_id=job['id'],run_id=run['id'],name=job['name'],conclusion=jobapi['conclusion'],actual_source=a.head,actual_signed_checkout=a.synthetic,signed_checkout_printed=a.synthetic.encode() in log,bytes=len(log),sha256=SHA(log),original_log=name+'_ORIGINAL_CI_V1.log',original_job_api_sha256=SHA(jobraw),original_run_api_sha256=SHA(runraw)));save();print('ORIGINAL_TERMINAL_JOB_LOG_RETAINED',a.label,job['id'],jobapi['conclusion'],len(log),flush=True)
    record['runs'].append(dict(run_id=run['id'],name=run['name'],conclusion=official['conclusion'],actual_source=a.head,original_run_api_sha256=SHA(runraw),jobs=len(jobs['jobs'])));save()
record['observed_required_canonical_workflows']=all_runs['total_count'];record['active_runs']=active;record['status']='ALL_TERMINAL_CANONICAL_RUN_LOGS_RETAINED' if len(record['runs'])==all_runs['total_count'] else 'PARTIAL_TERMINAL_CANONICAL_LOG_CAPTURE_ACTIVE_RUNS_PENDING';save();print(record['status'],len(record['runs']),len(record['jobs']),len(record['skipped_jobs']),len(active),flush=True)
