"""Fresh official matching PR/run/check metadata; terminal admission snapshots only."""
from pathlib import Path
import argparse,json,os,re,subprocess,urllib.request
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='09e5847a8fc4873b471f9e91eb7f2136ad64c76b';B='ae54d7d621a07e54dd8f9fdb758585b2a2cc754d';S='cffa9b9fd12bc19b93ab1c9581ce1ae6609f8c48';TREE='8e41d1d2eee8b9d1497bd8e886d87f9bc6108afd'
EXPECTED={373048667,360218774,361291030,350231902,374169088,366506117,377452065,367350343,377461752,374030810,351968455,377436526,369778710,377534434,372453937}
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['PREMERGE','POSTMERGE'],required=True);p.add_argument('--merge');p.add_argument('--probe',action='store_true');a=p.parse_args()
if a.phase=='POSTMERGE':assert a.merge and re.fullmatch('[0-9a-f]{40}',a.merge)
child=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);child.check_returncode();fields=dict(line.split('=',1) for line in child.stdout.decode().splitlines() if '=' in line)
headers={'Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','Accept-Encoding':'identity','Cache-Control':'no-cache','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-closed-default-admission-metadata'}
def fetch(path):
    with urllib.request.urlopen(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=45) as stream:return stream.read()
def once(name,raw):
    path=E/name
    if path.exists():assert path.read_bytes()==raw
    else:path.write_bytes(raw)
prraw=fetch('pulls/1813');pr=json.loads(prraw);assert pr['head']['sha']==C and pr['base']['ref']=='integration/f-ci-canonical'
refraw=fetch('git/ref/heads/integration/f-ci-canonical');ref=json.loads(refraw)
if a.phase=='PREMERGE':assert not pr['merged'] and pr['state']=='open' and pr['mergeable'] is True and pr['merge_commit_sha']==S and pr['base']['sha']==ref['object']['sha']==B
else:assert pr['merged'] and pr['state']=='closed' and pr['merge_commit_sha']==ref['object']['sha']==a.merge
runraw=fetch('actions/runs?head_sha='+C+'&event=pull_request&per_page=100');runs=json.loads(runraw);checkraw=fetch('commits/'+C+'/check-runs?per_page=100');checks=json.loads(checkraw)
assert runs['total_count']==len(runs['workflow_runs'])==len(EXPECTED)==15 and {v['workflow_id'] for v in runs['workflow_runs']}==EXPECTED

assert all(v['status']=='completed' for v in runs['workflow_runs'])
assert sum(v['conclusion']=='failure' for v in runs['workflow_runs'])==1 and sum(v['conclusion']=='success' for v in runs['workflow_runs'])==14
assert checks['total_count']==len(checks['check_runs'])==46 and all(v['status']=='completed' for v in checks['check_runs'])
assert sum(v['conclusion']=='failure' for v in checks['check_runs'])==1 and sum(v['conclusion']=='success' for v in checks['check_runs'])==28 and sum(v['conclusion']=='skipped' for v in checks['check_runs'])==17
for suffix,raw in [('_PR_ORIGINAL_API_V1.json',prraw),('_CANONICAL_REF_ORIGINAL_API_V1.json',refraw),('_ALL_CI_ORIGINAL_API_V1.json',runraw),('_ALL_CHECKS_ORIGINAL_API_V1.json',checkraw)]:once('CLOSED_DEFAULT_CALENDAR_STATE14_PR1813_FIRST_HEAD'+suffix,raw)
print('FIRST_REAL_PR_HEAD_15_TERMINAL_WORKFLOWS_46_CHECKS_ONE_GUARD_FAILURE_RETAINED',flush=True)
