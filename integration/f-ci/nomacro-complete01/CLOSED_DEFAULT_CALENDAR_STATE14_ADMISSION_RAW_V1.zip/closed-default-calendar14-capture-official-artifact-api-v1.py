"""Capture each completed PR run's original HTTP metadata and UTF8 job log once."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,urllib.request,urllib.error,urllib.parse
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');SHA=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--head',required=True);p.add_argument('--synthetic',required=True);p.add_argument('--label',required=True);a=p.parse_args();assert re.fullmatch('[0-9a-f]{40}',a.head) and re.fullmatch('[0-9a-f]{40}',a.synthetic) and re.fullmatch('[A-Z0-9_]+',a.label)
prefix='CLOSED_DEFAULT_CALENDAR_STATE14_'+a.label;target=E/(prefix+'_ORIGINAL_LOG_CUSTODY_V1.json')
record=json.loads(target.read_text()) if target.exists() else dict(status='CAPTURING_TERMINAL_PR_RUNS',actual_candidate=a.head,actual_checkout_source=a.synthetic,original_bytes_normalized=False,jobs=[],runs=[],skipped_jobs=[],canonical_admission=False)
assert record['actual_candidate']==a.head and record['actual_checkout_source']==a.synthetic
child=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);child.check_returncode();fields=dict(v.split('=',1) for v in child.stdout.decode().splitlines() if '=' in v);headers={'Cache-Control':'no-cache','Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','Accept-Encoding':'identity','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-terminal-CI-log-custody'}
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,response_headers,newurl):return None
opener=urllib.request.build_opener(NoRedirect)
def fetch(path):
    try:
        with opener.open(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=50) as stream:return stream.read()
    except urllib.error.HTTPError as error:
        if error.code not in (301,302,303,307,308):raise
        url=error.headers['Location'];parts=urllib.parse.urlsplit(url);assert parts.scheme=='https' and (parts.hostname.endswith('.blob.core.windows.net') or parts.hostname.endswith('.actions.githubusercontent.com'))
        with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept-Encoding':'identity'}),timeout=50) as stream:return stream.read()
def once(path,raw):
    if path.exists():assert path.read_bytes()==raw
    else:path.write_bytes(raw)
save=lambda:target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')

root=E/'closure14-official-artifact-api-v1';root.mkdir(exist_ok=True)
for label,run in [('UBUNTU',46044072466),('WINDOWS',46044072519),('FIRST_PREFLIGHT_UBUNTU',46043899772),('FIRST_PREFLIGHT_WINDOWS',46043899765)]:
 raw=fetch('actions/runs/'+str(run)+'/artifacts?per_page=100');api=json.loads(raw);assert api['total_count']==len(api['artifacts'])==2
 once(root/(label+'_ORIGINAL_ARTIFACT_API_V1.json'),raw)
 for artifact in api['artifacts']:
  assert artifact['workflow_run']['id']==run and not artifact['expired']
  if not label.startswith('FIRST_PREFLIGHT'):continue
  body=fetch('actions/artifacts/'+str(artifact['id'])+'/zip');assert SHA(body)==artifact['digest'].removeprefix('sha256:') and len(body)==artifact['size_in_bytes']
  once(root/('artifact-'+str(artifact['id'])+'-ORIGINAL.zip'),body)
 print('ORIGINAL_OFFICIAL_ARTIFACT_API_RETAINED',label,run,flush=True)
