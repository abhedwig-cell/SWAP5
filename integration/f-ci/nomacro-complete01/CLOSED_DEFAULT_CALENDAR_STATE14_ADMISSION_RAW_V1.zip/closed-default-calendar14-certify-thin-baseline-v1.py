from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');SHA=lambda b:hashlib.sha256(b).hexdigest();M='ae54d7d621a07e54dd8f9fdb758585b2a2cc754d';rows=[]
for mode in ['PUBLIC','PUBLICATION']:
    old='CLOSED_IMPLICIT_STATE13_ACTUAL_MERGE_'+mode+'_V1';new='CLOSED_DEFAULT_CALENDAR_STATE14_THIN_BASELINE_'+mode+'_V1';a=json.loads((E/(old+'.json')).read_text());b=json.loads((E/(new+'.json')).read_text());left=(E/(old+'.stdout.txt')).read_bytes();right=(E/(new+'.stdout.txt')).read_bytes()
    assert a['returncode']==b['returncode']==0 and a['before']==a['after'] and b['before']==b['after'] and a['before']['head']==b['before']['head']==M and a['before']['tree']==b['before']['tree']=='202bb30e809e46770b591bb56ce94866dbdffbfb'
    assert a['before']['original_project_files']==b['before']['original_project_files'] and len(a['before']['original_project_files'])==56 and len(a['before']['sparse'])==14 and len(b['before']['sparse'])==3
    assert left==right,'Actual unchanged source must retain identical complete admission output'
    rows.append(dict(mode=mode,full_view_seconds=a['seconds'],thin_view_seconds=b['seconds'],complete_stdout_bytes=len(right),complete_stdout_sha256=SHA(right),complete_stdout_byte_identical=True,original_56_project_files_exact=True,actual_same_source_HEAD=M))
q=dict(status='REAL_M13_THREE_PATTERN_SPARSE_BASELINE_PUBLIC_AND_ORDINARY_PUBLICATION_IDENTICAL_COMPLETE_OUTPUTS_PASS',actual_source=M,observations=rows,source_or_Git_or_filesystem_identity_projected=False,actual_sparse_configuration_changed=True,qualification_bodies_or_oracles_changed=False,scientific_or_portable_speedup_claimed=False,compiler_executions=0,model_executions=0,new_qualified_contexts=0)
target=E/'CLOSED_DEFAULT_CALENDAR_STATE14_THIN_BASELINE_INDEPENDENT_IDENTITY_V1.json';assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],[(v['mode'],v['complete_stdout_bytes']) for v in rows],flush=True)
