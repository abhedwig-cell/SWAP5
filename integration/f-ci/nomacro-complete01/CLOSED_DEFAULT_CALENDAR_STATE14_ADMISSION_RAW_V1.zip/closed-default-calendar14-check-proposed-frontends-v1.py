from pathlib import Path
import json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from analytical_hydraulic_archives import SHA
import experimental_project as e
from closed_default_calendar import selection
prepared=json.loads((E/'CLOSED_DEFAULT_CALENDAR_STATE14_ACCEPTED_ORIGINAL_INPUT_PREPARATION_V1.json').read_text());rows=[]
for item in prepared['contexts']:
    path=Path(item['input_root'])
    for name,v in item['prepared_members'].items():assert SHA((path/name).read_bytes())==v['sha256']
    try:
        p=e.load(path,original_output=True,time_step_policy='original-adaptive-day-seed-v1');owner=selection(p);assert owner is not None;row=dict(case=item['case'],status='ACTUAL_PROPOSED_FRONTEND_AND_REAL_DEFAULT_OWNER_ACCEPTED_NOT_QUALIFIED',nodes=p.nodes,actual_default_owner=owner)
    except Exception as error:row=dict(case=item['case'],status='ACTUAL_PROPOSED_FRONTEND_REFUSED',error=repr(error))
    rows.append(row);print(row,flush=True)
q=dict(status='PROPOSED_SOURCE_FRONTEND_OBSERVATIONS_NO_COMPILATION_OR_MODEL',actual_Git_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),actual_working_APP_source_hashes={p.relative_to(R).as_posix():SHA(p.read_bytes().replace(b'\r\n',b'\n')) for p in (R/'app/hybrid_water').glob('*.py')},working_source_not_yet_committed=True,contexts=rows,compiler_executions=0,model_executions=0,canonical_admission=False)
target=E/'CLOSED_DEFAULT_CALENDAR_STATE14_PROPOSED_FRONTEND_V1.json';assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');assert all(v['status'].startswith('ACTUAL_PROPOSED_FRONTEND_AND') for v in rows)
