from pathlib import Path
import difflib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage';P=R/'integration/f-ci/nomacro-complete01';B='ae54d7d621a07e54dd8f9fdb758585b2a2cc754d';git=lambda *v:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*v],cwd=R)
prepared=json.loads((E/'CLOSED_DEFAULT_CALENDAR_STATE14_ACCEPTED_ORIGINAL_INPUT_PREPARATION_V1.json').read_text());cases=[]
for row in prepared['contexts']:
    original=row['original_frontend']['report']['selectors'];cases.append(dict(name=row['case'],kind='cde' if original['SWSOLU'] else 'water',initial=1,hydraulic_model=1,history=original['SWHYST'],implicit=original['SWKIMPL'],snow=0,frost=0,drainage=0,bottom=6,actual_original_input_prefix=row['original_input_prefix']+'/',actual_original_input_producer=row['actual_original_scientific_producer'],calendar='unchanged-original-input',physical_parameters_profiles_forcing_output_controls_and_dates_preserved=True))
plan=dict(status='PROPOSED_FINITE_DEFAULT_MODEL1_PRESSURE_NONDAILY_CLOSED_STATE_DEPENDENCY_BASIS_NOT_QUALIFIED',actual_canonical_parent=B,cases=cases,independent_qualification_cases=[v['name'] for v in cases],not_a_configuration_cartesian_product=True,new_qualified_contexts=0,canonical_admission=False,whole_historical_completion='PARTIAL',global_family_and_gap_counts='UNKNOWN')
(P/'CLOSED_DEFAULT_CALENDAR_STATE14_FINITE_CASE_PLAN_V1.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8')
body=(T/'closed_implicit_state_feedback.py').read_text()
for before,after in [('2e98506b4fb469bbf5995a8ab0b49c88ead0972c',B),('IMPLICIT_HYDRAULIC_STATE11_FIRST_WINDOWS_O0_ORIGINAL_V1','INITIAL_PROFILE_CALENDAR_WINDOWS_RAW_V1'),('CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1','CLOSED_DEFAULT_CALENDAR_STATE14_FINITE_CASE_PLAN_V1'),('CLOSED_IMPLICIT','CLOSED_DEFAULT_CALENDAR')]:
    assert before in body,before;body=body.replace(before,after)
before="authority=dict(actual_git_source=PARENT,archive=name,archive_sha256=archive.record['sha256'],prefix=prefix,original_members={n:dict(bytes=len(v),sha256=SHA(v)) for n,v in original.items()})"
after="authority=dict(actual_git_source=PARENT,actual_original_scientific_producer=spec['actual_original_input_producer'],archive=name,archive_sha256=archive.record['sha256'],prefix=prefix,original_members={n:dict(bytes=len(v),sha256=SHA(v)) for n,v in original.items()})"
assert before in body;body=body.replace(before,after);compile(body,'closed_default_calendar_feedback.py','exec');(T/'closed_default_calendar_feedback.py').write_text(body,encoding='utf8')
path=R/'.github/workflows/fci-canonical.yml';before=git('show',B+':.github/workflows/fci-canonical.yml').decode();old='          sparse-checkout: |\n            /*\n';new=old+'            !/integration/**/*.zip\n            !/integration/**/*.zip.part*\n';assert before.count(old)>=2
current=before.replace(old,new,2);assert current.count(new)==2;path.write_text(current,encoding='utf8')
files=git('diff','--name-only',B,'--','app').decode().splitlines()+['app/hybrid_water/closed_default_calendar.py'];files=sorted(set(files));proposal={}
for name in files:
    result=subprocess.run(['git','show',B+':'+name],cwd=R,capture_output=True);left=result.stdout if result.returncode==0 else b'';right=(R/name).read_bytes().replace(b'\r\n',b'\n');a=left.decode();b=right.decode();edits=[]
    for op,lo,hi,start,end in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
        if op!='equal':edits.append(dict(base_start=lo,base_end=hi,before=a[lo:hi],after=b[start:end]))
    import hashlib
    proposal[name]=dict(new_file=result.returncode!=0,before_lf_sha256=hashlib.sha256(left).hexdigest(),after_lf_sha256=hashlib.sha256(right).hexdigest(),ordered_literal_edits=edits)
q=dict(status='PROPOSED_ACTUAL_DEFAULT_MODEL1_CLOSED_PRESSURE_NONDAILY_STATE_COMPOSITION',actual_canonical_parent=B,files=proposal,default_model1_not_mislabelled_as_non1_implicit_state=True,new_native_codec=False,new_physical_state=False,physical_equations_changed=False,new_numerical_policy=False,tolerances_or_iteration_limits_changed=False,parameters_or_output_controls_or_dates_normalized=False,canonical_admission=False)
(P/'CLOSED_DEFAULT_CALENDAR_STATE14_SOURCE_PROPOSAL_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
doc=R/'docs/science/NOMACRO_CLOSED_DEFAULT_CALENDAR_STATE14.md';doc.write_text('''# Original closed default-model1 pressure/calendar composition

Canonical parent ae54d7d621 admits1004 bounded contexts through PR1812. Its
signed source/parents/tree, candidate and actual-merge PUBLIC/publication,
14 required PR workflows,4 canonical workflows,33 original successful CI logs
and four real one-file negative controls are preserved in the inherited
CLOSED_IMPLICIT_STATE13_ADMISSION_RAW_V2 capsule. Whole migration PARTIAL;
scientific equivalence NOT_QUALIFIED; global family/gap counts UNKNOWN; RC3 fixed.

Five exact existing accepted pressure-profile inputs retain every physical
parameter, profile, forcing, output control and date. Only SWDRA0/SWBOTB6 are
declared. Original initialization accepts all five at zero model days; the
previous actual frontend refuses their state-owner cross. The proposed default
model1 owner uses its real existing calendar/hysteresis/CDE state, and does not
invent non1 implicit metadata, a new native codec or physical state. Simultaneous
implicit+hysteretic non-daily crosses remain a separate dependency scope.

Current frontend acceptance passes for all five; actual compiled physical,
native, cold and external transaction qualification is pending. Complete source
literal inverses must preserve every original physical equation, parameter,
tolerance, iteration limit and native calendar/counter. No numerical policy is
proposed. Any numerical failure remains a gap until diagnosed and qualified.

The real M13 baseline using three actual sparse patterns produces byte-identical
complete PUBLIC and ordinary-Python publication outputs, with the same source
tree and56 original project files. All119 removed working archive copies were
first byte-compared with real retained Git objects. The first two automatic
canonical checkout steps now use those same conservative exclusions. Their full
qualification command bodies remain unchanged; all other historical checkout
recipes remain intact. This changes materialization, not a scientific gate,
source identity or oracle. Local audit timing shows no speedup claim.

The two inherited explicit Gardner/Snow9 numerical gaps and AGE dry-pond/paired9
active-vapor scientific decisions remain open. No original period is replayed
for unchanged capability preservation.
''',encoding='utf8')
print('REAL_DEFAULT_CALENDAR_FEEDBACK_AND_FIVE_CASE_DEPENDENCY_PLAN_INSTALLED',len(files),flush=True)
