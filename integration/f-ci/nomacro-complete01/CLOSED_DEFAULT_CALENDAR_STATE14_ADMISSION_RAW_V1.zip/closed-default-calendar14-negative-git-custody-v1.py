"""Read every real control Git blob and retain original working EOL identities separately."""
from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='09e5847a8fc4873b471f9e91eb7f2136ad64c76b'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
q=json.loads((E/'CLOSED_DEFAULT_CALENDAR_STATE14_FINAL1_NEGATIVES_V1.json').read_text());assert q['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN3_PUBLIC_NEGATIVES_REFUSED' and len(q['controls'])==4
items=[]
for item in q['controls']:
    assert git('show','-s','--format=%P',item['head']).decode().split()==[C]
    assert git('diff','--name-only',C,item['head']).decode().strip()==item['path']
    original=git('show',C+':'+item['path']);changed=git('show',item['head']+':'+item['path'])
    options={original,original.replace(b'\n',b'\r\n')};matches=[b for b in options if SHA(b)==item['actual_original_file_sha256']];assert len(matches)==1;working=matches[0]
    if item['role']=='SOURCE':mutant=working.replace(b'SWDRA=0,SWBOTB=6',b'SWDRA=0,SWBOTB=7',1)
    elif item['role']=='PUBLICATION':mutant=working+b'\n \n'
    else:
        recipe=item['mutation_recipe'];assert recipe['xor_hex']=='01';mutant=bytearray(working);mutant[recipe['offset']]^=1;mutant=bytes(mutant)
    assert SHA(mutant)==item['actual_mutated_file_sha256']
    assert changed==mutant or changed==mutant.replace(b'\r\n',b'\n')
    if item['role']=='PUBLICATION':(E/'CLOSED_DEFAULT_CALENDAR_STATE14_FINAL1_PUBLICATION_ACTUAL_WORKING_MUTANT_V1.bin').write_bytes(mutant)
    items.append(dict(role=item['role'],actual_head=item['head'],exact_parent=C,path=item['path'],actual_committed_original_sha256=SHA(original),actual_committed_mutant_sha256=SHA(changed),actual_observed_working_original_sha256=SHA(working),actual_observed_working_mutant_sha256=SHA(mutant),actual_git_eol_conversion_present=changed!=mutant,original_working_and_Git_bytes_not_conflated=True))
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
record=dict(status='FOUR_REAL_CONTROL_GIT_BLOBS_EXACT_PARENTS_ONE_FILE_DELTAS_AND_SEPARATE_WORKING_BYTE_IDENTITIES_VERIFIED',controls=items,all_four_controls_first_executions=True,executed_controller='closed-default-calendar14-real-negative-controls-v1.py',compiler_executions=0,model_executions=0)
(E/'CLOSED_DEFAULT_CALENDAR_STATE14_FINAL1_NEGATIVE_GIT_CUSTODY_V1.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(record['status'])
