"""Use the unchanged accepted original initialization-only driver on five new inputs."""
from pathlib import Path
import hashlib,io,json,os,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import SHA
C='2d810e6db3acf6eb81ff96dae90859670eae9b3a';B='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';git=lambda *v:subprocess.check_output(['git',*v],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
data=GitArchiveSource(R,B);descriptor=json.loads((data/'FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.json').read_text());raw=(data/descriptor['archive']).read_bytes();assert len(raw)==descriptor['bytes'] and SHA(raw)==descriptor['sha256']
exe=W/'frost-undrained-state08-initialization-probe-O0-v1/corrected-module-import-v2/original_initialization_probe.exe';member='phase-driver/corrected-module-import-v2/original_initialization_probe.exe'
with zipfile.ZipFile(io.BytesIO(raw)) as z:assert exe.read_bytes()==z.read(member) and SHA(exe.read_bytes())==descriptor['members'][member]['sha256']=='dee4a94a5e0e92d07c9aee2a4790fc5178f159f7e81ad316fcaa58b6a6f28b5e'
prepared=json.loads((E/'CLOSED_DEFAULT_CALENDAR_STATE14_ACCEPTED_ORIGINAL_INPUT_PREPARATION_V1.json').read_text());assert len(prepared['contexts'])==5
root=E/'closure14-original-zero-day-v1';root.mkdir();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
record=dict(status='RUNNING_FIVE_ORIGINAL_INITIALIZATION_ONLY_CONTROLS',actual_APP_observer=C,actual_original_probe_source='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d',actual_original_probe_exe_sha256=SHA(exe.read_bytes()),actual_original_probe_archive_revision=B,actual_original_probe_archive_sha256=descriptor['sha256'],original_driver_O0=True,original_SDK_mixed_compiler_profiles=True,compiler_executions=0,model_days=0,original_full_period_equivalence_claimed=False,contexts=[],canonical13_admission_still_pending=True)
target=E/'CLOSED_DEFAULT_CALENDAR_STATE14_ORIGINAL_ZERO_DAY_V1.json';assert not target.exists();save=lambda:target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');save()
for item in prepared['contexts']:
    name=item['case'];source=Path(item['input_root']);folder=root/name;folder.mkdir()
    for relative,v in item['prepared_members'].items():
        raw=(source/relative).read_bytes();assert len(raw)==v['bytes'] and SHA(raw)==v['sha256'];path=folder/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    child=subprocess.run([str(exe),'./swap.swp'],cwd=folder,env=env,capture_output=True,timeout=30)
    (folder/'original-zero-day.stdout').write_bytes(child.stdout);(folder/'original-zero-day.stderr').write_bytes(child.stderr)
    accepted=b'ORIGINAL_INIT_PHASE AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS' in child.stdout
    record['contexts'].append(dict(case=name,returncode=child.returncode,original_initialization_accepted=accepted,actual_command=[str(exe),'./swap.swp'],actual_cwd=str(folder),all_declared_original_input_bytes_exact=True,actual_original_input_archive_sha256=item['archive_sha256'],actual_original_input_source_producer=item['actual_original_scientific_producer'],input_inventory=item['prepared_members'],stdout_sha256=SHA(child.stdout),stderr_sha256=SHA(child.stderr),original_phases=[v.decode() for v in child.stdout.splitlines() if v.startswith(b'ORIGINAL_INIT_PHASE ')],current_public_frontend_refusal_preserved=item['closed_frontend'],model_days=0));save();print(name,'ORIGINAL_INITIALIZATION_ACCEPTED',accepted,child.returncode,flush=True)
    for relative,v in item['prepared_members'].items():assert SHA((source/relative).read_bytes())==v['sha256']
assert all(v['original_initialization_accepted'] and v['returncode']==0 for v in record['contexts'])
record['status']='FIVE_ORIGINAL_CLOSED_DEFAULT_PRESSURE_CALENDAR_INITIALIZATIONS_PASS_CURRENT_FRONTEND_REFUSALS_RETAINED_ZERO_MODEL_DAYS';save();assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored');print(record['status'],flush=True)
