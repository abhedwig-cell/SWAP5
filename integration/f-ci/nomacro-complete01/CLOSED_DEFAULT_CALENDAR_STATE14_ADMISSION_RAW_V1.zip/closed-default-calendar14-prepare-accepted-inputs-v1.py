"""Prepare exact accepted input decks with only the declared closed selectors."""
from contextlib import ExitStack
from pathlib import Path
import json,re,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
from original_output_baseline import assignment
import experimental_project as project
C='2d810e6db3acf6eb81ff96dae90859670eae9b3a';B='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';git=lambda *v:subprocess.check_output(['git',*v],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
root=E/'closure14-accepted-original-inputs-v1';root.mkdir();cases=['implicit-monthly-cde','implicit-perstep-water','hys1-clock-water','hys2-monthly-water','hys2-periodic-cde'];rows=[]
def frontend(path):
    try:
        q=project.inspect(path,original_output=True);loaded=project.load(path,original_output=True,time_step_policy='original-adaptive-day-seed-v1');return dict(status='ACTUAL_UNMODIFIED_FRONTEND_ACCEPTED_NOT_FUNCTIONALLY_QUALIFIED',nodes=loaded.nodes,report=q)
    except Exception as error:return dict(status='ACTUAL_UNMODIFIED_FRONTEND_REFUSED',error=repr(error))
with ExitStack() as stack:
    store=Archive(GitArchiveSource(R,B),'INITIAL_PROFILE_CALENDAR_WINDOWS_RAW_V1',stack)
    for name in cases:
        prefix='profiles/initial-profile-calendar-original-dispatch-v1/'+name+'-initial1';roles=[v for v in store.record['roles'] if v['inputs']==prefix];assert len(roles)==2 and len({v['science']['producer'] for v in roles})==1
        source_producer=roles[0]['science']['producer'];folder=root/name;folder.mkdir();original={}
        for member in store.names:
            if not member.startswith(prefix+'/'):continue
            relative=member[len(prefix)+1:];raw=store.get(member);path=folder/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);original[relative]=dict(bytes=len(raw),sha256=SHA(raw),archive_member=member)
        assert original and 'swap.swp' in original;original_frontend=frontend(folder);assert original_frontend['status']=='ACTUAL_UNMODIFIED_FRONTEND_ACCEPTED_NOT_FUNCTIONALLY_QUALIFIED',(name,original_frontend)
        raw=(folder/'swap.swp').read_bytes();text=raw.decode('cp1252');changed=assignment(assignment(text,'SWDRA',0),'SWBOTB',6).encode('cp1252');assert changed!=raw;(folder/'swap.swp').write_bytes(changed)
        target={p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=SHA(p.read_bytes())) for p in folder.rglob('*') if p.is_file()};assert target.keys()==original.keys()
        for relative in original:
            if relative!='swap.swp':assert target[relative]['sha256']==original[relative]['sha256']
        result=frontend(folder);rows.append(dict(case=name,actual_observer_source=C,actual_accepted_archive_revision=B,archive='INITIAL_PROFILE_CALENDAR_WINDOWS_RAW_V1',archive_sha256=store.record['sha256'],original_input_prefix=prefix,actual_original_scientific_producer=source_producer,input_root=str(folder),declared_selector_changes=dict(SWDRA=0,SWBOTB=6),original_members=original,prepared_members=target,original_frontend=original_frontend,closed_frontend=result,all_original_physical_parameters_profiles_forcing_output_controls_and_dates_preserved=True,canonical_admission=False));print(name,result['status'],result.get('error',''),flush=True)
q=dict(status='FIVE_REAL_ACCEPTED_PRESSURE_PROFILE_CALENDAR_INPUTS_PREPARED_AND_FRONTEND_CLASSIFIED_NO_COMPILE_OR_MODEL',actual_observer=C,original_source_or_filesystem_identities_projected=False,contexts=rows,compiler_executions=0,model_executions=0,new_qualified_contexts=0,canonical13_admission_still_pending=True)
target=E/'CLOSED_DEFAULT_CALENDAR_STATE14_ACCEPTED_ORIGINAL_INPUT_PREPARATION_V1.json';assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
