"""Locate exact existing default-model input/calendar bytes; execute no model."""
from contextlib import ExitStack
from pathlib import Path
import hashlib,json,re,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
C='2d810e6db3acf6eb81ff96dae90859670eae9b3a';B='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';git=lambda *v:subprocess.check_output(['git',*v],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
keys=['SWMACRO','SWSOLU','SWKIMPL','SWHYST','SWFROST','SWSNOW','SWDRA','SWBOTB','SWINCO','NPRINTDAY','PERIOD','SWMONTH','SWODAT','SWRES','FLPRINTDT','IHWCKMODEL'];rows=[]
with ExitStack() as stack:
    store=Archive(GitArchiveSource(R,B),'IMPLICIT_HYDRAULIC_STATE11_GUARD_RAW_V1',stack)
    for name in store.names:
        if not name.endswith('/inputs/swap.swp'):continue
        raw=store.get(name);text=raw.decode('cp1252');active='\n'.join(v.split('!',1)[0] for v in text.splitlines() if not v.lstrip().startswith('*'));values={}
        for key in keys:
            matches=re.findall(r'(?mi)^[ \t]*'+key+r'[ \t]*=[ \t]*([^\r\n]*)',active);assert len(matches)<=1;values[key]=matches[0].strip() if matches else None
        models=values['IHWCKMODEL'];default=models is None or all(int(v)==1 for v in models.split())
        if default:rows.append(dict(actual_archive_revision=B,archive='IMPLICIT_HYDRAULIC_STATE11_GUARD_RAW_V1',archive_sha256=store.record['sha256'],member=name,bytes=len(raw),sha256=SHA(raw),selectors_and_output_controls=values,default_model1=True,ordinary=values['SWFROST']==values['SWSNOW']=='0'))
source=git('show',C+':app/hybrid_water/closed_zero_boundary.py');assert b"if selectors['SWSNOW']==0 and not implicit_analytical:" in source and b'dense=dict(NPRINTDAY=1,PERIOD=1,SWMONTH=0,SWODAT=0,SWRES=1)' in source
q=dict(status='READONLY_DEFAULT_MODEL1_EXISTING_INPUT_BYTE_CATALOG_FOR_NEXT_FUNCTIONAL_BLOCK_NOT_SELECTED_OR_QUALIFIED',actual_observer=C,actual_parent_scientific_archive=B,rows=rows,current_exact_guard_source_sha256=SHA(source),known_missing_gate='Ordinary default-model1 pressure-profile closed initialization retains a dense-only output-owner predicate; non-daily state/calendar composition needs separate owner qualification.',classification='COMPOSITION_MISSING',original_input_or_calendar_bytes_modified=False,compiler_executions=0,model_executions=0,canonical13_admission_still_pending=True)
target=E/'CLOSED_DEFAULT_CALENDAR_STATE14_READONLY_INPUT_DISCOVERY_V1.json';assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored');print(q['status'],len(rows),[(v['member'],v['selectors_and_output_controls']['SWMONTH'],v['selectors_and_output_controls']['PERIOD']) for v in rows],flush=True)
