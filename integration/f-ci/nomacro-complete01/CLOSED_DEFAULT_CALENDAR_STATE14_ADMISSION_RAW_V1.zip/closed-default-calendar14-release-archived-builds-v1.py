"""Release only owned completed compiler roots after exact genuine Git byte checks."""
from pathlib import Path
from contextlib import ExitStack
import json,os,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';cleanup=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();record=dict(actual_retained_Git_source=head,task=task,task_finished=False,verified_owned_builds=[],operations=[])
target=E/'CLOSED_DEFAULT_CALENDAR_STATE14_RELEASE_ARCHIVED_BUILDS_V1.json';save=lambda:target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
with ExitStack() as stack:
    stores={name:Archive(GitArchiveSource(R,head),name,stack) for name in ['CLOSED_DEFAULT_CALENDAR_STATE14_ALL_LOCAL_FAILURES_AND_SUCCESSES_RAW_V2','CLOSED_DEFAULT_CALENDAR_STATE14_FORTY_OLD_OBJECTS_AND_NATIVE_RAW_V4']}
    for opt in ['O0','O2']:
        for label in ['feedback-'+opt+'-v1','feedback-'+opt+'-v2','feedback-'+opt+'-v3','preservation-'+opt+'-v1']:
            root=W/('closure14-'+label);store=stores['CLOSED_DEFAULT_CALENDAR_STATE14_FORTY_OLD_OBJECTS_AND_NATIVE_RAW_V4' if label.startswith('preservation') else 'CLOSED_DEFAULT_CALENDAR_STATE14_ALL_LOCAL_FAILURES_AND_SUCCESSES_RAW_V2']
            prefix='actual/'+root.relative_to(W).as_posix()+'/'
            expected={name for name in store.names if name.startswith(prefix)}
            paths=[path for path in root.rglob('*') if path.is_file()];assert expected=={'actual/'+path.relative_to(W).as_posix() for path in paths} and paths
            for path in paths:assert path.read_bytes()==store.get('actual/'+path.relative_to(W).as_posix())
            record['verified_owned_builds'].append(dict(path=str(root),files=len(paths),retained_archive_sha256=store.record['sha256'],all_bytes_exact_to_actual_Git_archive_members=True))
save()
def call(*args):
    child=subprocess.run([sys.executable,'-B',str(cleanup),*args],cwd=cleanup.parents[2],capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1'),timeout=240)
    q=json.loads(child.stdout);record['operations'].append(dict(command=list(args),returncode=child.returncode,result=q,stderr=child.stderr.decode()));save();return child.returncode,q
for row in record['verified_owned_builds']:
    code,_=call('release','--task',task,'--path',row['path']);assert code==0
_,preview=call('cleanup','--task',task)
eligible=[row for row in preview.get('results',[]) if row.get('status','').startswith('eligible')]
if eligible:code,applied=call('cleanup','--apply','--task',task);assert code in (0,3)
else:applied=None
record['eligible_before_apply']=len(eligible);record['status']='EIGHT_COMPLETED_OWN_BUILD_ROOTS_EXACT_GIT_BYTE_VERIFIED_AND_RELEASED_TASK_ACTIVE';save()
print(record['status'],len(record['verified_owned_builds']),len(eligible),flush=True)
if applied:
    for row in applied.get('results',[]):
        if row.get('status') not in ('retained',):print(row.get('status'),row.get('path'),row.get('reason'),flush=True)
