"""Exact original terminal CI bytes, artifact APIs and premodeI failure packages."""
from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).parent;SHA=lambda raw:hashlib.sha256(raw).hexdigest()
name='CLOSED_DEFAULT_CALENDAR_STATE14_ORIGINAL_CI_AND_OBSERVER_CUSTODY_RAW_V3';target=E/(name+'.zip');members={}
sources={}
for path in E.iterdir():
    if path.is_file() and path.name.startswith(('CLOSED_DEFAULT_CALENDAR_STATE14_FIRST_PREFLIGHT_','CLOSED_DEFAULT_CALENDAR_STATE14_FIRST_PORTABLE_')) and path.suffix in ['.json','.log']:
        sources[path.name]=path
for path in (E/'closure14-official-artifact-api-v1').iterdir():
    if path.is_file():sources['official-artifact-api/'+path.name]=path
for filename in ['closed-default-calendar14-capture-portable-terminal-logs-v1.py','closed-default-calendar14-capture-official-artifact-api-v1.py','closed-default-calendar14-download-reusable-files-v1.py','closed-default-calendar14-seal-original-portable-v1.py','closed-default-calendar14-seal-ci-custody-v3.py','CLOSED_DEFAULT_CALENDAR_STATE14_GENUINE_PARENT_ADMISSION_V1.json','CLOSED_DEFAULT_CALENDAR_STATE14_PORTABLE_SELECTION_V2.json','CLOSED_DEFAULT_CALENDAR_STATE14_OLD_OBJECT_SELECTION_V1.json']:
    path=E/filename;assert path.is_file();sources['controllers-and-observations/'+filename]=path
successful=json.loads((E/'CLOSED_DEFAULT_CALENDAR_STATE14_FIRST_PORTABLE_ORIGINAL_LOG_CUSTODY_V1.json').read_text())
failed=json.loads((E/'CLOSED_DEFAULT_CALENDAR_STATE14_FIRST_PREFLIGHT_ORIGINAL_LOG_CUSTODY_V1.json').read_text())
assert len(successful['jobs'])==len(failed['jobs'])==4 and all(v['conclusion']=='success' for v in successful['jobs']) and all(v['conclusion']=='failure' for v in failed['jobs'])
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for key,path in sorted(sources.items()):
        raw=path.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for key,item in members.items():
        raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=target.read_bytes();assert len(raw)<48*1024**2
q=dict(status='FOUR_ORIGINAL_SUCCESSFUL_PORTABLE_JOBS_AND_FOUR_ORIGINAL_PREMODEL_PREFLIGHT_FAILURES_PRESERVED',archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,actual_successful_source='94c86c2918278ffd9595b9960eb8e1522652277a',actual_original_failed_source='86b03fbce60d6565302d4405235866fce056f96b',original_CI_log_bytes_normalized=False,successful_portable_jobs=4,original_preflight_failures=4,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(name,len(raw),SHA(raw),len(members),flush=True)
