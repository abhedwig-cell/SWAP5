"""Preserve the actual first PR checkout-guard refusal and all prior gate roles."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='09e5847a8fc4873b471f9e91eb7f2136ad64c76b';S='cffa9b9fd12bc19b93ab1c9581ce1ae6609f8c48';SHA=lambda raw:hashlib.sha256(raw).hexdigest()
q=json.loads((E/'CLOSED_DEFAULT_CALENDAR_STATE14_PR1813_FIRST_HEAD_ORIGINAL_LOG_CUSTODY_V1.json').read_text());assert len(q['runs'])==15 and len(q['jobs'])==29 and sum(v['conclusion']=='failure' for v in q['jobs'])==1 and len(q['skipped_jobs'])==17
failure=next(v for v in q['jobs'] if v['conclusion']=='failure');assert failure['job_id']==140679910663
log=(E/failure['original_log']).read_bytes();assert b'test_original_workflow_body_cannot_be_rewritten' in log and b'Foreign complete current checkout workflow: .github/workflows/fci-canonical.yml' in log
negative=json.loads((E/'CLOSED_DEFAULT_CALENDAR_STATE14_FINAL1_NEGATIVES_V1.json').read_text());assert negative['candidate']==C and negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN3_PUBLIC_NEGATIVES_REFUSED' and len(negative['controls'])==4
for label in ['PUBLIC','PUBLICATION']:
    v=json.loads((E/('CLOSED_DEFAULT_CALENDAR_STATE14_CANDIDATE_'+label+'_V1.json')).read_text());assert v['returncode']==0 and v['before']==v['after'] and v['before']['head']==C
name='CLOSED_DEFAULT_CALENDAR_STATE14_FIRST_PR_CHECKOUT_GUARD_REFUSAL_RAW_V6';target=E/(name+'.zip');members={};selected={}
prefixes=('CLOSED_DEFAULT_CALENDAR_STATE14_PR1813_FIRST_HEAD','CLOSED_DEFAULT_CALENDAR_STATE14_CANDIDATE_',
          'CLOSED_DEFAULT_CALENDAR_STATE14_FINAL1_','CLOSED_DEFAULT_CALENDAR_STATE14_ACTUAL_NEGATIVE_',
          'CLOSED_DEFAULT_CALENDAR_STATE14_PR1813_FINAL_SYNTHETIC_','CLOSED_DEFAULT_CALENDAR_STATE14_PR1813_GENUINE_GIT_OBJECT_'+S,
          'CLOSED_DEFAULT_CALENDAR_STATE14_DOCS_QA_V1')
for path in E.iterdir():
    if path.is_file() and path.name.startswith(prefixes) and path.suffix in ['.py','.json','.log','.txt','.bin','.zip']:
        selected[path.name]=path
for filename in ['closed-default-calendar14-capture-first-pr-refusal-v1.py','closed-default-calendar14-capture-pr-terminal-logs-v1.py','closed-default-calendar14-real-negative-controls-v1.py','closed-default-calendar14-negative-observe-v1.py','closed-default-calendar14-negative-git-custody-v1.py','closed-default-calendar14-seal-current-negative-objects-v1.py','closed-default-calendar14-seal-first-pr-guard-refusal-v6.py']:
    selected['controllers/'+filename]=E/filename
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for key,path in sorted(selected.items()):
        raw=path.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=subprocess.check_output(['git','archive','--format=zip',C,'tests/hupsel51/test_successor.py','tests/nomacro_drainage/ci_checkout_scope07.py','.github/workflows/fci-canonical.yml'],cwd=R);key='source/'+C+'-actual-first-failing-workflow-guard-source.zip';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for key,item in members.items():
        raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=target.read_bytes();assert len(raw)<48*1024**2
q=dict(status='FIRST_REAL_PR_GUARD_REFUSAL_RETAINED_AFTER_TRUE_CANDIDATE_PUBLIC_PUBLICATION_AND_FOUR_REAL_NEGATIVE_PASSES',actual_candidate=C,actual_signed_synthetic=S,actual_failed_job=140679910663,
    archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,
    original_PR_workflows=15,original_job_logs=29,original_skipped_jobs=17,actual_PR_workflow_failures=1,actual_failed_job_is_admission_guard_not_model_period=True,
    classification='EVIDENCE_ONLY',cause='The prior exact historical workflow guard does not yet recognize the two new original-evidence checkout exclusions; all qualification command bodies remain unchanged.',
    scientific_producers_or_prior_PASS_failure_roles_rebound=False,model_periods_replayed_for_this_repair=0,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(name,len(raw),SHA(raw),len(members),flush=True)
