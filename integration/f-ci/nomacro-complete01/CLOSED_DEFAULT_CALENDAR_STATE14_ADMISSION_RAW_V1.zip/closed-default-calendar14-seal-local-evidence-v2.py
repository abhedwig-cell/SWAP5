"""Preserve all first failures and actual ten-context local successes once."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
SHA=lambda raw:hashlib.sha256(raw).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=R)
C=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
contexts=[]
for opt in ['O0','O2']:
    for path in sorted((E/'closure14-native-v2'/opt).glob('*.independent.json')):
        q=json.loads(path.read_text());assert q['status']=='INDEPENDENT_ACTUAL_DEFAULT_CALENDAR_INPUT_SOURCE_BUDGET_PRIVATE_NATIVE_COLD_TRANSACTION_PASS'
        contexts.append(q)
assert len(contexts)==10 and sum(q['days'] for q in contexts)==350 and sum(q['native_refusals'] for q in contexts)==292
failures=[]
for version,expected in [('v1',4),('v2',4)]:
    found=[]
    for path in sorted((E/('closure14-feedback-'+version)).rglob('RESULT.json')):
        q=json.loads(path.read_text())
        if not q['status'].startswith('FAILED_'):continue
        daily=path.parent/'trajectory/daily.jsonl';days=len(daily.read_text().splitlines()) if daily.exists() else 0
        assert days==0;found.append(dict(case=q['case'],optimization=q['optimization'],actual_source=q['actual_source'],model_days=days,error=q['error'],role='ORIGINAL_FAILURE_NOT_PASS'))
    assert len(found)==expected;failures.extend(found)
summary=dict(status='TEN_LOCAL_CONTEXTS_INDEPENDENTLY_PASS_ALL_EARLIER_FAILURE_ROLES_RETAINED_PORTABLE_PENDING',actual_observer_source=C,contexts=contexts,
    original_failures=failures,counts=dict(contexts=10,primary_days=350,native_samples=sum(len(q['native_samples']) for q in contexts),cold_windows=sum(len(q['cold']) for q in contexts),compiled_native_refusals=292,own_positive_native_startups=10,external_transactions=10),
    new_qualified_contexts=0,new_admitted_contexts=0,canonical_admission=False)
(E/'CLOSED_DEFAULT_CALENDAR_STATE14_LOCAL_INDEPENDENT_TEN_V2.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
name='CLOSED_DEFAULT_CALENDAR_STATE14_ALL_LOCAL_FAILURES_AND_SUCCESSES_RAW_V2';target=E/(name+'.zip');members={}
roots=[E/('closure14-feedback-'+v) for v in ['v1','v2','v3']]+[E/('closure14-native-'+v) for v in ['v1','v2']]+[W/('closure14-feedback-'+opt+'-'+v) for opt in ['O0','O2'] for v in ['v1','v2','v3']]
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def put(name,raw):
        assert name not in members;z.writestr(name,raw);members[name]=dict(bytes=len(raw),sha256=SHA(raw))
    for root in roots:
        assert root.is_dir()
        for path in sorted(root.rglob('*')):
            if path.is_file():put('actual/'+path.relative_to(W).as_posix(),path.read_bytes())
    for producer in sorted({q['actual_producer'] for q in contexts}|{q['actual_source'] for q in failures}|{C}):
        raw=git('archive','--format=zip',producer,'app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','tests/nomacro_mixtures','docs/science/NOMACRO_CLOSED_DEFAULT_CALENDAR_STATE14.md')
        put('source/'+producer+'-actual-source.zip',raw)
    for path in sorted(E.iterdir()):
        if path.is_file() and path.suffix in ('.json','.py','.log') and path.name.startswith(('CLOSED_DEFAULT_CALENDAR_STATE14_','closed-default-calendar14-','closed_default_calendar_science.')) and path.name!=name+'.json':
            put('controllers-and-observations/'+path.name,path.read_bytes())
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for key,v in members.items():
        raw=z.read(key);assert len(raw)==v['bytes'] and SHA(raw)==v['sha256']
raw=target.read_bytes();parts=[];cap=48*1024**2
if len(raw)<=cap:parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))]
else:
    for index,offset in enumerate(range(0,len(raw),cap),1):
        chunk=raw[offset:offset+cap];path=target.with_name(target.name+'.part'+str(index).zfill(3));path.write_bytes(chunk);parts.append(dict(file=path.name,bytes=len(chunk),sha256=SHA(chunk)))
    assert b''.join((E/v['file']).read_bytes() for v in parts)==raw
descriptor=dict(status=summary['status'],actual_observer_source=C,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,counts=summary['counts'],original_failure_contexts=8,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(descriptor,indent=2)+'\n',encoding='utf8')
print(name,len(raw),SHA(raw),len(members),len(parts),summary['counts'],flush=True)
