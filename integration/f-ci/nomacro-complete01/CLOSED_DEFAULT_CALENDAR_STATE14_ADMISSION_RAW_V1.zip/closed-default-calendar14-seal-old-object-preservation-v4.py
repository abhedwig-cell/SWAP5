"""Retain forty current complete numerical builds and original native startups."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='12833d6ede29b8379d330fcee238c9ae32d4f3ef';SHA=lambda raw:hashlib.sha256(raw).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
rows=[]
for opt in ['O0','O2']:
    q=json.loads((E/'closure14-preservation-v1'/opt/'RESULT.json').read_text());assert q['actual_compiler_source']==C and q['status'].startswith('TWENTY_ACTUAL_OLD_COMPLETE_') and len(q['contexts'])==20 and q['model_days']==q['model_executions']==0
    rows+=q['contexts']
assert len(rows)==40 and sum(v['whole_object_proof']['actual_complete_objects'] for v in rows)==1046
name='CLOSED_DEFAULT_CALENDAR_STATE14_FORTY_OLD_OBJECTS_AND_NATIVE_RAW_V4';target=E/(name+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in [E/'closure14-preservation-v1',W/'closure14-preservation-O0-v1',W/'closure14-preservation-O2-v1']:
        for path in sorted(root.rglob('*')):
            if path.is_file():
                raw=path.read_bytes();key='actual/'+path.relative_to(W).as_posix();assert key not in members;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=git('archive','--format=zip',C,'app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','docs/science/NOMACRO_CLOSED_DEFAULT_CALENDAR_STATE14.md');key='source/'+C+'-actual-controller-source.zip';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    for filename in ['closed-default-calendar14-seal-old-object-preservation-v4.py','CLOSED_DEFAULT_CALENDAR_STATE14_OLD_OBJECT_SELECTION_V1.json']:
        raw=(E/filename).read_bytes();key='controllers-and-observations/'+filename;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for key,item in members.items():
        raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=target.read_bytes();parts=[];cap=48*1024**2
if len(raw)<=cap:parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))]
else:
    for index,offset in enumerate(range(0,len(raw),cap),1):
        body=raw[offset:offset+cap];path=target.with_name(target.name+'.part'+str(index).zfill(3));path.write_bytes(body);parts.append(dict(file=path.name,bytes=len(body),sha256=SHA(body)))
    assert b''.join((E/v['file']).read_bytes() for v in parts)==raw
q=dict(status='FORTY_ACTUAL_COMPLETE_OLD_GENERATED_SOURCES_AND_1046_WHOLE_OBJECTS_EXACT_ORIGINAL_NATIVE_READERS_PASS',actual_compiler_source=C,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,contexts=40,whole_objects=1046,whole_objects_unchanged=1046,original_native_positives=24,compiled_native_refusals=96,old_model_periods_replayed=0,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(name,len(raw),SHA(raw),len(members),len(parts),flush=True)
