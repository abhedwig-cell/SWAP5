"""Preserve the actual original mixed J SDK once; never rebuild or relabel it."""
from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).parent;J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');SHA=lambda raw:hashlib.sha256(raw).hexdigest()
prepared=json.loads((J/'PREPARED.json').read_text());names=set(prepared['provider_files'])|{'PREPARED.json','compile.log'}
identities=[]
for version in ['v1','v3']:
    for path in (E/('closure14-feedback-'+version)).rglob('RESULT.json'):
        q=json.loads(path.read_text())
        if not q['status'].endswith('FEEDBACK_PASS_NOT_QUALIFIED'):continue
        meta=json.loads((Path(q['build_root'])/'BUILD.json').read_text());identities.append((q,meta['identity']))
assert len(identities)==10
for q,identity in identities:
    for field,prefix in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
        for name,digest in identity[field].items():
            relative='build/'+prefix+'/'+name;names.add(relative);assert SHA((J/relative).read_bytes())==digest
    assert SHA((J/'build/ttutil-obj/libttutil.a').read_bytes())==identity['ttutil_library'];names.add('build/ttutil-obj/libttutil.a')
name='CLOSED_DEFAULT_CALENDAR_STATE14_ORIGINAL_MIXED_J_SDK_RAW_V5';target=E/(name+'.zip');members={};drift=[]
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for relative in sorted(names):
        path=J/relative;assert path.is_file();raw=path.read_bytes()
        key='original-provider-build/'+relative.removeprefix('build/') if relative.startswith('build/') else 'original-'+relative
        z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw),actual_original_relative_path=relative)
        declared=prepared['provider_files'].get(relative)
        if declared is not None and declared!=SHA(raw):drift.append(dict(path=relative,original_PREPARED_declared_sha256=declared,actual_used_and_preserved_sha256=SHA(raw)))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for key,v in members.items():
        raw=z.read(key);assert SHA(raw)==v['sha256'] and len(raw)==v['bytes']
raw=target.read_bytes();assert len(raw)<48*1024**2
descriptor=dict(status='EXACT_ORIGINAL_MIXED_J_SDK_BYTES_USED_BY_TEN_LOCAL_CONTEXTS_PRESERVED_ONCE',actual_original_provider_root=str(J),
    archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,
    actual_compiler_sha256=prepared['toolchain']['gfortran']['sha256'],original_PREPARED_declaration_retained_unmodified=True,original_PREPARED_vs_actual_used_file_differences=drift,
    actual_local_BUILD_sha256=[q['actual_BUILD_sha256'] for q,_ in identities],all_O0_provider_claimed=False,SDK_rebuilt=False,source_identity_rebound=False,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(descriptor,indent=2)+'\n',encoding='utf8');print(name,len(raw),SHA(raw),len(members),'original_manifest_differences',len(drift),flush=True)
