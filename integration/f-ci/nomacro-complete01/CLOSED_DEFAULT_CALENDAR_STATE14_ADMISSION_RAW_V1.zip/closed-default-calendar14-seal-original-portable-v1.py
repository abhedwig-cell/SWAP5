"""Retain original connector ZIP bytes and audit four actual portable artifacts."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from closed_default_calendar_portable_science import audit,PRODUCER
records=json.loads((E/'closure14-first-ci-artifacts-v1/ORIGINAL_CONNECTOR_ARTIFACTS.json').read_text())
specs=[('Windows','O0',15220429480,46044072519,140658812547),('Windows','O2',15220374450,46044072519,140658812995),
       ('Ubuntu','O0',15220524197,46044072466,140658811865),('Ubuntu','O2',15222030264,46044072466,140658812222)]
for platform,opt,artifact,run,job in specs:
    q=next(v for v in records if v['artifact_id']==artifact);name='CLOSED_DEFAULT_CALENDAR_STATE14_FIRST_'+platform.upper()+'_'+opt+'_ORIGINAL_V1';raw=E/'closure14-first-ci-artifacts-v1'/q['file']
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==q['sha256'] and raw.stat().st_size==q['bytes']<48*1024**2
    target=P/(name+'.zip')
    if target.exists():assert target.read_bytes()==raw.read_bytes()
    else:shutil.copyfile(raw,target)
    descriptor=dict(status='EXACT_ORIGINAL_GITHUB_ACTIONS_ARTIFACT_BYTES_RETAINED',actual_producer_source=PRODUCER,actual_workflow_run=run,actual_job=job,
        actual_artifact_id=artifact,connector_file_id=q['connector_file_id'],archive=target.name,bytes=q['bytes'],sha256=q['sha256'],parts=[dict(file=target.name,bytes=q['bytes'],sha256=q['sha256'])],members=q['members'],canonical_admission=False)
    for folder in [P,E]:(folder/(name+'.json')).write_text(json.dumps(descriptor,indent=2)+'\n',encoding='utf8')
    print('ORIGINAL_PORTABLE_ZIP_RETAINED',platform,opt,q['bytes'],q['sha256'],len(q['members']),flush=True)
observed=[]
for platform,opt,*_ in specs:
    q=audit(P,platform,opt);name='CLOSED_DEFAULT_CALENDAR_STATE14_FIRST_'+platform.upper()+'_'+opt+'_INDEPENDENT_V1.json'
    for folder in [P,E]:(folder/name).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
    observed.append(q);print('INDEPENDENT_ACTUAL_PORTABLE_PASS',platform,opt,q['context_count'],q['primary_days'],q['compiled_native_refusals'],flush=True)
assert sum(q['context_count'] for q in observed)==20
print('ALL_TWENTY_ACTUAL_PORTABLE_CONTEXTS_INDEPENDENT_PASS',flush=True)
