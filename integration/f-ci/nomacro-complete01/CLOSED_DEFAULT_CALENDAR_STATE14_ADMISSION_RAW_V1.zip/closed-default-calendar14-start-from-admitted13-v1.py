from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';M='ae54d7d621a07e54dd8f9fdb758585b2a2cc754d';SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *v:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*v],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
receipt=json.loads((E/'CLOSED_IMPLICIT_STATE13_MERGE_RECEIPT_V1.json').read_text());assert receipt['actual_merge']==M and receipt['canonical_admission'] and receipt['coadmission']['contexts']==1004
thin=json.loads((E/'CLOSED_DEFAULT_CALENDAR_STATE14_THIN_BASELINE_INDEPENDENT_IDENTITY_V1.json').read_text());assert all(v['complete_stdout_byte_identical'] for v in thin['observations'])
branch='codex/nomacro-closed-default-calendar14';git('switch','-c',branch,M)
for name in ['CLOSED_IMPLICIT_STATE13_ADMISSION_RAW_V2.zip','CLOSED_IMPLICIT_STATE13_ADMISSION_RAW_V2.json','CLOSED_IMPLICIT_STATE13_MERGE_RECEIPT_V1.json']:
    assert not (P/name).exists();shutil.copyfile(E/name,P/name);assert (P/name).read_bytes()==(E/name).read_bytes()
stem='CLOSED_DEFAULT_CALENDAR_STATE14_DISCOVERY_AND_THIN_BASELINE_RAW_V1';target=E/(stem+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in [E/'closure14-accepted-original-inputs-v1',E/'closure14-original-zero-day-v1']:
        for path in sorted(root.rglob('*')):
            if path.is_file():
                raw=path.read_bytes();name='actual/'+path.relative_to(W).as_posix();z.writestr(name,raw);members[name]=dict(bytes=len(raw),sha256=SHA(raw))
    for path in sorted(E.iterdir()):
        if path.is_file() and path.name.startswith(('CLOSED_DEFAULT_CALENDAR_STATE14_','closed-default-calendar14-')) and path.suffix in ['.json','.py','.txt'] and path.name!=stem+'.json':
            raw=path.read_bytes();z.writestr(path.name,raw);members[path.name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for name,item in members.items():assert len(z.read(name))==item['bytes'] and SHA(z.read(name))==item['sha256']
raw=target.read_bytes();assert len(raw)<48*1024**2
q=dict(status='FIVE_ORIGINAL_CLOSED_DEFAULT_INITIALIZATIONS_CURRENT_FRONTEND_REFUSALS_AND_REAL_THIN_BASELINE_PRESERVED_NOT_FUNCTIONALLY_QUALIFIED',actual_accepted_canonical=M,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,original_initializations_accepted=5,current_frontend_refusals=5,actual_frontend_observer='2d810e6db3acf6eb81ff96dae90859670eae9b3a',actual_thin_baseline_observer=M,thin_complete_public_and_ordinary_publication_outputs_identical=True,compiler_executions=0,model_executions=0,new_qualified_contexts=0,canonical_admission=False)
(E/(stem+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for name in [stem+'.json',target.name]:assert not (P/name).exists();shutil.copyfile(E/name,P/name)
for name in ['STATUS.json','GAP_MATRIX.json']:
    path=P/name;state=json.loads(path.read_text());state['canonical']=M;state['closed_implicit_state13_admission']=receipt;state['closed_default_calendar_state14']=dict(status='IMPLEMENTATION_PENDING_FIVE_PROVEN_ORIGINAL_FRONTEND_COMPOSITION_GAPS',classification='COMPOSITION_MISSING',baseline=M,original_initializations_accepted=5,current_frontend_refusals=5,original_physical_parameters_profiles_forcing_output_controls_and_dates_preserved=True,declared_selector_changes=dict(SWDRA=0,SWBOTB=6),actual_thin_baseline=thin['status'],qualified_contexts=0,new_admitted_contexts=0,canonical_admission=False,next_action='Implement the actual default-model1 original pressure/calendar closed state owner and exact zero-bottom CDE trial composition; qualify physical/native/cold/transaction semantics and preserve all unchanged domains.')
    if name=='STATUS.json':state.update(branch=branch,last_commit=M,running_ci=[],active_local_jobs=[],recovery_point=stem+'.json',next_action=state['closed_default_calendar_state14']['next_action'])
    path.write_text(json.dumps(state,indent=2)+'\n',encoding='utf8')
paths=['integration/f-ci/nomacro-complete01/'+name for name in ['CLOSED_IMPLICIT_STATE13_ADMISSION_RAW_V2.zip','CLOSED_IMPLICIT_STATE13_ADMISSION_RAW_V2.json','CLOSED_IMPLICIT_STATE13_MERGE_RECEIPT_V1.json',stem+'.zip',stem+'.json','STATUS.json','GAP_MATRIX.json']]
git('add','--sparse','--',*paths);git('diff','--cached','--check');print(git('commit','-m','Preserve genuine canonical1004 admission and original closed calendar gaps').decode(),flush=True);print('NEXT_FUNCTIONAL_BLOCK_STARTED',git('rev-parse','HEAD').decode().strip(),len(raw),q['sha256'],len(members),flush=True)
