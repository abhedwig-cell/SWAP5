"""Omit only exact retained Git archive copies through standard reversible sparse checkout."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');W=E.parent;TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';M='ae54d7d621a07e54dd8f9fdb758585b2a2cc754d';TREE='202bb30e809e46770b591bb56ce94866dbdffbfb';SHA=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *v,**kw:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*v],cwd=R,**kw)
expected_store=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/SWAP5/.git').resolve();actual_store=Path(git('rev-parse','--path-format=absolute','--git-common-dir').decode().strip()).resolve();assert actual_store==expected_store
assert R.resolve()==Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01').resolve() and git('rev-parse','HEAD').decode().strip()==M and git('rev-parse','HEAD^{tree}').decode().strip()==TREE and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
for scope in ['PUBLIC','PUBLICATION']:
    q=json.loads((E/('CLOSED_IMPLICIT_STATE13_ACTUAL_MERGE_'+scope+'_V1.json')).read_text());assert q['returncode']==0 and q['before']==q['after'] and q['before']['head']==M
def overlaps():
    state=json.loads(Path('C:/Users/Veldh012/.codex/storage/swap5/state.json').read_text());hits=[];own=R.resolve()
    assert state['tasks'][TASK]['state']=='active'
    for task,value in state['tasks'].items():
        if task==TASK or value['state']!='active':continue
        for name in value['protects']:
            path=Path(name).resolve()
            if own==path or own.is_relative_to(path) or path.is_relative_to(own):hits.append(dict(task=task,path=str(path)))
    return hits
assert not overlaps(),'Another active task needs this physical checkout'
def index():
    rows={}
    for line in git('ls-files','-v','-s','-z').split(b'\0'):
        if line:
            meta,path=line.split(b'\t',1);flag,mode,digest,stage=meta.decode().split();assert stage=='0';rows[path.decode()]=dict(flag=flag,mode=mode,blob=digest)
    return rows
before=index();sparse_file=Path(git('rev-parse','--git-path','info/sparse-checkout').decode().strip());sparse_file=sparse_file if sparse_file.is_absolute() else R/sparse_file;old_sparse=sparse_file.read_bytes();assert len(old_sparse.decode().splitlines())==14
old_record=E/'CLOSED_DEFAULT_CALENDAR_STATE14_PREVIOUS_SPARSE_CHECKOUT_V1.txt';assert not old_record.exists();old_record.write_bytes(old_sparse)
fixture=lambda:{p.relative_to(R).as_posix():SHA(p.read_bytes()) for p in (R/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()};projects=fixture();assert len(projects)==56
q=dict(status='VERIFYING_REAL_ARCHIVE_GIT_BYTES_BEFORE_STANDARD_SPARSE_CHECKOUT',actual_source=M,actual_tree=TREE,task=TASK,task_remains_active=True,selection_record='https://github.com/abhedwig-cell/SWAP5/pull/1812',actual_common_git_store=str(actual_store),original_sparse_file=old_record.name,original_sparse_sha256=SHA(old_sparse),original_project_files=projects,other_active_task_protection_overlaps=[],archives=[],free_before=shutil.disk_usage(R).free,source_or_Git_identity_projected=False,compiler_executions=0,model_executions=0,new_qualified_contexts=0,canonical13_push_CI_still_pending=True)
target=E/'CLOSED_DEFAULT_CALENDAR_STATE14_THIN_WORKTREE_PREPARATION_V1.json';assert not target.exists();save=lambda:target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');save()
copies=[]
for name,item in before.items():
    path=R/name
    if name.startswith('integration/') and re.search(r'\.zip(?:$|\.part)',name) and path.is_file():
        assert item['mode']=='100644' and not path.is_symlink() and path.resolve().is_relative_to(R.resolve());copies.append((name,item,path))
assert copies
child=subprocess.Popen(['git','-c','gc.auto=0','-c','maintenance.auto=false','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
try:
    for name,item,path in copies:
        size=path.stat().st_size;child.stdin.write((item['blob']+'\n').encode());child.stdin.flush();header=child.stdout.readline().decode().split();assert header==[item['blob'],'blob',str(size)];digest=hashlib.sha256();object_hash=hashlib.sha1(b'blob '+str(size).encode()+b'\0');total=0
        with path.open('rb') as stream:
            while True:
                raw=stream.read(8*1024**2)
                if not raw:break
                central=child.stdout.read(len(raw));assert central==raw,(name,total);digest.update(raw);object_hash.update(raw);total+=len(raw)
        assert total==size and object_hash.hexdigest()==item['blob'] and child.stdout.read(1)==b'\n';q['archives'].append(dict(path=name,bytes=size,sha256=digest.hexdigest(),actual_retained_git_blob=item['blob'],every_original_working_byte_compared_with_real_git_bytes=True))
        if len(q['archives'])%25==0:save();print('EXACT_RETAINED_GIT_ARCHIVE_COPIES_VERIFIED',len(q['archives']),flush=True)
finally:child.stdin.close();assert child.wait(timeout=30)==0
save();assert not overlaps() and git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
ref='refs/heads/codex/storage-retained/closure14-thin-source-baseline-20261127';git('update-ref',ref,M);q['retained_ref']=ref
new_sparse=b'/*\n!/integration/**/*.zip\n!/integration/**/*.zip.part*\n';q['selected_sparse_patterns']=new_sparse.decode().splitlines();save()
git('sparse-checkout','set','--no-cone','--stdin',input=new_sparse)
after=index();assert {n:(v['mode'],v['blob']) for n,v in before.items()}=={n:(v['mode'],v['blob']) for n,v in after.items()}
assert git('rev-parse','HEAD').decode().strip()==M and git('rev-parse','HEAD^{tree}').decode().strip()==TREE and not git('status','--porcelain=v1','--untracked-files=all','--ignored') and fixture()==projects and sparse_file.read_bytes()==new_sparse
for name,item,path in copies:assert not path.exists() and after[name]['flag']=='S'
q.update(status='REAL_M13_THIN_WORKING_VIEW_PREPARED_ALL_SOURCE_INDEX_AND56_PROJECT_FILES_UNCHANGED',source_and_fixture_bytes_changed=False,removed_reproducible_working_archive_copies=len(copies),logical_duplicate_bytes=sum(v['bytes'] for v in q['archives']),free_after=shutil.disk_usage(R).free);q['actual_net_free_change']=q['free_after']-q['free_before'];save();print(q['status'],len(copies),q['logical_duplicate_bytes'],q['actual_net_free_change'],flush=True)
body=(E/'closed-implicit-state13-actual-merge-observer-v1.py').read_text().replace("'CLOSED_IMPLICIT_STATE13_ACTUAL_MERGE_'","'CLOSED_DEFAULT_CALENDAR_STATE14_THIN_BASELINE_'").replace("len(before['sparse'])==14","len(before['sparse'])==3")
observer=E/'closed-default-calendar14-thin-baseline-observe-v1.py';assert not observer.exists();compile(body,observer.name,'exec');observer.write_text(body,encoding='utf8')
