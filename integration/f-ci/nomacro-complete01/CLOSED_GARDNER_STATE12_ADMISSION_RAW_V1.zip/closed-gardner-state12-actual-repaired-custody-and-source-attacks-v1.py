"""Fresh Git byte custody and real negative whole-source interface controls."""
from pathlib import Path
import hashlib,json,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from closed_gardner_state_feedback import m,SHA,git
from ordinary_pond_source_guard import validate
head=git('rev-parse','HEAD').decode().strip();assert head=='eb4198bed4ad7480bf2048204a7f368052607e16'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
stem='CLOSED_GARDNER_STATE12_FIRST_LOCAL_SUCCESSES_FAILURES_RAW_V1';prefix='integration/f-ci/nomacro-complete01/'
descriptor=json.loads(git('show',head+':'+prefix+stem+'.json'));whole=hashlib.sha256();parts=[]
for item in descriptor['parts']:
    raw=git('show',head+':'+prefix+item['file']);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
    assert raw==(E/item['file']).read_bytes();whole.update(raw);parts.append(item)
assert whole.hexdigest()==descriptor['sha256']=='8acadb26f64f33f3836719af90341aeaf1de80dae37ab2bebe81be7dcc6aed6b'
q=dict(status='RUNNING_ACTUAL_REPAIRED_SOURCE_NEGATIVES_AND_ORIGINAL_RAW_GIT_CUSTODY',actual_observer=head,
    original_first_cohort_producer='3be78ad24d2bce348f38a26e289af0f4846c5883',actual_retained_archive_sha256=whole.hexdigest(),
    actual_retained_archive_bytes=descriptor['bytes'],actual_retained_members=len(descriptor['members']),parts=parts,
    archive_CRC_not_repeated_because_whole_bytes_equal_to_previously_full_verified_seal=True,model_executions=0,compiler_executions=0,source_attacks=[],canonical_admission=False)
root=W/'closure12-original-causal-v1/repaired-source-attacks-v1';root.mkdir()
for opt in ['O0','O2']:
    for name in ['closed-ordinary-implicit-h0-water-profile','closed-ordinary-implicit-h1-cde','closed-ordinary-implicit-h2-water']:
        profile=W/'closure12-feedback-v1'/('finite-'+opt+'-v1')/name;old=json.loads((profile/'RESULT.json').read_text());build=Path(old['build_root']);meta=json.loads((build/'BUILD.json').read_text())
        project=m.e.load(old['input_root'],original_output=True,time_step_policy=old['time_step_policy']);validate(build,project,meta['identity'])
        source=(build/'headcalc.f90').read_text(encoding='cp1252');anchor='if (abs(deviat) > CritDevPondDt)';assert source.count(anchor)==1
        bad=source.replace(anchor,'if (abs(deviat) > 2d0*CritDevPondDt)',1);target=root/(name+'-'+opt);target.mkdir();(target/'headcalc.f90').write_text(bad,encoding='cp1252')
        try:validate(target,project,meta['identity'])
        except ValueError as error:
            assert str(error)=='Foreign actual ordinary implicit coupled HeadCalc provider'
            q['source_attacks'].append(dict(case=name,optimization=opt,actual_original_compiler_source=old['actual_source'],actual_original_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()),positive_whole_source_accepted=True,
                actual_mutant_lf_sha256=SHA(bad.encode('cp1252')),changed_actual_pond_tolerance_source_refused=True,error=str(error)))
        else:raise AssertionError('Actual whole-source tolerance mutant accepted')
q['status']='ACTUAL_REPAIRED_SIX_POSITIVE_WHOLE_SOURCE_AND_SIX_TOLERANCE_MUTANT_REFUSALS_AND_EXACT_FIRST_RAW_GIT_BYTES_PASS'
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
(E/'CLOSED_GARDNER_STATE12_ACTUAL_REPAIRED_CUSTODY_AND_SOURCE_ATTACKS_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(q['status'],flush=True)
