"""Seal observed genuine canonical948 admission; never run a model or compiler."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
B='105b9a8e6ca9e846f214d69a71afe73ed18be11d';C='07cb2850e2cd45deb1e197161409a3784a8975e7';S='8fe30349bfb9717e9610008d1eebe5a957a8f476';M='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';A='b2ac1ce22bf248ac9cca7717945c86c9cec03550';TREE='8df17cc12686e8ab5522360b87f6430a345aabdb'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((E/n).read_text(encoding='utf8'))
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
for sha in [C,S,M]:assert git('rev-parse',sha+'^{tree}').decode().strip()==TREE
for sha in [S,M]:
    assert git('show','-s','--format=%P',sha).decode().split()==[B,C]
    raw=(E/('CLOSED_GARDNER_STATE12_PR1811_GENUINE_GIT_OBJECT_'+sha+'.bin')).read_bytes();assert raw==git('cat-file','commit',sha) and hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha
api=read('CLOSED_GARDNER_STATE12_PR1811_ACTUAL_GIT_API_V1.json');assert api['sha']==M and api['verification']['verified'] and api['verification']['reason']=='valid'
observations={};fixtures=None;coadmission=None
for role,head,scope,version in [('CANDIDATE',C,'PUBLIC','V1'),('CANDIDATE',C,'PUBLICATION','ORDINARY_V2'),('ACTUAL_MERGE',M,'PUBLIC','V1'),('ACTUAL_MERGE',M,'PUBLICATION','V1')]:
    stem='CLOSED_GARDNER_STATE12_'+role+'_'+scope+'_'+version;q=read(stem+'.json');raw=(E/(stem+'.stdout.txt')).read_bytes()
    assert q['returncode']==0 and q.get('error') is None and q['before']==q['after'] and not q['before']['status'] and not (E/(stem+'.stderr.txt')).read_bytes()
    before=q['before'];assert before['head']==head and before['tree']==TREE and len(before['sparse'])==14 and len(before['original_project_files'])==56
    if fixtures is None:fixtures=before['original_project_files']
    assert fixtures==before['original_project_files']
    if scope=='PUBLIC':
        actual=json.loads(raw);assert actual['coadmission']['contexts']==948 and len(actual['new_original_portable_science'])==4 and not actual['additional_local_contexts_counted_again'] and not actual['unchanged_periods_replayed'] and not actual['original_scientific_producers_rebound']
        assert actual['compiler_executions']==actual['model_executions']==0 and len(actual['deferred_numerical_cases'])==2
        assert actual['additional_actual_local_and_whole_object_science']['whole_objects']==1046
        if coadmission is None:coadmission=actual['coadmission']
        assert actual['coadmission']==coadmission
    else:assert b'PUBLICATION_REPLAY_SELECTED=false' in raw and q['ordinary_python_default_dont_write_bytecode'] is False and q['child_bytecode_environment_variables_absent']
    observations[stem]=dict(actual_head=head,seconds=q['seconds'],stdout_bytes=len(raw),stdout_sha256=SHA(raw))
assert tuple(coadmission[k] for k in ['contexts','short35_contexts','native_calendar_samples','exact_cold_windows'])==(948,854,6282,2760)
neg=read('CLOSED_GARDNER_STATE12_FINAL1_NEGATIVES_V3.json');assert neg['candidate']==C and neg['never_merge'] and neg['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED' and len(neg['controls'])==4
for item in neg['controls']:
    assert item['actual_refusal'] and item['actual_one_file_delta'] and git('show','-s','--format=%P',item['head']).decode().split()==[C] and git('diff','--name-only',C,item['head']).decode().strip()==item['path']
    record=read(item['actual_observation']+'.json');assert record['returncode'] not in (None,0) and record['before']==record['after'] and record['before']['head']==item['head'] and record['before']['original_project_files']==fixtures
assert neg['controls'][-1]['actual_publication_replay_selected']
custody=read('CLOSED_GARDNER_STATE12_FINAL1_NEGATIVE_GIT_CUSTODY_V1.json');assert len(custody['controls'])==4
runs=read('CLOSED_GARDNER_STATE12_PR1811_ALL_CI_API_V1.json');checks=read('CLOSED_GARDNER_STATE12_PR1811_ALL_CHECKS_API_V1.json')
assert runs['total_count']==len(runs['workflow_runs'])==14 and all(v['head_sha']==C and v['status']=='completed' and v['conclusion']=='success' for v in runs['workflow_runs'])
assert checks['total_count']==len(checks['check_runs'])==45 and all(v['status']=='completed' and v['conclusion'] in ['success','skipped'] for v in checks['check_runs'])
assert sum(v['conclusion']=='success' for v in checks['check_runs'])==28 and sum(v['conclusion']=='skipped' for v in checks['check_runs'])==17
logs=[]
for label,count in [('PART1',26),('PART2',2)]:
    q=read('CLOSED_GARDNER_STATE12_PR1811_'+label+'_ORIGINAL_LOG_CUSTODY_V1.json');assert len(q['observations'])==count
    for item in q['observations']:
        raw=(E/item['log']).read_bytes();raw.decode('utf8',errors='strict');assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and item['actual_head']==C
        job=read('CLOSED_GARDNER_STATE12_PR1811_JOB_'+str(item['job_id'])+'_ORIGINAL_API_V1.json');assert job['head_sha']==C and job['conclusion']=='success';logs.append(item)
    if label=='PART2':assert all(v['actual_signed_checkout_printed_in_log'] for v in q['observations'])
mc=read('CLOSED_GARDNER_STATE12_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json');assert mc['actual_parent']==B and mc['actual_candidate']==C and mc['unchanged_tracked_files']==1063 and not git('diff',B,M,'--',*mc['unchanged_dependency_paths'])
canonical=read('CLOSED_GARDNER_STATE12_ACTUAL_MERGE_ALL_CI_API_V1.json');assert canonical['total_count']==len(canonical['workflow_runs'])==4
for run in canonical['workflow_runs']:assert run['head_sha']==M and run['status']=='completed' and run['conclusion']=='success'
for run in canonical['workflow_runs']:
    jobs=read('CLOSED_GARDNER_STATE12_ACTUAL_MERGE_CI_JOBS_'+str(run['id'])+'_V1.json')
    assert jobs['total_count']==len(jobs['jobs']) and jobs['jobs'] and all(j['status']=='completed' and j['conclusion'] in ['success','skipped'] for j in jobs['jobs'])
canonical_logs=read('CLOSED_GARDNER_STATE12_ACTUAL_MERGE_COMPLETE_ORIGINAL_LOG_CUSTODY_V1.json');assert len(canonical_logs['observations'])==5
for item in canonical_logs['observations']:
    value=(E/item['log']).read_bytes();value.decode('utf8',errors='strict');assert item['actual_head']==M and len(value)==item['bytes'] and SHA(value)==item['sha256']
    if item['role'].endswith('/ modular-feedback'):assert item['actual_signed_checkout_printed_in_log'] and b'"contexts": 948' in value
name='CLOSED_GARDNER_STATE12_ADMISSION_RAW_V1';archive=E/(name+'.zip');assert not archive.exists();files={}
for path in E.iterdir():
    if not path.is_file() or path.suffix in ['.zip','.tar','.gz','.xz'] or '.zip.part' in path.name or path.name.startswith(name):continue
    if path.name.startswith(('CLOSED_GARDNER_STATE12_','closed-gardner-state12-','closed_gardner_state')):files[path.name]=path
members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(files.items()):
        raw=p.read_bytes();z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(members) and set(z.namelist())==set(members)
    for n,item in members.items():
        raw=z.read(n);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and raw==files[n].read_bytes()
raw=archive.read_bytes();assert len(raw)<48*1024**2
common=dict(canonical_admission=True,actual_merge=M,qualified_candidate=C,source_anchor=A,whole_tree=TREE,coadmission=coadmission,new_scientific_contexts=68,actual_primary_portable_producer='e112e8f7f6f0bd00e4ae9035d00ef53860477448',actual_additional_local_producer='d143437f4d9d855f03c036a9db1b8a3f86ec63ef',additional_12_local_contexts_counted_again=False,whole_object_contexts=40,whole_objects=1046,two_deferred_Gardner_Snow9_numerical_cases_remain_functional_gaps=True,original_reference_causality='UNKNOWN_ORIGINAL_MAIN_ACCEPTED_MODEL3_CONTROL_ALSO_SIGSEGV',producer_roles_rebound=False,new_numerical_policy=False,physical_equations_changed=False,new_physical_state=False,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
manifest=dict(status='ACTUAL_CANONICAL948_SIGNED_SOURCE_PUBLIC_ORDINARY_PUBLICATION_14CI_FOUR_REAL_NEGATIVES_AND_ORIGINAL_LOGS_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,actual_public_observations=observations,successful_PR_workflows=14,successful_PR_checks=28,skipped_PR_checks=17,original_PR_successful_log_roles=logs,canonical_push_workflows_success=4,negative_controller_initial_harness_error_preserved_and_recovered=True,admission_controller=Path(__file__).name,admission_controller_sha256=SHA(Path(__file__).read_bytes()),**common)
receipt=dict(status='ACTUAL_CANONICAL948_CLOSED_GARDNER_STATE_ADMISSION_VERIFIED',PR=1811,previous_canonical=B,ordered_parents=[B,C],synthetic_merge=S,admission_archive_sha256=SHA(raw),**common)
for n,q in [(name+'.json',manifest),('CLOSED_GARDNER_STATE12_MERGE_RECEIPT_V1.json',receipt)]:
    assert not (E/n).exists();(E/n).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(manifest['status'],len(raw),manifest['sha256'],len(members),flush=True)
