"""Read the actual persisted finite batch using genuine immutable input donors."""
from contextlib import ExitStack
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
import closed_gardner_state_feedback as f
head=f.git('rev-parse','HEAD').decode().strip()
assert head=='015ed8c24db53414b219ef2c091adbae090547b7'
assert not f.git('status','--porcelain=v1','--untracked-files=all','--ignored')
plan=json.loads(f.git('show',head+':'+f.P+'CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V2.json'))
q=dict(status='RUNNING_ALL19_ACTUAL_PUBLIC_INPUT_PREFLIGHT',actual_source=head,compiler_executions=0,model_executions=0,model_days=0,cases=[],canonical_admission=False)
out=E/'CLOSED_GARDNER_STATE12_ALL_INPUT_PREFLIGHT_V1.json'
def save():out.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
with ExitStack() as stack:
    donors={}
    for spec in plan['cases']:
        folder=E.parent/'closure12-feedback-v1'/'all-input-preflight-v1'/spec['name'];folder.parent.mkdir(parents=True,exist_ok=True)
        key=spec['bottom']==9
        if key not in donors:donors[key]=f.input_donor(spec,stack)
        item=dict(case=spec['name'],inputs=str(folder))
        try:
            item['input_authority']=f.prepare(spec,folder,donors[key])
            policy='original-adaptive-event-closure-v1' if spec['frost'] else 'original-adaptive-day-seed-v1'
            project=f.m.e.load(folder,original_output=True,time_step_policy=policy)
            item.update(status='ACTUAL_PUBLIC_ACCEPTED',nodes=project.nodes,native_codec=f.m.e.auxiliary_magic(project).decode(),policy=policy,input_inventory=f.m.e.inventory(folder))
        except Exception as error:item.update(status='ACTUAL_PUBLIC_REFUSED',error=repr(error))
        q['cases'].append(item);save();print(item['case'],item['status'],item.get('error',''),flush=True)
q['status']='ALL19_ACTUAL_PUBLIC_INPUTS_ACCEPTED_ZERO_MODELS' if all(v['status']=='ACTUAL_PUBLIC_ACCEPTED' for v in q['cases']) else 'ACTUAL_PUBLIC_INPUT_GAPS_PRESERVED_NOT_QUALIFIED'
save();print(q['status'],flush=True)
