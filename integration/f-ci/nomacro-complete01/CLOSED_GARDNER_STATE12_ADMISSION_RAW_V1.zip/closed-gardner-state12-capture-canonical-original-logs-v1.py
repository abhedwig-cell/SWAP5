"""Capture complete official UTF8 PR job logs and original HTTP API bytes."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,urllib.request,urllib.error,urllib.parse
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';S='2e98506b4fb469bbf5995a8ab0b49c88ead0972c'
SHA=lambda b:hashlib.sha256(b).hexdigest();p=argparse.ArgumentParser();p.add_argument('--selection',required=True);p.add_argument('--label',required=True);a=p.parse_args()
jobs=json.loads((E/a.selection).read_text(encoding='utf8'));assert len(jobs)==len({v['job_id'] for v in jobs})
r=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);assert r.returncode==0
fields=dict(line.split('=',1) for line in r.stdout.decode().splitlines() if '=' in line);token=fields.get('password');assert token
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Accept-Encoding':'identity','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-evidence-custody'}
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,response_headers,newurl):return None
opener=urllib.request.build_opener(NoRedirect)
def fetch(path):
    try:
        with opener.open(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=60) as stream:return stream.read()
    except urllib.error.HTTPError as e:
        if e.code not in (301,302,303,307,308):raise
        loc=e.headers['Location'];parts=urllib.parse.urlsplit(loc);assert parts.scheme=='https' and (parts.hostname.endswith('.blob.core.windows.net') or parts.hostname.endswith('.actions.githubusercontent.com'))
        with urllib.request.urlopen(urllib.request.Request(loc,headers={'Accept-Encoding':'identity'}),timeout=60) as stream:return stream.read()
def once(path,raw):
    if path.exists():assert path.read_bytes()==raw
    else:path.write_bytes(raw)
observations=[]
for spec in jobs:
    job_id,run_id=spec['job_id'],spec['run_id'];jobraw=fetch('actions/jobs/'+str(job_id));runraw=fetch('actions/runs/'+str(run_id));job=json.loads(jobraw);run=json.loads(runraw)
    assert job['head_sha']==run['head_sha']==C and job['run_id']==run_id and run['event']=='push' and job['status']=='completed' and job['conclusion']=='success'
    stem='CLOSED_GARDNER_STATE12_ACTUAL_MERGE_JOB_'+str(job_id)
    path=E/(stem+'_ORIGINAL_CI_V1.log');raw=path.read_bytes() if path.exists() else fetch('actions/jobs/'+str(job_id)+'/logs');text=raw.decode('utf8',errors='strict');assert not raw.startswith(b'PK')
    once(path,raw);once(E/(stem+'_ORIGINAL_API_V1.json'),jobraw);once(E/(stem+'_RUN_ORIGINAL_API_V1.json'),runraw)
    observations.append(dict(role=spec['role'],run_id=run_id,job_id=job_id,actual_head=C,actual_signed_synthetic_checkout=S,actual_signed_checkout_printed_in_log=S in text,bytes=len(raw),sha256=SHA(raw),log=path.name,original_UTF8_bytes_normalized=False))
    print(job_id,len(raw),SHA(raw),flush=True)
record=dict(status='OFFICIAL_COMPLETE_SUCCESSFUL_PR_UTF8_JOB_LOGS_AND_API_BYTES_PRESERVED',observations=observations,compiler_executions=0,model_executions=0,actual_verified_merge=C,actual_signed_synthetic_checkout=S)
once(E/('CLOSED_GARDNER_STATE12_ACTUAL_MERGE_'+a.label+'_ORIGINAL_LOG_CUSTODY_V1.json'),(json.dumps(record,indent=2)+'\n').encode())
