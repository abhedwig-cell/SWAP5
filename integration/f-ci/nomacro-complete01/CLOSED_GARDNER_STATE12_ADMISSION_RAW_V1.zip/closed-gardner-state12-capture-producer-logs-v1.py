"""Retain original official producer logs and API bytes without text conversion."""
from pathlib import Path
import hashlib,json,os,subprocess,urllib.request,urllib.error,urllib.parse
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='e112e8f7f6f0bd00e4ae9035d00ef53860477448';SHA=lambda b:hashlib.sha256(b).hexdigest()
r=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30)
assert r.returncode==0
fields=dict(line.split('=',1) for line in r.stdout.decode().splitlines() if '=' in line);token=fields.get('password');assert token
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Accept-Encoding':'identity','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-evidence-custody'}
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,response_headers,newurl):return None
opener=urllib.request.build_opener(NoRedirect)
def fetch(path):
    try:
        with opener.open(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=60) as stream:return stream.read()
    except urllib.error.HTTPError as e:
        if e.code not in (301,302,303,307,308):raise
        loc=e.headers['Location'];parts=urllib.parse.urlsplit(loc)
        assert parts.scheme=='https' and (parts.hostname.endswith('.blob.core.windows.net') or parts.hostname.endswith('.actions.githubusercontent.com'))
        with urllib.request.urlopen(urllib.request.Request(loc,headers={'Accept-Encoding':'identity'}),timeout=60) as stream:return stream.read()
def once(name,raw):
    path=E/name
    if path.exists():assert path.read_bytes()==raw
    else:path.write_bytes(raw)
observed=[]
for run_id,job_id,platform,opt in [(45991118737,140478886593,'UBUNTU','O0'),(45991118737,140478886080,'UBUNTU','O2'),(45991118752,140478885940,'WINDOWS','O0'),(45991118752,140478886512,'WINDOWS','O2')]:
    runraw=fetch('actions/runs/'+str(run_id));jobraw=fetch('actions/jobs/'+str(job_id));run=json.loads(runraw);job=json.loads(jobraw)
    assert run['head_sha']==job['head_sha']==C and run['event']=='push' and run['conclusion']==job['conclusion']=='success' and job['run_id']==run_id
    raw=fetch('actions/jobs/'+str(job_id)+'/logs');text=raw.decode('utf8',errors='strict');assert C in text and not raw.startswith(b'PK')
    stem='CLOSED_GARDNER_STATE12_FIRST_'+platform+'_'+opt
    once(stem+'_JOB_ORIGINAL_API_V1.json',jobraw);once(stem+'_RUN_ORIGINAL_API_V1.json',runraw);once(stem+'_ORIGINAL_CI_V1.log',raw)
    observed.append(dict(platform=platform,optimization=opt,run_id=run_id,job_id=job_id,bytes=len(raw),sha256=SHA(raw),actual_source=C,conclusion=job['conclusion']))
    print(platform,opt,len(raw),SHA(raw),flush=True)
once('CLOSED_GARDNER_STATE12_FIRST_FOUR_ORIGINAL_JOB_LOGS_V1.json',(json.dumps(dict(status='FOUR_ORIGINAL_SUCCESSFUL_PRODUCER_LOGS_AND_API_BYTES_PRESERVED',observations=observed,original_bytes_normalized=False,model_executions=0),indent=2)+'\n').encode())
