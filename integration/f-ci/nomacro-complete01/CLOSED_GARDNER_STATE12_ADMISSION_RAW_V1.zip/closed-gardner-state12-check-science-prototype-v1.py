"""Execute the proposed read-only observer on four actual completed contexts."""
from pathlib import Path
import hashlib,json,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
import closed_gardner_state12_science_proposed as observer
q=dict(status='RUNNING_PROPOSED_INDEPENDENT_ARTIFACT_OBSERVER',actual_observer_source=observer.git('rev-parse','HEAD').decode().strip(),proposed_observer_sha256=hashlib.sha256((E/'closed_gardner_state12_science_proposed.py').read_bytes()).hexdigest(),contexts=[],compiler_executions=0,model_executions=0,canonical_admission=False)
out=E/'CLOSED_GARDNER_STATE12_PROPOSED_INDEPENDENT_FIRST4_V1.json'
def save():out.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
try:
    for opt in ['O0','O2']:
        root=E.parent/'closure12-feedback-v1'/('finite-'+opt+'-v1')
        for name in ['closed-frost-implicit-h0-water','closed-frost-implicit-h1-cde-profile-monthly']:
            q['contexts'].append(observer.observe(root/name,controls=root/(name+'-native-controls')));save();print(opt,name,'INDEPENDENT_PASS',flush=True)
    q['status']='PROPOSED_INDEPENDENT_ACTUAL_FIRST4_ARTIFACT_AUDITS_PASS_NOT_QUALIFIED'
except Exception as error:q.update(status='FAILED_PROPOSED_INDEPENDENT_ARTIFACT_OBSERVER',error=repr(error));raise
finally:save()
