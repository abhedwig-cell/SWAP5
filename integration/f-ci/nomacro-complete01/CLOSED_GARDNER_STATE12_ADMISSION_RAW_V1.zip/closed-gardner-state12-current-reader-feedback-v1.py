"""Actual committed public reader over preserved original-reader inputs; zero models."""
from pathlib import Path
import hashlib,json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='d7ffa497fea6326547a7e2c9ddf0e6c4d22db89f'
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all','--ignored'],cwd=R)
old=json.loads((E/'CLOSED_GARDNER_STATE12_ORIGINAL_INACTIVE_VAPOR_READER_V1.json').read_text(encoding='utf8'))
q=dict(status='RUNNING_ACTUAL_COMMITTED_PUBLIC_READER',actual_source=head,original_observation=old['actual_controller'],cases=[],compiler_executions=0,model_executions=0,model_days=0,canonical_admission=False)
code="import sys;sys.path.insert(0,str(__import__('pathlib').Path.cwd()/'app/hybrid_water'));import experimental_project as e;e.load(sys.argv[1],original_output=True,time_step_policy='original-adaptive-event-closure-v1');print('ACTUAL_PUBLIC_ACCEPTED')"
for item in old['cases']:
    source=Path(item['folder']);root=E.parent/'closure12-feedback-v1'/'reader-inputs-v3'/item['case'];root.mkdir(parents=True)
    for n,v in item['original_input_inventory'].items():
        raw=(source/n).read_bytes();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
        target=root/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    child=subprocess.run([sys.executable,'-B','-c',code,str(root)],cwd=R,capture_output=True)
    accepted=child.returncode==0
    q['cases'].append(dict(case=item['case'],original_reader_accepted=item['original_reader_accepted'],actual_public_accepted=accepted,returncode=child.returncode,stdout=child.stdout.decode('utf8'),stderr=child.stderr.decode('utf8')))
    print(item['case'],accepted,flush=True)
    (E/'CLOSED_GARDNER_STATE12_CURRENT_READER_FEEDBACK_V3.json').write_text(json.dumps(q,indent=2),encoding='utf8')
    assert accepted==item['original_reader_accepted'],q['cases'][-1]
q['status']='ACTUAL_COMMITTED_PUBLIC_READER_FOUR_ORIGINAL_ACCEPTANCES_AND_ORIGINAL_NON1_HYSTERESIS_REFUSAL_PASS_ZERO_MODELS'
with (E/'CLOSED_GARDNER_STATE12_CURRENT_READER_FEEDBACK_V3.json').open('w',encoding='utf8') as f:json.dump(q,f,indent=2)
print(q['status'],flush=True)
