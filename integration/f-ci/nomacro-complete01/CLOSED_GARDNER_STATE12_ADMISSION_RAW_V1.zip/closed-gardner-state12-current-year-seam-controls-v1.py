"""Add real cold year seams to completed current contexts, without warm replay."""
from datetime import date
from pathlib import Path
import json,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from closed_gardner_state_feedback import SHA,git,m,own
from frost_undrained_state_controls import active_frost_start
head=git('rev-parse','HEAD').decode().strip();assert head=='3be78ad24d2bce348f38a26e289af0f4846c5883'
base=E.parent/'closure12-feedback-v1';record=dict(status='CURRENT_ADDITIONAL_YEAR_SEAMS_FINISHED_AVAILABLE_CONTEXTS_ONLY',actual_observer=head,compiler_executions=0,original_warm_model_periods_replayed=0,contexts=[],canonical_admission=False)
for opt in ['O0','O2']:
    root=base/('finite-'+opt+'-v1');batch=json.loads((root/'RESULT.json').read_text())
    for case in batch['contexts']:
        if case['status']!='PASS_NOT_QUALIFIED':continue
        profile=root/case['case'];q=json.loads((profile/'RESULT.json').read_text());assert q['actual_source']==head
        build=Path(q['build_root']);meta=json.loads((build/'BUILD.json').read_text());start=date.fromisoformat(meta['project']['start_date']);offset=(date(start.year+1,1,1)-start).days
        if not 2<offset<35:continue
        cuts=[2,4,7,9,30,34,35];lo=max(v for v in cuts if v<offset);hi=min(v for v in cuts if v>offset)
        target=base/'additional-year-seams-v1'/opt/case['case'];target.parent.mkdir(parents=True,exist_ok=True)
        report=target/'RESULT.json'
        if report.is_file():
            item=json.loads(report.read_text());assert item['actual_source']==head and item['primary_RESULT_sha256']==SHA((profile/'RESULT.json').read_bytes())
            record['contexts'].append(item);continue
        assert not target.exists();project=m.e.load(q['input_root'],original_output=True,time_step_policy=q['time_step_policy'])
        item=dict(case=case['case'],optimization=opt,actual_source=head,primary_RESULT_sha256=SHA((profile/'RESULT.json').read_bytes()),actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()),start_date=str(start),new_year_offset=offset,window=[lo,hi],original_primary_model_days_replayed=0)
        item['cold']=own(build,Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'),project,profile/'trajectory',m.rows(profile/'trajectory'),lo,hi,target)
        if q['specification']['frost']:
            item['actual_Frost_active_day30']=active_frost_start(profile/'trajectory/accepted-column-1-day-30.zip',project)
        item['status']='ACTUAL_ORIGINAL_YEAR_SEAM_COMPLETE_NATIVE_COLD_AND_USER_OUTPUT_PASS'
        report.write_text(json.dumps(item,indent=2)+'\n',encoding='utf8');record['contexts'].append(item)
        print(opt,case['case'],lo,hi,'YEAR_SEAM_PASS',flush=True)
(E/'CLOSED_GARDNER_STATE12_CURRENT_ADDITIONAL_YEAR_SEAMS_V1.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print('COMPLETED_AVAILABLE_ADDITIONAL_YEAR_SEAMS',len(record['contexts']),flush=True)
