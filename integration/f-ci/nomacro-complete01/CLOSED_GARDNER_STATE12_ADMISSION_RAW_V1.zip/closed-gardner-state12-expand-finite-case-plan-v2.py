"""Include effective vapor slots and paired9 affected by the same native owner."""
from pathlib import Path
import json
E=Path(__file__).parent
q=json.loads((E/'CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V1.json').read_text(encoding='utf8'))
base=dict(days=35,kind='water',snow=1,frost=1,drainage=0,bottom=5,implicit=0,hysteresis=0,initial=2,models=[2],calendar='dense')
q['cases']+=[
    dict(base,**dict(name='gardner-mixed2-8-frost-explicit-inactive-vapor-slot',kind='cde',models=[2,8],effective_original_vapor_flags=[1,0])),
    dict(base,**dict(name='gardner-snow-paired9-explicit-water',frost=0,bottom=9)),
    dict(base,**dict(name='gardner-mixed2-1-snow-paired9-explicit-cde',frost=0,bottom=9,kind='cde',models=[2,1])),
]
assert len(q['cases'])==len({c['name'] for c in q['cases']})==19
q.update(status='FINITE19_AFFECTED_STATE_AND_EFFECTIVE_FLAG_COUPLINGS_PLANNED_NOT_EXECUTED_NOT_QUALIFIED',
    primary_days_if_all_executed=19*35*4,actual_model_and_compiler_executions=0,new_scientific_contexts_claimed=0,
    independent_original_reader_observation='CLOSED_GARDNER_STATE12_ORIGINAL_INACTIVE_VAPOR_READER_V1.json',
    original_zero_day_reader_accepts=4,original_non1_hysteresis_reader_refusals=1,
    selected_source_proposals=['CLOSED_GARDNER_STATE12_GARDNER_SOURCE_PROPOSAL_V2.json','CLOSED_GARDNER_STATE12_CLOSED_SOURCE_PROPOSAL_V1.json','CLOSED_GARDNER_STATE12_INITIAL_SOURCE_PROPOSAL_V1.json'])
with (E/'CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V2.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],len(q['cases']))
