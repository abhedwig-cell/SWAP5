"""Install actual batch12 code only after genuine complete canonical880 admission."""
from pathlib import Path
import argparse,ast,difflib,hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
M='105b9a8e6ca9e846f214d69a71afe73ed18be11d';C='e4d9a56143d85550ee272fbac55f1d4a08173195';BR='codex/nomacro-closed-gardner-state12'
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
read=lambda n:json.loads((E/n).read_text(encoding='utf8'))
def main():
    a=argparse.ArgumentParser();a.add_argument('--apply',action='store_true');args=a.parse_args()
    assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
    receipt=read('IMPLICIT_HYDRAULIC_STATE11_MERGE_RECEIPT_V1.json');admission=read('IMPLICIT_HYDRAULIC_STATE11_ADMISSION_RAW_V1.json')
    assert receipt['actual_merge']==M and receipt['qualified_candidate']==C and receipt['canonical_admission']
    assert receipt['coadmission']['contexts']==880 and receipt['admission_archive_sha256']==admission['sha256']
    assert git('rev-parse',M+'^{tree}').decode().strip()==receipt['whole_tree']=='a5e95a0420e7ae330926c41e256392fc8c52cadc'
    before={};after={};sources={};targets={}
    proposals=['CLOSED_GARDNER_STATE12_GARDNER_SOURCE_PROPOSAL_V3.json','CLOSED_GARDNER_STATE12_CLOSED_SOURCE_PROPOSAL_V1.json','CLOSED_GARDNER_STATE12_INITIAL_SOURCE_PROPOSAL_V1.json']
    for name in proposals:
        q=read(name)
        for path,item in q['files'].items():
            if item.get('new_file'):
                assert subprocess.run(['git','cat-file','-e',M+':'+path],cwd=R,capture_output=True).returncode!=0
                raw=(E/item['proposed_file']).read_bytes();assert SHA(raw)==item['proposed_lf_sha256'];ast.parse(raw)
                assert path not in after;before[path]=b'';after[path]=raw;sources[path]=[name];continue
            raw=git('show',M+':'+path);assert SHA(raw)==item['before_lf_sha256']
            independent=raw.decode()
            for edit in item['ordered_literal_replacements']:
                assert independent.count(edit['before'])==1
                independent=independent.replace(edit['before'],edit['after'],1)
            assert SHA(independent.encode())==item['proposed_lf_sha256']
            if path not in after:before[path]=raw;after[path]=raw;sources[path]=[]
            assert before[path]==raw;combined=after[path].decode()
            for edit in item['ordered_literal_replacements']:
                assert combined.count(edit['before'])==1,(path,name,edit['before'])
                combined=combined.replace(edit['before'],edit['after'],1)
            ast.parse(combined);after[path]=combined.encode();sources[path].append(name)
    literal={}
    for path,raw in after.items():
        left=before[path].decode();right=raw.decode()
        edits=[dict(base_start=i,base_end=j,before=left[i:j],after=right[k:l]) for tag,i,j,k,l in difflib.SequenceMatcher(None,left,right,autojunk=False).get_opcodes() if tag!='equal']
        literal[path]=dict(new_file=not bool(before[path]),before_lf_sha256=SHA(before[path]),proposed_lf_sha256=SHA(raw),ordered_literal_edits=edits,source_proposals=sources[path])
        targets[R/path]=raw
    review=read('CLOSED_GARDNER_STATE12_COMBINED_SOURCE_REVIEW_V1.json')
    assert review['actual_parent']==M and set(review['files'])==set(after)
    assert all(SHA(raw)==review['files'][path]['proposed_lf_sha256'] for path,raw in after.items())
    for prefix in ['IMPLICIT_HYDRAULIC_STATE11_ADMISSION_RAW_V1','CLOSED_GARDNER_STATE12_ORIGINAL_READER_RAW_V1']:
        q=read(prefix+'.json');pieces=[]
        for part in q['parts']:
            raw=(E/part['file']).read_bytes();assert len(raw)==part['bytes'] and SHA(raw)==part['sha256'];pieces.append(raw);targets[P/part['file']]=raw
        raw=b''.join(pieces);assert len(raw)==q['bytes'] and SHA(raw)==q['sha256']
        import io
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(q['members']) and set(z.namelist())==set(q['members'])
            for member,item in q['members'].items():
                body=z.read(member);assert len(body)==item['bytes'] and SHA(body)==item['sha256']
        targets[P/(prefix+'.json')]=(E/(prefix+'.json')).read_bytes()
    targets[P/'IMPLICIT_HYDRAULIC_STATE11_MERGE_RECEIPT_V1.json']=(E/'IMPLICIT_HYDRAULIC_STATE11_MERGE_RECEIPT_V1.json').read_bytes()
    keep=[*proposals,'CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V2.json','CLOSED_GARDNER_STATE12_ORIGINAL_SOURCE_DEPENDENCY_AUDIT_V1.json','CLOSED_GARDNER_STATE12_ORIGINAL_INACTIVE_VAPOR_READER_V1.json']
    for name in keep:targets[P/name]=(E/name).read_bytes()
    contract=dict(status='ACTUAL_CLOSED_ZERO_BOUNDARY_GARDNER_SOURCE_INSTALLED_PENDING_SCIENTIFIC_QUALIFICATION',actual_canonical_parent=M,
        files=literal,scientific_change_class='B_COMPOSITION_OF_EXISTING_PHYSICAL_PROCESSES_AND_NATIVE_STATE_OWNERS',
        physical_equations_changed=False,new_physical_state=False,new_numerical_policy=False,new_scientific_contexts=0,
        canonical_admission=False,actual_original_reader_accepts=4,actual_original_non1_hysteresis_refusals=1,
        raw_reader_archive_sha256=read('CLOSED_GARDNER_STATE12_ORIGINAL_READER_RAW_V1.json')['sha256'])
    targets[P/'CLOSED_GARDNER_STATE12_SOURCE_PROPOSAL_V1.json']=(json.dumps(contract,indent=2)+'\n').encode()
    next_action='Qualify the installed19-case closed-boundary default-Mualem/explicit Gardner coupling cohort on actual committed source. First public reader and directed original-budget/native/cold controls; then coherent portable acceptance. Reuse immutable original sources and old whole-object baselines without old long-period replay.'
    status=json.loads(git('show',M+':integration/f-ci/nomacro-complete01/STATUS.json'))
    status.update(canonical=M,branch=BR,last_commit=M,active_functional_batch='closed_gardner_state12',next_action=next_action,functional_completeness='PARTIAL',scientific_equivalence='NOT_QUALIFIED')
    status['canonical880_actual_admission']=receipt
    status['implicit_hydraulic_state11']=dict(status='ACTUAL_CANONICAL880_IMPLICIT_ANALYTICAL_STATE_ADMITTED',actual_canonical=M,
        canonical_admission=True,new_admitted_contexts=56,merge_receipt='IMPLICIT_HYDRAULIC_STATE11_MERGE_RECEIPT_V1.json',admission_raw_sha256=admission['sha256'],whole_family_closed=False)
    status['closed_gardner_state12']=dict(status='FUNCTIONAL_SOURCE_CHECKPOINT_NOT_SCIENTIFICALLY_QUALIFIED',actual_parent=M,branch=BR,
        source_proposal='CLOSED_GARDNER_STATE12_SOURCE_PROPOSAL_V1.json',finite_case_plan='CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V2.json',
        planned_cases=19,new_qualified_contexts=0,new_admitted_contexts=0,canonical_admission=False,next_action=next_action)
    status.setdefault('completed',[]).append('PR1810 genuine signed canonical105b9a8e6ca9 admits bounded880 with56 new portable contexts, current clean PUBLIC/ordinary publication,15PR47checks, four real committed negatives, eighteen original logs and original failures retained; closed/Gardner batch12 implementation follows in the same checkpoint.')
    targets[P/'STATUS.json']=(json.dumps(status,indent=2)+'\n').encode()
    gap=json.loads(git('show',M+':integration/f-ci/nomacro-complete01/GAP_MATRIX.json'))
    gap['implicit_hydraulic_state11']=dict(status='BOUNDED_IMPLICIT_ANALYTICAL_STATE_ACTUALLY_ADMITTED_CANONICAL880',classification='ADMITTED_BOUNDED_COMPOSITION_NOT_WHOLE_FAMILY',actual_canonical=M,new_admitted_contexts=56,whole_family_closed=False)
    gap['closed_gardner_state12']=dict(classification='COMPOSITION_MISSING',status='IMPLEMENTED_SOURCE_PENDING_QUALIFICATION',
        historical_support='Actual original zero-day reader accepts four explicit Gardner configurations; original non1+hysteresis remains refused. Original Boundbottom sets qbot=0 for bottom6.',
        scope='Drainage-off Mualem implicit/hysteresis existing state owners and explicit Gardner Snow/Frost/paired9 with effective NoVap semantics',planned_cases=19,new_admitted_contexts=0,whole_family_closed=False)
    gap.setdefault('migration_progress',{}).update(current_canonical=M,next_dependency_ordered_blocks=[
        'Installed coherent closed-boundary/Gardner19 coupling batch12',
        'Remaining original RIA12 and valid tabulated hydraulic/thermal state compositions, including original table constraints',
        'Independent remaining boundary/drainage/vapor families and source-valid crop/weather/chemical/tillage owners',
        'Independent integral functional release review; no global completeness claim from bounded cohorts'])
    targets[P/'GAP_MATRIX.json']=(json.dumps(gap,indent=2)+'\n').encode()
    doc=(f'# Canonical implicit analytical hydraulic state11\n\nActual signed canonical `{M}` (PR1810) has ordered parents `22520105f5a3ccac2bd2ae1b726f27b7b0d67b1e` and `{C}`, and tree `a5e95a0420e7ae330926c41e256392fc8c52cadc`. The exact source anchor, current positive/negative observations, complete original CI and retained original failures are in `IMPLICIT_HYDRAULIC_STATE11_MERGE_RECEIPT_V1.json` and its admission RAW descriptor.\n\nThe bounded cohort adds56 portable Windows/Ubuntu O0/O2 contexts to880. Its1960 primary days,392 native samples,176 exact cold/output windows,320 compiled refusals and56 transactions retain producer `c40ca084d8e5eb638e0b4ac5c471463d9aad01c3`. The28 additional local contexts are not counted again. The model-specific nonconstant derivative and exact selected model5 chain rule are explicit numerical policies; physical equations, parameters and1e-10 limits are unchanged. The original Ubuntu producer observer failure and corrected observer-only outcomes retain their original roles.\n\nFunctional migration remains PARTIAL and whole scientific equivalence NOT_QUALIFIED. Closed zero-flux Mualem state couplings and explicit Gardner native domains proceed in coherent batch12. RIA12/tabulated compositions, other source-valid families and the separate AGE dryout/head-flux scientific decisions remain open. RC3 is unchanged.\n').encode()
    targets[R/'docs/science/NOMACRO_IMPLICIT_HYDRAULIC_STATE11.md']=doc
    targets[R/'docs/science/NOMACRO_CLOSED_GARDNER_STATE12.md']=(f'# Closed-boundary and explicit Gardner state12\n\nParent canonical: `{M}`. This checkpoint installs existing state-owner and input/native guard composition, with no new physical equation, state or numerical policy. Scientific qualification is pending.\n\nThe finite19-case plan covers closed drainage-off default-Mualem implicit/hysteresis state and original explicit Gardner Snow/Frost/paired9. Effective vapor slots are checked only for models8..11; original non1+hysteresis stays excluded. Four original zero-day initializations and one original refusal are preserved with exact accepted original reader/SDK identities. No model period is claimed from those observations.\n\nNext: actual committed public input checks, O0/O2 independent budgets, full native/refusal/cold/transaction controls and portable acceptance. Preserve prior immutable scientific results and compare unchanged whole compiler objects. Whole historical functionality remains PARTIAL.\n').encode()
    print('REVIEWABLE_BATCH12_INSTALLATION',len(targets),'files',len(after),'physical-composition APP files',flush=True)
    if not args.apply:return
    assert git('ls-remote','--heads','origin','refs/heads/integration/f-ci-canonical').decode().split()[0]==M,'Canonical advanced; reconcile before installation'
    assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+BR],cwd=R).returncode==1
    subprocess.run(['git','switch','-c',BR],cwd=R,check=True)
    for path,raw in targets.items():path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    relative=sorted(path.relative_to(R).as_posix() for path in targets)
    git('add','--sparse','--',*relative)
    subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Compose original closed Mualem and explicit Gardner state owners after canonical880 admission'],cwd=R,check=True)
    head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
    output=dict(status='ACTUAL_BATCH12_FUNCTIONAL_SOURCE_AND_PARENT880_ADMISSION_CHECKPOINT_NOT_QUALIFIED',actual_parent=M,branch=BR,
        actual_source=head,whole_tree=git('rev-parse','HEAD^{tree}').decode().strip(),APP_files=list(after),planned_cases=19,
        new_qualified_contexts=0,new_admitted_contexts=0,canonical_admission=False,compiler_executions=0,model_executions=0)
    with (E/'CLOSED_GARDNER_STATE12_ACTUAL_SOURCE_CHECKPOINT_V1.json').open('x',encoding='utf8') as out:json.dump(output,out,indent=2);out.write('\n')
    for prefix in ['IMPLICIT_HYDRAULIC_STATE11_ADMISSION_RAW_V1','CLOSED_GARDNER_STATE12_ORIGINAL_READER_RAW_V1']:
        q=read(prefix+'.json')
        for part in q['parts']:assert git('show',head+':integration/f-ci/nomacro-complete01/'+part['file'])==(E/part['file']).read_bytes()
    print(json.dumps(output,indent=2))

if __name__=='__main__':main()
