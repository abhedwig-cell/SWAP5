"""Install reviewed exact repairs after all actual first-cohort model jobs ended."""
from pathlib import Path
import ast,hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='3be78ad24d2bce348f38a26e289af0f4846c5883'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
for opt in ['O0','O2']:
    q=json.loads((E.parent/'closure12-feedback-v1'/('finite-'+opt+'-v1')/'RESULT.json').read_text())
    assert q['actual_source']==head and q['status']=='CLOSED_GARDNER_BATCH_FAILURES_RETAINED_NOT_QUALIFIED' and len(q['contexts'])==19
proposal=json.loads((E/'CLOSED_GARDNER_STATE12_DIRECTED_REPAIRS_PROPOSED_V1.json').read_text());files=proposal['files']
controller=json.loads((E/'CLOSED_GARDNER_STATE12_INPUT_CONTROLLER_REPAIR_PROPOSED_V1.json').read_text());files[controller['source_path']]=controller
for path,item in files.items():
    assert SHA(git('show',head+':'+path))==item['before_lf_sha256']
    assert (R/path).read_bytes().replace(b'\r\n',b'\n')==git('show',head+':'+path)
    raw=(E/item['proposed_file']).read_bytes();assert SHA(raw)==item['after_lf_sha256'];ast.parse(raw)
for path,item in files.items():(R/path).write_bytes((E/item['proposed_file']).read_bytes())
q=dict(status='DIRECTED_REPAIRS_INSTALLED_UNCOMMITTED_PENDING_FIRST_RAW_ARCHIVE_COMPLETION_AND_FUNCTIONAL_CHECKPOINT',actual_parent=head,files=files,
    first_cohort_original_model_source=head,first_cohort_all_jobs_terminal=True,compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'CLOSED_GARDNER_STATE12_DIRECTED_REPAIRS_INSTALLATION_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(q['status'],len(files),flush=True)
