"""Persist coherent portable qualification after completed actual local feedback."""
from pathlib import Path
import ast,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);head=git('rev-parse','HEAD').decode().strip()
assert head=='d143437f4d9d855f03c036a9db1b8a3f86ec63ef' and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
summary=json.loads((E/'CLOSED_GARDNER_STATE12_REPAIRED_LOCAL_SUMMARY_V1.json').read_text())
assert (summary['local_contexts'],summary['primary_model_days'],summary['native_samples'],summary['exact_cold_windows'],summary['compiled_native_refusals'],summary['current_public_preservation_build_contexts'],summary['current_preserved_whole_objects'])==(12,420,84,44,172,40,1046)
paths=[]
for platform in ['ubuntu','windows']:
    source=E/('CLOSED_GARDNER_STATE12_PROPOSED_WORKFLOW_'+platform+'.yml');target=R/'.github/workflows'/('nomacro-closed-gardner-state12-'+platform+'.yml')
    assert not target.exists();text=source.read_text()
    assert 'closed_gardner_state_batch.py --scope independent' in text and '--check-selection closed_gardner_portable' in text
    assert 'codex/nomacro-closed-gardner-state12' in text and 'closed_gardner_state_science.py' in text
    target.write_bytes(source.read_bytes());paths.append(target.relative_to(R).as_posix())
names=['CLOSED_GARDNER_STATE12_REPAIRED_LOCAL_SUMMARY_V1.json','CLOSED_GARDNER_STATE12_REPAIRED_O0_INDEPENDENT_V1.json','CLOSED_GARDNER_STATE12_REPAIRED_O2_INDEPENDENT_V1.json',
       'CLOSED_GARDNER_STATE12_ACTUAL_REPAIRED_SOURCE_CONTRACT_V1.json','CLOSED_GARDNER_STATE12_ACTUAL_REPAIRED_PARENT_ADMISSION_V1.json','CLOSED_GARDNER_STATE12_ACTUAL_REPAIRED_CUSTODY_AND_SOURCE_ATTACKS_V2.json']
for name in names:(P/name).write_bytes((E/name).read_bytes());paths.append('integration/f-ci/nomacro-complete01/'+name)
q=json.loads((P/'STATUS.json').read_text());q['closed_gardner_state12'].update(status='ACTUAL12_REPAIRED_LOCAL_CONTEXTS_40_PRIOR_COMPILED_CONTEXTS_PASS_PORTABLE17_PENDING',
    actual_repaired_local_source=head,actual_local_independent_summary=summary,actual_prior_canonical_whole_object_contexts=40,actual_prior_canonical_identical_whole_objects=1046,
    original_first22_passes_role='Original preliminary observations remain retained under3be78, not rebound or counted as new portable/current admission',
    next_action='Execute17 independent closed/Gardner coupling contexts on real Windows/Ubuntu O0/O2 through the new explicit portable workflows; preserve every original source, input, provider, compiled byte and failure. Independently audit portable artifacts, freeze current public owner and integrate only after required acceptance. Two numerical Snow9 gaps remain open.',new_qualified_contexts=0,new_admitted_contexts=0,canonical_admission=False)
q['next_action']=q['closed_gardner_state12']['next_action'];q['test_selection']['portable_selection_pending_new_persisted_workflow_candidate']=True
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');paths.append('integration/f-ci/nomacro-complete01/STATUS.json')
gap=json.loads((P/'GAP_MATRIX.json').read_text());gap['closed_gardner_state12'].update(status='REPAIRED_SAFE_COUPLINGS_LOCALLY_TESTED_PORTABLE_INDEPENDENT17_PENDING',
    actual_repaired_source=head,actual_repaired_local_contexts=12,actual_prior_canonical_preservation_contexts=40,actual_identical_whole_objects=1046,old_warm_periods_replayed=0,new_admitted_contexts=0)
(P/'GAP_MATRIX.json').write_text(json.dumps(gap,indent=2)+'\n',encoding='utf8');paths.append('integration/f-ci/nomacro-complete01/GAP_MATRIX.json')
git('add','--',*paths)
print('STAGED_ACTUAL_LOCAL_CLOSEOUT_AND_PORTABLE_QUALIFICATION_WORKFLOWS',len(paths),flush=True)
