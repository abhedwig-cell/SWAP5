"""Select no fresh MCSOL replay only after reading actual accepted authority and Git bytes."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from analytical_hydraulic_archives import Archive
from frost_boundary_git_archive import GitArchiveSource
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest();C='07cb2850e2cd45deb1e197161409a3784a8975e7';B='105b9a8e6ca9e846f214d69a71afe73ed18be11d'
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
name='IMPLICIT_HYDRAULIC_STATE11_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V3.json'
with ExitStack() as stack:
    old=Archive(GitArchiveSource(R,C),'IMPLICIT_HYDRAULIC_STATE11_ADMISSION_RAW_V1',stack);assert old.record['sha256']=='4517de7ded03c9a6b1433a03d8656b7a61f97a6bbc2b627016ce7314d3ca6077'
    raw=old.get(name);assert raw==(E/name).read_bytes();q=json.loads(raw)
paths=q['unchanged_dependency_paths'];assert not git('diff',B,C,'--',*paths)
before=git('ls-tree','-r','-l',B,'--',*paths);current=git('ls-tree','-r','-l',C,'--',*paths);assert before==current and len(current.splitlines())==1063 and SHA(current)==q['actual_ls_tree_rl_sha256']=='b4aff8d1a27934512a1a311bbcf3f067f1e050fdde5a2cac0a78bdeef7348461'
record=dict(status='MCSOL_NOT_SELECTED_IMPACT_FRESH_CURRENT1063_LITERAL_DEPENDENCY_FILES_AND_ACCEPTED_PRIOR_SELECTION_VERIFIED',actual_parent=B,actual_candidate=C,unchanged_dependency_paths=paths,unchanged_tracked_files=1063,actual_ls_tree_rl_sha256=SHA(current),actual_accepted_prior_selection_archive_sha256=old.record['sha256'],actual_prior_selection_member=name,actual_prior_selection_sha256=SHA(raw),current_model_replay='NOT_SELECTED_IMPACT',fresh_current_MCSOL_scientific_PASS_claimed=False,original_scientific_sources_rebound=False,compiler_executions=0,model_executions=0)
(E/'CLOSED_GARDNER_STATE12_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(record['status'])
