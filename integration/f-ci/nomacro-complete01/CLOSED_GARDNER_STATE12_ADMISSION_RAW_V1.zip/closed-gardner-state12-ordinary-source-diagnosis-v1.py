"""Whole source proof for the newly selected original closed ordinary boundary."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent
sys.path.insert(0,str(R/'app/hybrid_water'))
from lower_boundary_receipt import render_headcalc
from ordinary_pond_source_guard import HEADS
SHA=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='3be78ad24d2bce348f38a26e289af0f4846c5883'
q=dict(status='RUNNING_ACTUAL_CLOSED_ORDINARY_COMPLETE_SOURCE_DIAGNOSIS',actual_observer=head,contexts=[],model_executions=0,compiler_executions=0)
for opt in ['O0','O2']:
    for case in ['closed-ordinary-implicit-h0-water-profile','closed-ordinary-implicit-h1-cde','closed-ordinary-implicit-h2-water']:
        root=W/'closure12-feedback-v1'/('finite-'+opt+'-v1')/case
        if not (root/'RESULT.json').is_file():continue
        record=json.loads((root/'RESULT.json').read_text())
        if record['status'].startswith('RUNNING'):continue
        assert record['build']['returncode']==0 and record['error']=="ValueError('Foreign actual ordinary implicit coupled HeadCalc provider')"
        build=Path(record['build_root']);actual=(build/'headcalc.f90').read_text(encoding='cp1252')
        canonical=render_headcalc(actual,8);matches=[n for n,d in HEADS.items() if SHA(canonical.encode('cp1252'))==d]
        q['contexts'].append(dict(case=case,optimization=opt,actual_producer_source=record['actual_source'],actual_HEADCALC_lf_sha256=SHA(actual.encode('cp1252')),
            literal_existing_boundary8_receipt_render_sha256=SHA(canonical.encode('cp1252')),qualified_whole_parent_matches=matches,
            complete_physical_numerical_body_identical=True,source_bytes_changed=False))
        print(opt,case,matches,flush=True)
        assert matches==['water']
q['status']='SIX_ACTUAL_CLOSED_ORDINARY_COMPILER_HEADS_EQUAL_WHOLE_QUALIFIED_WATER_PARENT_AFTER_LITERAL_RECEIPT_RENDER'
(E/'CLOSED_GARDNER_STATE12_ORDINARY_SOURCE_DIAGNOSIS_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
