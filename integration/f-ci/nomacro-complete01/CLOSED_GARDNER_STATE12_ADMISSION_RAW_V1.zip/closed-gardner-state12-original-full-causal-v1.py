"""Original35day causal observation on identical failed Gardner/Snow9 inputs."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');D=W/'closure12-original-causal-v1';B=W/'closure12-original-causal-O0-v1'
SHA=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='3be78ad24d2bce348f38a26e289af0f4846c5883'
q=dict(status='RUNNING_ORIGINAL_MIXED_SDK_FULL_MODEL_CAUSAL_NOT_QUALIFICATION',actual_controller_source=head,
    original_provider=str(J),compiler_executions=0,link_executions=0,physical_parameter_or_date_edits=False,
    scientific_question='Does the original full SWAP model on identical dry Gardner/Snow9 inputs also develop the observed nonfinite value during original snowmelt?',
    expected_seconds=65,original_SDK_mixed_compiler_profiles=True,all_O0_original_SDK_claimed=False,cases=[],canonical_admission=False)
report=D/'RESULT.json'
def save():report.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
try:
    prepared=json.loads((J/'PREPARED.json').read_text());checked={}
    for name,digest in prepared['provider_files'].items():
        raw=(J/name).read_bytes();assert SHA(raw)==digest,name;checked[name]=digest
    q['exact_original_provider_files']=checked;q['original_PREPARED_sha256']=SHA((J/'PREPARED.json').read_bytes())
    exe=B/'original_mixed_SDK_full_swap.exe';objects=sorted((J/'build/swap-obj').glob('*.o'))
    assert objects and any(p.name.lower()=='swap_main.o' for p in objects)
    assert SHA(Path('C:/msys64/ucrt64/bin/gfortran.exe').read_bytes())==prepared['toolchain']['gfortran']['sha256']
    cmd=['C:/msys64/ucrt64/bin/gfortran.exe','-o',str(exe),*map(str,objects),str(J/'build/ttutil-obj/libttutil.a')]
    started=time.perf_counter();child=subprocess.run(cmd,cwd=B,capture_output=True,timeout=30)
    (B/'link.stdout').write_bytes(child.stdout);(B/'link.stderr').write_bytes(child.stderr)
    q['link']=dict(command=cmd,returncode=child.returncode,seconds=time.perf_counter()-started);q['link_executions']=1;save();child.check_returncode()
    q['actual_original_link_executable_sha256']=SHA(exe.read_bytes());save()
    for name in ['gardner-snow-paired9-explicit-water','gardner-mixed2-1-snow-paired9-explicit-cde']:
        original=W/'closure12-feedback-v1/finite-O0-v1'/name;prior=json.loads((original/'RESULT.json').read_text())
        root=D/name;root.mkdir();inventory={}
        for filename,digest in prior['input_inventory']:
            raw=(Path(prior['input_root'])/filename).read_bytes();assert SHA(raw)==digest
            target=root/filename;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);inventory[filename]=digest
        text=(root/'swap.swp').read_text(encoding='cp1252');assert re.search(r'(?mi)^\s*SWMACRO\s*=\s*0\b',text)
        item=dict(case=name,original_failed_current_source=prior['actual_source'],identical_input_inventory=inventory,
            original_executable_sha256=q['actual_original_link_executable_sha256'],command=[str(exe),'./swap.swp'],all_input_bytes_and_dates_identical=True)
        started=time.perf_counter()
        with (root/'full-original.stdout').open('xb') as out,(root/'full-original.stderr').open('xb') as err:
            try:
                child=subprocess.run(item['command'],cwd=root,stdout=out,stderr=err,timeout=30);item.update(status='ORIGINAL_PROCESS_TERMINAL_OBSERVED_NOT_QUALIFIED',returncode=child.returncode)
            except subprocess.TimeoutExpired:item.update(status='CENSORED_ORIGINAL_PROCESS_AT30_SECONDS',returncode=None)
        item['seconds']=time.perf_counter()-started
        item['actual_text_nonfinite_or_convergence_diagnostics']=[]
        for path in root.rglob('*'):
            if not path.is_file() or path.name in inventory:continue
            if path.suffix.lower() not in ('.stdout','.stderr','.err','.log','.bal','.blc','.csv','.wrn','.war'):continue
            raw=path.read_bytes();matches=[line.decode('cp1252',errors='replace') for line in raw.splitlines() if re.search(rb'(?i)(?:\bnan\b|\binfinity\b|no convergence|INPUT ERROR)',line)]
            if matches:item['actual_text_nonfinite_or_convergence_diagnostics'].append(dict(path=path.relative_to(root).as_posix(),sha256=SHA(raw),matching_lines=matches[:30],total_matching_lines=len(matches)))
        q['cases'].append(item);save();print(name,item['status'],item.get('returncode'),len(item['actual_text_nonfinite_or_convergence_diagnostics']),flush=True)
    q['status']='ORIGINAL_FULL_MODEL_CAUSAL_OBSERVATIONS_RETAINED_NO_QUALIFICATION_OR_LEGACY_DEFECT_ASSUMPTION'
except Exception as error:q.update(status='FAILED_ORIGINAL_FULL_MODEL_CAUSAL_PREFLIGHT',error=repr(error));raise
finally:save()
