"""Observe genuine original zero-day reader against current explicit Gardner guard."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,io,json,os,re,subprocess,sys,zipfile
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent
D=W/'closure12-original-reader-v1';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
B=W/'frost-undrained-state08-initialization-probe-O0-v1/corrected-module-import-v2'
CURRENT='e4d9a56143d85550ee272fbac55f1d4a08173195';SEED='e28233d32c404c86fa58d7cbd71f7632dde1654c';PRODUCER='c40ca084d8e5eb638e0b4ac5c471463d9aad01c3'
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==CURRENT and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from analytical_hydraulic_archives import Archive
from frost_boundary_git_archive import GitArchiveSource
from original_output_baseline import assignment
original_source=(R/'reference/swap-4.3.1/source-archives/SWAP.ZIP').read_bytes()
assert SHA(original_source)=='1a2d798994c2990b397f9349317e3a26f40662fbcff55c9ea484dd638af45151'
with zipfile.ZipFile(R/'reference/swap-4.3.1/source-archives/SWAP.ZIP') as z:reader=z.read('SWAP/readswap.f90')
assert reader==(J/'build/swap-selected/readswap.f90').read_bytes() and SHA(reader)=='3ab42ae4ad9a76d96b01d90b173cf821a9add8514620a965bf31eaf874405cf2'
driver=(B/'probe.f90').read_bytes();assert SHA(driver.replace(b'\r\n',b'\n'))=='4ab1a6bb4143c6bf04fb09354c56552fdc79a828703d797274b08f3688084a52'
metadata=json.loads((B/'BUILD_DIAGNOSTIC.json').read_text(encoding='utf8'))
assert metadata['actual_controller_source']=='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d'
for name,digest in metadata['original_objects'].items():assert SHA((J/'build/swap-obj'/name).read_bytes())==digest
assert SHA((J/'build/ttutil-obj/libttutil.a').read_bytes())==metadata['original_library_sha256']
original_data=GitArchiveSource(R,SEED)
original_descriptor=json.loads((original_data/'FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.json').read_bytes())
original_raw=(original_data/original_descriptor['archive']).read_bytes()
assert len(original_raw)==original_descriptor['bytes'] and SHA(original_raw)==original_descriptor['sha256']
with zipfile.ZipFile(io.BytesIO(original_raw)) as original_store:
    assert original_store.testzip() is None and set(original_store.namelist())==set(original_descriptor['members'])
    assert len(original_store.namelist())==len(set(original_store.namelist()))
    def original_get(member):
        raw=original_store.read(member);item=original_descriptor['members'][member]
        assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'];return raw
    original_prefix='phase-driver/corrected-module-import-v2/'
    original_probe=json.loads(original_get(original_prefix+'RESULT.json'))
    exe=B/'original_initialization_probe.exe'
    assert exe.read_bytes()==original_get(original_prefix+exe.name)
    assert (B/'RESULT.json').read_bytes()==original_get(original_prefix+'RESULT.json')
    assert SHA(exe.read_bytes())==original_probe['executable_sha256']=='dee4a94a5e0e92d07c9aee2a4790fc5178f159f7e81ad316fcaa58b6a6f28b5e'
    original_probe_archive_sha256=original_descriptor['sha256']
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
q=dict(status='RUNNING_GENUINE_ORIGINAL_READER_ZERO_DAY_ONLY_NOT_QUALIFIED',actual_controller=CURRENT,
    actual_input_archive_git_source=SEED,actual_input_producer=PRODUCER,original_reader_sha256=SHA(reader),original_driver_raw_sha256=SHA(driver),original_driver_lf_text_sha256=SHA(driver.replace(b'\r\n',b'\n')),
    original_driver_source=metadata['actual_controller_source'],original_probe_exe_sha256=SHA(exe.read_bytes()),
    original_probe_accepted_archive_sha256=original_probe_archive_sha256,original_probe_exact_Git_member_verified=True,
    original_driver_O0=True,original_SDK_mixed_compiler_profiles=True,all_O0_SDK_claimed=False,
    original_SDK_object_hashes=metadata['original_objects'],original_SDK_library_sha256=metadata['original_library_sha256'],
    cases=[],compiler_executions=0,model_days=0,scientific_qualification=False,canonical_admission=False)
def save():(E/'CLOSED_GARDNER_STATE12_ORIGINAL_INACTIVE_VAPOR_READER_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
with ExitStack() as stack:
    archive=Archive(GitArchiveSource(R,SEED),'IMPLICIT_HYDRAULIC_STATE11_FIRST_WINDOWS_O0_ORIGINAL_V1',stack)
    prefix='current/frost-mixed2-3-water-d0-b5/inputs/'
    report=json.loads(archive.get('current/frost-mixed2-3-water-d0-b5/RESULT.json'))
    assert report['actual_source']==PRODUCER
    originals={n[len(prefix):]:archive.get(n) for n in archive.names if n.startswith(prefix)}
    assert originals and 'swap.swp' in originals;q['original_archive_sha256']=archive.record['sha256']
    q['original_input_member_inventory']={n:dict(bytes=len(raw),sha256=SHA(raw)) for n,raw in originals.items()};save()
for name,models,flags,hys in [('gardner-absent','2',None,0),('gardner-zero','2','0 0',0),('gardner-one','2','1 1',0),('mixed2-3-one','2 3','1 1',0),('gardner-hys1-original-refusal','2','1 1',1)]:
    folder=D/name;folder.mkdir()
    for n,raw in originals.items():
        path=folder/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    path=folder/'swap.swp';text=originals['swap.swp'].decode('cp1252')
    for key,value in [('SWKIMPL',0),('IHWCKMODEL',models),('SWHYST',hys)]:text=assignment(text,key,value)
    text=re.sub(r'(?mi)^[ \t]*SWVAPOR[ \t]*=[^\r\n]*(?:\r?\n|$)','',text)
    if flags is not None:text+='\nSWVAPOR = '+flags+'\n'
    path.write_bytes(text.encode('cp1252'))
    inputs={p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=SHA(p.read_bytes())) for p in folder.rglob('*') if p.is_file()}
    public_command=[sys.executable,'-B','-c',"import sys;sys.path.insert(0,"+repr(str(R/'app/hybrid_water'))+");import experimental_project as e;e.load("+repr(str(folder))+",original_output=True);print('CURRENT_PUBLIC_ACCEPTED')"]
    public=subprocess.run(public_command,cwd=R,env=env,capture_output=True,timeout=30)
    (folder/'current-public.stdout').write_bytes(public.stdout);(folder/'current-public.stderr').write_bytes(public.stderr)
    observed=subprocess.run([str(exe),'./swap.swp'],cwd=folder,env=env,capture_output=True,timeout=30)
    (folder/'original-probe.stdout').write_bytes(observed.stdout);(folder/'original-probe.stderr').write_bytes(observed.stderr)
    phases=[line.decode() for line in observed.stdout.splitlines() if line.startswith(b'ORIGINAL_INIT_PHASE ')]
    accepted=b'ORIGINAL_INIT_PHASE AFTER_READSWAP' in observed.stdout
    initialized=b'ORIGINAL_INIT_PHASE AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS' in observed.stdout
    q['cases'].append(dict(case=name,folder=str(folder),declared_edits=dict(SWKIMPL=0,IHWCKMODEL=models,SWHYST=hys,SWVAPOR=flags),
        original_input_inventory=inputs,current_public_returncode=public.returncode,current_public_stdout_sha256=SHA(public.stdout),current_public_stderr_sha256=SHA(public.stderr),
        original_probe_returncode=observed.returncode,original_reader_accepted=accepted,original_zero_day_initialization_reached=initialized,original_phases=phases,
        original_stdout_sha256=SHA(observed.stdout),original_stderr_sha256=SHA(observed.stderr),model_days=0,physical_parameter_tables_edited=False));save()
    print(name,public.returncode,observed.returncode,accepted,initialized,flush=True)
assert git('rev-parse','HEAD').decode().strip()==CURRENT and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q['status']='GENUINE_ORIGINAL_ZERO_DAY_READER_AND_CURRENT_PUBLIC_GUARD_OBSERVED_NOT_QUALIFIED';save()
