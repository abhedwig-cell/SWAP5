"""Actual original zero-day initialization of the repaired mixed2/8 input deck."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
import closed_gardner_state_feedback as f
head=f.git('rev-parse','HEAD').decode().strip();dirty=f.git('status','--porcelain=v1','--untracked-files=all').decode();assert dirty
plan=json.loads(f.git('show',head+':'+f.P+'CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V2.json'))
spec=next(v for v in plan['cases'] if v['name']=='gardner-mixed2-8-frost-explicit-inactive-vapor-slot')
root=W/'closure12-original-causal-v1/original-mixed2-8-reader-v1';authority=f.prepare(spec,root)
assert set(authority['additional_original_parameter_authority']['literal_original_named_lines'])=={'HA','APAR','OMEGA_K'}
exe=W/'frost-undrained-state08-initialization-probe-O0-v1/corrected-module-import-v2/original_initialization_probe.exe'
assert f.SHA(exe.read_bytes())=='dee4a94a5e0e92d07c9aee2a4790fc5178f159f7e81ad316fcaa58b6a6f28b5e'
inventory=f.m.e.inventory(root)
child=subprocess.run([str(exe),'./swap.swp'],cwd=root,capture_output=True,timeout=30)
(root/'original-probe.stdout').write_bytes(child.stdout);(root/'original-probe.stderr').write_bytes(child.stderr)
phases=[line.decode() for line in child.stdout.splitlines() if line.startswith(b'ORIGINAL_INIT_PHASE ')]
q=dict(status='ACTUAL_ORIGINAL_MIXED2_8_REPAIRED_INPUT_ZERO_DAY_OBSERVED_NOT_QUALIFIED',actual_git_base=head,actual_uncommitted_status=dirty,
    actual_working_input_controller_sha256=f.SHA((R/'tests/nomacro_drainage/closed_gardner_state_feedback.py').read_bytes()),
    original_driver_source='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d',original_probe_executable_sha256=f.SHA(exe.read_bytes()),
    original_SDK_mixed_compiler_profiles=True,original_driver_O0=True,compiler_executions=0,model_days=0,
    original_reader_and_zero_day_initialization_accepted=b'ORIGINAL_INIT_PHASE AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS' in child.stdout,
    input_authority=authority,input_inventory=inventory,returncode=child.returncode,original_phases=phases,stdout_sha256=f.SHA(child.stdout),stderr_sha256=f.SHA(child.stderr),canonical_admission=False)
(E/'CLOSED_GARDNER_STATE12_ORIGINAL_REPAIRED_INPUT_READER_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
assert q['original_reader_and_zero_day_initialization_accepted'],q
print('ACTUAL_ORIGINAL_MIXED2_8_ZERO_DAY_INITIALIZATION_ACCEPTED_WITH_LITERAL_ORIGINAL_HA_APAR_OMEGA_K',flush=True)
