"""Finite next coupling surface from genuine original source and actual Git blobs."""
import hashlib,io,json,re,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
C='fdea74b3914fe37c05a6a5301af6661773e1e5e3'
SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
P='integration/f-ci/nomacro-complete01/'
catalog=json.loads(git('show',C+':'+P+'NOMACRO_CLOSURE03_ORIGINAL_SOURCE_CALL_CATALOG_V1.json'))
raw=git('show',C+':'+catalog['original_source_path']);assert SHA(raw)==catalog['original_archive_sha256']
members={}
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    for name,terms in {
        'SWAP/readswap.f90':['iHWCKmodel','swhyst','swkimpl','swsophy'],
        'SWAP/MOD_MvG_functions.f90':['imod == 2','dexp(alfamg','watcon =','moiscap =','hconduc =','dhconduc ='],
        'SWAP/headcalc.f90':['swbotb == 6','swbotb.eq.6','swbotb==6','case (6)','dkdh','swkimpl'],
        'SWAP/boundbottom.f90':['swbotb == 6','swbotb.eq.6','swbotb==6','qbot','case (6)'],
    }.items():
        body=z.read(name);item=catalog['source_members'][name]
        assert len(body)==item['bytes'] and SHA(body)==item['sha256']
        lines=body.decode('cp1252').splitlines();indexes=set()
        for i,line in enumerate(lines):
            if any(t.lower() in line.lower() for t in terms):indexes.update(range(max(0,i-2),min(len(lines),i+4)))
        members[name]=dict(bytes=len(body),sha256=SHA(body),original_lines=[dict(line=i+1,text=lines[i]) for i in sorted(indexes)])
surface=['frost_undrained_state.py','frost_boundary_state_calendar.py','frost_boundary_composition.py',
    'frost_analytical_composition.py','frost_analytical_native.f90','frost_analytical_boundary_native.f90',
    'implicit_conductivity.py','implicit_frost_composition.py','implicit_snow_composition.py',
    'implicit_frost_source_guard.py','implicit_snow_source_guard.py','frost_boundary_terminal_trial.py',
    'analytical_snow_undrained.py','implicit_hydraulic_state.py']
blobs={}
for name in surface:
    path='app/hybrid_water/'+name;body=git('show',C+':'+path)
    assert body==(R/path).read_bytes().replace(b'\r\n',b'\n')
    blobs[path]=dict(bytes=len(body),sha256=SHA(body))
record=dict(status='NEXT_FINITE_HYDRAULIC_THERMAL_STATE_DEPENDENCY_SURFACE_AUDITED_NOT_IMPLEMENTED_OR_QUALIFIED',
    actual_observer=C,original_archive=dict(file=catalog['original_source_path'],sha256=SHA(raw)),original_source=members,
    current_source_blobs=blobs,
    next_coherent_batch=[
      dict(family='Drainage-off original closed zero-flux bottom6 with implicit default-Mualem and hys0/1/2',
        classification='COMPOSITION_MISSING',scope='Ordinary/Snow/Frost water and CDE, original initialization1/2 and state/calendar owners',
        physical_boundary='Use literal original zero-flux boundary, without replacing measured qbot or inventory',
        source_proof_required='Exact head/time/trial-receipt composition and original original native/state owner; no authority hash bypass'),
      dict(family='Explicit Gardner model2 and originally valid mixed layers',classification='COMPOSITION_MISSING',
        scope='Ordinary/Snow/Frost and previously admitted explicit analytical boundary/drainage/calendars',
        prior_guard='model_domain and static native domain exclude model2 although original watcon/moiscap/hconduc/dhconduc include it',
        physical_equations='Reuse actual original Gardner bodies and original physical parameters'),
    ],
    preserve=dict(existing_drained_bottom6_model1='ALREADY_ADMITTED_DO_NOT_REOPEN',
        original_non1_hysteresis='INVALID_ORIGINAL_READER',original_non1_tabulated='INVALID_ORIGINAL_READER',
        active_macropores='EXCLUDED_MACRO',scientific_decisions=['Prescribed head/flux9 vapor/thermal residual','AGE dryout retained moment'],
        explicit_Szymkiewicz='Requires actual original physical Kavg table; never invent'),
    compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'CLOSED_GARDNER_STATE12_ORIGINAL_SOURCE_DEPENDENCY_AUDIT_V1.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
assert git('rev-parse','HEAD').decode().strip()==C
print(record['status'],len(members),len(blobs))
