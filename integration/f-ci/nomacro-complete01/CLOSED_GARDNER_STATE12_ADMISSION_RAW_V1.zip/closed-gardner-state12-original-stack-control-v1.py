"""Original executable stack control; no change to model objects, inputs or physics."""
from contextlib import ExitStack
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');D=W/'closure12-original-causal-v1';B=W/'closure12-original-causal-O0-v1'
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from closed_gardner_state_feedback import input_donor
SHA=lambda b:hashlib.sha256(b).hexdigest();first=json.loads((D/'RESULT.json').read_text())
q=dict(status='RUNNING_ORIGINAL_MAIN_STACK_CONTROL_NOT_QUALIFIED',actual_controller_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    original_first_link_failures='Two original full-main SIGSEGV failures, not evidence of a Gardner-specific legacy defect',
    compile_executions=0,link_executions=0,original_model_object_bytes_changed=False,physical_parameters_or_dates_changed=False,cases=[],canonical_admission=False)
report=D/'RESULT_STACK64_V1.json'
def save():report.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
try:
    for name,digest in first['exact_original_provider_files'].items():assert SHA((J/name).read_bytes())==digest
    exe=B/'original_mixed_SDK_stack64_full_swap.exe';objects=sorted((J/'build/swap-obj').glob('*.o'))
    command=['C:/msys64/ucrt64/bin/gfortran.exe','-Wl,--stack,67108864','-o',str(exe),*map(str,objects),str(J/'build/ttutil-obj/libttutil.a')]
    child=subprocess.run(command,cwd=B,capture_output=True,timeout=30);(B/'link-stack64.stdout').write_bytes(child.stdout);(B/'link-stack64.stderr').write_bytes(child.stderr);child.check_returncode()
    q['link_executions']=1;q['actual_command']=command;q['original_executable_sha256']=SHA(exe.read_bytes());save()
    cases=['original-model3-snow9-control','gardner-snow-paired9-explicit-water','gardner-mixed2-1-snow-paired9-explicit-cde']
    for name in cases:
        root=D/(name+'-stack64-v1');root.mkdir();inventory={}
        if name=='original-model3-snow9-control':
            with ExitStack() as stack:
                donor_name,donor=input_donor(dict(bottom=9,kind='water'),stack);prefix='model3-water-initial2/'
                for member in donor.names:
                    if member.startswith(prefix):
                        filename=member[len(prefix):];raw=donor.get(member);target=root/filename;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);inventory[filename]=SHA(raw)
                authority=dict(archive=donor_name,sha256=donor.record['sha256'],prefix=prefix)
        else:
            prior=next(v for v in first['cases'] if v['case']==name);authority='EXACT_IDENTICAL_ORIGINAL_FIRST_CAUSAL_INPUTS'
            for filename,digest in prior['identical_input_inventory'].items():
                raw=(D/name/filename).read_bytes();assert SHA(raw)==digest;target=root/filename;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);inventory[filename]=digest
        command=[str(exe),'./swap.swp'];started=time.perf_counter()
        with (root/'full-original.stdout').open('xb') as out,(root/'full-original.stderr').open('xb') as err:
            try:child=subprocess.run(command,cwd=root,stdout=out,stderr=err,timeout=30);item=dict(status='ORIGINAL_STACK64_PROCESS_TERMINAL_NOT_QUALIFIED',returncode=child.returncode)
            except subprocess.TimeoutExpired:item=dict(status='CENSORED_ORIGINAL_STACK64_AT30_SECONDS',returncode=None)
        item.update(case=name,seconds=time.perf_counter()-started,command=command,input_authority=authority,identical_input_inventory=inventory,
                    stdout_sha256=SHA((root/'full-original.stdout').read_bytes()),stderr_sha256=SHA((root/'full-original.stderr').read_bytes()))
        q['cases'].append(item);save();print(name,item['status'],item['returncode'],flush=True)
        if name=='original-model3-snow9-control' and item['returncode']!=0:
            q['status']='ORIGINAL_MAIN_POSITIVE_CONTROL_UNRESOLVED_NO_GARDNER_LEGACY_DEFECT_CLAIM';break
    else:q['status']='ORIGINAL_STACK64_MODEL3_AND_GARDNER_OBSERVATIONS_RETAINED_NOT_SCIENTIFICALLY_QUALIFIED'
except Exception as error:q.update(status='FAILED_ORIGINAL_STACK_CONTROL_PREFLIGHT',error=repr(error));raise
finally:save()
