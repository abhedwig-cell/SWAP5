"""Diagnose the actual original pending-date refusal without altering a counter."""
from pathlib import Path
import hashlib,json,re,struct,subprocess,zipfile
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent
SHA=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='3be78ad24d2bce348f38a26e289af0f4846c5883'
name='closed-frost-implicit-h2-water-dates';folder=W/'closure12-feedback-v1/finite-O0-v1'/name
q=json.loads((folder/'RESULT.json').read_text());assert q['actual_source']==head and q['trajectory']['status']=='SHORT_PASS' and q['cold']==[]
assert b'ERROR STOP Inconsistent original interval date pointer' in (folder/'own-2/original/donor.stderr').read_bytes()
build=Path(q['build_root']);meta=json.loads((build/'BUILD.json').read_text());nodes=meta['project']['nodes']
with zipfile.ZipFile(folder/'trajectory/accepted-column-1-day-2.zip') as z:raw=z.read('macro.bin')
frames=[]
for pos in range(8,len(raw)-160):
    if raw[pos:pos+8]!=struct.pack('<2i',1,nodes):continue
    h=struct.unpack_from('<20i',raw,pos)
    if h==struct.unpack_from('<20i',raw,pos+80) and h[3]>100 and pos+160+16*h[3]<=len(raw):frames.append((pos,h))
assert len(frames)==1;pos,header=frames[0]
assert header[6]==2 and header[10]==1
source=(folder/'inputs/swap.swp').read_text(encoding='cp1252')
assert re.search(r'(?mi)^\s*TSTART\s*=\s*2002-12-26',source)
assert re.search(r'(?mis)^\s*OUTDATINT\s*=\s*\n\s*2002-01-31\s*\n\s*2004-12-31',source)
with zipfile.ZipFile(R/'reference/swap-4.3.1/source-archives/SWAP.ZIP') as z:original=z.read('SWAP/timecontrol.f90')
text=original.decode('cp1252').replace('\r\n','\n')
assert re.search(r'(?m)^\s*ioutdatint = 1\s*$',text)
assert 'if (abs(outdatint(ioutdatint) - t1900 + 1.d0) < 1.d-3) then\n               floutput   = .TRUE.\n               flzerointr = .TRUE.\n               ioutdatint = ioutdatint + 1' in text
path='app/hybrid_water/frost_implicit_plate_calendar.py';before=subprocess.check_output(['git','show',head+':'+path],cwd=R)
anchor="item['implicit']==1 and item['bottom'] in (5,8)";replacement="item['implicit']==1 and item['bottom'] in (5,8) or item['implicit']==1 and item['bottom']==6 and item['swodat']==1"
assert before.decode().count(anchor)==1;after=before.decode().replace(anchor,replacement,1)
out=dict(status='ACTUAL35DAY_PASS_COLD_REFUSAL_IS_MISSING_COMPOSITION_OF_EXISTING_ORIGINAL_PENDING_DATE_GUARD',actual_source=head,
    original_timecontrol_sha256=SHA(original),original_timecontrol_initial_pointer=1,actual_day2_interval_pointer=header[10],actual_calendar_header=list(header),
    actual_initial_interval_date='2002-01-31',actual_immutable_TSTART='2002-12-26',original_pending_pointer_must_remain_one=True,
    failed_RESULT_sha256=SHA((folder/'RESULT.json').read_bytes()),failed_stderr_sha256=SHA((folder/'own-2/original/donor.stderr').read_bytes()),
    classification='COMPOSITION_MISSING',source_path=path,before_lf_sha256=SHA(before),after_lf_sha256=SHA(after.encode()),
    literal_before=anchor,literal_after=replacement,dates_changed=False,counters_changed=False,tolerances_changed=False,
    model_executions=0,compiler_executions=0,scientific_qualification=False,canonical_admission=False)
(E/'CLOSED_GARDNER_STATE12_PENDING_DATE_DIAGNOSIS_V1.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
(E/'CLOSED_GARDNER_STATE12_PROPOSED_frost_implicit_plate_calendar.py').write_bytes(after.encode())
print(out['status'],flush=True)
