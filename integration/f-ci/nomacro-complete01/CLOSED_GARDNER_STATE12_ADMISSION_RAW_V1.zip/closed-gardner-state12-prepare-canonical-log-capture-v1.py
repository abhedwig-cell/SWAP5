from pathlib import Path
import ast
E=Path(__file__).parent;M='2e98506b4fb469bbf5995a8ab0b49c88ead0972c'
s=(E/'closed-gardner-state12-capture-pr-original-logs-v1.py').read_text(encoding='utf8')
s=s.replace('07cb2850e2cd45deb1e197161409a3784a8975e7',M).replace('8fe30349bfb9717e9610008d1eebe5a957a8f476',M)
s=s.replace("run['event']=='pull_request'","run['event']=='push'").replace('CLOSED_GARDNER_STATE12_PR1811_','CLOSED_GARDNER_STATE12_ACTUAL_MERGE_').replace('actual_candidate=C','actual_verified_merge=C')
ast.parse(s);(E/'closed-gardner-state12-capture-canonical-original-logs-v1.py').write_text(s,encoding='utf8')
