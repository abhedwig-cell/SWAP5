"""Prepare exact original closed-boundary state couplings; do not install/run."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
C='e28233d32c404c86fa58d7cbd71f7632dde1654c';app='app/hybrid_water/'
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
changes={}
def edit(name,before,after):
    path=app+name
    if path not in changes:
        original=git('show',C+':'+path).decode();changes[path]=dict(before=original,after=original,edits=[])
    item=changes[path];assert item['after'].count(before)==1,(name,before)
    item['after']=item['after'].replace(before,after,1);item['edits'].append(dict(before=before,after=after))

edit('frost_undrained_state.py',"                and (boundary.get('SWBOTB')!=6 or selectors.get('SWKIMPL')==selectors.get('SWHYST')==0)\n",'')
before="""    if values['SWBOTB']==6:
        from frost_analytical_composition import model_domain
        analytical=model_domain(active,values,allow_model1=True)
        if analytical is None:return None"""
after="""    if values['SWBOTB']==6:
        if values['SWKIMPL']==values['SWHYST']==0:
            from frost_analytical_composition import model_domain
            analytical=model_domain(active,values,allow_model1=True)
            if analytical is None:return None
        elif models and re.fullmatch(r'\\+?0*1(?:[ \\t]+\\+?0*1)*[ \\t]*',models[0]) is None:
            # Original non1+hysteresis is invalid. Implicit closed non1 still
            # requires its separate explicit per-layer native admission.
            return None"""
edit('frost_undrained_state.py',before,after)
edit('implicit_conductivity.py',"or boundary['SWBOTB']==6 and selectors.get('SWDRA') in (1,2)",
     "or boundary['SWBOTB']==6 and selectors.get('SWDRA') in (0,1,2)")
edit('implicit_snow_composition.py','bottom in (1,5,8) and drain in (0,1))',
     '((bottom in (1,5,8) and drain in (0,1)) or (bottom==6 and drain==0)))')
edit('implicit_frost_source_guard.py','    if boundary is None:\n','    if boundary is None or boundary==6:\n')
edit('snow_undrained.py',"report['boundary']['SWBOTB'] not in (5,8,9)","report['boundary']['SWBOTB'] not in (5,6,8,9)")
before="    if selected['swbotb']==9:\n        text=replace(text,'(swbotb/=5.and.swbotb/=8)','swbotb/=9')"
after="    if selected['swbotb']==6:\n        text=replace(text,'(swbotb/=5.and.swbotb/=8)','swbotb/=6')\n    elif selected['swbotb']==9:\n        text=replace(text,'(swbotb/=5.and.swbotb/=8)','swbotb/=9')"
edit('snow_undrained_state.py',before,after)
edit('snow_undrained_state.py',"    if selected['swkimpl'] and not project.solute:\n",
     "    if selected['swkimpl'] and not project.solute and selected['swbotb']!=6:\n")
before="    if selected['swbotb']==9:\n        result=native.replace(result,'(swbotb/=5.and.swbotb/=8)','swbotb/=9')"
after="    if selected['swbotb']==6:\n        result=native.replace(result,'(swbotb/=5.and.swbotb/=8)','swbotb/=6')\n    elif selected['swbotb']==9:\n        result=native.replace(result,'(swbotb/=5.and.swbotb/=8)','swbotb/=9')"
edit('snow_undrained_build.py',before,after)
before="    if selected is not None and selected['swbotb']==9:\n"
after="""    if selected is not None and selected['swbotb']==6:
        # Literal original Boundbottom assigns qbot=0 for bottom6. This is an
        # independent candidate receipt, not a substituted accepted flux/store.
        guard='\\n         hybrid_snow_trial_guard=hybrid_snow_soil_trial_residual(0d0)\\n         if(abs(hybrid_snow_trial_guard)>1d-10)flnonconv=.true.'
    elif selected is not None and selected['swbotb']==9:
"""
edit('snow_undrained_build.py',before,after)
edit('snow_undrained_source_guard.py',"    if selection(project)['swbotb']==9:return namespace['source']",
     "    if selection(project)['swbotb'] in (6,9):return namespace['source']")
before="        if hashlib.sha256(source.encode('cp1252')).hexdigest()!=HEADS['water']:"
after="""        elif selected['swbotb']==6:
            from lower_boundary_receipt import render_headcalc
            source=render_headcalc(source,8)
        if hashlib.sha256(source.encode('cp1252')).hexdigest()!=HEADS['water']:"""
edit('snow_undrained_source_guard.py',before,after)

records={}
for path,item in changes.items():
    ast.parse(item['after']);before=item['before'].encode();after=item['after'].encode()
    name='CLOSED_GARDNER_STATE12_PROPOSED_CLOSED_'+Path(path).name
    with (E/name).open('x',encoding='utf8',newline='\n') as out:out.write(item['after'])
    records[path]=dict(actual_before_git_source=C,before_lf_sha256=SHA(before),proposed_lf_sha256=SHA(after),
        proposed_file=name,ordered_literal_replacements=item['edits'])
record=dict(status='PROPOSED_EXISTING_MUALEM_CLOSED_ZERO_BOUNDARY_STATE_COUPLING_NOT_INSTALLED_OR_QUALIFIED',
    actual_preparation_source=C,files=records,original_equations_changed=False,new_physical_state=False,
    original_qbot_rule='SWAP/boundbottom.f90: if (swbotb == 6) qbot = 0.0d0',
    conservation_limits_changed=False,candidate_receipt='Actual original zero boundary, never inferred or corrected from final storage',
    required_followup=['Original profile initialization guard composition before SWINCO1 tests',
      'Real public original-input reader and O0/O2 physical water/CDE windows',
      'Complete native/header refusals, exact cold output and rollback/restart',
      'Independent 1e-10 physical receipts and prior unchanged whole-object postimages',
      'Combine with selected explicit Gardner in the same coherent batch12'],
    prior_ordinary_nonsnow_calendar_gaps_not_claimed_closed=True,
    compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'CLOSED_GARDNER_STATE12_CLOSED_SOURCE_PROPOSAL_V1.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
print(record['status'],len(records))
