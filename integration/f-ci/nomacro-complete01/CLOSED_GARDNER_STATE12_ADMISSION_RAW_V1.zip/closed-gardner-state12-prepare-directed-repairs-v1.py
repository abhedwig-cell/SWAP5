"""Prepare exact narrow repairs while the frozen original cohort continues."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='3be78ad24d2bce348f38a26e289af0f4846c5883'
pending=json.loads((E/'CLOSED_GARDNER_STATE12_PENDING_DATE_DIAGNOSIS_V1.json').read_text())
changes={pending['source_path']:[(pending['literal_before'],pending['literal_after'])],
 'app/hybrid_water/analytical_snow_undrained.py':[(
  '  if _models_from_grid(active,models) is None:return None',
  '  expanded=_models_from_grid(active,models)\n  if expanded is None:return None\n  if 2 in models:models=expanded')],
 'app/hybrid_water/ordinary_pond_source_guard.py':[(
  "    if hashlib.sha256(source).hexdigest() != HEADS[form]:",
  "    if report['boundary']['SWBOTB']==6:\n"
  "        from closed_zero_boundary import input_domain as closed_domain\n"
  "        text=(Path(project.input_directory)/'swap.swp').read_text(encoding='cp1252')\n"
  "        if closed_domain(text,report['selectors'],project.original_output):\n"
  "            # The newly composed ordinary closed6 dense domains all retain\n"
  "            # the exact qualified water HeadCalc. Reconstruct only the known\n"
  "            # independent bottom8 receipt before comparing the WHOLE body.\n"
  "            from lower_boundary_receipt import render_headcalc\n"
  "            source=render_headcalc(source.decode('cp1252'),8).encode('cp1252')\n"
  "            form='water'\n"
  "    if hashlib.sha256(source).hexdigest() != HEADS[form]:")],
}
q=dict(status='DIRECTED_EXACT_GUARD_AND_NATIVE_DESCRIPTOR_REPAIRS_PROPOSED_NOT_INSTALLED',actual_parent_source=head,files={},physical_equations_changed=False,new_physical_state=False,new_numerical_policy=False,model_executions=0,compiler_executions=0,canonical_admission=False)
for path,edits in changes.items():
    before=git('show',head+':'+path);after=before.decode()
    for left,right in edits:
        assert after.count(left)==1;after=after.replace(left,right,1)
    ast.parse(after);name='CLOSED_GARDNER_STATE12_DIRECTED_PROPOSED_'+Path(path).name
    (E/name).write_bytes(after.encode())
    q['files'][path]=dict(before_lf_sha256=SHA(before),after_lf_sha256=SHA(after.encode()),proposed_file=name,literal_edits=[dict(before=left,after=right) for left,right in edits])
(E/'CLOSED_GARDNER_STATE12_DIRECTED_REPAIRS_PROPOSED_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(q['status'],len(q['files']),flush=True)
