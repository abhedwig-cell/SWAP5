"""Prepare reviewable selected Gardner/native coupling edits, without installing."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
C='fdea74b3914fe37c05a6a5301af6661773e1e5e3'
SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
changes={}
def edit(path,old,new):
    if path not in changes:
        original=git('show',C+':'+path).decode();changes[path]=dict(before=original,after=original,edits=[])
    item=changes[path];text=item['after'];assert text.count(old)==1,(path,old)
    item['after']=text.replace(old,new,1);item['edits'].append(dict(before=old,after=new))
app='app/hybrid_water/'
edit(app+'frost_analytical_composition.py','any(x not in (1,3,4,5,6,7,8,9,10,11) for x in models)',
     'any(x not in range(1,12) for x in models)')
anchor="    return text.replace('swbotb/=5','swbotb/='+str(item['bottom']),1)"
replacement="""    # The original Gardner branches already own the physical constitutive
    # calculations. Relax only their previously excluded static native witness,
    # selected by the actual per-layer input models. All admitted old model
    # native renderings remain byte-for-byte unchanged.
    if 2 in item['analytical_frost_models']:
        if boundary_domain(item):
            before=('    if(any(iHWCKmodel(1:numlay)<1).or.any(iHWCKmodel(1:numlay)>11).or. &\\n'
                    \"       any(iHWCKmodel(1:numlay)==2))error stop 'Foreign analytical Frost boundary constitutive models'\")
            after=\"    if(any(iHWCKmodel(1:numlay)<1).or.any(iHWCKmodel(1:numlay)>11))error stop 'Foreign analytical Frost boundary constitutive models'\"
        else:
            before='       any(iHWCKmodel(1:numlay)==2).or.all(iHWCKmodel(1:numlay)==1)) &'
            after='       all(iHWCKmodel(1:numlay)==1)) &'
        if text.count(before)!=1:raise ValueError('Foreign original Gardner Frost native witness anchor')
        text=text.replace(before,after,1)
    return text.replace('swbotb/=5','swbotb/='+str(item['bottom']),1)"""
edit(app+'frost_analytical_composition.py',anchor,replacement)
edit(app+'analytical_snow_undrained.py','any(x not in (1,3,4,5,6,7,8,9,10,11) for x in models)',
     'any(x not in range(1,12) for x in models)')
anchor="        extra=Path(__file__).with_name('snow_analytical_native.f90').read_text(encoding='cp1252')"
replacement=anchor+"""
        if 2 in selected['analytical_snow_models']:
            before='       any(iHWCKmodel(1:numlay)==2).or.all(iHWCKmodel(1:numlay)==1)) &'
            after='       all(iHWCKmodel(1:numlay)==1)) &'
            extra=replace(extra,before,after)"""
edit(app+'snow_undrained_state.py',anchor,replacement)
records={}
for path,item in changes.items():
    ast.parse(item['after']);before=item['before'].encode();after=item['after'].encode()
    name='CLOSED_GARDNER_STATE12_PROPOSED_GARDNER_'+Path(path).name
    with (E/name).open('x',encoding='utf8',newline='\n') as out:out.write(item['after'])
    records[path]=dict(actual_before_git_source=C,before_lf_sha256=SHA(before),proposed_lf_sha256=SHA(after),
        proposed_file=name,ordered_literal_replacements=item['edits'])
record=dict(status='PROPOSED_SELECTED_GARDNER_EXPLICIT_SNOW_FROST_COUPLING_NOT_INSTALLED_OR_QUALIFIED',
    actual_preparation_source=C,files=records,original_equations_changed=False,new_physical_state=False,
    all_prior_model_source_renderings_required_to_remain_bit_identical=True,
    required_followup=['Real public reader and O0/O2 model windows from original immutable inputs',
        'Complete native/header refusals, cold/output identity and rollback/restart',
        'Independent water/CDE conservation and unchanged old whole-object postimages',
        'Group with original closed-boundary default-Mualem compositions in batch12'],
    compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'CLOSED_GARDNER_STATE12_GARDNER_SOURCE_PROPOSAL_V1.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
print(record['status'],len(records))
