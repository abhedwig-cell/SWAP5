"""Complete the proposed effective NoVap domain from actual original reader proof."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
C='e4d9a56143d85550ee272fbac55f1d4a08173195'
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
prior=json.loads((E/'CLOSED_GARDNER_STATE12_GARDNER_SOURCE_PROPOSAL_V1.json').read_text(encoding='utf8'))
observed=json.loads((E/'CLOSED_GARDNER_STATE12_ORIGINAL_INACTIVE_VAPOR_READER_V1.json').read_text(encoding='utf8'))
assert len(observed['cases'])==5
assert all(v['original_reader_accepted'] and v['original_zero_day_initialization_reached'] and v['current_public_returncode']!=0 for v in observed['cases'][:4])
assert not observed['cases'][4]['original_reader_accepted'] and observed['model_days']==0
files={}
for path,item in prior['files'].items():
    raw=git('show',C+':'+path);assert SHA(raw)==item['before_lf_sha256']
    text=raw.decode();edits=list(item['ordered_literal_replacements'])
    for edit in edits:assert text.count(edit['before'])==1;text=text.replace(edit['before'],edit['after'],1)
    assert SHA(text.encode())==item['proposed_lf_sha256']
    if path.endswith('/frost_analytical_composition.py'):
        before='        if any(x!=0 for x in flags) or any(x>=8 for x in models) and len(flags)!=count:return None'
        after=('        if any(x not in (0,1) for x in flags) or any(x>=8 for x in models) and len(flags)!=count:return None\n'
               '        if any(x>=8 for x in models) and any(flag!=0 for model,flag in zip(models,flags) if model>=8):return None')
        assert text.count(before)==1;text=text.replace(before,after,1);edits.append(dict(before=before,after=after))
    elif path.endswith('/analytical_snow_undrained.py'):
        before=" if rows and (re.fullmatch(r'[+-]?[0-9]+(?:[ \\t]+[+-]?[0-9]+)*[ \\t]*',rows[0]) is None or any(int(x)!=0 for x in rows[0].split())):return None"
        after=(" if rows and (re.fullmatch(r'[+-]?[0-9]+(?:[ \\t]+[+-]?[0-9]+)*[ \\t]*',rows[0]) is None or any(int(x) not in (0,1) for x in rows[0].split())):return None\n"
               " if 2 in models or any(x>=8 for x in models):\n"
               "  from implicit_hydraulic_state import _models_from_grid\n"
               "  # Pure original grid/scalar replication and effective vapor flags;\n"
               "  # no implicit selector or physical state is assigned by this reader.\n"
               "  if _models_from_grid(active,models) is None:return None")
        assert text.count(before)==1;text=text.replace(before,after,1);edits.append(dict(before=before,after=after))
    ast.parse(text);name='CLOSED_GARDNER_STATE12_PROPOSED_GARDNER_V2_'+Path(path).name
    with (E/name).open('x',encoding='utf8',newline='\n') as out:out.write(text)
    files[path]=dict(actual_before_git_source=C,before_lf_sha256=SHA(raw),proposed_lf_sha256=SHA(text.encode()),
        proposed_file=name,ordered_literal_replacements=edits,previous_uninstalled_proposal_source=item['actual_before_git_source'])
record=dict(status='PROPOSED_GARDNER_AND_ORIGINAL_EFFECTIVE_NOVAP_DOMAIN_NOT_INSTALLED_OR_QUALIFIED',
    actual_preparation_source=C,files=files,original_reader_zero_day_proof='CLOSED_GARDNER_STATE12_ORIGINAL_INACTIVE_VAPOR_READER_V1.json',
    original_reader_accepted_configurations=4,original_non1_hysteresis_refusal_preserved=True,
    active_vapor_for_models8_11_still_refused=True,unused_vapor_flags_for_models1_7_are_not_physics=True,
    physical_equations_changed=False,new_physical_state=False,compiler_executions=0,model_executions=0,canonical_admission=False,
    old_qualified_selected_native_renderings_required_bit_identical=True)
with (E/'CLOSED_GARDNER_STATE12_GARDNER_SOURCE_PROPOSAL_V2.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
print(record['status'],len(files))
