"""Avoid reading inactive native NoVap slots in newly selected Gardner domains."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
M='105b9a8e6ca9e846f214d69a71afe73ed18be11d';git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
prior=json.loads((E/'CLOSED_GARDNER_STATE12_GARDNER_SOURCE_PROPOSAL_V2.json').read_text(encoding='utf8'));files={}
for path,item in prior['files'].items():
    raw=git('show',M+':'+path);assert SHA(raw)==item['before_lf_sha256']
    text=raw.decode();edits=list(item['ordered_literal_replacements'])
    for edit in edits:assert text.count(edit['before'])==1;text=text.replace(edit['before'],edit['after'],1)
    assert SHA(text.encode())==item['proposed_lf_sha256']
    if path.endswith('/frost_analytical_composition.py'):
        before="        text=text.replace(before,after,1)\n    return text.replace('swbotb/=5','swbotb/='+str(item['bottom']),1)"
        after="""        text=text.replace(before,after,1)
        if not boundary_domain(item):
            before_vapor=('    if(any((iHWCKmodel(1:numlay)>=8).and.(.not.NoVap(1:numlay)))) &\\n'
                          \"       error stop 'Active vapor cannot use analytical Frost native'\")
            after_vapor=('    do i=1,numlay\\n'
                         '      if(iHWCKmodel(i)>=8)then\\n'
                         \"        if(.not.NoVap(i))error stop 'Active vapor cannot use analytical Frost native'\\n\"
                         '      end if\\n    end do')
            for left,right in [('    integer::n,ios','    integer::n,ios,i'),(before_vapor,after_vapor)]:
                if text.count(left)!=1:raise ValueError('Foreign Gardner inactive native vapor anchor')
                text=text.replace(left,right,1)
    return text.replace('swbotb/=5','swbotb/='+str(item['bottom']),1)"""
        assert text.count(before)==1;text=text.replace(before,after,1);edits.append(dict(before=before,after=after))
    elif path.endswith('/snow_undrained_state.py'):
        before="            extra=replace(extra,before,after)\n        if selected['swbotb'] in (5,8):"
        after="""            extra=replace(extra,before,after)
            extra=replace(extra,'    integer::n,ios','    integer::n,ios,i')
            before_vapor=('    if(any((iHWCKmodel(1:numlay)>=8).and.(.not.NoVap(1:numlay)))) &\\n'
                          \"       error stop 'Active vapor cannot use analytical Snow native'\")
            after_vapor=('    do i=1,numlay\\n'
                         '      if(iHWCKmodel(i)>=8)then\\n'
                         \"        if(.not.NoVap(i))error stop 'Active vapor cannot use analytical Snow native'\\n\"
                         '      end if\\n    end do')
            extra=replace(extra,before_vapor,after_vapor)
        if selected['swbotb'] in (5,8):"""
        assert text.count(before)==1;text=text.replace(before,after,1);edits.append(dict(before=before,after=after))
    ast.parse(text);name='CLOSED_GARDNER_STATE12_PROPOSED_GARDNER_V3_'+Path(path).name
    with (E/name).open('x',encoding='utf8',newline='\n') as out:out.write(text)
    files[path]=dict(actual_before_git_source=M,before_lf_sha256=SHA(raw),proposed_lf_sha256=SHA(text.encode()),
        proposed_file=name,ordered_literal_replacements=edits,previous_uninstalled_proposal_source=item['actual_before_git_source'])
q=dict(status='PROPOSED_ORIGINAL_GARDNER_NATIVE_DOMAIN_WITH_NO_INACTIVE_VAPOR_READ_NOT_INSTALLED_OR_QUALIFIED',
    actual_preparation_source=M,files=files,original_reader_zero_day_proof='CLOSED_GARDNER_STATE12_ORIGINAL_INACTIVE_VAPOR_READER_V1.json',
    new_native_Gardner_only_guard_reads_NoVap_only_for_effective_models8_11=True,
    prior_non_Gardner_native_source_renderings_unchanged=True,physical_equations_changed=False,new_physical_state=False,
    compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'CLOSED_GARDNER_STATE12_GARDNER_SOURCE_PROPOSAL_V3.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],len(files))
