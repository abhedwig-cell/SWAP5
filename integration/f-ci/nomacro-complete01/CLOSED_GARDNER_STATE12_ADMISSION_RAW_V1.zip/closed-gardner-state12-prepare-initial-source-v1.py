"""Prepare native owner initialization coupling; genuine source only, no install."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
C='e28233d32c404c86fa58d7cbd71f7632dde1654c';app='app/hybrid_water/'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
files={}
for name,before,after in [
 ('experimental_project.py','        else:state_supported=True\n',
  '        else:state_supported=True\n        from closed_zero_boundary import input_domain as closed_initial_domain\n        state_supported=state_supported or closed_initial_domain(text,selected,original_output)\n'),
 ('initial_profile_calendar.py',' if history:\n',
  ' from closed_zero_boundary import input_domain as closed_domain\n if snow and closed_domain(text,s,original_output):pass\n elif history:\n'),
]:
    path=app+name;raw=git('show',C+':'+path);text=raw.decode();assert text.count(before)==1,(path,before)
    changed=text.replace(before,after,1);ast.parse(changed)
    proposed='CLOSED_GARDNER_STATE12_PROPOSED_INITIAL_'+name
    with (E/proposed).open('x',encoding='utf8',newline='\n') as out:out.write(changed)
    files[path]=dict(actual_before_git_source=C,before_lf_sha256=SHA(raw),proposed_lf_sha256=SHA(changed.encode()),
        proposed_file=proposed,ordered_literal_replacements=[dict(before=before,after=after)])
path=app+'closed_zero_boundary.py';raw=(E/'closed_zero_boundary.PROPOSED_V1.py').read_bytes();ast.parse(raw)
files[path]=dict(actual_before_git_source=C,new_file=True,proposed_lf_sha256=SHA(raw),proposed_file='closed_zero_boundary.PROPOSED_V1.py')
record=dict(status='PROPOSED_ORIGINAL_PROFILE_INITIALIZATION_OWNER_COMPOSITION_NOT_INSTALLED_OR_QUALIFIED',
    actual_preparation_source=C,files=files,original_physical_initialization_unchanged=True,new_physical_state=False,
    ordinary_nonsnow_nondaily_gap_claimed_closed=False,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'CLOSED_GARDNER_STATE12_INITIAL_SOURCE_PROPOSAL_V1.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
print(record['status'],len(files))
