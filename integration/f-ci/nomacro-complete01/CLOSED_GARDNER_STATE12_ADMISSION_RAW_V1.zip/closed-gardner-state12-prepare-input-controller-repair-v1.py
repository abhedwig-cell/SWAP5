"""Complete missing model8 reader inputs with literal accepted original rows."""
from pathlib import Path
import ast,hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='3be78ad24d2bce348f38a26e289af0f4846c5883'
path='tests/nomacro_drainage/closed_gardner_state_feedback.py';before=git('show',head+':'+path);text=before.decode()
left="                       original_members={n:dict(bytes=len(raw),sha256=SHA(raw)) for n,raw in original.items()})\n    path=output/'swap.swp';text=original['swap.swp'].decode('cp1252')"
right="""                       original_members={n:dict(bytes=len(raw),sha256=SHA(raw)) for n,raw in original.items()})
        extra_lines={};extra_authority=None
        if any(v>=8 for v in spec['models']):
            member='current/frost-mixed8-9-water-d1-b8/inputs/swap.swp'
            raw=archive.get(member);donor_text=raw.decode('cp1252')
            for key in ['HA','APAR','OMEGA_K','H0']:
                if re.search(r'(?mi)^[ \\t]*'+key+r'[ \\t]*=',original['swap.swp'].decode('cp1252')):continue
                rows=re.findall(r'(?mi)^[ \\t]*'+key+r'[ \\t]*=[^\\r\\n]*(?:\\r?\\n|$)',donor_text);assert len(rows)==1
                extra_lines[key]=rows[0]
            extra_authority=dict(actual_git_source=PARENT,archive=name,archive_sha256=archive.record['sha256'],member=member,
                member_sha256=SHA(raw),literal_original_named_lines=extra_lines,existing_parameter_tables_unchanged=True)
    path=output/'swap.swp';text=original['swap.swp'].decode('cp1252')
    for row in extra_lines.values():text+='\\n'+row"""
assert text.count(left)==1;text=text.replace(left,right,1)
left='return dict(authority=authority,declared_selectors=values,physical_parameter_tables_unchanged=True,'
right='return dict(authority=authority,additional_original_parameter_authority=extra_authority,declared_selectors=values,physical_parameter_tables_unchanged=True,'
assert text.count(left)==1;text=text.replace(left,right,1)
ast.parse(text);name='CLOSED_GARDNER_STATE12_DIRECTED_PROPOSED_closed_gardner_state_feedback.py';(E/name).write_bytes(text.encode())
q=dict(status='ORIGINAL_NAMED_MODEL8_PARAMETER_INPUT_COMPLETION_PROPOSED_NOT_INSTALLED',actual_parent_source=head,source_path=path,before_lf_sha256=SHA(before),after_lf_sha256=SHA(text.encode()),proposed_file=name,
    original_failure='Real original ReadSwap refuses missing HA before HYBRID_READY',physical_parameter_values_invented=False,existing_parameter_tables_edited=False,compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'CLOSED_GARDNER_STATE12_INPUT_CONTROLLER_REPAIR_PROPOSED_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(q['status'],flush=True)
