"""Prepare genuine committed controls for the newly frozen public owner."""
from pathlib import Path
import ast
E=Path(__file__).parent
s=(E/'implicit-hydraulic-state11-real-negative-controls-v3.py').read_text(encoding='utf8')
for before,after in [('implicit_hydraulic_state.py','closed_zero_boundary.py'),('IMPLICIT_HYDRAULIC_STATE11_FIRST_UBUNTU_O0_ORIGINAL_V1','CLOSED_GARDNER_STATE12_FIRST_UBUNTU_O0_ORIGINAL_V1'),('FROST_UNDRAINED_STATE08_ADMISSION_RAW_V1.zip','IMPLICIT_HYDRAULIC_STATE11_ADMISSION_RAW_V1.zip'),('IMPLICIT_HYDRAULIC_STATE11','CLOSED_GARDNER_STATE12'),('nomacro-implicit-hydraulic11-negative-','nomacro-closed-gardner12-negative-'),("role.lower()+'03'","role.lower()+'01'"),('nomacro-implicit-hydraulic-state11','nomacro-closed-gardner-state12'),("before=b\"TAG=b'S5IHX001'\";assert original.count(before)==1;changed=original.replace(before,b\"TAG=b'S5IHX999'\",1)","before=b'SWDRA=0,SWBOTB=6';assert original.count(before)==1;changed=original.replace(before,b'SWDRA=0,SWBOTB=7',1)"),('Wrong actual typed per-layer analytical native model version; never execute models','Wrong actual closed bottom selector; never execute models'),('NEVER MERGE implicit hydraulic ','NEVER MERGE closed Gardner '),('FINAL3','FINAL1')]:
    assert before in s,before;s=s.replace(before,after)
ast.parse(s)
(E/'closed-gardner-state12-real-negative-controls-v1.py').write_text(s,encoding='utf8')
print('Prepared genuine four committed source/raw/inherited/publication controls, not executed')
