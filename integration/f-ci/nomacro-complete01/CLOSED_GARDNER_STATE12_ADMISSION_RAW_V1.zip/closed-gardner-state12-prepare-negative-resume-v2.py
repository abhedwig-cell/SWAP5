from pathlib import Path
import ast
E=Path(__file__).parent
q=E/'CLOSED_GARDNER_STATE12_FINAL1_NEGATIVES_V3.json'
(E/'CLOSED_GARDNER_STATE12_FINAL1_NEGATIVES_HARNESS_FAILURE_V1.json').write_bytes(q.read_bytes())
s=(E/'closed-gardner-state12-real-negative-controls-v1.py').read_text(encoding='utf8')
before='CLOSED_GARDNER_STATE12_ADMISSION_RAW_V1.zip';assert s.count(before)==1;s=s.replace(before,'IMPLICIT_HYDRAULIC_STATE11_ADMISSION_RAW_V1.zip')
before="   run(['git','switch','-c',branch]);target=R/path"
after="""   if subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=R).returncode==0:
    assert git('rev-parse',branch)==C;run(['git','switch',branch])
   else:run(['git','switch','-c',branch])
   target=R/path"""
assert s.count(before)==1;s=s.replace(before,after);ast.parse(s)
(E/'closed-gardner-state12-real-negative-controls-v2.py').write_text(s,encoding='utf8')
