"""Freeze actual portable science, original CI bytes and the current ownership boundary."""
from pathlib import Path
import ast,hashlib,io,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
SHA=lambda b:hashlib.sha256(b).hexdigest()
results=[]
for platform in ['UBUNTU','WINDOWS']:
    for opt in ['O0','O2']:
        name='CLOSED_GARDNER_STATE12_FIRST_'+platform+'_'+opt+'_INDEPENDENT_V1.json';raw=(E/name).read_bytes();q=json.loads(raw)
        assert q['context_count']==17 and q['primary_days']==595 and q['compiled_native_refusals']==285 and not q['canonical_admission'];(P/name).write_bytes(raw);results.append(q)
name='CLOSED_GARDNER_STATE12_REPAIRED_LOCAL_ARCHIVE_INDEPENDENT_V1.json';raw=(E/name).read_bytes();q=json.loads(raw);assert q['whole_objects']==1046 and q['context_count']==12;(P/name).write_bytes(raw)
lognames=[]
for platform in ['UBUNTU','WINDOWS']:
    for opt in ['O0','O2']:
        stem='CLOSED_GARDNER_STATE12_FIRST_'+platform+'_'+opt
        lognames.extend(stem+suffix for suffix in ['_JOB_ORIGINAL_API_V1.json','_RUN_ORIGINAL_API_V1.json','_ORIGINAL_CI_V1.log'])
lognames.append('CLOSED_GARDNER_STATE12_FIRST_FOUR_ORIGINAL_JOB_LOGS_V1.json')
members={};buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in lognames:
        value=(E/name).read_bytes();z.writestr(name,value);members[name]=dict(bytes=len(value),sha256=SHA(value))
raw=buffer.getvalue();name='CLOSED_GARDNER_STATE12_FIRST_ORIGINAL_CI_LOGS_RAW_V1'
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    for n,v in members.items():assert SHA(z.read(n))==v['sha256']
(P/(name+'.zip')).write_bytes(raw)
record=dict(status='EXACT_ORIGINAL_SUCCESSFUL_PRODUCER_LOG_AND_API_BYTES_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,actual_producer_source='e112e8f7f6f0bd00e4ae9035d00ef53860477448',original_text_or_source_identities_rewritten=False,canonical_admission=False)
(P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
summary=dict(status='SIXTYEIGHT_ACTUAL_WINDOWS_UBUNTU_O0_O2_PORTABLE_CONTEXTS_INDEPENDENT_PASS_CURRENT_PUBLIC_ADMISSION_PENDING',actual_parent='105b9a8e6ca9e846f214d69a71afe73ed18be11d',actual_portable_scientific_producer=results[0]['actual_producer_source'],context_count=68,primary_days=2380,native_samples=476,exact_cold_windows=240,compiled_native_refusals=1140,external_transaction_contexts=68,additional_local_contexts=12,additional_local_contexts_counted_again=False,whole_object_contexts=40,whole_objects=1046,deferred_numerical_cases=2,new_admitted_contexts=0,canonical_admission=False,original_failures_and_producers_rebound=False,old_model_periods_replayed=False,functional_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
(P/'CLOSED_GARDNER_STATE12_PORTABLE_INDEPENDENT_SUMMARY_V1.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
for name in ['STATUS.json','GAP_MATRIX.json']:
    q=json.loads((P/name).read_text(encoding='utf8'));batch=q.setdefault('closed_gardner_state12',{})
    batch.update(status=summary['status'],actual_portable_scientific_producer=summary['actual_portable_scientific_producer'],actual_portable_science=summary,canonical_admission=False,new_admitted_contexts=0,qualified_contexts=68,new_qualified_contexts=68,next_action='Freeze and independently test the real current public and publication owner; run actual committed source/raw/inherited/publication negatives; integrate only after required stable-candidate admission. Two genuine Gardner/Snow9 numerical gaps remain open.')
    if name=='STATUS.json':q['running_ci']=[];q['next_action']=batch['next_action'];q['recovery_point']='CLOSED_GARDNER_STATE12_PORTABLE_INDEPENDENT_SUMMARY_V1.json';q['active_local_jobs']=[]
    (P/name).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for path in (R/'tests/nomacro_drainage').glob('closed_gardner_state*.py'):ast.parse(path.read_text(encoding='utf8'))
print(json.dumps(summary,indent=2))
