"""Stage the actual functional repairs with original failures and exact recovery."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
head=git('rev-parse','HEAD').decode().strip();parent='105b9a8e6ca9e846f214d69a71afe73ed18be11d'
assert head=='3be78ad24d2bce348f38a26e289af0f4846c5883'
raw_name='CLOSED_GARDNER_STATE12_FIRST_LOCAL_SUCCESSES_FAILURES_RAW_V1';raw=json.loads((E/(raw_name+'.json')).read_text())
assert raw['sha256']=='8acadb26f64f33f3836719af90341aeaf1de80dae37ab2bebe81be7dcc6aed6b' and raw['bytes']==145682512 and len(raw['members'])==20236 and len(raw['parts'])==2
for part in raw['parts']:
    value=(E/part['file']).read_bytes();assert len(value)==part['bytes'] and SHA(value)==part['sha256'];(P/part['file']).write_bytes(value)
(P/(raw_name+'.json')).write_bytes((E/(raw_name+'.json')).read_bytes())
proposal=dict(status='REVIEWED_ACTUAL_WORKING_CLOSED_GARDNER_POSTIMAGES_FOR_COHERENT_CHECKPOINT_PENDING_QUALIFICATION',actual_previous_checkpoint=head,actual_canonical_parent=parent,
    observed_working_postimages_not_parent_source=True,files={},physical_equations_changed=False,new_physical_state=False,new_numerical_policy=False,canonical_admission=False)
for path in git('diff','--name-only',parent,'--','app').decode().splitlines():
    exists=subprocess.run(['git','cat-file','-e',parent+':'+path],cwd=R,capture_output=True).returncode==0
    before=git('show',parent+':'+path) if exists else b'';after=(R/path).read_bytes().replace(b'\r\n',b'\n');ast.parse(after)
    left=before.decode().splitlines(keepends=True);right=after.decode().splitlines(keepends=True);offsets=[0]
    for line in left:offsets.append(offsets[-1]+len(line))
    edits=[dict(base_start=offsets[i],base_end=offsets[j],before=''.join(left[i:j]),after=''.join(right[k:l])) for tag,i,j,k,l in difflib.SequenceMatcher(None,left,right,autojunk=False).get_opcodes() if tag!='equal']
    restored=before.decode()
    for item in reversed(edits):
        lo,hi=item['base_start'],item['base_end'];assert restored[lo:hi]==item['before'];restored=restored[:lo]+item['after']+restored[hi:]
    assert restored.encode()==after
    proposal['files'][path]=dict(new_file=not exists,before_lf_sha256=SHA(before),after_lf_sha256=SHA(after),ordered_literal_edits=edits)
assert len(proposal['files'])==19
(P/'CLOSED_GARDNER_STATE12_SOURCE_PROPOSAL_V3.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf8')
plan=json.loads((P/'CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V2.json').read_text());deferred=['gardner-snow-paired9-explicit-water','gardner-mixed2-1-snow-paired9-explicit-cde']
plan.update(status='FINITE19_ORIGINAL_ATTEMPTS_PRESERVED_17_INDEPENDENT_QUALIFICATION_CASES_TWO_NUMERICAL_DEFECTS_RETAINED',selected_source_proposals=['CLOSED_GARDNER_STATE12_SOURCE_PROPOSAL_V3.json'],
    actual_first_attempt_source=head,actual_first_attempt_passes=22,actual_first_attempt_failures=16,
    independent_qualification_cases=[v['name'] for v in plan['cases'] if v['name'] not in deferred],
    deferred_numerical_cases=[dict(case=name,classification='NUMERICAL_DEFECT',actual_source=head,observation='Nonfinite original implicit pond availability during Snowmelt after partial actual day returns. Neither PASS nor original legacy defect established.',
        original_reference_causal_status='UNKNOWN_ORIGINAL_MAIN_POSITIVE_CONTROL_SIGSEGV_ALSO_OCCURS_FOR_ACCEPTED_MODEL3_CONTROL',raw_archive=raw_name+'.json',still_functional_migration_gap=True) for name in deferred],
    original_failed_model8_input_completed_with_literal_original_HA_APAR_OMEGA_K=True,current_original_repaired_input_zero_day_reader_accepted=True,qualified_contexts=0,new_admitted_contexts=0,canonical_admission=False)
(P/'CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V3.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8')
names=['CLOSED_GARDNER_STATE12_PENDING_DATE_DIAGNOSIS_V1.json','CLOSED_GARDNER_STATE12_ORDINARY_SOURCE_DIAGNOSIS_V1.json',
       'CLOSED_GARDNER_STATE12_DIRECTED_REPAIRS_PROPOSED_V1.json','CLOSED_GARDNER_STATE12_INPUT_CONTROLLER_REPAIR_PROPOSED_V1.json',
       'CLOSED_GARDNER_STATE12_WORKING_REPAIR_FEEDBACK_V1.json','CLOSED_GARDNER_STATE12_ORIGINAL_REPAIRED_INPUT_READER_V1.json',
       'CLOSED_GARDNER_STATE12_CURRENT_ADDITIONAL_YEAR_SEAMS_V1.json']
for name in names:(P/name).write_bytes((E/name).read_bytes())
q=json.loads((P/'STATUS.json').read_text());q['closed_gardner_state12'].update(status='DIRECTED_FUNCTIONAL_REPAIRS_AND_FULL_FIRST_FAILURE_RAW_CHECKPOINT_PENDING_COMMITTED_FEEDBACK',
    previous_source_checkpoint=head,source_proposal='CLOSED_GARDNER_STATE12_SOURCE_PROPOSAL_V3.json',finite_case_plan='CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V3.json',
    actual_first_local_context_attempts=38,actual_first_local_complete_passes=22,actual_first_local_failures=16,actual_additional_year_cold_windows=10,
    original_first_local_raw=raw_name+'.json',original_first_local_raw_sha256=raw['sha256'],independent_qualification_cases=17,deferred_numerical_cases=deferred,
    current_zero_day_original_mixed2_8_reader_accepted=True,new_qualified_contexts=0,new_admitted_contexts=0,canonical_admission=False,
    next_action='Run only six repaired safe contexts on actual committed O0/O2 source; retain unchanged first22 local successes through current whole-object postimages. Qualify the17 independent Windows/Ubuntu O0/O2 couplings coherently; investigate the two genuine Gardner/Snow9 numerical failures separately without parameter/date/flux/tolerance correction.')
q['next_action']=q['closed_gardner_state12']['next_action']
q['test_selection']['groups']['closed_gardner_state12']['prior_execution']='FAILED'
q['test_selection']['groups']['closed_gardner_state12']['diagnosis']='First38 local attempts retained:22 complete passes and16 failures. Three narrow source/native guard repairs and literal original model8 input completion have real source/native/zero-day interface feedback. Two distinct Snow9 numerical failures remain open. New persisted selection is required before any further expensive cohort; no stale PASS.'
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
gap=json.loads((P/'GAP_MATRIX.json').read_text());gap['closed_gardner_state12'].update(status='DIRECTED_REPAIRS_IMPLEMENTED_FIRST38_ORIGINAL_ATTEMPTS_PRESERVED_NOT_QUALIFIED',
    first_local_passes=22,first_local_failures=16,additional_exact_year_cold_windows=10,independent_qualification_cases=17,new_admitted_contexts=0)
gap['gardner_snow9_nonfinite']=dict(classification='NUMERICAL_DEFECT',actual_source=head,scope=deferred,observed='Nonfinite pond availability during actual Snowmelt; original full-main reference positive control unresolved, no LEGACY_DEFECT assertion',
    raw_archive=raw_name+'.json',scientific_choice_or_numerical_repair_not_invented=True,blocks_independent_closed_Mualem_Gardner58_qualification=False,still_a_historical_migration_gap=True)
(P/'GAP_MATRIX.json').write_text(json.dumps(gap,indent=2)+'\n',encoding='utf8')
(R/'docs/science/NOMACRO_CLOSED_GARDNER_STATE12.md').write_text('''# Closed-boundary and explicit Gardner state12

Canonical parent is `105b9a8e6ca9e846f214d69a71afe73ed18be11d` (admitted bounded880). Functional closure remains PARTIAL, whole scientific equivalence NOT_QUALIFIED, global counts UNKNOWN and RC3 unchanged.

The first actual source `3be78ad24d2bce348f38a26e289af0f4846c5883` produced38 local O0/O2 attempts:22 complete passes and16 retained failures. Ten additional exact year-crossing cold windows passed without warm replay. The original whole raw archive preserves20,236 members and all actual producer, compiled, native, input, positive, failure and diagnostic roles.

Directed repairs compose the existing pending-date guard for closed implicit Frost dates, reconstruct the exact qualified whole water HeadCalc for closed ordinary dense output, and reflect the original Gardner scalar replication in native metadata. The model8 mixed test input receives only missing literal HA/APAR/OMEGA_K rows from an accepted original donor; the original reader and full zero-day initialization accept it. No physical equation, parameter value, date, native counter or tolerance is corrected.

Seventeen independent couplings proceed to coherent qualification. The two Gardner/Snow head-flux9 contexts retain an actual nonfinite-value numerical failure during Snowmelt. They remain migration gaps. The original full-main positive control also SIGSEGVs for accepted model3, so no original legacy-defect conclusion is made. The separate AGE dryout and active-vapor/thermal head-flux scientific decisions remain unchanged.

Next: persisted O0/O2 feedback on the six repaired safe contexts, unchanged whole-object preservation for earlier successful contexts, then portable scientific qualification and current public admission. No new context is canonically admitted at this checkpoint.
''',encoding='utf8')
paths=[*proposal['files'],*['tests/nomacro_drainage/'+n for n in ['closed_gardner_state_feedback.py','closed_gardner_state_native_controls.py','closed_gardner_state_batch.py','closed_gardner_state_science.py','closed_gardner_state_parent_admission.py','closed_gardner_state_source_contract.py']],
    'docs/science/NOMACRO_CLOSED_GARDNER_STATE12.md',*['integration/f-ci/nomacro-complete01/'+n for n in ['STATUS.json','GAP_MATRIX.json','CLOSED_GARDNER_STATE12_SOURCE_PROPOSAL_V3.json','CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V3.json',raw_name+'.json',*[p['file'] for p in raw['parts']],*names]]]
git('add','--sparse','--',*sorted(set(paths)))
print('STAGED_REVIEWABLE_FUNCTIONAL_REPAIRS_RAW_AND_SCIENCE_OWNERS',len(set(paths)),flush=True)
