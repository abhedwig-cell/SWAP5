"""Retain exact official ZIP bytes and every member identity, without replay."""
from pathlib import Path
import argparse,hashlib,json,zipfile
E=Path(__file__).parent
P=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01')
SHA=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--platform',choices=['UBUNTU','WINDOWS'],required=True);p.add_argument('--opt',choices=['O0','O2'],required=True);p.add_argument('--artifact',type=int,required=True);p.add_argument('--bytes',type=int,required=True);p.add_argument('--sha256',required=True);a=p.parse_args()
name='CLOSED_GARDNER_STATE12_FIRST_'+a.platform+'_'+a.opt+'_ORIGINAL_V1'
path=E/('CLOSED_GARDNER_STATE12_FIRST_'+a.platform+'_'+a.opt+'_OFFICIAL_ARTIFACT_V1.zip')
raw=path.read_bytes();assert len(raw)==a.bytes and SHA(raw)==a.sha256
with zipfile.ZipFile(path) as z:
    names=z.namelist();assert len(names)==len(set(names)) and all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
    members={}
    for n in names:
        value=z.read(n);members[n]=dict(bytes=len(value),sha256=SHA(value))
    q=json.loads(z.read('current/RESULT.json'))
    assert q['actual_source']=='e112e8f7f6f0bd00e4ae9035d00ef53860477448' and q['optimization']==a.opt and q['scope']=='independent' and len(q['contexts'])==17
    assert q['status']=='ALL_SELECTED_CLOSED_GARDNER_LOCAL_CONTEXTS_AND_NATIVE_CONTROLS_PASS_NOT_QUALIFIED'
parts=[]
for i,offset in enumerate(range(0,len(raw),48*1024**2),1):
    value=raw[offset:offset+48*1024**2];file=name+f'.zip.part{i:03d}'
    target=P/file
    if target.exists():assert target.read_bytes()==value
    else:target.write_bytes(value)
    parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
record=dict(status='EXACT_OFFICIAL_PORTABLE_ZIP_PRESERVED_INDEPENDENT_OBSERVER_PENDING_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,
    actual_producer_source=q['actual_source'],actual_workflow_run={'UBUNTU':45991118737,'WINDOWS':45991118752}[a.platform],actual_artifact_id=a.artifact,
    official_size_and_sha256_verified=True,all_original_member_CRCS_and_SHA_verified=True,original_ZIP_bytes_rewritten=False,source_identity_rebound=False,canonical_admission=False)
for root in [E,P]:(root/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(name=name,bytes=len(raw),sha256=SHA(raw),members=len(members))))
