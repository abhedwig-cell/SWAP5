"""Persist the actual bounded execution selection and complete literal source delta."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();parent='105b9a8e6ca9e846f214d69a71afe73ed18be11d'
assert head=='86b9ee6892d202a4b276a1e132536613fb6beafa' and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
proposal=dict(status='ACTUAL_COMPLETE_LITERAL_CLOSED_GARDNER_APP_SOURCE_DELTA_PENDING_QUALIFICATION',actual_source=head,actual_canonical_parent=parent,files={},physical_equations_changed=False,new_physical_state=False,new_numerical_policy=False,canonical_admission=False)
for path in git('diff','--name-only',parent,head,'--','app').decode().splitlines():
    exists=subprocess.run(['git','cat-file','-e',parent+':'+path],cwd=R,capture_output=True).returncode==0
    before=git('show',parent+':'+path) if exists else b'';after=git('show',head+':'+path);ast.parse(after)
    left,right=before.decode(),after.decode();edits=[dict(base_start=i,base_end=j,before=left[i:j],after=right[k:l]) for tag,i,j,k,l in difflib.SequenceMatcher(None,left,right,autojunk=False).get_opcodes() if tag!='equal']
    replay=left
    for item in reversed(edits):
        assert replay[item['base_start']:item['base_end']]==item['before']
        replay=replay[:item['base_start']]+item['after']+replay[item['base_end']:]
    assert replay.encode()==after
    proposal['files'][path]=dict(new_file=not exists,before_lf_sha256=SHA(before),after_lf_sha256=SHA(after),ordered_literal_edits=edits)
(P/'CLOSED_GARDNER_STATE12_SOURCE_PROPOSAL_V2.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf8')
q=json.loads((P/'STATUS.json').read_text());q['closed_gardner_state12'].update(actual_source_checkpoint='d7ffa497fea6326547a7e2c9ddf0e6c4d22db89f',actual_feedback_controller=head,source_proposal='CLOSED_GARDNER_STATE12_SOURCE_PROPOSAL_V2.json',all19_current_public_inputs_accepted=True,public_input_observation='CLOSED_GARDNER_STATE12_ALL_INPUT_PREFLIGHT_V2.json',new_qualified_contexts=0,new_admitted_contexts=0)
q['test_selection']=dict(candidate=head,groups=dict(closed_gardner_state12=dict(changed_dependency='Actual closed zero-boundary existing output/implicit/Frost/Snow owners, original explicit Gardner static native/input domains including paired9;18 actual APP files, complete literal delta in SOURCE_PROPOSAL_V2',scientific_claim='Finite19 affected state couplings on both local O0/O2: unchanged1e-10 independent water/CDE every-prefix ledgers, whole native/exact cold user output, rollback/replay/accept and actual compiled native attacks',owner='nomacro-complete01 closed_gardner_state12',authority='docs/development/workstream-execution-protocol.md#enforced-proportional-execution-2026-10-15',expected_seconds=3000,existing_evidence='Parent canonical880 and full original evidence retained. Two directed35day feedback contexts passed on7a32108; no additional local cohort qualification exists. No original full1096day period selected or replayed.',prior_execution='NONE')))
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for name in ['CLOSED_GARDNER_STATE12_ALL_INPUT_PREFLIGHT_V1.json','CLOSED_GARDNER_STATE12_ALL_INPUT_PREFLIGHT_V2.json','CLOSED_GARDNER_STATE12_CURRENT_READER_FEEDBACK_V2.json','CLOSED_GARDNER_STATE12_CURRENT_READER_FEEDBACK_V3.json']:
    (P/name).write_bytes((E/name).read_bytes())
print('RECORDED_ACTUAL_LOCAL_SELECTION',head,len(proposal['files']),flush=True)
