"""Release finished own first-feedback copies after exact retained Git custody."""
from pathlib import Path
import hashlib,json,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
tool=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py')
task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';prefix='integration/f-ci/nomacro-complete01/'
ref='eb4198bed4ad7480bf2048204a7f368052607e16';name='CLOSED_GARDNER_STATE12_FIRST_LOCAL_SUCCESSES_FAILURES_RAW_V1'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
q=json.loads(git('show',ref+':'+prefix+name+'.json'));sha=hashlib.sha256();size=0
for p in q['parts']:
    raw=git('show',ref+':'+prefix+p['file']);assert len(raw)==p['bytes'] and hashlib.sha256(raw).hexdigest()==p['sha256'];size+=len(raw);sha.update(raw)
assert size==q['bytes'] and sha.hexdigest()==q['sha256']=='8acadb26f64f33f3836719af90341aeaf1de80dae37ab2bebe81be7dcc6aed6b'
report=dict(status='RUNNING',retained_source=ref,retained_archive_sha256=q['sha256'],task_remains_active=True,released=[])
save=lambda:(E/'CLOSED_GARDNER_STATE12_RELEASED_FIRST_FEEDBACK_V1.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
save()
for name in ['closure12-feedback-v1','closure12-feedback-O0-v1','closure12-feedback-O2-v1','closure12-finite-O0-v1','closure12-finite-O2-v1']:
    run=subprocess.run([sys.executable,'-B',str(tool),'release','--task',task,'--path',str(W/name)],capture_output=True,timeout=180)
    if run.returncode:
        report.update(status='RELEASE_REFUSED_NO_BYPASS',error=run.stdout.decode(errors='replace')+run.stderr.decode(errors='replace'));save();raise RuntimeError(report['error'])
    report['released'].append(str(W/name));save();print('RELEASED',name,flush=True)
for apply in [False,True]:
    run=subprocess.run([sys.executable,'-B',str(tool),'cleanup','--task',task,*(['--apply'] if apply else [])],capture_output=True,timeout=600)
    report['apply' if apply else 'preview']=json.loads(run.stdout);report['apply_returncode' if apply else 'preview_returncode']=run.returncode;save()
report['status']='OWN_FINISHED_FEEDBACK_RELEASED_NORMAL_CLEANUP_REPORTED';save()
print(json.dumps({k:report['apply'].get(k) for k in ['free_before','free_after','net_free_change','blocked_count','report_file']},indent=2),flush=True)
