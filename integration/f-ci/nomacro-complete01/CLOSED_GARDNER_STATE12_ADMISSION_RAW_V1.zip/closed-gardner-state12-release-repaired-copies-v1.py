"""Release only exact archived own copies; live providers and original probe remain active."""
from pathlib import Path
import hashlib,json,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='07cb2850e2cd45deb1e197161409a3784a8975e7'
tool=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';P='integration/f-ci/nomacro-complete01/'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
name='CLOSED_GARDNER_STATE12_REPAIRED_LOCAL_AND_POSTIMAGES_RAW_V1';q=json.loads(git('show',C+':'+P+name+'.json'));digest=hashlib.sha256();size=0
for item in q['parts']:
    raw=git('show',C+':'+P+item['file']);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'];digest.update(raw);size+=len(raw)
assert size==q['bytes'] and digest.hexdigest()==q['sha256']=='280f57ca5554a5bcd746fa3cb56460da35c668952b52f64e267d6c7aba6a8089'
ref='refs/heads/codex/storage-retained/closure12-repaired-20261127'
old=subprocess.run(['git','rev-parse','--verify',ref],cwd=R,capture_output=True)
if old.returncode:git('update-ref',ref,C,'0'*40)
else:assert old.stdout.decode().strip()==C
roots=q['actual_resource_roots'];assert len(roots)==7
report=dict(status='VERIFYING_ALL_ACTUAL_OWN_COPY_BYTES_BEFORE_RELEASE',actual_retained_source=C,retained_ref=ref,actual_archive_sha256=q['sha256'],task_remains_active=True,verified=[],released=[])
save=lambda:(E/'CLOSED_GARDNER_STATE12_RELEASED_REPAIRED_COPIES_V1.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
save()
for root in roots:
    folder=W/root;prefix='actual/'+root+'/';seen=set()
    for path in folder.rglob('*'):
        if not path.is_file():continue
        assert not path.is_symlink();member=prefix+path.relative_to(folder).as_posix();item=q['members'][member];raw=path.read_bytes();assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'];seen.add(member)
    expected={m for m in q['members'] if m.startswith(prefix)};assert seen==expected
    report['verified'].append(dict(path=str(folder),files=len(seen),all_actual_bytes_equal_accepted_archive_members=True));save()
for root in roots:
    run=subprocess.run([sys.executable,'-B',str(tool),'release','--task',task,'--path',str(W/root)],capture_output=True,timeout=180)
    if run.returncode:
        report.update(status='RELEASE_REFUSED_NO_BYPASS',error=run.stdout.decode(errors='replace')+run.stderr.decode(errors='replace'));save();raise RuntimeError(report['error'])
    report['released'].append(str(W/root));save();print('RELEASED_EXACT_ARCHIVED_COPY',root,flush=True)
for apply in [False,True]:
    run=subprocess.run([sys.executable,'-B',str(tool),'cleanup','--task',task,*(['--apply'] if apply else [])],capture_output=True,timeout=600)
    report['apply' if apply else 'preview']=json.loads(run.stdout);report['apply_returncode' if apply else 'preview_returncode']=run.returncode;save()
report['status']='SEVEN_EXACT_ACCEPTED_OWN_COPIES_RELEASED_NORMAL_CLEANUP_REPORTED_LIVE_PROVIDERS_PRESERVED';save();print(json.dumps({k:report['apply'].get(k) for k in ['free_before','free_after','net_free_change','blocked_count','report_file']},indent=2))
