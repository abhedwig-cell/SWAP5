"""Review all combined literal edits against the genuine actual merge; no install."""
from pathlib import Path
import ast,hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');M='105b9a8e6ca9e846f214d69a71afe73ed18be11d'
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
names=['CLOSED_GARDNER_STATE12_GARDNER_SOURCE_PROPOSAL_V3.json','CLOSED_GARDNER_STATE12_CLOSED_SOURCE_PROPOSAL_V1.json','CLOSED_GARDNER_STATE12_INITIAL_SOURCE_PROPOSAL_V1.json']
before={};after={};origins={}
for name in names:
    q=json.loads((E/name).read_text(encoding='utf8'))
    for path,item in q['files'].items():
        if item.get('new_file'):
            assert subprocess.run(['git','cat-file','-e',M+':'+path],cwd=R,capture_output=True).returncode!=0
            raw=(E/item['proposed_file']).read_bytes();assert SHA(raw)==item['proposed_lf_sha256']
            before[path]=b'';after[path]=raw;origins[path]=[name];continue
        raw=git('show',M+':'+path);assert SHA(raw)==item['before_lf_sha256']
        own=raw.decode()
        for edit in item['ordered_literal_replacements']:
            assert own.count(edit['before'])==1;own=own.replace(edit['before'],edit['after'],1)
        assert SHA(own.encode())==item['proposed_lf_sha256']
        if path not in after:before[path]=raw;after[path]=raw;origins[path]=[]
        merged=after[path].decode()
        for edit in item['ordered_literal_replacements']:
            assert merged.count(edit['before'])==1,(path,name)
            merged=merged.replace(edit['before'],edit['after'],1)
        after[path]=merged.encode();origins[path].append(name)
files={}
for path,raw in after.items():
    ast.parse(raw);name='CLOSED_GARDNER_STATE12_COMBINED_'+Path(path).name
    with (E/name).open('xb') as stream:stream.write(raw)
    files[path]=dict(actual_before_git_source=M,new_file=not bool(before[path]),before_lf_sha256=SHA(before[path]),proposed_lf_sha256=SHA(raw),combined_file=name,proposals=origins[path])
# Exact native-template anchors are checked without running proposed Python.
for name,kind in [('frost_analytical_native.f90','Frost'),('snow_analytical_native.f90','Snow')]:
    raw=git('show',M+':app/hybrid_water/'+name);text=raw.decode('cp1252')
    assert text.count('    integer::n,ios')==1
    guard="    if(any((iHWCKmodel(1:numlay)>=8).and.(.not.NoVap(1:numlay)))) &\n       error stop 'Active vapor cannot use analytical "+kind+" native'"
    assert text.count(guard)==1
q=dict(status='COMBINED_CLOSED_GARDNER_LITERAL_POSTIMAGES_AND_NATIVE_ANCHORS_REVIEWED_NOT_INSTALLED_OR_QUALIFIED',
    actual_parent=M,files=files,overlapping_file_edits_composed_without_overwriting=True,
    physical_equations_changed=False,new_physical_state=False,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'CLOSED_GARDNER_STATE12_COMBINED_SOURCE_REVIEW_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
print(q['status'],len(files))
