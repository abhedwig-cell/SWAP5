"""Preserve every first-cohort success/failure and actual compiler byte once."""
from pathlib import Path
import hashlib,io,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
HEAD='3be78ad24d2bce348f38a26e289af0f4846c5883';SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
for opt in ['O0','O2']:
    q=json.loads((W/'closure12-feedback-v1'/('finite-'+opt+'-v1')/'RESULT.json').read_text())
    assert q['actual_source']==HEAD and q['status']=='CLOSED_GARDNER_BATCH_FAILURES_RETAINED_NOT_QUALIFIED' and len(q['contexts'])==19
source=git('archive','--format=zip',HEAD,'app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','tests/nomacro_mixtures','tests/saltfarm_newton','.github/workflows')
extra={'source/actual-source.zip':source,'source/actual-source.json':(json.dumps(dict(actual_head=HEAD,actual_tree=git('rev-parse','HEAD^{tree}').decode().strip(),bytes=len(source),sha256=SHA(source)),indent=2)+'\n').encode()}
files={}
resources=['closure12-feedback-v1','closure12-feedback-O0-v1','closure12-feedback-O2-v1','closure12-finite-O0-v1','closure12-finite-O2-v1']
for name in resources:
    root=W/name;assert root.is_dir() and not root.is_symlink()
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():files['actual/'+path.relative_to(W).as_posix()]=path
for path in E.iterdir():
    if not path.is_file():continue
    if path.name.startswith(('closed-gardner-state12-','closed_gardner_state12_')) or path.name.startswith('CLOSED_GARDNER_STATE12_') and path.suffix in ('.json','.py'):
        files['observers-and-proposals/'+path.name]=path
members={name:dict(bytes=path.stat().st_size,sha256=SHA(path.read_bytes())) for name,path in files.items()}
members.update({name:dict(bytes=len(raw),sha256=SHA(raw)) for name,raw in extra.items()})
zipname='CLOSED_GARDNER_STATE12_FIRST_LOCAL_SUCCESSES_FAILURES_RAW_V1.zip';target=E/zipname
assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in files.items():
        raw=path.read_bytes();assert len(raw)==members[name]['bytes'] and SHA(raw)==members[name]['sha256'];z.writestr(name,raw)
    for name,raw in extra.items():z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members) and set(z.namelist())==set(members)
    for name,item in members.items():
        raw=z.read(name);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
for name,path in files.items():assert SHA(path.read_bytes())==members[name]['sha256']
whole=hashlib.sha256();parts=[];limit=96*1024*1024
if target.stat().st_size>limit:
    with target.open('rb') as f:
        index=0
        while raw:=f.read(limit):
            index+=1;name=zipname+f'.part{index:03d}';p=E/name
            with p.open('xb') as out:out.write(raw)
            whole.update(raw);parts.append(dict(file=name,bytes=len(raw),sha256=SHA(raw)))
else:
    raw=target.read_bytes();whole.update(raw);parts=[dict(file=zipname,bytes=len(raw),sha256=SHA(raw))]
q=dict(status='FIRST_LOCAL38_FINITE_CONTEXT_ATTEMPTS_ACTUAL22_COMPLETE_PASSES_AND16_FAILURES_PLUS_ORIGINAL_DIRECTED_FEEDBACK_AND10_YEAR_SEAMS_PRESERVED_NOT_QUALIFIED',
    actual_primary_controller_source=HEAD,actual_canonical_parent='105b9a8e6ca9e846f214d69a71afe73ed18be11d',archive=zipname,bytes=target.stat().st_size,sha256=whole.hexdigest(),parts=parts,members=members,
    actual_resource_roots=resources,original_roles_rebound=False,source_archive_sha256=SHA(source),new_admitted_contexts=0,canonical_admission=False,
    original_paired9_nonfinite_pond_availability_failures_preserved=True,original_missing_model8_HA_input_failures_preserved=True,
    original_ordinary_complete_head_guard_failures_preserved=True,original_scalar_Gardner_native_metadata_failure_preserved=True,
    original_closed_Frost_pending_date_cold_failures_preserved=True,proposed_observers_and_repairs_are_not_installed_controller_source=True)
with (E/'CLOSED_GARDNER_STATE12_FIRST_LOCAL_SUCCESSES_FAILURES_RAW_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
assert git('rev-parse','HEAD').decode().strip()==HEAD
print('SEALED_ACTUAL_FIRST_LOCAL_RAW',q['bytes'],q['sha256'],len(members),'members',len(parts),'parts',flush=True)
