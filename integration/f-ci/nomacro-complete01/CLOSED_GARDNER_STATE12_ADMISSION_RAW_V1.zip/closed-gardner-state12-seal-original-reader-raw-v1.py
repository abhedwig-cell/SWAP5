"""Retain original zero-day observations in protected unique evidence storage."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
D=W/'closure12-original-reader-v1';M='105b9a8e6ca9e846f214d69a71afe73ed18be11d'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==M and D.resolve().parent==W.resolve()
result=json.loads((E/'CLOSED_GARDNER_STATE12_ORIGINAL_INACTIVE_VAPOR_READER_V1.json').read_text(encoding='utf8'))
assert len(result['cases'])==5 and sum(c['original_reader_accepted'] for c in result['cases'])==4
assert result['model_days']==0 and result['compiler_executions']==0 and result['scientific_qualification'] is False
files={}
for path in D.rglob('*'):
    assert not path.is_symlink()
    if path.is_file():files['actual-original-reader-output/'+path.relative_to(D).as_posix()]=path
for name in ['CLOSED_GARDNER_STATE12_ORIGINAL_INACTIVE_VAPOR_READER_V1.json','closed-gardner-state12-original-inactive-vapor-reader-v1.py',Path(__file__).name]:files['controller-and-provenance/'+name]=E/name
assert files
name='CLOSED_GARDNER_STATE12_ORIGINAL_READER_RAW_V1';archive=E/(name+'.zip');members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for member,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members) and set(z.namelist())==set(members)
    for member,item in members.items():
        raw=z.read(member);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and raw==files[member].read_bytes()
raw=archive.read_bytes()
q=dict(status='GENUINE_ORIGINAL_ZERO_DAY_ELIGIBILITY_RAW_PRESERVED_IN_PROTECTED_EVIDENCE_NOT_SCIENTIFIC_QUALIFICATION',
    archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members=members,
    actual_preservation_observer=M,actual_original_controller=result['actual_controller'],
    actual_original_driver_source=result['original_driver_source'],actual_input_producer=result['actual_input_producer'],
    original_producer_paths_preserved=True,original_output_root=str(D),
    original_probe_recovery=dict(git_source=result['actual_input_archive_git_source'],archive='FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1',
      archive_sha256=result['original_probe_accepted_archive_sha256'],member='phase-driver/corrected-module-import-v2/original_initialization_probe.exe',sha256=result['original_probe_exe_sha256']),
    original_reader_accepts=4,original_non1_hysteresis_refusals=1,current_public_guard_refusals=5,
    scientific_qualification=False,canonical_admission=False,model_days=0,compiler_executions=0,
    registered_debug_root_now_secondary_exact_duplicate_only=True,delete_or_release_performed=False)
with (E/(name+'.json')).open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
assert git('rev-parse','HEAD').decode().strip()==M
print(q['status'],len(raw),q['sha256'],len(members))
