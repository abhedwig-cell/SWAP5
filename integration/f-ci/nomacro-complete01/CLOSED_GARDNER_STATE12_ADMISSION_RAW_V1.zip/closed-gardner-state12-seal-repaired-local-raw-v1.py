"""Seal immutable completed local results; moving observer HEAD is recorded, never projected."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,stat,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
SOURCE='d143437f4d9d855f03c036a9db1b8a3f86ec63ef';SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
observer_start=git('rev-parse','HEAD').decode().strip()
observations=[]
for opt in ['O0','O2']:
    base=W/'closure12-directed-v2';q=json.loads((base/opt/'RESULT.json').read_text())
    assert q['actual_source']==SOURCE and q['status']=='ALL_SELECTED_CLOSED_GARDNER_LOCAL_CONTEXTS_AND_NATIVE_CONTROLS_PASS_NOT_QUALIFIED' and len(q['contexts'])==6
    observations.append(dict(kind='directed-feedback',optimization=opt,contexts=6))
    for kind,count,key in [('current',12,'actual_current_compiler_source'),('parent',8,'actual_compiler_source')]:
        q=json.loads((base/('preservation-'+opt)/kind/'RESULT.json').read_text())
        assert q[key]==SOURCE and len(q['contexts'])==count and q['model_executions']==q['model_days']==0 and not q['status'].startswith(('RUNNING','FAILED'))
        observations.append(dict(kind='whole-object-'+kind,optimization=opt,contexts=count,whole_objects=sum(len(v['whole_objects']) for v in q['contexts'])))
resources=['closure12-directed-v2','closure12-directed-O0-v2','closure12-directed-O2-v2','closure12-preservation-O0-v1','closure12-preservation-O2-v1','closure12-original-causal-v1','closure12-original-causal-O0-v1']
files={};initial_stats={}
def scan(root):
    pending=[root]
    while pending:
        current=pending.pop()
        with os.scandir(current) as entries:
            for entry in entries:
                info=entry.stat(follow_symlinks=False)
                assert not getattr(info,'st_file_attributes',0)&0x400,'Reparse point is not archive authority: '+entry.path
                if stat.S_ISDIR(info.st_mode):pending.append(Path(entry.path))
                elif stat.S_ISREG(info.st_mode):yield Path(entry.path),info
                else:raise ValueError('Nonregular proof member: '+entry.path)
for name in resources:
    root=W/name;assert root.is_dir() and not root.is_symlink()
    for path,info in scan(root):
        key='actual/'+path.relative_to(W).as_posix();files[key]=path;initial_stats[key]=(info.st_size,info.st_mtime_ns)
for path in E.iterdir():
    if path.is_file() and path.name.startswith(('CLOSED_GARDNER_STATE12_','closed-gardner-state12-','closed_gardner_state12_')) and path.suffix in ('.json','.py','.yml'):
        key='controllers-and-observations/'+path.name;files[key]=path;info=path.stat();initial_stats[key]=(info.st_size,info.st_mtime_ns)
source=git('archive','--format=zip',SOURCE,'app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','tests/nomacro_mixtures','tests/saltfarm_newton','.github/workflows')
extra={'source/actual-scientific-controller-source.zip':source,'source/IDENTITY.json':(json.dumps(dict(actual_scientific_producer=SOURCE,actual_whole_tree=git('rev-parse',SOURCE+'^{tree}').decode().strip(),bytes=len(source),sha256=SHA(source)),indent=2)+'\n').encode()}
name='CLOSED_GARDNER_STATE12_REPAIRED_LOCAL_AND_POSTIMAGES_RAW_V1.zip';target=E/name;assert not target.exists();members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for index,key in enumerate(sorted(files),1):
        path=files[key];raw=path.read_bytes();info=path.stat();assert (len(raw),info.st_mtime_ns)==initial_stats[key]
        members[key]=dict(bytes=len(raw),sha256=SHA(raw));z.writestr(key,raw)
        if index%2000==0:print('PRESERVED_MEMBERS',index,'OF',len(files),flush=True)
    for key,raw in extra.items():members[key]=dict(bytes=len(raw),sha256=SHA(raw));z.writestr(key,raw)
with zipfile.ZipFile(target) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(members) and set(z.namelist())==set(members)
    # Reading every member checks its CRC as well as the independent SHA/size.
    for key,item in members.items():
        raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
def unchanged(item):
    key,path=item;raw=path.read_bytes();info=path.stat()
    assert (len(raw),info.st_mtime_ns)==initial_stats[key] and SHA(raw)==members[key]['sha256']
with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(unchanged,files.items()))
whole=hashlib.sha256();parts=[];limit=48*1024*1024
if target.stat().st_size>limit:
    with target.open('rb') as stream:
        index=0
        while raw:=stream.read(limit):
            index+=1;part=E/(name+f'.part{index:03d}')
            with part.open('xb') as out:out.write(raw)
            whole.update(raw);parts.append(dict(file=part.name,bytes=len(raw),sha256=SHA(raw)))
else:
    raw=target.read_bytes();whole.update(raw);parts=[dict(file=name,bytes=len(raw),sha256=SHA(raw))]
q=dict(status='ACTUAL12_REPAIRED_LOCAL_CONTEXTS_40_CURRENT_WHOLE_OBJECT_BUILDS_AND_ORIGINAL_CAUSAL_OBSERVATIONS_PRESERVED_NOT_ADMITTED',actual_scientific_producer_source=SOURCE,
    actual_preservation_observer_head_start=observer_start,actual_preservation_observer_head_end=git('rev-parse','HEAD').decode().strip(),
    archive=name,bytes=target.stat().st_size,sha256=whole.hexdigest(),parts=parts,members=members,observations=observations,actual_resource_roots=resources,
    current_public_preservation_build_contexts=40,old_warm_model_periods_replayed=0,individual_compiler_invocations='UNKNOWN',
    all_member_CRCS_SHA_and_final_local_bytes_checked=True,original_source_or_observer_identities_rebound=False,new_admitted_contexts=0,canonical_admission=False,
    original_full_main_SIGSEGV_positive_control_failures_are_not_Gardner_legacy_defect_evidence=True,
    first_cohort_successes_and_failures_already_retained_once_in_Git='eb4198bed4ad7480bf2048204a7f368052607e16:integration/f-ci/nomacro-complete01/CLOSED_GARDNER_STATE12_FIRST_LOCAL_SUCCESSES_FAILURES_RAW_V1.json')
with (E/'CLOSED_GARDNER_STATE12_REPAIRED_LOCAL_AND_POSTIMAGES_RAW_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print('SEALED_ACTUAL_REPAIRED_LOCAL_RAW',q['bytes'],q['sha256'],len(members),len(parts),flush=True)
