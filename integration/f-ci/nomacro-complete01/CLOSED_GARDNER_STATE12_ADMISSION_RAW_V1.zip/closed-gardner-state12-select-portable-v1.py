"""Version the portable decision after the workflow/source checkpoint, before pushing."""
from pathlib import Path
import json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);head=git('rev-parse','HEAD').decode().strip()
assert head=='3241c70a2b9e3a50ca5287dc05afc778d6f819ff' and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=json.loads((P/'STATUS.json').read_text());plan=json.loads((P/'CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V3.json').read_text())
assert len(plan['independent_qualification_cases'])==17 and len(plan['deferred_numerical_cases'])==2
q['test_selection']=dict(candidate=head,groups=dict(closed_gardner_portable=dict(
    changed_dependency='Actual19-file closed-boundary/Gardner APP composition already passed directed local O0/O2 physical/native/cold/refusal feedback and40 prior generated/whole-object preservation contexts; new portable workflows own the17 independent coupling cases',
    scientific_claim='Seventeen original input coupling contexts on each Windows/Ubuntu O0/O2 producer: full35day trajectories, independent1e-10water/CDE every-prefix ledgers, exact whole native/user-output cold windows, real year seams, active original Frost/Snow, transactions and compiled invalid-domain startup refusals',
    owner='nomacro-complete01 closed_gardner_state12',authority='docs/development/workstream-execution-protocol.md#enforced-proportional-execution-2026-10-15',expected_seconds=2400,
    existing_evidence='Local scientific producer d143437f4d:12 repaired contexts420primarydays84native44cold172compiled refusals;40 prior current build contexts1046whole objects byte-identical, zero old warm replay. First38 earlier attempts and both Snow9 numerical failures remain immutable in Git. No portable batch12 qualification exists.',
    prior_execution='NONE',cases=plan['independent_qualification_cases'],deferred_numerical_cases=[v['case'] for v in plan['deferred_numerical_cases']],
    planned_platform_profile_contexts=68,planned_primary_days_if_all_pass=2380,old_warm_model_periods_selected=False)))
q['closed_gardner_state12']['portable_workflow_source_checkpoint']=head
q['closed_gardner_state12']['portable_qualification_status']='SELECTED_BEFORE_PUSH_NOT_EXECUTED_NOT_QUALIFIED'
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print('SELECTED_ACTUAL_PORTABLE17_FOUR_PLATFORM_PROFILE_CONTEXTS_NOT_QUALIFIED',head,flush=True)
