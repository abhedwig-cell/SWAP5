"""Bind the next measured feedback to the actually persisted repaired source."""
from pathlib import Path
import json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).parent
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);head=git('rev-parse','HEAD').decode().strip()
assert head=='eb4198bed4ad7480bf2048204a7f368052607e16' and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=json.loads((P/'STATUS.json').read_text());cases=['closed-frost-implicit-h2-water-dates','closed-ordinary-implicit-h0-water-profile','closed-ordinary-implicit-h1-cde','closed-ordinary-implicit-h2-water','gardner-snow-explicit-d0-b5-water','gardner-mixed2-8-frost-explicit-inactive-vapor-slot']
common=dict(owner='nomacro-complete01 closed_gardner_state12',authority='docs/development/workstream-execution-protocol.md#enforced-proportional-execution-2026-10-15')
groups={
 'closed_gardner_repaired_feedback':dict(**common,changed_dependency='Persisted closed6 ordinary source inverse, original pending-date guard selection, Gardner scalar native descriptor, literal original model8 parameter input completion and year-cold controls',
     scientific_claim='Six repaired safe contexts O0/O2: actual35days, independent1e-10water/CDE every-prefix balances, exact full native/cold/original output, year seams, transactions and compiled malformed-domain refusals',
     expected_seconds=1200,existing_evidence='Original first38 attempts retained exactly in Git eb4198bed4,22 complete passes16failures. Six new actual positive whole-source interfaces and six tolerance-source mutants refuse; original repaired mixed2/8 zero-day initialization accepts. New compiled coupling evidence is still required.',prior_execution='FAILED',
     diagnosis='Correct only measured guard/composition and missing-original-input causes. The two separately preserved Snow9 nonfinite numerical defects are excluded from this independent feedback scope and remain migration gaps.',cases=cases),
 'closed_gardner_postimages':dict(**common,changed_dependency='Nineteen current APP source/selection/native/input owners; preserve nonselected original implicit analytical, default Mualem and explicit/implicit Frost/hysteresis/drainage/native paths',
     scientific_claim='Actual current public O0/O2 generated source and WHOLE compiler object bytes remain identical to original immutable parent/provider artifacts for the existing12+8 context selections; no old warm model period replay',
     expected_seconds=1500,existing_evidence='Original canonical880 postimages and accepted source/SDK/compiler objects are retained in Git. The new19-file current selection surface has not yet been rebuilt against those baselines.',prior_execution='NONE')}
q['test_selection']=dict(candidate=head,groups=groups)
q['closed_gardner_state12'].update(actual_repaired_source=head,current_source_contract_observation='CLOSED_GARDNER_STATE12_ACTUAL_REPAIRED_SOURCE_CONTRACT_V1.json',
    actual_original_first_raw_Git_byte_custody=True,actual_six_qualified_parent_source_positive_controls=True,actual_six_changed_tolerance_source_refusals=True,qualified_contexts=0,new_admitted_contexts=0)
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print('SELECTED_ACTUAL_REPAIRED_FEEDBACK_AND_WHOLE_OBJECT_PRESERVATION',head,flush=True)
