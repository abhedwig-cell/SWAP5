"""Real source/native production interfaces on the explicit uncommitted repair tree."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage')]
from closed_gardner_state_feedback import m,SHA
from ordinary_pond_source_guard import validate as guard
from snow_undrained import selection
from snow_undrained_state import validate_native
from frost_implicit_plate_calendar import selected,source,original_source
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='3be78ad24d2bce348f38a26e289af0f4846c5883'
dirty=git('status','--porcelain=v1','--untracked-files=all').decode();assert dirty
q=dict(status='RUNNING_REAL_WORKING_REPAIR_INTERFACES_NOT_QUALIFIED',actual_git_base=head,actual_uncommitted_status=dirty,
    actual_changed_working_files={p:SHA((R/p).read_bytes()) for p in git('diff','--name-only').decode().splitlines()},
    compiler_executions=0,model_executions=0,canonical_admission=False,ordinary=[],Gardner=[],pending_dates=[])
for opt in ['O0','O2']:
    root=W/'closure12-feedback-v1'/('finite-'+opt+'-v1')
    for name in ['closed-ordinary-implicit-h0-water-profile','closed-ordinary-implicit-h1-cde','closed-ordinary-implicit-h2-water']:
        old=json.loads((root/name/'RESULT.json').read_text());build=Path(old['build_root']);meta=json.loads((build/'BUILD.json').read_text())
        project=m.e.load(old['input_root'],original_output=True,time_step_policy=old['time_step_policy']);guard(build,project,meta['identity'])
        q['ordinary'].append(dict(case=name,optimization=opt,actual_original_compiler_source=old['actual_source'],complete_qualified_parent_source_guard_pass=True))
    name='gardner-snow-explicit-d0-b5-water';old=json.loads((root/name/'RESULT.json').read_text());project=m.e.load(old['input_root'],original_output=True,time_step_policy=old['time_step_policy']);item=selection(project)
    assert item['analytical_snow_models']==[2,2]
    with zipfile.ZipFile(root/name/'trajectory/accepted-column-1-day-4.zip') as z:raw=z.read('macro.bin')
    validate_native(raw,item,project.nodes);q['Gardner'].append(dict(optimization=opt,actual_original_compiler_source=old['actual_source'],actual_original_native_sha256=SHA(raw),true_replication=[2,2],actual_typed_native_accepted=True))
    name='closed-frost-implicit-h2-water-dates';old=json.loads((root/name/'RESULT.json').read_text());project=m.e.load(old['input_root'],original_output=True,time_step_policy=old['time_step_policy']);assert selected(project)
    before=(Path(old['build_root'])/'integral.f90').read_text(encoding='cp1252');after=source(before);assert original_source(after)==before
    q['pending_dates'].append(dict(optimization=opt,actual_original_compiler_source=old['actual_source'],whole_old_integral_lf_sha256=SHA(before.encode('cp1252')),whole_proposed_integral_lf_sha256=SHA(after.encode('cp1252')),complete_literal_existing_pending_date_guard_inverse_pass=True))
q['status']='REAL_UNCOMMITTED_SIX_WHOLE_SOURCE_GUARDS_TWO_GARDNER_TYPED_NATIVE_AND_TWO_PENDING_GUARD_INVERSES_PASS_NO_QUALIFICATION'
(E/'CLOSED_GARDNER_STATE12_WORKING_REPAIR_FEEDBACK_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(q['status'],flush=True)
