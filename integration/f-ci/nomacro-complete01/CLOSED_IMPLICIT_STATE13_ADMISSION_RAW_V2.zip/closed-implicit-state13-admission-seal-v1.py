"""Seal the actual signed canonical1004 admission after every observed gate passes."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');p=argparse.ArgumentParser();p.add_argument('--merge',required=True);args=p.parse_args();M=args.merge
B='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';C='2d810e6db3acf6eb81ff96dae90859670eae9b3a';S='c1eb28258a92b231748645a384c032c818c671d6';A='423291a89b68b7660d7af9aa1530941efba501fb';TREE='202bb30e809e46770b591bb56ce94866dbdffbfb'
git=lambda *v:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*v],cwd=R);SHA=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda name:json.loads((E/name).read_text(encoding='utf8'))
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
for sha in [C,S,M]:assert git('rev-parse',sha+'^{tree}').decode().strip()==TREE
for sha,role in [(S,'SYNTHETIC'),(M,'ACTUAL_MERGE')]:
    assert git('show','-s','--format=%P',sha).decode().split()==[B,C]
    raw=(E/('CLOSED_IMPLICIT_STATE13_PR1812_GENUINE_GIT_OBJECT_'+sha+'.bin')).read_bytes();assert raw==git('cat-file','commit',sha) and hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha
    api=read('CLOSED_IMPLICIT_STATE13_PR1812_FINAL_'+role+'_GIT_API_V1.json');assert api['sha']==sha and api['verification']['verified'] and api['verification']['reason']=='valid'
observations={};fixtures=None;sparse=None;coadmission=None
for role,head,scope,version in [('CANDIDATE',C,'PUBLIC','V2'),('CANDIDATE',C,'PUBLICATION','V2'),('ACTUAL_MERGE',M,'PUBLIC','V1'),('ACTUAL_MERGE',M,'PUBLICATION','V1')]:
    stem='CLOSED_IMPLICIT_STATE13_'+role+'_'+scope+'_'+version;q=read(stem+'.json');raw=(E/(stem+'.stdout.txt')).read_bytes()
    assert q['returncode']==0 and q.get('error') is None and q['before']==q['after'] and not q['before']['status'] and not (E/(stem+'.stderr.txt')).read_bytes()
    before=q['before'];assert before['head']==head and before['tree']==TREE and len(before['sparse'])==14 and len(before['original_project_files'])==56
    if fixtures is None:fixtures=before['original_project_files'];sparse=before['sparse']
    assert fixtures==before['original_project_files'] and sparse==before['sparse']
    if scope=='PUBLIC':
        actual=json.loads(raw);assert actual['coadmission']['contexts']==1004 and len(actual['new_original_portable_science'])==4 and actual['new_numerical_policy'] is True and not actual['physical_equations_changed'] and not actual['new_physical_state']
        assert actual['compiler_executions']==actual['model_executions']==0 and len(actual['deferred_numerical_cases'])==2 and actual['current_finite_batch_deferred_numerical_cases']==[] and not actual['additional_local_contexts_counted_again'] and not actual['unchanged_periods_replayed'] and not actual['original_scientific_producers_rebound']
        assert tuple(sum(v[key] for v in actual['new_original_portable_science']) for key in ['context_count','primary_days','native_samples','exact_cold_windows','compiled_native_refusals','external_transaction_contexts'])==(56,1960,392,176,1608,56)
        assert actual['additional_actual_local_science']['context_count']==4 and actual['actual_old_numerical_and_native_preservation']['counts']==dict(contexts=40,whole_objects=1046,unchanged_whole_objects=1022,changed_static_guard_objects=24,compiled_native_positive_controls=24,compiled_native_refusals=480,old_model_days_replayed=0)
        assert actual['functional_completion']=='PARTIAL' and actual['whole_scientific_equivalence']=='NOT_QUALIFIED' and actual['global_family_and_gap_counts']=='UNKNOWN' and actual['RC3_changed'] is False
        if coadmission is None:coadmission=actual['coadmission']
        assert coadmission==actual['coadmission']
    else:assert b'PUBLICATION_REPLAY_SELECTED=false' in raw and q['ordinary_python_default_dont_write_bytecode'] is False and q['child_bytecode_environment_variables_absent'] is True
    observations[stem]=dict(actual_head=head,seconds=q['seconds'],stdout_bytes=len(raw),stdout_sha256=SHA(raw))
assert tuple(coadmission[key] for key in ['contexts','short35_contexts','native_calendar_samples','exact_cold_windows'])==(1004,910,6674,2936)
negative=read('CLOSED_IMPLICIT_STATE13_FINAL1_NEGATIVES_V3.json');assert negative['candidate']==C and negative['never_merge'] and negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED' and len(negative['controls'])==4
for item in negative['controls']:
    assert item['actual_refusal'] and item['actual_one_file_delta'] and git('show','-s','--format=%P',item['head']).decode().split()==[C] and git('diff','--name-only',C,item['head']).decode().strip()==item['path']
    q=read(item['actual_observation']+'.json');assert q['returncode'] not in [None,0] and q['before']==q['after'] and q['before']['head']==item['head'] and q['before']['original_project_files']==fixtures
assert negative['controls'][-1]['actual_publication_replay_selected']
custody=read('CLOSED_IMPLICIT_STATE13_FINAL1_NEGATIVE_GIT_CUSTODY_V1.json');assert len(custody['controls'])==4
mini=read('CLOSED_IMPLICIT_STATE13_ACTUAL_NEGATIVE_GENUINE_GIT_OBJECTS_V1.json');assert mini['candidate']==C and mini['candidate_tree']==TREE and mini['sha256']=='e83038ea285360961ad803ed24cedd1fcb1bf9bd46bed4ccedd2c7129277a27b'
for phase in ['PREMERGE','POSTMERGE']:
    prefix='CLOSED_IMPLICIT_STATE13_PR1812_'+phase;runs=read(prefix+'_ALL_CI_ORIGINAL_API_V1.json');checks=read(prefix+'_ALL_CHECKS_ORIGINAL_API_V1.json')
    assert runs['total_count']==len(runs['workflow_runs'])==14 and all(v['head_sha']==C and v['status']=='completed' and v['conclusion']=='success' for v in runs['workflow_runs'])
    assert checks['total_count']==len(checks['check_runs'])==45 and all(v['head_sha']==C and v['status']=='completed' and v['conclusion'] in ['success','skipped'] for v in checks['check_runs']) and sum(v['conclusion']=='success' for v in checks['check_runs'])==28 and sum(v['conclusion']=='skipped' for v in checks['check_runs'])==17
    pr=read(prefix+'_ORIGINAL_API_V1.json');assert pr['head']['sha']==C and pr['base']['ref']=='integration/f-ci-canonical' and pr['merged']==(phase=='POSTMERGE')
    assert read(prefix+'_CANONICAL_REF_ORIGINAL_API_V1.json')['object']['sha']==(M if phase=='POSTMERGE' else B)
final=read('CLOSED_IMPLICIT_STATE13_PR1812_FINAL_HEAD_ORIGINAL_LOG_CUSTODY_V1.json');assert final['status']=='ALL_FOURTEEN_TERMINAL_PR_RUN_LOGS_RETAINED' and len(final['runs'])==14 and len(final['jobs'])==28 and len(final['skipped_jobs'])==17
canonical=read('CLOSED_IMPLICIT_STATE13_ACTUAL_MERGE_ALL_CI_ORIGINAL_API_V1.json');assert canonical['total_count']==len(canonical['workflow_runs'])==4 and all(v['head_sha']==M and v['status']=='completed' and v['conclusion']=='success' for v in canonical['workflow_runs'])
canon=read('CLOSED_IMPLICIT_STATE13_ACTUAL_MERGE_ORIGINAL_LOG_CUSTODY_V1.json');assert canon['status']=='ALL_FOUR_TERMINAL_CANONICAL_RUN_LOGS_RETAINED' and canon['actual_verified_merge']==M and len(canon['runs'])==4 and len(canon['jobs'])==5
logs=[]
for role,report,head,prefix in [('PR_FINAL',final,C,'CLOSED_IMPLICIT_STATE13_PR1812_FINAL_HEAD'),('ACTUAL_MERGE',canon,M,'CLOSED_IMPLICIT_STATE13_ACTUAL_MERGE')]:
    for item in report['jobs']:
        raw=(E/item['original_log']).read_bytes();raw.decode('utf8',errors='strict');assert item['actual_source']==head and item['conclusion']=='success' and len(raw)==item['bytes'] and SHA(raw)==item['sha256']
        stem=prefix+'_JOB_'+str(item['job_id']);job=read(stem+'_ORIGINAL_API_V1.json');run=read(stem+'_RUN_ORIGINAL_API_V1.json');assert job['head_sha']==run['head_sha']==head and job['run_id']==run['id'] and job['conclusion']==run['conclusion']=='success' and run['event']==('push' if role=='ACTUAL_MERGE' else 'pull_request')
        if item['name']=='modular-feedback':assert item['signed_checkout_printed'] and b'"contexts": 1004' in raw
        logs.append(dict(role=role,**item))
assert len(logs)==33
first=read('CLOSED_IMPLICIT_STATE13_PR1812_FIRST_HEAD_ORIGINAL_LOG_CUSTODY_V1.json');assert first['actual_candidate']=='aa43c6d21479ab1f5564d19f7d191445dabfe527' and len(first['runs'])==14 and len(first['jobs'])==28 and sum(v['conclusion']=='failure' for v in first['jobs'])==1
failed=next(v for v in first['jobs'] if v['conclusion']=='failure');assert b'deferred_numerical_cases' in (E/failed['original_log']).read_bytes()
mcsol=read('CLOSED_IMPLICIT_STATE13_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json');assert mcsol['actual_parent']==B and mcsol['actual_candidate']==C and mcsol['unchanged_tracked_files']==1063 and not git('diff',B,M,'--',*mcsol['unchanged_dependency_paths'])
stem='CLOSED_IMPLICIT_STATE13_ADMISSION_RAW_V1';archive=E/(stem+'.zip');assert not archive.exists();files={}
for path in E.iterdir():
    if not path.is_file() or path.name.startswith(stem) or path.suffix in ['.zip','.tar','.gz','.xz'] or '.zip.part' in path.name:continue
    if path.name.startswith(('CLOSED_IMPLICIT_STATE13_','closed-implicit-state13-','closed_implicit_state')):files[path.name]=path
files['CLOSED_IMPLICIT_STATE13_ACTUAL_NEGATIVE_GENUINE_GIT_OBJECTS_V1.zip']=E/'CLOSED_IMPLICIT_STATE13_ACTUAL_NEGATIVE_GENUINE_GIT_OBJECTS_V1.zip';members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(name,raw);members[name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for name,item in members.items():raw=z.read(name);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and raw==files[name].read_bytes()
raw=archive.read_bytes();assert len(raw)<48*1024**2
common=dict(canonical_admission=True,actual_merge=M,qualified_candidate=C,source_anchor=A,whole_tree=TREE,coadmission=coadmission,new_scientific_contexts=56,actual_primary_portable_producer='62cf6eefb110099ab1c181b06f2a5ae74b48f144',actual_additional_local_producer='ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30',additional_four_local_contexts_counted_again=False,whole_object_contexts=40,whole_objects=1046,unchanged_whole_objects=1022,changed_static_native_guard_objects=24,original_native_positive_controls=24,original_native_compiled_refusals=480,two_inherited_explicit_Gardner_Snow9_numerical_cases_remain_functional_gaps=True,current_finite_batch_deferred_numerical_cases=0,original_full_period_reference_causality='UNKNOWN_INITIALIZATION_CSV_CONTROL_DOES_NOT_ESTABLISH_FULL_PERIOD_CAUSALITY',producer_roles_rebound=False,new_numerical_policy=True,numerical_policy='original-closed-implicit-residual-start-and-conditional-convergence-v3',physical_equations_changed=False,new_physical_state=False,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
descriptor=dict(status='ACTUAL_CANONICAL1004_SIGNED_SOURCE_PUBLIC_ORDINARY_PUBLICATION_14CI_FOUR_REAL_NEGATIVES_AND33_ORIGINAL_LOGS_PRESERVED',archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members=members,actual_public_observations=observations,successful_PR_workflows=14,successful_PR_checks=28,skipped_PR_checks=17,canonical_push_workflows_success=4,original_final_successful_CI_log_roles=logs,first_failed_public_and_first_CI_scope_assertion_roles_preserved=True,admission_controller=Path(__file__).name,admission_controller_sha256=SHA(Path(__file__).read_bytes()),**common)
receipt=dict(status='ACTUAL_CANONICAL1004_CLOSED_IMPLICIT_STATE_ADMISSION_VERIFIED',PR=1812,previous_canonical=B,ordered_parents=[B,C],synthetic_merge=S,admission_archive_sha256=SHA(raw),**common)
for name,q in [(stem+'.json',descriptor),('CLOSED_IMPLICIT_STATE13_MERGE_RECEIPT_V1.json',receipt)]:assert not (E/name).exists();(E/name).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(descriptor['status'],len(raw),descriptor['sha256'],len(members),flush=True)
