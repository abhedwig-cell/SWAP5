         else if(imod>=3.and.imod<=11)then
            block
              use WC_K_models_04_11,only:NoVap
              real(8)::alpha(2),nn(2),mm(2),weight(2),gm(2),gm0(2),uu(2),uu0(2),dgm(2)
              real(8)::xx,sc,dsc,aa,daa,den,sc_i,dsc_i,ll,cap_dk,film,film_dk
              real(8)::ha0,h00,apar0,omega_k0,xa0,x00,xh0,bb0,nb0,sad0,zlog,logistic,sad_dh
              integer::modes,mode
              logical::scaled,pdi
              if(head>=0d0.or.(imod==3.and.theta>=cofgen(2,node)))then
                 dhconduc=0d0
                 return
              end if
              modes=1
              if(any(imod==[3,6,7,10,11]))modes=2
              scaled=any(imod==[5,7,9,11]);pdi=imod>=8
              alpha(1)=cofgen(4,node);nn(1)=cofgen(6,node);mm(1)=cofgen(7,node)
              weight(1)=1d0
              if(modes==2)then
                 alpha(2)=cofgen(13,node);nn(2)=cofgen(14,node);mm(2)=cofgen(15,node)
                 weight(1)=cofgen(16,node);weight(2)=cofgen(17,node)
                 if(imod==3)weight(2)=1d0-weight(1)
              end if
              ll=cofgen(5,node);sc=0d0;dsc=0d0
              do mode=1,modes
                 xx=abs(alpha(mode)*head)**nn(mode)
                 gm(mode)=(1d0+xx)**(-mm(mode))
                 uu(mode)=xx/(1d0+xx)
                 dgm(mode)=mm(mode)*nn(mode)*gm(mode)*uu(mode)/abs(head)
                 if(scaled)then
                    gm0(mode)=(1d0+abs(alpha(mode)*cofgen(18,node))**nn(mode))**(-mm(mode))
                    uu0(mode)=1d0-gm0(mode)**(1d0/mm(mode))
                    sc_i=(gm(mode)-gm0(mode))/(1d0-gm0(mode))
                    dsc_i=dgm(mode)/(1d0-gm0(mode))
                 else
                    uu0(mode)=1d0
                    sc_i=gm(mode);dsc_i=dgm(mode)
                 end if
                 sc=sc+weight(mode)*sc_i
                 dsc=dsc+weight(mode)*dsc_i
              end do
              if(modes==1)then
                 den=uu0(1)
                 aa=1d0-(uu(1)/den)**mm(1)
                 daa=(uu(1)/den)**(mm(1)-1d0)*gm(1)**(1d0/mm(1)-1d0)*dgm(1)/den
              else
                 den=sum(weight(1:2)*alpha(1:2)*uu0(1:2)**mm(1:2))
                 aa=1d0-sum(weight(1:2)*alpha(1:2)*uu(1:2)**mm(1:2))/den
                 daa=sum(weight(1:2)*alpha(1:2)*uu(1:2)**(mm(1:2)-1d0)* &
                     gm(1:2)**(1d0/mm(1:2)-1d0)*dgm(1:2))/den
              end if
              cap_dk=ll*sc**(ll-1d0)*dsc*aa**2+2d0*sc**ll*aa*daa
              if(pdi)then
                 if(.not.NoVap(layer(node)))error stop 'Active vapor outside closed implicit capillary derivative'
                 h00=cofgen(18,node);ha0=cofgen(19,node);apar0=cofgen(20,node);omega_k0=cofgen(21,node)
                 xa0=log10(ha0);x00=log10(h00);xh0=log10(abs(head));nb0=nn(1)
                 if(modes==2.and.alpha(2)>alpha(1))nb0=nn(2)
                 bb0=0.1d0+0.2d0/nb0**2*(1d0-exp(-((cofgen(1,node)/(cofgen(2,node)-cofgen(1,node)))**2)))
                 zlog=(xa0-xh0)/bb0
                 sad0=1d0+(xh0-xa0+bb0*log(1d0+exp(zlog)))/(xa0-x00)
                 if(zlog>0d0)then
                    logistic=exp(-zlog)/(1d0+exp(-zlog))
                 else
                    logistic=1d0/(1d0+exp(zlog))
                 end if
                 sad_dh=-logistic/(abs(head)*log(10d0)*(xa0-x00))
                 film=(h00/ha0)**(apar0*(1d0-sad0))
                 film_dk=-apar0*log(h00/ha0)*film*sad_dh
                 dhconduc=cofgen(3,node)*((1d0-omega_k0)*cap_dk+omega_k0*film_dk)
              else
                 dhconduc=cofgen(3,node)*cap_dk
              end if
              if(swfrost==1)dhconduc=dhconduc*rfcp
              return
            end block
