from pathlib import Path
import json,subprocess,sys
E=Path(__file__).parent;W=E.parent;TOOL=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
q=json.loads((E/'CLOSED_IMPLICIT_STATE13_NATIVE_PRESERVATION_RESOURCE_RELEASE_V2.json').read_text());eligible=[v for v in q['preview']['results'] if v['status'].startswith('eligible')]
assert len(eligible)==2 and {Path(v['path']).name for v in eligible}=={'closure13-native-preservation-O0-v1','closure13-native-preservation-O2-v1'}
for row in eligible:
    path=Path(row['path']);assert path.resolve().parent==W.resolve() and path.is_dir() and not list(path.iterdir())
child=subprocess.run([sys.executable,'-B',str(TOOL),'cleanup','--apply','--task',task],cwd=TOOL.parents[2],capture_output=True,text=True,timeout=180);record=dict(status='SHARED_CLEANUP_SUPERSEDED_EMPTY_NATIVE_BUILD_APPLY_RETURNED',task=task,task_remains_active=True,preview=eligible,returncode=child.returncode,stdout=child.stdout,stderr=child.stderr);target=E/'CLOSED_IMPLICIT_STATE13_SUPERSEDED_EMPTY_BUILD_CLEANUP_V1.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');child.check_returncode();result=json.loads(child.stdout);print(record['status'],[(Path(v['path']).name,v['status']) for v in result['results'] if Path(v['path']).name in {Path(x['path']).name for x in eligible}],result['net_free_change'],flush=True)
