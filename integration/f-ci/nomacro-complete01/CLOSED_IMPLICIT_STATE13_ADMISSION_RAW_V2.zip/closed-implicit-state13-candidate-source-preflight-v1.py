from pathlib import Path
import json,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from closed_implicit_state_verify import SEALED
from closed_implicit_state_source_custody import source
q=source(SEALED);target=E/'CLOSED_IMPLICIT_STATE13_CANDIDATE_COMPLETE_SOURCE_PREFLIGHT_V1.json';assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],q['actual_head'],len(q['files']),flush=True)
