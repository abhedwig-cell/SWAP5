from pathlib import Path
import hashlib,json,os,subprocess,urllib.request
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';C='62cf6eefb110099ab1c181b06f2a5ae74b48f144'
child=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);child.check_returncode();fields=dict(v.split('=',1) for v in child.stdout.decode().splitlines() if '=' in v);headers={'Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','Accept-Encoding':'identity','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-artifact-custody'}
for run_id,platform in [(46020246228,'UBUNTU'),(46020246319,'WINDOWS')]:
    with urllib.request.urlopen(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/actions/runs/'+str(run_id)+'/artifacts',headers=headers),timeout=40) as response:raw=response.read()
    q=json.loads(raw);assert q['total_count']==len(q['artifacts'])==2
    for item in q['artifacts']:
        assert item['workflow_run']['id']==run_id and item['workflow_run']['head_sha']==C
        opt=next(v for v in ['O0','O2'] if '-'+v+'-' in item['name']);descriptor=json.loads((P/('CLOSED_IMPLICIT_STATE13_FIRST_'+platform+'_'+opt+'_ORIGINAL_V1.json')).read_text())
        assert item['id']==descriptor['actual_artifact_id'] and item['size_in_bytes']==descriptor['bytes'] and item['digest']=='sha256:'+descriptor['sha256']
    name='CLOSED_IMPLICIT_STATE13_FIRST_'+platform+'_ORIGINAL_ARTIFACT_API_V1.json'
    for root in [E,P]:assert not (root/name).exists();(root/name).write_bytes(raw)
    print('ORIGINAL_OFFICIAL_ARTIFACT_API_RETAINED',platform,len(raw),hashlib.sha256(raw).hexdigest(),flush=True)
