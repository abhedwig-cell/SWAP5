"""Retain original failed CI log/API bytes; decoded connector text is diagnostic only."""
from pathlib import Path
import hashlib,json,os,subprocess,urllib.request,urllib.error,urllib.parse
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='7c6a0ef700e1e94ff10b265fb4df0bca1babaa74';SHA=lambda b:hashlib.sha256(b).hexdigest();root=E/'closure13-first-ci-original-logs-v1';root.mkdir()
specs=[(46018822331,140572814035),(46018822331,140572814598),(46018822402,140572814473),(46018822402,140572814635)]
credential=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);credential.check_returncode();fields=dict(line.split('=',1) for line in credential.stdout.decode().splitlines() if '=' in line);token=fields['password']
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Accept-Encoding':'identity','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-failure-evidence-custody'}
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,response_headers,newurl):return None
opener=urllib.request.build_opener(NoRedirect)
def fetch(path):
    try:
        with opener.open(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=40) as stream:return stream.read()
    except urllib.error.HTTPError as error:
        if error.code not in (301,302,303,307,308):raise
        loc=error.headers['Location'];url=urllib.parse.urlsplit(loc);assert url.scheme=='https' and (url.hostname.endswith('.blob.core.windows.net') or url.hostname.endswith('.actions.githubusercontent.com'))
        with urllib.request.urlopen(urllib.request.Request(loc,headers={'Accept-Encoding':'identity'}),timeout=40) as stream:return stream.read()
records=[]
for run_id,job_id in specs:
    jobraw=fetch('actions/jobs/'+str(job_id));runraw=fetch('actions/runs/'+str(run_id));log=fetch('actions/jobs/'+str(job_id)+'/logs');job=json.loads(jobraw);run=json.loads(runraw)
    assert job['head_sha']==run['head_sha']==C and job['run_id']==run_id and run['event']=='push' and job['conclusion']=='failure' and job['status']=='completed'
    steps={v['name']:v['conclusion'] for v in job['steps']};assert steps['Preserve real source and prepare original provider']=='failure' and steps['Run finite ordinary Snow Frost cohort and compiled native refusals']=='skipped'
    assert b'missing owning authority' in log and C.encode() in log;log.decode('utf8',errors='strict')
    stem='job-'+str(job_id)
    for suffix,raw in [('.original.log',log),('.original-job-api.json',jobraw),('.original-run-api.json',runraw)]:
        path=root/(stem+suffix);assert not path.exists();path.write_bytes(raw)
    records.append(dict(actual_producer=C,run_id=run_id,job_id=job_id,name=job['name'],original_log_sha256=SHA(log),original_log_bytes=len(log),original_job_API_sha256=SHA(jobraw),original_run_API_sha256=SHA(runraw),log_normalized_or_recoded=False,model_executions=0,project_compiler_executions=0,refusal='missing owning authority in actual sparse checkout'))
q=dict(status='FOUR_ORIGINAL_FAILED_CI_PREFLIGHT_UTF8_LOGS_AND_OFFICIAL_API_BYTES_PRESERVED_ZERO_MODELS',actual_producer=C,jobs=records,temporary_URLs_or_credentials_retained=False)
(root/'CUSTODY.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],len(records),flush=True)
