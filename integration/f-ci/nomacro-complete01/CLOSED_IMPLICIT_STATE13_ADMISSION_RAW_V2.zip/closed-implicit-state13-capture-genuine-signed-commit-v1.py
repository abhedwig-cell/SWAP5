from pathlib import Path
import argparse,json,os,subprocess,sys,urllib.request
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='aa43c6d21479ab1f5564d19f7d191445dabfe527';B='2e98506b4fb469bbf5995a8ab0b49c88ead0972c'
p=argparse.ArgumentParser();p.add_argument('--sha',required=True);p.add_argument('--role',choices=['SYNTHETIC','ACTUAL_MERGE'],required=True);a=p.parse_args()
git=lambda *v:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*v],cwd=R);before=git('rev-parse','HEAD');assert before.decode().strip()==C
child=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);child.check_returncode();fields=dict(v.split('=',1) for v in child.stdout.decode().splitlines() if '=' in v)
request=urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/git/commits/'+a.sha,headers={'Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','Accept-Encoding':'identity','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-genuine-signed-object-custody'})
with urllib.request.urlopen(request,timeout=40) as response:raw=response.read()
q=json.loads(raw);assert q['sha']==a.sha and [v['sha'] for v in q['parents']]==[B,C] and q['tree']['sha']==git('rev-parse',C+'^{tree}').decode().strip() and q['verification']['verified'] is True
target=E/('CLOSED_IMPLICIT_STATE13_PR1812_'+a.role+'_GIT_API_V1.json');assert not target.exists();target.write_bytes(raw)
helper=E/'closed-implicit-state13-genuine-signed-object-import-v1.py'
if not helper.exists():helper.write_text((E/'closed-gardner-state12-genuine-signed-object-import-v1.py').read_text().replace('CLOSED_GARDNER_STATE12_PR1811','CLOSED_IMPLICIT_STATE13_PR1812'),encoding='utf8')
subprocess.run([sys.executable,'-B',str(helper),'--repository',str(R),'--api',str(target)],check=True)
assert git('rev-parse','HEAD')==before;git('update-ref','refs/heads/codex/storage-retained/closure13-'+a.role.lower()+'-20261127',a.sha);print('ACTUAL_GITHUB_SIGNED_OBJECT_RETAINED_HEAD_UNCHANGED',a.role,a.sha,flush=True)
