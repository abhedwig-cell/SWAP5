from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest();name='CLOSED_IMPLICIT_STATE13_FIRST_PORTABLE_PREFLIGHT_FAILURES_RAW_V7'
assert SHA((E/(name+'.zip')).read_bytes())=='3a4c3281b24f10371989104fe7c9c81fa4f7083b1b41d408a0a4518338d5e96d'
for suffix in ['.zip','.json']:
    target=P/(name+suffix);assert not target.exists();shutil.copyfile(E/target.name,target)
for filename in ['STATUS.json','GAP_MATRIX.json']:
    path=P/filename;q=json.loads(path.read_text());item=q['closed_implicit_state13'];item.update(first_portable_preflight=dict(actual_producer='7c6a0ef700e1e94ff10b265fb4df0bca1babaa74',runs=[46018822331,46018822402],jobs=4,conclusion='FAILURE_BEFORE_PROJECT_COMPILATION_OR_MODELS',cause='Exact owning science document existed in committed source but was absent from actual CI sparse checkout.',raw=name+'.zip',sha256='3a4c3281b24f10371989104fe7c9c81fa4f7083b1b41d408a0a4518338d5e96d',project_compiler_executions=0,model_executions=0),next_action='Run real second portable producer with exact owning document materialized, and40 current old-domain native/compiler preservation builds. Physical APP/source unchanged from ae8ddfbb; no model periods existed in first portable attempt.')
    if filename=='STATUS.json':
        group=q['test_selection']['groups']['closed_implicit_portable'];group['prior_execution']='FAILED';group['diagnosis']='All4 source7c6a0ef7 CI jobs refused missing owning authority before source/provider/model execution; raw3a4c3281 holds official original UTF8 logs/APIs and four original empty scientific artifacts. Add only the actual versioned authority document to the real sparse checkout; source, inputs and numerical policy remain unchanged.'
    path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
git('add','--sparse','--','.github/workflows/nomacro-closed-implicit-state13-windows.yml','.github/workflows/nomacro-closed-implicit-state13-ubuntu.yml',str(P.relative_to(R)));git('commit','-m','Materialize actual closed implicit authority before portable selection')
C=git('rev-parse','HEAD').decode().strip();assert not git('diff','ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30',C,'--','app','src','tools','reference');path=P/'STATUS.json';q=json.loads(path.read_text());q['test_selection']['candidate']=C;path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');git('add','--',str(path.relative_to(R)));git('commit','-m','Select actual second portable producer without changing scientific source')
print(git('rev-parse','HEAD').decode().strip(),flush=True)
