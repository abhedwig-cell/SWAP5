from pathlib import Path
import ast,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()=='62cf6eefb110099ab1c181b06f2a5ae74b48f144'
path=R/'tests/nomacro_drainage/closed_implicit_state_verify.py';body=path.read_text();before='actual_raw_custody=raw,new_original_portable_science=results';assert body.count(before)==1;path.write_text(body.replace(before,'actual_raw_custody=raw,actual_original_portable_CI_custody=ci,new_original_portable_science=results'),encoding='utf8')
status=json.loads((P/'STATUS.json').read_text());summary=status['closed_implicit_state13_portable_candidate'];summary['next_action']='Freeze the actual current PUBLIC and ordinary Python publication owner, test four genuine committed negative controls, complete required candidate CI and merge, then verify actual canonical receipt. Continue the remaining finite dependency backlog.'
for name in ['STATUS.json','GAP_MATRIX.json']:
    path=P/name;q=json.loads(path.read_text());batch=q.setdefault('closed_implicit_state13',{});batch.update(status=summary['status'],actual_portable_science=summary,qualified_contexts=56,new_admitted_contexts=0,canonical_admission=False,next_action=summary['next_action'])
    if name=='STATUS.json':q['running_ci']=[];q['active_local_jobs']=[];q['next_action']=summary['next_action'];q['recovery_point']='CLOSED_IMPLICIT_STATE13_PORTABLE_ORIGINAL_CI_INDEPENDENT_V1.json'
    path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for path in (R/'tests/nomacro_drainage').glob('closed_implicit_state*.py'):ast.parse(path.read_text())
git('diff','--check');rows=git('status','--porcelain=v1','-z','--untracked-files=all').split(b'\0');paths=[]
for row in rows:
    if not row:continue
    path=row[3:].decode();assert path.startswith(('tests/nomacro_drainage/closed_implicit_state_','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_')) or path in ['docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md','integration/f-ci/nomacro-complete01/STATUS.json','integration/f-ci/nomacro-complete01/GAP_MATRIX.json','tests/nomacro_drainage/initial_profile_age_groundwater_verify.py'];paths.append(path)
git('add','--',*paths);print('STAGED_OWN_ACTUAL_ARCHIVES_AND_OWNER',len(paths),flush=True);print(git('commit','-m','Qualify closed implicit original native and portable scientific ownership').decode(),flush=True)
anchor=git('rev-parse','HEAD').decode().strip();(E/'CLOSED_IMPLICIT_STATE13_OWNING_ANCHOR_V1.json').write_text(json.dumps(dict(actual_anchor=anchor,files=len(paths),formal_candidate_admission_pending=True),indent=2)+'\n',encoding='utf8');print('ACTUAL_OWNING_ANCHOR',anchor,flush=True)
