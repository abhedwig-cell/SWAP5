from pathlib import Path
import hashlib,json
E=Path(__file__).parent;name='CLOSED_IMPLICIT_STATE13_FORTY_NATIVE_PRESERVATION_RAW_V8';path=E/(name+'.json');q=json.loads(path.read_text());old=q['parts'];record=E/(name+'_INITIAL_UNADMITTED_DESCRIPTOR.json');assert not record.exists();record.write_bytes(path.read_bytes())
for index,item in enumerate(q['parts'],1):
    raw=(E/item['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256'];target=q['archive']+'.part'+str(index).zfill(3);assert not (E/target).exists();(E/target).write_bytes(raw);item['file']=target
q['descriptor_recovery']='Only unadmitted ZIP-part filenames corrected to existing Archive contract; identical archive bytes, original compiler and scientific identities retained.';path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print('NATIVE_PART_FILENAMES_CORRECTED_IDENTICAL_ARCHIVE_BYTES',flush=True)
