from pathlib import Path
import json,sys,traceback
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from closed_implicit_state_preservation_science import audit
try:audit(E)
except Exception as error:
    frames=[];tb=error.__traceback__
    while tb:
        values=tb.tb_frame.f_locals
        if 'item' in values:frames.append(dict(case=values['item'].get('case'),matches=values.get('matches'),before_path=getattr(values.get('before'),'path',None)))
        tb=tb.tb_next
    record=dict(status='UNADMITTED_OBSERVER_FAILURE_RETAINED_NO_MODEL_OR_COMPILER_EXECUTION',error=repr(error),frames=frames,traceback=traceback.format_exc(),observer_source=(R/'tests/nomacro_drainage/closed_implicit_state_preservation_science.py').read_text())
    (E/'CLOSED_IMPLICIT_STATE13_NATIVE_ARCHIVE_OBSERVER_FAILURE_V1.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');print(frames,flush=True)
