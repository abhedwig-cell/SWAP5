"""Copy connector file references exactly; retain hashes/IDs, never temporary URLs."""
from pathlib import Path
import hashlib,json,sys,urllib.parse,urllib.request,zipfile
E=Path(__file__).parent;root=E/'closure13-first-ci-artifacts-v1';root.mkdir(exist_ok=True)
print('READY_FOR_REUSABLE_FILE_REFERENCES',flush=True)
items=json.loads(sys.stdin.readline());records=[]
for item in items:
    url=urllib.parse.urlsplit(item['url']);assert url.scheme=='https' and url.hostname.endswith('.oaiusercontent.com')
    with urllib.request.urlopen(item['url'],timeout=30) as stream:raw=stream.read()
    digest=hashlib.sha256(raw).hexdigest();assert digest==item['sha256'] and len(raw)==item['bytes']
    target=root/('artifact-'+str(item['artifact_id'])+'.zip');assert not target.exists();target.write_bytes(raw)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        members={name:dict(bytes=len(z.read(name)),sha256=hashlib.sha256(z.read(name)).hexdigest()) for name in z.namelist()}
    records.append(dict(artifact_id=item['artifact_id'],connector_file_id=item['file_id'],bytes=len(raw),sha256=digest,file=target.name,members=members,temporary_URL_retained=False))
(root/'ORIGINAL_CONNECTOR_ARTIFACTS.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8');print('FOUR_ORIGINAL_CONNECTOR_ZIPS_EXACT',len(records),flush=True)
