from pathlib import Path
import json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
q=dict(status='PREFLIGHT_ONLY_SCHEMA_AND_WORKER_PROTOCOL_ASSUMPTIONS_CORRECTED_NO_MODEL_OR_COMPILER_EXECUTIONS',original_observer='84d271321104fe724a64b8a096b9c6512b99cfd7',selection_failure='prior_execution requires enum NONE/PASS/FAILED/UNEXPECTED_LONG; free prose rejected before science',independent_audit_failure='Worker restart startup emits preliminary stock before the final pre-READY record; the real receive protocol uses latest value. Unique-record assertion failed before any models. Original failed strict audit JSON V4 remains intact.',correction='Use NONE for the never-executed portable/static-guard matrix; bind the positive receipt to the last actual record before READY, exactly like the real protocol.',model_executions=0,compiler_executions=0)
name='CLOSED_IMPLICIT_STATE13_PORTABLE_PREFLIGHT_HARNESS_RECOVERY_V1.json';(E/name).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');(P/name).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
path=P/'STATUS.json';q=json.loads(path.read_text())
for name in ['closed_implicit_portable','closed_implicit_native_preservation']:
    q['test_selection']['groups'][name]['prior_execution']='NONE'
    q['test_selection']['groups'][name]['diagnosis']='Four local ae8ddfbb regressions PASS; this complete portable/static-guard matrix has not executed. Earlier preflight schema and duplicate startup-token assumptions were harness-only, zero compiler/model executions.'
path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
git('add','--','tests/nomacro_drainage/closed_implicit_state_science.py','tests/nomacro_drainage/closed_implicit_state_parent_native_controls.py',str(path.relative_to(R)),str((P/'CLOSED_IMPLICIT_STATE13_PORTABLE_PREFLIGHT_HARNESS_RECOVERY_V1.json').relative_to(R)));git('commit','-m','Match actual restart startup protocol and validate portable selection schema')
C=git('rev-parse','HEAD').decode().strip();q=json.loads(path.read_text());q['test_selection']['candidate']=C;path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');git('add','--',str(path.relative_to(R)));git('commit','-m','Bind reviewed portable preflight to unchanged actual scientific source')
print(git('rev-parse','HEAD').decode().strip(),flush=True)
