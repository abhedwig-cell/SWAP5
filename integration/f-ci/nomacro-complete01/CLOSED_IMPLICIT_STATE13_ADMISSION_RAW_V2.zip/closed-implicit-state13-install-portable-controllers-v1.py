from pathlib import Path
import ast,hashlib,json,shutil,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SCI='ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30';git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==SCI and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
mapping={'closed-implicit-state13-parent-native-controls.draft.py':'tests/nomacro_drainage/closed_implicit_state_parent_native_controls.py','closed-implicit-state13-postimages.draft.py':'tests/nomacro_drainage/closed_implicit_state_postimages.py','closed-implicit-state13-science.draft.py':'tests/nomacro_drainage/closed_implicit_state_science.py'}
for source,target in mapping.items():
    data=(E/source).read_bytes();ast.parse(data);(R/target).write_bytes(data)
for platform in ['windows','ubuntu']:
    target=R/('.github/workflows/nomacro-closed-implicit-state13-'+platform+'.yml');assert not target.exists();shutil.copyfile(E/('nomacro-closed-implicit-state13-'+platform+'.draft.yml'),target)
for name,expected in [('CLOSED_IMPLICIT_STATE13_REPAIRED_LOCAL_FOUR_RAW_V6','bb345b239044957f390efd1bb193bff3cb89d36b9162aebe6fdc9ade67117f6f'),('CLOSED_IMPLICIT_STATE13_PARENT_NEGATIVE_GENUINE_GIT_OBJECTS_V1','dee474b11fab224f8e8620ec2fe5f0877db00e91c331d1674c460e13c39b53c0')]:
    assert SHA((E/(name+'.zip')).read_bytes())==expected
    for suffix in ['.json','.zip']:
        target=P/(name+suffix);assert not target.exists();shutil.copyfile(E/target.name,target)
for filename in ['STATUS.json','GAP_MATRIX.json']:
    path=P/filename;q=json.loads(path.read_text());item=q['closed_implicit_state13'];item.update(status='FOUR_REPAIRED_PRODUCTION_COUPLINGS_INDEPENDENT_PASS_PORTABLE14_AND_PARENT_NATIVE_PRESERVATION_SELECTED_NOT_QUALIFIED',actual_repaired_local_scientific_source=SCI,local_completed_contexts=4,local_primary_days=140,local_native_samples=28,local_exact_cold_windows=12,local_compiled_native_refusals=125,local_external_transaction_contexts=4,local_archive='CLOSED_IMPLICIT_STATE13_REPAIRED_LOCAL_FOUR_RAW_V6.zip',local_archive_sha256='bb345b239044957f390efd1bb193bff3cb89d36b9162aebe6fdc9ade67117f6f',new_qualified_contexts=0,new_admitted_contexts=0,next_action='Strong independent exact native attack-byte audit of all4 local contexts; all14 Windows/Ubuntu O0/O2 producers with original SDK/source/raw custody. Compile40 old contexts without model replay: only the two known static native guard providers may differ, with exact original native startup/compiled refusal proof; all numerical objects remain byte-identical.')
    if filename=='STATUS.json':
        groups=q['test_selection']['groups']
        base=dict(owner='SWAP5-NOMACRO-COMPLETE01',authority='docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md',prior_execution='Four actual ae8ddfbb production35day couplings independently PASS; retained failures/censors/prototypes remain original roles.',routine_feedback=False,original_model_periods_replayed=0)
        groups['closed_implicit_portable']=dict(**base,changed_dependency='New closed6/no-drainage analytical implicit state/output composition and signed residual/conditional complete convergence order; all14 actual original input decks.',scientific_claim='All14 finite35day contexts Windows/Ubuntu O0/O2, independent1e-10 water/CDE/prefix budgets, complete native layouts/cold windows, transactions, complete compiled native attack byte sets and original source/SDK provenance. No full historical completeness or scientific-equivalence claim.',expected_seconds=1800,existing_evidence='Four actual local contexts:140primary days,28native,12cold,125compiled refusals,4transactions; bb345b23 raw. All original14 zero-day/public input/output metadata seams and complete13APP inverses. Portable profiles not yet executed.')
        groups['closed_implicit_native_preservation']=dict(**base,changed_dependency='The two static native providers extend their accepted closed6/no-drainage guard; original numerical modules, all native layouts and old domains are preserved.',scientific_claim='Forty current public old-domain O0/O2 builds: original input/SDK and every complete numerical source/object identical; only exact known static guard provider source/object deltas permitted, plus real compiled original native positives/refusals without model days. Unaffected parent16 builds retain every whole object.',expected_seconds=1200,existing_evidence='Canonical948 accepted raw source/native/science and prior40whole-object evidence retained. Current additional static guard code requires new startup controls; old scientific periods are not selected for replay.')
    path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
doc=R/'docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md'
with doc.open('a',encoding='utf8') as f:f.write('''
Actual ae8ddfbb production V3 completes all four previous failure regressions:
140 primary days,28 native samples,12 exact cold windows,125 compiled native
refusals and4 transaction contexts. Independent audit passes; raw bb345b23.
This is local feedback; portable14 on Windows/Ubuntu O0/O2 remains selected.
Independent raw auditing now reconstructs every expected native attack byte,
checks the full attack-name set and exact positive initial physical receipts,
and binds each numerical provider to its genuine actual producer Git bytes.

Native preservation accounts explicitly for the changed static guard code:
only implicit_hydraulic_state_native or implicit_frost_hydraulic_state_native
may differ, exactly from canonical948 source to the committed literal proposal.
All other complete generated numerical source/object bytes must be identical.
Real compiled consumers must read the exact original native state and refuse
every corrupted static field before READY; original checkpoint bindings and
producer roles remain unchanged. No original physical period is repeated.
The unaffected parent controller keeps its stricter whole-object equality.
''')
git('add','--sparse','--','tests/nomacro_drainage/closed_implicit_state_science.py','tests/nomacro_drainage/closed_implicit_state_postimages.py','tests/nomacro_drainage/closed_implicit_state_parent_native_controls.py','.github/workflows/nomacro-closed-implicit-state13-windows.yml','.github/workflows/nomacro-closed-implicit-state13-ubuntu.yml',str(P.relative_to(R)),str(doc.relative_to(R)));git('commit','-m','Select complete portable closed implicit batch and exact parent native preservation')
C=git('rev-parse','HEAD').decode().strip();assert not git('diff',SCI,C,'--','app','src','tools','reference');path=P/'STATUS.json';q=json.loads(path.read_text());q['test_selection']['candidate']=C;path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');git('add','--',str(path.relative_to(R)));git('commit','-m','Bind portable and native preservation selection to stable actual source')
print(git('rev-parse','HEAD').decode().strip(),flush=True)
