from pathlib import Path
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage'
for source,target in [('closed-implicit-state13-parent-admission.draft.py','closed_implicit_state_parent_admission.py'),('closed-implicit-state13-portable-science.draft.py','closed_implicit_state_portable_science.py')]:
    body=(E/source).read_text()
    if 'portable' in source:
        body=body.replace("assert (counts['context_count'],counts['primary_days'],counts['native_samples'])==(14,490,98)\n        assert counts['exact_cold_windows']>=42 and counts['compiled_native_refusals']>=14*3","assert (counts['context_count'],counts['primary_days'],counts['native_samples'],counts['exact_cold_windows'],counts['compiled_native_refusals'])==(14,490,98,44,402)")
        before="assert not contract['source_or_filesystem_identity_projected'] and contract['compiler_executions']==contract['model_executions']==0"
        after=before+"\n    assert not contract['physical_equations_changed'] and not contract['new_physical_state'] and contract['new_numerical_policy'] is True and contract['numerical_policy']=='original-closed-implicit-residual-start-and-conditional-convergence-v3'"
        assert before in body;body=body.replace(before,after)
    compile(body,target,'exec');path=T/target;assert not path.exists();path.write_text(body,encoding='utf8')
print('TESTED_PARENT_AND_PORTABLE_OBSERVERS_INSTALLED_WITH_EXACT_FINITE_COUNTS',flush=True)
