from contextlib import ExitStack
from pathlib import Path,PureWindowsPath
import json,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from analytical_hydraulic_archives import Archive
from frost_boundary_git_archive import GitArchiveSource
from explicit_bottom9_archive_science import ReadView
from closed_implicit_state_science import observe,OriginalInputs
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert not git('diff','ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30',head,'--','app','src','tools','reference')
records=[]
with ExitStack() as stack:
    source=GitArchiveSource(R,head);store=Archive(source,'CLOSED_IMPLICIT_STATE13_REPAIRED_LOCAL_FOUR_RAW_V6',stack);assert store.record['sha256']=='bb345b239044957f390efd1bb193bff3cb89d36b9162aebe6fdc9ade67117f6f'
    original=OriginalInputs(stack)
    for opt in ['O0','O2']:
        root=ReadView(store,'actual/evidence/closure13-residual-feedback-v3/'+opt);summary=json.loads((root/'SUMMARY.json').read_text())
        for entry in summary['cases']:
            profile=root/entry['case'];q=json.loads((profile/'RESULT.json').read_text());assert q['actual_source']=='ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30'
            relative=PureWindowsPath(q['build_root']).relative_to(PureWindowsPath(W));build=ReadView(store,'actual/'+relative.as_posix())
            records.append(observe(profile,build=build,inputs=profile/'inputs',controls=root/(entry['case']+'-native-controls'),original_store=original))
assert len(records)==4
result=dict(status='ACTUAL_GIT_ARCHIVE_FOUR_REPAIRED_LOCAL_CONTEXTS_STRICT_NATIVE_AND_GENUINE_PRODUCER_INDEPENDENT_PASS_NO_LIVE_BUILD_DEPENDENCY',actual_observer_source=head,actual_scientific_producer='ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30',raw_sha256=store.record['sha256'],contexts=records,model_executions=0,compiler_executions=0,new_admitted_contexts=0,canonical_admission=False)
(E/'CLOSED_IMPLICIT_STATE13_REPAIRED_LOCAL_ACTUAL_GIT_ARCHIVE_STRICT_AUDIT_V1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(result['status'],flush=True)
