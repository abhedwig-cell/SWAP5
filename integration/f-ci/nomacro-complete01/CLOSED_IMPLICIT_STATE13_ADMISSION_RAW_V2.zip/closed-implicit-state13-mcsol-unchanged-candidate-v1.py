"""Prove unchanged MCSOL source/input/workflow bytes; execute no old model periods."""
from contextlib import ExitStack
from pathlib import Path
import json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
git=lambda *v:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*v],cwd=R);C='2d810e6db3acf6eb81ff96dae90859670eae9b3a';B='2e98506b4fb469bbf5995a8ab0b49c88ead0972c'
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
with ExitStack() as stack:
    archive=Archive(GitArchiveSource(R,C),'CLOSED_GARDNER_STATE12_ADMISSION_RAW_V1',stack);assert archive.record['sha256']=='d4ec3ee6947288d7a0d21d9d9b393c1178d2e7fca50d9651cc5eb9d78c9e9564'
    name='CLOSED_GARDNER_STATE12_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json';raw=archive.get(name);parent=json.loads(raw);paths=parent['unchanged_dependency_paths'];assert parent['unchanged_tracked_files']==1063
    assert not git('diff',B,C,'--',*paths);before=git('ls-tree','-rl',B,'--',*paths);after=git('ls-tree','-rl',C,'--',*paths);assert before==after and len(after.splitlines())==1063 and SHA(after)==parent['actual_ls_tree_rl_sha256']
    q=dict(status='MCSOL_ALL_1063_ACTUAL_ACCEPTED_DEPENDENCY_TREE_ENTRIES_EXACT_NO_MODEL_REPLAY',actual_parent=B,actual_candidate=C,unchanged_dependency_paths=paths,unchanged_tracked_files=1063,actual_ls_tree_rl_sha256=SHA(after),actual_accepted_parent_admission_archive_sha256=archive.record['sha256'],actual_parent_selection_member=name,actual_parent_selection_sha256=SHA(raw),current_model_replay=False,fresh_current_MCSOL_scientific_PASS_claimed=False,original_scientific_sources_rebound=False,compiler_executions=0,model_executions=0)
target=E/'CLOSED_IMPLICIT_STATE13_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json';assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],q['actual_ls_tree_rl_sha256'],flush=True)
