"""Save original official HTTP admission metadata only for terminal matching sources."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,urllib.request
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='2d810e6db3acf6eb81ff96dae90859670eae9b3a';B='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';S='c1eb28258a92b231748645a384c032c818c671d6';TREE='202bb30e809e46770b591bb56ce94866dbdffbfb';SHA=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['PREMERGE','POSTMERGE'],required=True);p.add_argument('--merge');p.add_argument('--probe',action='store_true');a=p.parse_args()
if a.phase=='POSTMERGE':assert a.merge and re.fullmatch('[0-9a-f]{40}',a.merge)
child=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);child.check_returncode();fields=dict(v.split('=',1) for v in child.stdout.decode().splitlines() if '=' in v);headers={'Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','Accept-Encoding':'identity','Cache-Control':'no-cache','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-official-admission-metadata-custody'}
def fetch(path):
    with urllib.request.urlopen(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=45) as stream:return stream.read()
def once(name,raw):
    path=E/name
    if path.exists():assert path.read_bytes()==raw
    else:path.write_bytes(raw)
prraw=fetch('pulls/1812');pr=json.loads(prraw);assert pr['head']['sha']==C and pr['base']['ref']=='integration/f-ci-canonical'
refraw=fetch('git/ref/heads/integration/f-ci-canonical');ref=json.loads(refraw)
if a.phase=='PREMERGE':assert not pr['merged'] and pr['state']=='open' and pr['mergeable'] is True and pr['merge_commit_sha']==S and pr['base']['sha']==ref['object']['sha']==B
else:assert pr['merged'] is True and pr['state']=='closed' and pr['merge_commit_sha']==ref['object']['sha']==a.merge
runraw=fetch('actions/runs?head_sha='+C+'&event=pull_request&per_page=100');runs=json.loads(runraw);checkraw=fetch('commits/'+C+'/check-runs?per_page=100');checks=json.loads(checkraw)
if a.probe:
    observed=runs
    if a.phase=='POSTMERGE':observed=json.loads(fetch('actions/runs?head_sha='+a.merge+'&event=push&per_page=100'))
    print(json.dumps(dict(phase=a.phase,workflows=len(observed['workflow_runs']),completed=sum(v['status']=='completed' for v in observed['workflow_runs']),success=sum(v['conclusion']=='success' for v in observed['workflow_runs']),candidate_checks=len(checks['check_runs']),candidate_check_statuses={s:sum(v['status']==s for v in checks['check_runs']) for s in ['completed','in_progress','queued']})),flush=True)
    for run in observed['workflow_runs']:
        if run['status']=='completed':continue
        jobs=json.loads(fetch('actions/runs/'+str(run['id'])+'/jobs?per_page=100'))
        print(json.dumps(dict(run_id=run['id'],name=run['name'],status=run['status'],jobs=[dict(id=j['id'],name=j['name'],status=j['status'],conclusion=j['conclusion'],active_steps=[v['name'] for v in j['steps'] if v['status']=='in_progress']) for j in jobs['jobs'] if j['conclusion']!='skipped'])),flush=True)
    raise SystemExit(0)
assert runs['total_count']==len(runs['workflow_runs'])==len({v['workflow_id'] for v in runs['workflow_runs']})==14 and all(v['head_sha']==C and v['status']=='completed' and v['conclusion']=='success' for v in runs['workflow_runs'])
assert checks['total_count']==len(checks['check_runs'])==45 and all(v['head_sha']==C and v['status']=='completed' and v['conclusion'] in ['success','skipped'] for v in checks['check_runs'])
assert sum(v['conclusion']=='success' for v in checks['check_runs'])==28 and sum(v['conclusion']=='skipped' for v in checks['check_runs'])==17
prefix='CLOSED_IMPLICIT_STATE13_PR1812_'+a.phase
for suffix,raw in [('_ORIGINAL_API_V1.json',prraw),('_CANONICAL_REF_ORIGINAL_API_V1.json',refraw),('_ALL_CI_ORIGINAL_API_V1.json',runraw),('_ALL_CHECKS_ORIGINAL_API_V1.json',checkraw)]:once(prefix+suffix,raw)
if a.phase=='POSTMERGE':
    raw=fetch('git/commits/'+a.merge);q=json.loads(raw);assert q['sha']==a.merge and q['verification']['verified'] is True and q['verification']['reason']=='valid' and q['tree']['sha']==TREE and [v['sha'] for v in q['parents']]==[B,C]
    once(prefix+'_ACTUAL_GIT_ORIGINAL_API_V1.json',raw)
    canonicalraw=fetch('actions/runs?head_sha='+a.merge+'&event=push&per_page=100');canonical=json.loads(canonicalraw)
    assert canonical['total_count']==len(canonical['workflow_runs'])==4 and all(v['head_sha']==a.merge and v['status']=='completed' and v['conclusion']=='success' for v in canonical['workflow_runs'])
    once('CLOSED_IMPLICIT_STATE13_ACTUAL_MERGE_ALL_CI_ORIGINAL_API_V1.json',canonicalraw)
    for run in canonical['workflow_runs']:
        jobsraw=fetch('actions/runs/'+str(run['id'])+'/jobs?per_page=100');jobs=json.loads(jobsraw);assert jobs['total_count']==len(jobs['jobs']) and all(v['head_sha']==a.merge and v['status']=='completed' and v['conclusion'] in ['success','skipped'] for v in jobs['jobs']);once('CLOSED_IMPLICIT_STATE13_ACTUAL_MERGE_JOBS_'+str(run['id'])+'_ORIGINAL_API_V1.json',jobsraw)
print('OFFICIAL_MATCHING_TERMINAL_ADMISSION_METADATA_SAVED',a.phase,14,28,17,flush=True)
