from pathlib import Path
E=Path(__file__).parent;body=(E/'closed-implicit-state13-capture-pr-terminal-logs-v1.py').read_text()
changes={
 "p.add_argument('--head',required=True);p.add_argument('--synthetic',required=True);p.add_argument('--label',required=True)":"p.add_argument('--head',required=True);p.add_argument('--synthetic',required=True);p.add_argument('--label',required=True)",
 "prefix='CLOSED_IMPLICIT_STATE13_PR1812_'+a.label":"assert a.head==a.synthetic and a.label=='COMPLETE'\nprefix='CLOSED_IMPLICIT_STATE13_ACTUAL_MERGE'",
 'actual_signed_synthetic':'actual_signed_checkout',
 "'&event=pull_request&per_page=100'":"'&event=push&per_page=100'",
 "len(all_runs['workflow_runs'])==14":"len(all_runs['workflow_runs'])==4",
 "run['event']=='pull_request'":"run['event']=='push'",
 "official['event']=='pull_request'":"official['event']=='push'",
 "'ALL_FOURTEEN_TERMINAL_PR_RUN_LOGS_RETAINED' if len(record['runs'])==14 else 'PARTIAL_TERMINAL_PR_LOG_CAPTURE_ACTIVE_RUNS_PENDING'":"'ALL_FOUR_TERMINAL_CANONICAL_RUN_LOGS_RETAINED' if len(record['runs'])==4 else 'PARTIAL_TERMINAL_CANONICAL_LOG_CAPTURE_ACTIVE_RUNS_PENDING'"
}
for before,after in changes.items():assert before in body,before;body=body.replace(before,after)
body=body.replace('each completed PR run','each completed canonical push run');target=E/'closed-implicit-state13-capture-canonical-terminal-logs-v1.py';assert not target.exists();compile(body,target.name,'exec');target.write_text(body,encoding='utf8');print('FOUR_CANONICAL_ORIGINAL_LOG_CAPTURE_PREPARED_NOT_EXECUTED',flush=True)
