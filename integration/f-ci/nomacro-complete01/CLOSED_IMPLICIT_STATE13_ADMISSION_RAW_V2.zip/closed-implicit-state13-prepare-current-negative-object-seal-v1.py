from pathlib import Path
E=Path(__file__).parent;body=(E/'closed-implicit-state13-seal-parent-negative-objects-v1.py').read_text()
for before,after in [('07cb2850e2cd45deb1e197161409a3784a8975e7','2d810e6db3acf6eb81ff96dae90859670eae9b3a'),('8df17cc12686e8ab5522360b87f6430a345aabdb','202bb30e809e46770b591bb56ce94866dbdffbfb'),('CLOSED_GARDNER_STATE12_FINAL1_','CLOSED_IMPLICIT_STATE13_FINAL1_'),('CLOSED_IMPLICIT_STATE13_PARENT_NEGATIVE_GENUINE_GIT_OBJECTS_V1','CLOSED_IMPLICIT_STATE13_ACTUAL_NEGATIVE_GENUINE_GIT_OBJECTS_V1'),('FOUR_GENUINE_PRIOR_NEGATIVE','FOUR_GENUINE_CURRENT_NEGATIVE')]:
    assert before in body,before;body=body.replace(before,after)
target=E/'closed-implicit-state13-seal-current-negative-objects-v1.py';assert not target.exists();compile(body,target.name,'exec');target.write_text(body,encoding='utf8')
