from pathlib import Path
E=Path(__file__).parent;body=(E/'closed-gardner-state12-negative-git-custody-v1.py').read_text().replace('CLOSED_GARDNER_STATE12','CLOSED_IMPLICIT_STATE13').replace('07cb2850e2cd45deb1e197161409a3784a8975e7','2d810e6db3acf6eb81ff96dae90859670eae9b3a')
body=body.replace("prior_controller_error_preserved_as='CLOSED_IMPLICIT_STATE13_FINAL1_NEGATIVES_HARNESS_FAILURE_V1.json',first_two_successful_controls_replayed=False,recovered_controller='closed-gardner-state12-real-negative-controls-v2.py'","all_four_controls_first_executions=True,executed_controller='closed-implicit-state13-real-negative-controls-v1.py'")
target=E/'closed-implicit-state13-negative-git-custody-v1.py';assert not target.exists();compile(body,target.name,'exec');target.write_text(body,encoding='utf8')
