from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
body=(R/'tests/nomacro_drainage/closed_gardner_state_portable_science.py').read_text()
replacements={
 'closed_gardner_state_feedback':'closed_implicit_state_feedback',
 'from closed_gardner_state_science import observe':'from closed_implicit_state_science import observe,OriginalInputs',
 'e112e8f7f6f0bd00e4ae9035d00ef53860477448':'62cf6eefb110099ab1c181b06f2a5ae74b48f144',
 'd143437f4d9d855f03c036a9db1b8a3f86ec63ef':'ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30',
 '45991118737':'46020246228','45991118752':'46020246319',
 'nomacro-closed-gardner-state12-':'nomacro-closed-implicit-state13-',
 '105b9a8e6ca9e846f214d69a71afe73ed18be11d':'2e98506b4fb469bbf5995a8ab0b49c88ead0972c',
 "len(contract['APP_files'])==19":"len(contract['APP_files'])==13",
 'closed_gardner_portable':'closed_implicit_portable',
 "=='3241c70a2b9e3a50ca5287dc05afc778d6f819ff'":" and len(selection['candidate'])==40",
 'CLOSED_GARDNER_STATE12_':'CLOSED_IMPLICIT_STATE13_',
 'ALL_SELECTED_CLOSED_GARDNER_LOCAL':'ALL_SELECTED_CLOSED_IMPLICIT_LOCAL',
 'FINITE_CASE_PLAN_V3':'FINITE_CASE_PLAN_V1',
 "len(cohort['contexts'])==17":"len(cohort['contexts'])==14",
 'projection=json.loads(store.get(\'COMPILED_PROJECTION_V1.json\'));contexts=[]':"projection=json.loads(store.get('COMPILED_PROJECTION_V1.json'));contexts=[];original_store=OriginalInputs(stack)",
 'observe(profile,build=build,inputs=inputs,controls=controls)':'observe(profile,build=build,inputs=inputs,controls=controls,original_store=original_store)',
 "assert (counts['context_count'],counts['primary_days'],counts['native_samples'],counts['exact_cold_windows'],counts['compiled_native_refusals'])==(17,595,119,60,285)":"assert (counts['context_count'],counts['primary_days'],counts['native_samples'])==(14,490,98)\n        assert counts['exact_cold_windows']>=42 and counts['compiled_native_refusals']>=14*3",
 'SEVENTEEN_ACTUAL_PORTABLE_CLOSED_GARDNER':'FOURTEEN_ACTUAL_PORTABLE_CLOSED_IMPLICIT',
 }
for before,after in replacements.items():
    assert before in body,before;body=body.replace(before,after)
compile(body,'closed_implicit_state_portable_science.py','exec')
target=E/'closed-implicit-state13-portable-science.draft.py';assert not target.exists();target.write_text(body,encoding='utf8')
print('DRAFT_PORTABLE_AUDITOR_CREATED',flush=True)
