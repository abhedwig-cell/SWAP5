from pathlib import Path
E=Path(__file__).parent;body=(E/'closed-gardner-state12-real-negative-controls-v2.py').read_text()
for a,b in [('CLOSED_GARDNER_STATE12','CLOSED_IMPLICIT_STATE13'),('nomacro-closed-gardner12-negative-','nomacro-closed-implicit13-negative-'),('nomacro-closed-gardner-state12','nomacro-closed-implicit-state13'),('IMPLICIT_HYDRAULIC_STATE11_ADMISSION_RAW_V1.zip','CLOSED_GARDNER_STATE12_ADMISSION_RAW_V1.zip'),('NEVER MERGE closed Gardner ','NEVER MERGE closed implicit '),('FINAL1','FINAL1')]:
    assert a in body,a;body=body.replace(a,b)
target=E/'closed-implicit-state13-real-negative-controls-v1.py';assert not target.exists();compile(body,target.name,'exec');target.write_text(body,encoding='utf8');print('FOUR_NEVER_MERGE_REAL_COMMIT_NEGATIVE_CONTROLS_PREPARED_NOT_EXECUTED',flush=True)
