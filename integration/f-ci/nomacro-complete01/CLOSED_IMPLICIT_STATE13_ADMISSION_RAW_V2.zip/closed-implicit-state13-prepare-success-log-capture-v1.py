from pathlib import Path
E=Path(__file__).parent
body=(E/'closed-implicit-state13-capture-first-ci-original-logs-v1.py').read_text()
body=body.replace('7c6a0ef700e1e94ff10b265fb4df0bca1babaa74','62cf6eefb110099ab1c181b06f2a5ae74b48f144').replace('closure13-first-ci-original-logs-v1','closure13-portable-ci-original-logs-v1')
body=body.replace('[(46018822331,140572814035),(46018822331,140572814598),(46018822402,140572814473),(46018822402,140572814635)]','[(46020246228,140577714527),(46020246228,140577715122),(46020246319,140577715220),(46020246319,140577715748)]')
body=body.replace("job['conclusion']=='failure'","job['conclusion']=='success'")
body=body.replace("steps['Preserve real source and prepare original provider']=='failure' and steps['Run finite ordinary Snow Frost cohort and compiled native refusals']=='skipped'","steps['Preserve real source and prepare original provider']=='success' and steps['Run finite ordinary Snow Frost cohort and compiled native refusals']=='success' and steps['Independently read exact physical native cold and transaction evidence']=='success'")
body=body.replace("b'missing owning authority' in log","b'ALL_SELECTED_CLOSED_IMPLICIT_LOCAL_CONTEXTS_AND_NATIVE_CONTROLS_PASS_NOT_QUALIFIED' in log")
body=body.replace(",model_executions=0,project_compiler_executions=0,refusal='missing owning authority in actual sparse checkout'",",conclusion='success',scientific_roles_preserved=True")
body=body.replace('FOUR_ORIGINAL_FAILED_CI_PREFLIGHT_UTF8_LOGS_AND_OFFICIAL_API_BYTES_PRESERVED_ZERO_MODELS','FOUR_ORIGINAL_SUCCESSFUL_PORTABLE_UTF8_LOGS_AND_OFFICIAL_API_BYTES_PRESERVED')
target=E/'closed-implicit-state13-capture-portable-original-logs-v1.py';assert not target.exists();target.write_text(body,encoding='utf8')
