"""Preserve the failed packing inventory and omit duplicate unadmitted ZIP-byte copies."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_boundary_git_archive import GitArchiveSource
SHA=lambda raw:hashlib.sha256(raw).hexdigest();M='ae54d7d621a07e54dd8f9fdb758585b2a2cc754d';source=GitArchiveSource(R,M)
failed=E/'CLOSED_IMPLICIT_STATE13_ADMISSION_RAW_V1.zip';members={}
with zipfile.ZipFile(failed) as z:
    assert z.testzip() is None
    for name in z.namelist():
        raw=z.read(name);members[name]=dict(bytes=len(raw),sha256=SHA(raw))
duplicates=[];descriptor=json.loads((source/'CLOSED_IMPLICIT_STATE13_FORTY_NATIVE_PRESERVATION_RAW_V8.json').read_text());assert descriptor['sha256']=='1e07ff4764eeae2c5f705a1985d1897237f6c50fc7145abc196f4fa23df9cd68'
for path in sorted(E.glob('CLOSED_IMPLICIT_STATE13_*.zipbytes')):
    raw=path.read_bytes();assert path.name in members;matches=[v for v in descriptor['parts'] if len(raw)==v['bytes'] and SHA(raw)==v['sha256']];assert len(matches)==1 and (source/matches[0]['file']).read_bytes()==raw
    duplicates.append(dict(unadmitted_working_copy=path.name,bytes=len(raw),sha256=SHA(raw),actual_retained_Git_revision=M,actual_retained_Git_file=matches[0]['file'],actual_Git_bytes_equal=True))
assert len(duplicates)==3
q=dict(status='ADMISSION_PACKAGING_ONLY_FAILURE_ALL_QUALIFICATION_GATES_ALREADY_PASSED_DUPLICATE_NATIVE_PART_COPIES_EXCLUDED_FROM_RECOVERY',failed_controller='closed-implicit-state13-admission-seal-v1.py',failed_archive=failed.name,failed_archive_bytes=failed.stat().st_size,failed_archive_sha256=SHA(failed.read_bytes()),failed_archive_members=members,diagnosis='The top-level file collector included three old .zipbytes spelling-recovery copies of the already retained native V8 archive. The completed ZIP therefore exceeded the48MiB single-part packing cap. No source or scientific result failed.',duplicate_parts=duplicates,original_failed_zip_retained_locally=True,all_original_sources_or_scientific_roles_rebound=False,compiler_executions=0,model_executions=0)
target=E/'CLOSED_IMPLICIT_STATE13_ADMISSION_PACKAGING_RECOVERY_V2.json';assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
body=(E/'closed-implicit-state13-admission-seal-v1.py').read_text();before="path.suffix in ['.zip','.tar','.gz','.xz']";assert before in body;body=body.replace(before,"path.suffix in ['.zip','.tar','.gz','.xz','.zipbytes']").replace("stem='CLOSED_IMPLICIT_STATE13_ADMISSION_RAW_V1'","stem='CLOSED_IMPLICIT_STATE13_ADMISSION_RAW_V2'")
target=E/'closed-implicit-state13-admission-seal-v2.py';assert not target.exists();compile(body,target.name,'exec');target.write_text(body,encoding='utf8');print('PACKING_RECOVERY_PRESERVED_ACTUAL_GIT_DUPLICATES_ONLY',len(duplicates),failed.stat().st_size,len(members),flush=True)
