"""Release only owned inactive copies after actual Git ZIP member byte comparison."""
from contextlib import ExitStack
from pathlib import Path
import hashlib,json,subprocess,sys,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';P='integration/f-ci/nomacro-complete01/'
TOOL=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');HOME=TOOL.parents[2]
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive
from frost_boundary_git_archive import GitArchiveSource
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
C=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
audit=json.loads((E/'CLOSED_IMPLICIT_STATE13_REPAIRED_LOCAL_ACTUAL_GIT_ARCHIVE_STRICT_AUDIT_V1.json').read_text());assert audit['raw_sha256']=='bb345b239044957f390efd1bb193bff3cb89d36b9162aebe6fdc9ade67117f6f' and len(audit['contexts'])==4
ref='refs/heads/codex/storage-retained/closure13-local-failure-and-success-20261127';git('update-ref',ref,C)
state=json.loads(Path('C:/Users/Veldh012/.codex/storage/swap5/state.json').read_text());active={'closure13-native-preservation-O0-v2','closure13-native-preservation-O2-v2'}
resources=[v for v in state['resources'].values() if v['task']==TASK and v['kind'] in ['build','debug','temp'] and not v['released'] and Path(v['path']).name.startswith('closure13-') and Path(v['path']).name not in active]
resources.sort(key=lambda v:v['registered'])
record=dict(status='CHECKING_OWN_INACTIVE_COPIES_AGAINST_ACTUAL_GIT_ARCHIVED_BYTES',actual_Git_source=C,retained_ref=ref,task=TASK,task_remains_active=True,active_dependencies_preserved=sorted(active),archives=[],resources=[],release_commands=[],unknown_or_unarchived_resources_retained=True)
target=E/'CLOSED_IMPLICIT_STATE13_RELEASE_ARCHIVED_RESOURCES_V1.json';save=lambda:target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');save()
with ExitStack() as stack:
    source=GitArchiveSource(R,C);index={};stores={}
    for path in sorted((R/P).glob('CLOSED_IMPLICIT_STATE13_*RAW*.json')):
        q=json.loads(git('show',C+':'+P+path.name))
        if not isinstance(q.get('members'),dict) or not q.get('parts'):continue
        stem=path.stem;store=Archive(source,stem,stack);stores[stem]=store
        assert store.z.testzip() is None
        record['archives'].append(dict(name=stem,sha256=store.record['sha256'],members=len(store.names)))
        for name,item in store.names.items():index.setdefault((item['bytes'],item['sha256']),[]).append((stem,name))
    save()
    for resource in resources:
        path=Path(resource['path']);assert path.resolve().parent==W.resolve() and path.is_dir() and not path.is_symlink()
        row=dict(path=str(path),kind=resource['kind'],registered_source_ref=resource.get('source_ref'),registered_recipe=resource.get('recipe'),files=[],unmatched=[])
        for file in sorted(path.rglob('*')):
            if not file.is_file():continue
            assert not file.is_symlink();raw=file.read_bytes();digest=SHA(raw);candidates=index.get((len(raw),digest),[])
            relative=file.relative_to(W).as_posix();preferred=[v for v in candidates if v[1]=='actual/'+relative];candidates=preferred or candidates
            if not candidates:row['unmatched'].append(file.relative_to(path).as_posix());continue
            stem,name=candidates[0];assert stores[stem].get(name)==raw
            row['files'].append(dict(path=file.relative_to(path).as_posix(),bytes=len(raw),sha256=digest,recovery_archive=stem,recovery_member=name))
        row['decision']='RETAIN_UNMATCHED_BYTES' if row['unmatched'] else 'RELEASE_EXACT_GIT_ARCHIVED_COPY';record['resources'].append(row);save()
        if not row['unmatched']:
            command=[sys.executable,'-B',str(TOOL),'release','--task',TASK,'--path',str(path)];run=subprocess.run(command,cwd=HOME,capture_output=True);record['release_commands'].append(dict(path=str(path),returncode=run.returncode,stdout=run.stdout.decode(),stderr=run.stderr.decode()));save();run.check_returncode()
        print(path.name,row['decision'],len(row['files']),len(row['unmatched']),flush=True)
preview=subprocess.run([sys.executable,'-B',str(TOOL),'cleanup','--task',TASK],cwd=HOME,capture_output=True);preview.check_returncode();report=json.loads(preview.stdout);record['cleanup_preview']=report;save()
eligible=[v for v in report['results'] if v['status'].startswith('eligible')]
if eligible:
    run=subprocess.run([sys.executable,'-B',str(TOOL),'cleanup','--apply','--task',TASK],cwd=HOME,capture_output=True,timeout=180)
    record['cleanup_apply_returncode']=run.returncode;record['cleanup_apply']=json.loads(run.stdout);record['cleanup_apply_stderr']=run.stderr.decode();save()
assert git('rev-parse','HEAD').decode().strip()==C
record['status']='OWN_EXACT_ARCHIVED_INACTIVE_COPIES_RELEASED_ACTIVE_TASK_AND_DEPENDENCIES_PRESERVED';save()
print(record['status'],sum(v['decision'].startswith('RELEASE') for v in record['resources']),sum(v['decision'].startswith('RETAIN') for v in record['resources']),flush=True)
