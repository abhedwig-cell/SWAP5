"""Release owned inactive builds only after exact real Git-archive byte comparison."""
from contextlib import ExitStack
from pathlib import Path
import json,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';C='2d810e6db3acf6eb81ff96dae90859670eae9b3a';TOOL=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');workspace=TOOL.parents[2]
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
git=lambda *v:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*v],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
state=json.loads(Path('C:/Users/Veldh012/.codex/storage/swap5/state.json').read_text());q=dict(status='VERIFYING_INACTIVE_NATIVE_BUILDS_WITH_RETAINED_ACTUAL_GIT_ARCHIVE',actual_archive_revision=C,task=TASK,task_remains_active=True,resources=[],commands=[])
target=E/'CLOSED_IMPLICIT_STATE13_NATIVE_PRESERVATION_RESOURCE_RELEASE_V2.json';assert not target.exists();save=lambda:target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');save()
with ExitStack() as stack:
    store=Archive(GitArchiveSource(R,C),'CLOSED_IMPLICIT_STATE13_FORTY_NATIVE_PRESERVATION_RAW_V8',stack);assert store.record['sha256']=='1e07ff4764eeae2c5f705a1985d1897237f6c50fc7145abc196f4fa23df9cd68'
    for opt in ['O0','O2']:
        root=W/('closure13-native-preservation-'+opt+'-v2');rows=[v for v in state['resources'].values() if v['task']==TASK and Path(v['path']).resolve()==root.resolve()];assert len(rows)==1 and rows[0]['kind']=='build' and not rows[0]['released'];files=[]
        for path in sorted(root.rglob('*')):
            if not path.is_file():continue
            name='actual/'+path.relative_to(W).as_posix();raw=path.read_bytes();assert name in store.names and store.get(name)==raw;files.append(dict(path=path.relative_to(root).as_posix(),archive_member=name,bytes=len(raw),sha256=SHA(raw)))
        assert files;q['resources'].append(dict(path=str(root),source_ref=rows[0]['source_ref'],recipe=rows[0]['recipe'],archive_sha256=store.record['sha256'],files=files));save()
git('update-ref','refs/heads/codex/storage-retained/closure13-native-preservation-20261127',C)
def cli(*args):
    child=subprocess.run([sys.executable,'-B',str(TOOL),*args],cwd=workspace,capture_output=True,text=True,timeout=180);q['commands'].append(dict(arguments=list(args),returncode=child.returncode,stdout=child.stdout,stderr=child.stderr));save();child.check_returncode();return json.loads(child.stdout)
for item in q['resources']:cli('release','--task',TASK,'--path',item['path'])
preview=cli('cleanup','--task',TASK);q['preview']=preview;save()
if any(v.get('status')=='eligible' for v in preview.get('decisions',[])):q['applied']=cli('cleanup','--apply','--task',TASK)
q['status']='TWO_OWN_INACTIVE_NATIVE_BUILDS_RELEASED_AFTER_EXACT_GIT_ARCHIVE_COMPARISON_TASK_ACTIVE';save();print(q['status'],[(Path(v['path']).name,len(v['files'])) for v in q['resources']],flush=True)
