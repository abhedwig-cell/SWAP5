from pathlib import Path
import json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()=='62cf6eefb110099ab1c181b06f2a5ae74b48f144';paths=[]
for row in git('status','--porcelain=v1','-z','--untracked-files=all').split(b'\0'):
    if not row:continue
    path=row[3:].decode();assert path.startswith(('tests/nomacro_drainage/closed_implicit_state_','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_')) or path in ['docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md','integration/f-ci/nomacro-complete01/STATUS.json','integration/f-ci/nomacro-complete01/GAP_MATRIX.json','tests/nomacro_drainage/initial_profile_age_groundwater_verify.py'];paths.append(path)
git('add','--sparse','--',*paths);git('diff','--cached','--check');print('STAGED_OWN_ARCHIVES_WITH_EXISTING_SPARSE_RULES_UNCHANGED',len(paths),flush=True);print(git('commit','-m','Qualify closed implicit original native and portable scientific ownership').decode(),flush=True)
anchor=git('rev-parse','HEAD').decode().strip();(E/'CLOSED_IMPLICIT_STATE13_OWNING_ANCHOR_V1.json').write_text(json.dumps(dict(actual_anchor=anchor,files=len(paths),formal_candidate_admission_pending=True),indent=2)+'\n',encoding='utf8');print('ACTUAL_OWNING_ANCHOR',anchor,flush=True)
