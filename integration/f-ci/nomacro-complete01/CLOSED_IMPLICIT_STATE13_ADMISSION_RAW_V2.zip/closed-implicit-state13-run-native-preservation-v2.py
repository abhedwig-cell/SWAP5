from pathlib import Path
import json,os,subprocess,sys,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');opt=sys.argv[1];C='62cf6eefb110099ab1c181b06f2a5ae74b48f144';git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
root=E/'closure13-native-preservation-v2'/opt;root.mkdir(parents=True);build=W/('closure13-native-preservation-'+opt+'-v2');env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1',TEMP=str(W/'active-python-scratch-v2'),TMP=str(W/'active-python-scratch-v2'));env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH'];summary=dict(actual_compiler_source=C,optimization=opt,old_model_periods_replayed=0,phases=[])
for role,script in [('current','closed_implicit_state_postimages.py'),('parent','implicit_hydraulic_state_parent_postimages.py')]:
    command=[sys.executable,'-B','tests/nomacro_drainage/'+script,'--output',str(root/role),'--build-root',str(build/role),'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--optimization',opt];started=time.perf_counter()
    with (root/(role+'.stdout')).open('xb') as out,(root/(role+'.stderr')).open('xb') as err:run=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=1800)
    summary['phases'].append(dict(role=role,returncode=run.returncode,seconds=time.perf_counter()-started));(root/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8');print(role,opt,run.returncode,flush=True)
    assert git('rev-parse','HEAD').decode().strip()==C
assert all(v['returncode']==0 for v in summary['phases'])
