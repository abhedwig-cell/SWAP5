from pathlib import Path
import importlib.util,json,sys,time
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
if sys.argv[1]=='portable':
    spec=importlib.util.spec_from_file_location('proposed_portable',E/'closed-implicit-state13-portable-science.draft.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    for platform in ['Ubuntu','Windows']:
        for opt in ['O0','O2']:
            started=time.perf_counter();q=module.audit(E,platform,opt);name='CLOSED_IMPLICIT_STATE13_FIRST_'+platform.upper()+'_'+opt+'_INDEPENDENT_V1.json';target=E/name;assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(platform,opt,q['context_count'],q['primary_days'],q['native_samples'],q['exact_cold_windows'],q['compiled_native_refusals'],round(time.perf_counter()-started,2),flush=True)
else:
    from closed_implicit_state_preservation_science import audit
    q=audit(E);target=E/'CLOSED_IMPLICIT_STATE13_FORTY_NATIVE_PRESERVATION_INDEPENDENT_V1.json';assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],q['counts'],flush=True)
