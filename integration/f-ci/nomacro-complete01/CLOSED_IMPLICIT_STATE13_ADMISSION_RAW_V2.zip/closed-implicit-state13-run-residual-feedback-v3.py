from pathlib import Path
import json,os,subprocess,sys,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');opt=sys.argv[1];C='ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
cases=['closed-frost-mixed4-5-cde','closed-ordinary-model6-snow-cde-profile'] if opt=='O0' else ['closed-frost-mixed8-9-water','closed-ordinary-model5-cde-profile']
root=E/'closure13-residual-feedback-v3'/opt;root.mkdir(parents=True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1',TEMP=str(W/'active-python-scratch-v2'),TMP=str(W/'active-python-scratch-v2'));env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
summary=dict(actual_source=C,optimization=opt,cases=[],original_inputs_and_calendars_unchanged=True,new_numerical_policy='original-closed-implicit-residual-start-and-conditional-convergence-v3',original_tolerances_unchanged=True,canonical_admission=False)
for name in cases:
    command=[sys.executable,'-B','tests/nomacro_drainage/closed_implicit_state_feedback.py','--case',name,'--optimization',opt,'--output',str(root/name),'--build-output',str(W/('closure13-residual-feedback-'+opt+'-v3')/'current'/name),'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider']
    start=time.perf_counter()
    with (root/(name+'.stdout')).open('xb') as out,(root/(name+'.stderr')).open('xb') as err:run=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=700)
    result=json.loads((root/name/'RESULT.json').read_text());record=dict(case=name,returncode=run.returncode,seconds=time.perf_counter()-start,status=result['status'],error=result.get('error'));summary['cases'].append(record)
    (root/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8');print(name,run.returncode,result['status'],result.get('error',''),flush=True)
    assert git('rev-parse','HEAD').decode().strip()==C
    if run.returncode==0:
        controls=[sys.executable,'-B','tests/nomacro_drainage/closed_implicit_state_native_controls.py','--profile',str(root/name),'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--output',str(root/(name+'-native-controls'))]
        with (root/(name+'-controls.stdout')).open('xb') as out,(root/(name+'-controls.stderr')).open('xb') as err:check=subprocess.run(controls,cwd=R,env=env,stdout=out,stderr=err,timeout=120)
        record['native_controls_returncode']=check.returncode;(root/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8');print(name,'native controls',check.returncode,flush=True)
assert all(v['returncode']==0 and v.get('native_controls_returncode')==0 for v in summary['cases'])
