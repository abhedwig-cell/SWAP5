from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='7c6a0ef700e1e94ff10b265fb4df0bca1babaa74';SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
logs=E/'closure13-first-ci-original-logs-v1';artifacts=E/'closure13-first-ci-artifacts-v1';custody=json.loads((logs/'CUSTODY.json').read_text());records=json.loads((artifacts/'ORIGINAL_CONNECTOR_ARTIFACTS.json').read_text());assert len(records)==len(custody['jobs'])==4 and custody['actual_producer']==C
for item in records:
    payload=(artifacts/item['file']).read_bytes();assert SHA(payload)==item['sha256']
    with zipfile.ZipFile(artifacts/item['file']) as z:
        assert set(z.namelist())=={'COMPILED_PROJECTION_V1.json','actual-test-selection.json'} and json.loads(z.read('COMPILED_PROJECTION_V1.json'))=={} and z.read('actual-test-selection.json')==b''
    matching=[row for row in custody['jobs'] if item['sha256'].encode() in (logs/('job-'+str(row['job_id'])+'.original.log')).read_bytes()];assert len(matching)==1
    assert str(item['artifact_id']).encode() in (logs/('job-'+str(matching[0]['job_id'])+'.original.log')).read_bytes()
name='CLOSED_IMPLICIT_STATE13_FIRST_PORTABLE_PREFLIGHT_FAILURES_RAW_V7';target=E/(name+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in [logs,artifacts]:
        for p in sorted(root.rglob('*')):
            if p.is_file():
                raw=p.read_bytes();key=root.name+'/'+p.relative_to(root).as_posix();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=git('archive','--format=zip',C,'.github/workflows/nomacro-closed-implicit-state13-windows.yml','.github/workflows/nomacro-closed-implicit-state13-ubuntu.yml','app','src','tools','tests/nomacro_drainage','docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md','integration/f-ci/nomacro-complete01/STATUS.json');key='observer-genuine-producer-Git-source.zip';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    for path in E.iterdir():
        if path.is_file() and path.name.startswith('closed-implicit-state13-') and path.suffix=='.py':
            raw=path.read_bytes();key='controllers/'+path.name;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for key,item in members.items():assert SHA(z.read(key))==item['sha256'] and len(z.read(key))==item['bytes']
raw=target.read_bytes();q=dict(status='FOUR_ORIGINAL_WINDOWS_UBUNTU_O0_O2_CI_PREFLIGHT_FAILURES_MISSING_MATERIALIZED_AUTHORITY_PRESERVED',actual_producer=C,runs=[46018822331,46018822402],archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,project_compiler_executions=0,model_executions=0,scientific_input_decks_executed=0,actual_CI_artifacts_verified_against_official_digests_and_original_logs=True,observer_Git_source_capsule_is_not_a_CI_checkout_projection=True,scientific_source_or_producer_roles_rebound=False,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(len(raw),q['sha256'],len(members),flush=True)
