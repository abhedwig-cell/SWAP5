"""Retain actual forty compiler/native consumers without replaying old periods."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='62cf6eefb110099ab1c181b06f2a5ae74b48f144';SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
counts=dict(contexts=0,whole_objects=0,unchanged_whole_objects=0,changed_static_guard_objects=0,compiled_native_positive_controls=0,compiled_native_refusals=0,old_model_days_replayed=0)
for opt in ['O0','O2']:
    s=json.loads((E/'closure13-native-preservation-v2'/opt/'SUMMARY.json').read_text());assert s['actual_compiler_source']==C and all(v['returncode']==0 for v in s['phases'])
    for role,n in [('current',12),('parent',8)]:
        q=json.loads((E/'closure13-native-preservation-v2'/opt/role/'RESULT.json').read_text());assert len(q['contexts'])==n and q['model_days']==q['model_executions']==0
        for item in q['contexts']:
            total=len(item['whole_objects']);changed=len(item.get('current_native_guard_proof',{}).get('static_guard_object_changes',[]));counts['contexts']+=1;counts['whole_objects']+=total;counts['unchanged_whole_objects']+=total-changed;counts['changed_static_guard_objects']+=changed
            control=item.get('current_compiled_original_native_controls',{})
            if control.get('selected'):
                assert control['status'].startswith('CURRENT_STATIC_GUARD_EXACT_ORIGINAL_NATIVE_POSITIVE')
                counts['compiled_native_positive_controls']+=1;counts['compiled_native_refusals']+=len(control['controls'])
assert counts['contexts']==40 and counts['whole_objects']==1046
stem='CLOSED_IMPLICIT_STATE13_FORTY_NATIVE_PRESERVATION_RAW_V8';target=E/(stem+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in [E/'closure13-native-preservation-v2',W/'closure13-native-preservation-O0-v2',W/'closure13-native-preservation-O2-v2']:
        for path in sorted(root.rglob('*')):
            if path.is_file():
                raw=path.read_bytes();key='actual/'+path.relative_to(W).as_posix();assert key not in members;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=git('archive','--format=zip',C,'app','src','tools','tests/nomacro_drainage','docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md');key='source/actual-62cf-controller-and-physical-source.zip';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for key,v in members.items():
        raw=z.read(key);assert len(raw)==v['bytes'] and SHA(raw)==v['sha256']
raw=target.read_bytes();parts=[];limit=48*1024**2
for index,start in enumerate(range(0,len(raw),limit)):
    chunk=raw[start:start+limit];name=stem+'.part'+str(index+1).zfill(2)+'.zipbytes';path=E/name;assert not path.exists();path.write_bytes(chunk);parts.append(dict(file=name,bytes=len(chunk),sha256=SHA(chunk)))
q=dict(status='FORTY_ACTUAL_COMPILER_CONSUMERS_NUMERICAL_WHOLE_OBJECTS_AND_ORIGINAL_NATIVE_CONTROLS_PRESERVED',actual_compiler_source=C,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,counts=counts,canonical_admission=False,new_qualified_contexts=0,new_admitted_contexts=0,original_scientific_identities_preserved=True)
(E/(stem+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['bytes'],q['sha256'],len(members),counts,flush=True)
