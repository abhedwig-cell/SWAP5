from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).parent;root=E/'closure13-portable-ci-artifacts-v1';C='62cf6eefb110099ab1c181b06f2a5ae74b48f144';SHA=lambda b:hashlib.sha256(b).hexdigest()
specs=[('UBUNTU','O0',46020246228,15208208109,'5cb07b812de86d17a6b4707c830d3175be3769c3a0d5394869a1786705ff4b7c'),('UBUNTU','O2',46020246228,15207653766,'fb9e26e6918d1f336d44ecabfdfcf156b462d1cab9ee82bd594df3ea6b121a76'),('WINDOWS','O0',46020246319,15207459491,'50d949e9d4b70b3ce81dbe16799f7674adb12d5127c9a8a4bcf89f62fd192626'),('WINDOWS','O2',46020246319,15210630271,'72e2d624d54e0b60e27008f2fce6c4c5dcd4f0f8232f6e5619209ee5b9c7b89b')]
for platform,opt,run_id,artifact_id,digest in specs:
    raw=(root/('artifact-'+str(artifact_id)+'.zip')).read_bytes();assert SHA(raw)==digest;members={};stem='CLOSED_IMPLICIT_STATE13_FIRST_'+platform+'_'+opt+'_ORIGINAL_V1'
    with zipfile.ZipFile(root/('artifact-'+str(artifact_id)+'.zip')) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        for name in z.namelist():
            content=z.read(name);members[name]=dict(bytes=len(content),sha256=SHA(content))
        cohort=json.loads(z.read('current/RESULT.json'));science=json.loads(z.read('INDEPENDENT_SCIENCE.json'))
        assert cohort['actual_source']==C and len(cohort['contexts'])==14 and all(v['status']=='PASS_NOT_QUALIFIED' for v in cohort['contexts'])
        assert len(science['contexts'])==14 and science['status'].startswith('INDEPENDENT_CLOSED_IMPLICIT_ORIGINAL_INPUTS')
    parts=[];limit=48*1024**2
    for index,start in enumerate(range(0,len(raw),limit)):
        chunk=raw[start:start+limit];name=stem+'.zip.part'+str(index+1).zfill(3);target=E/name;assert not target.exists();target.write_bytes(chunk);parts.append(dict(file=name,bytes=len(chunk),sha256=SHA(chunk)))
    q=dict(status='ORIGINAL_SUCCESSFUL_PORTABLE_CI_ARTIFACT_BYTES_PRESERVED_NOT_CANONICALLY_ADMITTED',actual_producer_source=C,actual_workflow_run=run_id,actual_artifact_id=artifact_id,official_GitHub_artifact_sha256=digest,archive=stem+'.zip',bytes=len(raw),sha256=digest,parts=parts,members=members,source_identity_rewritten=False,scientific_role='first full portable fourteen-context successes after genuine preflight-only failures',canonical_admission=False)
    target=E/(stem+'.json');assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(platform,opt,len(raw),len(members),digest,flush=True)
