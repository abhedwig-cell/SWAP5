"""Retain genuine previous negative commit/tree bytes for offline inherited custody."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='07cb2850e2cd45deb1e197161409a3784a8975e7';TREE='8df17cc12686e8ab5522360b87f6430a345aabdb';git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest();objects={}
negative=json.loads((E/'CLOSED_GARDNER_STATE12_FINAL1_NEGATIVES_V3.json').read_text());custody=json.loads((E/'CLOSED_GARDNER_STATE12_FINAL1_NEGATIVE_GIT_CUSTODY_V1.json').read_text());assert negative['candidate']==C and len(negative['controls'])==4
def get(kind,digest):
    key=kind+'/'+digest
    if key not in objects:
        raw=git('cat-file',kind,digest);assert hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==digest;objects[key]=raw
    return objects[key]
def headers(raw):
    block=raw.split(b'\n\n',1)[0].splitlines();return dict(tree=next(v[5:].decode() for v in block if v.startswith(b'tree ')),parents=[v[7:].decode() for v in block if v.startswith(b'parent ')])
def entries(digest):
    raw=get('tree',digest);pos=0;result={}
    while pos<len(raw):
        space=raw.index(b' ',pos);zero=raw.index(b'\0',space);name=raw[space+1:zero].decode();mode=raw[pos:space].decode();child=raw[zero+1:zero+21].hex();assert len(raw[zero+1:zero+21])==20 and name not in result
        result[name]=(mode,child);pos=zero+21
    assert pos==len(raw);return result
def delta(left,right,prefix=''):
    if left==right:return []
    a,b=entries(left),entries(right);assert a.keys()==b.keys();changes=[]
    for name in a:
        mode,x=a[name];other,y=b[name];assert mode==other
        if x!=y:
            path=prefix+name
            if mode=='40000':changes.extend(delta(x,y,path+'/'))
            else:assert mode=='100644';changes.append(dict(path=path,original_blob=x,mutant_blob=y))
    return changes
base=headers(get('commit',C));assert base['tree']==TREE
records=[]
for item in negative['controls']:
    head=item['head'];h=headers(get('commit',head));assert h['parents']==[C];changes=delta(TREE,h['tree']);assert len(changes)==1 and changes[0]['path']==item['path']
    actual=next(v for v in custody['controls'] if v['role']==item['role']);assert actual['actual_head']==head and actual['path']==item['path'] and actual['exact_parent']==C
    assert git('diff','--name-only',C,head).decode().splitlines()==[item['path']]
    records.append(dict(role=item['role'],head=head,exact_parent=C,tree=h['tree'],delta=changes[0],original_actual_Git_byte_custody=actual))
name='CLOSED_IMPLICIT_STATE13_PARENT_NEGATIVE_GENUINE_GIT_OBJECTS_V1';target=E/(name+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for key,raw in sorted(objects.items()):
        member='objects/'+key+'.bin';z.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=json.dumps(records,indent=2).encode();z.writestr('NEGATIVE_OBJECT_RECORDS.json',raw);members['NEGATIVE_OBJECT_RECORDS.json']=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for key,item in members.items():assert SHA(z.read(key))==item['sha256'] and len(z.read(key))==item['bytes']
raw=target.read_bytes();q=dict(status='FOUR_GENUINE_PRIOR_NEGATIVE_COMMIT_AND_EXACT_ONE_FILE_TREE_OBJECT_DELTAS_RETAINED_NO_HEAD_SUBSTITUTION',candidate=C,candidate_tree=TREE,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,records=records,raw_scientific_blobs_not_duplicated=True,Git_refs_or_HEAD_changed=False,compiler_executions=0,model_executions=0)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(len(raw),q['sha256'],len(objects),flush=True)
