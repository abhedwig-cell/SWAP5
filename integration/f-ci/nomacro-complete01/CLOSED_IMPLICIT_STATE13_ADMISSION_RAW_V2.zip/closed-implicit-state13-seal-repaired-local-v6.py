from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30';SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
science=json.loads((E/'CLOSED_IMPLICIT_STATE13_REPAIRED_LOCAL_FOUR_INDEPENDENT_SCIENCE_V3.json').read_text());assert len(science['contexts'])==4 and science['status'].startswith('INDEPENDENT_CLOSED_IMPLICIT_')
for opt in ['O0','O2']:
    batch=json.loads((E/'closure13-residual-feedback-v3'/opt/'SUMMARY.json').read_text());assert len(batch['cases'])==2 and all(v['returncode']==v['native_controls_returncode']==0 for v in batch['cases'])
name='CLOSED_IMPLICIT_STATE13_REPAIRED_LOCAL_FOUR_RAW_V6';target=E/(name+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in [E/'closure13-residual-feedback-v3',W/'closure13-residual-feedback-O0-v3',W/'closure13-residual-feedback-O2-v3']:
        for p in sorted(root.rglob('*')):
            if p.is_file():
                raw=p.read_bytes();key='actual/'+p.relative_to(W).as_posix();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=git('archive','--format=zip',C,'app','src','tools','tests/nomacro_drainage','docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V7.json','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json');key='source/actual-ae8dd-controller-and-physical-source.zip';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    for p in sorted(E.iterdir()):
        if p.is_file() and p.suffix in ('.py','.json') and p.name.startswith(('CLOSED_IMPLICIT_STATE13_','closed-implicit-state13-')) and p.name!=name+'.json':
            raw=p.read_bytes();key='controllers-and-observations/'+p.name;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for key,item in members.items():assert SHA(z.read(key))==item['sha256'] and len(z.read(key))==item['bytes']
raw=target.read_bytes();assert len(raw)<48*1024**2
counts=dict(contexts=4,primary_days=sum(v['days'] for v in science['contexts']),native_samples=sum(len(v['native_samples']) for v in science['contexts']),exact_cold_windows=sum(len(v['exact_cold_windows']) for v in science['contexts']),compiled_native_refusals=sum(v['compiled_native_refusals'] for v in science['contexts']),external_transaction_contexts=4)
q=dict(status='FOUR_ACTUAL_PRODUCTION_REPAIRED_CLOSED_IMPLICIT_COUPLINGS_INDEPENDENTLY_PASS_NOT_PORTABLY_QUALIFIED',actual_scientific_producer_source=C,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,counts=counts,new_qualified_contexts=0,new_admitted_contexts=0,additional_local_contexts_not_counted_again=True,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(len(raw),q['sha256'],counts,len(members),flush=True)
