from contextlib import ExitStack
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';C='62cf6eefb110099ab1c181b06f2a5ae74b48f144';SHA=lambda b:hashlib.sha256(b).hexdigest();sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from closed_implicit_state_local_archive_science import audit as local
from closed_implicit_state_preservation_science import audit as preservation
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C
q=local(GitArchiveSource(R,C));name='CLOSED_IMPLICIT_STATE13_REPAIRED_LOCAL_ARCHIVE_INDEPENDENT_V1.json';assert not (E/name).exists();(E/name).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
q=preservation(E);assert q==json.loads((E/'CLOSED_IMPLICIT_STATE13_FORTY_NATIVE_PRESERVATION_INDEPENDENT_V1.json').read_text());print('CURRENT_STRICT_NATIVE_AND_LOCAL_ARCHIVE_AUDITS_PASS',flush=True)
stems=['CLOSED_IMPLICIT_STATE13_FORTY_NATIVE_PRESERVATION_RAW_V8']+['CLOSED_IMPLICIT_STATE13_FIRST_'+platform+'_'+opt+'_ORIGINAL_V1' for platform in ['UBUNTU','WINDOWS'] for opt in ['O0','O2']]
for stem in stems:
    with ExitStack() as stack:
        store=Archive(E,stem,stack)
        for member in store.names:store.get(member)
    descriptor=json.loads((E/(stem+'.json')).read_text())
    for name in [stem+'.json']+[v['file'] for v in descriptor['parts']]:
        assert not (P/name).exists();shutil.copyfile(E/name,P/name);assert (P/name).read_bytes()==(E/name).read_bytes()
    print('EXACT_ORIGINAL_ARCHIVE_COPIED',stem,flush=True)
names=['CLOSED_IMPLICIT_STATE13_REPAIRED_LOCAL_ARCHIVE_INDEPENDENT_V1.json','CLOSED_IMPLICIT_STATE13_FORTY_NATIVE_PRESERVATION_INDEPENDENT_V1.json','CLOSED_IMPLICIT_STATE13_PROPOSED_PARENT948_ADMISSION_AUDIT_V1.json']+['CLOSED_IMPLICIT_STATE13_FIRST_'+platform+'_'+opt+'_INDEPENDENT_V1.json' for platform in ['UBUNTU','WINDOWS'] for opt in ['O0','O2']]
for name in names:assert not (P/name).exists();shutil.copyfile(E/name,P/name)
stem='CLOSED_IMPLICIT_STATE13_QUALIFICATION_CUSTODY_AND_OBSERVER_RECOVERY_RAW_V9';target=E/(stem+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    paths=list((E/'closure13-portable-ci-original-logs-v1').rglob('*'))+[E/n for n in ['CLOSED_IMPLICIT_STATE13_NATIVE_ARCHIVE_OBSERVER_FAILURE_V1.json','CLOSED_IMPLICIT_STATE13_RELEASE_ARCHIVED_RESOURCES_V1.json','CLOSED_IMPLICIT_STATE13_FORTY_NATIVE_PRESERVATION_RAW_V8_INITIAL_UNADMITTED_DESCRIPTOR.json','closed-implicit-state13-seal-native-preservation-v8.py','closed-implicit-state13-correct-native-part-names-v1.py','closed-implicit-state13-seal-original-portable-v1.py','closed-implicit-state13-capture-portable-original-logs-v1.py','closed-implicit-state13-run-new-archive-auditors-v1.py']]
    for path in paths:
        if path.is_file():
            raw=path.read_bytes();name=path.relative_to(E).as_posix();assert name not in members;z.writestr(name,raw);members[name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name,v in members.items():assert SHA(z.read(name))==v['sha256']
raw=target.read_bytes();assert len(raw)<48*1024**2;q=dict(status='ORIGINAL_SUCCESSFUL_PORTABLE_CI_LOGS_OFFICIAL_API_AND_UNADMITTED_OBSERVER_RECOVERY_BYTES_RETAINED',actual_portable_producer=C,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,scientific_roles_or_producers_rebound=False,canonical_admission=False);(E/(stem+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for name in [target.name,stem+'.json']:assert not (P/name).exists();shutil.copyfile(E/name,P/name)
path=R/'docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md';body=path.read_text();body+='\nActual 62cf6eef portable producer completes all fourteen original-input couplings\non Windows and Ubuntu at O0 and O2. All four independent archive audits pass:\n56 contexts,1960 primary days,392 native samples,176 exact cold windows,1608\ncompiled native refusals and56 external transaction contexts. Original CI ZIP\nbytes match official GitHub artifact digests; source capsules and original SDK\nbytes are independently read. Earlier preflight failures remain RAW V7.\n\nForty current preservation builds pass:1022 whole objects remain byte-identical;\n24 static native guard objects change exactly with their literal source proposal.\nAll24 compiled consumers accept original native states with exact physical\nreceipts and refuse480 independently reconstructed corruptions before READY.\nNo old model period is repeated. RAW V8 retains every actual build/input/control\nbyte. A first archive observer ambiguously selected a native-control receipt as\na primary trajectory; selecting the actual day4 trajectory resolves this\nread-only observer failure, retained in RAW V9. Formal candidate PUBLIC, ordinary\nPython publication, CI admission and real merge receipt remain pending.\nWhole migration PARTIAL; global counts UNKNOWN; fixed RC3 unchanged.\n';path.write_text(body,encoding='utf8')
path=P/'STATUS.json';q=json.loads(path.read_text());q['closed_implicit_state13_portable_candidate']=dict(status='FOUR_ORIGINAL_PORTABLE_AND_INDEPENDENT_ARCHIVE_PROFILES_PASS_FORMAL_ADMISSION_PENDING',actual_portable_producer=C,actual_physical_producer='ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30',contexts=56,primary_days=1960,native_samples=392,exact_cold_windows=176,compiled_native_refusals=1608,external_transaction_contexts=56,preservation_builds=40,unchanged_whole_objects=1022,changed_static_native_guard_objects=24,original_native_positive_controls=24,original_native_compiled_refusals=480,old_model_periods_replayed=0,admitted_new_contexts=0,canonical_admission=False,new_numerical_policy=True,physical_equations_changed=False,global_functional_completion='PARTIAL',scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False);path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print('QUALIFIED_RAW_ARCHIVES_AND_COMPACT_RESULTS_STAGED_WITHOUT_REBINDING_PRODUCERS',len(members),len(raw),SHA(raw),flush=True)
