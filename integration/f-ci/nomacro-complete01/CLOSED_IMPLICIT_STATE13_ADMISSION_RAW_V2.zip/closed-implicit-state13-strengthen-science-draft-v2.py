from pathlib import Path
import ast
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');text=(R/'tests/nomacro_drainage/closed_implicit_state_science.py').read_text()
needle="        assert b'HYBRID_READY' in (controls/'genuine-own-positive/donor.stdout').read_bytes() and not (controls/'genuine-own-positive/donor.stderr').read_bytes()\n"
assert text.count(needle)==1
extra='''        original_receipt,original_payload=payload(folder/'trajectory/accepted-column-1-day-4.zip')
        good=original_payload['macro.bin'];assert c['original_checkpoint_sha256']==SHA((folder/'trajectory/accepted-column-1-day-4.zip').read_bytes())
        positive=(controls/'genuine-own-positive/donor.stdout').read_text().splitlines()
        states=[line.split()[1:] for line in positive if line.startswith('HYBRID_STOCK_FLUX ')]
        heads=[line.split()[1:] for line in positive if line.startswith('HYBRID_HYDRAULIC ')]
        assert len(states)==len(heads)==1 and list(map(float,states[0][:6]))==original_receipt['receipt']['stock_end_cm']
        assert list(map(float,heads[0][2:]))==original_receipt['receipt']['pressure_head_cm']
        domains=[]
        if spec['frost']:
            domains.append(['thermal',[1,nodes,0,int(spec['kind']=='cde'),spec['hysteresis'],1,1,0,1,2]])
            domains.append(['root',[5,nodes,int(spec['kind']=='cde'),1,spec['hysteresis'],6,1,0]])
        elif spec['snow']:
            domains.append(['root',[3,nodes,int(spec['kind']=='cde'),1,spec['hysteresis'],6,1,0]])
        domains.append(['implicit-per-layer',header]);assert c['domains']==domains
        expected_attacks={'foreign-magic':b'S5BAD999'+good[8:],'truncated':good[:-1],'trailing':good+b'x'}
        for label,values in domains:
            packed=struct.pack('<'+str(len(values))+'i',*values);assert good.count(packed+packed)==1
            pos=good.index(packed+packed);size=len(packed)
            for index,value in enumerate(values):
                bad=bytearray(good)
                for offset in [pos,pos+size]:struct.pack_into('<i',bad,offset+4*index,value+1)
                expected_attacks[label+'-field-'+str(index)]=bytes(bad)
            bad=bytearray(good);struct.pack_into('<i',bad,pos+size,values[0]+1);expected_attacks[label+'-single-witness']=bytes(bad)
        if scalar('SWODAT')==1 and scalar('SWMONTH')==0:
            dates=re.findall(r'(?mis)^\\s*OUTDATINT\\s*=\\s*\\n\\s*(\\d{4}-\\d{2}-\\d{2})',text);assert len(dates)==1
            if dates[0]<meta['project']['start_date']:
                positions=[]
                for pos in range(8,len(good)-160):
                    if good[pos:pos+8]!=struct.pack('<2i',1,nodes):continue
                    values=struct.unpack_from('<20i',good,pos)
                    if values[3]>100 and values==struct.unpack_from('<20i',good,pos+80):positions.append((pos,values))
                assert len(positions)==1;pos,values=positions[0];assert values[10]==1
                bad=bytearray(good)
                for offset in [pos,pos+80]:struct.pack_into('<i',bad,offset+40,2)
                expected_attacks['forged-advance-of-original-pending-date-pointer']=bytes(bad)
        assert len(c['refusals'])==len({v['attack'] for v in c['refusals']})==len(expected_attacks)
        assert {v['attack'] for v in c['refusals']}==set(expected_attacks)
'''
text=text.replace(needle,needle+extra,1)
needle="            root=controls/check['attack'];assert SHA((root/'origin/macro.bin').read_bytes())==check['actual_mutant_sha256'];"
assert text.count(needle)==1
text=text.replace(needle,"            root=controls/check['attack'];assert (root/'origin/macro.bin').read_bytes()==expected_attacks[check['attack']];assert SHA((root/'origin/macro.bin').read_bytes())==check['actual_mutant_sha256'];",1)
text=text.replace('        assert refusals>=3','        assert refusals==len(expected_attacks)',1)
needle="    assert dict(q['input_inventory'])==meta['inputs']\n";assert text.count(needle)==1
extra='''    trial=meta['identity']['implicit_hydraulic_state'].get('closed_desaturation_trial_start')
    if trial is not None:
        owner=git('show',q['actual_source']+':app/hybrid_water/implicit_closed_desaturation.py')
        tree=__import__('ast').parse(owner);policy=next(__import__('ast').literal_eval(v.value) for v in tree.body if isinstance(v,__import__('ast').Assign) and any(isinstance(t,__import__('ast').Name) and t.id=='POLICY' for t in v.targets))
        assert trial['policy']==policy and trial['new_numerical_policy'] is True
        assert not trial['accepted_state_added'] and not trial['physical_equations_changed'] and not trial['tolerances_changed']
        assert trial['original_full_residual_and_budget_acceptance_required'] is True
        assert trial['providers']=={name:SHA(git('show',q['actual_source']+':app/hybrid_water/'+name)) for name in ['implicit_closed_desaturation.py','implicit_closed_desaturation_trial.f90']}
'''
text=text.replace(needle,needle+extra,1)
ast.parse(text);path=E/'closed-implicit-state13-science.draft.py';assert not path.exists();path.write_text(text,encoding='utf8')
print('Prepared independent exact full native attack-byte set and genuine-producer numerical policy custody',flush=True)
