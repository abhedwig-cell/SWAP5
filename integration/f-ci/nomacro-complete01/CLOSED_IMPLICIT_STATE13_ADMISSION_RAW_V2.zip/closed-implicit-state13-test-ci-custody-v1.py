from pathlib import Path
import json,shutil,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from closed_implicit_state_ci_custody import audit
q=audit(E);target=E/'CLOSED_IMPLICIT_STATE13_PORTABLE_ORIGINAL_CI_INDEPENDENT_V1.json';assert not target.exists();target.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');shutil.copyfile(target,R/'integration/f-ci/nomacro-complete01'/target.name);print(q['status'],flush=True)
