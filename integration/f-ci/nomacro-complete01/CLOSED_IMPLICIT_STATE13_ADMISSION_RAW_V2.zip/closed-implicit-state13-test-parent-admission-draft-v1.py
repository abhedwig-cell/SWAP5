from pathlib import Path
import hashlib,json,runpy,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
module=runpy.run_path(str(E/'closed-implicit-state13-parent-admission.draft.py'))
q=module['parent_admission']();q['actual_proposed_observer_file_sha256']=hashlib.sha256((E/'closed-implicit-state13-parent-admission.draft.py').read_bytes()).hexdigest()
(E/'CLOSED_IMPLICIT_STATE13_PROPOSED_PARENT948_ADMISSION_AUDIT_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],flush=True)
