from pathlib import Path
import json,shutil
E=Path(__file__).parent;W=E.parent;old=E/'CLOSED_IMPLICIT_STATE13_ANALYTICAL_DERIVATIVE_PROTOTYPE_V1.json';q=json.loads(old.read_text());assert q['component_probe']['pass_'] is False
target=E/'closure13-derivative-fd-resolution-v1';target.mkdir()
shutil.copyfile(old,target/old.name)
build=W/'closure13-analytic-derivative-prototype-O0-v1';work=W/'closure13-analytic-derivative-prototype-v1'
for p in [build/'probe_main.f90',build/'probe_main.o',build/'derivative_probe.exe',work/'component/probe.stdout',work/'component/probe.stderr']:
    shutil.copyfile(p,target/p.name)
text=(E/'closed-implicit-state13-analytical-derivative-prototype-v1.py').read_text()
changes=[('probe_d=abs(probe_h)*1d-4','probe_d=abs(probe_h)*1d-2'),("probe_dir=work/'component'","probe_dir=work/'component-v2'"),('CLOSED_IMPLICIT_STATE13_ANALYTICAL_DERIVATIVE_PROTOTYPE_V1.json','CLOSED_IMPLICIT_STATE13_ANALYTICAL_DERIVATIVE_PROTOTYPE_V2.json'),('abs(dk-fd2)/scale','abs(dk-(4*fd2-fd1)/3)/scale'),('against refined central differences','against Richardson-extrapolated original K central differences (relative steps1e-2 and5e-3; first cancellation-sensitive1e-4 comparison retained separately)')]
for before,after in changes:
    assert before in text,before;text=text.replace(before,after)
path=E/'closed-implicit-state13-analytical-derivative-prototype-v2.py';assert not path.exists();path.write_text(text,encoding='utf8')
