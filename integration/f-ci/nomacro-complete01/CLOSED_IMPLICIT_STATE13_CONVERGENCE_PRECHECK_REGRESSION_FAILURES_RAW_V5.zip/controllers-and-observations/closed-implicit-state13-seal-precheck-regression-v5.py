from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='3ee4db1ceeb9d923d44fd833f82d196e116a23c0';SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
observations=[]
for opt in ['O0','O2']:
    root=E/'closure13-residual-feedback-v2'/opt;batch=json.loads((root/'SUMMARY.json').read_text());assert len(batch['cases'])==2
    for item in batch['cases']:
        q=json.loads((root/item['case']/'RESULT.json').read_text());assert q['actual_source']==C and item['returncode']!=0
        daily=root/item['case']/'trajectory/daily.jsonl';observations.append(dict(case=item['case'],optimization=opt,actual_source=C,primary_days=len(daily.read_text().splitlines()) if daily.exists() else 0,status=q['status'],error=q['error'],complete=False))
name='CLOSED_IMPLICIT_STATE13_CONVERGENCE_PRECHECK_REGRESSION_FAILURES_RAW_V5';target=E/(name+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in [E/'closure13-residual-feedback-v2',W/'closure13-residual-feedback-O0-v2',W/'closure13-residual-feedback-O2-v2']:
        for p in sorted(root.rglob('*')):
            if p.is_file():
                raw=p.read_bytes();key='actual/'+p.relative_to(W).as_posix();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=git('archive','--format=zip',C,'app','src','tools','tests/nomacro_drainage','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V6.json');key='source/actual3ee4-controller-and-physical-source.zip';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    for p in sorted(E.iterdir()):
        if p.is_file() and p.suffix in ('.py','.json') and p.name.startswith(('CLOSED_IMPLICIT_STATE13_','closed-implicit-state13-')) and p.name!=name+'.json':
            raw=p.read_bytes();key='controllers-and-observations/'+p.name;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for key,item in members.items():assert SHA(z.read(key))==item['sha256'] and len(z.read(key))==item['bytes']
raw=target.read_bytes();assert len(raw)<48*1024**2
q=dict(status='FOUR_ACTUAL_PRECHECK_WITHOUT_NEWTON_PROGRESS_REGRESSIONS_RETAINED_NOT_QUALIFIED',actual_scientific_source=C,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,observations=observations,complete_contexts=0,new_qualified_contexts=0,canonical_admission=False,next_repair='A failed complete convergence check must require actual Newton progress before checking the same iterate again. The unchanged mandatory polish check may evaluate the already feasible iterate again.')
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(len(raw),q['sha256'],observations,flush=True)
