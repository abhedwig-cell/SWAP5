from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='84452a487cf7b4726953be695867e53397daf396';SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
sys.path.insert(0,str(R/'tests/nomacro_drainage'));from closed_implicit_state_feedback import m,ledger
contexts=[]
for opt in ['O0','O2']:
    batch=json.loads((E/'closure13-residual-feedback-v1'/opt/'SUMMARY.json').read_text());assert len(batch['cases'])==2
    for item in batch['cases']:
        folder=E/'closure13-residual-feedback-v1'/opt/item['case'];q=json.loads((folder/'RESULT.json').read_text());assert q['actual_source']==C;days=len((folder/'trajectory/daily.jsonl').read_text().splitlines())
        contexts.append(dict(case=item['case'],optimization=opt,actual_source=C,status=q['status'],error=q.get('error'),primary_days=days,complete=item['returncode']==0,partial_or_complete_budgets=ledger(folder/'trajectory',q['specification']['kind'],days)))
assert sum(v['complete'] for v in contexts)==2 and sum(v['primary_days'] for v in contexts)==128
science=json.loads((E/'CLOSED_IMPLICIT_STATE13_FIRST_REPAIRED_FROST_INDEPENDENT_SCIENCE_V1.json').read_text());assert len(science['contexts'])==2 and science['status'].startswith('INDEPENDENT_CLOSED_IMPLICIT_')
prototypes=[]
for name,folder,count in [('SIGNED_RESIDUAL_PROTOTYPE_V2','closure13-signed-residual-prototype-v2',26),('RESIDUAL_PRECHECK_PROTOTYPE_V1','closure13-residual-precheck-prototype-v1',5)]:
    q=json.loads((E/('CLOSED_IMPLICIT_STATE13_'+name+'.json')).read_text());assert q['accepted_resumed_days']==count and not q.get('error')
    rows=[json.loads(v) for v in (E/folder/'daily.jsonl').read_text().splitlines()];prototypes.append(dict(report='CLOSED_IMPLICIT_STATE13_'+name+'.json',actual_original_producer=q['actual_original_scientific_source'],resumed_days=count,original_checkpoint_sha256=q['original_checkpoint_sha256'],budgets=m.check(rows),new_numerical_policy_prototype=True,qualified=False))
name='CLOSED_IMPLICIT_STATE13_RESIDUAL_FAILURES_SUCCESSES_AND_CAUSAL_PROTOTYPES_RAW_V4';target=E/(name+'.zip');members={}
summary=dict(actual_scientific_source=C,contexts=contexts,independent_Frost_contexts=2,prototypes=prototypes,new_qualified_contexts=0,new_admitted_contexts=0,scientific_qualification=False,canonical_admission=False,necessary_next_repair='Signed original-residual initial iterate handles wetting too; evaluate unchanged complete convergence block on already converged current iterate before poorly conditioned Newton solve. Exact analytical derivative prototype alone did not solve Snow censor, so it remains a non-admitted diagnostic.')
(E/'CLOSED_IMPLICIT_STATE13_RESIDUAL_INVESTIGATION_SUMMARY_V4.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
stems=['closure13-partial-plateau-observer','closure13-signed-residual-prototype','closure13-signed-residual-snow-prototype','closure13-snow-progress-observer','closure13-analytic-derivative-prototype','closure13-snow-newton-observer','closure13-residual-precheck-prototype']
roots=[E/'closure13-residual-feedback-v1',W/'closure13-residual-feedback-O0-v1',W/'closure13-residual-feedback-O2-v1',E/'closure13-derivative-fd-resolution-v1']
for root in [W,E]:
    roots += [p for p in root.iterdir() if p.is_dir() and any(p.name.startswith(stem) for stem in stems)]
assert len({p.resolve() for p in roots})==len(roots)
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in roots:
        for p in sorted(root.rglob('*')):
            if p.is_file():
                raw=p.read_bytes();key='actual/'+p.relative_to(W).as_posix();assert key not in members;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=git('archive','--format=zip',C,'app','src','tools','tests/nomacro_drainage','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V5.json','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json');key='source/actual84452-controller-and-physical-source.zip';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    for p in sorted(E.iterdir()):
        if p.is_file() and p.suffix in ('.py','.json','.diff','.f90') and p.name.startswith(('CLOSED_IMPLICIT_STATE13_','closed-implicit-state13-')) and p.name!=name+'.json':
            raw=p.read_bytes();key='controllers-and-observations/'+p.name;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(members) and z.testzip() is None
    for key,item in members.items():assert SHA(z.read(key))==item['sha256'] and len(z.read(key))==item['bytes']
raw=target.read_bytes();assert len(raw)<48*1024**2
descriptor=dict(status='ORIGINAL_TWO_FROST_LOCAL_PASSES_AND_ALL_REMAINING_FAILURE_CENSOR_AND_CAUSAL_PROTOTYPE_ROLES_PRESERVED_NOT_QUALIFIED',actual_scientific_source=C,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,summary=summary,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(descriptor,indent=2)+'\n',encoding='utf8');print(len(raw),descriptor['sha256'],len(members),flush=True)
