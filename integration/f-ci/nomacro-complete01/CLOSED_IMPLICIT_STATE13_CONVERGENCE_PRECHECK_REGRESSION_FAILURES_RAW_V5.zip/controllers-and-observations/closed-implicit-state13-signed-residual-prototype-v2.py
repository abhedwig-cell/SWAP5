from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,traceback
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from closed_implicit_state_feedback import m
import implicit_closed_desaturation as owner
name='closed-ordinary-model5-cde-profile';old=W/'closure13-residual-feedback-O2-v1/current'/name/'bundle';full=E/'closure13-residual-feedback-v1/O2'/name/'trajectory';build=W/'closure13-signed-residual-prototype-O2-v2';work=W/'closure13-signed-residual-prototype-v2';reference=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');SHA=lambda b:hashlib.sha256(b).hexdigest()
meta=json.loads((old/'BUILD.json').read_text());identity=meta['identity'];q=dict(actual_original_scientific_source='84452a487cf7b4726953be695867e53397daf396',case=name,actual_original_BUILD_sha256=SHA((old/'BUILD.json').read_bytes()),numerical_policy_prototype='signed original residual initial iterate on actual closed implicit zero-pond domain',physical_equations_or_parameters_changed=False,tolerances_changed=False,accepted_stocks_or_fluxes_corrected=False,canonical_admission=False)
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_SIGNED_RESIDUAL_PROTOTYPE_V2.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');save()
actual=(old/'headcalc.f90').read_bytes().replace(b'\r\n',b'\n').decode('cp1252');parent=owner.restore(actual)
trigger=owner.TRIGGER.replace('all(dimoca(1:NN)==0d0).and.sum(F(1:NN))>0d0','sum(F(1:NN))/=0d0')
routine=owner.routine().replace('right_value,value,shift','right_value,value,shift,direction').replace('      left_value=sum(F(1:NN))','      direction=sign(1d0,sum(F(1:NN)))\n      left_value=direction*sum(F(1:NN))').replace('initial_head(1:NN)-shift','initial_head(1:NN)-direction*shift').replace('value=sum(F(1:NN))','value=direction*sum(F(1:NN))')
assert trigger!=owner.TRIGGER and routine!=owner.routine()
source=parent.replace(owner.ANCHOR,trigger+owner.ANCHOR,1).replace(owner.ROUTINE_ANCHOR,routine+'\n'+owner.ROUTINE_ANCHOR,1)
assert source.replace(trigger,'',1).replace(routine+'\n','',1)==parent
q.update(actual_parent_lf_sha256=SHA(parent.encode('cp1252')),prototype_lf_sha256=SHA(source.encode('cp1252')),complete_literal_original_equation_parent_inverse=True,prototype_trigger=trigger,prototype_routine=routine)
path=build/'headcalc.f90';path.write_text(source,encoding='cp1252');os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH']
objects=reference/'build/swap-obj';ttutil=reference/'build/ttutil-obj';commands=[['gfortran',*identity['donor_flags'],'-I',str(old),'-I',str(objects),'-I',str(ttutil),'-c',str(path)]]
generated={Path(n).stem for n in identity['donor_generated']};donor_objects=sorted(objects.glob('*.o'));names={p.stem for p in donor_objects};link=[str((build if p.stem=='headcalc' else old)/(p.stem+'.o')) if p.stem in generated else str(p) for p in donor_objects];link += [str(old/(n+'.o')) for n in sorted(generated-names)];link.append(str(old/'hybrid_step_budget.o'));donor=build/'day_donor.exe';commands.append(['gfortran','-o',str(donor),*link,str(ttutil/'libttutil.a')])
for index,cmd in enumerate(commands):
    run=subprocess.run(cmd,cwd=build,capture_output=True);(work/(str(index)+'.stdout')).write_bytes(run.stdout);(work/(str(index)+'.stderr')).write_bytes(run.stderr);run.check_returncode()
q.update(commands=commands,prototype_executable_sha256=SHA(donor.read_bytes()),linked_objects={p:SHA(Path(p).read_bytes()) for p in link});save()
for p in old.glob('*restart*'):
    if p.is_file():shutil.copyfile(p,build/p.name)
inputs=E/'closure13-residual-feedback-v1/O2'/name/'inputs';project=m.e.load(str(inputs),original_output=True,time_step_policy='original-adaptive-day-seed-v1');checkpoint=full/'accepted-column-1-day-9.zip';q['original_checkpoint_sha256']=SHA(checkpoint.read_bytes());origin=work/'origin';receipt=m.h.verify_checkpoint(checkpoint,9,meta['binding'],origin);out=E/'closure13-signed-residual-prototype-v2';out.mkdir();started=time.perf_counter()
try:q['result'],q['model_seconds']=m.bounded(90,lambda:m.h.run(donor,m.h.executable(old,'day_kernel'),inputs,out,35,checkpoint_day=9,origin=origin,origin_receipt=receipt,runtime=True,publish_day=35,checkpoint_binding=meta['binding'],model=project.model,project=project))
except Exception as error:q.update(error=repr(error),traceback=traceback.format_exc())
finally:
    q.update(seconds=time.perf_counter()-started,accepted_resumed_days=len((out/'daily.jsonl').read_text().splitlines()) if (out/'daily.jsonl').exists() else 0,status='ACTUAL_SIGNED_RESIDUAL_PROTOTYPE_RETAINED_NOT_QUALIFICATION');assert SHA(checkpoint.read_bytes())==q['original_checkpoint_sha256'];save()
print(q['status'],q['accepted_resumed_days'],q.get('error'),flush=True)
