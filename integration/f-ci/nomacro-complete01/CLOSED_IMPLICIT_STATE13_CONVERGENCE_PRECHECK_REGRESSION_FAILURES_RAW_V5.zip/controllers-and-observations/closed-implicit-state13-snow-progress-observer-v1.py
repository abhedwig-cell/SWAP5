from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,traceback
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from closed_implicit_state_feedback import m
name='closed-ordinary-model6-snow-cde-profile';old=W/'closure13-residual-feedback-O0-v1/current'/name/'bundle';proto=W/'closure13-signed-residual-snow-prototype-O0-v2';full=E/'closure13-residual-feedback-v1/O0'/name/'trajectory';build=W/'closure13-snow-progress-observer-O0-v1';work=W/'closure13-snow-progress-observer-v1';reference=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');SHA=lambda b:hashlib.sha256(b).hexdigest()
meta=json.loads((old/'BUILD.json').read_text());identity=meta['identity'];q=dict(actual_original_scientific_source='84452a487cf7b4726953be695867e53397daf396',case=name,actual_original_BUILD_sha256=SHA((old/'BUILD.json').read_bytes()),actual_numerical_variant='signed-residual Snow prototype V2',physical_equations_or_parameters_changed=False,accepted_stocks_or_fluxes_corrected=False,wall_cap=20,canonical_admission=False)
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_SNOW_PROGRESS_OBSERVER_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');save()
original=(old/'timecontrol.f90').read_bytes().replace(b'\r\n',b'\n').decode('cp1252');anchor='   case (5)';assert original.count(anchor)==1
addition="""
      if(t1900>=37289d0.and.mod(isteps,1000)==0)then
         write(*,'(a,*(1x,es25.17e3))') 'SNOW_CLOCK_OBSERVER',t1900,dt,tcum,real(isteps,8),real(numbit,8),dtmin
         write(*,*) 'SNOW_CLOCK_OBSERVER_FLAGS',fldecdt,fldtmin,floutput,flprintdt,floutputshort,nprintcount,ioutdatint
         flush(6)
      end if
"""
source=original.replace(anchor,anchor+addition,1);assert source.replace(addition,'',1)==original;path=build/'timecontrol.f90';path.write_text(source,encoding='cp1252');q.update(original_timecontrol_lf_sha256=SHA(original.encode('cp1252')),observer_timecontrol_lf_sha256=SHA(source.encode('cp1252')),stdout_only_addition=addition,prototype_headcalc_lf_sha256=SHA((proto/'headcalc.f90').read_bytes().replace(b'\r\n',b'\n')))
os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH'];objects=reference/'build/swap-obj';ttutil=reference/'build/ttutil-obj';commands=[['gfortran',*identity['donor_flags'],'-I',str(old),'-I',str(objects),'-I',str(ttutil),'-c',str(path)]]
generated={Path(n).stem for n in identity['donor_generated']};donor_objects=sorted(objects.glob('*.o'));names={p.stem for p in donor_objects};link=[]
for p in donor_objects:
    chosen=build if p.stem=='timecontrol' else proto if p.stem=='headcalc' else old
    link.append(str(chosen/(p.stem+'.o')) if p.stem in generated else str(p))
link += [str(old/(n+'.o')) for n in sorted(generated-names)];link.append(str(old/'hybrid_step_budget.o'));donor=build/'day_donor.exe';commands.append(['gfortran','-o',str(donor),*link,str(ttutil/'libttutil.a')])
for index,cmd in enumerate(commands):
    run=subprocess.run(cmd,cwd=build,capture_output=True);(work/(str(index)+'.stdout')).write_bytes(run.stdout);(work/(str(index)+'.stderr')).write_bytes(run.stderr);run.check_returncode()
q.update(commands=commands,observer_executable_sha256=SHA(donor.read_bytes()),linked_objects={p:SHA(Path(p).read_bytes()) for p in link});save()
for p in old.glob('*restart*'):
    if p.is_file():shutil.copyfile(p,build/p.name)
inputs=E/'closure13-residual-feedback-v1/O0'/name/'inputs';project=m.e.load(str(inputs),original_output=True,time_step_policy='original-adaptive-day-seed-v1');checkpoint=full/'accepted-column-1-day-30.zip';q['original_checkpoint_sha256']=SHA(checkpoint.read_bytes());origin=work/'origin';receipt=m.h.verify_checkpoint(checkpoint,30,meta['binding'],origin);out=E/'closure13-snow-progress-observer-v1';out.mkdir();started=time.perf_counter()
try:q['result'],q['model_seconds']=m.bounded(20,lambda:m.h.run(donor,m.h.executable(old,'day_kernel'),inputs,out,34,checkpoint_day=30,origin=origin,origin_receipt=receipt,runtime=True,publish_day=34,checkpoint_binding=meta['binding'],model=project.model,project=project))
except Exception as error:q.update(error=repr(error),traceback=traceback.format_exc())
finally:
    q.update(seconds=time.perf_counter()-started,accepted_resumed_days=len((out/'daily.jsonl').read_text().splitlines()) if (out/'daily.jsonl').exists() else 0,status='ACTUAL_SNOW_CLOCK_PROGRESS_OBSERVER_RETAINED_NOT_QUALIFICATION');assert SHA(checkpoint.read_bytes())==q['original_checkpoint_sha256'];save()
print(q['status'],q['accepted_resumed_days'],q.get('error'),flush=True)
