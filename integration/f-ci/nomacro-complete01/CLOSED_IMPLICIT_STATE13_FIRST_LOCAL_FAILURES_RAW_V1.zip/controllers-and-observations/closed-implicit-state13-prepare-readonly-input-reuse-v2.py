"""Use an explicit pinned immutable donor view in the next observer; no global cache."""
from pathlib import Path
import ast
E=Path(__file__).parent;old=E/'closed-implicit-state13-proposed-controllers-v1';out=E/'closed-implicit-state13-proposed-controllers-v2';out.mkdir()
for path in old.iterdir():(out/path.name).write_bytes(path.read_bytes())
p=out/'closed_implicit_state_science.py';s=p.read_text(encoding='utf8');lo=s.index('def original_inputs(');hi=s.index('def observe(',lo)
replacement='''class OriginalInputs:
    """A concrete archive opened from the real pinned scientific input commit."""
    NAME='IMPLICIT_HYDRAULIC_STATE11_FIRST_WINDOWS_O0_ORIGINAL_V1'
    def __init__(self,stack):
        self.source=GitArchiveSource(R,PARENT)
        self.archive=Archive(self.source,self.NAME,stack)


def original_inputs(q,inputs,original_store=None):
    authority=q['inputs']['authority']
    assert authority['actual_git_source']==PARENT and authority['archive']==OriginalInputs.NAME
    assert q['inputs']['additional_original_parameter_authority'] is None
    assert q['inputs']['declared_selectors']==dict(SWDRA=0,SWBOTB=6)
    with ExitStack() as stack:
        store=OriginalInputs(stack) if original_store is None else original_store
        assert isinstance(store,OriginalInputs) and store.source.repository==R.resolve() and store.source.revision==PARENT
        archive=store.archive;assert archive.record['sha256']==authority['archive_sha256']
        prefix=authority['prefix'];original={n[len(prefix):]:archive.get(n) for n in archive.names if n.startswith(prefix)}
        assert original and authority['original_members']=={n:dict(bytes=len(raw),sha256=SHA(raw)) for n,raw in original.items()}
        assert set(original)=={n for n,_ in q['input_inventory']}
        for name,raw in original.items():
            if name=='swap.swp':
                text=raw.decode('cp1252')
                for key,value in [('SWDRA',0),('SWBOTB',6)]:text=assignment(text,key,value)
                assert text.encode('cp1252')==(inputs/name).read_bytes()
            else:assert raw==(inputs/name).read_bytes()
    return dict(original_archive_sha256=archive.record['sha256'],all_original_parameters_and_other_input_bytes_preserved=True,only_explicit_declared_selectors_changed=True)


'''
s=s[:lo]+replacement+s[hi:];before='def observe(folder,build=None,inputs=None,controls=None):';assert s.count(before)==1;s=s.replace(before,'def observe(folder,build=None,inputs=None,controls=None,original_store=None):')
before='    input_proof=original_inputs(q,inputs)';assert s.count(before)==1;s=s.replace(before,'    input_proof=original_inputs(q,inputs,original_store)')
before="""        for folder in a.folder:
            q['contexts'].append(observe(folder,controls=folder.with_name(folder.name+'-native-controls')));save()"""
after="""        with ExitStack() as stack:
            original_store=OriginalInputs(stack)
            for folder in a.folder:
                q['contexts'].append(observe(folder,controls=folder.with_name(folder.name+'-native-controls'),original_store=original_store));save()"""
assert s.count(before)==1;s=s.replace(before,after);ast.parse(s);p.write_text(s,encoding='utf8')
print('PREPARED_EXPLICIT_IMMUTABLE_INPUT_REUSE_FOR_NEXT_OBSERVER_NOT_INSTALLED_NOT_EXECUTED')
