"""Retain every first runtime guard and genuine day33 numerical failure on its actual source."""
from pathlib import Path
import hashlib,io,json,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='2215b9d93d3616160d5ac813bd0c7b879536171a';SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from closed_implicit_state_feedback import ledger
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
observed=[]
for opt in ['O0','O2']:
    root=E/'closure13-local-feedback-v1'/opt;batch=json.loads((root/'RESULT.json').read_text());assert all(v['status']=='RUNTIME_FAILURE_RETAINED' for v in batch['contexts'])
    for item in batch['contexts']:
        p=root/item['case'];q=json.loads((p/'RESULT.json').read_text());daily=p/'trajectory/daily.jsonl';days=len(daily.read_text().splitlines()) if daily.exists() else 0
        record=dict(case=item['case'],optimization=opt,actual_source=C,primary_days_returned=days,original_error=q['error'],classification='NUMERICAL_DEFECT' if days else 'COMPOSITION_MISSING',complete_PASS_claimed=False)
        if days:
            assert days==32 and b'Implicit original retry reached clock resolution' in (p/'trajectory/original/donor.stderr').read_bytes();record['partial_independent_budgets']=ledger(p/'trajectory',q['specification']['kind'],days)
            assert all(json.loads(v)['external_flux_cm'][-1]==0 for v in daily.read_text().splitlines())
        observed.append(record)
assert len(observed)==5 and sum(v['primary_days_returned'] for v in observed)==64
summary=dict(status='FIRST_FIVE_LOCAL_CONTEXT_FAILURES_RETAINED_THREE_OUTPUT_OWNER_GUARDS_AND_TWO_DAY33_CLOCK_RESOLUTION_FAILURES_NOT_QUALIFIED',actual_source=C,contexts=observed,complete_contexts=0,partial_days_returned=64,output_configuration_in_first_plan_misdescribed_as_dense=True,actual_original_output_input_bytes_never_changed=True,original_main_reference_causality='UNKNOWN',canonical_admission=False)
(E/'CLOSED_IMPLICIT_STATE13_FIRST_LOCAL_FAILURE_SUMMARY_V1.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
name='CLOSED_IMPLICIT_STATE13_FIRST_LOCAL_FAILURES_RAW_V1';archive=E/(name+'.zip');assert not archive.exists();members={};sources={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in [E/'closure13-local-feedback-v1',W/'closure13-feedback-O0-v1',W/'closure13-feedback-O2-v1']:
        for p in sorted(root.rglob('*')):
            if not p.is_file():continue
            assert not p.is_symlink();n='actual/'+p.relative_to(W).as_posix();raw=p.read_bytes();z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw));sources[n]=p
    raw=git('archive','--format=zip',C,'app','src','tools','tests/nomacro_drainage','docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V2.json','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json');n='source/actual-controller-and-physical-source.zip';z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw))
    for p in E.iterdir():
        if p.is_file() and p.suffix not in ['.zip','.tar','.gz','.xz'] and '.zip.part' not in p.name and p.name!=name+'.json' and p.name.startswith(('CLOSED_IMPLICIT_STATE13_','closed-implicit-state13-')):
            n='controllers-and-observations/'+p.name;raw=p.read_bytes();z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw));sources[n]=p
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(members)
    for n,item in members.items():
        raw=z.read(n);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
        if n in sources:assert raw==sources[n].read_bytes()
raw=archive.read_bytes();assert len(raw)<48*1024**2
q=dict(status=summary['status'],actual_scientific_source=C,archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members=members,observations=observed,source_or_producer_roles_rebound=False,complete_contexts=0,partial_days_returned=64,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],len(raw),q['sha256'],len(members),flush=True)
