from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).parent;W=E.parent;SHA=lambda b:hashlib.sha256(b).hexdigest();name='CLOSED_IMPLICIT_STATE13_ORIGINAL_MAIN_STARTUP_RAW_V1';archive=E/(name+'.zip');assert not archive.exists();members={};sources={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for label,root in [('actual-startup',W/'closure13-original-main-startup-v1'),('actual-compiled-diagnostic',W/'closure13-original-main-startup-O0-v1')]:
        for p in sorted(root.rglob('*')):
            if not p.is_file():continue
            n=label+'/'+p.relative_to(root).as_posix();raw=p.read_bytes();z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw));sources[n]=p
    for n in ['CLOSED_IMPLICIT_STATE13_ORIGINAL_MAIN_STARTUP_DIAGNOSTIC_V1.json','closed-implicit-state13-original-main-startup-diagnostic-v1.py','closed-implicit-state13-seal-startup-diagnostic-v1.py']:
        p=E/n;raw=p.read_bytes();member='controllers-and-observations/'+n;z.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=SHA(raw));sources[member]=p
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(members)
    for n,item in members.items():
        raw=z.read(n);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and raw==sources[n].read_bytes()
raw=archive.read_bytes();q=dict(status='ORIGINAL_MAIN_STARTUP_SIGSEGV_BEFORE_TASK1_COMPLETION_ZERO_MODEL_DAYS_WITH_EXPLICIT_DIAGNOSTIC_SOURCE_NOT_GARDNER_LEGACY_PROOF',archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members=members,actual_observer_source='2e98506b4fb469bbf5995a8ab0b49c88ead0972c',model_days=0,original_main_source_changed_only_by_explicit_phase_IO_and_zero_day_stop=True,all_original_SDK_objects_except_main_unchanged=True,original_SDK_mixed_profiles=True,all_O0_SDK_claimed=False,legacy_Gardner_defect_claimed=False,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],len(raw),q['sha256'],len(members))
