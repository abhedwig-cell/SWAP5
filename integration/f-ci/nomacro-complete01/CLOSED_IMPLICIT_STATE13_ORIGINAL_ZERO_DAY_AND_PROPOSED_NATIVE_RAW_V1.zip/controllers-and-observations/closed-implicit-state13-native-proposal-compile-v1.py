"""Compile the two exact proposed native-domain providers; never link or run a model."""
from pathlib import Path
import hashlib,json,os,subprocess,time
E=Path(__file__).parent;W=E.parent;source=E/'closed-implicit-state13-proposed-source-v1';out=W/'closure13-native-proposal-O0-v1';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
compiler=Path('C:/msys64/ucrt64/bin/gfortran.exe');SHA=lambda b:hashlib.sha256(b).hexdigest()
assert SHA(compiler.read_bytes())=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
sdk={str(p.relative_to(J)):SHA(p.read_bytes()) for root in [J/'build/swap-obj',J/'build/ttutil-obj'] for p in root.glob('*.mod')}
result=dict(status='RUNNING_EXACT_PROPOSED_NATIVE_DOMAIN_COMPILE_ONLY_NOT_PRODUCTION_ADMITTED',actual_proposal_base='07cb2850e2cd45deb1e197161409a3784a8975e7',actual_compiler_sha256=SHA(compiler.read_bytes()),actual_original_SDK_modules=sdk,optimization='O0',model_executions=0,link_executions=0,contexts=[])
for name in ['implicit_hydraulic_state_native','implicit_frost_hydraulic_state_native']:
    path=source/(name+'.f90');obj=out/(name+'.o');assert not obj.exists()
    command=[str(compiler),'-std=f2008','-ffree-line-length-none','-O0','-fcheck=all','-fbacktrace','-ffpe-trap=invalid,zero,overflow','-I'+str(J/'build/swap-obj'),'-I'+str(J/'build/ttutil-obj'),'-J'+str(out),'-c',str(path),'-o',str(obj)]
    start=time.perf_counter();run=subprocess.run(command,cwd=out,capture_output=True,timeout=30)
    (out/(name+'.stdout')).write_bytes(run.stdout);(out/(name+'.stderr')).write_bytes(run.stderr)
    result['contexts'].append(dict(name=name,actual_command=command,actual_proposed_source_sha256=SHA(path.read_bytes()),returncode=run.returncode,seconds=time.perf_counter()-start,actual_object_sha256=SHA(obj.read_bytes()) if obj.exists() else None));(E/'CLOSED_IMPLICIT_STATE13_PROPOSED_NATIVE_COMPILE_V1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');run.check_returncode()
result['status']='TWO_EXACT_PROPOSED_CLOSED_IMPLICIT_NATIVE_PROVIDERS_COMPILE_O0_PASS_NO_LINK_OR_MODEL';(E/'CLOSED_IMPLICIT_STATE13_PROPOSED_NATIVE_COMPILE_V1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(result['status'])
