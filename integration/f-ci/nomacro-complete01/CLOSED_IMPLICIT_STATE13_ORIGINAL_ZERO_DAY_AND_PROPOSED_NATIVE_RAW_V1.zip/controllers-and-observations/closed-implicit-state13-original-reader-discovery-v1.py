"""Observe finite original closed/implicit input reachability with zero model days."""
from pathlib import Path
from contextlib import ExitStack
import io,hashlib,json,os,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=W/'closure13-closed-implicit-reader-v1'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from analytical_hydraulic_archives import Archive
from frost_boundary_git_archive import GitArchiveSource
from original_output_baseline import assignment
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='07cb2850e2cd45deb1e197161409a3784a8975e7' and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
base='105b9a8e6ca9e846f214d69a71afe73ed18be11d';data=GitArchiveSource(R,base)
q=json.loads((data/'FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.json').read_text());raw=(data/q['archive']).read_bytes();assert len(raw)==q['bytes'] and SHA(raw)==q['sha256']
exe=W/'frost-undrained-state08-initialization-probe-O0-v1/corrected-module-import-v2/original_initialization_probe.exe'
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    member='phase-driver/corrected-module-import-v2/original_initialization_probe.exe';assert exe.read_bytes()==z.read(member) and SHA(exe.read_bytes())==q['members'][member]['sha256']=='dee4a94a5e0e92d07c9aee2a4790fc5178f159f7e81ad316fcaa58b6a6f28b5e'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
result=dict(status='RUNNING_FINITE_CLOSED_IMPLICIT_ORIGINAL_ZERO_DAY_DISCOVERY',actual_observer=head,actual_original_input_git_source=base,actual_original_input_producer='c40ca084d8e5eb638e0b4ac5c471463d9aad01c3',actual_original_probe_source='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d',actual_original_probe_exe_sha256=SHA(exe.read_bytes()),original_driver_O0=True,original_SDK_mixed_compiler_profiles=True,compiler_executions=0,model_days=0,cases=[])
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_ORIGINAL_READER_DISCOVERY_V1.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
save()
with ExitStack() as stack:
    archive=Archive(data,'IMPLICIT_HYDRAULIC_STATE11_FIRST_WINDOWS_O0_ORIGINAL_V1',stack);cohort=json.loads(archive.get('current/RESULT.json'));assert len(cohort['contexts'])==14
    result['actual_original_input_archive_sha256']=archive.record['sha256']
    for entry in cohort['contexts']:
        name=entry['name'];prefix='current/'+name+'/inputs/';original={n[len(prefix):]:archive.get(n) for n in archive.names if n.startswith(prefix)};assert original and 'swap.swp' in original
        folder=D/name;folder.mkdir()
        for n,raw in original.items():
            target=folder/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        text=original['swap.swp'].decode('cp1252')
        for key,value in [('SWDRA',0),('SWBOTB',6)]:text=assignment(text,key,value)
        (folder/'swap.swp').write_bytes(text.encode('cp1252'));inventory={p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=SHA(p.read_bytes())) for p in folder.rglob('*') if p.is_file()}
        command=[sys.executable,'-B','-c',"import sys;sys.path.insert(0,"+repr(str(R/'app/hybrid_water'))+");import experimental_project as e;e.load("+repr(str(folder))+",original_output=True);print('CURRENT_PUBLIC_ACCEPTED')"]
        public=subprocess.run(command,cwd=R,env=env,capture_output=True,timeout=30)
        native=subprocess.run([str(exe),'./swap.swp'],cwd=folder,env=env,capture_output=True,timeout=30)
        for label,child in [('current-public',public),('original-zero-day',native)]:
            (folder/(label+'.stdout')).write_bytes(child.stdout);(folder/(label+'.stderr')).write_bytes(child.stderr)
        accepted=b'ORIGINAL_INIT_PHASE AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS' in native.stdout
        result['cases'].append(dict(name=name,original_prefix=prefix,declared_selector_edits=dict(SWDRA=0,SWBOTB=6),all_other_original_input_and_parameter_bytes_preserved=True,input_inventory=inventory,current_public_returncode=public.returncode,current_public_accepted=b'CURRENT_PUBLIC_ACCEPTED' in public.stdout,original_probe_returncode=native.returncode,original_zero_day_initialization_accepted=accepted,original_phases=[n.decode() for n in native.stdout.splitlines() if n.startswith(b'ORIGINAL_INIT_PHASE ')],original_stdout_sha256=SHA(native.stdout),original_stderr_sha256=SHA(native.stderr)));save()
        print(name,'original_zero_day',accepted,'current_public',public.returncode,flush=True)
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
result.update(status='FINITE_ORIGINAL_CLOSED_IMPLICIT_ZERO_DAY_REACHABILITY_OBSERVED_NOT_QUALIFIED',original_accepted=sum(v['original_zero_day_initialization_accepted'] for v in result['cases']),current_public_accepted=sum(v['current_public_accepted'] for v in result['cases']),canonical_admission=False);save()
print(result['status'],result['original_accepted'],result['current_public_accepted'],flush=True)
