"""Prepare literal state-domain composition; no checkout mutation or qualification claim."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='07cb2850e2cd45deb1e197161409a3784a8975e7'
SHA=lambda b:hashlib.sha256(b).hexdigest();sources={}
def load(name):
    path='app/hybrid_water/'+name;raw=subprocess.check_output(['git','show',C+':'+path],cwd=R);sources[path]=[raw,raw.decode()];return path
def edit(path,before,after):
    old,text=sources[path];assert text.count(before)==1,(path,before);sources[path]=[old,text.replace(before,after,1)]
p=load('implicit_hydraulic_state.py')
edit(p,"boundary.get('SWBOTB') not in (5,8)","boundary.get('SWBOTB') not in (5,6,8)")
edit(p,"    frost=selectors.get('SWFROST')","    closed=boundary.get('SWBOTB')==6\n    if closed and selectors.get('SWDRA')!=0:return None\n    frost=selectors.get('SWFROST')")
edit(p,"    elif frost!=0 or selectors.get('SWDRA')!=1:return None","    elif frost!=0 or selectors.get('SWDRA')!=(0 if closed else 1):return None")
edit(p,"    if s['SWFROST']==1:result.update(frost=1,drainage=s['SWDRA'])","    if s['SWFROST']==1:result.update(frost=1,drainage=s['SWDRA'])\n    elif boundary['SWBOTB']==6:result['drainage']=0")
p=load('frost_undrained_state.py')
edit(p,"            # Original non1+hysteresis is invalid. Implicit closed non1 still\n            # requires its separate explicit per-layer native admission.\n            return None","            if values['SWKIMPL']!=1 or values['SWHYST']!=0:return None\n            from implicit_hydraulic_state import input_models\n            implicit_analytical=input_models(text,values,values,original_output)\n            if implicit_analytical is None:return None")
p=load('closed_zero_boundary.py')
edit(p,"    if rows and re.fullmatch(r'\\+?0*1(?:[ \\t]+\\+?0*1)*[ \\t]*',rows[0]) is None:return False","    if rows and re.fullmatch(r'\\+?0*1(?:[ \\t]+\\+?0*1)*[ \\t]*',rows[0]) is None:\n        if selectors['SWKIMPL']!=1 or selectors['SWHYST']!=0:return False\n        from implicit_hydraulic_state import input_models\n        if input_models(text,selectors,selectors,original_output) is None:return False")
p=load('implicit_frost_hydraulic_state_native.f90')
edit(p,"swsophy/=0.or.swkimpl/=1.or.(swbotb/=5.and.swbotb/=8)","swsophy/=0.or.swkimpl/=1.or.(swbotb/=5.and.swbotb/=6.and.swbotb/=8)")
edit(p,"    partition_active=0","    if(swbotb==6.and.swdra/=0)error stop 'Closed implicit Frost hydraulic boundary requires drainage off'\n    partition_active=0")
p=load('implicit_hydraulic_state_native.f90')
edit(p,'    integer::n,ios,i','    integer::n,ios,i,partition_active')
edit(p,'swfrost/=0.or.swhyst/=0.or.swdra/=1.or.swhea/=1','swfrost/=0.or.swhyst/=0.or.(swdra/=0.and.swdra/=1).or.swhea/=1')
edit(p,'swsophy/=0.or.swkimpl/=1.or.(swbotb/=5.and.swbotb/=8)','swsophy/=0.or.swkimpl/=1.or.(swbotb/=5.and.swbotb/=6.and.swbotb/=8)')
edit(p,"    if(swdivd<0.or.swdivd>1)error stop 'Foreign implicit hydraulic drainage partition'\n    if(swsolu==1.and.swdivd==0)error stop 'Invalid original solute drainage partition'","    if((swbotb==6).neqv.(swdra==0))error stop 'Foreign closed implicit hydraulic drainage selection'\n    partition_active=0\n    if(swdra==1)then\n      if(swdivd<0.or.swdivd>1)error stop 'Foreign implicit hydraulic drainage partition'\n      if(swsolu==1.and.swdivd==0)error stop 'Invalid original solute drainage partition'\n      partition_active=swdivd\n    end if")
edit(p,'swhea,swcalt,swdra,swbotb,swdivd]','swhea,swcalt,swdra,swbotb,partition_active]')
root=E/'closed-implicit-state13-proposed-source-v1';root.mkdir(exist_ok=False);files={}
for path,(before,text) in sources.items():
    after=text.encode();target=root/Path(path).name;target.write_bytes(after)
    if path.endswith('.py'):ast.parse(after)
    edits=[];left=before.decode()
    for kind,a,b,c,d in difflib.SequenceMatcher(a=left,b=text,autojunk=False).get_opcodes():
        if kind!='equal':edits.append(dict(base_start=a,base_end=b,before=left[a:b],after=text[c:d]))
    files[path]=dict(before_lf_sha256=SHA(before),proposed_after_lf_sha256=SHA(after),ordered_literal_edits=edits)
q=dict(status='PROPOSED_FIVE_FILE_CLOSED_IMPLICIT_ORIGINAL_DOMAIN_COMPOSITION_NOT_INSTALLED_NOT_QUALIFIED',actual_input_source=C,original_reachability_observation='CLOSED_IMPLICIT_STATE13_ORIGINAL_READER_DISCOVERY_V1.json',files=files,physical_equations_changed=False,new_physical_state=False,new_numerical_policy=False,original_parameters_fluxes_stocks_tolerances_or_dates_changed=False,model_executions=0,compiler_executions=0,canonical_admission=False)
(E/'CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],len(files))
