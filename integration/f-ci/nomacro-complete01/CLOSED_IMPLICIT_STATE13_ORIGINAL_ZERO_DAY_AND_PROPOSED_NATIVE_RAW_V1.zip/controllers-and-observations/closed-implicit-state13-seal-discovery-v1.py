"""Preserve actual zero-day observations and explicitly proposed source/compiler results."""
from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).parent;W=E.parent;SHA=lambda b:hashlib.sha256(b).hexdigest()
name='CLOSED_IMPLICIT_STATE13_ORIGINAL_ZERO_DAY_AND_PROPOSED_NATIVE_RAW_V1';path=E/(name+'.zip');assert not path.exists()
roots=[('actual-zero-day',W/'closure13-closed-implicit-reader-v1'),('actual-proposed-compile',W/'closure13-native-proposal-O0-v1'),('proposed-source-not-installed',E/'closed-implicit-state13-proposed-source-v1')]
records=['CLOSED_IMPLICIT_STATE13_ORIGINAL_READER_DISCOVERY_V1.json','CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V1.json','CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_PROPOSED_V1.json','CLOSED_IMPLICIT_STATE13_PROPOSED_NATIVE_COMPILE_V1.json','closed-implicit-state13-original-reader-discovery-v1.py','closed-implicit-state13-prepare-source-proposal-v1.py','closed-implicit-state13-native-proposal-compile-v1.py','closed-implicit-state13-seal-discovery-v1.py']
members={};sources={}
with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for prefix,root in roots:
        for source in sorted(root.rglob('*')):
            if not source.is_file():continue
            assert not source.is_symlink();member=prefix+'/'+source.relative_to(root).as_posix();raw=source.read_bytes();assert member not in members
            z.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=SHA(raw));sources[member]=source
    for n in records:
        source=E/n;raw=source.read_bytes();member='controllers-and-observations/'+n;z.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=SHA(raw));sources[member]=source
with zipfile.ZipFile(path) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(members)
    for n,item in members.items():
        raw=z.read(n);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and sources[n].read_bytes()==raw
raw=path.read_bytes();assert len(raw)<48*1024**2
q=dict(status='FOURTEEN_ACTUAL_ORIGINAL_ZERO_DAY_ACCEPTANCES_AND_CURRENT_PUBLIC_REFUSALS_WITH_EXPLICIT_UNINSTALLED_SOURCE_PROPOSALS_RETAINED_NOT_QUALIFIED',archive=path.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=path.name,bytes=len(raw),sha256=SHA(raw))],members=members,actual_observer_source='07cb2850e2cd45deb1e197161409a3784a8975e7',original_scientific_input_producer='c40ca084d8e5eb638e0b4ac5c471463d9aad01c3',original_probe_source='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d',original_zero_day_acceptances=14,current_public_acceptances=0,proposed_compile_only_contexts=2,production_source_proposal_installed=False,scientific_qualification=False,canonical_admission=False,model_days=0,original_roles_or_identities_rebound=False)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],q['bytes'],q['sha256'],len(members))
