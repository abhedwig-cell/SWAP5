from pathlib import Path
import hashlib,json,math,os,shutil,subprocess,sys,time,traceback
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from closed_implicit_state_feedback import m
name='closed-ordinary-model6-snow-cde-profile';old=W/'closure13-residual-feedback-O0-v1/current'/name/'bundle';head=W/'closure13-signed-residual-snow-prototype-O0-v2';full=E/'closure13-residual-feedback-v1/O0'/name/'trajectory';build=W/'closure13-analytic-derivative-prototype-O0-v1';work=W/'closure13-analytic-derivative-prototype-v1';reference=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');SHA=lambda b:hashlib.sha256(b).hexdigest()
meta=json.loads((old/'BUILD.json').read_text());identity=meta['identity'];q=dict(actual_original_scientific_source='84452a487cf7b4726953be695867e53397daf396',case=name,actual_original_BUILD_sha256=SHA((old/'BUILD.json').read_bytes()),numerical_policy_prototype='actual analytical K chain-rule derivative and signed original residual initial iterate',physical_equations_or_parameters_changed=False,tolerances_changed=False,accepted_stocks_or_fluxes_corrected=False,canonical_admission=False)
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_ANALYTICAL_DERIVATIVE_PROTOTYPE_V2.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');save()
original=(old/'MOD_MvG_functions.f90').read_bytes().replace(b'\r\n',b'\n').decode('cp1252');branch=(E/'closed-implicit-state13-analytical-derivative-prototype-v1.f90').read_text();begin='      real(8) function dhconduc';end='      end function dhconduc';lo=original.index(begin);hi=original.index(end,lo)+len(end);body=original[lo:hi];anchor='         else  ! use default MvG';assert body.count(anchor)==1
source=original[:lo]+body.replace(anchor,branch+anchor,1)+original[hi:];assert source.replace(branch,'',1)==original
path=build/'MOD_MvG_functions.f90';path.write_text(source,encoding='cp1252');q.update(original_module_lf_sha256=SHA(original.encode('cp1252')),prototype_module_lf_sha256=SHA(source.encode('cp1252')),complete_original_module_inverse=True,original_watcon_moiscap_and_hconduc_bodies_unchanged=True,actual_derivative_branch=branch)
probe='''   block
      use MOD_MvG,only:watcon,moiscap,hconduc,dhconduc,iHWCKmodel
      use MOD_grid,only:layer
      integer::probe_node,probe_power
      real(8)::probe_h,probe_d,probe_w,probe_c,probe_k,probe_dk,probe_l,probe_r,probe_l2,probe_r2,probe_wl,probe_wr
      do probe_node=1,numnod
         do probe_power=-4,3
            probe_h=-10d0**probe_power;probe_d=abs(probe_h)*1d-2
            probe_w=watcon(probe_node,probe_h);probe_c=moiscap(probe_node,probe_h)
            probe_k=hconduc(probe_node,probe_h,probe_w,1d0)
            probe_dk=dhconduc(probe_node,probe_h,probe_w,probe_c,1d0)
            probe_wl=watcon(probe_node,probe_h-probe_d);probe_wr=watcon(probe_node,probe_h+probe_d)
            probe_l=hconduc(probe_node,probe_h-probe_d,probe_wl,1d0);probe_r=hconduc(probe_node,probe_h+probe_d,probe_wr,1d0)
            probe_wl=watcon(probe_node,probe_h-probe_d/2d0);probe_wr=watcon(probe_node,probe_h+probe_d/2d0)
            probe_l2=hconduc(probe_node,probe_h-probe_d/2d0,probe_wl,1d0);probe_r2=hconduc(probe_node,probe_h+probe_d/2d0,probe_wr,1d0)
            write(*,'(a,3(1x,i0),8(1x,es25.17e3))') 'ACTUAL_ORIGINAL_INPUT_K_DERIVATIVE', &
               probe_node,layer(probe_node),iHWCKmodel(layer(probe_node)),probe_h,probe_w,probe_c,probe_k,probe_dk, &
               (probe_r-probe_l)/(2d0*probe_d),(probe_r2-probe_l2)/probe_d,probe_d
         end do
      end do
      stop 'ORIGINAL_INPUT_DERIVATIVE_PROBE_ZERO_MODEL_DAYS'
   end block
'''
main=(old/'swap_main.f90').read_bytes().replace(b'\r\n',b'\n').decode('cp1252');anchor='   flush(output_unit)\n   do\n';assert main.count(anchor)==1;probe_source=main.replace(anchor,'   flush(output_unit)\n'+probe+'   do\n',1);assert probe_source.replace(probe,'',1)==main
probe_main=build/'probe_main.f90';probe_main.write_text(probe_source,encoding='cp1252');q['probe_source_lf_sha256']=SHA(probe_source.encode('cp1252'));os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH'];objects=reference/'build/swap-obj';ttutil=reference/'build/ttutil-obj';flags=['gfortran',*identity['donor_flags'],'-I',str(build),'-I',str(old),'-I',str(objects),'-I',str(ttutil)]
commands=[[ *flags,'-c',str(path)], [*flags,'-c',str(probe_main)]]
generated={Path(n).stem for n in identity['donor_generated']};donor_objects=sorted(objects.glob('*.o'));names={p.stem for p in donor_objects};link=[]
for p in donor_objects:
    chosen=build if p.stem=='MOD_MvG_functions' else head if p.stem=='headcalc' else old
    link.append(str(chosen/(p.stem+'.o')) if p.stem in generated else str(p))
link += [str(old/(n+'.o')) for n in sorted(generated-names)];link.append(str(old/'hybrid_step_budget.o'))
donor=build/'day_donor.exe';commands.append(['gfortran','-o',str(donor),*link,str(ttutil/'libttutil.a')]);probe_link=[str(build/'probe_main.o') if Path(p).name=='swap_main.o' else p for p in link];probe_exe=build/'derivative_probe.exe';commands.append(['gfortran','-o',str(probe_exe),*probe_link,str(ttutil/'libttutil.a')])
for index,cmd in enumerate(commands):
    run=subprocess.run(cmd,cwd=build,capture_output=True);(work/(str(index)+'.stdout')).write_bytes(run.stdout);(work/(str(index)+'.stderr')).write_bytes(run.stderr);run.check_returncode()
q.update(commands=commands,prototype_executable_sha256=SHA(donor.read_bytes()),probe_executable_sha256=SHA(probe_exe.read_bytes()),linked_objects={p:SHA(Path(p).read_bytes()) for p in link});save()
inputs=E/'closure13-residual-feedback-v1/O0'/name/'inputs';probe_dir=work/'component-v2';shutil.copytree(inputs,probe_dir);run=subprocess.run([str(probe_exe),'./swap.swp'],cwd=probe_dir,capture_output=True,timeout=20);(probe_dir/'probe.stdout').write_bytes(run.stdout);(probe_dir/'probe.stderr').write_bytes(run.stderr);q['component_returncode']=run.returncode
rows=[line.split() for line in run.stdout.decode().splitlines() if line.startswith('ACTUAL_ORIGINAL_INPUT_K_DERIVATIVE ')];assert run.returncode==0 and len(rows)==34*8
errors=[]
for row in rows:
    values=list(map(float,row[4:]));assert len(values)==8 and all(math.isfinite(v) for v in values);dk,fd1,fd2=values[4:7];scale=max(abs(dk),abs(fd2),1e-100);errors.append(abs(dk-(4*fd2-fd1)/3)/scale)
q['component_probe']=dict(samples=len(rows),actual_models=sorted({int(row[3]) for row in rows}),maximum_relative_derivative_difference=max(errors),criterion='Relative5e-5 against Richardson-extrapolated original K central differences (relative steps1e-2 and5e-3; first cancellation-sensitive1e-4 comparison retained separately) of literal original K on every actually initialized node, heads1e-4..1e3; separate from unchanged1e-10 physical budgets',pass_=max(errors)<5e-5);save();assert q['component_probe']['pass_'],q['component_probe']
for p in old.glob('*restart*'):
    if p.is_file():shutil.copyfile(p,build/p.name)
project=m.e.load(str(inputs),original_output=True,time_step_policy='original-adaptive-day-seed-v1');checkpoint=full/'accepted-column-1-day-30.zip';q['original_checkpoint_sha256']=SHA(checkpoint.read_bytes());origin=work/'origin';receipt=m.h.verify_checkpoint(checkpoint,30,meta['binding'],origin);out=E/'closure13-analytic-derivative-prototype-v1';out.mkdir();started=time.perf_counter()
try:q['result'],q['model_seconds']=m.bounded(60,lambda:m.h.run(donor,m.h.executable(old,'day_kernel'),inputs,out,35,checkpoint_day=30,origin=origin,origin_receipt=receipt,runtime=True,publish_day=35,checkpoint_binding=meta['binding'],model=project.model,project=project))
except Exception as error:q.update(error=repr(error),traceback=traceback.format_exc())
finally:
    q.update(seconds=time.perf_counter()-started,accepted_resumed_days=len((out/'daily.jsonl').read_text().splitlines()) if (out/'daily.jsonl').exists() else 0,status='ACTUAL_ANALYTICAL_DERIVATIVE_PROTOTYPE_RETAINED_NOT_QUALIFICATION');assert SHA(checkpoint.read_bytes())==q['original_checkpoint_sha256'];save()
print(q['status'],q['accepted_resumed_days'],q.get('error'),q['component_probe'],flush=True)
