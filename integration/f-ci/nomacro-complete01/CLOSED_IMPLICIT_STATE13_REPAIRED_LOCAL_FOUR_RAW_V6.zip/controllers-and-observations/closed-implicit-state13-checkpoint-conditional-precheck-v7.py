from pathlib import Path
import ast,difflib,hashlib,json,shutil,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';BASE='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';POLICY='original-closed-implicit-residual-start-and-conditional-convergence-v3'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest();files=set(git('diff','--name-only',BASE,'--','app').decode().splitlines());assert len(files)==13
proposal=dict(status='IMPLEMENTED_SIGNED_ORIGINAL_RESIDUAL_START_AND_ONCE_PER_CURRENT_ITERATE_COMPLETE_CONVERGENCE_CHECK_NOT_QUALIFIED',actual_canonical_parent=BASE,physical_equations_changed=False,new_physical_state=False,new_numerical_policy=True,numerical_policy=POLICY,accepted_stock_flux_or_parameter_corrections=False,tolerances_or_iteration_limits_changed=False,files={})
for path in sorted(files):
    new=subprocess.run(['git','cat-file','-e',BASE+':'+path],cwd=R,capture_output=True).returncode!=0;before=b'' if new else git('show',BASE+':'+path);after=(R/path).read_bytes().replace(b'\r\n',b'\n');a=before.decode();b=after.decode()
    if path.endswith('.py'):ast.parse(after)
    edits=[dict(base_start=lo,base_end=hi,before=a[lo:hi],after=b[j:k]) for tag,lo,hi,j,k in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if tag!='equal'];proposal['files'][path]=dict(new_file=new,before_lf_sha256=SHA(before),after_lf_sha256=SHA(after),ordered_literal_edits=edits)
(P/'CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V7.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf8')
path=R/'tests/nomacro_drainage/closed_implicit_state_source_contract.py';text=path.read_text();assert text.count('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V6.json')==1;text=text.replace('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V6.json','CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V7.json').replace('original-closed-implicit-residual-start-and-convergence-order-v2',POLICY);ast.parse(text);path.write_text(text,encoding='utf8')
name='CLOSED_IMPLICIT_STATE13_CONVERGENCE_PRECHECK_REGRESSION_FAILURES_RAW_V5'
for suffix in ['.zip','.json']:
    source=E/(name+suffix);target=P/source.name;assert not target.exists();shutil.copyfile(source,target);assert SHA(source.read_bytes())==SHA(target.read_bytes())
assert SHA((P/(name+'.zip')).read_bytes())=='d6cf52bfa315ae73a88af7abc77f3f22afe4cb1364c8f690519bf09b441b698a'
for filename in ['STATUS.json','GAP_MATRIX.json']:
    path=P/filename;q=json.loads(path.read_text());item=q['closed_implicit_state13'];item.update(status='CONDITIONAL_CURRENT_ITERATE_COMPLETE_CONVERGENCE_CHECK_IMPLEMENTED_NOT_QUALIFIED',source_proposal='CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V7.json',new_numerical_policy=POLICY,fifth_local_feedback=dict(actual_source='3ee4db1ceeb9d923d44fd833f82d196e116a23c0',attempts=4,complete_contexts=0,partial_primary_days=7,classification='NUMERICAL_DEFECT',cause='Residual-only precheck repeatedly jumped to full budget rejection without Newton progress. A local nonserialized iterate-check flag now requires a real Newton residual evaluation after rejection; original mandatory polish remains separately repeatable.',raw=name+'.zip',sha256=SHA((P/(name+'.zip')).read_bytes())),next_action='Run four actual35day regressions on conditional per-iterate convergence order, then independent science. Continue all14 portable/source/native preservation after this local gate passes; no13 canonical admission.')
    if filename=='STATUS.json':q['test_selection']['groups']['closed_implicit_feedback'].update(changed_dependency='Local nonserialized per-iterate check ownership: a failed complete convergence/pond/budget test requires actual Newton progress; genuine vector_F reevaluation or unchanged original mandatory polish resets eligibility. Original physical state, rates, equations and tolerances remain intact.',existing_evidence='Four actual3ee4 early failures,7 partial primarydays, complete original raw d6cf52bf preserved. Four concrete generated source forms accept the exact new ownership seams and invert completely to their genuine original parent. All prior failure/censor/local-PASS/prototype roles retained; portable qualification pending.',expected_seconds=900)
    path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
doc=R/'docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md';text=doc.read_text().replace('original-closed-implicit-residual-start-and-convergence-order-v2',POLICY)
text+='''
Actual3ee4 V2 full regressions expose four early failures (7 total partial days),
because a failed strict budget check could return to the same residual-only
precheck indefinitely without Newton progress. RAW V5 d6cf52bf retains every
actual source/input/build/stdout/native byte and failure identity. V3 adds only
a transient HeadCalc-local iterate-check flag. A current candidate is checked
once; failed full acceptance then requires an actual Newton vector evaluation.
The unchanged mandatory original polish may recheck an already feasible point.
No physical/native state or clock counter is assigned; original loop bounds,
complete head/pond/soil/budget criteria and rollback still own acceptance.
Four actual previous generated forms pass exact new literal seams/inverses.
Actual production V3 coupled qualification is pending.
''';doc.write_text(text,encoding='utf8')
git('add','--sparse','--','app','tests/nomacro_drainage/closed_implicit_state_source_contract.py',str(P.relative_to(R)),str(doc.relative_to(R)));git('commit','-m','Require actual Newton progress after a failed complete implicit iterate check')
C=git('rev-parse','HEAD').decode().strip();path=P/'STATUS.json';q=json.loads(path.read_text());q['test_selection']['candidate']=C;path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');git('add','--',str(path.relative_to(R)));git('commit','-m','Bind conditional implicit convergence regressions to actual source')
print(git('rev-parse','HEAD').decode().strip(),flush=True)
