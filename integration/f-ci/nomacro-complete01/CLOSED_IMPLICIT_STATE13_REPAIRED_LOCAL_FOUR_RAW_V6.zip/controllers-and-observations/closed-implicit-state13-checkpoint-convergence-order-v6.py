from pathlib import Path
import ast,difflib,hashlib,json,shutil,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';BASE='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';POLICY='original-closed-implicit-residual-start-and-convergence-order-v2'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
files=set(git('diff','--name-only',BASE,'--','app').decode().splitlines());assert len(files)==13
proposal=dict(status='IMPLEMENTED_SIGNED_ORIGINAL_RESIDUAL_TRIAL_START_AND_UNCHANGED_COMPLETE_CONVERGENCE_PRECHECK_NOT_QUALIFIED',actual_canonical_parent=BASE,physical_equations_changed=False,new_physical_state=False,new_numerical_policy=True,numerical_policy=POLICY,accepted_stock_flux_or_parameter_corrections=False,tolerances_or_iteration_limits_changed=False,files={})
for path in sorted(files):
    check=subprocess.run(['git','cat-file','-e',BASE+':'+path],cwd=R,capture_output=True);new=check.returncode!=0;before=b'' if new else git('show',BASE+':'+path);after=(R/path).read_bytes().replace(b'\r\n',b'\n');a=before.decode();b=after.decode()
    if path.endswith('.py'):ast.parse(after)
    edits=[dict(base_start=lo,base_end=hi,before=a[lo:hi],after=b[j:k]) for tag,lo,hi,j,k in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if tag!='equal']
    proposal['files'][path]=dict(new_file=new,before_lf_sha256=SHA(before),after_lf_sha256=SHA(after),ordered_literal_edits=edits)
(P/'CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V6.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf8')
path=R/'tests/nomacro_drainage/closed_implicit_state_source_contract.py';text=path.read_text();assert text.count('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V5.json')==1;text=text.replace('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V5.json','CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V6.json').replace('original-closed-implicit-saturated-residual-initial-iterate-v1',POLICY);ast.parse(text);path.write_text(text,encoding='utf8')
name='CLOSED_IMPLICIT_STATE13_RESIDUAL_FAILURES_SUCCESSES_AND_CAUSAL_PROTOTYPES_RAW_V4'
for suffix in ['.zip','.json']:
    source=E/(name+suffix);target=P/source.name;assert not target.exists();shutil.copyfile(source,target);assert SHA(source.read_bytes())==SHA(target.read_bytes())
assert SHA((P/(name+'.zip')).read_bytes())=='cacdaae6a05ed728c7e6a8f8e71e320ca9f42f5a9049956ea16df8890d1edb29'
for filename in ['STATUS.json','GAP_MATRIX.json']:
    path=P/filename;q=json.loads(path.read_text());item=q['closed_implicit_state13']
    item.update(status='SIGNED_ORIGINAL_RESIDUAL_START_AND_ORIGINAL_CONVERGENCE_ORDER_IMPLEMENTED_NOT_QUALIFIED',source_proposal='CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V6.json',new_numerical_policy=POLICY,fourth_local_feedback=dict(actual_source='84452a487cf7b4726953be695867e53397daf396',complete_Frost_contexts=2,primary_Frost_days=70,independent_science=True,ordinary_model5_CDE_day26_numerical_failure=True,Snow_model6_CDE_censor_after33days=True,signed_residual_model5_cold_prototype_resumed_days=26,Snow_original_convergence_precheck_cold_prototype_resumed_days=5,analytical_derivative_prototype_alone_did_not_solve_Snow=True,analytical_derivative_prototype_not_installed=True,raw=name+'.zip',sha256=SHA((P/(name+'.zip')).read_bytes())),next_action='Requalify four previously failing/censored actual35day contexts on signed original-residual start and unchanged complete convergence precheck; then all14 Windows/Ubuntu O0/O2 plus native/current-parent compiler preservation. No canonical13 admission yet.')
    if filename=='STATUS.json':
        group=q['test_selection']['groups']['closed_implicit_feedback']
        group.update(changed_dependency='Signed original vector_F initial iterate for both wetting/drying; evaluate unchanged complete convergence block on residual-converged current iterate before ill-conditioned linear solve. Original constitutive derivatives, physical functions, state, criteria, loops and limits retained.',scientific_claim='Four original35day failure regressions O0/O2 with exact native/cold/transactions and independent1e-10 budgets. Broad14 portable matrix and actual old native-provider impact preservation remain required.',existing_evidence='84452:2 Frost35day/native/cold/transactions/compiled controls independently pass; ordinary model5 day26 fails; Snow33day censored. Signed root alone completes26 model5 cold days; complete original convergence-precheck prototype completes5 Snow cold days. Complete cacdaae6 raw preserves all roles including derivative-only diagnostic (not installed).',expected_seconds=900)
    path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
doc=R/'docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md';text=doc.read_text();text=text.replace('`original-closed-implicit-saturated-residual-initial-iterate-v1`','`'+POLICY+'`').replace('zero trial pond, all-zero moisture capacities and an unresolved positive original\nresidual identify the saturated plateau. A uniform trial-head shift brackets and','zero trial pond and an unresolved nonzero original total residual select the\ninitial trial search. A signed uniform trial-head shift brackets and').replace('This changes the starting trial iterate, then returns to the unchanged full','This changes the starting trial iterate for wetting and drying. When a current\niterate already meets the original compartment and total residual criteria, the\ncomplete original convergence block is evaluated before a potentially ill-\nconditioned linear solve. The actual head step is zero because no Newton move\nhas been made; no head, residual, physical stock or flux is assigned. All original\npond, head-change, strict budget and extra-polish checks still run. Otherwise\nthe original linear solve/backtracking executes. Both paths retain the unchanged full')
text+='''
Actual84452: both earlier Frost failures complete35 days and independent audits;
ordinary model5 CDE still fails at day26; Snow model6 CDE remains censored after33
days. Diagnostics expose near-zero physical residuals but large spurious Newton
head directions on the saturated closed column. The signed-residual prototype
completes26 resumed model5 days; the complete-convergence-precheck prototype
completes5 resumed Snow days. Exact analytical K derivative probes separately
pass but do not remove the Snow censor, so that derivative change is not
installed. RAW V4 cacdaae6 preserves all source/binary/positive/failure/censor
roles. New production V2 qualification remains pending.
''';doc.write_text(text,encoding='utf8')
git('add','--sparse','--','app','tests/nomacro_drainage/closed_implicit_state_source_contract.py',str(P.relative_to(R)),str(doc.relative_to(R)));git('commit','-m','Evaluate original closed implicit convergence before an unnecessary Newton solve')
C=git('rev-parse','HEAD').decode().strip();path=P/'STATUS.json';q=json.loads(path.read_text());q['test_selection']['candidate']=C;path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');git('add','--',str(path.relative_to(R)));git('commit','-m','Select signed residual and complete convergence production regressions')
print(git('rev-parse','HEAD').decode().strip(),flush=True)
