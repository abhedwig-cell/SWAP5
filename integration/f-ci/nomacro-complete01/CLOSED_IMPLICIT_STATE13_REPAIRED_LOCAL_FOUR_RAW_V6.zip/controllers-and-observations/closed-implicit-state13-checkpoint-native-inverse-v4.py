from pathlib import Path
import ast,difflib,hashlib,json,shutil,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';BASE='2e98506b4fb469bbf5995a8ab0b49c88ead0972c'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
proposal=dict(status='IMPLEMENTED_CLOSED_IMPLICIT_OUTPUT_AND_COMPLETE_PARENT_NATIVE_INVERSE_NOT_QUALIFIED',actual_canonical_parent=BASE,physical_equations_changed=False,new_physical_state=False,new_numerical_policy=False,files={})
files=git('diff','--name-only',BASE,'--','app').decode().splitlines();assert len(files)==10
for path in files:
    before=git('show',BASE+':'+path);after=(R/path).read_bytes().replace(b'\r\n',b'\n');a=before.decode();b=after.decode()
    if path.endswith('.py'):ast.parse(after)
    edits=[dict(base_start=lo,base_end=hi,before=a[lo:hi],after=b[j:k]) for tag,lo,hi,j,k in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if tag!='equal']
    proposal['files'][path]=dict(new_file=False,before_lf_sha256=SHA(before),after_lf_sha256=SHA(after),ordered_literal_edits=edits)
(P/'CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V4.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf8')
path=R/'tests/nomacro_drainage/closed_implicit_state_source_contract.py';text=path.read_text();assert text.count('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V3.json')==1;path.write_text(text.replace('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V3.json','CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V4.json'),encoding='utf8')
rawname='CLOSED_IMPLICIT_STATE13_OUTPUT_FEEDBACK_AND_CLOCK_OBSERVATION_RAW_V2'
for suffix in ['.zip','.json']:
    source=E/(rawname+suffix);target=P/source.name;assert not target.exists();shutil.copyfile(source,target)
    assert SHA(source.read_bytes())==SHA(target.read_bytes())
assert SHA((P/(rawname+'.zip')).read_bytes())=='c8ef491dc2664db877c916ee4868cf739d653e71d3d0840c136f8b089da50063'
for filename in ['STATUS.json','GAP_MATRIX.json']:
    path=P/filename;q=json.loads(path.read_text());item=q['closed_implicit_state13']
    item.update(source_files=10,source_proposal='CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V4.json',status='CLOSED_IMPLICIT_OUTPUT_COMPOSED_NATIVE_PARENT_INVERSE_REPAIRED_ONE_LOCAL_PASS_NOT_QUALIFIED',second_local_feedback=dict(actual_source='6a0e6ff6cab1c0a7565938f43ee3b1921f63eaa3',complete_contexts=1,complete_primary_days=35,partial_primary_days=25,numerical_defects=['closed-ordinary-model5-cde-profile O2 day26 clock resolution'],composition_missing=['closed-ordinary-model6-snow-cde-profile: whole parent native comparison had not inverted the separately validated implicit EOF witness'],raw=rawname+'.zip',sha256=SHA((P/(rawname+'.zip')).read_bytes())),next_action='Validate Snow complete native parent inverse and run this previously unexecuted original35day coupling. Keep Gardner35day PASS with exact source dependency proof; do not repeat its models for the Snow-only guard repair. Diagnose dry-pond saturated closed implicit Newton branch from day30 native observation without deleting water or changing tolerances.')
    if filename=='STATUS.json':
        q['test_selection']['groups']['closed_implicit_feedback'].update(existing_evidence='6a0e Gardner35day/native/cold/transactions PASS; ordinary model5 CDE day26 numerical failure25 partialdays; Snow native premodel guard failure. All bytes in c8ef491d raw. Original2215 Frost day30 cold observer reproduces day33 failure with2 accepted resumed days and removable stdout-only diagnostics.',scientific_claim='Snow model6 CDE original35day coupling after exact parent-native inverse repair. Native refusal controls on completed Gardner context without rerunning its warm days.',expected_seconds=300)
    path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
doc=R/'docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md'
with doc.open('a',encoding='utf8') as out:out.write('\nSource6a0e: Gardner monthly water O0 completes35 days with exact cold/native\nand transactions. Ordinary model5 CDE O2 fails at day26 after25 accepted days.\nSnow model6 CDE stops in the whole native parent validator before model days;\nthe repair removes only the exactly reconstructed implicit EOF witness before\ncomparing the complete parent procedure. Existing independent extension\nvalidation remains required. No physical/native layout bytes are changed.\nThe genuine2215 Frost day30 checkpoint reproduces failure after2 resumed days\nwith stdout-only pre-rollback observations: zero moisture capacity throughout\nthe saturated profile, tiny positive old pond, zero trial pond and persistent\nsoil residual. This localizes a numerical wet/dry transition; original\nreference causality remains UNKNOWN. RAW V2 c8ef491d retains all observations.\n')
git('add','--sparse','--','app','tests/nomacro_drainage/closed_implicit_state_native_controls.py','tests/nomacro_drainage/closed_implicit_state_source_contract.py',str(P.relative_to(R)),str(doc.relative_to(R)));git('commit','-m','Invert exact implicit native extension in Snow parent source admission')
C=git('rev-parse','HEAD').decode().strip();path=P/'STATUS.json';q=json.loads(path.read_text());q['test_selection']['candidate']=C;path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');git('add','--',str(path.relative_to(R)));git('commit','-m','Bind Snow native composition feedback to actual repaired source')
print(git('rev-parse','HEAD').decode().strip(),flush=True)
