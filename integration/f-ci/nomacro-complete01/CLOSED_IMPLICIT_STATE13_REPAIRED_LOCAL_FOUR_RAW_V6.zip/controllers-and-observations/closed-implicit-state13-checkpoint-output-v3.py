from pathlib import Path
import ast,difflib,hashlib,json,re,shutil,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
BASE='2e98506b4fb469bbf5995a8ab0b49c88ead0972c'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
sha=lambda b:hashlib.sha256(b).hexdigest()
files=git('diff','--name-only',BASE,'--','app').decode().splitlines()
assert len(files)==9,files
proposal=dict(status='IMPLEMENTED_ACTUAL_CLOSED_IMPLICIT_STATE_AND_ORIGINAL_CALENDAR_COMPOSITION_NOT_QUALIFIED',actual_canonical_parent=BASE,physical_equations_changed=False,new_physical_state=False,new_numerical_policy=False,files={})
for path in files:
    before=git('show',BASE+':'+path);after=(R/path).read_bytes().replace(b'\r\n',b'\n')
    if path.endswith('.py'):ast.parse(after)
    a=before.decode();b=after.decode();edits=[]
    for tag,lo,hi,j,k in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
        if tag!='equal':edits.append(dict(base_start=lo,base_end=hi,before=a[lo:hi],after=b[j:k]))
    proposal['files'][path]=dict(new_file=False,before_lf_sha256=sha(before),after_lf_sha256=sha(after),ordered_literal_edits=edits)
(P/'CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V3.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf8')
contract=R/'tests/nomacro_drainage/closed_implicit_state_source_contract.py'
text=contract.read_text();assert text.count('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V2.json')+text.count('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V3.json')==1
contract.write_text(text.replace('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V2.json','CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V3.json').replace('genuine canonical880','genuine canonical948'),encoding='utf8')
plan_path=P/'CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json';plan=json.loads(plan_path.read_text())
for spec in plan['cases']:
    raw=(E/'closure13-input-preflight-v1'/spec['name']/'inputs/swap.swp').read_bytes();text=raw.decode('cp1252')
    fields={}
    for key in ['NPRINTDAY','PERIOD','SWMONTH','SWODAT','SWRES','FLPRINTDT']:
        vals=re.findall(r'(?mi)^[ \t]*'+key+r'[ \t]*=[ \t]*([^!\r\n]+)',text)
        assert len(vals)<=1,(spec['name'],key)
        fields[key]=vals[0].strip() if vals else None
    spec['calendar']='unchanged-original-input'
    spec['original_output_controls']=fields
plan.update(status='ACTUAL_ORIGINAL_INPUT_PLAN_METADATA_CORRECTED_NO_INPUT_BYTES_CHANGED_NOT_QUALIFIED',calendar_description_correction='Earlier dense labels described no executed modification: prepare changed only SWDRA and SWBOTB. Exact failed producer2215 inputs remain in FIRST_LOCAL_FAILURES_RAW_V1.',actual_current_input_preflight_source='2215b9d93d3616160d5ac813bd0c7b879536171a')
plan_path.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8')
raw='CLOSED_IMPLICIT_STATE13_FIRST_LOCAL_FAILURES_RAW_V1'
for name in [raw+'.zip',raw+'.json','CLOSED_IMPLICIT_STATE13_FIRST_LOCAL_FAILURE_SUMMARY_V1.json']:
    src=E/name;assert src.is_file(),name
    dst=P/name;assert not dst.exists();shutil.copyfile(src,dst);assert sha(src.read_bytes())==sha(dst.read_bytes())
assert sha((P/(raw+'.zip')).read_bytes())=='0558985b573556487caf8160ea2dc1aee2c46c4d86b792abaa204198694eb783'
for name in ['STATUS.json','GAP_MATRIX.json']:
    path=P/name;q=json.loads(path.read_text());item=q['closed_implicit_state13']
    item.update(status='NINE_FILE_CLOSED_IMPLICIT_ORIGINAL_CALENDAR_COMPOSITION_IMPLEMENTED_NOT_QUALIFIED',source_proposal='CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V3.json',source_files=9,current_public_input_acceptances=14,new_qualified_contexts=0,new_admitted_contexts=0,first_local_feedback=dict(actual_source='2215b9d93d3616160d5ac813bd0c7b879536171a',attempts=5,complete=0,partial_days=64,composition_missing=3,numerical_defect=2,raw=raw+'.zip',sha256=sha((P/(raw+'.zip')).read_bytes()),numerical_failure='Frost mixed4-5 CDE O0 and mixed8-9 water O2 stop at day33 clock resolution after32 accepted days each. Original causality UNKNOWN; not LEGACY_DEFECT.'),next_action='Qualify corrected ordinary monthly/Snow/CDE output compositions on actual committed source. Diagnose Frost day33 independently from retained native state; no tolerance/date/parameter changes or warm-period reruns for metadata-only changes.')
    if name=='STATUS.json':
        group=q['test_selection']['groups']['closed_implicit_feedback']
        group['existing_evidence']='Canonical948 retained. Actual2215 all14 public inputs accepted; first5 feedback attempts failed (3 output compositions,2 Frost day33 numerical failures,64 partial accepted days). Full raw preserved0558985b. Actual dirty nine-file preflight accepts all14 original output metadata without compiler/models; production feedback remains pending.'
        item['local_feedback_selection']='Three repaired ordinary35day contexts: Gardner monthly water O0, Snow model6 CDE O0, ordinary model5 CDE O2. No replay of two unchanged Frost32day failures.'
    path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
doc=R/'docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md'
with doc.open('a',encoding='utf8') as f:f.write('\nCurrent repair checkpoint: nine production files compose the original monthly,\nper-step and Snow output owners using actual implicit inputs. No calendar or\nparameter bytes change. All14 current public inputs and output metadata are\naccepted; model qualification remains pending. The first five actual2215\nfeedback attempts all failed: three output-owner composition guards and two\nFrost clock-resolution failures after32 days each. Complete original failure\nbytes are preserved in FIRST_LOCAL_FAILURES_RAW_V1 (0558985b). The latter\nremain NUMERICAL_DEFECT with original causality UNKNOWN.\n')
git('add','--','app','tests/nomacro_drainage/closed_implicit_state_source_contract.py',str(P.relative_to(R)),str(doc.relative_to(R)))
git('commit','-m','Compose closed implicit original output owners and retain first physical failures')
print(git('rev-parse','HEAD').decode().strip())
