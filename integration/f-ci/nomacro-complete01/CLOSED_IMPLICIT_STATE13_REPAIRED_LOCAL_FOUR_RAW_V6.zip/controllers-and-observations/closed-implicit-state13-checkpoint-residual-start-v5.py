from pathlib import Path
import ast,difflib,hashlib,json,shutil,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';BASE='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';POLICY='original-closed-implicit-saturated-residual-initial-iterate-v1'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
files=set(git('diff','--name-only',BASE,'--','app').decode().splitlines())|set(git('ls-files','--others','--exclude-standard','--','app').decode().splitlines());assert len(files)==13,files
proposal=dict(status='IMPLEMENTED_BOUNDED_CLOSED_IMPLICIT_ORIGINAL_RESIDUAL_TRIAL_INITIALIZATION_NOT_QUALIFIED',actual_canonical_parent=BASE,physical_equations_changed=False,new_physical_state=False,new_numerical_policy=True,numerical_policy=POLICY,accepted_stock_flux_or_parameter_corrections=False,tolerances_or_iteration_limits_changed=False,files={})
for path in sorted(files):
    check=subprocess.run(['git','cat-file','-e',BASE+':'+path],cwd=R,capture_output=True);new=check.returncode!=0;before=b'' if new else git('show',BASE+':'+path);after=(R/path).read_bytes().replace(b'\r\n',b'\n');a=before.decode();b=after.decode()
    if path.endswith('.py'):ast.parse(after)
    edits=[dict(base_start=lo,base_end=hi,before=a[lo:hi],after=b[j:k]) for tag,lo,hi,j,k in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if tag!='equal']
    proposal['files'][path]=dict(new_file=new,before_lf_sha256=SHA(before),after_lf_sha256=SHA(after),ordered_literal_edits=edits)
(P/'CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V5.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf8')
path=R/'tests/nomacro_drainage/closed_implicit_state_source_contract.py';text=path.read_text();assert text.count('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V4.json')==1
text=text.replace('CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V4.json','CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V5.json')
old="and not contract['new_numerical_policy']";assert text.count(old)==1
text=text.replace(old,"and contract['new_numerical_policy'] is True\n    assert contract['numerical_policy']=='"+POLICY+"' and not contract['tolerances_or_iteration_limits_changed'] and not contract['accepted_stock_flux_or_parameter_corrections']",1)
text=text.replace('physical_equations_changed=False,new_physical_state=False,new_numerical_policy=False,','physical_equations_changed=False,new_physical_state=False,new_numerical_policy=True,numerical_policy=contract[\'numerical_policy\'],')
ast.parse(text);path.write_text(text,encoding='utf8')
name='CLOSED_IMPLICIT_STATE13_SNOW_CENSOR_AND_NUMERICAL_PROTOTYPE_RAW_V3'
for suffix in ['.zip','.json']:
    source=E/(name+suffix);target=P/source.name;assert not target.exists();shutil.copyfile(source,target);assert SHA(source.read_bytes())==SHA(target.read_bytes())
assert SHA((P/(name+'.zip')).read_bytes())=='087bda732165fb78d898c37628d42004d26dc31ea79a536e7361742c49c9a85a'
for filename in ['STATUS.json','GAP_MATRIX.json']:
    path=P/filename;q=json.loads(path.read_text());item=q['closed_implicit_state13']
    item.update(status='BOUNDED_CLOSED_IMPLICIT_SATURATED_INITIAL_ITERATE_REPAIR_IMPLEMENTED_NOT_QUALIFIED',source_files=13,source_proposal='CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V5.json',new_numerical_policy=POLICY,physical_equations_changed=False,tolerances_changed=False,accepted_stores_fluxes_dates_or_parameters_corrected=False,third_local_feedback=dict(actual_source='66dae38844cf8d16508e76b6caee4460c11e5fdc',Snow_model6_CDE='CENSORED_AT_240_SECONDS_AFTER33_ACCEPTED_DAYS_NOT_PASS',Gardner_native_refusals=19,prototype_actual_original_source='2215b9d93d3616160d5ac813bd0c7b879536171a',prototype_day30_cold_resumed_days=5,prototype_days31_32_exact=True,prototype_independent_budget_pass=True,prototype_qualified=False,raw=name+'.zip',sha256=SHA((P/(name+'.zip')).read_bytes())),next_action='First test actual production original-residual initial-iterate owner on four previously failing/censored contexts O0/O2. Then all14 finite cases portable/full native/cold/transactions and required original-parent preservation. No current13 scientific qualification or canonical admission yet.')
    if filename=='STATUS.json':
        group=q['test_selection']['groups']['closed_implicit_feedback']
        group.update(changed_dependency='Closed6/no-drainage implicit analytical Newton saturated initial iterate: scalar search along uniform trial-head shift using only original residual/constitutive/root functions, followed by unchanged original full Newton and strict acceptance. Complete Snow/ordinary/Frost parent source guards invert this literal provider.',scientific_claim='Four original35day couplings previously failed/censored: Frost4-5 CDE O0, Frost8-9 water O2, ordinary model5 CDE O2, Snow model6 CDE O0; exact native/cold, independent1e-10 budgets and external transactions. Subsequent portable14 required for qualification.',existing_evidence='Prototype from genuine2215 day30 original native state completes5 resumed days, budgets1e-10 and first2 days exact. First failures0558985b, output repairs c8ef491d, Snow33day censor/prototype087bda73 retained. Gardner6a0e35days/native/cold/transactions and19compiled refusals retained but not evidence of new-policy qualification.',expected_seconds=900)
    path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
doc=R/'docs/science/NOMACRO_CLOSED_IMPLICIT_STATE13.md'
doc.write_text('''# Original closed implicit analytical composition and saturated trial start

Candidate following actual canonical948
`2e98506b4fb469bbf5995a8ab0b49c88ead0972c`; not qualified or admitted.
Fourteen unchanged original analytical2..11 input decks (including mixed and
inactive-vapor layers) change only SWDRA=0 and SWBOTB=6. All14 original zero-day
reader acceptances, actual current public inputs and output metadata are retained.
Non1+hysteresis, table/RIA12, active vapor and implicit paired9 are outside scope.

Existing ordinary monthly/per-step, Snow and Frost native/output owners are
composed without altering their requested calendar, physical parameters or state.
The per-layer implicit EOF extension has a complete literal inverse; parent
procedure validation and independent compiled extension checks remain required.

The new numerical policy is
`original-closed-implicit-saturated-residual-initial-iterate-v1`. It selects only
the new analytical closed6/no-drainage implicit scope. At the first Newton iterate,
zero trial pond, all-zero moisture capacities and an unresolved positive original
residual identify the saturated plateau. A uniform trial-head shift brackets and
bisects the sum of the ORIGINAL vector_F, recomputing original watcon/hconduc,
conductivity means and root extraction. The existing MaxIt1 bounds the search.
This changes the starting trial iterate, then returns to the unchanged full
Newton/backtracking, original rollback and every original/strict budget criterion.
No accepted stock, flux, moment, pressure, date, parameter or tolerance is fixed.
No physical equation or accepted/native state is added. The full generated body
must invert exactly to its qualified parent; arbitrary candidate hashes cannot
authorize it. Full production qualification remains pending.

Actual2215: three premodel output guards and two Frost failures after32 accepted
days each; raw0558985b. Actual6a0e: Gardner monthly water O0 completes35 days,
exact native/cold/transactions; ordinary model5 CDE O2 fails at day26 after25
days; Snow model6 CDE stops at its parent-native guard before models; rawc8ef491d.
Actual66dae: repaired Snow native guard passes, then the model is censored at240s
after33 accepted days. None is silently upgraded. The standalone provisional
residual initial-iterate diagnostic resumes genuine2215 day30 through day35,
retains exact prior days31/32 and independent1e-10 budgets; raw087bda73.
The original main's CSV initialization crashes on a positive control; changing
only SWCSV to0 completes original zero-day task1. Original full-period physical
causality remains UNKNOWN; this establishes no LEGACY_DEFECT or equivalence.

Whole migration PARTIAL; scientific equivalence NOT_QUALIFIED; global family/gap
counts UNKNOWN; fixed RC3 unchanged. Explicit Gardner/Snow9 numerical gaps,
AGE dry-pond moments and paired9 active-vapor thermal semantics remain separate.
''',encoding='utf8')
git('add','--sparse','--','app','tests/nomacro_drainage/closed_implicit_state_source_contract.py',str(P.relative_to(R)),str(doc.relative_to(R)));git('commit','-m','Start saturated closed implicit Newton trials on the original residual manifold')
C=git('rev-parse','HEAD').decode().strip();path=P/'STATUS.json';q=json.loads(path.read_text());q['test_selection']['candidate']=C;path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');git('add','--',str(path.relative_to(R)));git('commit','-m','Select real previously failing closed implicit coupling regressions')
print(git('rev-parse','HEAD').decode().strip(),flush=True)
