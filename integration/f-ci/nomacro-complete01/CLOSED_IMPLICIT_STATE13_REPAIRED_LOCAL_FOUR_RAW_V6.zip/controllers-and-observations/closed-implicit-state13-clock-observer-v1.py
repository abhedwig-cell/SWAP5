"""Actual failed2215 executable with removable stdout-only Newton diagnostics."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,traceback
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from closed_implicit_state_feedback import m
old=W/'closure13-feedback-O0-v1/current/closed-frost-mixed4-5-cde/bundle'
full=E/'closure13-local-feedback-v1/O0/closed-frost-mixed4-5-cde/trajectory'
build=W/'closure13-clock-observer-O0-v1';work=W/'closure13-clock-observer-v1'
reference=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
meta=json.loads((old/'BUILD.json').read_text());identity=meta['identity'];SHA=lambda b:hashlib.sha256(b).hexdigest()
q=dict(actual_scientific_producer='2215b9d93d3616160d5ac813bd0c7b879536171a',actual_original_BUILD_sha256=SHA((old/'BUILD.json').read_bytes()),observer='removable stdout-only before original failed Newton rollback',physical_equations_or_parameters_changed=False,accepted_state_assignments_added=False,tolerances_changed=False,source_or_producer_roles_rebound=False,canonical_admission=False)
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_CLOCK_OBSERVER_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH'];os.environ['OMP_NUM_THREADS']='1'
original=(old/'headcalc.f90').read_bytes().replace(b'\r\n',b'\n').decode('cp1252')
anchor='!  Convergence could not been reached'
assert original.count(anchor)==1
addition="""   if(dt<=dtmin)then
      write(*,'(a,*(1x,es25.17e3))') 'OBSERVER_FAILED_NEWTON',t1900,dt,pondm1,pond,q0,qtop, &
         minval(h(1:NN)),maxval(h(1:NN)),minval(dimoca(1:NN)),maxval(dimoca(1:NN)), &
         minval(F(1:NN)),maxval(F(1:NN)),sumold,sump
      write(*,*) 'OBSERVER_FAILED_NEWTON_FLAGS',numbit,MaxIt1,ierror,flnonconv,flnonconv3
      flush(6)
   end if
"""
source=original.replace(anchor,addition+anchor,1);assert source.replace(addition,'',1)==original
path=build/'headcalc.f90';path.write_text(source,encoding='cp1252')
q['original_headcalc_lf_sha256']=SHA(original.encode('cp1252'));q['observer_headcalc_lf_sha256']=SHA(source.encode('cp1252'));q['stdout_addition']=addition
objects=reference/'build/swap-obj';ttutil=reference/'build/ttutil-obj'
command=['gfortran',*identity['donor_flags'],'-I',str(old),'-I',str(objects),'-I',str(ttutil),'-c',str(path)]
q['compile_command']=command;run=subprocess.run(command,cwd=build,capture_output=True);(work/'compile.stdout').write_bytes(run.stdout);(work/'compile.stderr').write_bytes(run.stderr);run.check_returncode()
generated={Path(name).stem for name in identity['donor_generated']}
donor_objects=sorted(objects.glob('*.o'));names={p.stem for p in donor_objects}
link=[str((build if p.stem=='headcalc' else old)/(p.stem+'.o')) if p.stem in generated else str(p) for p in donor_objects]
link += [str(old/(name+'.o')) for name in sorted(generated-names)]
link.append(str(old/'hybrid_step_budget.o'))
donor=build/'day_donor.exe';command=['gfortran','-o',str(donor),*link,str(ttutil/'libttutil.a')];q['link_command']=command
run=subprocess.run(command,cwd=build,capture_output=True);(work/'link.stdout').write_bytes(run.stdout);(work/'link.stderr').write_bytes(run.stderr);run.check_returncode()
q['observer_executable_sha256']=SHA(donor.read_bytes());q['linked_objects']={p:SHA(Path(p).read_bytes()) for p in link};save()
input_root=E/'closure13-local-feedback-v1/O0/closed-frost-mixed4-5-cde/inputs'
project=m.e.load(str(input_root),original_output=True,time_step_policy='original-adaptive-event-closure-v1')
checkpoint=full/'accepted-column-1-day-30.zip';q['original_checkpoint_sha256']=SHA(checkpoint.read_bytes());origin=work/'origin-v2';receipt=m.h.verify_checkpoint(checkpoint,30,meta['binding'],origin)
for path in old.glob('*restart*'):
    if path.is_file():shutil.copyfile(path,build/path.name)
out=E/'closure13-clock-observer-v2';out.mkdir();started=time.perf_counter()
try:
    q['result']=m.h.run(donor,m.h.executable(old,'day_kernel'),input_root,out,33,checkpoint_day=30,origin=origin,origin_receipt=receipt,runtime=True,publish_day=33,checkpoint_binding=meta['binding'],model=project.model,project=project)
except Exception as error:q.update(error=repr(error),traceback=traceback.format_exc())
finally:
    q['seconds']=time.perf_counter()-started
    q['accepted_resumed_days']=len((out/'daily.jsonl').read_text().splitlines()) if (out/'daily.jsonl').exists() else 0
    assert SHA(checkpoint.read_bytes())==q['original_checkpoint_sha256']
    q['status']='ACTUAL_DAY30_COLD_NEWTON_OBSERVATION_RETAINED_NOT_QUALIFICATION';save()
print(q['status'],q['accepted_resumed_days'],q.get('error'),flush=True)
