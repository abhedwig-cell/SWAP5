from pathlib import Path
import difflib,hashlib,json,re,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');SHA=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(R/'reference/swap-4.3.1/source-archives/SWAP.ZIP') as z:raw=z.read('SWAP/swap.f90')
original=re.sub(rb'\r+\n',b'\n',raw).decode('cp1252');sdk=(J/'build/swap-selected/swap.f90').read_text(encoding='cp1252')
diff=''.join(difflib.unified_diff(original.splitlines(True),sdk.splitlines(True),fromfile='ORIGINAL_SWAP_ZIP/swap.f90',tofile='J_actual_selected/swap.f90'))
(E/'CLOSED_IMPLICIT_STATE13_ORIGINAL_SWAP_VERSUS_SDK_V1.diff').write_text(diff,encoding='utf8')
q=dict(original_archive_member='SWAP/swap.f90',original_raw_sha256=SHA(raw),original_lf_sha256=SHA(original.encode('cp1252')),actual_J_selected_lf_sha256=SHA(sdk.encode('cp1252')),identical=original==sdk,model_executions=0)
(E/'CLOSED_IMPLICIT_STATE13_ORIGINAL_SWAP_VERSUS_SDK_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(json.dumps(q));print(diff[:8500])
