from pathlib import Path
import json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
path=R/'integration/f-ci/nomacro-complete01/STATUS.json';q=json.loads(path.read_text());q['test_selection']['candidate']=head
q['test_selection']['groups']['closed_implicit_feedback']['existing_evidence']='Genuine canonical948 admission archive d4ec3ee6; original14 zero-day acceptances/current0 acceptances; two exact original-SDK proposed native compiles. First source13 proof rejected its two Fortran files through a Python-only AST check before any model; corrected to retain full literal byte proofs and parse Python files only.'
path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');git('add','--','integration/f-ci/nomacro-complete01/STATUS.json');git('commit','-m','Complete stable source13 local feedback evidence selection')
print(git('rev-parse','HEAD').decode().strip())
