from pathlib import Path
import hashlib,json,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path.insert(0,str(R/'app/hybrid_water'));import implicit_closed_desaturation as owner
q=json.loads((E/'CLOSED_IMPLICIT_STATE13_RESIDUAL_PRECHECK_PROTOTYPE_V1.json').read_text());old_trigger=q['prototype_trigger'];old_check=q['original_complete_convergence_precheck'];old_routine=q['prototype_routine']+'\n';SHA=lambda b:hashlib.sha256(b).hexdigest();records=[]
for opt,names in [('O0',['closed-frost-mixed4-5-cde','closed-ordinary-model6-snow-cde-profile']),('O2',['closed-frost-mixed8-9-water','closed-ordinary-model5-cde-profile'])]:
    for name in names:
        path=W/('closure13-residual-feedback-'+opt+'-v2')/'current'/name/'bundle/headcalc.f90';actual=path.read_text(encoding='cp1252');parent=actual
        for part in [old_trigger,old_check,old_routine]:assert parent.count(part)==1;parent=parent.replace(part,'',1)
        updated=owner.source(parent);assert owner.restore(updated)==parent and updated!=actual
        records.append(dict(case=name,optimization=opt,actual_previous_generated_lf_sha256=SHA(actual.encode('cp1252')),complete_original_parent_lf_sha256=SHA(parent.encode('cp1252')),new_generated_lf_sha256=SHA(updated.encode('cp1252')),all_actual_literal_iterate_seams_unique=True,complete_parent_inverse=True))
report=dict(status='FOUR_CONCRETE_ACTUAL_OLD_BUNDLES_NEW_CONDITIONAL_ITERATE_OWNERSHIP_SOURCE_AND_COMPLETE_INVERSES_PASS_ZERO_MODELS',working_owner_lf_sha256=SHA((R/'app/hybrid_water/implicit_closed_desaturation.py').read_bytes().replace(b'\r\n',b'\n')),cases=records,compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'CLOSED_IMPLICIT_STATE13_CONCRETE_CONDITIONAL_SOURCE_PREFLIGHT_V7.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(report['status'],flush=True)
