from pathlib import Path
import ast
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
text=(R/'tests/nomacro_drainage/implicit_hydraulic_state_current_postimages.py').read_text()
text=text.replace('"""Current genuine public builds versus whole original implicit-state objects."""','"""Preserve whole numerical objects and qualify the two extended static native guards."""')
text=text.replace('from explicit_bottom9_runtime import m','from explicit_bottom9_runtime import m\nfrom closed_implicit_state_parent_native_controls import compare as compare_current,native_controls')
before="    sources={f.name:f.read_bytes() for f in before.glob('*.f90')};current={f.name:f.read_bytes() for f in build.glob('*.f90')};assert sources.keys()==current.keys() and all(raw==current[n] for n,raw in sources.items()),name\n    objects={f.name:f.read_bytes() for f in before.glob('*.o')};after={f.name:f.read_bytes() for f in build.glob('*.o')};assert objects and objects.keys()==after.keys() and all(raw==after[n] for n,raw in objects.items()),name\n"
after="    proof=compare_current(before,build,project)\n    controls=native_controls(archive,original,old,build,project,a.output/name/'native-controls')\n    sources={p.name:p.read_bytes() for p in build.glob('*.f90')};objects={p.name:p.read_bytes() for p in build.glob('*.o')}\n"
assert text.count(before)==1;text=text.replace(before,after,1)
text=text.replace('all_complete_generated_sources_identical=True,all_complete_objects_identical=True','current_native_guard_proof=proof,current_compiled_original_native_controls=controls,all_numerical_sources_and_objects_identical=True')
text=text.replace('TWELVE_ACTUAL_CURRENT_PUBLIC_IMPLICIT_MODEL_STATE_BUILDS_COMPLETE_GENERATED_WHOLE_OBJECTS_AND_SDK_POSTIMAGES_PASS_NO_MODEL_REPLAY','TWELVE_ACTUAL_CURRENT_ORIGINAL_NUMERICAL_OBJECTS_AND_STATIC_NATIVE_GUARD_CONSUMERS_PASS_NO_MODEL_REPLAY')
text=text.replace('ACTUAL_WHOLE_OBJECT_POSTIMAGES_PASS','ACTUAL_NUMERICAL_OBJECTS_AND_STATIC_NATIVE_CONTROLS_PASS')
ast.parse(text);target=E/'closed-implicit-state13-postimages.draft.py';assert not target.exists();target.write_text(text,encoding='utf8')
for platform in ['windows','ubuntu']:
    source=R/('.github/workflows/nomacro-closed-gardner-state12-'+platform+'.yml');text=source.read_text()
    text=text.replace('closed boundary and explicit Gardner state','closed implicit analytical state and original residual Newton').replace('closed-gardner-state12','closed-implicit-state13').replace('closed_gardner_portable','closed_implicit_portable').replace('closed_gardner_state_','closed_implicit_state_')
    target=E/('nomacro-closed-implicit-state13-'+platform+'.draft.yml');assert not target.exists();target.write_text(text,encoding='utf8')
print('Prepared strict native impact controllers and two real portable producer workflows',flush=True)
