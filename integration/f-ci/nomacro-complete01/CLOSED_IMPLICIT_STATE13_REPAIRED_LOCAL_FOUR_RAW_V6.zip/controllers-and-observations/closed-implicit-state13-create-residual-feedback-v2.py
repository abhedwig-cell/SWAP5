from pathlib import Path
E=Path(__file__).parent;text=(E/'closed-implicit-state13-run-residual-feedback-v1.py').read_text()
for before,after in [('84452a487cf7b4726953be695867e53397daf396','3ee4db1ceeb9d923d44fd833f82d196e116a23c0'),('closure13-residual-feedback-v1','closure13-residual-feedback-v2'),("+'-v1'","+'-v2'"),('original-closed-implicit-saturated-residual-initial-iterate-v1','original-closed-implicit-residual-start-and-convergence-order-v2')]:
    assert before in text,before;text=text.replace(before,after)
path=E/'closed-implicit-state13-run-residual-feedback-v2.py';assert not path.exists();path.write_text(text,encoding='utf8')
