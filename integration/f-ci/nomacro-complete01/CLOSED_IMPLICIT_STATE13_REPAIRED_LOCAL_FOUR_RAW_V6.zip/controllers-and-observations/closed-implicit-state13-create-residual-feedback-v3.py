from pathlib import Path
E=Path(__file__).parent;text=(E/'closed-implicit-state13-run-residual-feedback-v2.py').read_text()
for before,after in [('3ee4db1ceeb9d923d44fd833f82d196e116a23c0','ae8ddfbb9e029190baa0d4f42f9002cc3bce8b30'),('closure13-residual-feedback-v2','closure13-residual-feedback-v3'),("+'-v2'","+'-v3'"),('original-closed-implicit-residual-start-and-convergence-order-v2','original-closed-implicit-residual-start-and-conditional-convergence-v3')]:
    assert before in text,before;text=text.replace(before,after)
path=E/'closed-implicit-state13-run-residual-feedback-v3.py';assert not path.exists();path.write_text(text,encoding='utf8')
