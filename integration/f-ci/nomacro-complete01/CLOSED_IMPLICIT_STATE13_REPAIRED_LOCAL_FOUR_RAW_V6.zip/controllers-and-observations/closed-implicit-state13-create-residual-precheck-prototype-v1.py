from pathlib import Path
E=Path(__file__).parent;text=(E/'closed-implicit-state13-signed-residual-snow-prototype-v2.py').read_text()
precheck='''      if(swmacro==0.and.swbotb==6.and.swkimpl==1)then
         if(maxval(abs(F(1:NN)))<=CritDevBalCp.and.abs(sum(F(1:NN)))<=CritDevBalTot)then
            sump=0.5d0*dot_product(F(1:NN),F(1:NN))
            sum1=sum(F(1:NN))
            Fmax=maxval(abs(F(1:NN)))
            goto 1
         end if
      end if
'''
old="source=parent.replace(owner.ANCHOR,trigger+owner.ANCHOR,1).replace(owner.ROUTINE_ANCHOR,routine+'\\n'+owner.ROUTINE_ANCHOR,1)"
assert text.count(old)==1
text=text.replace(old,'precheck='+repr(precheck)+'\n'+old.replace('trigger+owner.ANCHOR','trigger+precheck+owner.ANCHOR'),1)
text=text.replace("source.replace(trigger,'',1).replace(routine+'\\n','',1)","source.replace(trigger,'',1).replace(precheck,'',1).replace(routine+'\\n','',1)")
text=text.replace('prototype_trigger=trigger,prototype_routine=routine','prototype_trigger=trigger,prototype_routine=routine,original_complete_convergence_precheck=precheck')
for before,after in [('closure13-signed-residual-snow-prototype-O0-v2','closure13-residual-precheck-prototype-O0-v1'),('closure13-signed-residual-snow-prototype-v2','closure13-residual-precheck-prototype-v1'),('CLOSED_IMPLICIT_STATE13_SIGNED_RESIDUAL_SNOW_PROTOTYPE_V2','CLOSED_IMPLICIT_STATE13_RESIDUAL_PRECHECK_PROTOTYPE_V1')]:
    assert before in text,before;text=text.replace(before,after)
path=E/'closed-implicit-state13-residual-precheck-prototype-v1.py';assert not path.exists();path.write_text(text,encoding='utf8')
