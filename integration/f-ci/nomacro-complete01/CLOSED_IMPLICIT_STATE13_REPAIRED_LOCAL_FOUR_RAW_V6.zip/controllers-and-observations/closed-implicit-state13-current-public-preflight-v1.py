"""Read every new original-input seam on the real committed current source; zero models."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='2215b9d93d3616160d5ac813bd0c7b879536171a';git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
plan=json.loads(git('show',C+':integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json'));root=E/'closure13-input-preflight-v1';root.mkdir()
q=dict(status='RUNNING_ACTUAL_ALL14_CLOSED_IMPLICIT_PUBLIC_INPUT_PREFLIGHT_ZERO_MODELS',actual_source=C,scientific_output_location=str(root),scientific_output_is_not_registered_disposable=True,cases=[],compiler_executions=0,model_executions=0,canonical_admission=False)
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_CURRENT_ALL_PUBLIC_INPUTS_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
for spec in plan['cases']:
    name=spec['name'];command=[sys.executable,'-B','tests/nomacro_drainage/closed_implicit_state_feedback.py','--case',name,'--optimization','O0','--output',str(root/name),'--build-output',str(W/'closure13-feedback-O0-v1'/'input-only-not-compiled'/name),'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--input-only']
    start=time.perf_counter();run=subprocess.run(command,cwd=R,env=env,capture_output=True,timeout=90);(root/(name+'.stdout')).write_bytes(run.stdout);(root/(name+'.stderr')).write_bytes(run.stderr)
    actual=json.loads((root/name/'RESULT.json').read_text()) if (root/name/'RESULT.json').exists() else {}
    q['cases'].append(dict(case=name,command=command,returncode=run.returncode,seconds=time.perf_counter()-start,status=actual.get('status'),error=actual.get('error'),actual_input_inventory=actual.get('input_inventory'),stdout_sha256=SHA(run.stdout),stderr_sha256=SHA(run.stderr)));save();print(name,run.returncode,actual.get('status'),flush=True)
    assert git('rev-parse','HEAD').decode().strip()==C
q['accepted']=sum(v['returncode']==0 for v in q['cases']);q['status']='ALL14_ACTUAL_CLOSED_IMPLICIT_CURRENT_PUBLIC_INPUTS_ACCEPTED_ZERO_MODELS' if q['accepted']==14 else 'ACTUAL_CLOSED_IMPLICIT_PUBLIC_INPUT_FAILURES_RETAINED';save();assert q['accepted']==14
