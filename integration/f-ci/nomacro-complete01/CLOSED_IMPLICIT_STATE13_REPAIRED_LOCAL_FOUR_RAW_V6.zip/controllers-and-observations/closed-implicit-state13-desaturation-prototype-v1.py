"""Provisional numerical initial iterate; original residual and acceptance stay intact."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,traceback
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from closed_implicit_state_feedback import m,ledger
old=W/'closure13-feedback-O0-v1/current/closed-frost-mixed4-5-cde/bundle';full=E/'closure13-local-feedback-v1/O0/closed-frost-mixed4-5-cde/trajectory'
build=W/'closure13-desaturation-prototype-O0-v1';work=W/'closure13-desaturation-prototype-v1';reference=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
meta=json.loads((old/'BUILD.json').read_text());identity=meta['identity'];SHA=lambda b:hashlib.sha256(b).hexdigest()
q=dict(status='PROVISIONAL_SATURATED_CLOSED_RESIDUAL_INITIAL_ITERATE_DIAGNOSTIC_NOT_QUALIFICATION',actual_original_scientific_source='2215b9d93d3616160d5ac813bd0c7b879536171a',actual_original_BUILD_sha256=SHA((old/'BUILD.json').read_bytes()),new_numerical_policy_prototype=True,physical_equations_changed=False,accepted_state_stock_flux_or_parameter_corrections=False,original_tolerances_and_iteration_limits_unchanged=True,canonical_admission=False)
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_DESATURATION_PROTOTYPE_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');save()
original=(old/'headcalc.f90').read_bytes().replace(b'\r\n',b'\n').decode('cp1252')
anchor='!     special case: SwKimpl = 1';assert original.count(anchor)==1
trigger='''      if(numbit==1.and.swmacro==0.and.swbotb==6.and.swkimpl==1.and.pond==0d0)then
         if(all(dimoca(1:NN)==0d0).and.sum(F(1:NN))>0d0.and.maxval(abs(F(1:NN)))>CritDevBalCp)then
            call closed_desaturation_trial()
            sumold=0.5d0*dot_product(F(1:NN),F(1:NN))
            cycle
         end if
      end if
'''
evaluate='''      h(1:NN)=initial_head(1:NN)-shift
      do node=1,NN
         theta(node)=watcon(node,h(node))
      end do
      do node=2,NN
         hgrad(node)=(h(node-1)-h(node))/disnod(node)+1d0
      end do
      call RootExtraction(2)
      do node=1,NN
         k(node)=hconduc(node,h(node),theta(node),rfcp(node))
         if(node>1)kmean(node)=hcomean(swkmean,k(node-1),k(node),dz(node-1),dz(node),node,h(node-1),h(node))
      end do
      kmean(NN+1)=k(NN)
      call vector_F(2,hgrad)
      value=sum(F(1:NN))
'''
routine='''   subroutine closed_desaturation_trial()
      real(8)::initial_head(macp),lower,upper,middle,left_value,right_value,value,shift
      integer::trial,node
      initial_head(1:NN)=h(1:NN)
      lower=0d0
      left_value=sum(F(1:NN))
      upper=maxval(abs(initial_head(1:NN)))
      if(upper<=0d0)return
      do trial=1,MaxIt1
         shift=upper
'''+evaluate+'''         if(.not.ieee_is_finite(value))exit
         if(value<0d0)goto 100
         upper=2d0*upper
         if(.not.ieee_is_finite(upper))exit
      end do
      shift=0d0
'''+evaluate+'''      return
100   right_value=value
      do trial=1,MaxIt1
         middle=0.5d0*lower+0.5d0*upper
         if(middle==lower.or.middle==upper)exit
         shift=middle
'''+evaluate+'''         if(.not.ieee_is_finite(value))exit
         if(value>0d0)then
            lower=middle
            left_value=value
         else
            upper=middle
            right_value=value
         end if
      end do
      shift=upper
      if(abs(left_value)<abs(right_value))shift=lower
'''+evaluate+'''      write(*,'(a,*(1x,es25.17e3))') 'PROTOTYPE_ORIGINAL_RESIDUAL_TRIAL_START',t1900,dt,shift,value, &
         minval(h(1:NN)),maxval(h(1:NN)),maxval(abs(F(1:NN)))
      flush(6)
   end subroutine closed_desaturation_trial
'''
source=original.replace(anchor,trigger+anchor,1);anchor2='   subroutine alternative_solver()';assert source.count(anchor2)==1
source=source.replace(anchor2,routine+'\n'+anchor2,1)
assert source.replace(trigger,'',1).replace(routine+'\n','',1)==original
path=build/'headcalc.f90';path.write_text(source,encoding='cp1252');q.update(original_headcalc_lf_sha256=SHA(original.encode('cp1252')),prototype_headcalc_lf_sha256=SHA(source.encode('cp1252')),complete_literal_original_inverse=True,trial_trigger=trigger,trial_routine=routine)
os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH'];os.environ['OMP_NUM_THREADS']='1'
objects=reference/'build/swap-obj';ttutil=reference/'build/ttutil-obj'
command=['gfortran',*identity['donor_flags'],'-I',str(old),'-I',str(objects),'-I',str(ttutil),'-c',str(path)]
run=subprocess.run(command,cwd=build,capture_output=True);(work/'compile.stdout').write_bytes(run.stdout);(work/'compile.stderr').write_bytes(run.stderr);q['compile_command']=command;run.check_returncode()
generated={Path(name).stem for name in identity['donor_generated']};donor_objects=sorted(objects.glob('*.o'));names={p.stem for p in donor_objects}
link=[str((build if p.stem=='headcalc' else old)/(p.stem+'.o')) if p.stem in generated else str(p) for p in donor_objects]
link += [str(old/(name+'.o')) for name in sorted(generated-names)];link.append(str(old/'hybrid_step_budget.o'))
donor=build/'day_donor.exe';command=['gfortran','-o',str(donor),*link,str(ttutil/'libttutil.a')];q['link_command']=command
run=subprocess.run(command,cwd=build,capture_output=True);(work/'link.stdout').write_bytes(run.stdout);(work/'link.stderr').write_bytes(run.stderr);run.check_returncode()
for p in old.glob('*restart*'):
    if p.is_file():shutil.copyfile(p,build/p.name)
q['prototype_executable_sha256']=SHA(donor.read_bytes());q['linked_objects']={p:SHA(Path(p).read_bytes()) for p in link};save()
inputs=E/'closure13-local-feedback-v1/O0/closed-frost-mixed4-5-cde/inputs';project=m.e.load(str(inputs),original_output=True,time_step_policy='original-adaptive-event-closure-v1')
checkpoint=full/'accepted-column-1-day-30.zip';q['original_checkpoint_sha256']=SHA(checkpoint.read_bytes());origin=work/'origin';receipt=m.h.verify_checkpoint(checkpoint,30,meta['binding'],origin)
out=E/'closure13-desaturation-prototype-v1';out.mkdir();started=time.perf_counter()
try:
    q['result'],q['model_seconds']=m.bounded(90,lambda:m.h.run(donor,m.h.executable(old,'day_kernel'),inputs,out,35,checkpoint_day=30,origin=origin,origin_receipt=receipt,runtime=True,publish_day=35,checkpoint_binding=meta['binding'],model=project.model,project=project))
except Exception as error:q.update(error=repr(error),traceback=traceback.format_exc())
finally:
    q['seconds']=time.perf_counter()-started;q['accepted_resumed_days']=len((out/'daily.jsonl').read_text().splitlines()) if (out/'daily.jsonl').exists() else 0
    assert SHA(checkpoint.read_bytes())==q['original_checkpoint_sha256'];save()
print(q['status'],q['accepted_resumed_days'],q.get('error'),flush=True)
