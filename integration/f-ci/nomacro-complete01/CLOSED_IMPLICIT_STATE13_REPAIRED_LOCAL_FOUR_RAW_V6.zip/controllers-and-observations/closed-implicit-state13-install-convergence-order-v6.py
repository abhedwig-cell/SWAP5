from pathlib import Path
import ast,json
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');A=R/'app/hybrid_water'
q=json.loads((E/'CLOSED_IMPLICIT_STATE13_RESIDUAL_PRECHECK_PROTOTYPE_V1.json').read_text());assert q['accepted_resumed_days']==5 and not q.get('error')
signed=json.loads((E/'CLOSED_IMPLICIT_STATE13_SIGNED_RESIDUAL_PROTOTYPE_V2.json').read_text());assert signed['accepted_resumed_days']==26 and not signed.get('error')
assert q['prototype_trigger']==signed['prototype_trigger'] and q['prototype_routine']==signed['prototype_routine']
(A/'implicit_closed_desaturation_trial.f90').write_text(q['prototype_routine'],encoding='utf8')
path=A/'implicit_closed_desaturation.py';text=path.read_text();tree=ast.parse(text);node=next(v for v in tree.body if isinstance(v,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TRIGGER' for t in v.targets))
lines=text.splitlines(True);before=''.join(lines[node.lineno-1:node.end_lineno]);assert text.count(before)==1
text=text.replace(before,'TRIGGER='+repr(q['prototype_trigger'])+'\nPRECHECK='+repr(q['original_complete_convergence_precheck'])+'\n',1)
text=text.replace("POLICY='original-closed-implicit-saturated-residual-initial-iterate-v1'","POLICY='original-closed-implicit-residual-start-and-convergence-order-v2'")
text=text.replace('TRIGGER+ANCHOR','TRIGGER+PRECHECK+ANCHOR').replace("text.count(TRIGGER)!=1 or text.count(body)!=1","text.count(TRIGGER)!=1 or text.count(PRECHECK)!=1 or text.count(body)!=1").replace("text.replace(TRIGGER,'',1).replace(body,'',1)","text.replace(TRIGGER,'',1).replace(PRECHECK,'',1).replace(body,'',1)")
text=text.replace('Start degenerate closed implicit Newton trials on the original residual manifold.','Start closed implicit Newton trials and check the original convergence block.')
text=text.replace('actual first Newton iterate; closed bottom6, implicit1, zero trial pond, every moisture capacity zero, positive total residual and original compartment criterion exceeded','actual first Newton iterate; closed bottom6, implicit1, zero trial pond, nonzero original total residual and original compartment criterion exceeded')
text=text.replace('uniform trial-head shift, bracket/bisect sum of original vector_F; original watcon/hconduc, conductivity means and root extraction on every probe','signed uniform trial-head shift, bracket/bisect original vector_F sum for wetting or drying; original watcon/hconduc, conductivity means and root extraction on every probe')
text=text.replace("        original_full_residual_and_budget_acceptance_required=True)","        original_full_residual_and_budget_acceptance_required=True,\n        convergence_order='when the current iterate already meets original compartment and total residual criteria, evaluate the unchanged complete convergence/pond/strict-budget block before computing an ill-conditioned Newton direction; no physical state or tolerance is assigned')")
ast.parse(text);path.write_text(text,encoding='utf8')
print('Installed signed original residual start and original complete convergence precheck; no derivative changes',flush=True)
