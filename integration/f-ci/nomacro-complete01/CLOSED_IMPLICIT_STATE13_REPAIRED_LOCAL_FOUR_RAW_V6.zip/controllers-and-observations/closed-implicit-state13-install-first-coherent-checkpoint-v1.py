"""Preserve actual canonical12 admission and install the finite five-file next composition."""
from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';T=R/'tests/nomacro_drainage';M='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';branch='codex/nomacro-closed-implicit-state13'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
receipt=json.loads((E/'CLOSED_GARDNER_STATE12_MERGE_RECEIPT_V1.json').read_text(encoding='utf8'));assert receipt['actual_merge']==M and receipt['canonical_admission'] and receipt['coadmission']['contexts']==948
manifest=json.loads((E/'CLOSED_GARDNER_STATE12_ADMISSION_RAW_V1.json').read_text(encoding='utf8'));raw=(E/manifest['archive']).read_bytes();assert len(raw)==manifest['bytes'] and SHA(raw)==manifest['sha256']=='d4ec3ee6947288d7a0d21d9d9b393c1178d2e7fca50d9651cc5eb9d78c9e9564'
assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=R).returncode==1
git('switch','-c',branch,M);paths=[]
def copy(source,target):
    assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);paths.append(target.relative_to(R).as_posix())
for n in ['CLOSED_GARDNER_STATE12_ADMISSION_RAW_V1.json','CLOSED_GARDNER_STATE12_ADMISSION_RAW_V1.zip','CLOSED_GARDNER_STATE12_MERGE_RECEIPT_V1.json',
          'CLOSED_IMPLICIT_STATE13_ORIGINAL_ZERO_DAY_AND_PROPOSED_NATIVE_RAW_V1.json','CLOSED_IMPLICIT_STATE13_ORIGINAL_ZERO_DAY_AND_PROPOSED_NATIVE_RAW_V1.zip',
          'CLOSED_IMPLICIT_STATE13_ORIGINAL_MAIN_STARTUP_RAW_V1.json','CLOSED_IMPLICIT_STATE13_ORIGINAL_MAIN_STARTUP_RAW_V1.zip',
          'CLOSED_IMPLICIT_STATE13_ORIGINAL_READER_DISCOVERY_V1.json','CLOSED_IMPLICIT_STATE13_ORIGINAL_MAIN_STARTUP_DIAGNOSTIC_V1.json']:
    copy(E/n,P/n)
controllers=E/'closed-implicit-state13-proposed-controllers-v3'
proposal=json.loads((controllers/'CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V2.json').read_text(encoding='utf8'));assert proposal['actual_canonical_parent']==M and len(proposal['files'])==5
for path,item in proposal['files'].items():
    original=git('show',M+':'+path);actual=(R/path).read_bytes().replace(b'\r\n',b'\n');assert actual==original and SHA(actual)==item['before_lf_sha256']
    value=(E/'closed-implicit-state13-proposed-source-v1'/Path(path).name).read_bytes();assert SHA(value)==item['after_lf_sha256'];(R/path).write_bytes(value);paths.append(path)
for source in controllers.iterdir():
    if source.suffix=='.py':copy(source,T/source.name)
    elif source.suffix=='.json':copy(source,P/source.name)
    elif source.suffix=='.md':
        target=R/'docs/science'/source.name;copy(source,target);text=target.read_text(encoding='utf8').replace('Proposed work unit following genuine canonical','Candidate implementation following genuine canonical').replace('Five proposed production files','Five candidate production files');target.write_text(text,encoding='utf8')
for n in ['STATUS.json','GAP_MATRIX.json']:
    q=json.loads((P/n).read_text(encoding='utf8'));old=q.setdefault('closed_gardner_state12',{});old.update(status='CANONICAL948_ACTUAL_SIGNED_MERGE_PUBLIC_ORDINARY_PUB_ALL_REQUIRED_CI_AND_FOUR_NEGATIVES_ADMITTED',actual_merge=M,canonical_admission=True,new_admitted_contexts=68,merge_receipt='CLOSED_GARDNER_STATE12_MERGE_RECEIPT_V1.json',admission_archive_sha256=manifest['sha256'])
    q['closed_implicit_state13']=dict(status='FIVE_FILE_ACTUAL_ORIGINAL_CLOSED_IMPLICIT_STATE_COMPOSITION_IMPLEMENTED_NOT_QUALIFIED',classification='COMPOSITION_MISSING',actual_canonical_parent=M,source_proposal='CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V2.json',finite_case_plan='CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json',original_zero_day_acceptances=14,pre_change_public_acceptances=0,original_discovery_source='07cb2850e2cd45deb1e197161409a3784a8975e7',source_files=5,independent_cases=14,new_qualified_contexts=0,new_admitted_contexts=0,canonical_admission=False,next_action='Validate all14 actual current public inputs and complete literal source inverses, then focused real local physical/native/cold/transaction feedback, followed by portable qualification on unchanged actual source. Preserve every failure. Whole closure remains incomplete.')
    if n=='STATUS.json':
        q.update(canonical=M,last_commit=M,canonical_head=M,current_canonical_sha=M,branch=branch,active_branch=branch,working_branch=branch,current_workbranch=branch,active_functional_batch='closed_implicit_state13',coadmission=receipt['coadmission'],recovery_point='CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json',next_action=q['closed_implicit_state13']['next_action'],running_ci=[],active_local_jobs=[],functional_completeness='PARTIAL',scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN')
        q['canonical948_actual_admission']=receipt
    (P/n).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');paths.append('integration/f-ci/nomacro-complete01/'+n)
git('add','--sparse','--',*paths);git('commit','-m','Compose original closed implicit analytical state and preserve canonical948 admission')
head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
(E/'CLOSED_IMPLICIT_STATE13_FIRST_ACTUAL_CHECKPOINT_V1.json').write_text(json.dumps(dict(status='FIRST_ACTUAL_CLOSED_IMPLICIT_STATE_IMPLEMENTATION_COMMITTED_NOT_QUALIFIED',actual_source=head,actual_parent=M,branch=branch,paths=paths,canonical12_admission_archive_sha256=manifest['sha256'],new_qualified_contexts=0,new_admitted_contexts=0),indent=2)+'\n',encoding='utf8')
print('ACTUAL_CLOSED_IMPLICIT_STATE13_SOURCE_COMMITTED',head,len(paths),flush=True)
