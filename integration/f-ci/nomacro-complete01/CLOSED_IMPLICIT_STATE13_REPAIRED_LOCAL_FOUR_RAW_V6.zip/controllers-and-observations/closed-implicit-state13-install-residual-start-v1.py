from pathlib import Path
import ast,hashlib,json
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');A=R/'app/hybrid_water'
q=json.loads((E/'CLOSED_IMPLICIT_STATE13_DESATURATION_PROTOTYPE_V1.json').read_text());assert q['accepted_resumed_days']==5 and not q.get('error')
trigger=q['trial_trigger'];routine=q['trial_routine']
diagnostic="      write(*,'(a,*(1x,es25.17e3))') 'PROTOTYPE_ORIGINAL_RESIDUAL_TRIAL_START',t1900,dt,shift,value, &\n         minval(h(1:NN)),maxval(h(1:NN)),maxval(abs(F(1:NN)))\n      flush(6)\n"
assert routine.count(diagnostic)==1;routine=routine.replace(diagnostic,'',1)
path=A/'implicit_closed_desaturation_trial.f90';assert not path.exists();path.write_text(routine,encoding='utf8')
module='''"""Start degenerate closed implicit Newton trials on the original residual manifold.

Only the initial trial iterate changes. Original watcon/hconduc, root extraction,
surface equations, rejected-step rollback and every convergence/mass criterion
continue to own acceptance. No accepted state, parameter, flux or clock is fixed.
"""
from pathlib import Path
import hashlib

POLICY='original-closed-implicit-saturated-residual-initial-iterate-v1'
TRIGGER=TRIGGER_LITERAL
ANCHOR='!     special case: SwKimpl = 1'
ROUTINE_ANCHOR='   subroutine alternative_solver()'


def routine():
    return Path(__file__).with_name('implicit_closed_desaturation_trial.f90').read_text(encoding='utf8')


def selected(item):
    return item is not None and item['bottom']==6 and item.get('drainage',1)==0


def source(text):
    if text.count(ANCHOR)!=1 or text.count(ROUTINE_ANCHOR)!=1 or 'subroutine closed_desaturation_trial' in text:
        raise ValueError('Foreign complete original closed implicit initial-iterate seam')
    result=text.replace(ANCHOR,TRIGGER+ANCHOR,1).replace(ROUTINE_ANCHOR,routine()+'\\n'+ROUTINE_ANCHOR,1)
    if restore(result)!=text:raise ValueError('Incomplete original closed implicit initial-iterate inverse')
    return result


def restore(text):
    if 'closed_desaturation_trial' not in text:return text
    body=routine()+'\\n'
    if text.count(TRIGGER)!=1 or text.count(body)!=1:
        raise ValueError('Foreign original-residual initial-iterate body')
    return text.replace(TRIGGER,'',1).replace(body,'',1)


def metadata(item):
    if not selected(item):return None
    sha=lambda p:hashlib.sha256(p.read_bytes().replace(b'\\r\\n',b'\\n')).hexdigest()
    return dict(policy=POLICY,new_numerical_policy=True,
        providers={p.name:sha(p) for p in [Path(__file__),Path(__file__).with_name('implicit_closed_desaturation_trial.f90')]},
        trigger='actual first Newton iterate; closed bottom6, implicit1, zero trial pond, every moisture capacity zero, positive total residual and original compartment criterion exceeded',
        search='uniform trial-head shift, bracket/bisect sum of original vector_F; original watcon/hconduc, conductivity means and root extraction on every probe',
        search_iteration_bound='existing MaxIt1; no changed original Newton/backtracking limits',
        accepted_state_added=False,physical_equations_changed=False,tolerances_changed=False,
        original_full_residual_and_budget_acceptance_required=True)


def validate(bundle,item):
    path=Path(bundle)/'headcalc.f90';text=path.read_text(encoding='cp1252')
    if selected(item):
        parent=restore(text)
        if parent==text or source(parent)!=text:raise ValueError('Missing complete closed implicit initial-iterate provider')
    elif 'closed_desaturation_trial' in text:
        raise ValueError('Closed implicit initial iterate outside its actual selected domain')
'''.replace('TRIGGER_LITERAL',repr(trigger))
ast.parse(module);path=A/'implicit_closed_desaturation.py';assert not path.exists();path.write_text(module,encoding='utf8')
def change(name,before,after):
    path=A/name;text=path.read_text(encoding='utf8');assert text.count(before)==1,(name,before);path.write_text(text.replace(before,after,1),encoding='utf8')
change('implicit_hydraulic_state.py',"                parent_state_layout_preserved=True,physical_equations_changed=False,new_physical_state=False)","                parent_state_layout_preserved=True,physical_equations_changed=False,new_physical_state=False,\n                **({'closed_desaturation_trial_start':__import__('implicit_closed_desaturation').metadata(item)}\n                   if __import__('implicit_closed_desaturation').selected(item) else {}))")
change('implicit_hydraulic_state.py',"    name=native_provider(item)\n    if name in patched:","    from implicit_closed_desaturation import selected as desaturation_selected,source as desaturation_source\n    if desaturation_selected(item):\n        head=output/'headcalc.f90';head.write_text(desaturation_source(head.read_text(encoding='cp1252')),encoding='cp1252')\n    name=native_provider(item)\n    if name in patched:")
change('implicit_hydraulic_state.py',"    name=native_provider(selected(project));path=Path(bundle)/(name+'.f90')", "    from implicit_closed_desaturation import validate as validate_desaturation\n    validate_desaturation(bundle,selected(project))\n    name=native_provider(selected(project));path=Path(bundle)/(name+'.f90')")
change('ordinary_pond_source_guard.py',"    source = (Path(bundle)/'headcalc.f90').read_bytes().replace(b'\\r\\n', b'\\n')", "    source = (Path(bundle)/'headcalc.f90').read_bytes().replace(b'\\r\\n', b'\\n')\n    from implicit_closed_desaturation import restore as restore_desaturation\n    source=restore_desaturation(source.decode('cp1252')).encode('cp1252')")
change('snow_undrained_source_guard.py',"    source=actual('headcalc.f90')", "    from implicit_closed_desaturation import restore as restore_desaturation\n    source=restore_desaturation(actual('headcalc.f90'))")
change('implicit_frost_source_guard.py',"def canonical_water_headcalc(source,boundary=None):\n    from lower_boundary_receipt", "def canonical_water_headcalc(source,boundary=None):\n    from implicit_closed_desaturation import restore as restore_desaturation\n    source=restore_desaturation(source)\n    from lower_boundary_receipt")
print('Installed provisional actual residual initial-iterate owner; no qualification claimed',flush=True)
