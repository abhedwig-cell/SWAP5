"""Locate original main startup failure using phase-only IO and an explicit zero-day stop."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,io,json,os,re,subprocess,sys,time,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
D=W/'closure13-original-main-startup-v1';B=W/'closure13-original-main-startup-O0-v1';M='2e98506b4fb469bbf5995a8ab0b49c88ead0972c';SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from closed_gardner_state_feedback import input_donor
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
record=dict(status='RUNNING_ORIGINAL_MAIN_STARTUP_DIAGNOSTIC_NOT_SCIENTIFIC_QUALIFICATION',actual_controller_source=M,original_driver_source_role='ORIGINAL_MAIN_PLUS_EXPLICIT_STDOUT_PHASES_AND_STOP_AFTER_ORIGINAL_TASK1',model_days=0,original_SDK_mixed_compiler_profiles=True,new_main_driver_O0=True,all_O0_SDK_claimed=False,physical_parameters_dates_equations_and_numerical_limits_changed=False,canonical_admission=False)
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_ORIGINAL_MAIN_STARTUP_DIAGNOSTIC_V1.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
save()
try:
    prepared=json.loads((J/'PREPARED.json').read_text());checked={}
    for name,digest in prepared['provider_files'].items():
        raw=(J/name).read_bytes();assert SHA(raw)==digest;checked[name]=digest
    record['exact_original_provider_files']=checked
    archive=(R/'reference/swap-4.3.1/source-archives/SWAP.ZIP').read_bytes();assert SHA(archive)=='1a2d798994c2990b397f9349317e3a26f40662fbcff55c9ea484dd638af45151'
    with zipfile.ZipFile(io.BytesIO(archive)) as z:original_raw=z.read('SWAP/swap_main.f90')
    original=re.sub(rb'\r+\n',b'\n',original_raw).decode('cp1252');assert original==(J/'build/swap-selected/swap_main.f90').read_text(encoding='cp1252')
    assert SHA(original.encode('cp1252'))=='54439f52f2a3c612ff1f9c8cca790ae373d0d1b65e18d14d37e9282596417b38'
    (B/'original_swap_main_normalized.f90').write_bytes(original.encode('cp1252'))
    markers=[]
    def phase(label):
        lines=["   write(*,'(a)') 'ORIGINAL_MAIN_PHASE "+label+"'\n",'   flush(6) ! ORIGINAL_MAIN_DIAGNOSTIC_FLUSH\n'];markers.extend(lines);return ''.join(lines)
    text=original
    for anchor,label in [('sw_animo = 1\n','BEFORE_SW_ANIMO_ASSIGNMENT'),('iun1 = getun (400,900)\n','BEFORE_GETUN'),("call fopens (iun1,'reruns.log','new','del')\n",'BEFORE_FOPENS'),("call rdsets (iun2,iun1,'reruns.dat',insets)\n",'BEFORE_RDSETS'),('   call rdfrom (iset,.TRUE.)\n','BEFORE_RDFROM')]:
        assert text.count(anchor)==1;text=text.replace(anchor,phase(label)+anchor,1)
    anchor='   if (iCaller == 0) call swap(iCaller, iTask, tstart_in, tend_in)\n';assert text.count(anchor)==3
    stop="   stop 'ORIGINAL_MAIN_ZERO_DAY_DIAGNOSTIC_COMPLETE'\n";text=text.replace(anchor,phase('BEFORE_SWAP_TASK1')+anchor+phase('AFTER_SWAP_TASK1')+stop,1)
    inverse=text
    for line in markers:
        assert line in inverse;inverse=inverse.replace(line,'',1)
    assert inverse.replace(stop,'',1)==original
    source=B/'original_main_startup_diagnostic.f90';source.write_bytes(text.encode('cp1252'));obj=B/'original_main_startup_diagnostic.o';exe=B/'original_main_startup_diagnostic.exe'
    compiler=Path('C:/msys64/ucrt64/bin/gfortran.exe');assert SHA(compiler.read_bytes())=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
    commands=[['C:/msys64/ucrt64/bin/gfortran.exe','-O0','-std=legacy','-ffree-line-length-none','-fbacktrace','-I'+str(J/'build/swap-obj'),'-I'+str(J/'build/ttutil-obj'),'-J'+str(B),'-c',str(source),'-o',str(obj)]]
    objects=[p for p in sorted((J/'build/swap-obj').glob('*.o')) if p.name.lower()!='swap_main.o'];assert objects
    commands.append(['C:/msys64/ucrt64/bin/gfortran.exe','-Wl,--stack,67108864','-o',str(exe),str(obj),*map(str,objects),str(J/'build/ttutil-obj/libttutil.a')])
    for index,command in enumerate(commands):
        start=time.perf_counter();child=subprocess.run(command,cwd=B,capture_output=True,timeout=30);(B/('command-'+str(index)+'.stdout')).write_bytes(child.stdout);(B/('command-'+str(index)+'.stderr')).write_bytes(child.stderr);record.setdefault('build_commands',[]).append(dict(command=command,returncode=child.returncode,seconds=time.perf_counter()-start));save();child.check_returncode()
    record.update(original_main_raw_sha256=SHA(original_raw),original_main_normalized_sha256=SHA(original.encode('cp1252')),actual_diagnostic_source_sha256=SHA(source.read_bytes()),actual_diagnostic_executable_sha256=SHA(exe.read_bytes()),complete_literal_original_source_inverse=True)
    with ExitStack() as stack:
        name,donor=input_donor(dict(bottom=9,kind='water'),stack);prefix='model3-water-initial2/';inventory={}
        for member in donor.names:
            if member.startswith(prefix):
                filename=member[len(prefix):];raw=donor.get(member);path=D/filename;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);inventory[filename]=dict(bytes=len(raw),sha256=SHA(raw))
        record.update(input_authority=dict(archive=name,archive_sha256=donor.record['sha256'],prefix=prefix),input_inventory=inventory)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
    start=time.perf_counter();child=subprocess.run([str(exe),'./swap.swp'],cwd=D,env=env,capture_output=True,timeout=20);(D/'original-startup.stdout').write_bytes(child.stdout);(D/'original-startup.stderr').write_bytes(child.stderr)
    phases=[line.decode() for line in child.stdout.splitlines() if line.startswith(b'ORIGINAL_MAIN_PHASE ')];record.update(returncode=child.returncode,seconds=time.perf_counter()-start,phases=phases,original_task1_completed=b'ORIGINAL_MAIN_PHASE AFTER_SWAP_TASK1' in child.stdout,stdout_sha256=SHA(child.stdout),stderr_sha256=SHA(child.stderr),status='ORIGINAL_MAIN_STARTUP_PHASES_OBSERVED_ZERO_MODEL_DAYS_NOT_LEGACY_DEFECT_PROOF')
    assert git('rev-parse','HEAD').decode().strip()==M
    for name,item in inventory.items():assert SHA((D/name).read_bytes())==item['sha256']
    print(record['status'],record['returncode'],record['phases'],flush=True)
except Exception as error:record.update(status='FAILED_ORIGINAL_MAIN_STARTUP_DIAGNOSTIC_PREFLIGHT',error=repr(error));raise
finally:save()
