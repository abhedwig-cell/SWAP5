from pathlib import Path
import hashlib,json,os,re,subprocess
E=Path(__file__).parent;W=E.parent;root=W/'closure13-original-output-isolation-v1';old=W/'closure13-original-swap-startup-v2';B=W/'closure13-original-swap-startup-O0-v2';SHA=lambda b:hashlib.sha256(b).hexdigest()
prior=json.loads((E/'CLOSED_IMPLICIT_STATE13_ORIGINAL_SWAP_STARTUP_V2.json').read_text());q=dict(status='RUNNING_ORIGINAL_ZERO_DAY_OUTPUT_ISOLATION_NOT_PHYSICAL_EQUIVALENCE',model_days=0,original_input_authority=prior['input_authority'],original_executable_sha256=prior['executable_sha256'],changed_output_selector={'SWCSV':0},physical_parameters_dates_or_equations_changed=False,canonical_admission=False)
originals=prior['input_inventory'];before={};after={}
for name,item in originals.items():
    raw=(old/name).read_bytes();assert SHA(raw)==item['sha256'];before[name]=SHA(raw)
    if name=='swap.swp':
        text=raw.decode('cp1252');text,n=re.subn(r'(?m)^([ \t]*SWCSV[ \t]*=[ \t]*)[0-3]\b',lambda m:m[1]+'0',text);assert n==1;raw=text.encode('cp1252')
    target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);after[name]=SHA(raw)
assert [n for n in before if before[n]!=after[n]]==['swap.swp'];q.update(before=before,after=after)
env=dict(os.environ,OMP_NUM_THREADS='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH'];exe=B/'original_swap_startup.exe';assert SHA(exe.read_bytes())==q['original_executable_sha256']
run=subprocess.run([str(exe),'./swap.swp'],cwd=root,env=env,capture_output=True,timeout=20);(root/'output-isolation.stdout').write_bytes(run.stdout);(root/'output-isolation.stderr').write_bytes(run.stderr)
q.update(returncode=run.returncode,original_task1_completed=b'ORIGINAL_MAIN_PHASE AFTER_SWAP_TASK1' in run.stdout,status='ORIGINAL_ZERO_DAY_OUTPUT_SELECTOR_ISOLATION_OBSERVED_NOT_PHYSICAL_EQUIVALENCE',phases=[v.decode() for v in run.stdout.splitlines() if v.startswith((b'ORIGINAL_MAIN_PHASE ',b'ORIGINAL_SWAP_PHASE '))])
(E/'CLOSED_IMPLICIT_STATE13_ORIGINAL_OUTPUT_ISOLATION_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],q['returncode'],q['original_task1_completed'],flush=True)
