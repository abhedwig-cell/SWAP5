"""Trace original full SWAP initialization with exact removable stdout phases only."""
from pathlib import Path
import gzip,hashlib,io,json,os,re,shutil,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
B=W/'closure13-original-swap-startup-O0-v2';D=W/'closure13-original-swap-startup-v2';oldD=W/'closure13-original-main-startup-v1';oldB=W/'closure13-original-main-startup-O0-v1';SHA=lambda b:hashlib.sha256(b).hexdigest()
q=dict(status='RUNNING_ORIGINAL_FULL_SWAP_TASK1_PHASE_ONLY_CONTROL_ZERO_MODEL_DAYS',actual_controller_source='66dae38844cf8d16508e76b6caee4460c11e5fdc',original_archive_sha256='1a2d798994c2990b397f9349317e3a26f40662fbcff55c9ea484dd638af45151',model_days=0,original_SDK_mixed_profiles=True,all_O0_SDK_claimed=False,physical_equations_or_parameters_changed=False,source_or_producer_roles_rebound=False,canonical_admission=False)
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_ORIGINAL_SWAP_STARTUP_V2.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save();archive=(R/'reference/swap-4.3.1/source-archives/SWAP.ZIP').read_bytes();assert SHA(archive)==q['original_archive_sha256']
with zipfile.ZipFile(io.BytesIO(archive)) as z:raw=z.read('SWAP/swap.f90')
sys.path.insert(0,str(R/'tools/vq'))
from b0_source_runner import select_dec_branches,SYMBOLS
original_raw_lf=re.sub(rb'\r+\n',b'\n',raw).decode('cp1252')
original=select_dec_branches(original_raw_lf)
assert original==(J/'build/swap-selected/swap.f90').read_text(encoding='cp1252')
q['original_compiler_conditional_selection']=SYMBOLS
q['original_unselected_lf_sha256']=SHA(original_raw_lf.encode('cp1252'))
markers=[]
def marker(label):
    text="write(*,'(a)') 'ORIGINAL_SWAP_PHASE "+label+"'\nflush(6) ! ORIGINAL_SWAP_PHASE_FLUSH\n";markers.append(text);return text
source=original
for anchor,label in [('call swap_invoke()\n','SWAP_INVOKE'),('   if (iCaller /= 1) call Initialize\n','INITIALIZE'),('   call IterTime(1)\n','ITERTIME'),('      call swap_configuration()\n','CONFIGURATION'),('   call ReadSwap\n','READSWAP'),('   call Meteo(1)\n','METEO'),('   call TimeControl(1)\n','TIMECONTROL'),('      call fill_cofgen\n','FILL_COFGEN'),('   call SoilWater(1)\n','SOILWATER'),('   if (swhea > 0) call SoilTemperature(1)\n','SOILTEMP'),('   if (swsnow  == 1) call Snow(1, tsoil(1), tav, epond, peva, empreva)\n','SNOW'),('   call SwapOutput(1)\n','OUTPUT')]:
    assert source.count(anchor)>=1,(label,source.count(anchor));source=source.replace(anchor,marker('BEFORE_'+label)+anchor+marker('AFTER_'+label),1)
inverse=source
for text in markers:assert inverse.count(text)==1;inverse=inverse.replace(text,'',1)
assert inverse==original
path=B/'swap.f90';path.write_text(source,encoding='cp1252');q.update(original_swap_raw_sha256=SHA(raw),original_swap_lf_sha256=SHA(original.encode('cp1252')),observer_swap_lf_sha256=SHA(source.encode('cp1252')),complete_original_source_inverse=True,stdout_only_additions=markers)
main=oldB/'original_main_startup_diagnostic.f90';assert main.exists();shutil.copyfile(main,B/'original_main_startup_diagnostic.f90')
flags=['-O0','-std=legacy','-ffree-line-length-none','-fbacktrace','-I'+str(J/'build/swap-obj'),'-I'+str(J/'build/ttutil-obj'),'-J'+str(B)]
commands=[['C:/msys64/ucrt64/bin/gfortran.exe',*flags,'-c',str(path),'-o',str(B/'swap.o')],['C:/msys64/ucrt64/bin/gfortran.exe',*flags,'-c',str(B/'original_main_startup_diagnostic.f90'),'-o',str(B/'main.o')]]
objects=[p for p in sorted((J/'build/swap-obj').glob('*.o')) if p.name.lower() not in ('swap_main.o','swap.o')]
exe=B/'original_swap_startup.exe';commands.append(['C:/msys64/ucrt64/bin/gfortran.exe','-Wl,--stack,67108864','-o',str(exe),str(B/'main.o'),str(B/'swap.o'),*map(str,objects),str(J/'build/ttutil-obj/libttutil.a')])
q['commands']=commands;save()
for index,command in enumerate(commands):
    run=subprocess.run(command,cwd=B,capture_output=True,timeout=30);(B/(str(index)+'.stdout')).write_bytes(run.stdout);(B/(str(index)+'.stderr')).write_bytes(run.stderr);run.check_returncode()
prior=json.loads((E/'CLOSED_IMPLICIT_STATE13_ORIGINAL_MAIN_STARTUP_DIAGNOSTIC_V1.json').read_text());q['input_authority']=prior['input_authority'];q['input_inventory']=prior['input_inventory']
for name,item in q['input_inventory'].items():
    source=oldD/name;assert SHA(source.read_bytes())==item['sha256'];target=D/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
q['new_SWAP_object_sha256']=SHA((B/'swap.o').read_bytes());q['original_SDK_SWAP_object_sha256']=SHA((J/'build/swap-obj/swap.o').read_bytes());q['executable_sha256']=SHA(exe.read_bytes())
env=dict(os.environ,OMP_NUM_THREADS='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
run=subprocess.run([str(exe),'./swap.swp'],cwd=D,env=env,capture_output=True,timeout=25);(D/'original-task1.stdout').write_bytes(run.stdout);(D/'original-task1.stderr').write_bytes(run.stderr)
q.update(returncode=run.returncode,phases=[v.decode() for v in run.stdout.splitlines() if v.startswith((b'ORIGINAL_SWAP_PHASE ',b'ORIGINAL_MAIN_PHASE '))],original_task1_completed=b'ORIGINAL_MAIN_PHASE AFTER_SWAP_TASK1' in run.stdout,status='ORIGINAL_FULL_SWAP_TASK1_PHASES_OBSERVED_ZERO_MODEL_DAYS_NOT_LEGACY_CAUSALITY_PROOF')
save();print(q['status'],run.returncode,q['phases'],flush=True)
