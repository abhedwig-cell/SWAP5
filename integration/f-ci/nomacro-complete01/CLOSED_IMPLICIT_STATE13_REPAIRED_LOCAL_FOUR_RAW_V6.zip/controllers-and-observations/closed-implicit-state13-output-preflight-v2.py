"""Inspect actual output owners against untouched original input decks; zero models."""
from pathlib import Path
import ast,hashlib,json,subprocess,sys,traceback
E=Path(__file__).parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from closed_implicit_state_feedback import m
import groundwater_water_output as output
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
plan=json.loads((R/'integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json').read_text())
files=git('diff','--name-only','2e98506b4fb469bbf5995a8ab0b49c88ead0972c','--','app').decode().splitlines()
sha=lambda b:hashlib.sha256(b).hexdigest()
q=dict(actual_HEAD=git('rev-parse','HEAD').decode().strip(),working_tree_dirty=bool(git('status','--porcelain')),working_APP_sha256={p:sha((R/p).read_bytes().replace(b'\r\n',b'\n')) for p in files},compiler_executions=0,model_executions=0,cases=[])
for path in files:
    if path.endswith('.py'):ast.parse((R/path).read_bytes())
for spec in plan['cases']:
    folder=E/'closure13-input-preflight-v1'/spec['name']/'inputs'
    record=dict(case=spec['name'])
    try:
        p=m.e.load(str(folder),original_output=True,time_step_policy='original-adaptive-event-closure-v1' if spec['frost'] else 'original-adaptive-day-seed-v1')
        import importlib
        owner=output
        for candidate in ['original_output_aquifer','original_output_hysteresis','original_output','age_output_clock','age_output_schedule','age_output_calendar']:
            if owner.selection(p) is not None:break
            owner=importlib.import_module(candidate)
        record['owner']=owner.__name__
        record['selection']=owner.selection(p)
        record['metadata']=owner.metadata(p)
        assert record['selection'] is not None and record['metadata'] is not None
        record['status']='ACTUAL_OUTPUT_OWNER_METADATA_ACCEPTED_ZERO_MODELS'
    except Exception as error:
        record.update(status='FAILED_ACTUAL_OUTPUT_OWNER_METADATA',error=repr(error),traceback=traceback.format_exc())
    q['cases'].append(record)
    print(spec['name'],record['status'],record.get('error',''),flush=True)
q['accepted']=sum(v['status']=='ACTUAL_OUTPUT_OWNER_METADATA_ACCEPTED_ZERO_MODELS' for v in q['cases'])
target=E/'CLOSED_IMPLICIT_STATE13_OUTPUT_PREFLIGHT_V3.json'
with target.open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print('accepted',q['accepted'],flush=True)
