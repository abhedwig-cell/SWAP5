from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,traceback
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from closed_implicit_state_feedback import m
name='closed-ordinary-model5-cde-profile';old=W/'closure13-residual-feedback-O2-v1/current'/name/'bundle';full=E/'closure13-residual-feedback-v1/O2'/name/'trajectory';build=W/'closure13-partial-plateau-observer-O2-v1';work=W/'closure13-partial-plateau-observer-v1';reference=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');SHA=lambda b:hashlib.sha256(b).hexdigest()
meta=json.loads((old/'BUILD.json').read_text());identity=meta['identity'];q=dict(actual_scientific_source='84452a487cf7b4726953be695867e53397daf396',case=name,actual_original_BUILD_sha256=SHA((old/'BUILD.json').read_bytes()),observer='removable stdout-only plateau conditions and pre-rollback diagnostics',physical_equations_or_parameters_changed=False,canonical_admission=False)
save=lambda:(E/'CLOSED_IMPLICIT_STATE13_PARTIAL_PLATEAU_OBSERVER_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');save()
original=(old/'headcalc.f90').read_bytes().replace(b'\r\n',b'\n').decode('cp1252')
anchor='      if(numbit==1.and.swmacro==0.and.swbotb==6.and.swkimpl==1.and.pond==0d0)then';assert original.count(anchor)==1
addition="""      if(numbit==1.and.dt<=dtmin)then
         write(*,'(a,*(1x,es25.17e3))') 'OBSERVER_INITIAL_PLATEAU',t1900,dt,pondm1,pond, &
            minval(dimoca(1:NN)),maxval(dimoca(1:NN)),sum(F(1:NN)),maxval(abs(F(1:NN))),CritDevBalCp
         flush(6)
      end if
"""
source=original.replace(anchor,addition+anchor,1)
anchor2='!  Convergence could not been reached';assert source.count(anchor2)==1
failure="""   if(dt<=dtmin)then
      write(*,'(a,*(1x,es25.17e3))') 'OBSERVER_FAILED_NEWTON',t1900,dt,pondm1,pond,q0,qtop, &
         minval(h(1:NN)),maxval(h(1:NN)),minval(dimoca(1:NN)),maxval(dimoca(1:NN)), &
         minval(F(1:NN)),maxval(F(1:NN)),sumold,sump
      write(*,*) 'OBSERVER_FAILED_NEWTON_FLAGS',numbit,MaxIt1,ierror,flnonconv,flnonconv3
      flush(6)
   end if
"""
source=source.replace(anchor2,failure+anchor2,1);assert source.replace(addition,'',1).replace(failure,'',1)==original
path=build/'headcalc.f90';path.write_text(source,encoding='cp1252');q.update(original_headcalc_lf_sha256=SHA(original.encode('cp1252')),observer_headcalc_lf_sha256=SHA(source.encode('cp1252')),additions=[addition,failure]);os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH']
objects=reference/'build/swap-obj';ttutil=reference/'build/ttutil-obj';commands=[['gfortran',*identity['donor_flags'],'-I',str(old),'-I',str(objects),'-I',str(ttutil),'-c',str(path)]]
generated={Path(n).stem for n in identity['donor_generated']};donor_objects=sorted(objects.glob('*.o'));names={p.stem for p in donor_objects};link=[str((build if p.stem=='headcalc' else old)/(p.stem+'.o')) if p.stem in generated else str(p) for p in donor_objects];link += [str(old/(n+'.o')) for n in sorted(generated-names)];link.append(str(old/'hybrid_step_budget.o'));donor=build/'day_donor.exe';commands.append(['gfortran','-o',str(donor),*link,str(ttutil/'libttutil.a')])
for index,cmd in enumerate(commands):
    run=subprocess.run(cmd,cwd=build,capture_output=True);(work/(str(index)+'.stdout')).write_bytes(run.stdout);(work/(str(index)+'.stderr')).write_bytes(run.stderr);run.check_returncode()
q.update(commands=commands,observer_executable_sha256=SHA(donor.read_bytes()),linked_objects={p:SHA(Path(p).read_bytes()) for p in link});save()
for p in old.glob('*restart*'):
    if p.is_file():shutil.copyfile(p,build/p.name)
inputs=E/'closure13-residual-feedback-v1/O2'/name/'inputs';project=m.e.load(str(inputs),original_output=True,time_step_policy='original-adaptive-day-seed-v1');checkpoint=full/'accepted-column-1-day-9.zip';q['original_checkpoint_sha256']=SHA(checkpoint.read_bytes());origin=work/'origin';receipt=m.h.verify_checkpoint(checkpoint,9,meta['binding'],origin);out=E/'closure13-partial-plateau-observer-v1';out.mkdir();started=time.perf_counter()
try:q['result'],q['model_seconds']=m.bounded(90,lambda:m.h.run(donor,m.h.executable(old,'day_kernel'),inputs,out,26,checkpoint_day=9,origin=origin,origin_receipt=receipt,runtime=True,publish_day=26,checkpoint_binding=meta['binding'],model=project.model,project=project))
except Exception as error:q.update(error=repr(error),traceback=traceback.format_exc())
finally:
    q.update(seconds=time.perf_counter()-started,accepted_resumed_days=len((out/'daily.jsonl').read_text().splitlines()) if (out/'daily.jsonl').exists() else 0,status='ACTUAL_PARTIAL_PLATEAU_OBSERVATION_RETAINED_NOT_QUALIFICATION');assert SHA(checkpoint.read_bytes())==q['original_checkpoint_sha256'];save()
print(q['status'],q['accepted_resumed_days'],q.get('error'),flush=True)
