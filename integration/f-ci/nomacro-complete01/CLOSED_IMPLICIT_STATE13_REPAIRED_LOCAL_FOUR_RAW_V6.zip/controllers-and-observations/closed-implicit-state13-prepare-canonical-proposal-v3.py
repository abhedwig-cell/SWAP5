"""Pin the next proposal to the genuine M12 parent and name only new executions."""
from pathlib import Path
import ast,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');M='2e98506b4fb469bbf5995a8ab0b49c88ead0972c'
old=E/'closed-implicit-state13-proposed-controllers-v2';out=E/'closed-implicit-state13-proposed-controllers-v3';out.mkdir()
for path in old.iterdir():(out/path.name).write_bytes(path.read_bytes())
plan=json.loads((out/'CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json').read_text(encoding='utf8'))
for spec in plan['cases']:
    original=spec['name'];name='closed-'+original
    if spec['frost']:
        for suffix in ['-d0-b5','-d1-b5','-d0-b8','-d1-b8']:
            if name.endswith(suffix):name=name[:-len(suffix)]
    spec.update(name=name,actual_original_zero_day_record_case=original)
plan.update(actual_canonical_parent=M,actual_original_input_git_source=M,original_input_scientific_producer='c40ca084d8e5eb638e0b4ac5c471463d9aad01c3',independent_qualification_cases=[v['name'] for v in plan['cases']],source_proposal='CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V2.json')
(out/'CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8')
p=out/'closed_implicit_state_feedback.py';s=p.read_text(encoding='utf8');assert s.count("PARENT='105b9a8e6ca9e846f214d69a71afe73ed18be11d'")==1;s=s.replace("PARENT='105b9a8e6ca9e846f214d69a71afe73ed18be11d'","PARENT='"+M+"'");p.write_text(s,encoding='utf8')
p=out/'closed_implicit_state_science.py';s=p.read_text(encoding='utf8');s=s.replace('        layers=[]','        layers=[];grid_nodes=0').replace("depth=float(fields[2])","depth=float(fields[2].replace('D','e').replace('d','e'))").replace('layers.append(soil)','layers.append(soil);grid_nodes+=count').replace('        assert layers and set(layers)','        assert grid_nodes==nodes\n        assert layers and set(layers)');p.write_text(s,encoding='utf8')
proposal=json.loads((E/'CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V1.json').read_text(encoding='utf8'));proposal.update(actual_canonical_parent=M,actual_original_source_proposal='CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V1.json',physical_equations_changed=False,new_physical_state=False,new_numerical_policy=False)
for path,item in proposal['files'].items():
    item['new_file']=False;item['after_lf_sha256']=item['proposed_after_lf_sha256']
    import hashlib
    before=subprocess.check_output(['git','show',M+':'+path],cwd=R);assert hashlib.sha256(before).hexdigest()==item['before_lf_sha256']
(out/'CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V2.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf8')
s=(R/'tests/nomacro_drainage/closed_gardner_state_source_contract.py').read_text(encoding='utf8').replace('closed_gardner_state_feedback','closed_implicit_state_feedback').replace('CLOSED_GARDNER_STATE12_SOURCE_PROPOSAL_V3','CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V2')
(out/'closed_implicit_state_source_contract.py').write_text(s,encoding='utf8')
for path in out.glob('*.py'):ast.parse(path.read_text(encoding='utf8'))
doc='''# Original closed implicit analytical hydraulic state composition

Proposed work unit following genuine canonical `2e98506b4fb469bbf5995a8ab0b49c88ead0972c`.
The existing analytical models2..11, including mixed layers and NoVap8..11,
are composed with original zero-flux bottom6 and drainage0 in ordinary,
Snow and Frost water/CDE states. Original parameters, equations, dates,
stocks, fluxes and numerical limits remain unchanged. Non1+hysteresis,
active vapor, table/RIA12 and implicit paired9 are outside this bounded change.

Fourteen literal prior input decks, changing only SWDRA=0 and SWBOTB=6,
reach the complete original zero-day initialization. The pre-change public
reader refuses all14. The original probe has a mixed SDK and O0 driver;
no all-O0 SDK or original full-period equivalence is claimed.

Five proposed production files bind existing input/state owners and extend
the duplicated per-layer static native witness to closed6/drainage0.
Inactive SWDIVD is never read or normalized. Two exact proposed native
providers compile O0 against the original SDK; this is not production
qualification. Full coupled native/cold/transaction and portable checks
remain pending. Original scientific source identities and failures remain.

The two explicit Gardner/Snow paired9 numerical failures, paired9 active
vapor/thermal semantics and retained AGE dry-pond moments stay separate.
Whole migration PARTIAL, scientific equivalence NOT_QUALIFIED, global
family/gap counts UNKNOWN and fixed RC3 unchanged.
'''
(out/'NOMACRO_CLOSED_IMPLICIT_STATE13.md').write_text(doc,encoding='utf8')
print('PROPOSED_CANONICAL12_BASE_FIVE_FILE_COMPOSITION_AND_FIVE_DISTINCT_CONTROLLERS_READY_NOT_INSTALLED')
