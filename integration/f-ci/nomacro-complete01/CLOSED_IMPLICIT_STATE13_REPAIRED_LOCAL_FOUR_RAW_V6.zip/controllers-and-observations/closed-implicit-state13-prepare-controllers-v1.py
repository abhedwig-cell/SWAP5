"""Prepare distinct controllers for the next actual branch; never execute prototypes here."""
from pathlib import Path
import ast,json
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage';out=E/'closed-implicit-state13-proposed-controllers-v1';out.mkdir()
plan=json.loads((E/'CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_PROPOSED_V1.json').read_text(encoding='utf8'));plan['independent_qualification_cases']=[v['name'] for v in plan['cases']];plan['deferred_numerical_cases']=[]
(out/'CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8')
prepare='''def prepare(spec,output,donor=None):
    """Only the declared closed boundary/drainage selectors change."""
    output.mkdir()
    name='IMPLICIT_HYDRAULIC_STATE11_FIRST_WINDOWS_O0_ORIGINAL_V1'
    prefix=spec['actual_original_input_prefix']
    with ExitStack() as stack:
        archive=Archive(GitArchiveSource(R,PARENT),name,stack)
        original={n[len(prefix):]:archive.get(n) for n in archive.names if n.startswith(prefix)}
        assert original and 'swap.swp' in original
        authority=dict(actual_git_source=PARENT,archive=name,archive_sha256=archive.record['sha256'],prefix=prefix,original_members={n:dict(bytes=len(v),sha256=SHA(v)) for n,v in original.items()})
        for n,raw in original.items():
            target=output/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    text=original['swap.swp'].decode('cp1252');values=dict(SWDRA=0,SWBOTB=6)
    for key,value in values.items():text=assignment(text,key,value)
    (output/'swap.swp').write_bytes(text.encode('cp1252'))
    return dict(authority=authority,additional_original_parameter_authority=None,declared_selectors=values,physical_parameter_tables_unchanged=True,current_swp_sha256=SHA((output/'swap.swp').read_bytes()))


'''
s=(T/'closed_gardner_state_feedback.py').read_text(encoding='utf8');lo=s.index('def input_donor(');hi=s.index('def ledger(');s=s[:lo]+prepare+s[hi:]
s=s.replace('CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V3','CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1').replace('CLOSED_GARDNER','CLOSED_IMPLICIT')
ast.parse(s);(out/'closed_implicit_state_feedback.py').write_text(s,encoding='utf8')
s=(T/'closed_gardner_state_batch.py').read_text(encoding='utf8').replace('closed_gardner_state','closed_implicit_state').replace('CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V3','CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1').replace('CLOSED_GARDNER','CLOSED_IMPLICIT');ast.parse(s);(out/'closed_implicit_state_batch.py').write_text(s,encoding='utf8')
s=(T/'closed_gardner_state_native_controls.py').read_text(encoding='utf8').replace('closed_gardner_state_feedback','closed_implicit_state_feedback').replace('CLOSED_GARDNER','CLOSED_IMPLICIT')
before="""        if 2 in spec['models']:
            from frost_analytical_composition import selected,native_domain
            domains.append(('gardner',native_domain(good,selected(project),nodes)))
""";assert s.count(before)==1;s=s.replace(before,'')
before="""        models=selected.get('analytical_snow_models')
        if models:domains.append(('gardner',[1,nodes,len(models),int(project.solute),*models]))
""";assert s.count(before)==1;s=s.replace(before,'')
before="    attacks=[('foreign-magic'";assert s.count(before)==1
s=s.replace(before,"    from implicit_hydraulic_state import selected as hydraulic_selection,header as hydraulic_header\n    hydraulic=hydraulic_selection(project);assert hydraulic and hydraulic['bottom']==6 and hydraulic['drainage']==0\n    domains.append(('implicit-per-layer',hydraulic_header(hydraulic,nodes)))\n"+before)
ast.parse(s);(out/'closed_implicit_state_native_controls.py').write_text(s,encoding='utf8')
s=(T/'closed_gardner_state_science.py').read_text(encoding='utf8').replace('closed_gardner_state_feedback','closed_implicit_state_feedback').replace('CLOSED_GARDNER_STATE12_FINITE_CASE_PLAN_V3','CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1').replace('CLOSED_GARDNER','CLOSED_IMPLICIT')
before="        assert raw['macro.bin'][:8].decode()==meta['identity']['original_output']['native_codec']"
after=before+"""
        grid=re.search(r'(?mis)^[ \\t]*ISUBLAY[ \\t]+ISOILLAY[ \\t]+HSUBLAY[ \\t]+NCOMP[ \\t]*\\n([^\\n]*(?:\\n[^\\n]+)*)',active)
        assert grid is not None
        layers=[]
        for line in grid.group(1).splitlines():
            fields=line.split()
            if len(fields)!=4:break
            try:sub,soil,count=int(fields[0]),int(fields[1]),int(fields[3]);depth=float(fields[2])
            except ValueError:break
            assert sub==len(layers)+1 and soil>0 and count>0 and math.isfinite(depth) and depth>0;layers.append(soil)
        assert layers and set(layers)==set(range(1,max(layers)+1))
        effective=models*max(layers) if len(models)==1 else models;assert len(effective)==max(layers)
        header=[1,nodes,len(effective),int(spec['kind']=='cde'),1,0,spec['snow'],spec['frost'],1,2,0,6,0,*effective]
        packed=struct.pack('<'+str(len(header))+'i',*header);tag=b'S5IFX001' if spec['frost'] else b'S5IHX001'
        assert raw['macro.bin'].endswith(tag+packed+packed)
"""
assert s.count(before)==1;s=s.replace(before,after);ast.parse(s);(out/'closed_implicit_state_science.py').write_text(s,encoding='utf8')
print('PREPARED_FOUR_DISTINCT_CLOSED_IMPLICIT_CONTROLLERS_AND_FINITE_PLAN_NOT_INSTALLED_NOT_EXECUTED')
