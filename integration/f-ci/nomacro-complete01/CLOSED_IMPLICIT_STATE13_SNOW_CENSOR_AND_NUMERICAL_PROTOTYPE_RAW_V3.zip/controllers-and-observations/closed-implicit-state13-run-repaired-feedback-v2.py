from pathlib import Path
import json,os,subprocess,sys,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');opt=sys.argv[1]
C='6a0e6ff6cab1c0a7565938f43ee3b1921f63eaa3'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
cases=['closed-ordinary-gardner-water','closed-ordinary-model6-snow-cde-profile'] if opt=='O0' else ['closed-ordinary-model5-cde-profile']
root=E/'closure13-local-feedback-v2'/opt;root.mkdir(parents=True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1',TEMP=str(W/'active-python-scratch-v2'),TMP=str(W/'active-python-scratch-v2'))
env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
summary=dict(actual_source=C,optimization=opt,cases=[],models_selected=len(cases),original_input_parameters_and_calendars_unchanged=True)
for name in cases:
    command=[sys.executable,'-B','tests/nomacro_drainage/closed_implicit_state_feedback.py','--case',name,'--optimization',opt,'--output',str(root/name),'--build-output',str(W/('closure13-feedback-'+opt+'-v2')/'current'/name),'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider']
    start=time.perf_counter()
    with (root/(name+'.stdout')).open('xb') as out,(root/(name+'.stderr')).open('xb') as err:
        run=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=700)
    result=json.loads((root/name/'RESULT.json').read_text())
    summary['cases'].append(dict(case=name,returncode=run.returncode,seconds=time.perf_counter()-start,status=result['status'],error=result.get('error')))
    (root/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
    print(name,run.returncode,result['status'],result.get('error',''),flush=True)
    assert git('rev-parse','HEAD').decode().strip()==C
assert all(v['returncode']==0 for v in summary['cases'])
