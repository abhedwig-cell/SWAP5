from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
from decimal import Decimal,localcontext
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='66dae38844cf8d16508e76b6caee4460c11e5fdc';SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
sys.path.insert(0,str(R/'tests/nomacro_drainage'));from closed_implicit_state_feedback import ledger,m
snow=E/'closure13-local-feedback-v3/O0/closed-ordinary-model6-snow-cde-profile';q=json.loads((snow/'RESULT.json').read_text());assert q['actual_source']==C and q['error']=="TimeoutError('Model wall cap 240s')"
partial=ledger(snow/'trajectory','cde',33)
prototype=json.loads((E/'CLOSED_IMPLICIT_STATE13_DESATURATION_PROTOTYPE_V1.json').read_text());assert prototype['accepted_resumed_days']==5 and not prototype.get('error')
rows=[json.loads(v) for v in (E/'closure13-desaturation-prototype-v1/daily.jsonl').read_text().splitlines()]
oldrows=[json.loads(v) for v in (E/'closure13-local-feedback-v1/O0/closed-frost-mixed4-5-cde/trajectory/daily.jsonl').read_text().splitlines()]
assert [v['day'] for v in rows]==[31,32,33,34,35] and m.physical(rows[:2])==m.physical(oldrows[30:32])
prototype_checks=m.check(rows)
decimal_checks=[]
with localcontext() as context:
    context.prec=80
    for line in (E/'closure13-desaturation-prototype-v1/daily.jsonl').read_text().splitlines():
        row=json.loads(line,parse_float=Decimal);f=row['external_flux_cm'];water=sum(row['stock_start_cm'])-sum(row['stock_end_cm'])+sum(f[:7])-sum(f[7:]);chem=row['solute_end_mg_cm2']-row['solute_start_mg_cm2']-sum(row['solute_ledger_mg_cm2'][2:5])+sum(row['solute_ledger_mg_cm2'][5:8]);assert abs(water)<=Decimal('1e-10') and abs(chem)<=Decimal('1e-10')
        decimal_checks.append(dict(actual_day=row['day'],water_cm=str(water),chemical_mg_cm2=str(chem)))
name='CLOSED_IMPLICIT_STATE13_SNOW_CENSOR_AND_NUMERICAL_PROTOTYPE_RAW_V3';target=E/(name+'.zip');members={}
summary=dict(actual_scientific_source=C,Snow_status='CENSORED_AT_240_SECONDS_AFTER33_ACCEPTED_DAYS_NOT_PASS',partial_independent_budgets=partial,prototype_original_producer=prototype['actual_original_scientific_source'],prototype_new_numerical_policy=True,prototype_resumed_days=5,prototype_checks=prototype_checks,prototype_decimal_checks=decimal_checks,prototype_prior_days31_32_exact=True,new_qualified_contexts=0,new_admitted_contexts=0,original_reference='CSV0-only zero-day original initialization succeeds; original CSV initialization fails. Original full physical period causality remains UNKNOWN.',canonical_admission=False)
(E/'CLOSED_IMPLICIT_STATE13_SNOW_CENSOR_AND_PROTOTYPE_SUMMARY_V3.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
for opt in ['O0','O2']:
    path=W/('closure13-feedback-'+opt+'-v2')/'ACTUAL_BUILD_PROVENANCE.json'
    path.write_text(json.dumps(dict(actual_scientific_source='6a0e6ff6cab1c0a7565938f43ee3b1921f63eaa3',allocation_source_ref='2215b9d93d3616160d5ac813bd0c7b879536171a',allocation_ref_was_pending_and_stale=True,correction='Subsequent register update was refused as overlap. Actual immutable RESULT and BUILD bytes identify producer6a0e; neither registry nor scientific roles were rewritten.',optimization=opt),indent=2)+'\n',encoding='utf8')
roots=[E/'closure13-local-feedback-v3',W/'closure13-snow-native-O0-v3',E/'closure13-gardner-native-controls-v4',W/'closure13-original-swap-startup-O0-v2',W/'closure13-original-swap-startup-v2',W/'closure13-original-output-isolation-v1',W/'closure13-desaturation-prototype-O0-v1',W/'closure13-desaturation-prototype-v1',E/'closure13-desaturation-prototype-v1']
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in roots:
        for p in sorted(root.rglob('*')):
            if p.is_file():
                raw=p.read_bytes();key='actual/'+p.relative_to(W).as_posix();assert key not in members;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=git('archive','--format=zip',C,'app','src','tools','tests/nomacro_drainage','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V4.json','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json');key='source/actual66dae-controller-and-physical-source.zip';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    for p in sorted(E.iterdir()):
        if p.is_file() and p.suffix in ('.py','.json','.diff') and p.name.startswith(('CLOSED_IMPLICIT_STATE13_','closed-implicit-state13-')) and p.name!=name+'.json':
            raw=p.read_bytes();key='controllers-and-observations/'+p.name;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(members) and z.testzip() is None
    for key,item in members.items():assert SHA(z.read(key))==item['sha256'] and len(z.read(key))==item['bytes']
raw=target.read_bytes();assert len(raw)<48*1024**2
descriptor=dict(status=summary['Snow_status'],actual_scientific_source=C,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,summary=summary,canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(descriptor,indent=2)+'\n',encoding='utf8');print(len(raw),descriptor['sha256'],len(members),flush=True)
