from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='6a0e6ff6cab1c0a7565938f43ee3b1921f63eaa3';P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
sys.path.insert(0,str(R/'tests/nomacro_drainage'));from closed_implicit_state_feedback import ledger
contexts=[]
for opt in ['O0','O2']:
    batch=json.loads((E/'closure13-local-feedback-v2'/opt/'SUMMARY.json').read_text())
    for item in batch['cases']:
        root=E/'closure13-local-feedback-v2'/opt/item['case'];q=json.loads((root/'RESULT.json').read_text());assert q['actual_source']==C
        daily=root/'trajectory/daily.jsonl';days=len(daily.read_text().splitlines()) if daily.exists() else 0
        record=dict(case=item['case'],optimization=opt,actual_source=C,status=q['status'],error=q.get('error'),primary_days=days,complete=item['returncode']==0)
        record['classification']='EVIDENCE_ONLY' if record['complete'] else 'NUMERICAL_DEFECT' if days else 'COMPOSITION_MISSING'
        if days:record['independent_budgets']=ledger(root/'trajectory',q['specification']['kind'],days)
        contexts.append(record)
assert len(contexts)==3 and sum(v['complete'] for v in contexts)==1 and sum(v['primary_days'] for v in contexts)==60
name='CLOSED_IMPLICIT_STATE13_OUTPUT_FEEDBACK_AND_CLOCK_OBSERVATION_RAW_V2';target=E/(name+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for root in [E/'closure13-local-feedback-v2',W/'closure13-feedback-O0-v2',W/'closure13-feedback-O2-v2',W/'closure13-clock-observer-O0-v1',W/'closure13-clock-observer-v1',E/'closure13-clock-observer-v1',E/'closure13-clock-observer-v2']:
        for p in sorted(root.rglob('*')):
            if p.is_file():
                raw=p.read_bytes();key='actual/'+p.relative_to(W).as_posix();assert key not in members
                z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=git('archive','--format=zip',C,'app','src','tools','tests/nomacro_drainage','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_SOURCE_PROPOSAL_V3.json','integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_FINITE_CASE_PLAN_V1.json');key='source/actual6a0e-controller-and-physical-source.zip';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    for p in sorted(E.iterdir()):
        if p.is_file() and p.suffix in ('.py','.json') and p.name.startswith(('CLOSED_IMPLICIT_STATE13_','closed-implicit-state13-')) and p.name!=name+'.json':
            raw=p.read_bytes();key='controllers-and-observations/'+p.name;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(target) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(members)
    assert z.testzip() is None
    for key,item in members.items():assert SHA(z.read(key))==item['sha256'] and len(z.read(key))==item['bytes']
raw=target.read_bytes();assert len(raw)<48*1024**2
q=dict(status='ONE_35DAY_LOCAL_PASS_ONE_DAY26_NUMERICAL_FAILURE_ONE_PREMODEL_SNOW_NATIVE_GUARD_FAILURE_AND_DAY30_COLD_CAUSAL_OBSERVATION_RETAINED',actual_scientific_source=C,archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,contexts=contexts,complete_contexts=1,partial_primary_days=25,new_qualified_contexts=0,new_admitted_contexts=0,original_main_causality='UNKNOWN',canonical_admission=False)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(len(raw),q['sha256'],len(members),flush=True)
