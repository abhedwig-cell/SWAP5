from pathlib import Path
import hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
C=git('rev-parse','HEAD').decode().strip();assert C=='84332daf3c5e398d1566b2e9c0da1af94b18796e' and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
assert hashlib.sha256(git('show',C+':integration/f-ci/nomacro-complete01/CLOSED_IMPLICIT_STATE13_FIRST_LOCAL_FAILURES_RAW_V1.zip')).hexdigest()=='0558985b573556487caf8160ea2dc1aee2c46c4d86b792abaa204198694eb783'
path=P/'STATUS.json';q=json.loads(path.read_text());q['test_selection']['candidate']=C
group=q['test_selection']['groups']['closed_implicit_feedback']
group.update(changed_dependency='Nine actual production files compose unchanged original closed implicit analytical state and monthly/perstep/Snow output owners; no solver, parameter, calendar input or numerical-policy modification',scientific_claim='Three corrected ordinary35day couplings: Gardner monthly water O0, Snow model6 CDE O0, model5 ordinary CDE O2; exact cold/native/transactions. Two unmodified Frost day33 failures retained and not replayed.',expected_seconds=600)
path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
git('add','--',str(path.relative_to(R)));git('commit','-m','Select repaired closed implicit original calendar coupling feedback')
print(git('rev-parse','HEAD').decode().strip())
