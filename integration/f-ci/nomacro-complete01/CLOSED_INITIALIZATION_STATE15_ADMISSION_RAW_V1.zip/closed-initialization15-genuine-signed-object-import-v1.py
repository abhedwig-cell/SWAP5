"""Recover genuine signed GitHub commit bytes only if their Git SHA1 matches."""
import argparse,hashlib,json,re,subprocess
from pathlib import Path


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repository',type=Path,required=True)
    parser.add_argument('--api',type=Path,required=True)
    args=parser.parse_args();q=json.loads(args.api.read_text());sha=q['sha']
    assert re.fullmatch('[0-9a-f]{40}',sha)
    assert q['verification']['verified'] is True and q['verification']['reason']=='valid'
    payload=q['verification']['payload'].encode();signature=q['verification']['signature'].encode()
    assert b'\n\n' in payload and b'\0' not in payload
    headers,message=payload.split(b'\n\n',1);lines=headers.split(b'\n');matches=set()
    for sig in (signature,signature.rstrip(b'\n')):
        folded=b'gpgsig '+sig.replace(b'\n',b'\n ')
        for body in (folded,folded.rstrip(b' '),folded.rstrip(b' \n')):
            for at in range(len(lines)+1):
                raw=b'\n'.join(lines[:at]+[body]+lines[at:])+b'\n\n'+message
                if hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha:
                    matches.add(raw)
    assert len(matches)==1,'No unique genuine signed byte reconstruction; no object written'
    raw=matches.pop();git=lambda *a,**kw:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=args.repository,**kw)
    before=git('rev-parse','HEAD').decode().strip()
    assert git('hash-object','-t','commit','--stdin',input=raw).decode().strip()==sha
    assert git('hash-object','-t','commit','-w','--stdin',input=raw).decode().strip()==sha
    assert git('cat-file','commit',sha)==raw
    assert git('show','-s','--format=%P',sha).decode().split()==[p['sha'] for p in q['parents']]
    assert git('rev-parse',sha+'^{tree}').decode().strip()==q['tree']['sha']
    after=git('rev-parse','HEAD').decode().strip();assert before==after
    target=args.api.parent/('CLOSED_INITIALIZATION_STATE15_PR1814_GENUINE_GIT_OBJECT_'+sha+'.bin')
    with target.open('xb') as stream:stream.write(raw)
    record=dict(status='GENUINE_SIGNED_GITHUB_COMMIT_BYTES_EXACT_TARGET_GIT_SHA1_IMPORTED_NO_IDENTITY_PROJECTION',
                sha=sha,tree=q['tree']['sha'],parents=[p['sha'] for p in q['parents']],
                bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),file=target.name,
                original_API_file=args.api.name,original_API_sha256=hashlib.sha256(args.api.read_bytes()).hexdigest(),
                compiler_executions=0,model_executions=0,before_HEAD=before,after_HEAD=after,HEAD_changed=False)
    with target.with_suffix('.json').open('x') as stream:json.dump(record,stream,indent=2)
    print(record['status'],sha,len(raw),flush=True)


if __name__=='__main__':main()

