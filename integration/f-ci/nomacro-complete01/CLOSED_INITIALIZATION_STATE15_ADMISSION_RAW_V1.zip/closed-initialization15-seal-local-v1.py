"""Preserve actual local outputs/compiled bytes with genuine canonical Git source IDs."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
C='c23ae582a249b4167dad0d59823e33d87e108475';before=git('rev-parse','HEAD');assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
assert not git('diff',C,'HEAD','--','app','src','tools/solute','tools/vq','reference')
rows=[json.loads(p.read_text()) for p in sorted(E.glob('CLOSED_INITIALIZATION_STATE15_LOCAL_*_COMBINED_INDEPENDENT_V2.json'))]
assert len(rows)==10 and {q['actual_producer'] for q in rows}=={C}
assert tuple(sum(q[k] if k in ['days','native_refusals'] else len(q[k]) for q in rows) for k in ['days','native_samples','cold','native_refusals'])==(350,70,30,292)
files={}
for root in [E/'closure15-feedback-v1',W/'closure15-feedback-O0-v1',W/'closure15-feedback-O2-v1']:
    assert root.is_dir() and not root.is_symlink()
    for path in root.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():files['actual/'+path.relative_to(W).as_posix()]=path
for path in E.iterdir():
    if path.is_file() and path.suffix in {'.json','.txt','.py'} and path.name.startswith('CLOSED_INITIALIZATION_STATE15_LOCAL_'):files['observations/'+path.name]=path
identity=dict(status='GENUINE_CANONICAL_GIT_SOURCE_IDENTITIES_ORIGINAL_LOCAL_SCIENTIFIC_PRODUCER_NOT_A_WORKING_CHECKOUT_BYTE_CLAIM',actual_original_scientific_producer=C,actual_source_tree=git('rev-parse',C+'^{tree}').decode().strip(),original_input_archive='INITIAL_PROFILE_CALENDAR_WINDOWS_RAW_V1',original_input_archive_revision='fa77380ecce3317775bd1129b5de007fcbcf2e1f',original_mixed_SDK_archive='CLOSED_DEFAULT_CALENDAR_STATE14_ORIGINAL_MIXED_J_SDK_RAW_V5',original_mixed_SDK_sha256='0fb81e6854395c858153dd9efd33e34b5c48b79a7c9f1d964ecf909ab967271e',source_inventory=git('ls-tree','-r',C,'--','app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','reference/swap-4.3.1').decode().splitlines(),actual_generated_Fortran_objects_executables_and_all_raw_scientific_outputs_preserved=True,original_working_checkout_source_bytes_claimed=False,earlier_scientific_source_or_path_roles_rebound=False)
raw_identity=(json.dumps(identity,indent=2)+'\n').encode();members={};stem='CLOSED_INITIALIZATION_STATE15_ALL_LOCAL_RAW_V1';target=E/(stem+'.zip')
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(name,raw);members[name]=dict(bytes=len(raw),sha256=SHA(raw))
    z.writestr('ORIGINAL_CANONICAL_GIT_SOURCE_IDENTITIES.json',raw_identity);members['ORIGINAL_CANONICAL_GIT_SOURCE_IDENTITIES.json']=dict(bytes=len(raw_identity),sha256=SHA(raw_identity))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for name,v in members.items():
        raw=z.read(name);assert len(raw)==v['bytes'] and SHA(raw)==v['sha256']
        assert raw==(raw_identity if name=='ORIGINAL_CANONICAL_GIT_SOURCE_IDENTITIES.json' else files[name].read_bytes())
raw=target.read_bytes();parts=[];limit=48*1024**2
if len(raw)<=limit:parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))]
else:
    for i,start in enumerate(range(0,len(raw),limit),1):
        piece=raw[start:start+limit];path=E/(target.name+f'.part{i:03d}')
        with path.open('xb') as f:f.write(piece)
        parts.append(dict(file=path.name,bytes=len(piece),sha256=SHA(piece)))
    assert b''.join((E/v['file']).read_bytes() for v in parts)==raw
git('update-ref','refs/heads/codex/storage-retained/closure15-local-scientific-source-20261127',C)
assert git('rev-parse','HEAD')==before
record=dict(status='TEN_ACTUAL_ORIGINAL_LOCAL_CONTEXTS_AND_COMPLETE_RAW_GENERATED_COMPILED_AND_NEGATIVE_BYTES_SEALED_NO_SOURCE_REBINDING',archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_original_scientific_producer=C,context_count=10,primary_days=350,native_samples=70,exact_cold_windows=30,compiled_native_refusals=292,external_transaction_contexts=10,original_mixed_SDK_once_in_parent=identity['original_mixed_SDK_archive'],source_identity_kind=identity['status'],scientific_producers_rebound=False,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/(stem+'.json')).open('x',encoding='utf8') as f:json.dump(record,f,indent=2);f.write('\n')
print(record['status'],len(raw),SHA(raw),len(members),len(parts),flush=True)
