"""Keep original compiler/native roles, first refusals and complete zero-day raw bytes."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
C='9704f2626ef655e8b7b6108e058035b46e4f7119';before=git('rev-parse','HEAD');assert before.decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
results=[json.loads((E/('closure15-preservation-v2/'+opt+'/RESULT.json')).read_text()) for opt in ['O0','O2']]
assert all(q['actual_compiler_source']==C and q['status']=='FIVE_CURRENT_OLD_INITIAL1_COMPLETE_GENERATED_OBJECTS_AND_ORIGINAL_NATIVE_READERS_PASS_ZERO_MODEL_DAYS' and len(q['contexts'])==5 and q['model_days']==0 for q in results)
rows=[v for q in results for v in q['contexts']];objects=sum(v['whole_object_proof']['actual_complete_objects'] for v in rows);assert objects==210
assert all(v['whole_object_proof']['whole_file_bytes_identical'] and v['whole_object_proof']['compiler_and_original_SDK_identical'] for v in rows)
assert all(v['compiled_original_native']['actual_original_scientific_producer']=='94c86c2918278ffd9595b9960eb8e1522652277a' and len(v['compiled_original_native']['controls'])==5 for v in rows)
files={};roots=[E/'closure15-preservation-v1',E/'closure15-preservation-v2',E/'closure15-native-origin-diagnostic-v1']
roots += [W/('closure15-preservation-'+opt+'-'+version) for version in ['v1','v2'] for opt in ['O0','O2']]
for root in roots:
    assert root.is_dir() and not root.is_symlink()
    for path in root.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():files['actual/'+path.relative_to(W).as_posix()]=path
for path in E.iterdir():
    if path.is_file() and path.suffix in {'.json','.txt'} and path.name.startswith(tuple('CLOSED_INITIALIZATION_STATE15_'+part for part in ['FIRST_PRESERVATION','ORIGINAL_NATIVE_ORIGIN','PRESERVATION_SELECTION','FORTY_INHERITED','FIFTYSIX_INHERITED','MCSOL_UNCHANGED','PARENT_ADMISSION'])):files['observations/'+path.name]=path
sources={}
for source in [C,'b0e91b63ffb858e703d1cc5ff5ce913d616857a4']:
    assert git('cat-file','-t',source).strip()==b'commit'
    sources[source]=dict(actual_tree=git('rev-parse',source+'^{tree}').decode().strip(),source_inventory=git('ls-tree','-r',source,'--','app','src','tools/solute','tools/vq','tests/nomacro_drainage','reference/swap-4.3.1').decode().splitlines())
identity=dict(status='GENUINE_GIT_COMPILER_SOURCE_IDENTITIES_AND_DISTINCT_ORIGINAL_NUMERICAL_VERSUS_CANONICAL_METADATA_NATIVE_ROLES',actual_current_compiler_source=C,first_refused_compiler_source='b0e91b63ffb858e703d1cc5ff5ce913d616857a4',original_canonical_metadata_and_native_producer='94c86c2918278ffd9595b9960eb8e1522652277a',original_local_numerical_producers=sorted({v['actual_original_scientific_producer'] for v in rows}),sources=sources,raw_working_checkout_source_bytes_claimed=False,original_scientific_sources_or_fields_rebound=False)
raw_identity=(json.dumps(identity,indent=2)+'\n').encode();stem='CLOSED_INITIALIZATION_STATE15_CURRENT_OLD_PRESERVATION_RAW_V2';target=E/(stem+'.zip');members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(name,raw);members[name]=dict(bytes=len(raw),sha256=SHA(raw))
    z.writestr('ORIGINAL_DISTINCT_GIT_SOURCE_ROLES.json',raw_identity);members['ORIGINAL_DISTINCT_GIT_SOURCE_ROLES.json']=dict(bytes=len(raw_identity),sha256=SHA(raw_identity))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for name,v in members.items():
        raw=z.read(name);assert len(raw)==v['bytes'] and SHA(raw)==v['sha256'] and raw==(raw_identity if name=='ORIGINAL_DISTINCT_GIT_SOURCE_ROLES.json' else files[name].read_bytes())
raw=target.read_bytes();parts=[];limit=48*1024**2
if len(raw)<=limit:parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))]
else:
    for i,start in enumerate(range(0,len(raw),limit),1):
        piece=raw[start:start+limit];path=E/(target.name+f'.part{i:03d}')
        with path.open('xb') as f:f.write(piece)
        parts.append(dict(file=path.name,bytes=len(piece),sha256=SHA(piece)))
    assert b''.join((E/v['file']).read_bytes() for v in parts)==raw
git('update-ref','refs/heads/codex/storage-retained/closure15-current-preservation-source-20261127',C);assert git('rev-parse','HEAD')==before
record=dict(status='TEN_CURRENT_OLD_INITIAL1_COMPLETE_OBJECTS_CANONICAL_OUTPUT_METADATA_AND_ORIGINAL_NATIVE_ZERO_DAY_PRESERVATION_ALL_RAW_SEALED_WITH_FIRST_REFUSALS',archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_compiler_source=C,context_count=10,whole_objects=210,compiled_original_native_positives=10,compiled_native_refusals=40,old_model_periods_replayed=0,first_precanonical_metadata_assertion_refusals_retained=2,additional_original_native_origin_diagnostics_retained=True,original_source_roles=identity,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/(stem+'.json')).open('x',encoding='utf8') as f:json.dump(record,f,indent=2);f.write('\n')
print(record['status'],len(raw),SHA(raw),len(members),len(parts),flush=True)
