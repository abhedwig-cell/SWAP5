"""Observe actual clean current public/publication commands; no source projection."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
p=argparse.ArgumentParser();p.add_argument('--mode',choices=('PUBLIC','PUBLICATION'),required=True);p.add_argument('--version',required=True);p.add_argument('--expected-head',required=True);a=p.parse_args()
output=E/('CLOSED_JOINT_HISTORY_STATE16_'+a.version+'_'+a.mode+'_V1')
git=lambda *x:subprocess.check_output(['git',*x],cwd=R).decode().strip()
def snapshot():
    path=Path(git('rev-parse','--git-path','info/sparse-checkout'));path=path if path.is_absolute() else R/path
    return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all','--ignored'),sparse=path.read_text().splitlines(),original_project_files={p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()})
before=snapshot();assert before['head']==a.expected_head;assert not before['status'] and len(before['sparse'])==3 and len(before['original_project_files'])==56
env=dict(os.environ,GITHUB_EVENT_NAME='pull_request')
if a.mode=='PUBLICATION':
    for key in ('PYTHONDONTWRITEBYTECODE','PYTHONPYCACHEPREFIX'):env.pop(key,None)
    probe=subprocess.run([sys.executable,'-c','import sys; print(sys.dont_write_bytecode)'],env=env,capture_output=True,check=True)
    assert probe.stdout.strip()==b'False' and not probe.stderr
    command=[sys.executable,'tests/nomacro_drainage/frost_publication_scope.py']
else:command=[sys.executable,'-B','tests/hupsel51/verify_successor.py']
started=time.perf_counter();error=None;returncode=None
try:
    with output.with_suffix('.stdout.txt').open('xb') as stdout,output.with_suffix('.stderr.txt').open('xb') as stderr:
        child=subprocess.run(command,cwd=R,env=env,stdout=stdout,stderr=stderr,timeout=3600)
    returncode=child.returncode
except Exception as exc:error=repr(exc)
report=dict(status='ACTUAL_CURRENT_'+a.mode+'_COMMAND_RETURNED',command=command,returncode=returncode,error=error,seconds=time.perf_counter()-started,before=before,after=snapshot(),compiler_executions=0,model_executions=0)
if a.mode=='PUBLICATION':report.update(ordinary_python_default_dont_write_bytecode=False,child_bytecode_environment_variables_absent=True,entry_point_owns_no_bytecode_writes=True)
output.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
assert error is None and returncode==0 and report['before']==report['after']
assert not output.with_suffix('.stderr.txt').read_bytes()
if a.mode=='PUBLICATION':assert b'PUBLICATION_REPLAY_SELECTED=false' in output.with_suffix('.stdout.txt').read_bytes()
else:assert json.loads(output.with_suffix('.stdout.txt').read_text())['coadmission']['contexts']==1068
print(report['status'],report['seconds'],before['head'],flush=True)
