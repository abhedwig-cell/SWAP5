"""Seal only actual completed phase16 admission, preserving original source roles."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
p=argparse.ArgumentParser();p.add_argument('--merge',required=True);M=p.parse_args().merge
B='857b25a81c88626075b91f46a3fb42e9fce801f3';C='605a0c4b3bab0b17333d64fe3b0cbd78c0dcda78';S='f58ce156b1ccebf960f7b7af17ff20b5a943e9fb';A='3b4249e00cf085b8d3dcfd3cd238837cef852b75';TREE='3d05e0c68a08c159757e9474f97488ef623a9106'
PREFIX='CLOSED_JOINT_HISTORY_STATE16_'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda name:json.loads((E/(PREFIX+name+'.json')).read_text(encoding='utf8'))
observer=git('rev-parse','HEAD').decode().strip(); assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
# Package the immutable actual M15 objects and previously recorded real M15 executions.
# The packaging observer may be the genuine successor; never identify it as M15.
assert git('rev-parse',M+'^{commit}').decode().strip()==M
for sha in [C,S,M]:assert git('rev-parse',sha+'^{tree}').decode().strip()==TREE
for sha,role in [(S,'SYNTHETIC'),(M,'ACTUAL_MERGE')]:
    assert git('show','-s','--format=%P',sha).decode().split()==[B,C]
    raw=(E/(PREFIX+'PR1815_GENUINE_GIT_OBJECT_'+sha+'.bin')).read_bytes()
    assert raw==git('cat-file','commit',sha) and hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha
    api=read('PR1815_FINAL1_'+role+'_GIT_API_V1');assert api['sha']==sha and api['verification']['verified'] and api['verification']['reason']=='valid'
observations={};fixtures=sparse=coadmission=None
for role,head in [('CANDIDATE',C),('ACTUAL_MERGE1',M)]:
    for scope in ['PUBLIC','PUBLICATION']:
        stem=role+'_'+scope+'_V1';q=read(stem);raw=(E/(PREFIX+stem+'.stdout.txt')).read_bytes()
        assert q['returncode']==0 and q.get('error') is None and q['before']==q['after'] and not q['before']['status'] and not (E/(PREFIX+stem+'.stderr.txt')).read_bytes()
        before=q['before'];assert before['head']==head and before['tree']==TREE and len(before['sparse'])==3 and len(before['original_project_files'])==56
        if fixtures is None:fixtures=before['original_project_files'];sparse=before['sparse']
        assert before['original_project_files']==fixtures and before['sparse']==sparse
        if scope=='PUBLIC':
            actual=json.loads(raw);assert len(actual['new_original_portable_science'])==4
            assert tuple(sum(v[k] for v in actual['new_original_portable_science']) for k in ['context_count','primary_days','native_samples','exact_cold_windows','compiled_native_refusals','external_transaction_contexts'])==(24,840,168,72,744,24)
            assert actual['new_numerical_policy'] is False and actual['physical_equations_changed'] is False and actual['new_physical_state'] is False
            assert actual['compiler_executions']==actual['model_executions']==0 and len(actual['deferred_numerical_cases'])==2 and actual['current_finite_batch_deferred_numerical_cases']==[]
            assert not actual['additional_local_contexts_counted_again'] and not actual['unchanged_periods_replayed'] and not actual['original_scientific_producers_rebound']
            assert actual['additional_actual_original_local_science']['context_count']==12
            old=actual['actual_current_native_recovery_of_original_local_checkpoints'];assert len(old['contexts'])==4 and old['unchanged_whole_objects']==88 and old['exact_original_native_positives']==28 and old['compiled_native_refusals']==112 and old['model_executions']==0
            assert actual['additional_actual_original_local_science']['original_native_failure_contexts_not_qualified']==4 and actual['original_native_failure_roles_relabelled'] is False and actual['native_counters_or_dates_normalized'] is False
            assert len(actual['unaffected_original_local_source_selection']['contexts'])==8 and len(actual['admitted_default_original_policy_selection']['contexts'])==40
            inherited=actual['inherited_old40_unchanged_source_selection']; assert len(inherited['contexts'])==40 and inherited['whole_objects_inherited']==1046 and inherited['compiler_executions']==inherited['model_executions']==0
            assert len(actual['actual_non1_closed_domains_preserved']['contexts'])==56 and all(v['new_default_model1_branch_selected'] is False for v in actual['actual_non1_closed_domains_preserved']['contexts']) and actual['unchanged_MCSOL_selection']['unchanged_tracked_files']==1063 and len(actual['actual_raw_custody'])==8
            assert actual['functional_completion']=='PARTIAL' and actual['whole_scientific_equivalence']=='NOT_QUALIFIED' and actual['global_family_and_gap_counts']=='UNKNOWN' and actual['RC3_changed'] is False
            if coadmission is None:coadmission=actual['coadmission']
            assert coadmission==actual['coadmission']
        else:assert b'PUBLICATION_REPLAY_SELECTED=false' in raw and q['ordinary_python_default_dont_write_bytecode'] is False and q['child_bytecode_environment_variables_absent'] is True
        observations[PREFIX+stem]=dict(actual_head=head,seconds=q['seconds'],stdout_bytes=len(raw),stdout_sha256=SHA(raw))
assert tuple(coadmission[k] for k in ['contexts','short35_contexts','native_calendar_samples','exact_cold_windows'])==(1068,974,7122,3128)
negative=read('FINAL1_NEGATIVES_V1');assert negative['candidate']==C and negative['never_merge'] and negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN3_PUBLIC_NEGATIVES_REFUSED' and len(negative['controls'])==4
for item in negative['controls']:
    assert item['actual_refusal'] and item['actual_one_file_delta'] and git('show','-s','--format=%P',item['head']).decode().split()==[C] and git('diff','--name-only',C,item['head']).decode().strip()==item['path']
    q=read(item['actual_observation'][len(PREFIX):]);assert q['returncode'] not in [None,0] and q['before']==q['after'] and q['before']['head']==item['head'] and q['before']['original_project_files']==fixtures
assert negative['controls'][-1]['actual_publication_replay_selected']
assert len(read('FINAL1_NEGATIVE_GIT_CUSTODY_V1')['controls'])==4
mini=read('ACTUAL_NEGATIVE_GENUINE_GIT_OBJECTS_V1');assert mini['candidate']==C and mini['candidate_tree']==TREE
for phase in ['PREMERGE','POSTMERGE']:
    prefix='PR1815_FINAL1_'+phase;runs=read(prefix+'_ALL_CI_ORIGINAL_API_V1');checks=read(prefix+'_ALL_CHECKS_ORIGINAL_API_V1')
    assert runs['total_count']==len(runs['workflow_runs'])==14 and all(v['head_sha']==C and v['status']=='completed' and v['conclusion']=='success' for v in runs['workflow_runs'])
    assert checks['total_count']==len(checks['check_runs'])>=40 and all(v['head_sha']==C and v['status']=='completed' and v['conclusion'] in ['success','skipped'] for v in checks['check_runs'])
    pr=read(prefix+'_ORIGINAL_API_V1');assert pr['head']['sha']==C and pr['base']['ref']=='integration/f-ci-canonical' and pr['merged']==(phase=='POSTMERGE')
    assert read(prefix+'_CANONICAL_REF_ORIGINAL_API_V1')['object']['sha']==(M if phase=='POSTMERGE' else B)
success=sum(v['conclusion']=='success' for v in checks['check_runs']);skipped=sum(v['conclusion']=='skipped' for v in checks['check_runs'])
final=read('PR1815_FINAL_HEAD_ORIGINAL_LOG_CUSTODY_V1');assert final['status']=='ALL_TERMINAL_PR_RUN_LOGS_RETAINED' and len(final['runs'])==14 and len(final['jobs'])==success and len(final['skipped_jobs'])==skipped
canonical=read('ACTUAL_MERGE_ALL_CI_ORIGINAL_API_V1');assert canonical['total_count']==len(canonical['workflow_runs'])>=4 and all(v['head_sha']==M and v['status']=='completed' and v['conclusion']=='success' for v in canonical['workflow_runs'])
canon=read('ACTUAL_MERGE_ORIGINAL_LOG_CUSTODY_V1');assert canon['status']=='ALL_TERMINAL_CANONICAL_RUN_LOGS_RETAINED' and canon['actual_verified_merge']==M and len(canon['runs'])==canonical['total_count']
logs=[]
for role,report,head,prefix in [('PR_FINAL',final,C,'PR1815_FINAL_HEAD'),('ACTUAL_MERGE',canon,M,'ACTUAL_MERGE')]:
    for item in report['jobs']:
        raw=(E/item['original_log']).read_bytes();raw.decode('utf8',errors='strict');assert item['actual_source']==head and item['conclusion']=='success' and len(raw)==item['bytes'] and SHA(raw)==item['sha256']
        stem=prefix+'_JOB_'+str(item['job_id']);job=read(stem+'_ORIGINAL_API_V1');run=read(stem+'_RUN_ORIGINAL_API_V1');assert job['head_sha']==run['head_sha']==head and job['run_id']==run['id'] and job['conclusion']==run['conclusion']=='success' and run['event']==('push' if role=='ACTUAL_MERGE' else 'pull_request')
        if item['name']=='modular-feedback':assert item['signed_checkout_printed'] and b'"contexts": 1068' in raw
        logs.append(dict(role=role,**item))
assert not git('diff',B,M,'--','tests/hupsel51/test_successor.py')
assert read('ORIGINAL_ELEVEN_TESTS_V1')['returncode']==0
original_local=read('LOCAL_SCIENTIFIC_INDEPENDENT_V1'); assert original_local['context_count']==12 and original_local['primary_days']==420 and len(original_local['original_native_failures'])==4 and original_local['scientific_qualification'] is False
expected_pr=read('ORIGINAL_PR_WORKFLOW_SELECTION_V1'); assert {v['path'] for v in runs['workflow_runs']}=={v['path'] for v in expected_pr['expected_pull_request_workflows']}
expected_push=read('ORIGINAL_CANONICAL_WORKFLOW_SELECTION_V1'); assert {v['path'] for v in canonical['workflow_runs']}=={v['path'] for v in expected_push['expected_push_workflows']}
stem=PREFIX+'ADMISSION_RAW_V1';archive=E/(stem+'.zip');files={}
for path in E.iterdir():
    if path.is_file() and path.suffix in {'.py','.json','.log','.txt','.bin'} and not path.name.startswith(stem) and path.name.startswith((PREFIX,'closed-joint-history16-','closed_joint_history_calendar')):files[path.name]=path
tiny=E/mini['archive'];assert len(tiny.read_bytes())==mini['bytes'] and SHA(tiny.read_bytes())==mini['sha256'];files[tiny.name]=tiny
members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(name,raw);members[name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for name,item in members.items():raw=z.read(name);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and raw==files[name].read_bytes()
raw=archive.read_bytes();assert len(raw)<48*1024**2
assert git('rev-parse','HEAD').decode().strip()==observer
common=dict(packaging_actual_observer=observer,packaging_does_not_qualify_observer=True,canonical_admission=True,actual_merge=M,qualified_candidate=C,source_anchor=A,whole_tree=TREE,coadmission=coadmission,new_scientific_contexts=24,actual_primary_portable_producer='e8da5a5e30d28c74a41d57ddbfe3c44390a2a8af',actual_local_producers=['9f794ca219367b85b79bdd9850617e4e26c691a1'],actual_current_native_compiler='38eb3fa35db913ed6b4df20e3bc9dc1b178702a3',additional_twelve_local_contexts_counted_again=False,whole_object_contexts=4,unchanged_whole_objects=88,original_native_positive_controls=28,original_native_compiled_refusals=112,original_local_native_failure_contexts_preserved=4,inherited_unselected_contexts=40,inherited_whole_objects_not_recompiled=1046,two_inherited_explicit_Gardner_Snow9_numerical_cases_remain_functional_gaps=True,current_finite_batch_deferred_numerical_cases=0,original_full_period_reference_causality='UNKNOWN_INITIALIZATION_CSV_CONTROL_DOES_NOT_ESTABLISH_FULL_PERIOD_CAUSALITY',producer_roles_rebound=False,new_numerical_policy=False,physical_equations_changed=False,new_physical_state=False,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
descriptor=dict(status='ACTUAL_CANONICAL1068_SIGNED_SOURCE_PUBLIC_ORDINARY_PUBLICATION_REQUIRED_CI_AND_FOUR_REAL_NEGATIVES_PRESERVED',archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members=members,actual_public_observations=observations,successful_PR_workflows=14,successful_PR_checks=success,skipped_PR_checks=skipped,canonical_push_workflows_success=canonical['total_count'],original_final_successful_CI_log_roles=logs,four_original_local_native_failures_and_compiler_controller_refusals_preserved=True,large_scientific_raw_archives_duplicated=False,admission_controller=Path(__file__).name,admission_controller_sha256=SHA(Path(__file__).read_bytes()),**common)
receipt=dict(status='ACTUAL_CANONICAL1068_CLOSED_JOINT_HISTORY_CALENDAR_ADMISSION_VERIFIED',PR=1815,previous_canonical=B,ordered_parents=[B,C],synthetic_merge=S,admission_archive_sha256=SHA(raw),**common)
for name,q in [(stem+'.json',descriptor),(PREFIX+'MERGE_RECEIPT_V1.json',receipt)]:
    with (E/name).open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(descriptor['status'],len(raw),descriptor['sha256'],len(members),flush=True)
