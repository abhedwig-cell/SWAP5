"""Import only original GitHub signed bytes matching the requested real object SHA."""
from pathlib import Path
import argparse,json,os,re,subprocess,sys,urllib.request
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');B='857b25a81c88626075b91f46a3fb42e9fce801f3'
p=argparse.ArgumentParser();p.add_argument('--candidate',required=True);p.add_argument('--sha',required=True);p.add_argument('--role',choices=['SYNTHETIC','ACTUAL_MERGE'],required=True);a=p.parse_args();assert re.fullmatch('[0-9a-f]{40}',a.candidate) and re.fullmatch('[0-9a-f]{40}',a.sha)
git=lambda *v:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*v],cwd=R);before=git('rev-parse','HEAD');assert before.decode().strip()==a.candidate and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
child=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);child.check_returncode();fields=dict(v.split('=',1) for v in child.stdout.decode().splitlines() if '=' in v)
request=urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/git/commits/'+a.sha,headers={'Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','Accept-Encoding':'identity','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-genuine-final-object-custody'})
with urllib.request.urlopen(request,timeout=40) as response:raw=response.read()
q=json.loads(raw);assert q['sha']==a.sha and [v['sha'] for v in q['parents']]==[B,a.candidate] and q['tree']['sha']==git('rev-parse',a.candidate+'^{tree}').decode().strip() and q['verification']['verified'] is True
target=E/('CLOSED_JOINT_HISTORY_STATE16_PR1815_FINAL1_'+a.role+'_GIT_API_V1.json');assert not target.exists();target.write_bytes(raw)
subprocess.run([sys.executable,'-B',str(E/'closed-joint-history16-genuine-signed-object-import-v1.py'),'--repository',str(R),'--api',str(target)],check=True)
assert git('rev-parse','HEAD')==before;git('update-ref','refs/heads/codex/storage-retained/closure16-final1-'+a.role.lower()+'-20261127',a.sha);print('GENUINE_FINAL_GITHUB_SIGNED_OBJECT_RETAINED_HEAD_UNCHANGED',a.role,a.sha,flush=True)
