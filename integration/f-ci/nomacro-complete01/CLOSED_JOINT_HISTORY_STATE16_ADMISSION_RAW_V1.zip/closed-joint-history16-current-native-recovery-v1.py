"""Four actual current native reader compiles; original runtime roles stay literal."""
import argparse,json,subprocess,sys,time
from pathlib import Path
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from closed_joint_history_calendar_feedback import m,SHA,git
from closed_joint_history_calendar_science import source_contract
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=['O0','O2'],required=True);a=p.parse_args()
head=git('rev-parse','HEAD').decode().strip();assert head=='38eb3fa35db913ed6b4df20e3bc9dc1b178702a3'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
root=E/'closure16-current-native-v1'/a.optimization;root.mkdir(parents=True)
result=dict(status='RUNNING_CURRENT_JOINT_REGULAR_NATIVE_VALIDATION_RECOVERY',actual_current_compiler_source=head,original_runtime_source='9f794ca219367b85b79bdd9850617e4e26c691a1',optimization=a.optimization,source_contract=source_contract(head),contexts=[],old_model_periods_replayed=0,model_days=0,canonical_admission=False)
save=lambda:(root/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
save()
for name in ['hys2-periodic-water-initial1','hys2-periodic-water-initial2']:
    folder=root/name;folder.mkdir();original=E/'closure16-feedback-v1'/a.optimization/name
    old=json.loads((original/'RESULT.json').read_text());assert old['actual_source']==result['original_runtime_source']
    build=W/('closure16-native-recovery-'+a.optimization+'-v1')/name/'bundle'
    command=list(old['build']['command']);assert '--build-only' in command;command[command.index('--output')+1]=str(build)
    item=dict(case=name,actual_original_runtime_source=old['actual_source'],actual_current_compiler_source=head,original_profile=str(original),current_build=str(build),model_days=0)
    try:
        for member,digest in old['input_inventory']:assert SHA((Path(old['input_root'])/member).read_bytes())==digest
        started=time.perf_counter()
        with (folder/'build.stdout').open('xb') as out,(folder/'build.stderr').open('xb') as err:cp=subprocess.run(command,cwd=R,stdout=out,stderr=err,timeout=240)
        item['compile']=dict(command=command,returncode=cp.returncode,seconds=time.perf_counter()-started);save();cp.check_returncode()
        project=m.e.load(old['input_root'],original_output=True,time_step_policy=old['time_step_policy'])
        meta,_=m.validate_bundle(build,Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'),project)
        item['actual_current_BUILD_sha256']=SHA((build/'BUILD.json').read_bytes())
        command=[sys.executable,'-B',str(E/'closed-joint-history16-current-native-recovery-controls-v1.py'),'--profile',str(original),'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--current-build',str(build),'--output',str(folder/'native-controls')]
        with (folder/'native.stdout').open('xb') as out,(folder/'native.stderr').open('xb') as err:cp=subprocess.run(command,cwd=R,stdout=out,stderr=err,timeout=240)
        item['native']=dict(command=command,returncode=cp.returncode);cp.check_returncode()
        item['status']='CURRENT_NATIVE_READER_ORIGINAL_OWN_STOCK_HEAD_POSITIVE_AND_ALL_CORRUPTIONS_PASS_ZERO_MODEL_DAYS'
    except Exception as error:item.update(status='CURRENT_NATIVE_RECOVERY_FAILURE_RETAINED',error=repr(error))
    assert git('rev-parse','HEAD').decode().strip()==head
    result['contexts'].append(item);save();print(a.optimization,name,item['status'],flush=True)
result['status']='ALL_TWO_CURRENT_JOINT_REGULAR_NATIVE_READERS_PASS_NO_ORIGINAL_PERIOD_REPLAY' if all(v['status'].startswith('CURRENT_NATIVE_READER_') for v in result['contexts']) else 'CURRENT_JOINT_REGULAR_NATIVE_RECOVERY_FAILURES_RETAINED_NOT_QUALIFIED'
save();print(result['status'],flush=True)
if any(not v['status'].startswith('CURRENT_NATIVE_READER_') for v in result['contexts']):raise SystemExit(1)
