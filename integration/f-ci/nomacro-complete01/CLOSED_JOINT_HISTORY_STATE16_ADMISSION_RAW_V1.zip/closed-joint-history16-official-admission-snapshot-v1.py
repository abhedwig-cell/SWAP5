"""Fresh official matching PR/run/check metadata; terminal admission snapshots only."""
from pathlib import Path
import argparse,json,os,re,subprocess,urllib.request
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='605a0c4b3bab0b17333d64fe3b0cbd78c0dcda78';B='857b25a81c88626075b91f46a3fb42e9fce801f3';S=json.loads((E/'CLOSED_JOINT_HISTORY_STATE16_PR1815_FINAL1_SYNTHETIC_GIT_API_V1.json').read_text())['sha'];TREE='3d05e0c68a08c159757e9474f97488ef623a9106'
EXPECTED={373048667,361291030,350231902,374169088,366506117,377452065,367350343,377461752,374030810,351968455,377436526,369778710,377534434,372453937}
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['PREMERGE','POSTMERGE'],required=True);p.add_argument('--merge');p.add_argument('--probe',action='store_true');a=p.parse_args()
if a.phase=='POSTMERGE':assert a.merge and re.fullmatch('[0-9a-f]{40}',a.merge)
child=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30);child.check_returncode();fields=dict(line.split('=',1) for line in child.stdout.decode().splitlines() if '=' in line)
headers={'Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','Accept-Encoding':'identity','Cache-Control':'no-cache','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-closed-default-admission-metadata'}
def fetch(path):
    with urllib.request.urlopen(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=45) as stream:return stream.read()
def once(name,raw):
    path=E/name
    if path.exists():assert path.read_bytes()==raw
    else:path.write_bytes(raw)
prraw=fetch('pulls/1815');pr=json.loads(prraw);assert pr['head']['sha']==C and pr['base']['ref']=='integration/f-ci-canonical'
refraw=fetch('git/ref/heads/integration/f-ci-canonical');ref=json.loads(refraw)
if a.phase=='PREMERGE':assert not pr['merged'] and pr['state']=='open' and pr['mergeable'] is True and pr['merge_commit_sha']==S and pr['base']['sha']==ref['object']['sha']==B
else:assert pr['merged'] and pr['state']=='closed' and pr['merge_commit_sha']==ref['object']['sha']==a.merge
runraw=fetch('actions/runs?head_sha='+C+'&event=pull_request&per_page=100');runs=json.loads(runraw);checkraw=fetch('commits/'+C+'/check-runs?per_page=100');checks=json.loads(checkraw)
assert runs['total_count']==len(runs['workflow_runs'])==len(EXPECTED)==14 and {v['workflow_id'] for v in runs['workflow_runs']}==EXPECTED
selection=json.loads((E/'CLOSED_JOINT_HISTORY_STATE16_ORIGINAL_PR_WORKFLOW_SELECTION_V1.json').read_text()); assert selection['actual_candidate']==C and {v['path'] for v in runs['workflow_runs']}=={v['path'] for v in selection['expected_pull_request_workflows']}
observed=runs
if a.phase=='POSTMERGE':observed=json.loads(fetch('actions/runs?head_sha='+a.merge+'&event=push&per_page=100'))
if a.probe:
    print(json.dumps(dict(phase=a.phase,workflows=len(observed['workflow_runs']),completed=sum(v['status']=='completed' for v in observed['workflow_runs']),success=sum(v['conclusion']=='success' for v in observed['workflow_runs']),failed=[dict(id=v['id'],name=v['name'],conclusion=v['conclusion']) for v in observed['workflow_runs'] if v['status']=='completed' and v['conclusion']!='success'],check_count=checks['total_count'],checks_complete=sum(v['status']=='completed' for v in checks['check_runs']))),flush=True)
    for run in observed['workflow_runs']:
        if run['status']=='completed':continue
        jobs=json.loads(fetch('actions/runs/'+str(run['id'])+'/jobs?per_page=100'))
        print(json.dumps(dict(run_id=run['id'],name=run['name'],jobs=[dict(id=v['id'],name=v['name'],status=v['status'],conclusion=v['conclusion'],active_steps=[s['name'] for s in v['steps'] if s['status']=='in_progress']) for v in jobs['jobs'] if v['conclusion']!='skipped'])),flush=True)
    raise SystemExit(0)
assert all(v['head_sha']==C and v['status']=='completed' and v['conclusion']=='success' for v in runs['workflow_runs'])
assert checks['total_count']==len(checks['check_runs'])>=40 and all(v['head_sha']==C and v['status']=='completed' and v['conclusion'] in ['success','skipped'] for v in checks['check_runs'])
prefix='CLOSED_JOINT_HISTORY_STATE16_PR1815_FINAL1_'+a.phase
for suffix,raw in [('_ORIGINAL_API_V1.json',prraw),('_CANONICAL_REF_ORIGINAL_API_V1.json',refraw),('_ALL_CI_ORIGINAL_API_V1.json',runraw),('_ALL_CHECKS_ORIGINAL_API_V1.json',checkraw)]:once(prefix+suffix,raw)
if a.phase=='POSTMERGE':
    raw=fetch('git/commits/'+a.merge);q=json.loads(raw);assert q['sha']==a.merge and q['verification']['verified'] and q['verification']['reason']=='valid' and q['tree']['sha']==TREE and [v['sha'] for v in q['parents']]==[B,C]
    once(prefix+'_ACTUAL_GIT_ORIGINAL_API_V1.json',raw)
    raw=fetch('actions/runs?head_sha='+a.merge+'&event=push&per_page=100');canonical=json.loads(raw)
    assert canonical['total_count']==len(canonical['workflow_runs'])>=4 and all(v['head_sha']==a.merge and v['status']=='completed' and v['conclusion']=='success' for v in canonical['workflow_runs'])
    once('CLOSED_JOINT_HISTORY_STATE16_ACTUAL_MERGE_ALL_CI_ORIGINAL_API_V1.json',raw)
    for run in canonical['workflow_runs']:
        raw=fetch('actions/runs/'+str(run['id'])+'/jobs?per_page=100');jobs=json.loads(raw);assert jobs['total_count']==len(jobs['jobs']) and all(v['head_sha']==a.merge and v['status']=='completed' and v['conclusion'] in ['success','skipped'] for v in jobs['jobs'])
        once('CLOSED_JOINT_HISTORY_STATE16_ACTUAL_MERGE_JOBS_'+str(run['id'])+'_ORIGINAL_API_V1.json',raw)
print('OFFICIAL_MATCHING_TERMINAL_ADMISSION_METADATA_SAVED',a.phase,len(runs['workflow_runs']),checks['total_count'],sum(v['conclusion']=='success' for v in checks['check_runs']),sum(v['conclusion']=='skipped' for v in checks['check_runs']),flush=True)
