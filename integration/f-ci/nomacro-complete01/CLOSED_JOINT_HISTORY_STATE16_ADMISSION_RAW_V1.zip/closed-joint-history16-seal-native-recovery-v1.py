"""Retain actual current native compiles and separately identified original checkpoints."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
C='38eb3fa35db913ed6b4df20e3bc9dc1b178702a3';OLD='9f794ca219367b85b79bdd9850617e4e26c691a1'
before=git('rev-parse','HEAD');assert before.decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
observed=[]
for opt in ['O0','O2']:
    for name in ['hys2-periodic-water-initial1','hys2-periodic-water-initial2']:
        q=json.loads((E/'closure16-current-native-recovery-v2'/opt/name/'native-controls/RESULT.json').read_text())
        assert q['actual_current_compiler_source']==C and q['actual_original_runtime_source']==OLD and q['actual_original_stock_and_head_restored_exactly']
        assert q['status']=='ACTUAL_DEFAULT_CALENDAR_OWN_POSITIVE_AND_COMPILED_NATIVE_REFUSALS_PASS_ZERO_MODEL_DAYS' and len(q['refusals'])==28
        assert q['model_days']==q['compiler_executions']==0 and not q['original_scientific_checkpoint_and_runtime_identity_rebound']
        assert [v['file'] for v in q['complete_generated_source_comparison'] if not v['whole_equal']]==['integral.f90']
        assert [v['file'] for v in q['whole_object_comparison'] if not v['whole_equal']]==['integral.o']
        observed.append(q)
all_samples=json.loads((E/'CLOSED_JOINT_HISTORY_STATE16_CURRENT_NATIVE_ALL_SAMPLES_V1.json').read_text())
assert len(all_samples['contexts'])==24 and all_samples['total_current_positives_including_four_day4_controls']==28
files={}
for root in [E/'closure16-current-native-v1',E/'closure16-current-native-recovery-v2',E/'closure16-current-native-all-samples-v1',W/'closure16-native-recovery-O0-v1',W/'closure16-native-recovery-O2-v1']:
    assert root.is_dir() and not root.is_symlink()
    for p in root.rglob('*'):
        assert not p.is_symlink()
        if p.is_file():files['actual/'+p.relative_to(W).as_posix()]=p
for p in E.iterdir():
    if p.is_file() and p.suffix in {'.json','.py','.txt'} and p.name.startswith(('closed-joint-history16-current-native','CLOSED_JOINT_HISTORY_STATE16_CURRENT_','CLOSED_JOINT_HISTORY_STATE16_EIGHT_LOCAL_','CLOSED_JOINT_HISTORY_STATE16_NATIVE_COUNTER_','CLOSED_JOINT_HISTORY_STATE16_PERIODIC_COUNTER_')):files['observations/'+p.name]=p
identity=dict(status='ACTUAL_DISTINCT_CURRENT_COMPILER_AND_ORIGINAL_RUNTIME_CANONICAL_GIT_IDENTITIES_NOT_RAW_WORKING_SOURCE_BYTE_CLAIMS',actual_current_compiler_source=C,actual_original_runtime_source=OLD,current_tree=git('rev-parse',C+'^{tree}').decode().strip(),original_tree=git('rev-parse',OLD+'^{tree}').decode().strip(),source_inventory=git('ls-tree','-r',C,'--','app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface').decode().splitlines(),original_model_periods_replayed=0,all_actual_generated_Fortran_objects_executables_and_raw_native_streams_preserved=True,original_source_roles_rebound=False)
raw_identity=(json.dumps(identity,indent=2)+'\n').encode();members={};stem='CLOSED_JOINT_HISTORY_STATE16_CURRENT_NATIVE_RECOVERY_RAW_V2';target=E/(stem+'.zip')
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(files.items()):
        raw=p.read_bytes();z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw))
    z.writestr('ACTUAL_DISTINCT_SOURCE_IDENTITIES.json',raw_identity);members['ACTUAL_DISTINCT_SOURCE_IDENTITIES.json']=dict(bytes=len(raw_identity),sha256=SHA(raw_identity))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for n,v in members.items():
        raw=z.read(n);assert len(raw)==v['bytes'] and SHA(raw)==v['sha256']
        assert raw==(raw_identity if n=='ACTUAL_DISTINCT_SOURCE_IDENTITIES.json' else files[n].read_bytes())
raw=target.read_bytes();assert len(raw)<48*1024**2
record=dict(status='FOUR_CURRENT_NATIVE_READERS_EXACT_ORIGINAL28_HEAD_STOCK_POSITIVES_112_CORRUPTIONS_AND_UNCHANGED_NUMERICAL_OBJECTS_PRESERVED_ZERO_MODEL_DAYS',archive=target.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=target.name,bytes=len(raw),sha256=SHA(raw))],members=members,actual_current_compiler_source=C,actual_original_runtime_source=OLD,current_compiled_contexts=4,exact_original_native_positives=28,compiled_native_refusals=112,unchanged_whole_objects=sum(sum(v['whole_equal'] for v in q['whole_object_comparison']) for q in observed),changed_objects_only_in_native_validation=4,original_compiler_controller_filename_refusals_preserved=True,compiler_executions=0,model_days=0,original_scientific_roles_rebound=False,canonical_admission=False)
assert record['unchanged_whole_objects']==88 and git('rev-parse','HEAD')==before
with (E/(stem+'.json')).open('x',encoding='utf8') as f:json.dump(record,f,indent=2);f.write('\n')
git('update-ref','refs/heads/codex/storage-retained/closure16-current-native-source-20261127',C)
print(record['status'],len(raw),SHA(raw),len(members),flush=True)
