"""Actual retained fitted implicit/history decks; no numerical parameter edits."""
from contextlib import ExitStack
from pathlib import Path
import io,json,os,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
from original_output_baseline import assignment
from experimental_project import load,switches
from groundwater_water_output import metadata
from closed_default_calendar import selection
from implicit_conductivity import selection as implicit_selection
M='857b25a81c88626075b91f46a3fb42e9fce801f3'
git=lambda *v:subprocess.check_output(['git',*v],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
root=E/'closure16-original-fitted-discovery-v3';root.mkdir()
target=E/'CLOSED_JOINT_HISTORY_STATE16_FITTED_INPUT_DISCOVERY_V3.json';assert not target.exists()
record=dict(status='RUNNING_ACTUAL_FITTED_IMPLICIT_HISTORY_DISCOVERY',actual_APP_observer=M,contexts=[],compiler_executions=0,model_days=0,scientific_qualification_claimed=False,earlier_examined_Ksat_refusals_not_relabelled=True)
save=lambda:target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
save();data=GitArchiveSource(R,M)
descriptor=json.loads((data/'FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.json').read_bytes());raw=(data/descriptor['archive']).read_bytes()
assert len(raw)==descriptor['bytes'] and SHA(raw)==descriptor['sha256']
exe=W/'frost-undrained-state08-initialization-probe-O0-v1/corrected-module-import-v2/original_initialization_probe.exe'
member='phase-driver/corrected-module-import-v2/original_initialization_probe.exe'
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert exe.read_bytes()==z.read(member) and SHA(exe.read_bytes())==descriptor['members'][member]['sha256']=='dee4a94a5e0e92d07c9aee2a4790fc5178f159f7e81ad316fcaa58b6a6f28b5e'
record['actual_original_zero_day_probe']=dict(original_source='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d',executable_sha256=SHA(exe.read_bytes()),accepted_archive=descriptor['archive'],archive_sha256=descriptor['sha256'],O0_driver_with_original_mixed_SDK=True)
names=[('current','water-b5-i1-h1-p1-monthly-r1'),('current-inherited-postimages','water-b8-i1-h1-p2-monthly-r1'),('current','water-b5-i1-h2-p1-regular-r0'),('current','water-b8-i1-h2-p2-regular-r0'),('current','cde-b5-i1-h2-p1-dates-r1'),('current','cde-b5-i1-h2-p2-dates-r0')]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
with ExitStack() as stack:
    store=Archive(data,'FROST_IMPLICIT_HYS2_YEAR06_WINDOWS_O0_ORIGINAL_V1',stack)
    assert store.record['sha256']=='422a6e14386ee5cf7606be1124aafd236b1ab8411bc62241416d43dfa0801c30'
    assert store.record['actual_scientific_source']=='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6'
    for role,name in names:
        prefix=role+'/'+name+'/inputs/'
        original={n[len(prefix):]:store.get(n) for n in store.names if n.startswith(prefix)}
        assert original and 'swap.swp' in original
        folder=root/name;folder.mkdir()
        for n,raw in original.items():
            path=folder/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
        text=original['swap.swp'].decode('cp1252');before=switches(text)
        assert before['SWKIMPL']==1 and before['SWHYST'] in (1,2) and before['SWINCO'] in (1,2)
        declared=dict(SWDRA=0,SWBOTB=6,SWFROST=0,SWSNOW=0)
        for key,value in declared.items():text=assignment(text,key,value)
        (folder/'swap.swp').write_bytes(text.encode('cp1252'))
        current=switches(text);assert current['SWKIMPL']==before['SWKIMPL'] and current['SWHYST']==before['SWHYST'] and current['SWINCO']==before['SWINCO']
        fitted=implicit_selection(text,current,current,original_output=True)
        assert fitted['examined_ksat_interpolation'] is False
        inputs={p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=SHA(p.read_bytes())) for p in folder.rglob('*') if p.is_file()}
        item=dict(case=name,original_archive_at=M,original_archive=store.record['archive'],original_archive_sha256=store.record['sha256'],actual_original_input_producer=store.record['actual_scientific_source'],actual_original_input_role=role,original_input_prefix=prefix,original_input_members={n:dict(bytes=len(v),sha256=SHA(v)) for n,v in original.items()},declared_selector_changes=declared,initial=before['SWINCO'],history=before['SWHYST'],implicit=1,hydraulic_model=1,kind='cde' if before['SWSOLU'] else 'water',physical_parameter_tables_profiles_forcing_dates_and_output_controls_unchanged=True,input_root=str(folder),prepared_members=inputs,actual_unchanged_fitted_implicit_parameter_selection=fitted)
        try:
            project=load(folder,original_output=True);item['actual_frontend']='ACCEPTED_DESCRIPTOR';item['current_closed_default_selection']=selection(project)
            try:item['actual_output_metadata']=metadata(project);item['actual_output_owner']='ACCEPTED'
            except Exception as error:item['actual_output_owner']='REFUSED';item['actual_output_error']=repr(error)
        except Exception as error:item['actual_frontend']='REFUSED';item['actual_frontend_error']=repr(error)
        child=subprocess.run([str(exe),'./swap.swp'],cwd=folder,env=env,capture_output=True,timeout=30)
        (folder/'original-zero-day.stdout').write_bytes(child.stdout);(folder/'original-zero-day.stderr').write_bytes(child.stderr)
        item['actual_original_zero_day']=dict(returncode=child.returncode,accepted=b'ORIGINAL_INIT_PHASE AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS' in child.stdout,stdout_sha256=SHA(child.stdout),stderr_sha256=SHA(child.stderr),model_days=0)
        for n,v in inputs.items():assert SHA((folder/n).read_bytes())==v['sha256']
        record['contexts'].append(item);save();print(name,item['actual_frontend'],item.get('actual_output_owner'),item['actual_original_zero_day']['accepted'],flush=True)
assert len(record['contexts'])==6 and all(v['actual_original_zero_day']['accepted'] and v['actual_original_zero_day']['returncode']==0 for v in record['contexts'])
record['status']='SIX_ACTUAL_FITTED_IMPLICIT_HISTORY_INITIAL12_ZERO_DAY_ORIGINAL_CONTROLS_AND_M15_REFUSALS_RETAINED_NOT_QUALIFIED';save()
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
print(record['status'],flush=True)
