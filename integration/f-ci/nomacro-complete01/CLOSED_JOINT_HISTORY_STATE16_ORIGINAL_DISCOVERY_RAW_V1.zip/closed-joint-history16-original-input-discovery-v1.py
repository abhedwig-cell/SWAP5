"""Actual M15 joint implicit/hysteresis-domain discovery; retain old input identities, no periods."""
from contextlib import ExitStack
from pathlib import Path
import hashlib,io,json,os,re,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
from original_output_baseline import assignment
from experimental_project import load
from groundwater_water_output import metadata
from closed_default_calendar import selection
M='857b25a81c88626075b91f46a3fb42e9fce801f3';git=lambda *v:subprocess.check_output(['git',*v],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
root=E/'closure16-original-joint-discovery-v1';root.mkdir()
names=[(base,initial) for initial in [1,2] for base in ['hys1-clock-water','hys2-monthly-water','hys2-periodic-cde']]
record=dict(status='RUNNING_ACTUAL_JOINT_IMPLICIT_HISTORY_CLOSED_CALENDAR_DISCOVERY',actual_APP_observer=M,compiler_executions=0,model_days=0,contexts=[],canonical15_postmerge_validation_pending=True,scientific_qualification_claimed=False)
target=E/'CLOSED_JOINT_HISTORY_STATE16_ORIGINAL_INPUT_DISCOVERY_V1.json';assert not target.exists()
save=lambda:target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');save()
data=GitArchiveSource(R,M)
probe=data/'FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.json';descriptor=json.loads(probe.read_text());raw=(data/descriptor['archive']).read_bytes();assert len(raw)==descriptor['bytes'] and SHA(raw)==descriptor['sha256']
exe=W/'frost-undrained-state08-initialization-probe-O0-v1/corrected-module-import-v2/original_initialization_probe.exe';member='phase-driver/corrected-module-import-v2/original_initialization_probe.exe'
with zipfile.ZipFile(io.BytesIO(raw)) as z:assert exe.read_bytes()==z.read(member) and SHA(exe.read_bytes())==descriptor['members'][member]['sha256']=='dee4a94a5e0e92d07c9aee2a4790fc5178f159f7e81ad316fcaa58b6a6f28b5e'
record['actual_original_zero_day_probe']=dict(original_source='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d',executable_sha256=SHA(exe.read_bytes()),accepted_archive=descriptor['archive'],archive_sha256=descriptor['sha256'],O0_driver_with_original_mixed_SDK=True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
with ExitStack() as stack:
    store=Archive(data,'INITIAL_PROFILE_CALENDAR_WINDOWS_RAW_V1',stack)
    original_frontend=store.get('profiles/initial-profile-calendar-frontend-v1/RESULT.json')
    (root/'ORIGINAL_FRONTEND_RESULT.json').write_bytes(original_frontend)
    record['original_frontend_report_sha256']=SHA(original_frontend)
    for base,initial in names:
        name=base+'-initial'+str(initial)
        prefix='profiles/initial-profile-calendar-frontend-v1/'+name+'/'
        original={n[len(prefix):]:store.get(n) for n in store.names if n.startswith(prefix)}
        assert original and 'swap.swp' in original
        folder=root/name;folder.mkdir()
        for n,raw in original.items():
            path=folder/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
        text=original['swap.swp'].decode('cp1252');assert re.search(r'(?mi)^\s*SWINCO\s*=\s*'+str(initial)+r'\s*(?:!.*)?$',text)
        for key,value in [('SWDRA',0),('SWBOTB',6),('SWKIMPL',1)]:text=assignment(text,key,value)
        (folder/'swap.swp').write_bytes(text.encode('cp1252'))
        inputs={p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=SHA(p.read_bytes())) for p in folder.rglob('*') if p.is_file()}
        item=dict(case=name,original_archive_at=M,original_archive=store.record['archive'],original_archive_sha256=store.record['sha256'],original_input_prefix=prefix,original_input_members={n:dict(bytes=len(raw),sha256=SHA(raw)) for n,raw in original.items()},declared_selector_changes=dict(SWDRA=0,SWBOTB=6,SWKIMPL=1),original_initialization_selector_unchanged=initial,physical_parameters_profiles_forcing_output_controls_and_dates_unchanged=True,input_root=str(folder),prepared_members=inputs)
        try:
            project=load(folder,original_output=True);item['actual_frontend']='ACCEPTED_DESCRIPTOR';item['current_closed_default_selection']=selection(project)
            try:item['actual_output_metadata']=metadata(project);item['actual_output_owner']='ACCEPTED'
            except Exception as error:item['actual_output_owner']='REFUSED';item['actual_output_error']=repr(error)
        except Exception as error:item['actual_frontend']='REFUSED';item['actual_frontend_error']=repr(error)
        child=subprocess.run([str(exe),'./swap.swp'],cwd=folder,env=env,capture_output=True,timeout=30)
        (folder/'original-zero-day.stdout').write_bytes(child.stdout);(folder/'original-zero-day.stderr').write_bytes(child.stderr)
        item['actual_original_zero_day']=dict(returncode=child.returncode,accepted=b'ORIGINAL_INIT_PHASE AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS' in child.stdout,stdout_sha256=SHA(child.stdout),stderr_sha256=SHA(child.stderr),model_days=0)
        for n,v in inputs.items():assert SHA((folder/n).read_bytes())==v['sha256']
        record['contexts'].append(item);save();print(name,item['actual_frontend'],item.get('actual_output_owner'),item['actual_original_zero_day']['accepted'],flush=True)
assert len(record['contexts'])==6
assert all(v['actual_original_zero_day']['accepted'] and v['actual_original_zero_day']['returncode']==0 for v in record['contexts'])
record['status']='SIX_ORIGINAL_JOINT_IMPLICIT_HISTORY_INITIAL12_ZERO_DAY_CONTROLS_AND_ACTUAL_M15_ADAPTER_RESULTS_RETAINED_NOT_QUALIFIED';save()
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
print(record['status'],flush=True)
