"""Retain original scientific push APIs, logs and unchanged artifact ZIP bytes."""
from pathlib import Path,PurePosixPath
import hashlib,io,json,os,re,subprocess,urllib.request,urllib.error,urllib.parse,zipfile
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
C='e8da5a5e30d28c74a41d57ddbfe3c44390a2a8af';PREFIX='CLOSED_JOINT_HISTORY_STATE16_';SHA=lambda b:hashlib.sha256(b).hexdigest()
RUNS={46075802361:('UBUNTU',433205693),46075802339:('WINDOWS',433205692)}
target=E/(PREFIX+'ORIGINAL_PORTABLE_CI_CUSTODY_V1.json')
record=json.loads(target.read_text()) if target.exists() else dict(status='CAPTURING_ORIGINAL_PORTABLE_EVIDENCE_NOT_QUALIFIED',actual_scientific_producer=C,runs=[],jobs=[],artifacts=[],original_bytes_normalized=False)
assert record['actual_scientific_producer']==C
p=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),check=True,timeout=30)
fields=dict(v.split('=',1) for v in p.stdout.decode().splitlines() if '=' in v)
headers={'Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','Accept-Encoding':'identity','Cache-Control':'no-cache','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-joint-history-scientific-evidence'}
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect)
def fetch(path):
    try:
        with opener.open(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=90) as f:return f.read()
    except urllib.error.HTTPError as error:
        if error.code not in [301,302,303,307,308]:raise
        url=error.headers['Location'];q=urllib.parse.urlsplit(url)
        assert q.scheme=='https' and (q.hostname.endswith('.blob.core.windows.net') or q.hostname.endswith('.actions.githubusercontent.com'))
        # Signed download URLs and credentials are never emitted or persisted.
        with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept-Encoding':'identity'}),timeout=120) as f:return f.read()
def once(name,raw):
    p=E/name
    if p.exists():assert p.read_bytes()==raw
    else:
        with p.open('xb') as f:f.write(raw)
save=lambda:target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
active=[]
for run_id,(platform,workflow) in RUNS.items():
    if any(v['run_id']==run_id for v in record['runs']):continue
    runraw=fetch('actions/runs/'+str(run_id));run=json.loads(runraw)
    assert run['id']==run_id and run['head_sha']==C and run['event']=='push' and run['workflow_id']==workflow
    jobsraw=fetch('actions/runs/'+str(run_id)+'/jobs?per_page=100');jobs=json.loads(jobsraw)
    assert jobs['total_count']==len(jobs['jobs'])==2
    if run['status']!='completed':
        active.append(dict(run_id=run_id,platform=platform,jobs=[dict(id=v['id'],name=v['name'],status=v['status'],conclusion=v['conclusion']) for v in jobs['jobs']]))
        continue
    assert all(v['status']=='completed' and v['head_sha']==C for v in jobs['jobs'])
    stem=PREFIX+'FIRST_'+platform
    once(stem+'_RUN_ORIGINAL_API_V1.json',runraw);once(stem+'_JOBS_ORIGINAL_API_V1.json',jobsraw)
    for job in jobs['jobs']:
        assert job['run_id']==run_id
        opt=re.fullmatch(r'qualify \((O[02])\)',job['name'])[1]
        log=fetch('actions/jobs/'+str(job['id'])+'/logs');log.decode('utf8',errors='strict');assert not log.startswith(b'PK')
        jobraw=fetch('actions/jobs/'+str(job['id']));official=json.loads(jobraw)
        assert official['id']==job['id'] and official['head_sha']==C and official['status']=='completed' and official['run_id']==run_id
        name=stem+'_'+opt+'_ORIGINAL_CI_V1.log';once(name,log);once(stem+'_'+opt+'_JOB_ORIGINAL_API_V1.json',jobraw)
        record['jobs'].append(dict(run_id=run_id,job_id=job['id'],platform=platform,optimization=opt,actual_scientific_producer=C,conclusion=official['conclusion'],log=name,bytes=len(log),sha256=SHA(log)));save()
    araw=fetch('actions/runs/'+str(run_id)+'/artifacts?per_page=100');artifacts=json.loads(araw)
    assert artifacts['total_count']==len(artifacts['artifacts'])==2
    once(stem+'_ARTIFACTS_ORIGINAL_API_V1.json',araw)
    for artifact in artifacts['artifacts']:
        match=re.fullmatch('closed-joint-history-calendar-state16-'+('windows-' if platform=='WINDOWS' else '')+'(O[02])-'+C,artifact['name']);assert match and not artifact['expired'];opt=match[1]
        job=next(v for v in jobs['jobs'] if v['name']=='qualify ('+opt+')')
        raw=fetch('actions/artifacts/'+str(artifact['id'])+'/zip');assert len(raw)==artifact['size_in_bytes'] and artifact['digest']=='sha256:'+SHA(raw)
        name=stem+'_'+opt+'_ORIGINAL_V1';once(name+'.zip',raw);members={}
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            assert len(z.namelist())==len(set(z.namelist())) and z.testzip() is None
            for member in z.namelist():
                path=PurePosixPath(member);assert not path.is_absolute() and '..' not in path.parts and ':' not in member
                value=z.read(member);members[member]=dict(bytes=len(value),sha256=SHA(value))
        parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))]
        if len(raw)>48*1024**2:
            parts=[]
            for number,start in enumerate(range(0,len(raw),48*1024**2),1):
                value=raw[start:start+48*1024**2];filename=name+f'.zip.part{number:03d}';once(filename,value);parts.append(dict(file=filename,bytes=len(value),sha256=SHA(value)))
            assert b''.join((E/v['file']).read_bytes() for v in parts)==raw
        descriptor=dict(status='ORIGINAL_OFFICIAL_SCIENTIFIC_ARTIFACT_ZIP_DIGEST_CRC_AND_ALL_MEMBER_BYTES_VERIFIED_NOT_INDEPENDENT_QUALIFICATION',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_producer=C,run_id=run_id,job_id=job['id'],artifact_id=artifact['id'],platform=platform,optimization=opt,official_artifact_digest=artifact['digest'],original_bytes_normalized=False,canonical_admission=False)
        once(name+'.json',(json.dumps(descriptor,indent=2)+'\n').encode())
        record['artifacts'].append({k:v for k,v in descriptor.items() if k not in ['members','parts']});save();print('ORIGINAL_ARTIFACT_ZIP_VERIFIED',platform,opt,artifact['id'],len(raw),SHA(raw),len(members),flush=True)
    record['runs'].append(dict(run_id=run_id,workflow_id=workflow,platform=platform,actual_scientific_producer=C,conclusion=run['conclusion']));save()
record['active_runs']=active;record['status']='ALL_ORIGINAL_PORTABLE_EVIDENCE_CAPTURED_NOT_INDEPENDENT_QUALIFICATION' if len(record['runs'])==2 else 'PARTIAL_ORIGINAL_PORTABLE_EVIDENCE_CAPTURE_ACTIVE_RUNS_PENDING';save()
print(record['status'],len(record['runs']),len(record['jobs']),len(record['artifacts']),json.dumps(active),flush=True)
