* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-28 00:23:14

Period             :  1900-01-01  until  2002-02-04 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :          NaN cm              NaN mg/cm2
Initial :        18.28 cm       0.1788E+00 mg/cm2
            =============       =================
Change             NaN cm              NaN mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :     1.40    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.00
                             Crack flux        :     0.00
=========================    ============================
Sum            :     3.80    Sum               :     0.00


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :         NaN
Irrigation  :  0.1920E+01    Root uptake    :         NaN
Bottom flux :         NaN
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :         NaN    Sum            :         NaN

