"""Preserve new raw observations once, with exact immutable inherited input refs."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';M='bd9b3b2e74e93fccb8bbcc8b06822efcd740f349'
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from analytical_hydraulic_archives import Archive
from frost_boundary_git_archive import GitArchiveSource
SHA=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all','--ignored'],cwd=R)
name='CLOSED_REFERENCE_STATE17_ORIGINAL_CSV_AND_FULL_CAUSAL_RAW_V1';dest=E/(name+'.zip');assert not dest.exists()
files={};inherited={};reports={}
with ExitStack() as stack:
 old=Archive(GitArchiveSource(R,M),'CLOSED_GARDNER_STATE12_REPAIRED_LOCAL_AND_POSTIMAGES_RAW_V1',stack)
 for directory,report_names in [('closure17-reference-csv-lifecycle-v1',['RESULT.json']),('closure17-reference-csv-lifecycle-v2',['RESULT.json']),('closure17-reference-csv-lifecycle-v3',['RESULT.json']),('closure17-reference-accepted-v1',['zero-day-RESULT.json','full-period-RESULT.json'])]:
  root=E/directory
  for report_name in report_names:
   q=json.loads((root/report_name).read_text());reports[directory+'/'+report_name]=q
   for item in q['observations']:
    run=Path(item.get('actual_root',item.get('actual_observation_root',str(root/(item['optimization']+'-'+item['mode']+'-'+item['case']))))) if 'mode' in item else Path(item['actual_root'])
    prefix='actual/closure12-original-causal-v1/'+item['case']+'/'
    for filename,digest in item['input_inventory'].items():
     f=run/filename;raw=f.read_bytes();assert SHA(raw)==digest and old.get(prefix+filename)==raw
     inherited['observations/'+f.relative_to(E).as_posix()]=dict(archive='CLOSED_GARDNER_STATE12_REPAIRED_LOCAL_AND_POSTIMAGES_RAW_V1',archive_sha256=old.record['sha256'],git_source=M,member=prefix+filename,bytes=len(raw),sha256=digest)
  for f in root.rglob('*'):
   if f.is_file():
    member='observations/'+f.relative_to(E).as_posix()
    if member not in inherited:files[member]=f.read_bytes()
 for directory in ['closure17-reference-csv-O0-v1','closure17-reference-csv-O2-v1','closure17-reference-accepted-O0-v1','closure17-reference-accepted-O2-v1']:
  for f in (W/directory).rglob('*'):
   if f.is_file():files['builds/'+directory+'/'+f.relative_to(W/directory).as_posix()]=f.read_bytes()
 for path in ['tests/nomacro_drainage/closed_reference_csv_lifetime_probe.py','tests/nomacro_drainage/closed_reference_accepted_binary_probe.py']:
  for revision in ['07379e70e3','eaf1b20e79','0f3682b03b',head]:
   result=subprocess.run(['git','show',revision+':'+path],cwd=R,capture_output=True)
   if result.returncode==0:files['controller-source/'+revision+'/'+Path(path).name]=result.stdout
 for filename in ['CLOSED_REFERENCE_STATE17_ORIGINAL_FAULT_SYMBOL_DISCOVERY_V1.json','CLOSED_REFERENCE_STATE17_ORIGINAL_SYMBOLS_V1.txt',Path(__file__).name]:files['source/'+filename]=(E/filename).read_bytes()
 files['inherited-input-member-references.json']=(json.dumps(inherited,indent=2)+'\n').encode()
 files['original-controller-refusals.json']=(json.dumps(dict(first='07379e70e3 initial controller omitted fixed-irrigation.irg; original reader stopped before initialization, not scientific failure.',second='eaf1b20e79 parser assumed integers at byte0; original binary writehead emits five fixed80-character records. Actual model3 candidate process completed; only validator refused.',recovery='0f3682b03b reused all completed unchanged builds and four complete-input observations, parsed actual header at offset400. No hidden model-period replay or original result relabelling.'),indent=2)+'\n').encode()
 members={}
 with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,raw in sorted(files.items()):z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw))
 with zipfile.ZipFile(dest) as z:
  assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
  for n,d in members.items():raw=z.read(n);assert len(raw)==d['bytes'] and SHA(raw)==d['sha256'] and raw==files[n]
 raw=dest.read_bytes();assert len(raw)<48*1024**2
 q=dict(status='RAW_ORIGINAL_CSV_FAILURES_DIAGNOSTIC_ALTERNATIVE_EXISTING_CORRECTION_AND_SIX_FULL_REFERENCE_OBSERVATIONS_PRESERVED',actual_packaging_observer=head,archive=dest.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=dest.name,bytes=len(raw),sha256=SHA(raw))],members=members,inherited_input_members=len(inherited),unique_original_input_bytes_not_duplicated=True,original_provider='J_windows_provider',original_SDK_once_in='CLOSED_DEFAULT_CALENDAR_STATE14_ORIGINAL_MIXED_J_SDK_RAW_V5',original_SDK_is_mixed_compiler_profiles=True,physical_O0_O2_recompilation_claimed=False,existing_output_correction='NOMACRO-BINARY-OUTPUT-01',original_scientific_failures_relabelled=False,scientific_equivalence='NOT_QUALIFIED',qualified_B1_snapshot=False,whole_functional_completion='PARTIAL',global_counts='UNKNOWN',RC3_changed=False)
 (E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n')
 for n in [name+'.zip',name+'.json']:assert not (P/n).exists();(P/n).write_bytes((E/n).read_bytes())
 print('SEALED_ACTUAL17_RAW',len(raw),SHA(raw),len(members),len(inherited),flush=True)
