* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 06:53:37

Period             :  1900-01-01  until  2002-01-10 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.29 cm
Initial :        75.76 cm
            =============
Change            0.53 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     0.00    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     1.20
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.01
                             Crack flux        :     0.00
                             Drainage level 1  :     0.66
=========================    ============================
Sum            :     1.20    Sum               :     0.67
