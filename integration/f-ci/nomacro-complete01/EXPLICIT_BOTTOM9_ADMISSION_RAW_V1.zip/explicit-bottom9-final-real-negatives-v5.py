"""Real one-file committed+pushed negative descendants in the existing clean45 baseline."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
N=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent
CANDIDATE='67d2636672921505ecb47f1c9f4c6ea27a451889';git=lambda *args:subprocess.check_output(['git',*args],cwd=N,text=True).strip()
prepared=json.loads((E/'EXPLICIT_BOTTOM9_NEGATIVE_BASE_CLEAN45_PREPARATION_V4.json').read_text());assert prepared['candidate']==CANDIDATE and prepared['patterns']==45
inputs=prepared['preserved_input_bytes'];assert len(inputs)==33
assert git('rev-parse','HEAD')==CANDIDATE and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
record=E/'EXPLICIT_BOTTOM9_FINAL_NEGATIVES_OBSERVE_V4.json';assert not record.exists();q=dict(status='RUNNING',candidate=CANDIDATE,controls=[],never_merge=True,compiler_executions=0,model_executions=0)
def save():record.write_text(json.dumps(q,indent=2)+'\n')
def mutation(role,raw):
 if role=='SOURCE':
  old=b'if(abs(hybrid_output_trial_residual())>1d-10)flnonconv=.true.';assert raw.count(old)==1
  return raw.replace(old,old.replace(b'1d-10',b'2d-10'),1),dict(exact_unique_source_expression=old.decode(),replacement_guard='2d-10')
 if role in ('RAW','INHERITED'):
  offset=len(raw)//2;value=bytearray(raw);value[offset]^=1
  return bytes(value),dict(offset=offset,xor_hex='01',old_byte=raw[offset],new_byte=value[offset])
 assert role=='PUBLICATION';return raw+b'\n# NEVER_MERGE explicit9 actual publication-dependency negative control.\n',dict(append_only_comment=True)
save()
try:
 for role,path in [('SOURCE','app/hybrid_water/prescribed_head_flux_boundary.py'),('RAW','integration/f-ci/nomacro-complete01/EXPLICIT_BOTTOM9_CDE_UBUNTU_DRAIN_O0_RAW_V1.zip'),('INHERITED','integration/f-ci/nomacro-complete01/INITIAL_PROFILE_FROST_ADMISSION_RAW_V1.zip'),('PUBLICATION','tests/publication/run_pub_p2e09_reference_threshold_freeze.sh')]:
  branch='codex/nomacro-explicit-bottom9-negative-'+role.lower()+'02'
  assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
  subprocess.run(['git','switch','--detach',CANDIDATE],cwd=N,check=True,capture_output=True,text=True)
  file=(N/path).resolve();assert file.is_relative_to(N.resolve()) and file.is_file() and not file.is_symlink();before=file.read_bytes();bad,recipe=mutation(role,before)
  if role=='SOURCE':
   previous=json.loads((E/'EXPLICIT_BOTTOM9_FINAL_NEGATIVES_OBSERVE_V2.json').read_text())['controls'][0];head=previous['head'];assert head=='58b8de23195d52d3f27f2eebfe524d376f4b24a5' and git('ls-remote','origin','refs/heads/'+branch).split()[0]==head
   assert hashlib.sha256(before).hexdigest()==previous['actual_original_file_sha256'] and hashlib.sha256(bad).hexdigest()==previous['actual_mutated_file_sha256']
   subprocess.run(['git','switch','--detach',head],cwd=N,check=True,capture_output=True,text=True);assert file.read_bytes()==bad
   (E/('EXPLICIT_BOTTOM9_FINAL_'+role+'_NEGATIVE_PUSH_V4.stdout.txt')).write_text('Existing exact committed and pushed source-negative02 '+head+' reused without amendment; remote identity freshly verified.\n');(E/('EXPLICIT_BOTTOM9_FINAL_'+role+'_NEGATIVE_PUSH_V4.stderr.txt')).write_text('')
  else:
   assert not git('ls-remote','--heads','origin','refs/heads/'+branch),'Never replace an existing remote control'
   existing=subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=N)
   if existing.returncode==0:
    assert role=='RAW' and git('rev-parse','refs/heads/'+branch)==CANDIDATE
    subprocess.run(['git','switch',branch],cwd=N,check=True,capture_output=True,text=True)
   else:subprocess.run(['git','switch','-c',branch],cwd=N,check=True,capture_output=True,text=True)
   file.write_bytes(bad);subprocess.run(['git','add','--',path],cwd=N,check=True,capture_output=True,text=True)
   subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','NEVER MERGE explicit9 '+role.lower()+' negative against final67 actual216 candidate'],cwd=N,check=True,capture_output=True,text=True);head=git('rev-parse','HEAD')
   pushed=subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],cwd=N,capture_output=True,text=True,timeout=180);(E/('EXPLICIT_BOTTOM9_FINAL_'+role+'_NEGATIVE_PUSH_V4.stdout.txt')).write_text(pushed.stdout);(E/('EXPLICIT_BOTTOM9_FINAL_'+role+'_NEGATIVE_PUSH_V4.stderr.txt')).write_text(pushed.stderr);pushed.check_returncode();assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==head
  assert git('show','-s','--format=%P',head)==CANDIDATE and git('diff','--name-only',CANDIDATE,head)==path and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
  for name,digest in inputs.items():assert hashlib.sha256((N/name).read_bytes()).hexdigest()==digest
  item=dict(role=role,path=path,branch=branch,head=head,exact_parent=CANDIDATE,actual_one_file_delta=True,actual_original_file_sha256=hashlib.sha256(before).hexdigest(),actual_mutated_file_sha256=hashlib.sha256(bad).hexdigest(),mutation_recipe=recipe,never_merge=True,status='ACTUAL_COMMITTED_PUSHED_PENDING_PUBLIC_REFUSAL');q['controls'].append(item);save()
  label='EXPLICIT_BOTTOM9_FINAL_'+role+'_NEGATIVE_PUBLIC_V4';command=[sys.executable,'-B',str(E/'EXPLICIT_BOTTOM9_PUBLIC_OBSERVE_V1.py'),'--cwd',str(N),'--output',str(E/label)];started=time.perf_counter();observed=subprocess.run(command,cwd=N,capture_output=True,text=True,timeout=2400)
  (E/(label+'-observer.stdout.txt')).write_text(observed.stdout);(E/(label+'-observer.stderr.txt')).write_text(observed.stderr);observed.check_returncode();receipt=json.loads((E/(label+'.json')).read_text());error=(E/(label+'.stderr.txt')).read_bytes()
  assert receipt['before']==receipt['after'] and receipt['before']['head']==head and len(receipt['before']['sparse'])==45 and receipt['returncode'] not in (None,0) and b'AssertionError'in error
  item.update(status='ACTUAL_COMMITTED_PUSHED_CLEAN45_PUBLIC_REFUSED',actual_refusal=True,actual_public_seconds=receipt['seconds'],actual_public_returncode=receipt['returncode'],actual_public_stderr_sha256=hashlib.sha256(error).hexdigest());save()
  if role=='PUBLICATION':
   result=subprocess.run([sys.executable,'-B','tests/nomacro_drainage/frost_publication_scope.py'],cwd=N,env=dict(os.environ,GITHUB_EVENT_NAME='pull_request'),capture_output=True,text=True,timeout=1800);(E/'EXPLICIT_BOTTOM9_FINAL_PUBLICATION_SCOPE_NEGATIVE_V4.stdout.txt').write_text(result.stdout);(E/'EXPLICIT_BOTTOM9_FINAL_PUBLICATION_SCOPE_NEGATIVE_V4.stderr.txt').write_text(result.stderr);assert result.returncode==0 and not result.stderr and 'PUBLICATION_REPLAY_SELECTED=true'in result.stdout;item['actual_publication_replay_selected']=True;save()
  print('ACTUAL_COMMITTED_PUSHED_CLEAN45_NEGATIVE_REFUSED',role,head,receipt['seconds'],flush=True)
 q['status']='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN45_PUBLIC_NEGATIVES_REFUSED'
except Exception as error:q.update(status='FAILED_ACTUAL_FINAL_NEGATIVE_CAMPAIGN_NOT_QUALIFIED',error=repr(error));raise
finally:save()
print(q['status'],flush=True)
