module MOD_integral

   use MOD_arrays, only: madr, macp
   use MOD_integral_global
   use hybrid_age_output_state
   
   implicit none

   ! interfaces to main entries of subroutine integral
   !!!interface
   !!!   subroutine integral(iTask)
   !!!      integer, intent(in) :: iTask
   !!!   end subroutine integral
   !!!end interface
    
   real(8), dimension(macp),      save ::   inqrot              ! Array with intermediate amounts of extracted water by roots for each compartment (L)
   real(8), dimension(macp+1),    save ::   inq                 ! Array with intermediate amounts of water flow between current and upper compartment (L)
   real(8), dimension(macp),      save ::   inqssdi             ! Array with intermediate amounts of subsurface drip irrigation for each compartment (L)
   real(8), dimension(macp),      save ::   inqpotrot           ! Array with intermediate amounts of potential extracted water by roots for each compartment (L)
   real(8), dimension(macp),      save ::   inqredrot           ! Array with intermediate amounts of reduction of extracted water by roots for each compartment in case of no compensation (L)
   real(8), dimension(macp+1),    save ::   iqdo, iqup
   
   real(8),                       save ::   iqrot               ! Intermediate amount of extracted water by roots (L)
   real(8),                       save ::   iqssdi              ! Intermediate amount of water input via subsurface drip irrigation (L)
   real(8),                       save ::   iqredwet            ! Intermediate amount of reduced root water extraction due to wet conditions (L)
   real(8),                       save ::   iqreddry            ! Intermediate amount of reduced root water extraction due to dry conditions (L)
   real(8),                       save ::   iqredsol            ! Intermediate amount of reduced root water extraction due to salt conditions (L)
   real(8),                       save ::   iqredfrs            ! Intermediate amount of reduced root water extraction due to frost conditions (L)
   real(8),                       save ::   iintc               ! Intermediate amount of evaporation from canopy (L)
   real(8),                       save ::   isintc              ! Intermediate amount of evaporation from canopy reservoir (L)
   real(8),                       save ::   iepd                ! Intermediate amount of ponding evaporation (L)
   real(8),                       save ::   ipeva               ! Intermediate amount of potential soil evaporation (L)
   real(8),                       save ::   iptra               ! Intermediate amount of potential transpiration (L)
   real(8),                       save ::   ievap               ! Intermediate amount of actual soil evaporation (L)
   real(8),                       save ::   iruno               ! Intermediate amount of runoff (L)
   real(8),                       save ::   irunon              ! Intermediate amount of runon (L)
   real(8),                       save ::   iqbot               ! Intermediate amount of water flow through bottom of simulated soil column (L)
   real(8),                       save ::   iqbdo,iqbup         ! Intermediate amount of water flow through bottom of simulated soil column (L)
   real(8),                       save ::   iqtdo,iqtup         ! Intermediate amount of water flow through top of simulated soil column (L)
   
   real(8),                       save ::   igrai               ! Intermediate amount of gross rainfall (L)
   real(8),                       save ::   inrai               ! Intermediate amount of net precipitation (L)
   real(8),                       save ::   igird               ! Intermediate depth of gross irrigation (L)
   real(8),                       save ::   inird               ! Intermediate depth of net irrigation (L)
  
!  Balance period (e.g. year) cumulative amounts; output, used in outbal, outblc
   
   real(8),                       save ::   cgrai               ! Cumulative amount of gross precipitation (L)
   real(8),                       save ::   cnrai               ! Cumulative amount of net precipitation (L)
   real(8),                       save ::   caintc              ! Cumulative amount of rainfall interception (L)
   real(8),                       save ::   cqrot               ! Cumulative amount of extracted water by roots (L)
   real(8),                       save ::   cqbot               ! Cumulative amount of water flow through bottom of simulated soil column (L)
   real(8),                       save ::   cqbotdo             ! Cumulative amount of water (L) passed through the soil column bottom in downward direction
   real(8),                       save ::   cqbotup             ! Cumulative amount of water (L) passed through the soil column bottom in upward direction
   real(8),                       save ::   cqssdi              ! Cumulative amount of subsurface drip irrigation (L)
   real(8),                       save ::   cqtdo               ! Cumulative amount of water (L) passed through the soil surface in downward direction
   real(8),                       save ::   cqtup               ! Cumulative amount of water (L) passed through the soil surface in upward direction
   real(8),                       save ::   crunoff             ! Cumulative runoff (L)
   real(8),                       save ::   crunon              ! Cumulative amount of runon (L)
   real(8),                       save ::   cevap               ! Cumulative amount of actual soil evaporation (L)
   real(8),                       save ::   cepd                ! Cumulative amount of ponding evaporation (L)
   real(8),                       save ::   cpeva               ! Cumulative amount of potential soil evaporation (L)
   real(8),                       save ::   cptra               ! Cumulative amount of potential transpiration (L)
   real(8),                       save ::   cinund              ! Cumulative amount of inundation (L)
   real(8),                       save ::   cqprai              ! Cumulative amount of net rain (L)
   real(8),                       save ::   cgird               ! Cumulative amount of gross irrigation (L)
   real(8),                       save ::   cnird               ! Cumulative amount of net irrigation (L)

   ! for drainage and/or surfacewater
   real(8),                       save ::   cqdra              ! Cumulative amount of lateral drainage (L)
   real(8), dimension(madr),      save ::   cqdrain            ! Cumulative amount of lateral drainage for each drainage level (L)
   real(8), dimension(madr),      save ::   cqdrainin          ! Cumulative infiltration flux (L) for each drainage level
   real(8), dimension(madr),      save ::   cqdrainout         ! Cumulative drainage flux (L) for each drainage level
   real(8), dimension(madr,macp), save ::   inqdra             ! Array with intermediate amounts of lateral drainage for each level and compartment (L)
   real(8), dimension(madr,macp), save ::   inqdra_in, inqdra_out
   real(8),                       save ::   iqdra              ! Intermediate amount of lateral drainage (L)

   ! snow
   real(8),                       save ::   cgsnow              ! Cumulative amount of gross snow fall (L water)
   real(8),                       save ::   cmelt               ! Cumulative amount of melted snow (L water)
   real(8),                       save ::   csnrai              ! Cumulative amount of net snow fall (L water)
   real(8),                       save ::   csubl               ! Cumulative amount of sublimated snow (L water)
   real(8),                       save ::   isnrai              ! Incremental amount of net snow fall (L water)
   real(8),                       save ::   igsnow              ! Incremental amount of gross snow fall (L water)
   real(8),                       save ::   isubl               ! Incremental amount of sublimated snow (L water)

   public

   contains

! File VersionID:
!   $Id: integral.f90 341 2017-09-29 18:12:25Z kroes006 $
! ----------------------------------------------------------------------
      subroutine integral(iTask)
! ----------------------------------------------------------------------
!     Date:    November 2004
!     Purpose: calculation of intermediate and cumulative fluxes
! ----------------------------------------------------------------------
      use plant_interface, only: noddrz, ipgass, igass, imres, ipgasspot, igasspot, imrespot, sw_inter, sicact, siccap, crsflx_in, crsflx_out, siccaploss
      use MOD_grid,        only: numnod
      use MOD_swap_base,   only: swsnow, swdra, swmacro
      use MOD_meteo,       only: peva, ptra, graidt, nraidt, aintcdt
      use MOD_snow,        only: gsnow, melt, subl, snrai, snowinco, ssnow
      use MOD_drain,       only: qdrtot, nrlevs, qdra, qdrain
      use MOD_irrigation,  only: qssdisum, qssdi, gird, nird
      use MOD_macropore,   only: macropore
      use variables,       only: flzerocumu, flzerointr, fldaystart, dt, epd, reva, qbot, qrot, runots,runon, q, volini, volact, pondini, pond, theta, ivolbeg, ipondbeg, issnowbeg, isicbeg, ithetabeg
      use MOD_re_global,   only: qpotrot, qredwetsum, qreddrysum, qredsolsum, qredfrssum, qrosum, qredwet, qreddry, qredsol, qredfrs, qredrwu, alpwetnoddrz, alpdrynodrtz
      implicit none
!     global
      integer, intent(in) :: iTask

! --- local variables
      integer node,level
      real(8) qrotts,qdrats,ptrats,epdts,pevats,revats,qbotts
      real(8)::hybrid_receipt_increment
      integer::hybrid_receipt_status
! ----------------------------------------------------------------------

   select case(iTask)

   case (1,2)   ! initialization or resets
      
      if (iTask == 1 .OR. fldaystart) then

          iqrot_day = 0.d0
          iqreddry_day = 0.d0
          iqredsol_day = 0.d0
          iptra_day = 0.d0
          do node = 1,numnod 
            inqpotrot_day(node) = 0.d0
            inqredrot_day(node) = 0.d0
          end do
          
          ialpwet_day = 0.d0
          ialpdry_day = 0.d0
      
      end if

      if (iTask == 1 .OR. flzerocumu) then

         cgrai   = 0.0d0
         cnrai   = 0.0d0
         cgird   = 0.0d0
         cnird   = 0.0d0
         caintc  = 0.0d0
         cqrot   = 0.0d0
         cqbot   = 0.0d0
         cqbotdo = 0.0d0
         cqbotup = 0.0d0
         cqtdo   = 0.0d0 
         cqtup   = 0.0d0
         cqssdi  = 0.0d0
         crunoff = 0.0d0
         crunon  = 0.0d0 
         cptra   = 0.0d0
         cepd    = 0.0d0
         cpeva   = 0.0d0
         cevap   = 0.0d0
         cinund  = 0.0d0
         cqprai  = 0.0d0
         if (swdra > 0) then
            cqdra = 0.0d0
            do level = 1, nrlevs
               cqdrain(level)    = 0.0d0
               cqdrainin(level)  = 0.0d0
               cqdrainout(level) = 0.0d0
           end do
         end if
         if (swsnow == 1) then
            cgsnow = 0.0d0
            csubl  = 0.0d0
            csnrai = 0.0d0
            cmelt  = 0.0d0
         end if
         
         volini   = volact
         pondini  = pond
         snowinco = ssnow
!         sicini   = sicact
         
         if (swmacro == 1) call macropore(6)
         
      end if

      if (iTask == 1 .OR. flzerointr) then

         igrai = 0.0d0
         inrai = 0.0d0
         igird = 0.0d0
         inird = 0.0d0
         do node = 1, numnod
            inqrot(node)    = 0.0d0
            inqpotrot(node) = 0.0d0
            inqredrot(node) = 0.0d0
            inqssdi(node)   = 0.0d0
            inq(node)       = 0.0d0
         end do
         inq(numnod+1)    = 0.0d0
         iqrot            = 0.0d0
         iqssdi           = 0.0d0
         iqredwet         = 0.0d0
         iqreddry         = 0.0d0
         iqredsol         = 0.0d0
         iqredfrs         = 0.0d0
         iintc            = 0.0d0
         isintc           = 0.0d0
         iptra            = 0.0d0
         iepd             = 0.0d0
         ipeva            = 0.0d0
         ievap            = 0.0d0
         iruno            = 0.0d0
         iqbot            = 0.0d0
         iqbdo            = 0.0d0
         iqbup            = 0.0d0
         iqtdo            = 0.0d0
         iqtup            = 0.0d0
         irunon           = 0.0d0
         iqdo(1:numnod+1) = 0.0d0
         iqup(1:numnod+1) = 0.0d0
         if (swdra > 0) then
            do node = 1,numnod
               do level = 1,nrlevs
                  inqdra(level,node)     = 0.0d0
                  inqdra_in(level,node)  = 0.0d0
                  inqdra_out(level,node) = 0.0d0
               end do
            end do
            iqdra = 0.0d0
         end if
         if (swsnow == 1) then
            igsnow = 0.0d0
            isubl  = 0.0d0
            isnrai = 0.0d0
         end if
         
         ipgass= 0.d0; ipgasspot= 0.d0
         igass = 0.d0; igasspot = 0.d0
         imres = 0.d0; imrespot = 0.d0
         
         ivolbeg   = volact
         ipondbeg  = pond
         issnowbeg = ssnow
         isicbeg   = sicact
         do node = 1, numnod
            ithetabeg(node) = theta(node)
         end do
         
         if (swmacro == 1) call macropore(5)
         
      end if

   case (3)  ! perform integrations

! --- potential transpiration of this timestep
      ptrats = ptra * dt

! --- ponding evaporation of this timestep
      epdts = epd * dt
      
! --- potential soil evaporation of this timestep
      pevats = peva * dt

! --- reduced soil evaporation of this timestep
      revats = reva * dt

! --- flux lower boundary of this timestep
      qbotts = qbot*dt

! --- total root extraction of this timestep
      qrotts = qrosum * dt

! --- total drainage flux of this timestep
      qdrats = qdrtot * dt

! --- add time step fluxes to intermediate totals
      hybrid_receipt_increment=qrotts
      iqrot=iqrot+hybrid_receipt_increment
      if(hybrid_output_frame%active)then
       call observe_output_increment(hybrid_output_frame,10,hybrid_receipt_increment,hybrid_receipt_status)
       if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
      end if
      do node = 1,noddrz
        inqrot(node)        = inqrot(node) + qrot(node) * dt
        inqpotrot(node)     = inqpotrot(node) + qpotrot(node) * dt
        inqredrot(node)     = inqredrot(node) + (qredwet(node) + qreddry(node) + qredsol(node) + qredfrs(node) + qredrwu(node)) * dt
        inqpotrot_day(node) = inqpotrot_day(node) + qpotrot(node) * dt
        inqredrot_day(node) = inqredrot_day(node) + (qredwet(node) + qreddry(node) + qredsol(node) + qredfrs(node) + qredrwu(node)) * dt
      end do
      do node = 1,numnod
        inqssdi(node) = inqssdi(node) + qssdi(node) * dt
        hybrid_receipt_increment=qssdi(node) * dt
        iqssdi=iqssdi+hybrid_receipt_increment
        if(hybrid_output_frame%active)then
         call observe_output_increment(hybrid_output_frame,6,hybrid_receipt_increment,hybrid_receipt_status)
         if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
        end if
      end do
      iqredwet     = iqredwet + qredwetsum*dt
      iqreddry     = iqreddry + qreddrysum*dt
      iqredsol     = iqredsol + qredsolsum*dt
      iqredfrs     = iqredfrs + qredfrssum*dt
      iqreddry_day = iqreddry_day + qreddrysum*dt
      iqredsol_day = iqredsol_day + qredsolsum*dt
      iqrot_day    = iqrot_day + qrotts
      iptra_day    = iptra_day + ptra * dt
      
      ialpwet_day = ialpwet_day + alpwetnoddrz * dt
      ialpdry_day = ialpdry_day + alpdrynodrtz * dt

      if (sw_inter /= 3) then
         hybrid_receipt_increment=aintcdt * dt
         iintc=iintc+hybrid_receipt_increment
         if(hybrid_output_frame%active)then
          call observe_output_increment(hybrid_output_frame,8,hybrid_receipt_increment,hybrid_receipt_status)
          if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
         end if
      else
         hybrid_receipt_increment=crsflx_out * dt
         iintc=iintc+hybrid_receipt_increment
         if(hybrid_output_frame%active)then
          call observe_output_increment(hybrid_output_frame,8,hybrid_receipt_increment,hybrid_receipt_status)
          if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
         end if
      end if

      iptra  = iptra + ptrats
      hybrid_receipt_increment=epdts
      iepd=iepd+hybrid_receipt_increment
      if(hybrid_output_frame%active)then
       call observe_output_increment(hybrid_output_frame,11,hybrid_receipt_increment,hybrid_receipt_status)
       if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
      end if
      ipeva  = ipeva + pevats
      hybrid_receipt_increment=revats
      ievap=ievap+hybrid_receipt_increment
      if(hybrid_output_frame%active)then
       call observe_output_increment(hybrid_output_frame,12,hybrid_receipt_increment,hybrid_receipt_status)
       if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
      end if
      hybrid_receipt_increment=runots
      iruno=iruno+hybrid_receipt_increment
      if(hybrid_output_frame%active)then
       call observe_output_increment(hybrid_output_frame,9,hybrid_receipt_increment,hybrid_receipt_status)
       if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
      end if
      hybrid_receipt_increment=runon*dt
      irunon=irunon+hybrid_receipt_increment
      if(hybrid_output_frame%active)then
       call observe_output_increment(hybrid_output_frame,5,hybrid_receipt_increment,hybrid_receipt_status)
       if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
      end if
      hybrid_receipt_increment=graidt*dt
      igrai=igrai+hybrid_receipt_increment
      if(hybrid_output_frame%active)then
       call observe_output_increment(hybrid_output_frame,1,hybrid_receipt_increment,hybrid_receipt_status)
       if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
      end if
      hybrid_receipt_increment=gird*dt
      igird=igird+hybrid_receipt_increment
      if(hybrid_output_frame%active)then
       call observe_output_increment(hybrid_output_frame,4,hybrid_receipt_increment,hybrid_receipt_status)
       if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
      end if
      inrai  = inrai + nraidt*dt
      inird  = inird + nird*dt
      iqbot  = iqbot + qbotts
      if (qbotts < 0.0d0) then
         hybrid_receipt_increment=qbotts
         iqbdo=iqbdo-hybrid_receipt_increment
         if(hybrid_output_frame%active)then
          call observe_output_increment(hybrid_output_frame,16,-hybrid_receipt_increment,hybrid_receipt_status)
          if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
         end if
      else if (qbotts > 0.0d0) then
         hybrid_receipt_increment=qbotts
         iqbup=iqbup+hybrid_receipt_increment
         if(hybrid_output_frame%active)then
          call observe_output_increment(hybrid_output_frame,7,hybrid_receipt_increment,hybrid_receipt_status)
          if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
         end if
      end if
      if (q(1) < 0.0d0) then
         iqtdo = iqtdo - q(1)*dt
      else
         iqtup = iqtup + q(1)*dt
      end if
      do node = 1, numnod+1
         if (q(node) < 0.0d0) then
            iqdo(node) = iqdo(node) - q(node)*dt
         else
            iqup(node) = iqup(node) + q(node)*dt
         end if
      end do

!      iQMaPo = iQMaPo +QMaPo*dt
! --- add time step fluxes to total cumulative values
      cqssdi = cqssdi + qssdisum*dt
      cqrot = cqrot + qrotts
      cqdra = cqdra + qdrats
      cptra = cptra + ptrats
      cepd = cepd + epdts
      cpeva = cpeva + pevats
      cevap = cevap + revats
      if (runots < 0.0d0) then
         cinund = cinund - runots
      else if (runots > 0.0d0) then
         crunoff = crunoff + runots
      end if

      if (sw_inter /= 3) then
         caintc  = caintc + aintcdt * dt
      else
         caintc  = caintc + crsflx_out * dt
      end if

      cgrai  = cgrai + graidt*dt
      cnrai  = cnrai + nraidt*dt
!      cnrai  = cgrai - caintc
      cgird  = cgird + gird*dt
      cnird  = cnird + nird*dt

      if (qbotts < 0.0d0) then
         cqbotdo = cqbotdo - qbotts
      else if (qbotts > 0.0d0) then
         cqbotup = cqbotup + qbotts
      end if
      cqbot = cqbot + qbotts

      ! rain on the ponding surface
      cqprai = cqprai + nraidt*dt    
      crunon = crunon + runon*dt     
      if (q(1) < 0.0d0) then
         cqtdo = cqtdo - q(1)*dt
      else if (q(1) > 0.0d0) then
         cqtup = cqtup + q(1)*dt
      end if

!     drainage
      if (swdra > 0) then
         hybrid_receipt_increment=qdrats
         iqdra=iqdra+hybrid_receipt_increment
         if(hybrid_output_frame%active)then
          call observe_output_increment(hybrid_output_frame,14,hybrid_receipt_increment,hybrid_receipt_status)
          if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
         end if
         do node = 1, numnod
            do level = 1, nrlevs
               inqdra(level,node) = inqdra(level,node)+qdra(level,node)*dt
               if (qdra(level,node) > 0.0d0) then
                  inqdra_out(level,node) = inqdra_out(level,node) + qdra(level,node)*dt
               else
                  inqdra_in(level,node)  = inqdra_in(level,node) - qdra(level,node)*dt
               end if
            end do
         end do
         do level = 1,nrlevs
            ! infiltration
            if (qdrain(level) < 0.0d0) then
               cqdrainin(level) = cqdrainin(level) - qdrain(level)*dt
            ! drainage
            else if (qdrain(level) > 0.0d0) then
               cqdrainout(level) = cqdrainout(level) + qdrain(level)*dt
            end if      
            cqdrain(level) = cqdrain(level) + qdrain(level)*dt
         end do
      end if

   ! snow
      if (swsnow == 1) then
         cgsnow = cgsnow + gsnow*dt
         csubl  = csubl  + subl*dt
         cmelt  = cmelt  + melt*dt
         csnrai = csnrai + snrai*dt
         igsnow = igsnow + gsnow*dt
         isubl  = isubl  + subl*dt
         isnrai = isnrai + snrai*dt
      end if
      
      ! interception canopy reservoir
      isintc = isintc  + (crsflx_in - crsflx_out) * dt
      sicact = min(max(0.d0, sicact + (crsflx_in - crsflx_out) * dt), siccap)

   case (4)  ! perform integrations after update crop development
      
      ! interception canopy reservoir
      hybrid_receipt_increment=siccaploss
      iintc=iintc+hybrid_receipt_increment
      if(hybrid_output_frame%active)then
       call observe_output_increment(hybrid_output_frame,8,hybrid_receipt_increment,hybrid_receipt_status)
       if(hybrid_receipt_status/=OUTPUT_RECEIPT_OK)error stop 'Original output increment observer rejected'
      end if
      caintc = caintc + siccaploss
      isintc = isintc - siccaploss
      siccaploss = 0.d0
      
   case default
      call swap_error ('integral', 'Illegal value for ITASK')
   end select

   return
   end subroutine integral


subroutine hybrid_output_day_begin()
use variables,only:volact,pond
use plant_interface,only:sicact
integer::status
call begin_output_receipt(hybrid_output_frame,[volact,pond,0d0,sicact,0d0,0d0],status)
if(status/=OUTPUT_RECEIPT_OK)error stop 'Original output daily frame begin rejected'
end subroutine
subroutine hybrid_output_calendar_checkpoint(unit,restoring)
use iso_fortran_env,only:int64
use ieee_arithmetic,only:ieee_is_finite
use MOD_grid,only:numnod
use MOD_drain,only:nrlevs
use MOD_arrays,only:maout
use MOD_timer,only:tcumold
use plant_interface,only:ipgass,igass,imres,ipgasspot,igasspot,imrespot,sicact
use variables,only:volact,pond,volini,pondini,ivolbeg,ipondbeg,issnowbeg,isicbeg,ithetabeg, &
 daycum,cntper,nprintcount,ioutdat,ioutdatint,period,nprintday,swres,outper,outdat,outdatint, &
 flzerocumu,flzerointr,floutput,floutputshort,flbaloutput,flheader,flprintshort,flprintdt,t1900
integer,intent(in)::unit
logical,intent(in)::restoring
integer::header(20),witness_header(20),ios,nreal
real(8),allocatable::values(:),witness(:)
nreal=(numnod)+(numnod+1)+(numnod)+(numnod)+(numnod)+(numnod+1)+(numnod+1)+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+(nrlevs)+(nrlevs)+(nrlevs)+(nrlevs)*(numnod)+(nrlevs)*(numnod)+(nrlevs)*(numnod)+1+(numnod)+(numnod)+1+1+1+1+1+1+1+1+1+1+1+1+(numnod)+(maout)+(maout)+1+1+1+1+1+1+1+1
if(restoring)then
 read(unit,iostat=ios)header,witness_header
 if(ios/=0)error stop 'Incomplete original output calendar header'
 if(any(header/=witness_header))error stop 'Original output calendar header witness mismatch'
 if(any(header(1:6)/=[1,numnod,nrlevs,nreal,period,nprintday]))error stop 'Foreign original output calendar shape/policy'
 if(header(12)/=swres.or.minval(header(7:11))<0)error stop 'Invalid original output calendar counters'
 if(nprintday>1)then
  if(int(header(9),int64)/=int(header(7),int64)*int(nprintday,int64)+1_int64) &
   error stop 'Inconsistent original global print counter'
 else
  if(header(9)/=1)error stop 'Invalid original annual print counter'
 end if
 if(period>0.and.header(8)>=period)error stop 'Invalid original schedule periodic counter'
 if(period==0.and.header(8)/=header(7))error stop 'Inconsistent original zero-period day counter'
 if(any(header(10:11)<1).or.any(header(10:11)>maout))error stop 'Invalid original output date pointers'
 if(any(header(13:20)<0).or.any(header(13:20)>1))error stop 'Invalid original output calendar flags'
 if(header(19)/=merge(1,0,nprintday>1).or.header(20)/=0)error stop 'Foreign original age output clock flags'
 allocate(values(nreal),witness(nreal));read(unit,iostat=ios)values,witness
 if(ios/=0)error stop 'Incomplete original output calendar values'
 if(.not.all(ieee_is_finite(values)))error stop 'Nonfinite original output calendar values'
 if(any(transfer(values,0_int64,nreal)/=transfer(witness,0_int64,nreal)))error stop 'Original output calendar value witness mismatch'
 if(values(nreal)<0d0)error stop 'Negative original output period'
 pending_header=header
 if(allocated(pending_values))deallocate(pending_values)
 call move_alloc(values,pending_values);output_restore_pending=.true.
else
 header=[1,numnod,nrlevs,nreal,period,nprintday,daycum,cntper,nprintcount,ioutdat,ioutdatint,swres, &
 merge(1,0,flzerocumu),merge(1,0,flzerointr),merge(1,0,floutput),merge(1,0,floutputshort), &
 merge(1,0,flbaloutput),merge(1,0,flheader),merge(1,0,flprintshort),merge(1,0,flprintdt)]
 allocate(values(nreal));values=[inqrot(1:numnod),inq(1:numnod+1),inqssdi(1:numnod),inqpotrot(1:numnod),inqredrot(1:numnod),iqdo(1:numnod+1),iqup(1:numnod+1),iqrot,iqssdi,iqredwet,iqreddry,iqredsol,iqredfrs,iintc,isintc,iepd,ipeva,iptra,ievap,iruno,irunon,iqbot,iqbdo,iqbup,iqtdo,iqtup,igrai,inrai,igird,inird,cgrai,cnrai,caintc,cqrot,cqbot,cqbotdo,cqbotup,cqssdi,cqtdo,cqtup,crunoff,crunon,cevap,cepd,cpeva,cptra,cinund,cqprai,cgird,cnird,cqdra,cqdrain(1:nrlevs),cqdrainin(1:nrlevs),cqdrainout(1:nrlevs),reshape(inqdra(1:nrlevs,1:numnod),[(nrlevs)*(numnod)]),reshape(inqdra_in(1:nrlevs,1:numnod),[(nrlevs)*(numnod)]),reshape(inqdra_out(1:nrlevs,1:numnod),[(nrlevs)*(numnod)]),iqdra,inqpotrot_day(1:numnod),inqredrot_day(1:numnod),iqrot_day,iqreddry_day,iqredsol_day,iptra_day,ialpwet_day,ialpdry_day,volini,pondini,ivolbeg,ipondbeg,issnowbeg,isicbeg,ithetabeg(1:numnod),outdat(1:maout),outdatint(1:maout),ipgass,igass,imres,ipgasspot,igasspot,imrespot,tcumold,outper]
 if(.not.all(ieee_is_finite(values)))error stop 'Cannot publish nonfinite original output calendar'
 write(unit)header,header,values,values
end if
end subroutine
subroutine hybrid_output_calendar_apply()
use iso_fortran_env,only:int64
use ieee_arithmetic,only:ieee_is_finite
use MOD_grid,only:numnod
use MOD_drain,only:nrlevs
use MOD_arrays,only:maout
use MOD_timer,only:tcumold
use plant_interface,only:ipgass,igass,imres,ipgasspot,igasspot,imrespot,sicact
use variables,only:volact,pond,volini,pondini,ivolbeg,ipondbeg,issnowbeg,isicbeg,ithetabeg, &
 daycum,cntper,nprintcount,ioutdat,ioutdatint,period,nprintday,swres,outper,outdat,outdatint, &
 flzerocumu,flzerointr,floutput,floutputshort,flbaloutput,flheader,flprintshort,flprintdt,t1900
integer::pos
if(.not.output_restore_pending)return
if(abs(t1900-original_output_start_clock-dble(pending_header(7)))>1d-8)error stop 'Foreign original output calendar day'
daycum=pending_header(7);cntper=pending_header(8);nprintcount=pending_header(9)
ioutdat=pending_header(10);ioutdatint=pending_header(11)
flzerocumu=pending_header(13)==1;flzerointr=pending_header(14)==1
floutput=pending_header(15)==1;floutputshort=pending_header(16)==1
flbaloutput=pending_header(17)==1;flheader=pending_header(18)==1
flprintshort=pending_header(19)==1;flprintdt=pending_header(20)==1
pos=1
inqrot(1:numnod)=pending_values(pos:pos+(numnod)-1);pos=pos+(numnod)
inq(1:numnod+1)=pending_values(pos:pos+(numnod+1)-1);pos=pos+(numnod+1)
inqssdi(1:numnod)=pending_values(pos:pos+(numnod)-1);pos=pos+(numnod)
inqpotrot(1:numnod)=pending_values(pos:pos+(numnod)-1);pos=pos+(numnod)
inqredrot(1:numnod)=pending_values(pos:pos+(numnod)-1);pos=pos+(numnod)
iqdo(1:numnod+1)=pending_values(pos:pos+(numnod+1)-1);pos=pos+(numnod+1)
iqup(1:numnod+1)=pending_values(pos:pos+(numnod+1)-1);pos=pos+(numnod+1)
iqrot=pending_values(pos);pos=pos+1
iqssdi=pending_values(pos);pos=pos+1
iqredwet=pending_values(pos);pos=pos+1
iqreddry=pending_values(pos);pos=pos+1
iqredsol=pending_values(pos);pos=pos+1
iqredfrs=pending_values(pos);pos=pos+1
iintc=pending_values(pos);pos=pos+1
isintc=pending_values(pos);pos=pos+1
iepd=pending_values(pos);pos=pos+1
ipeva=pending_values(pos);pos=pos+1
iptra=pending_values(pos);pos=pos+1
ievap=pending_values(pos);pos=pos+1
iruno=pending_values(pos);pos=pos+1
irunon=pending_values(pos);pos=pos+1
iqbot=pending_values(pos);pos=pos+1
iqbdo=pending_values(pos);pos=pos+1
iqbup=pending_values(pos);pos=pos+1
iqtdo=pending_values(pos);pos=pos+1
iqtup=pending_values(pos);pos=pos+1
igrai=pending_values(pos);pos=pos+1
inrai=pending_values(pos);pos=pos+1
igird=pending_values(pos);pos=pos+1
inird=pending_values(pos);pos=pos+1
cgrai=pending_values(pos);pos=pos+1
cnrai=pending_values(pos);pos=pos+1
caintc=pending_values(pos);pos=pos+1
cqrot=pending_values(pos);pos=pos+1
cqbot=pending_values(pos);pos=pos+1
cqbotdo=pending_values(pos);pos=pos+1
cqbotup=pending_values(pos);pos=pos+1
cqssdi=pending_values(pos);pos=pos+1
cqtdo=pending_values(pos);pos=pos+1
cqtup=pending_values(pos);pos=pos+1
crunoff=pending_values(pos);pos=pos+1
crunon=pending_values(pos);pos=pos+1
cevap=pending_values(pos);pos=pos+1
cepd=pending_values(pos);pos=pos+1
cpeva=pending_values(pos);pos=pos+1
cptra=pending_values(pos);pos=pos+1
cinund=pending_values(pos);pos=pos+1
cqprai=pending_values(pos);pos=pos+1
cgird=pending_values(pos);pos=pos+1
cnird=pending_values(pos);pos=pos+1
cqdra=pending_values(pos);pos=pos+1
cqdrain(1:nrlevs)=pending_values(pos:pos+(nrlevs)-1);pos=pos+(nrlevs)
cqdrainin(1:nrlevs)=pending_values(pos:pos+(nrlevs)-1);pos=pos+(nrlevs)
cqdrainout(1:nrlevs)=pending_values(pos:pos+(nrlevs)-1);pos=pos+(nrlevs)
inqdra(1:nrlevs,1:numnod)=reshape(pending_values(pos:pos+(nrlevs)*(numnod)-1),shape(inqdra(1:nrlevs,1:numnod)));pos=pos+(nrlevs)*(numnod)
inqdra_in(1:nrlevs,1:numnod)=reshape(pending_values(pos:pos+(nrlevs)*(numnod)-1),shape(inqdra_in(1:nrlevs,1:numnod)));pos=pos+(nrlevs)*(numnod)
inqdra_out(1:nrlevs,1:numnod)=reshape(pending_values(pos:pos+(nrlevs)*(numnod)-1),shape(inqdra_out(1:nrlevs,1:numnod)));pos=pos+(nrlevs)*(numnod)
iqdra=pending_values(pos);pos=pos+1
inqpotrot_day(1:numnod)=pending_values(pos:pos+(numnod)-1);pos=pos+(numnod)
inqredrot_day(1:numnod)=pending_values(pos:pos+(numnod)-1);pos=pos+(numnod)
iqrot_day=pending_values(pos);pos=pos+1
iqreddry_day=pending_values(pos);pos=pos+1
iqredsol_day=pending_values(pos);pos=pos+1
iptra_day=pending_values(pos);pos=pos+1
ialpwet_day=pending_values(pos);pos=pos+1
ialpdry_day=pending_values(pos);pos=pos+1
volini=pending_values(pos);pos=pos+1
pondini=pending_values(pos);pos=pos+1
ivolbeg=pending_values(pos);pos=pos+1
ipondbeg=pending_values(pos);pos=pos+1
issnowbeg=pending_values(pos);pos=pos+1
isicbeg=pending_values(pos);pos=pos+1
ithetabeg(1:numnod)=pending_values(pos:pos+(numnod)-1);pos=pos+(numnod)
outdat(1:maout)=pending_values(pos:pos+(maout)-1);pos=pos+(maout)
outdatint(1:maout)=pending_values(pos:pos+(maout)-1);pos=pos+(maout)
ipgass=pending_values(pos);pos=pos+1
igass=pending_values(pos);pos=pos+1
imres=pending_values(pos);pos=pos+1
ipgasspot=pending_values(pos);pos=pos+1
igasspot=pending_values(pos);pos=pos+1
imrespot=pending_values(pos);pos=pos+1
tcumold=pending_values(pos);pos=pos+1
outper=pending_values(pos);pos=pos+1
if(pos/=size(pending_values)+1)error stop 'Original output calendar layout mismatch'
if(ioutdat/=1+count(outdat>0d0.and.outdat<t1900-1d-8))error stop 'Inconsistent original output date pointer'
! Original initial explicit date remains pending when it precedes TSTART.
if(outdatint(1)>0d0.and.outdatint(1)<original_output_start_clock-1d-8)then
 if(ioutdatint/=1)error stop 'Inconsistent original pending initial interval date pointer'
else
 if(ioutdatint/=1+count(outdatint>0d0.and.outdatint<t1900-1d-8))error stop 'Inconsistent original interval date pointer'
end if
output_restore_pending=.false.
! Original first-day crop initialization resets these six output integrals.
! Restore them once after that initialization, before the normal interval reset.
output_crop_restore_pending=.true.
end subroutine
subroutine hybrid_output_crop_apply()
use plant_interface,only:ipgass,igass,imres,ipgasspot,igasspot,imrespot
integer::pos
if(.not.output_crop_restore_pending)return
pos=size(pending_values)-7
ipgass=pending_values(pos);igass=pending_values(pos+1);imres=pending_values(pos+2)
ipgasspot=pending_values(pos+3);igasspot=pending_values(pos+4);imrespot=pending_values(pos+5)
output_crop_restore_pending=.false.
end subroutine
real(8) function hybrid_output_trial_residual() result(residual)
use iso_fortran_env,only:real128
      use plant_interface, only: noddrz, ipgass, igass, imres, ipgasspot, igasspot, imrespot, sw_inter, sicact, siccap, crsflx_in, crsflx_out, siccaploss
      use MOD_grid,        only: numnod,dz
      use MOD_swap_base,   only: swsnow, swdra, swmacro
      use MOD_meteo,       only: peva, ptra, graidt, nraidt, aintcdt
      use MOD_snow,        only: gsnow, melt, subl, snrai, snowinco, ssnow
      use MOD_drain,       only: qdrtot, nrlevs, qdra, qdrain
      use MOD_irrigation,  only: qssdisum, qssdi, gird, nird
      use MOD_macropore,   only: macropore
      use variables,       only: flzerocumu, flzerointr, fldaystart, dt, epd, reva, qbot, qrot, runots,runon, q, volini, volact, pondini, pond, theta, ivolbeg, ipondbeg, issnowbeg, isicbeg, ithetabeg
      use MOD_re_global,   only: qpotrot, qredwetsum, qreddrysum, qredsolsum, qredfrssum, qrosum, qredwet, qreddry, qredsol, qredfrs, qredrwu, alpwetnoddrz, alpdrynodrtz
use variables,only:swbotb
implicit none
type(output_receipt_frame_t)::trial
real(8)::epdts,revats,qbotts,qrotts,qdrats,projected_canopy,projected_soil,terms(28)
integer::node
if(.not.hybrid_output_frame%active)error stop 'Inactive original trial receipt'
if(swmacro/=0.or.swsnow/=0.or.swbotb/=9.or.swdra<0.or.swdra>1)error stop 'Foreign original trial receipt domain'
trial=hybrid_output_frame
epdts=epd * dt
revats=reva * dt
qbotts=qbot*dt
qrotts=qrosum * dt
qdrats=qdrtot * dt
trial%flow_cm(10)=trial%flow_cm(10)+(qrotts)
do node=1,numnod
trial%flow_cm(6)=trial%flow_cm(6)+(qssdi(node) * dt)
end do
      if (sw_inter /= 3) then
         trial%flow_cm(8)=trial%flow_cm(8)+(aintcdt * dt)
      else
         trial%flow_cm(8)=trial%flow_cm(8)+(crsflx_out * dt)
      end if
trial%flow_cm(11)=trial%flow_cm(11)+(epdts)
trial%flow_cm(12)=trial%flow_cm(12)+(revats)
trial%flow_cm(9)=trial%flow_cm(9)+(runots)
trial%flow_cm(5)=trial%flow_cm(5)+(runon*dt)
trial%flow_cm(1)=trial%flow_cm(1)+(graidt*dt)
trial%flow_cm(4)=trial%flow_cm(4)+(gird*dt)
      if (qbotts < 0.0d0) then
         trial%flow_cm(16)=trial%flow_cm(16)-(qbotts)
      else if (qbotts > 0.0d0) then
         trial%flow_cm(7)=trial%flow_cm(7)+(qbotts)
      end if
trial%flow_cm(14)=trial%flow_cm(14)+(qdrats)
projected_canopy=min(max(0.d0, sicact + (crsflx_in - crsflx_out) * dt), siccap)
projected_soil=sum(theta(1:numnod)*dz(1:numnod))
terms=[trial%flow_cm(1:7),-trial%flow_cm(8:16),trial%start_stock_cm, &
 -projected_soil,-pond,0d0,-projected_canopy,0d0,0d0]
residual=real(sum(real(terms,real128)),8)
end function

real(8) function hybrid_ordinary_trial_residual(candidate_bottom_cm_d) result(residual)
use iso_fortran_env,only:real128
use ieee_arithmetic,only:ieee_is_finite
use variables,only:swbotb,nprintday,flprintdt
      use plant_interface, only: noddrz, ipgass, igass, imres, ipgasspot, igasspot, imrespot, sw_inter, sicact, siccap, crsflx_in, crsflx_out, siccaploss
      use MOD_grid,        only: numnod,dz
      use MOD_swap_base,   only: swsnow, swdra, swmacro
      use MOD_meteo,       only: peva, ptra, graidt, nraidt, aintcdt
      use MOD_snow,        only: gsnow, melt, subl, snrai, snowinco, ssnow
      use MOD_drain,       only: qdrtot, nrlevs, qdra, qdrain
      use MOD_irrigation,  only: qssdisum, qssdi, gird, nird
      use MOD_macropore,   only: macropore
      use variables,       only: flzerocumu, flzerointr, fldaystart, dt, epd, reva, qbot, qrot, runots,runon, q, volini, volact, pondini, pond, theta, ivolbeg, ipondbeg, issnowbeg, isicbeg, ithetabeg
      use MOD_re_global,   only: qpotrot, qredwetsum, qreddrysum, qredsolsum, qredfrssum, qrosum, qredwet, qreddry, qredsol, qredfrs, qredrwu, alpwetnoddrz, alpdrynodrtz
implicit none
real(8),intent(in)::candidate_bottom_cm_d
type(output_receipt_frame_t)::trial
real(8)::epdts,revats,qbotts,qrotts,qdrats,projected_canopy,projected_soil,terms(28)
integer::node
if(.not.hybrid_output_frame%active)error stop 'Inactive original trial receipt'
if(swmacro/=0.or.swsnow/=0.or.swdra/=1.or.nprintday<1.or.nprintday>1440.or. &
 (.not.flprintdt.and.nprintday==1).or. &
 (swbotb/=5.and.swbotb/=8))error stop 'Foreign original ordinary Darcy trial domain'
if(.not.ieee_is_finite(candidate_bottom_cm_d))error stop 'Nonfinite original ordinary Darcy trial boundary'
trial=hybrid_output_frame
epdts=epd * dt
revats=reva * dt
qbotts=candidate_bottom_cm_d*dt
qrotts=qrosum * dt
qdrats=qdrtot * dt
trial%flow_cm(10)=trial%flow_cm(10)+(qrotts)
do node=1,numnod
trial%flow_cm(6)=trial%flow_cm(6)+(qssdi(node) * dt)
end do
      if (sw_inter /= 3) then
         trial%flow_cm(8)=trial%flow_cm(8)+(aintcdt * dt)
      else
         trial%flow_cm(8)=trial%flow_cm(8)+(crsflx_out * dt)
      end if
trial%flow_cm(11)=trial%flow_cm(11)+(epdts)
trial%flow_cm(12)=trial%flow_cm(12)+(revats)
trial%flow_cm(9)=trial%flow_cm(9)+(runots)
trial%flow_cm(5)=trial%flow_cm(5)+(runon*dt)
trial%flow_cm(1)=trial%flow_cm(1)+(graidt*dt)
trial%flow_cm(4)=trial%flow_cm(4)+(gird*dt)
      if (qbotts < 0.0d0) then
         trial%flow_cm(16)=trial%flow_cm(16)-(qbotts)
      else if (qbotts > 0.0d0) then
         trial%flow_cm(7)=trial%flow_cm(7)+(qbotts)
      end if
trial%flow_cm(14)=trial%flow_cm(14)+(qdrats)
projected_canopy=min(max(0.d0, sicact + (crsflx_in - crsflx_out) * dt), siccap)
projected_soil=sum(theta(1:numnod)*dz(1:numnod))
terms=[trial%flow_cm(1:7),-trial%flow_cm(8:16),trial%start_stock_cm, &
 -projected_soil,-pond,0d0,-projected_canopy,0d0,0d0]
residual=real(sum(real(terms,real128)),8)
if(.not.ieee_is_finite(residual))error stop 'Nonfinite original ordinary Darcy trial receipt'
end function

end module MOD_integral
   