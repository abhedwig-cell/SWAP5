import json,pathlib,subprocess,sys,time,os
E=pathlib.Path(__file__).parent
W=E.parent
R=pathlib.Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C=pathlib.Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py')
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert HEAD=='59781f1e1'+subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()[9:]
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
os.environ.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1',TEMP=str(W/'active-python-scratch'),TMP=str(W/'active-python-scratch'))
os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH']
old=json.loads((E/'explicit-bottom9-analytical-prior-cde-monthly-O0-postimage-observe-v3/RESULT.json').read_text())
assert old['compiler_executions']==0 and old['model_executions']==0 and old['actual_new_producer']=='48a7120fb5e751d93346c03ba9792ed8c0f14e6a'
items=[dict(case='cde-monthly',optimization='O0',profile=str(E/'explicit-bottom9-analytical-prior-cde-monthly-O0-postimage-observe-v3'),build_root=old['build_root'],producer=old['actual_new_producer'])]
start=time.monotonic()
def save(status):
 d=dict(status=status,observer_source=HEAD,profiles=items,seconds=time.monotonic()-start,compiler_only_new_builds=len(items)-1,model_executions=0,canonical_admission=False)
 (E/'EXPLICIT_BOTTOM9_ANALYTICAL_PRIOR_POSTIMAGES_BATCH_V1.json').write_text(json.dumps(d,indent=2)+'\n')
save('RUNNING_COMPILE_ONLY_ACTUAL_INTEGRATED_PRIOR_CONTEXT_POSTIMAGES')
for case in ['water-pressure-step','age-pressure-step','cde-pressure-daily','cde-monthly','cde-distributed-subdaily','water-last-node-drainage']:
 for opt in ['O0','O2']:
  if case=='cde-monthly' and opt=='O0':continue
  name='explicit-bottom9-analytical-prior-'+case+'-'+opt+'-postimage-v3'
  build=json.loads(subprocess.check_output([sys.executable,'-B',str(C),'allocate','--task','01a1e8b4-228b-75f1-8ac4-b07ca1e15713','--kind','build','--name',name,'--variant',opt,'--source-ref',HEAD,'--recipe','Actual accepted '+case+' '+opt+' inputs, compile only on analytical physical source9c9; full generated source and whole compiled comparison; no model period'],text=True))
  # allocate path field is supplied by the shared registry; never infer a disposable path.
  root=pathlib.Path(build.get('path',build.get('directory','')))
  assert root.is_absolute() and root.parent==W,build
  out=E/name;inputs=E/(name+'-inputs')
  command=[sys.executable,'-B','tests/nomacro_drainage/explicit_bottom9_analytical_parent_postimages.py','--case',case,'--optimization',opt,'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--inputs',str(inputs),'--build-root',str(root),'--output',str(out)]
  with (E/(name+'.stdout.txt')).open('x') as stdout,(E/(name+'.stderr.txt')).open('x') as stderr:
   done=subprocess.run(command,cwd=R,stdout=stdout,stderr=stderr,timeout=600)
  if done.returncode:
   items.append(dict(case=case,optimization=opt,profile=str(out),build_root=str(root),exit_code=done.returncode));save('REFUSED_RETAIN_ALL_ACTUAL_BUILD_AND_OBSERVER_EVIDENCE');raise RuntimeError((case,opt,done.returncode))
  result=json.loads((out/'RESULT.json').read_text());assert result['model_executions']==0
  items.append(dict(case=case,optimization=opt,profile=str(out),build_root=result['build_root'],producer=result['actual_new_producer']));save('RUNNING_COMPILE_ONLY_ACTUAL_INTEGRATED_PRIOR_CONTEXT_POSTIMAGES');print(case,opt,'PASS',flush=True)
assert len(items)==12
save('ALL12_ACTUAL_PRIOR_CONFIGURATION_COMPLETE_GENERATED_SOURCE_AND_WHOLE_COMPILED_POSTIMAGES_VERIFIED_NO_MODEL_PERIODS')
print('ALL12_PASS',time.monotonic()-start,flush=True)
