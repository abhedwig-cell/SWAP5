* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-22 07:59:23

Period             :  1900-01-01  until  2002-02-04 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        84.70 cm       0.0000E+00 mg/cm2
Initial :        84.70 cm       0.8470E+00 mg/cm2
            =============       =================
Change            0.00 cm      -0.8470E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   492.05    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :  -492.05    Soil evaporation  :     0.00
                             Crack flux        :     0.00
=========================    ============================
Sum            :     0.00    Sum               :     0.00


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.8470E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.8470E+00    Sum            :  0.0000E+00

