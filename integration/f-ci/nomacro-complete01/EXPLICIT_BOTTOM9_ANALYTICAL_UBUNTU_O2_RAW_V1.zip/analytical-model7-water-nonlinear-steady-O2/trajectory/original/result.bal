* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-22 08:00:01

Period             :  1900-01-01  until  2002-02-04 
Depth soil profile :  200.00 cm

            Water storage
Final   :        84.64 cm
Initial :        84.64 cm
            =============
Change            0.00 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   489.21    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :  -489.21    Soil evaporation  :     0.00
                             Crack flux        :     0.00
=========================    ============================
Sum            :     0.00    Sum               :     0.00
