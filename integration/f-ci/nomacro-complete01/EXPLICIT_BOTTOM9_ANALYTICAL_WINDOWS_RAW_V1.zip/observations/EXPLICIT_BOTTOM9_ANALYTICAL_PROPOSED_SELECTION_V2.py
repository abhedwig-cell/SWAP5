def selection(directory,original_output=True):
 if not directory or original_output is False:return None
 from experimental_project import switches
 text=(Path(directory)/'swap.swp').read_text(encoding='cp1252');s=switches(text)
 if s.get('SWBOTB')!=9:return None
 active='\n'.join(line.split('!',1)[0] for line in text.splitlines() if not line.lstrip().startswith('*'))
 def integer(key):
  rows=re.findall(r'(?mi)^[ \t]*'+key+r'[ \t]*=[ \t]*([^\r\n]*)',active)
  if len(rows)!=1 or re.fullmatch(r'[+-]?[0-9]+[ \t]*',rows[0]) is None:return None
  return int(rows[0])
 fixed=dict(SWMACRO=0,SWBOTB=9,SWKIMPL=0,SWHYST=0,SWSNOW=0,SWFROST=0,SWHEA=1,SWCALT=2,SWBR=0,SWMETDETAIL=0,SWSOPHY=0,SWBBCFILE=0)
 if any(integer(key)!=value for key,value in fixed.items()):return None
 if integer('SWINCO') not in (1,2) or integer('SWSOLU') not in (0,1,2) or integer('SWDRA') not in (0,1) or integer('SWKMEAN') not in range(1,7):return None
 if re.search(r'(?i)\bSWAP_SOILS_DB\b',active):return None
 models=re.findall(r'(?mi)^[ \t]*IHWCKMODEL[ \t]*=[ \t]*([^\r\n]*)',active)
 remainder=re.sub(r'(?mi)^[ \t]*IHWCKMODEL[ \t]*=[^\r\n]*','',active)
 if re.search(r'(?i)\bIHWCKMODEL\b',remainder) or len(models)>1 or models and re.fullmatch(r'[+]?[0-9]+(?:[ \t]+[+]?[0-9]+)*[ \t]*',models[0]) is None:return None
 if models:
  analytical=tuple(map(int,models[0].split()))
  if not all(value in (1,3,4,5,6,7,8,9,10,11) for value in analytical):return None
  if any(value!=1 for value in analytical):
   if integer('SWSOLU') not in (0,1):return None
   vapor=re.findall(r'(?mi)^[ \t]*SWVAPOR[ \t]*=[ \t]*([^\r\n]+)',active)
   if len(vapor)>1 or vapor and re.fullmatch(r'0(?:[ \t]+0)*[ \t]*',vapor[0]) is None:return None
 def civil(key):
  rows=re.findall(r'(?mi)^[ \t]*'+key+r'[ \t]*=[ \t]*([^\s]+)',active)
  if len(rows)!=1:raise ValueError('Ambiguous original paired-boundary interval')
  return date.fromisoformat(rows[0])
 try:
  start,end=civil('TSTART'),civil('TEND');tables={}
  if end<start:return None
  for axis,value,lower,upper in [('DATE9A','HBOT9',-1.e10,1000.),('DATE9B','QBOT9',-100.,100.)]:
   rows=re.findall(r'(?mis)^[ \t]*'+axis+r'[ \t]+'+value+r'[ \t]*(?:![^\r\n]*)?\r?\n(.*?)^[ \t]*\*[ \t]*End of table',text)
   if len(rows)!=1:return None
   values=[]
   for line in rows[0].splitlines():
    line=line.split('!',1)[0].strip()
    if not line or line.startswith('*'):continue
    fields=line.split()
    if len(fields)!=2:return None
    stamp=date.fromisoformat(fields[0]);number=float(fields[1].replace('D','E').replace('d','e'))
    if not math.isfinite(number) or not lower<=number<=upper:return None
    if values and stamp<=values[-1][0]:return None
    values.append((stamp,number))
   if not values or not (any(start<=stamp<=end for stamp,_ in values) or values[0][0]<=start and values[-1][0]>=end):return None
   tables[axis]=len(values)
 except (ValueError,OverflowError):return None
 return dict(policy=POLICY,kind=('water','cde','age')[s['SWSOLU']],drainage=s['SWDRA'],initial=s['SWINCO'],table_rows=tables,physical_equations_changed=False,new_native_codec=False)
