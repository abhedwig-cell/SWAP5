"""Prepare declared nonlinear controls from already-preserved actual original K; no model."""
import hashlib,io,json,re,subprocess,sys,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_inputs import prepare
from original_output_baseline import assignment
from initial_pressure_profile_science import initialized_heads
from analytical_hydraulic_archives import SHA
import experimental_project as project
HEAD='881e4ee9b21e476dd5aca53ed3c139ddcef1b81b';proof=R/'integration/f-ci/nomacro-complete01';name='HYDRAULIC_MODEL7_PRETERMINAL_RESEARCH_RAW_V1';record=json.loads((proof/(name+'.json')).read_text());archive_path='integration/f-ci/nomacro-complete01/'+record['archive']
raw=subprocess.check_output(['git','show',HEAD+':'+archive_path],cwd=R);assert len(raw)==record['bytes'] and SHA(raw)==record['sha256']
root=E/'explicit-bottom9-analytical-input-discovery-v1';assert not root.exists();root.mkdir();results=[]
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 def member(name):
  raw=z.read(name);item=record['members'][name];assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'];return raw
 for model in (3,7,11):
  components=[]
  for opt in ('O0','O2'):
   prefix='profiles/hydraulic-constitutive-original-'+opt+'-v1';old=json.loads(member(prefix+'/RESULT.json'));assert old['status']=='ACTUAL_ORIGINAL_HYDRAULIC_INTERFACES_OBSERVED_NO_ADMISSION'
   driver=member(prefix+'/hydraulic_constitutive_probe.f90');assert SHA(driver)==old['driver_sha256']
   assert driver.replace(b'\r\n',b'\n')==(R/'tests/nomacro_drainage/hydraulic_constitutive_probe.f90').read_bytes().replace(b'\r\n',b'\n')
   rows=[list(map(float,line.split()[1:])) for line in member(prefix+'/model'+str(model)+'.stdout').decode().splitlines() if line.startswith('ACTUAL_ORIGINAL_HYDRAULIC ')]
   row=[v for v in rows if v[0]==model and v[1]==1 and v[3]==-10.];assert len(row)==1 and 0<row[0][6]<=100;components.append(row[0])
  assert components[0]==components[1];conductivity=components[0][6]
  for kind in ('water','cde'):
   inputs=root/('model'+str(model)+'-'+kind+'-initial1');prepare(kind+'-pressure-daily',inputs,1);f=inputs/'swap.swp';text=f.read_bytes().decode('cp1252')
   for key,value in dict(IHWCKMODEL=str(model)+' '+str(model),ALFA_2='.005 .005',NPAR_2='1.5 1.5',OMEGA_1='.8 .8',H0='-1e6 -1e6',HA='-10 -10',APAR='-1.5 -1.5',OMEGA_K='.01 .01',SWVAPOR='0 0').items():
    text=assignment(text,key,value) if re.search(r'(?mi)^[ \t]*'+key+r'[ \t]*=',text) else text+'\n'+key+' = '+value+'\n'
   def replace(pattern,body):
    global text
    text,count=re.subn(pattern,lambda m:m[1]+body+m[2],text,count=1,flags=re.M|re.I|re.S);assert count==1
   replace(r'(^[ \t]*ORES[ \t]+OSAT[^\n]*\n).*?(^[ \t]*\* End of table)',('0.02 0.433878 0.021645 0.043290 1.348770 7.202077 83.24164 83.24164 -0.01 1315.0\n')*2)
   replace(r'(^[ \t]*HTB[ \t]*=[ \t]*\n).*?(^[ \t]*\* End of table)',' -0.5 -10.0\n -195.0 -10.0\n')
   for axis,value,number in [('DATE9A','HBOT9',-10.),('DATE9B','QBOT9',-conductivity)]:
    replace(r'(^[ \t]*'+axis+r'[ \t]+'+value+r'[^\n]*\n).*?(^[ \t]*\* End of table)','2002-01-01 '+format(number,'.17g')+'\n2004-01-01 '+format(number,'.17g')+'\n')
   f.write_bytes(text.encode('cp1252'));heads,_=initialized_heads(text);assert heads==[-10.]*34
   meteo=inputs/'283.met';lines=meteo.read_bytes().decode('cp1252').splitlines(keepends=True)
   for i,line in enumerate(lines):
    if not line.startswith("'283',"):continue
    values=line.rstrip('\r\n').split(',');assert len(values)==12;values[9]=format(10*conductivity,'.17g');lines[i]=','.join(values)+('\r\n' if line.endswith('\r\n') else '\n')
   meteo.write_bytes(''.join(lines).encode('cp1252'))
   for crop in inputs.glob('*.crp'):crop.write_bytes(assignment(crop.read_bytes().decode('cp1252'),'SWOXYGEN',1).encode('cp1252'))
   try:project.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
   except ValueError as error:refusal=str(error)
   else:raise AssertionError('Unexpected existing admission for new nonlinear paired9 input')
   results.append(dict(model=model,kind=kind,input_root=str(inputs),input_inventory=project.inventory(inputs),original_component_producer=old['source'],original_component_O0_O2_exact=True,actual_original_component_row=components[0],declared_uniform_initial_head=-10.,declared_bottom_head=-10.,declared_bottom_flux=-conductivity,declared_rain_cm_day=conductivity,original_hard_oxygen2_case_selected=False,actual_existing_frontend_refusal=refusal))
q=dict(status='SIX_PROPOSED_NONLINEAR_PAIRED9_INPUTS_FROM_PRESERVED_ACTUAL_ORIGINAL_K_ALL_REFUSED_BY_CURRENT_ADMISSION',source=HEAD,original_component_archive_sha256=record['sha256'],cases=results,model_executions=0,compiler_executions=0,new_inputs_are_not_current_runtime_qualification=True,physical_or_numerical_source_modified=False,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_ANALYTICAL_INPUT_SOURCE_DISCOVERY_V1.json').open('x') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'])
