"""Read the exact generic CDE prefix, never a groundwater-specific codec layout."""
import json,math,struct,sys,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from analytical_hydraulic_archives import SHA
profiles=[E/'explicit-bottom9-cde-pressure-daily-O0-v1',E/'explicit-bottom9-cde-pressure-daily-O2-composition-v1']+[E/('explicit-bottom9-cde-pressure-mean6-'+opt+'-composition-v1') for opt in ('O0','O2')]+[E/('explicit-bottom9-distributed-drain-cde-'+opt+'-v1') for opt in ('O0','O2')]
observed=[]
for profile in profiles:
 q=json.loads((profile/'RESULT.json').read_text());assert q['status']=='ACTUAL_EXPLICIT_PAIRED_HEAD_FLUX_PHYSICAL_NATIVE_EXACT_COLD_USER_OUTPUT_PASS_NOT_ADMITTED' and q['kind']=='cde'
 build=Path(q['build_root']);meta=json.loads((build/'BUILD.json').read_text());writer=build/'macropore.f90';assert SHA(writer.read_bytes())==meta['identity']['donor_generated']['macropore.f90'];source=writer.read_text(encoding='cp1252')
 for line in ("write(unit) 'S5IOC001',numnod,clock,old_step,canopy_stock",'write(unit) t,iyear'):assert source.count(line)==1
 samples=[]
 for directory in (profile/'trajectory',*[profile/('own-'+str(start)) for start in (2,19,30)]):
  rows={row['day']:row for row in map(json.loads,(directory/'daily.jsonl').read_text().splitlines())}
  for path in directory.glob('accepted-column-1-day-*.zip'):
   day=int(path.stem.split('-')[-1]);row=rows[day]
   with zipfile.ZipFile(path) as z:
    raw=z.read('macro.bin');packet=json.loads(z.read('checkpoint.json'));assert packet['receipt']==row and SHA(raw)==packet['files']['macro.bin']
   magic,n,clock,step,canopy,season,year=struct.unpack_from('<8si4di',raw)
   assert struct.calcsize('<8si4di')==48 and magic==b'S5IOC001' and n==meta['project']['nodes']==34
   assert all(map(math.isfinite,(clock,step,canopy,season))) and clock==meta['identity']['original_output']['original_output_epoch']+day and 0<step<=1 and canopy>=0 and canopy==row['stock_end_cm'][3] and 1<=year<=9999
   samples.append(dict(path=str(path),day=day,actual_nodes=n,actual_clock=clock,actual_step=step,actual_canopy=canopy,actual_seasonal_clock_retained=season,actual_year=year,seasonal_clock_normalized=False,actual_codec=magic.decode(),prefix_bytes=48))
 assert len(samples)==10
 observed.append(dict(profile=str(profile),producer=q['source'],optimization=q['optimization'],actual_generated_writer_sha256=SHA(writer.read_bytes()),samples=samples))
q=dict(status='ALL_SIX_CDE_CONTEXTS_60_ACTUAL_WARM_COLD_GENERIC_PREFIXES_MATCH_PINNED_WRITER_DOMAIN_CLOCK_STOCK_RECEIPTS',contexts=6,actual_native_prefixes=60,observations=observed,groundwater_codec_or_hydraulic_header_substituted=False,original_values_or_bytes_rewritten=False,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_ALL_CDE_GENERIC_NATIVE_PREFIX_V1.json').open('x') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'])
