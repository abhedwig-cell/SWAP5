"""Read-only proposed CDE calendar composition; no active source/build/model edits."""
import ast,json,shutil,sys
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import SHA
from original_output_baseline import assignment
from explicit_bottom9_source_inverse import complete_inverse,git
import experimental_project as e
import prescribed_head_flux_boundary as paired
complete_inverse();head=git('rev-parse','HEAD').decode().strip();assert head=='27149e8fac206ef7d30561a8eb28e4ad56736b9e'
root=E/'explicit-bottom9-cde-calendar-discovery-v1';root.mkdir();proposed={}
for name in ('cde_interval_output','cde_clock_output'):
    text=(R/'app/hybrid_water'/(name+'.py')).read_text()
    old="    bottom=inspect(project.input_directory,original_output=True)['boundary']['SWBOTB']\n"
    new=old+"    from prescribed_head_flux_boundary import selection as paired_selection\n    paired_bottom=bottom==9 and paired_selection(project.input_directory,project.original_output) is not None\n"
    assert text.count(old)==1;text=text.replace(old,new,1)
    for old,new in [("    if bottom not in (1,5,8):","    if bottom not in (1,5,8) and not paired_bottom:"),("    if bottom!=1 and drainage!=1:","    if bottom!=1 and drainage!=1 and not paired_bottom:")]:
        assert text.count(old)==1;text=text.replace(old,new,1)
    marker="        **({'analytical_vapor_calendar':True}"
    assert text.count(marker)==1;text=text.replace(marker,"        **({'paired_head_flux_cde_calendar':True} if paired_bottom else {}),\n"+marker,1)
    path=root/(name+'-proposed.py');path.write_text(text);namespace=dict(__file__=str(path),__name__='proposed_'+name)
    exec(compile(text,str(path),'exec'),namespace);proposed[name]=namespace
base=E/'explicit-bottom9-composed-inputs-v2/cde-pressure-daily';observed=[]
for mode,controls in [('periodic',dict(PERIOD=3,SWRES=1)),('monthly',dict(SWMONTH=1,SWRES=0)),('subdaily',dict(NPRINTDAY=3,PERIOD=3,SWRES=0)),('step',dict(PERIOD=0,SWRES=0,FLPRINTDT='.TRUE.'))]:
    inputs=root/(mode+'-initial1');shutil.copytree(base,inputs);path=inputs/'swap.swp';text=path.read_bytes().decode('cp1252')
    for key,value in controls.items():text=assignment(text,key,value)
    path.write_bytes(text.encode('cp1252'));counter=root/(mode+'-initial2');shutil.copytree(inputs,counter);path=counter/'swap.swp';path.write_bytes(assignment(path.read_bytes().decode('cp1252'),'SWINCO',2).encode('cp1252'))
    project=e.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
    try:e.auxiliary_magic(project)
    except ValueError as error:refusal=str(error);assert 'CDE output currently requires daily' in refusal
    else:raise AssertionError('Current non-daily CDE route unexpectedly admitted')
    namespace=proposed['cde_clock_output' if mode in ('subdaily','step') else 'cde_interval_output'];selected=namespace['active_selection'](project)
    assert selected and selected['paired_head_flux_cde_calendar'] and selected['swdra']==0
    original=(Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider/build/swap-selected/integral.f90')).read_text(encoding='cp1252');watstor=(Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider/build/swap-selected/watstor.f90')).read_text(encoding='cp1252')
    integral=namespace['render_integral'](original,watstor,selected) if mode in ('subdaily','step') else namespace['render_integral'](original,selected)
    if mode in ('subdaily','step'):
        integral=paired.render_output_trial(integral,original,watstor)
        assert "swbotb/=9.or.swdra<0.or.swdra>1" in integral
    (root/(mode+'-proposed-integral.f90')).write_text(integral,encoding='cp1252')
    observed.append(dict(mode=mode,actual_current_public_auxiliary_selection_refusal=refusal,proposed_selection=selected,proposed_existing_native_codec=namespace['magic'](project).decode(),proposed_integral_sha256=SHA(integral.encode('cp1252')),inputs=str(inputs),input_inventory=e.inventory(inputs),counter_inputs=str(counter),counter_inventory=e.inventory(counter),compiler_executions=0,model_executions=0))
    print('PURE_PROPOSED_CDE_CALENDAR_SELECTION_AND_INTEGRAL_PASS_NOT_QUALIFIED',mode,flush=True)
q=dict(status='PURE_PROPOSED_CDE9_INTERVAL_AND_CLOCK_SOURCE_SELECTION_INTEGRAL_DISCOVERY_ONLY_NOT_QUALIFIED',actual_unchanged_source=head,observations=observed,active_source_edited=False,compiler_executions=0,model_executions=0,required_remaining='Actual CDE clock HeadCalc must use unchanged full28term receipt with prescribed qbot, never the ordinary Darcy candidate. Then actual current source, O0/O2 daily increments/private20+N native/EOF/exact cold/full initial2 compiled postimage and representative Linux controls.',canonical_admission=False)
(E/'EXPLICIT_BOTTOM9_CDE_CALENDAR_SOURCE_DISCOVERY_V1.json').write_text(json.dumps(q,indent=2)+'\n')
