"""Prove the proposed receipt-only seam against an actual retained HeadCalc."""
import ast,json,sys
from pathlib import Path
from contextlib import ExitStack
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_source_inverse import CORE,HOST,MODULE,FINAL_LATE,complete_inverse,git
from analytical_hydraulic_archives import Archive,SHA
complete_inverse();head=git('rev-parse','HEAD').decode().strip();assert head=='27149e8fac206ef7d30561a8eb28e4ad56736b9e'
root=E/'explicit-bottom9-cde-calendar-discovery-v1'
tree=ast.parse((R/'app/hybrid_water/cde_clock_output.py').read_text())
assignments=[n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='guard' for t in n.targets) and isinstance(n.value,ast.BinOp)]
assert len(assignments)==1
old_guard=eval(compile(ast.Expression(assignments[0].value),'literal-existing-CDE-clock-guard','eval'),dict(__builtins__={},function='hybrid_ordinary_trial_residual'))
old_import='   use MOD_integral,only:hybrid_ordinary_trial_residual\n';old_decl='   real(8)::hybrid_cde_clock_trial_guard,hybrid_cde_clock_candidate_bottom\n'
new_import='   use MOD_integral,only:hybrid_output_trial_residual\n';new_guard='\n         if(abs(hybrid_output_trial_residual())>1d-10)flnonconv=.true.'
append='\n\nCDE_CLOCK_IMPORT='+repr(old_import)+'\nCDE_CLOCK_DECL='+repr(old_decl)+'\nCDE_CLOCK_GUARD='+repr(old_guard)+'\n'+'''\ndef render_cde_clock_headcalc(source):
 for old,new in ((CDE_CLOCK_IMPORT,'   use MOD_integral,only:hybrid_output_trial_residual\\n'),(CDE_CLOCK_DECL,''),(CDE_CLOCK_GUARD,'\\n         if(abs(hybrid_output_trial_residual())>1d-10)flnonconv=.true.')):
  if source.count(old)!=1:raise ValueError('Changed whole original CDE clock trial seam')
  source=source.replace(old,new,1)
 return source
'''
module=(R/MODULE).read_text();proposed_module=module+append;namespace=dict(__file__=str(root/'prescribed_head_flux_boundary-proposed.py'));exec(compile(proposed_module,namespace['__file__'],'exec'),namespace)
(root/'prescribed_head_flux_boundary-proposed.py').write_text(proposed_module)
late='''        if age_calendar.get('cde_clock_output'):
            from prescribed_head_flux_boundary import render_cde_clock_headcalc
            head=output/'headcalc.f90'
            head.write_text(render_cde_clock_headcalc(head.read_text(encoding='cp1252')),encoding='cp1252')
'''
new_late=FINAL_LATE.replace("        integral=output/'integral.f90'\n",late+"        integral=output/'integral.f90'\n",1)
host=(R/HOST).read_text();assert host.count(FINAL_LATE)==1;proposed_host=host.replace(FINAL_LATE,new_late,1)
assert proposed_host.replace(new_late,FINAL_LATE,1)==host and proposed_module.removesuffix(append)==module
(root/'daily_host-proposed.py').write_text(proposed_host)
with ExitStack() as stack:
 store=Archive(R/'integration/f-ci/nomacro-complete01','EXPLICIT_BOTTOM9_WINDOWS_RAW_V1',stack)
 role=next(r for r in store.record['roles'] if r['case']=='cde-pressure-daily' and r['optimization']=='O0');q=json.loads(store.get(role['profile']+'/RESULT.json'));projection=json.loads(store.get('COMPILED_PROJECTION_V1.json'));prefix=projection[q['build_root']]['archive_prefix'];raw=store.get(prefix+'/headcalc.f90');actual_head=raw.decode('cp1252').replace('\r\n','\n')
 anchor='   use hybrid_step_budget, only: projected_water_residual';assert actual_head.count(anchor)==1;old_clock=actual_head.replace(anchor,old_import+anchor,1)
 anchor='\n   implicit none\n';assert old_clock.count(anchor)==1;old_clock=old_clock.replace(anchor,anchor+old_decl,1)
 anchor='         if (abs(budget_total+budget_step)>1d-10*(t1900-budget_start+dt)) flnonconv=.true.';assert old_clock.count(anchor)==1;old_clock=old_clock.replace(anchor,anchor+old_guard,1)
 current=namespace['render_cde_clock_headcalc'](old_clock);assert current.count(new_import)==current.count(new_guard)==1
 assert 'hybrid_cde_clock_candidate_bottom' not in current and 'hybrid_ordinary_trial_residual' not in current
 restored=current.replace(new_import,old_import,1).replace('\n   implicit none\n','\n   implicit none\n'+old_decl,1).replace(new_guard,old_guard,1);assert restored==old_clock
 (root/'proposed-old-Darcy-clock-headcalc.f90').write_text(old_clock,encoding='cp1252');(root/'proposed-actual-prescribed-qbot-clock-headcalc.f90').write_text(current,encoding='cp1252')
 report=dict(status='PURE_PROPOSED_CDE_CLOCK_PRESCRIBED_QBOT_RECEIPT_SEAM_WHOLE_INVERSE_PASS_NOT_QUALIFIED',actual_unchanged_source=head,actual_retained_headcalc_producer=q['source'],actual_retained_headcalc_raw_sha256=SHA(raw),proposed_headcalc_sha256=SHA(current.encode('cp1252')),whole_old_clock_headcalc_restored_exact=True,actual_prescribed_qbot_28term_receipt_used=True,ordinary_Darcy_candidate_removed_only_from_new9_CDE_clock_guard=True,original_Newton_matrix_forced_head_and_strict_retry_bodies_unchanged=True,old_scope_conditional_branch_unselected=True,active_source_edited=False,compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'EXPLICIT_BOTTOM9_CDE_CLOCK_PRESCRIBED_QBOT_PROPOSAL_V1.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'])
