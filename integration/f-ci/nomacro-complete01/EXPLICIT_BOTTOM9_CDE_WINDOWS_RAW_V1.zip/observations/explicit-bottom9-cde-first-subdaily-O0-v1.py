"""First actual composed CDE clock, native cold workers and compiled counterpart."""
import json,os,subprocess,sys
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;W=E.parent
P=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');HEAD='3e0f10165ed67422ecfa7a0245d2c2b45a0af793'
TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';TOOL='C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_source_inverse import CDE_CORE,CORE,complete_inverse,git
from explicit_bottom9_compiled_postimage import compare
from analytical_hydraulic_archives import SHA
complete_inverse();assert git('rev-parse','HEAD').decode().strip()==HEAD
assert json.loads((E/'explicit-bottom9-cde-calendar-actual-source-3e0f-v1/RESULT.json').read_text())['producer_head']==HEAD
os.environ.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1',TEMP=str(W/'active-python-scratch'),TMP=str(W/'active-python-scratch'));os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH']
case='cde-subdaily';label='explicit-bottom9-cde-subdaily-O0-v1';profile=E/label;post=E/(label+'-initial2-postimage');inputs=E/'explicit-bottom9-cde-calendar-discovery-v1/subdaily-initial1';counter=inputs.with_name('subdaily-initial2');builds=[]
for name in (label,label+'-initial2-postimage'):
 r=subprocess.run([sys.executable,'-B',TOOL,'allocate','--task',TASK,'--kind','build','--name',name,'--variant','O0','--source-ref',HEAD,'--recipe','Actual CDE9 subdaily existing private20+N state and daily flux receipt; prescribedqbot28terms; original35days7native3cold orinitial2counter; O0'],cwd=R,capture_output=True,text=True,check=True);(E/(name+'-allocation.json')).write_text(r.stdout);builds.append(Path(json.loads(r.stdout)['path']))
q=dict(status='RUNNING',actual_source=HEAD,composition_core=CDE_CORE,unchanged_physical_equations_anchor=CORE,input=str(inputs),counter_input=str(counter),profile=str(profile),postimage=str(post),old_model_periods_replayed=False,canonical_admission=False)
record=E/'EXPLICIT_BOTTOM9_CDE_SUBDAILY_O0_FIRST_V1.json'
def save():record.write_text(json.dumps(q,indent=2)+'\n')
def run(args):
 assert git('rev-parse','HEAD').decode().strip()==HEAD
 subprocess.run([sys.executable,'-B',*map(str,args)],cwd=R,check=True)
save()
try:
 run(['tests/nomacro_drainage/explicit_bottom9_runtime.py','--case',case,'--input',inputs,'--reference-work',P,'--build-root',builds[0],'--output',profile,'--optimization','O0'])
 run(['tests/nomacro_drainage/explicit_bottom9_postimage.py','--profile',profile,'--input',counter,'--reference-work',P,'--build-root',builds[1],'--output',post])
 compiled=compare(builds[0]/'bundle',builds[1]/'bundle');path=E/(label+'-actual-compiled-v1.json');path.write_text(json.dumps(compiled,indent=2)+'\n')
 q.update(status='ACTUAL_FIRST_CDE9_SUBDAILY_O0_PHYSICAL_NATIVE_COLD_AND_ALL_COMPILED_COUNTERPART_PASS_PENDING_INDEPENDENT_SCIENCE',actual_compiled=str(path),actual_compiled_sha256=SHA(path.read_bytes()))
except Exception as error:q.update(status='FAILED_ACTUAL_CDE_CALENDAR_CONTEXT_NOT_QUALIFIED',error=repr(error));raise
finally:save()
print(q['status'],flush=True)
