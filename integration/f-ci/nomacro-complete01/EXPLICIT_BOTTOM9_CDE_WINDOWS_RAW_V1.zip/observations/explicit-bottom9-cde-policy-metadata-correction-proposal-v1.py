"""Correct only the descriptive paired-CDE trial policy after the frozen Win batch."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
p=R/'app/hybrid_water/cde_clock_output.py';raw=p.read_bytes();old=b"trial_receipt_policy='literal-original-independent-soil-candidate-bottom-cde-clock-v1',";new=b"trial_receipt_policy=('literal-original-all-node-prescribed-bottom-cde-clock-v1' if selected.get('paired_head_flux_cde_calendar') else 'literal-original-independent-soil-candidate-bottom-cde-clock-v1'),"
assert raw.count(old)==1 and new not in raw
p.write_bytes(raw.replace(old,new,1))
print('Only descriptive metadata label corrected; all execution and state construction bodies unchanged')
