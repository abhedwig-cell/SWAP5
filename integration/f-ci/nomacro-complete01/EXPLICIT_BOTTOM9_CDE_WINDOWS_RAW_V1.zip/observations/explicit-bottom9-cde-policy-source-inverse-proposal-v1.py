"""Bind the exact metadata-only correction without rebinding prior model results."""
import ast,subprocess
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
p=R/'tests/nomacro_drainage/explicit_bottom9_source_inverse.py';s=p.read_text()
a="CDE_CORE='dcf509f80e77866b24ca06a021df3e3e53fd3ec0'";assert s.count(a)==1;s=s.replace(a,a+"\nCDE_POLICY_CORE="+repr(sha),1)
old="trial_receipt_policy='literal-original-independent-soil-candidate-bottom-cde-clock-v1',";new="trial_receipt_policy=('literal-original-all-node-prescribed-bottom-cde-clock-v1' if selected.get('paired_head_flux_cde_calendar') else 'literal-original-independent-soil-candidate-bottom-cde-clock-v1'),"
anchor='def source_before_cde(path,raw):\n';assert s.count(anchor)==1
insert=" if path=='app/hybrid_water/cde_clock_output.py':\n  old="+repr(old.encode())+";new="+repr(new.encode())+"\n  assert raw.count(new)==1;raw=raw.replace(new,old,1)\n"
s=s.replace(anchor,anchor+insert,1)
s=s.replace("assert not git('diff',CDE_CORE,'--',*SURFACES)","assert not git('diff',CDE_POLICY_CORE,'--',*SURFACES)",1)
s=s.replace("assert raw==blob(CDE_CORE,path)","assert raw==blob(CDE_POLICY_CORE,path)",1)
a="assert before.keys()==after.keys() and {name for name in before if before[name]!=after[name]}=={expected}";assert s.count(a)==1
s=s.replace(a,"assert before.keys()==after.keys() and {name for name in before if before[name]!=after[name]}==({expected,'metadata'} if path=='app/hybrid_water/cde_clock_output.py' else {expected})",1)
a="def producer_epoch(sha):\n";assert s.count(a)==1;s=s.replace(a,a+" if not git('diff',CDE_POLICY_CORE,sha,'--',*SURFACES):return 'cde-calendar'\n",1)
compile(s,str(p),'exec');p.write_text(s,encoding='utf-8')
# The exact metadata correction is the only difference in the actual
# experimental source epoch. Keep the original producer category and raw IDs.
print('new exact metadata policy epoch',sha)
