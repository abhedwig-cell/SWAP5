"""Read-only proof: new CDE owner is unselected for every actual prior46 input."""
import ast,json,sys,types
from pathlib import Path
from contextlib import ExitStack
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from explicit_bottom9_archive_science import ReadView,CASES
from explicit_bottom9_source_inverse import complete_inverse,CDE_CORE,git,norm
import cde_clock_output,cde_interval_output
from experimental_project import switches
complete_inverse();modules=(cde_clock_output,cde_interval_output);functions=[]
for module in modules:
 raw=norm(Path(module.__file__).read_bytes());tree=ast.parse(raw)
 paired=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='paired_bottom' for t in n.targets))
 functions.append((module,types.FunctionType(module.active_selection.__code__,dict(vars(module),Path=lambda p:p)),paired.lineno))
with ExitStack() as stack:
 proof=R/'integration/f-ci/nomacro-complete01';stores={name:Archive(proof,name,stack) for name in ['EXPLICIT_BOTTOM9_WINDOWS_RAW_V1','EXPLICIT_BOTTOM9_UBUNTU_O0_RAW_V1','EXPLICIT_BOTTOM9_UBUNTU_O2_RAW_V1','EXPLICIT_BOTTOM9_LAST_NODE_WINDOWS_RAW_V1','EXPLICIT_BOTTOM9_LAST_NODE_UBUNTU_O0_RAW_V1','EXPLICIT_BOTTOM9_LAST_NODE_UBUNTU_O2_RAW_V1']};observations=[]
 def check(name,profile,input_store,input_prefix):
  store=stores[name];q=json.loads(store.get(profile+'/RESULT.json'));inputs=ReadView(stores[input_store],input_prefix)
  for filename,digest in q['input_inventory']:assert SHA((inputs/filename).read_bytes())==digest
  flags=switches((inputs/'swap.swp').read_text(encoding='cp1252'));project=types.SimpleNamespace(original_output=True,macro=False,input_directory=inputs,solute=flags['SWSOLU']>0,age=flags['SWSOLU']==2,time_step_policy='original-adaptive-day-seed-v1');calls=[]
  for module,fn,changed_line in functions:
   lines=[]
   def trace(frame,event,arg):
    if event=='line' and frame.f_code is fn.__code__:lines.append(frame.f_lineno)
    return trace
   prior=sys.gettrace();sys.settrace(trace)
   try:result=fn(project)
   finally:sys.settrace(prior)
   assert result is None and changed_line not in lines
   calls.append(dict(owner=module.__name__,selection=None,new_paired_condition_executed=False))
  if 'native_codec'in q:assert q['native_codec'] not in ('S5CIC001','S5CCC001')
  observations.append(dict(archive=name,profile=profile,source=q['source'],case=q.get('case'),optimization=q['optimization'],actual_input_hashes_verified=True,actual_prior_RESULT_sha256=SHA(store.get(profile+'/RESULT.json')),owners=calls))
 name='EXPLICIT_BOTTOM9_WINDOWS_RAW_V1'
 for role in stores[name].record['roles']+stores[name].record['water_controls']:check(name,role['profile'],name,role['inputs'])
 name='EXPLICIT_BOTTOM9_LAST_NODE_WINDOWS_RAW_V1'
 for role in stores[name].record['roles']:check(name,role['profile'],role['inputs_archive'],role['inputs'])
 for opt in ('O0','O2'):
  name='EXPLICIT_BOTTOM9_UBUNTU_'+opt+'_RAW_V1'
  for case in CASES:
   label='explicit-bottom9-'+case+'-'+opt+'-short';check(name,label,name,'inputs/'+case+('-initial2' if case=='cde-distributed-drain' else '-initial1'))
  name='EXPLICIT_BOTTOM9_LAST_NODE_UBUNTU_'+opt+'_RAW_V1';case='water-last-node-drainage';check(name,'explicit-bottom9-'+case+'-'+opt+'-short',name,'inputs/'+case+'-initial1')
 assert len(observations)==46
 result=dict(status='ACTUAL_PRIOR46_INPUTS_NEW_CDE_CALENDAR_OWNERS_RETURN_NONE_BEFORE_ANY_CHANGED_CONDITION_PASS',source=git('rev-parse','HEAD').decode().strip(),composition_source=CDE_CORE,observations=observations,compiler_executions=0,model_executions=0,prior_native_binding_or_producer_rewritten=False,whole_source_inverse_checked=True,canonical_admission=False)
 with (E/'EXPLICIT_BOTTOM9_CDE_PRIOR46_INHERITANCE_V1.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
 print(result['status'],flush=True)
