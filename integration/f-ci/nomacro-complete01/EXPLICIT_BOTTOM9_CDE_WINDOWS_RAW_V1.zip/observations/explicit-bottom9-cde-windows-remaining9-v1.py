"""Nine new Windows CDE9 contexts; completed O0 first context is reused unchanged."""
import json,os,subprocess,sys,time
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;W=E.parent
P=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');HEAD='ec40937ed483b6948eca15f29a6752df638342a1'
TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';TOOL='C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_source_inverse import complete_inverse,git,CDE_CORE
from explicit_bottom9_cde_calendar_inputs import CASES
from explicit_bottom9_cde_batch import execute
os.environ.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1',TEMP=str(W/'active-python-scratch'),TMP=str(W/'active-python-scratch'));os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH']
assert git('rev-parse','HEAD').decode().strip()==HEAD;complete_inverse()
record=E/'EXPLICIT_BOTTOM9_CDE_WINDOWS_REMAINING9_V1.json';assert not record.exists()
q=dict(status='RUNNING',actual_source=HEAD,composition_source=CDE_CORE,actual_first_completed_producer='3e0f10165ed67422ecfa7a0245d2c2b45a0af793',first_completed_profile=str(E/'explicit-bottom9-cde-subdaily-O0-v1'),contexts=[],canonical_admission=False,old_model_periods_replayed=0)
def save():record.write_text(json.dumps(q,indent=2)+'\n')
save()
try:
 for opt in ('O0','O2'):
  for case in CASES:
   if case=='cde-subdaily' and opt=='O0':continue
   assert git('rev-parse','HEAD').decode().strip()==HEAD
   label='explicit-bottom9-'+case+'-'+opt+'-v1';distributed=case=='cde-distributed-subdaily';postlabel=label+('-initial1-counterpart' if distributed else '-initial2-postimage');builds=[]
   for name in (label,postlabel):
    cmd=[sys.executable,'-B',TOOL,'allocate','--task',TASK,'--kind','build','--name',name,'--variant',opt,'--source-ref',HEAD,'--recipe','Target new CDE9 output calendar; original35days7native3cold daily6RHS private20+N; initial-selector wholecompiled counter; '+opt]
    a=subprocess.run(cmd,cwd=R,capture_output=True,text=True,check=True);(E/(name+'-allocation.json')).write_text(a.stdout);builds.append(Path(json.loads(a.stdout)['path']))
   item=execute(case,opt,E/(label+'-inputs'),P,*builds,E/label,E/postlabel);q['contexts'].append(item);save();print('NEW_CONTEXT_COMPLETE',case,opt,len(q['contexts']),flush=True)
 q['status']='ACTUAL_REMAINING_NINE_CDE9_WINDOWS_CONTEXTS_SCIENCE_NATIVE_COLD_WHOLE_COMPILED_PASS_PENDING_CENTRAL_CUSTODY_AND_UBUNTU'
except Exception as error:q.update(status='FAILED_ACTUAL_NEW_CDE9_BATCH_NOT_QUALIFIED',error=repr(error));raise
finally:save()
print(q['status'],flush=True)
