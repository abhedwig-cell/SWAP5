"""Seal real PR1790 admission only after final controls/CI/canonical observations."""
import argparse,hashlib,json,subprocess,zipfile
from pathlib import Path

CANDIDATE='2c4ef457491d99ca03b42dfca5af116a1d293980'
PARENT='4d39e97d2f257f70b6fc108c62eb5efce9967a42'
SOURCE_ANCHOR='cd02860f0f17f89bd44d52d8078bbcd38cc66acf'
STATUS='BOUNDED_ORIGINAL_ANALYTICAL_SNOW_HISTORY_PAIRED9_SOURCE_RAW_NATIVE_AND_WHOLE_COMPILED_POSTIMAGES_PASS'
CONTRACT_SHA='6a5d1a412f545cb739a9ba4ed356a81ca5ddf507b78be0228137116a5557ee00'
PARENT_ADMISSION_SHA='9b39b63653e17886bdd8a21560d955001057a24a88bd2e5e06bfd4c824a07d37'
SHA=lambda raw:hashlib.sha256(raw).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    for key in ('repository','evidence'):parser.add_argument('--'+key,type=Path,required=True)
    args=parser.parse_args();root,evidence=args.repository,args.evidence
    proof=root/'integration/f-ci/nomacro-complete01'
    git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode().strip()
    files={}
    def keep(name):
        path=evidence/name
        assert path.is_file() and not path.is_symlink()
        files[name]=path
        return path
    def load(name):return json.loads(keep(name).read_text())
    pre=load('EXPLICIT_BOTTOM9_COMBINED_PR1790_IMMEDIATE_PREMERGE_V1.json')
    assert pre['head']['sha']==CANDIDATE and pre['base']['sha']==PARENT and pre['mergeable'] and not pre['draft']
    synthetic=pre['merge_commit_sha'];assert len(synthetic)==40
    merged=load('EXPLICIT_BOTTOM9_COMBINED_PR1790_ACTUAL_MERGE_API_V1.json')
    assert merged['merged'];canonical=merged['sha'];assert len(canonical)==40
    tree=git('rev-parse',CANDIDATE+'^{tree}')
    for commit in (synthetic,canonical):
        assert git('show','-s','--format=%P',commit).split()==[PARENT,CANDIDATE]
        assert git('rev-parse',commit+'^{tree}')==tree
    negatives=load('EXPLICIT_BOTTOM9_COMBINED_FINAL_NEGATIVES_V6.json')
    assert negatives['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
    assert negatives['candidate']==CANDIDATE and negatives['never_merge'] and len(negatives['controls'])==4
    expected={'SOURCE':'app/hybrid_water/prescribed_head_flux_boundary.py',
              'RAW':'integration/f-ci/nomacro-complete01/CANONICAL_LEGACY_ORIGINAL_ORACLES_RAW_V1.zip',
              'INHERITED':'integration/f-ci/nomacro-complete01/INITIAL_PROFILE_FROST_ADMISSION_RAW_V1.zip',
              'PUBLICATION':'docs/publication/P2E09_REFERENCE_ONLY_THRESHOLD_FREEZE_PREREGISTRATION.json'}
    assert {q['role']:q['path'] for q in negatives['controls']}==expected
    observations={}
    positive_labels=[('EXPLICIT_BOTTOM9_COMBINED_CANDIDATE_PUBLIC_V5',CANDIDATE),
                     ('EXPLICIT_BOTTOM9_COMBINED_ACTUAL_CANONICAL_PUBLIC_V1',canonical)]
    fixtures=patterns=None
    for label,head in positive_labels:
        q=load(label+'.json');raw=keep(label+'.stdout.txt').read_bytes();err=keep(label+'.stderr.txt').read_bytes()
        assert q['status']=='ACTUAL_PUBLIC_COMMAND_RETURNED' and q['returncode']==0 and not err
        assert q['before']==q['after'] and q['before']['head']==head and q['before']['tree']==tree
        assert not q['before']['status'] and len(q['before']['sparse'])==14 and len(q['before']['original_project_files'])==56
        assert q['command'][-1]=='tests/hupsel51/verify_successor.py' and q['compiler_executions']==q['model_executions']==0
        if fixtures is None:fixtures,patterns=q['before']['original_project_files'],q['before']['sparse']
        else:assert fixtures==q['before']['original_project_files'] and patterns==q['before']['sparse']
        r=json.loads(raw);assert r['status']==STATUS and r['compiler_executions']==r['model_executions']==0
        stats=r['coadmission'];assert stats['contexts']==280 and stats['short35_contexts']==278 and stats['year367_contexts']==2
        assert stats['native_calendar_samples']==1966 and stats['exact_cold_windows']==844
        assert stats['compiled_initialization_postimages']==223 and stats['integrated_compiler_preservation_postimages']==88
        assert stats['standalone_AGE110_admission_claimed'] is False
        assert r['functional_completion']=='PARTIAL' and r['whole_scientific_equivalence']=='NOT_QUALIFIED' and r['RC3_changed'] is False
        src=r['inherited_fresh_source'];assert src['actual_head']==head and src['source_anchor']==SOURCE_ANCHOR and not src['actual_Git_or_filesystem_views_projected']
        assert len(src['additional_publication_document_custody']['files'])==304
        assert not r['inherited_fresh_bytes']['scientific_bytes_cached_or_projected'] and len(r['actual_current_raw_custody'])==18
        observations[label]=q
    for item in negatives['controls']:
        assert item['actual_refusal'] and item['never_merge'] and item['exact_parent']==CANDIDATE
        assert git('show','-s','--format=%P',item['head'])==CANDIDATE
        assert git('diff','--name-only',CANDIDATE,item['head'])==item['path']
        assert git('ls-remote','origin','refs/heads/'+item['branch']).split()[0]==item['head']
        label='EXPLICIT_BOTTOM9_COMBINED_FINAL_'+item['role']+'_NEGATIVE_PUBLIC_V6'
        q=load(label+'.json');keep(label+'.stdout.txt');err=keep(label+'.stderr.txt').read_bytes()
        assert q['status']=='ACTUAL_PUBLIC_COMMAND_RETURNED' and q['returncode'] not in (None,0) and b'AssertionError' in err
        assert q['before']==q['after'] and q['before']['head']==item['head'] and not q['before']['status']
        assert q['before']['sparse']==patterns and q['before']['original_project_files']==fixtures
        for suffix in ('.stdout.txt','.stderr.txt'):keep('EXPLICIT_BOTTOM9_COMBINED_FINAL_'+item['role']+'_NEGATIVE_PUSH_V6'+suffix)
    for label,head in [('EXPLICIT_BOTTOM9_COMBINED_CANDIDATE_PUBLICATION_V5',CANDIDATE),
                       ('EXPLICIT_BOTTOM9_COMBINED_ACTUAL_CANONICAL_PUBLICATION_V1',canonical)]:
        q=load(label+'.json');out=keep(label+'.stdout.txt').read_text();err=keep(label+'.stderr.txt').read_bytes()
        assert q['before']==q['after'] and q['before']['head']==head and q['before']['sparse']==patterns
        assert q['before']['original_project_files']==fixtures and not q['before']['status'] and q['returncode']==0 and not err
        assert 'PUBLICATION_REPLAY_SELECTED=false' in out and q['compiler_executions']==q['model_executions']==0
    label='EXPLICIT_BOTTOM9_COMBINED_FINAL_PUBLICATION_NEGATIVE_SCOPE_V6'
    q=load(label+'.json');assert q['before']==q['after'] and q['returncode']==0 and not keep(label+'.stderr.txt').read_bytes()
    assert 'PUBLICATION_REPLAY_SELECTED=true' in keep(label+'.stdout.txt').read_text()
    checks=load('EXPLICIT_BOTTOM9_COMBINED_FINAL_ALL_TERMINAL_CHECKS_V1.json')
    assert checks['total_count']==len(checks['check_runs'])==len({q['id'] for q in checks['check_runs']}) and checks['total_count']>=45
    assert all(q['head_sha']==CANDIDATE and q['status']=='completed' and q['conclusion'] in ('success','skipped') for q in checks['check_runs'])
    runs=load('EXPLICIT_BOTTOM9_COMBINED_FINAL_ALL_TERMINAL_RUNS_V1.json')
    assert runs['total_count']==len(runs['workflow_runs'])==17
    assert all(q['head_sha']==CANDIDATE and q['status']=='completed' and q['conclusion']=='success' for q in runs['workflow_runs'])
    legacy=load('EXPLICIT_BOTTOM9_COMBINED_FINAL_COMMIT_STATUSES_V1.json')
    assert legacy['total_count']==len(legacy['statuses']) and all(q['state']=='success' for q in legacy['statuses'])
    ci=load('EXPLICIT_BOTTOM9_COMBINED_FINAL_ORIGINAL_CI_LOGS_V1.json')
    assert ci['candidate']==CANDIDATE and len(ci['logs'])>=2
    for item in ci['logs']:
        raw=keep(item['file']).read_bytes();assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
        assert CANDIDATE in raw.decode() and STATUS in raw.decode()
    contract='EXPLICIT_BOTTOM9_COMBINED_COADMISSION_CONTRACT_V1.json'
    raw=(proof/contract).read_bytes().replace(b'\r\n',b'\n');assert SHA(raw)==CONTRACT_SHA and json.loads(raw)['parent_admission_sha256']==PARENT_ADMISSION_SHA
    for name in (contract,'EXPLICIT_BOTTOM9_MERGE_RECEIPT_V1.json','EXPLICIT_BOTTOM9_ADMISSION_RAW_V1.json'):
        assert (proof/name).read_bytes().replace(b'\r\n',b'\n')==subprocess.check_output(['git','show',CANDIDATE+':integration/f-ci/nomacro-complete01/'+name],cwd=root)
        files['neutral-'+name]=proof/name
    # Original scientific/CI artifact ZIPs are already preserved once centrally;
    # admission stores their identity, not additional copies of those payloads.
    for path in evidence.iterdir():
        if not path.is_file():continue
        name=path.name
        wanted=name.startswith(('EXPLICIT_BOTTOM9_COMBINED_CANDIDATE_PUBLIC','EXPLICIT_BOTTOM9_COMBINED_FINAL_',
                                'EXPLICIT_BOTTOM9_COMBINED_ACTUAL_CANONICAL','EXPLICIT_BOTTOM9_COMBINED_PR1790',
                                'EXPLICIT_BOTTOM9_COMBINED_PUBLICATION_DOCUMENT','EXPLICIT_BOTTOM9_COMBINED_ORIGINAL_WORKFLOW',
                                'EXPLICIT_BOTTOM9_COMBINED_SUPERSEDED'))
        if wanted and path.suffix in ('.json','.txt','.log'):files.setdefault(name,path)
    files['negative-v6-preexecution-repair.json']=evidence/'EXPLICIT_BOTTOM9_COMBINED_NEGATIVE_V6_PREEXECUTION_REPAIR_V1.json'
    files['negative-v6-unexecuted-suffix-snapshot.py']=evidence/'explicit-bottom9-combined-negative-v6-preexecution-suffix-snapshot.py'
    files['actual-sealer.py']=Path(__file__)
    files['actual-negative-controller-v6.py']=evidence/'explicit-bottom9-combined-actual-negative-controls-v6.py'
    files['negative-v3-setup-failure-and-v4-recovery.json']=evidence/'EXPLICIT_BOTTOM9_COMBINED_NEGATIVE_V3_SETUP_FAILURE_AND_V4_RECOVERY_V1.json'
    files['original-failed-controller-v3.py']=root/'tests/nomacro_drainage/explicit_bottom9_combined_negative_controls_v3.py'
    name='EXPLICIT_BOTTOM9_COMBINED_ADMISSION_RAW_V1';archive=proof/(name+'.zip')
    assert not archive.exists() and not archive.with_suffix('.json').exists()
    members={key:dict(bytes=path.stat().st_size,sha256=SHA(path.read_bytes())) for key,path in files.items()}
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as store:
        for key,path in sorted(files.items()):store.write(path,key)
    with zipfile.ZipFile(archive) as store:
        assert len(store.namelist())==len(set(store.namelist()))==len(members)
        for key,item in members.items():
            raw=store.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
    raw=archive.read_bytes();assert len(raw)<90*1024*1024
    record=dict(status='ACTUAL_CANONICAL_280CONTEXT_ANALYTICAL_SNOW_HISTORY_PAIRED9_ADMISSION_RAW_SEALED',
                canonical=canonical,candidate=CANDIDATE,source_anchor=SOURCE_ANCHOR,ordered_parents=[PARENT,CANDIDATE],
                full_tree=tree,archive=archive.name,bytes=len(raw),sha256=SHA(raw),members=members,
                parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],canonical_admission=True,
                parent216_admission_sha256=PARENT_ADMISSION_SHA,neutral_scientific_archives_changed=False)
    archive.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
    receipt=dict(status='ACTUAL_CANONICAL_280CONTEXT_ANALYTICAL_SNOW_HISTORY_PAIRED9_ADMISSION_VERIFIED',
                 PR=1790,previous_canonical=PARENT,qualified_head=CANDIDATE,source_anchor=SOURCE_ANCHOR,
                 synthetic_merge=synthetic,actual_merge=canonical,ordered_parents=[PARENT,CANDIDATE],whole_qualified_tree=tree,
                 all_terminal_PR_checks=checks['total_count'],all17workflow_runs_success=True,
                 actual_candidate_public_seconds=observations[positive_labels[0][0]]['seconds'],
                 actual_canonical_public_seconds=observations[positive_labels[1][0]]['seconds'],
                 admission_archive_sha256=SHA(raw),canonical_admission=True,contexts=280,new_contexts=64,
                 native_calendar_samples=1966,exact_cold_windows=844,compiled_initialization_postimages=223,
                 integrated_compiler_preservation_postimages=88,standalone_AGE110_admission_claimed=False,
                 fresh_compiler_executions_in_observers=0,fresh_model_executions_in_observers=0,
                 whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',
                 global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
    (proof/'EXPLICIT_BOTTOM9_COMBINED_MERGE_RECEIPT_V1.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(record['status'],len(raw),SHA(raw),len(members),flush=True)


if __name__=='__main__':main()
