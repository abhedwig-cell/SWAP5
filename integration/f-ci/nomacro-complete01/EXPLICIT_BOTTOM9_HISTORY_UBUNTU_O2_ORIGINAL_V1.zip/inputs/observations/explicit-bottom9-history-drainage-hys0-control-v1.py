"""One-day causal control: identical refused CDE drainage input, hysteresis0."""
import json,re,subprocess,sys,time,shutil
from pathlib import Path
R=Path.cwd();E=Path(__file__).parent;sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_runtime import m
from analytical_hydraulic_archives import SHA
P=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();out=E/'explicit-bottom9-history-drainage-hys0-control-O0-v1';out.mkdir();inputs=out/'input';shutil.copytree(E/'explicit-bottom9-history-drainage-inputs-v2/cde-hys1-initial1',inputs)
p=inputs/'swap.swp';raw=p.read_bytes();changed,n=re.subn(rb'(?mi)^([ \t]*SWHYST[ \t]*=[ \t]*)1',rb'\g<1>0',raw);assert n==1;p.write_bytes(changed)
project=m.e.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
tool=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py')
allocation=json.loads(subprocess.check_output([sys.executable,'-B',str(tool),'allocate','--task','01a1e8b4-228b-75f1-8ac4-b07ca1e15713','--kind','build','--name','explicit-bottom9-history-drainage-hys0-control-O0-v1','--variant','O0','--source-ref',source,'--recipe','One actual one-day CDE paired9 SWDIVD1 causal control; only SWHYST1->0; current unchanged original process bodies; O0'],text=True));build=Path(allocation['path'])/'bundle'
q=dict(status='RUNNING',actual_source=source,input_root=str(inputs),input_inventory=m.e.inventory(inputs),build_root=str(build),allocation=allocation,one_input_change='Exact SWHYST selector1->0 only',scientific_admission=False,days_requested=1)
def save():(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
save();started=time.perf_counter()
try:
 command=[sys.executable,'-B','tools/solute/run_water.py','--model',project.model,'--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy',project.time_step_policy,'--reference-work',str(P),'--build-only','--donor-opt','O0','--kernel-opt','O0','--output',str(build)]
 with (out/'build.stdout').open('x') as stdout,(out/'build.stderr').open('x') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,cwd=R,timeout=300)
 r.check_returncode();assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source;q['actual_BUILD_sha256']=SHA((build/'BUILD.json').read_bytes());m.validate_bundle(build,P,project)
 q['trajectory'],data=m.trajectory(build,P,project,out/'trajectory',1,{1},120);q['status']='ONE_DAY_UNCHANGED_HYSTERESIS0_CAUSAL_CONTROL_PASSED_NOT_A_QUALIFICATION'
except Exception as error:q.update(status='ONE_DAY_UNCHANGED_HYSTERESIS0_CAUSAL_CONTROL_REFUSED_NO_SCIENTIFIC_ADMISSION',error=repr(error))
finally:q['seconds']=time.perf_counter()-started;save()
print(q['status'],q.get('error',''),flush=True)
