"""Bind active original drainage9 to the same existing hydraulic history batch."""
import json,re,sys,subprocess
from pathlib import Path
from contextlib import ExitStack
R=Path.cwd();E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_analytical_parent_postimages import role,materialize
from analytical_hydraulic_archives import SHA
import experimental_project as e
from prescribed_history_boundary import selection
root=E/'explicit-bottom9-history-drainage-inputs-v2';root.mkdir();observed=[]
with ExitStack() as stack:
 archive,inputs,item,q,old=role(R/'integration/f-ci/nomacro-complete01','water-last-node-drainage','O0',stack)
 for kind in ('water','cde'):
  for mode in (1,2):
   for initial in (1,2):
    out=root/(kind+'-hys'+str(mode)+'-initial'+str(initial));inventory=materialize(inputs,item['inputs'],out,q['input_inventory']);p=out/'swap.swp';text=p.read_bytes().decode('cp1252')
    for key,value in [('SWHYST',mode),('SWINCO',initial),('SWSOLU',int(kind=='cde'))]:
     text,n=re.subn(r'(?mi)^([ \t]*'+key+r'[ \t]*=[ \t]*)[^!\r\n]*',lambda m:m[1]+str(value)+' ',text);assert n==1
    p.write_bytes(text.encode('cp1252'))
    if kind=='cde':
     dra=out/'swap.dra';raw=dra.read_bytes();raw,n=re.subn(rb'(?mi)^([ \t]*SWDIVD[ \t]*=[ \t]*)0',rb'\g<1>1',raw);assert n==1;dra.write_bytes(raw)
    project=e.load(out,original_output=True,time_step_policy='original-adaptive-day-seed-v1');selected=selection(out);assert selected and selected['drainage']==1
    observed.append(dict(kind=kind,hysteresis=mode,initial=initial,input_root=str(out),source_archive=archive.record['archive'],source_archive_sha256=archive.record['sha256'],actual_original_inventory=inventory,actual_new_inventory=e.inventory(out),changed_input_paths=[name for name in inventory if inventory[name]!=SHA((out/name).read_bytes())]))
    assert set(observed[-1]['changed_input_paths'])==({'swap.swp','swap.dra'} if kind=='cde' else {'swap.swp'})
q=dict(status='EIGHT_ACTIVE_DRAINAGE9_HISTORY_FRONTEND_CONTEXTS_PREPARED_NOT_SCIENTIFICALLY_QUALIFIED',actual_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),inputs=observed,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_HISTORY_DRAINAGE_INPUTS_V2.json').open('x') as f:json.dump(q,f,indent=2)
print(q['status'],len(observed))
