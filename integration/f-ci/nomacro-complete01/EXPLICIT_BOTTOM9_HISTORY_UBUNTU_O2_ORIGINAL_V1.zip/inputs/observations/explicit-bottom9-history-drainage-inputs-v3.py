"""Use actual accepted CDE/drainage reference inputs; retain saturated refusal."""
import json,re,sys,subprocess,shutil
from pathlib import Path
from contextlib import ExitStack
R=Path.cwd();E=Path(__file__).parent;sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
import experimental_project as e
from prescribed_history_boundary import selection
root=E/'explicit-bottom9-history-drainage-inputs-v3';root.mkdir();rows=[]
with ExitStack() as stack:
 store=Archive(R/'integration/f-ci/nomacro-complete01','EXPLICIT_BOTTOM9_CDE_UBUNTU_DRAIN_O0_RAW_V1',stack)
 for kind in ('water','cde'):
  for mode in (1,2):
   for initial in (1,2):
    label=kind+'-hys'+str(mode)+'-initial'+str(initial);out=root/label
    if kind=='water':
     source=E/'explicit-bottom9-history-drainage-inputs-v2'/label;shutil.copytree(source,out);original=e.inventory(source);origin='EXPLICIT_BOTTOM9_LAST_NODE_WINDOWS_RAW_V1'
    else:
     prefix='inputs/cde-distributed-subdaily-initial1/';out.mkdir();original=[]
     for name in store.names:
      if not name.startswith(prefix):continue
      raw=store.get(name);target=out/name[len(prefix):];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);original.append((name[len(prefix):],SHA(raw)))
     origin=store.record['archive'];p=out/'swap.swp';text=p.read_bytes().decode('cp1252')
     for key,value in [('SWHYST',mode),('SWINCO',initial),('NPRINTDAY',1)]:
      text,n=re.subn(r'(?mi)^([ \t]*'+key+r'[ \t]*=[ \t]*)[^!\r\n]*',lambda m:m[1]+str(value)+' ',text);assert n==1
     p.write_bytes(text.encode('cp1252'))
    project=e.load(out,original_output=True,time_step_policy='original-adaptive-day-seed-v1');selected=selection(out);assert selected and selected['drainage']==1
    rows.append(dict(kind=kind,hysteresis=mode,initial=initial,input_root=str(out),source_archive=origin,actual_original_inventory=original,actual_new_inventory=e.inventory(out),new_cde_source_archive_sha256=store.record['sha256'] if kind=='cde' else None))
q=dict(status='EIGHT_HISTORY9_DRAINAGE_INPUTS_ACTUAL_ACCEPTED_CDE_REFERENCE_AND_UNCHANGED_WATER_REFERENCE_PREPARED_NOT_ADMITTED',actual_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),inputs=rows,earlier_saturated_input_refusal='V2 CDE initialh=0/zero bottom exchange with distributed drainage refused before firstday; exact sameinput with SWHYST0 also refused; both actual failures retained, not relabelled as a hysteresis defect or waived',compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_HISTORY_DRAINAGE_INPUTS_V3.json').open('x') as f:json.dump(q,f,indent=2)
print(q['status'],len(rows))
