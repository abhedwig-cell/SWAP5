"""Retain actual unsupported composition descriptors and frontend refusals."""
import json,re,shutil,sys,subprocess
from pathlib import Path
R=Path.cwd();E=Path(__file__).parent;sys.path.insert(0,str(R/'app/hybrid_water'))
import experimental_project as e
source=E/'explicit-bottom9-history-inputs-v1/water-hys1-initial1';root=E/'explicit-bottom9-history-frontend-controls-v1';root.mkdir()
attacks=[('SWINCO',3),('SWKIMPL',1),('SWSOLU',2),('IHWCKMODEL',3),('SWVAPOR',1),('SWFROST',1),('SWSNOW',1),('SWBR',1),('SWMETDETAIL',1),('SWSOPHY',1),('SWHEA',0),('SWCALT',1),('SWBBCFILE',1),('PERIOD',3),('SWMONTH',1),('NPRINTDAY',2),('SWRES',0),('SWODAT',1),('FLPRINTDT','.TRUE.'),('SWHYST',3),('DUPLICATE_SWHYST',1)]
rows=[]
for key,value in attacks:
 target=root/key;shutil.copytree(source,target);p=target/'swap.swp';text=p.read_bytes().decode('cp1252')
 if key=='DUPLICATE_SWHYST':text+='\nSWHYST = 1\n'
 else:
  text,n=re.subn(r'(?mi)^([ \t]*'+key+r'[ \t]*=[ \t]*)[^!\r\n]*',lambda m:m[1]+str(value)+' ',text);assert n in (0,1)
  if n==0:text+='\n'+key+' = '+str(value)+'\n'
 p.write_bytes(text.encode('cp1252'))
 try:e.load(target,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
 except ValueError as error:rows.append(dict(key=key,value=value,input_root=str(target),actual_refusal=str(error),actual_inventory=e.inventory(target)))
 else:raise AssertionError('Unsupported history9 selector accepted: '+key)
q=dict(status='ALL21_ACTUAL_UNQUALIFIED_HISTORY9_FRONTEND_COMPOSITIONS_REFUSED',actual_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),refusals=rows,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_HISTORY_FRONTEND_CONTROLS_V1.json').open('x') as f:json.dump(q,f,indent=2)
print(q['status'])
