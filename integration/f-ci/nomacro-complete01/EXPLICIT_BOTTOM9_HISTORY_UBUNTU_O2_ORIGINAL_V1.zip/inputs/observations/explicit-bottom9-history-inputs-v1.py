"""Derive exact paired9 pressure inputs with existing original hysteresis."""
import json,re,sys,subprocess,hashlib
from pathlib import Path
from contextlib import ExitStack
R=Path.cwd();E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_analytical_parent_postimages import role,materialize
from analytical_hydraulic_archives import SHA
import experimental_project as e
from prescribed_history_boundary import selection
from original_output_hysteresis import metadata

root=E/'explicit-bottom9-history-inputs-v1';root.mkdir();observed=[]
with ExitStack() as stack:
 for kind in ('water','cde'):
  archive,inputs,item,q,old=role(R/'integration/f-ci/nomacro-complete01',kind+'-pressure-daily','O0',stack)
  for mode in (1,2):
   for initial in (1,2):
    out=root/(kind+'-hys'+str(mode)+'-initial'+str(initial));old_inventory=materialize(inputs,item['inputs'],out,q['input_inventory'])
    p=out/'swap.swp';raw=p.read_bytes();text=raw.decode('cp1252')
    for key,value in [('SWHYST',mode),('SWINCO',initial)]:
     text,n=re.subn(r'(?mi)^([ \t]*'+key+r'[ \t]*=[ \t]*)[^!\r\n]*',lambda m:m[1]+str(value)+' ',text);assert n==1,(key,n)
    p.write_bytes(text.encode('cp1252'));project=e.load(out,original_output=True,time_step_policy='original-adaptive-day-seed-v1');assert selection(out) is not None
    observed.append(dict(kind=kind,hysteresis=mode,initial=initial,input_root=str(out),source_archive=archive.record['archive'],source_archive_sha256=archive.record['sha256'],actual_original_inventory=old_inventory,actual_new_inventory=e.inventory(out),metadata=metadata(project),changed_input_paths=[name for name in old_inventory if old_inventory[name]!=SHA((out/name).read_bytes())]))
    assert observed[-1]['changed_input_paths']==['swap.swp']
q=dict(status='EIGHT_ACTUAL_PAIRED9_HISTORY_INPUTS_NEW_FRONTEND_ACCEPTED_NO_BUILDS_OR_MODEL_PERIODS',actual_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),inputs=observed,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_HISTORY_INPUTS_V1.json').open('x') as f:json.dump(q,f,indent=2)
print(q['status'],len(observed),flush=True)
