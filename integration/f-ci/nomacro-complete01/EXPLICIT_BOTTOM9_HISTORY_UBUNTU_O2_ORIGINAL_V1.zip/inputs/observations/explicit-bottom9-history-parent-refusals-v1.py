"""Observe real unchanged parent refusals, restoring the same sole checkout."""
import json,subprocess,hashlib
from pathlib import Path
R=Path.cwd();E=Path(__file__).parent
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
branch=git('branch','--show-current');head=git('rev-parse','HEAD');parent=git('rev-parse','codex/nomacro-explicit-bottom9-analytical01')
fixtures={p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'reference/projects').rglob('*') if p.is_file()};assert len(fixtures)==56
code="""import sys,json,subprocess
from pathlib import Path
R=Path.cwd();sys.path[:0]=[str(R/'app/hybrid_water')]
import experimental_project as e
E=Path(sys.argv[1]);q=json.loads((E/'EXPLICIT_BOTTOM9_HISTORY_INPUTS_V1.json').read_text());rows=[]
for item in q['inputs']:
 try:e.load(Path(item['input_root']),original_output=True,time_step_policy='original-adaptive-day-seed-v1')
 except ValueError as error:rows.append(dict(kind=item['kind'],hysteresis=item['hysteresis'],initial=item['initial'],actual_refusal=str(error)))
 else:raise AssertionError('Unchanged actual parent unexpectedly accepted history9')
print(json.dumps(dict(actual_parent_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),refusals=rows)))
"""
try:
 subprocess.run(['git','switch','--detach',parent],cwd=R,check=True)
 assert git('rev-parse','HEAD')==parent
 result=subprocess.run(['python','-B','-c',code,str(E)],cwd=R,text=True,capture_output=True,timeout=90)
 (E/'EXPLICIT_BOTTOM9_HISTORY_ACTUAL_PARENT_REFUSALS_V1.stdout.txt').write_text(result.stdout)
 (E/'EXPLICIT_BOTTOM9_HISTORY_ACTUAL_PARENT_REFUSALS_V1.stderr.txt').write_text(result.stderr)
 result.check_returncode();q=json.loads(result.stdout);assert q['actual_parent_head']==parent and len(q['refusals'])==8
finally:
 subprocess.run(['git','switch',branch],cwd=R,check=True)
 assert git('rev-parse','HEAD')==head and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
 assert {p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'reference/projects').rglob('*') if p.is_file()}==fixtures
q.update(status='ALL8_ACTUAL_UNCHANGED_PARENT_HISTORY9_FRONTEND_REFUSALS_AND_EXACT_SAME_CHECKOUT_RESTORATION',restored_actual_head=head,restored_branch=branch,all56_actual_reference_fixture_sha256=fixtures,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_HISTORY_ACTUAL_PARENT_REFUSALS_V1.json').open('x') as f:json.dump(q,f,indent=2)
print(q['status'],parent,head)
