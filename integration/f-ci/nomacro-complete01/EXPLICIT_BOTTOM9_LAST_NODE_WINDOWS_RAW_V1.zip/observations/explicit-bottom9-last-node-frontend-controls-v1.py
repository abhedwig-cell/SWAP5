"""Actual bounded file ownership, historical solute refusal and retained guards."""
import json,shutil,sys
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_source_inverse import complete_inverse,git,LAST_NODE_CORE
from original_output_baseline import assignment
import experimental_project as e
complete_inverse();head=git('rev-parse','HEAD').decode().strip();assert head=='31837609d478a2d55781b30df76deb03fd20a8f1'
root=E/'explicit-bottom9-last-node-frontend-controls-v1';root.mkdir();source=E/'explicit-bottom9-active-drain-water-initial1-v1';checks=[]
def change(path,key,value):path.write_bytes(assignment(path.read_bytes().decode('cp1252'),key,value).encode('cp1252'))
cases=[('selected-file-in-subfolder',None,True),('CDE-original-DIVD0-hard-refusal',('SWSOLU',1),False),('AGE-original-DIVD0-hard-refusal',('SWSOLU',2),False),('active-macro',('SWMACRO',1),False),('other-bottom-not-widened',('SWBOTB',5),False),('unused-drain-does-not-own-new-scope',None,False),('unqualified-other-drainage-structure',None,False),('implicit9-original-not-implemented',('SWKIMPL',1),False),('other-initial-owner-not-widened',('SWINCO',3),False)]
for label,mutation,positive in cases:
 directory=root/label;shutil.copytree(source,directory)
 if mutation:change(directory/'swap.swp',*mutation)
 if label=='selected-file-in-subfolder':
  target=directory/'drain/laterals.dra';target.parent.mkdir();(directory/'swap.dra').rename(target);change(directory/'swap.swp','PATHDRAIN',"'drain/'");change(directory/'swap.swp','DRFIL',"'laterals'")
 elif label=='unused-drain-does-not-own-new-scope':
  shutil.copyfile(directory/'swap.dra',directory/'unused.dra');change(directory/'swap.dra','SWDIVD',1)
 elif label=='unqualified-other-drainage-structure':change(directory/'swap.dra','SWDISLAY',1)
 inventory=e.inventory(directory)
 try:project=e.load(directory,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
 except ValueError as error:
  assert not positive,(label,error)
  if label in ('CDE-original-DIVD0-hard-refusal','AGE-original-DIVD0-hard-refusal','unused-drain-does-not-own-new-scope','unqualified-other-drainage-structure'):assert 'Drainage process/state combination is not implemented' in str(error),(label,error)
  item=dict(label=label,status='ACTUAL_PUBLIC_LOAD_REFUSED',error=str(error))
 else:
  assert positive,label;item=dict(label=label,status='ACTUAL_SELECTED_DRAINAGE_FILE_IN_SUBFOLDER_LOADED',case=project.case,native_codec=e.auxiliary_magic(project).decode())
 assert inventory==e.inventory(directory)
 item.update(input_root=str(directory),input_inventory=inventory);checks.append(item);print(label,item['status'],flush=True)
q=dict(status='ACTUAL_LAST_NODE_WATER_SELECTED_DRAINAGE_FILE_OWNERSHIP_AND_EIGHT_RETAINED_HARD_BOUNDARIES_PASS',source=head,input_admission_core=LAST_NODE_CORE,checks=checks,compiler_executions=0,model_executions=0,original_DIVD0_solute_refusal_retained=True,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_LAST_NODE_FRONTEND_CONTROLS_V1.json').open('x') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],flush=True)
