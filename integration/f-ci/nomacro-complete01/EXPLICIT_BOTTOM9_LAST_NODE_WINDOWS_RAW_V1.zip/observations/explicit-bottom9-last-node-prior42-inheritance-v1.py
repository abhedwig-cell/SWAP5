"""Prove the new incoming guard is unselected for all42 preserved contexts."""
import ast,json,sys
from pathlib import Path
from contextlib import ExitStack
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from explicit_bottom9_source_inverse import complete_inverse,checked_last_node_delta,LAST_NODE_CORE,CORE,ADAPTER,git
from groundwater_water_output import metadata
import experimental_project as e
complete_inverse();checked_last_node_delta()
source=ast.parse((R/ADAPTER).read_text());assignments=[n for n in ast.walk(source) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='paired_last_node_water' for t in n.targets)];assert len(assignments)==1
predicate=compile(ast.Expression(assignments[0].value),'actual-literal-new-water-drain-admission','eval')
observed=[]
with ExitStack() as stack:
 store=Archive(R/'integration/f-ci/nomacro-complete01','EXPLICIT_BOTTOM9_WINDOWS_RAW_V1',stack);projection=json.loads(store.get('COMPILED_PROJECTION_V1.json'))
 for role in store.record['roles']+store.record['water_controls']:
  q=json.loads(store.get(role['profile']+'/RESULT.json'));path=Path(q['input_root']);text=(path/'swap.swp').read_text(encoding='cp1252');selected=e.switches(text);project=e.load(path,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
  inventory=dict(project.input_inventory);old=q['input_inventory'];assert inventory==dict(old)
  meta=json.loads(store.get(projection[q['build_root']]['archive_prefix']+'/BUILD.json'))
  assert {key:getattr(project,key) for key in meta['project']}==meta['project']
  assert metadata(project)==meta['identity']['original_output'] and e.auxiliary_magic(project).decode()==q.get('native_codec','S5IOW001')
  for file in path.rglob('*.dra'):
   body=file.read_text(encoding='cp1252');sig=e.switches(body)
   namespace=dict(paired_boundary={},selected=selected,sig=sig,path=file,directory=path,text=text,one=e.one)
   assert eval(predicate,namespace) is False
  observed.append(dict(archive='EXPLICIT_BOTTOM9_WINDOWS_RAW_V1',profile=role['profile'],actual_original_producer=q['source'],new_pure_admission_predicate_selected=False,actual_project_case_native_codec_original_output_metadata_and_inputs_unchanged=True,original_BUILD_sha256=SHA(store.get(projection[q['build_root']]['archive_prefix']+'/BUILD.json'))))
 for opt in ('O0','O2'):
  store=Archive(R/'integration/f-ci/nomacro-complete01','EXPLICIT_BOTTOM9_UBUNTU_'+opt+'_RAW_V1',stack)
  for case in ('water-pressure-step','cde-distributed-drain','age-pressure-subdaily'):
   label='explicit-bottom9-'+case+'-'+opt+'-short';q=json.loads(store.get(label+'/RESULT.json'));prefix=q['input_root'].split('/proof/',1)[1];text=store.get(prefix+'/swap.swp').decode('cp1252');selected=e.switches(text);sig=e.switches(store.get(prefix+'/swap.dra').decode('cp1252'))
   # The first unchanged conjuncts already short circuit the actual literal
   # expression. No runner path, descriptor or producer identity is rebound.
   assert (selected['SWSOLU'],selected['SWDRA'],sig['SWDIVD']) in ((0,0,1),(1,1,1),(2,0,1))
   assert eval(predicate,dict(paired_boundary={},selected=selected,sig=sig)) is False
   for name,digest in q['input_inventory']:assert SHA(store.get(prefix+'/'+name))==digest
   observed.append(dict(archive='EXPLICIT_BOTTOM9_UBUNTU_'+opt+'_RAW_V1',profile=label,actual_original_producer=q['source'],new_pure_admission_predicate_selected=False,actual_input_bytes_retained=True))
assert len(observed)==42
q=dict(status='ALL42_ACTUAL_PRIOR_CONTEXTS_RETAINED_UNDER_EXACT_SINGLE_INCOMING_GUARD_INVERSE_NO_MODEL_OR_COMPILER_REPLAY',actual_source=git('rev-parse','HEAD').decode().strip(),input_admission_core=LAST_NODE_CORE,unchanged_physical_core=CORE,contexts=42,observations=observed,compiler_executions=0,model_executions=0,original_producer_BUILD_and_checkpoint_identities_rewritten=False,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_LAST_NODE_PRIOR42_INHERITANCE_V1.json').open('x') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],flush=True)
