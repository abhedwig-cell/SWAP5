"""Qualify the existing refused original last-node water input on actual source."""
import json,os,subprocess,sys
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;W=E.parent
P=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
HEAD='6ce72513c589c3a701530bfcaddf9d26e0b4e22b';TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
TOOL='C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_source_inverse import complete_inverse,git,CORE,LAST_NODE_CORE
from analytical_hydraulic_archives import SHA
from explicit_bottom9_compiled_postimage import compare
os.environ.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1',TEMP=str(W/'active-python-scratch'),TMP=str(W/'active-python-scratch'))
os.environ['PATH']='C:/msys64/ucrt64/bin;'+os.environ['PATH']
complete_inverse();assert git('rev-parse','HEAD').decode().strip()==HEAD
capsule=json.loads((E/'explicit-bottom9-last-node-actual-source-6ce7-v2/RESULT.json').read_text());assert capsule['producer_head']==HEAD
record=json.loads((R/'integration/f-ci/nomacro-complete01/EXPLICIT_BOTTOM9_WINDOWS_RAW_V1.json').read_text())
inputs=[E/('explicit-bottom9-active-drain-water-initial'+str(i)+'-v1') for i in (1,2)]
for path in inputs:
 for file in path.rglob('*'):
  if file.is_file():
   item=record['members']['profiles/'+path.name+'/'+file.relative_to(path).as_posix()];raw=file.read_bytes();assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
q=dict(status='RUNNING',actual_source=HEAD,unchanged_physical_core=CORE,input_admission_core=LAST_NODE_CORE,actual_controller_sha256=SHA(Path(__file__).read_bytes()),prior_exact_inputs_reused_without_rewrite=True,O0_actual_completed_runtime_and_counterpart_reused_without_reexecution=True,O0_observer_diagnostic='EXPLICIT_BOTTOM9_LAST_NODE_O0_OBSERVER_DIAGNOSTIC_V1.json',contexts=[],canonical_admission=False)
out=E/'EXPLICIT_BOTTOM9_LAST_NODE_WATER_O0_O2_V2.json'
def save():out.write_text(json.dumps(q,indent=2)+'\n')
def run(args):
 assert git('rev-parse','HEAD').decode().strip()==HEAD
 subprocess.run([sys.executable,'-B',*map(str,args)],cwd=R,check=True)
save()
for opt in ('O0','O2'):
 label='explicit-bottom9-water-last-node-drainage-'+opt+'-v1';profile=E/label;post=E/(label+'-initial2-postimage');builds=[]
 if opt=='O0':
  prior=json.loads((profile/'RESULT.json').read_text());counter=json.loads((post/'RESULT.json').read_text());assert prior['source']==counter['source']=='31837609d478a2d55781b30df76deb03fd20a8f1'
  builds=[Path(prior['build_root']).parent,Path(counter['build_root']).parent]
 else:
  for name in (label,label+'-initial2-postimage'):
   raw=subprocess.check_output([sys.executable,'-B',TOOL,'allocate','--task',TASK,'--kind','build','--name',name,'--variant',opt,'--source-ref',HEAD,'--recipe','Original SWDIVD0 last-node water drainage under paired9; actual original35 physical +7native +3exactcold; initial2 compiled counterpart; '+opt],cwd=R,text=True)
   (E/(name+'-allocation.json')).write_text(raw);builds.append(Path(json.loads(raw)['path']))
  run(['tests/nomacro_drainage/explicit_bottom9_runtime.py','--input',inputs[0],'--reference-work',P,'--build-root',builds[0],'--output',profile,'--case','water-last-node-drainage','--optimization',opt])
  run(['tests/nomacro_drainage/explicit_bottom9_postimage.py','--profile',profile,'--input',inputs[1],'--reference-work',P,'--build-root',builds[1],'--output',post])
 science=E/(label+'-independent-v2.json')
 if opt!='O0':run(['tests/nomacro_drainage/explicit_bottom9_last_node_science.py','--profile',profile,'--postimage',post,'--reference-work',P,'--output',science])
 binary=compare(builds[0]/'bundle',builds[1]/'bundle');compiled=E/(label+'-actual-compiled-v1.json');compiled.write_text(json.dumps(binary,indent=2)+'\n')
 q['contexts'].append(dict(case='water-last-node-drainage',optimization=opt,profile=str(profile),postimage=str(post),producer=json.loads((profile/'RESULT.json').read_text())['source'],independent_reader_source=HEAD,independent=str(science),independent_sha256=SHA(science.read_bytes()),actual_compiled=str(compiled),actual_compiled_sha256=SHA(compiled.read_bytes())));save();print('LAST_NODE_WATER_NATIVE_COLD_ALL_NODE_COMPILED_INDEPENDENT_PASS',opt,flush=True)
q.update(status='ACTUAL_BOTH_ORIGINAL_LAST_NODE_WATER_CONTEXTS_ALL_NODE_DARCY_LEDGER_NATIVE_EXACT_COLD_COMPILED_POSTIMAGES_PASS_NOT_ADMITTED',native_checkpoints=14,exact_cold_windows=6,initial2_compiled_counterparts=2);save();print(q['status'],flush=True)
