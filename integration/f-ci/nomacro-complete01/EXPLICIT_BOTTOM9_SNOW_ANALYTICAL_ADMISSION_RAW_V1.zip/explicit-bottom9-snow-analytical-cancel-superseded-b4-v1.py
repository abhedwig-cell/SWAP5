"""Cancel only superseded PR1793 b4 jobs; preserve real responses, no PASS."""
import json,os,subprocess,http.client
from pathlib import Path
E=Path(__file__).resolve().parent
old='b4e50c63c58773b347e55128e556dbe2686ef5b0'
q=json.loads((E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_SUPERSEDED_B4_RUNS_BEFORE_CANCEL_V1.json').read_text())
assert len(q['workflow_runs'])==13 and all(x['head_sha']==old for x in q['workflow_runs'])
r=subprocess.run(['git','credential','fill'],cwd='C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01',input=b'protocol=https\nhost=github.com\npath=abhedwig-cell/SWAP5.git\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'),timeout=30)
assert r.returncode==0,'Existing authentication unavailable; no credential printed'
values=dict(line.split(b'=',1) for line in r.stdout.splitlines() if b'=' in line);token=values.get(b'password');assert token
headers={'Authorization':'Bearer '+token.decode(),'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-superseded-candidate-cancellation'}
record=dict(superseded_candidate=old,replacement_candidate='9fbc580c79db7ef78f0a74de74192b7dfe8ab080',reason='Actual original archive-schema public reader refusal; corrected exact candidate replaces this source. No scientific PASS claimed for cancellations.',runs=[])
for item in q['workflow_runs']:
 c=http.client.HTTPSConnection('api.github.com',timeout=30);base='/repos/abhedwig-cell/SWAP5/actions/runs/'+str(item['id'])
 c.request('GET',base,headers=headers);response=c.getresponse();assert response.status==200;current=json.loads(response.read());assert current['head_sha']==old
 entry=dict(id=item['id'],before=current)
 if current['status']!='completed':
  c.request('POST',base+'/cancel',body=b'',headers=headers);response=c.getresponse();entry.update(cancel_HTTP=response.status,cancel_body=response.read().decode());assert entry['cancel_HTTP'] in (202,409)
 record['runs'].append(entry);c.close()
 with (E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_SUPERSEDED_B4_CANCEL_RESPONSES_V1.json').open('w') as out:json.dump(record,out,indent=2)
 print('SUPERSEDED_CANDIDATE_ONLY',item['id'],current['status'],entry.get('cancel_HTTP'),flush=True)
