"""Exercise actual current bounded frontend positives and hard domain refusals."""
import hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;P=R/'integration/f-ci/nomacro-complete01';sys.path.insert(0,str(R/'app/hybrid_water'))
import experimental_project as actual
from model7_capacity import analytical_models
SHA=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_INPUTS_V1';q=json.loads((P/(name+'.json')).read_text());raw=(P/(name+'.zip')).read_bytes();assert SHA(raw)==q['sha256'] and len(raw)==q['bytes'];out=E/'explicit-bottom9-snow-analytical-current-hard-domains-v1';out.mkdir();checks=[]
with zipfile.ZipFile(P/(name+'.zip')) as z:
 def get(role):
  files={Path(key).name:z.read(key) for key in z.namelist() if key.startswith(role+'/')};assert len(files)==10;return files
 def put(label,files):
  path=out/label;path.mkdir()
  for key,value in files.items():(path/key).write_bytes(value)
  return path
 for model in (3,7,11):
  for kind in ('water','cde'):
   files=get('model'+str(model)+'-'+kind+'-initial1');folder=put('positive-'+str(model)+'-'+kind,files);project=actual.load(folder,original_output=True,time_step_policy='original-adaptive-day-seed-v1');assert analytical_models(project)==(model,model) and actual.auxiliary_magic(project).startswith(b'S5A')
   checks.append(dict(case=folder.name,frontend_accepted=True,models=list(analytical_models(project)),native_codec=actual.auxiliary_magic(project).decode()))
 base=get('model11-water-initial1')
 for label,field,value in [('active-vapor','SWVAPOR','1 1'),('macro','SWMACRO','1'),('frost','SWFROST','1'),('hys1','SWHYST','1'),('hys2','SWHYST','2'),('implicit9','SWKIMPL','1'),('age-snow','SWSOLU','2'),('drained','SWDRA','1'),('unqualified-model2','IHWCKMODEL','2 2'),('RIA12','IHWCKMODEL','12 12')]:
  files=dict(base);before=files['swap.swp'];pattern=rb'(?mi)^([ \t]*'+field.encode()+rb'[ \t]*=[ \t]*)[^!\r\n]*';after,count=re.subn(pattern,lambda match:match[1]+value.encode()+b' ',before);assert count==1;files['swap.swp']=after;folder=put('negative-'+label,files)
  try:actual.load(folder,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
  except ValueError as error:diagnostic=str(error)
  else:raise AssertionError('Actual bounded frontend accepted foreign domain '+label)
  checks.append(dict(case=label,field=field,value=value,frontend_accepted=False,actual_diagnostic=diagnostic,original_swp_sha256=SHA(before),actual_swp_sha256=SHA(after)))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==head
record=dict(status='ACTUAL_CURRENT_EXPERIMENTAL6_POSITIVE_AND10_HARD_DOMAIN_REFUSALS_PASS_NOT_ADMITTED',actual_source=head,actual_frontend_path=str(Path(actual.__file__).resolve()),checks=checks,compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CURRENT_HARD_DOMAINS_V1.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['status'],len(checks))

