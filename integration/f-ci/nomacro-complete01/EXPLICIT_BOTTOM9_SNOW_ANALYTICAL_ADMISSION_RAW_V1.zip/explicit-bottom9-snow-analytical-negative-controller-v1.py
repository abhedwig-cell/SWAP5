"""Prepare actual source/raw/inherited/publication committed negative controls."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage'
s=(T/'explicit_bottom9_snow_history_text_fix_negative_controls.py').read_text()
s=s.replace('EXPLICIT_BOTTOM9_SNOW_HISTORY_UBUNTU_O0_ORIGINAL_V1.zip','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_GUARD_UBUNTU_O0_ORIGINAL_V1.zip')
s=s.replace('EXPLICIT_BOTTOM9_SNOW_HISTORY_TEXT_FIX_CANDIDATE_PUBLIC_V2','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CANDIDATE_PUBLIC_V1')
s=s.replace('EXPLICIT_BOTTOM9_SNOW_HISTORY_TEXT_FIX_CANDIDATE_PUBLICATION_V2','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CANDIDATE_PUBLICATION_V1')
s=s.replace("result['coadmission']['contexts'] == 336","result['coadmission']['contexts'] == 360")
s=s.replace('nomacro-paired9-snow-history-text-negative-','nomacro-paired9-snow-analytical-negative-')
s=s.replace('EXPLICIT_BOTTOM9_SNOW_HISTORY_TEXT_FIX_FINAL_','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_FINAL_')
s=s.replace('NEVER MERGE paired9 Snow history ','NEVER MERGE paired9 analytical Snow ')
(T/'explicit_bottom9_snow_analytical_negative_controls.py').write_text(s)
print('ACTUAL_FOUR_CONTROL_CONTROLLER_PREPARED_NO_MUTANTS_EXECUTED')

