"""Turn the executed explicit ZIP reader into a reusable repository auditor."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
s=(E/'explicit-bottom9-snow-analytical-central-independent-v1.py').read_text()
s=s.replace("R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')","R=Path(__file__).resolve().parents[2]")
old="def main():\n p=argparse.ArgumentParser();p.add_argument('--platform',choices=('Windows','Ubuntu'),required=True);p.add_argument('--optimization',choices=('O0','O2'),required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--guard',action='store_true');p.add_argument('--legacy',action='store_true');a=p.parse_args()"
new="def audit(platform,optimization,guard_mode=False,legacy_mode=False):\n from types import SimpleNamespace\n a=SimpleNamespace(platform=platform,optimization=optimization,guard=guard_mode,legacy=legacy_mode)"
assert s.count(old)==1;s=s.replace(old,new,1)
old="  with a.output.open('x') as stream:json.dump(record,stream,indent=2)\n  print(record['status'],a.platform,a.optimization,flush=True)"
assert s.count(old)==1;s=s.replace(old,"  return record",1)
old="if __name__=='__main__':main()"
new="""def main():
 p=argparse.ArgumentParser();p.add_argument('--platform',choices=('Windows','Ubuntu'),required=True);p.add_argument('--optimization',choices=('O0','O2'),required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--guard',action='store_true');p.add_argument('--legacy',action='store_true');a=p.parse_args()
 record=audit(a.platform,a.optimization,a.guard,a.legacy)
 with a.output.open('x') as stream:json.dump(record,stream,indent=2)
 print(record['status'],a.platform,a.optimization,flush=True)


if __name__=='__main__':main()"""
assert s.count(old)==1;s=s.replace(old,new,1)
(R/'tests/nomacro_drainage/explicit_bottom9_snow_analytical_central_science.py').write_text(s)
print('EXECUTED_READONLY_ARCHIVE_AUDITOR_WITH_EXPLICIT_REUSABLE_API')

