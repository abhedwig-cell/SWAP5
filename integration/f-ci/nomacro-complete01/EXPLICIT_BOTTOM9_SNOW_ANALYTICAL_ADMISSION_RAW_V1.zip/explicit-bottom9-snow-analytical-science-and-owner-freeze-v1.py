"""Persist actual scientific records and activate the declared bounded owner hooks."""
import json,subprocess
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;P=R/'integration/f-ci/nomacro-complete01'
names=[]
for platform in ('WINDOWS','UBUNTU'):
 for opt in ('O0','O2'):
  names.extend(['EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_'+platform+'_'+opt+'_CENTRAL_WITH_NATIVE_CONTROLS_V2','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CURRENT_GUARD_'+platform+'_'+opt+'_CENTRAL_INDEPENDENT_V1'])
names.extend(['EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_MODEL1_'+opt+'_CENTRAL_INDEPENDENT_V1' for opt in ('O0','O2')]);names.append('EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CURRENT_HARD_DOMAINS_V1')
for name in names:
 raw=(E/(name+'.json')).read_bytes();q=json.loads(raw);assert 'PASS' in q['status'] and q['compiler_executions']==q['model_executions']==0;(P/(name+'.json')).write_bytes(raw)
path=R/'tests/nomacro_drainage/initial_profile_age_groundwater_verify.py';text=path.read_text()
for method in ('guard_previous_source','verify','strip_current_evidence','publication_dependencies_unchanged'):
 args='text' if method=='strip_current_evidence' else ''
 before=' import explicit_bottom9_snow_history_verify as snow_history_owner\n return snow_history_owner.'+method+'('+args+')\n'
 after=' import explicit_bottom9_snow_analytical_verify as snow_analytical_owner\n return snow_analytical_owner.'+method+'('+args+')\n'
 assert text.count(before)==1;text=text.replace(before,after,1)
path.write_text(text)
q=json.loads((P/'STATUS.json').read_text());q['snow_analytical_active_recovery'].update(status='ALL24_ORIGINAL35_AND_CURRENT_NATIVE_GUARD_BRIDGES_CENTRAL_INDEPENDENT_PASS_LEGACY8_AND_HARD16_PASS_OWNER_PREPARED_NOT_ADMITTED',positive_physics_source='505954d2943b3f7f478efbb617c53f53dc5f5126',current_native_guard_source='535b0ee491605b8e47a594977ccdfe21431359a7',current_native_guard_batch_source='134760c0583a5eb31bdcaf1af0f5f2c4386c15fa',all24_scientific_records_recomputed_from_original_central_archives=True,actual_model_native_refusals=408,actual_root_native_refusals=200,actual_external_transaction_cases=8,actual_current_foreign_active_vapor_refusals=8,original_full35_periods_replayed=0,fresh_current_guard_warm_days=96,fresh_current_guard_cold_windows=24,fresh_current_guard_cold_accepted_days=72,new_checkpoint_bindings_created=True,old_checkpoint_bindings_rewritten=False,global_functional_family_counts='UNKNOWN',next='Commit scientific postimage/owner once, stamp actual immutable source anchor, run genuine clean14 candidate public/PUB and four committed pushed source/raw/inherited/publication negative controls. Select applicable stable-candidate CI, integrate responsibly only after all gates, run genuine actual canonical public/PUB, seal actual admission and continue next historical gap. Do not stop at this checkpoint.',canonical_admission=False)
q['next_action']=q['snow_analytical_active_recovery']['next'];q['active_branch']=q['working_branch']=q['branch']='codex/nomacro-explicit-bottom9-snow-analytical01';q['recovery_point']='Full24 scientific data original6a/4d/505 and current535/134 native precondition bridges are actual, centrally hashed and independently reread. Parent336 actual canonical04dc remains admitted; proposed360 not yet public/canonical-qualified. Current owner and actual Source/HEAD/index/raw/dependency guards prepared; freeze/stamp actual next source before observers.'
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n')
g=json.loads((P/'GAP_MATRIX.json').read_text());g['next_snow_hydraulic_composition_discovery'].update(status='IMPLEMENTED_BOUNDED_ANALYTICAL_SNOW24_CURRENT_NATIVE_NO_VAPOR_GUARD_CENTRAL_INDEPENDENT_PASS_NOT_YET_ADMITTED',actual_full35_contexts=24,current_guard_warm4_cold4_7_contexts=24,actual_current_model1_whole_compiled_preservation_cases=8,actual_global_family_counts='UNKNOWN',native_active_vapor_gap='Actual source505 compiled startup acceptance preserved; current535/134 rejects active vapor before READY with genuine current-origin state; no source/checkpoint rebinding',next='Public/fail-closed source/data controls, stable-candidate CI and real actual canonical admission',canonical_admission=False)
(P/'GAP_MATRIX.json').write_text(json.dumps(g,indent=2)+'\n')
print('ACTUAL_CENTRAL_RECORDS_AND_BOUNDED360_OWNER_READY_FOR_IMMUTABLE_SOURCE_FREEZE',len(names))

