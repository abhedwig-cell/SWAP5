"""Prepare strict real-source custody for the next canonical336 successor."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage'
s=(T/'explicit_bottom9_snow_history_source_custody.py').read_text()
s=s.replace('from explicit_bottom9_snow_history_source_v2 import ROOT,CORE,complete_inverse,git','from explicit_bottom9_snow_analytical_source import ROOT,CORE,complete_inverse,git')
s=s.replace("SELF='tests/nomacro_drainage/explicit_bottom9_snow_history_verify.py'","SELF='tests/nomacro_drainage/explicit_bottom9_snow_analytical_verify.py'")
s=s.replace("ACTUAL_COMPILER_SOURCE='6154891091824c9f0f64c9fff299ad320ccd9479'","ACTUAL_COMPILER_SOURCE='535b0ee491605b8e47a594977ccdfe21431359a7'")
s=s.replace('EXPLICIT_BOTTOM9_SNOW_HISTORY_CONTRACT_V2.json','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CONTRACT_V1.json')
s=s.replace("old=' import explicit_bottom9_combined_verify as combined_owner\\n return combined_owner.'","old=' import explicit_bottom9_snow_history_verify as snow_history_owner\\n return snow_history_owner.'")
s=s.replace("new=' import explicit_bottom9_snow_history_verify as snow_history_owner\\n return snow_history_owner.'","new=' import explicit_bottom9_snow_analytical_verify as snow_analytical_owner\\n return snow_analytical_owner.'")
s=s.replace('COMPLETE_280_PARENT_AND_CURRENT_SOURCE_TREE_INDEX_WORKING_BYTES_LITERAL_TWO_GUARDS_AND_PUBLIC_OWNER_INVERSE_PASS','COMPLETE_REAL_CANONICAL336_AND_CURRENT_ANALYTICAL_SNOW_SOURCE_INDEX_WORKING_BYTES_LITERALS_AND_OWNER_INVERSE_PASS')
s=s.replace('Current execution source differs from actual completed whole compiled postimages','Current execution source differs from qualified native precondition/current actual warm-cold compiled bridges')
# Freeze actual HEAD proof objects as well as the index and real working bytes.
s=s.replace(' new_proof=[]',' current_proof={line.split(\'\\t\',1)[1]:line.split(\'\\t\',1)[0] for line in git(\'ls-tree\',\'-rl\',\'HEAD\',\'--\',PREFIX).decode().splitlines()}\n new_proof=[]')
s=s.replace("  assert kind=='blob' and path in tracked and tracked[path][1:]==(mode,digest),'Changed new scientific proof tree/index: '+path","  assert current_proof.get(path)==meta,'Changed actual HEAD scientific proof: '+path\n  assert kind=='blob' and path in tracked and tracked[path][1:]==(mode,digest),'Changed new scientific proof tree/index: '+path")
s=s.replace(" head=git('rev-parse','HEAD');tracked=tracked_working_files();rows=[]"," head=git('rev-parse','HEAD');tracked=tracked_working_files();rows=[];current_proof={line.split('\\t',1)[1]:line.split('\\t',1)[0] for line in git('ls-tree','-rl','HEAD','--',PREFIX).decode().splitlines()}")
s=s.replace("  assert kind=='blob' and path in tracked and tracked[path][1:]==(mode,digest),'Changed inherited evidence tree/index: '+path","  assert current_proof.get(path)==meta,'Changed actual HEAD inherited evidence: '+path\n  assert kind=='blob' and path in tracked and tracked[path][1:]==(mode,digest),'Changed inherited evidence tree/index: '+path")
(T/'explicit_bottom9_snow_analytical_source_custody.py').write_text(s)
# Freeze the executed read-only archive auditor as an ordinary, repo-relative
# scientific reader. No data or Git identity is transformed.
e=Path(__file__).parent;s=(e/'explicit-bottom9-snow-analytical-central-independent-v1.py').read_text()
s=s.replace("R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')","R=Path(__file__).resolve().parents[2]")
(T/'explicit_bottom9_snow_analytical_central_science.py').write_text(s)
print('STRICT_CANONICAL336_SUCCESSOR_SOURCE_AND_LITERAL_ARCHIVE_READER_PERSISTED')

