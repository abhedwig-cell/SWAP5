"""Check actual compiled analytical Snow rejects activation of foreign vapor state."""
import hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
import implicit_conductivity_runtime as original
SHA=lambda b:hashlib.sha256(b).hexdigest()
profile=E/'explicit-bottom9-snow-analytical-batch-Windows-O0-v2/model11-water-O0';q=json.loads((profile/'RESULT.json').read_text());assert q['source']=='505954d2943b3f7f478efbb617c53f53dc5f5126' and q['layer_models']==[11,11]
build=Path(q['build_root']);meta=json.loads((build/'BUILD.json').read_text());project=original.m.e.load(q['input_root'],original_output=True,time_step_policy='original-adaptive-day-seed-v1')
checkpoint=profile/'trajectory/accepted-column-1-day-2.zip';oldsha=SHA(checkpoint.read_bytes());out=E/'explicit-bottom9-snow-analytical-model11-active-vapor-startup-gap-v1';out.mkdir()
rows=[]
for label,active in [('own-positive',False),('foreign-active-vapor-private-input',True)]:
 root=out/label;root.mkdir();origin=root/'origin';receipt=original.m.h.verify_checkpoint(checkpoint,2,meta['binding'],origin);directory=root/'original'
 original.m.h.prepare_column(Path(q['input_root']),directory,original.m.h.ColumnStart('original',2,origin,receipt),True,True,project)
 path=directory/'swap.swp';before=path.read_bytes()
 if active:
  after,count=re.subn(rb'(?mi)^([ \t]*SWVAPOR[ \t]*=[ \t]*)[^!\r\n]*',lambda m:m[1]+b'1 1 ',before);assert count==1;path.write_bytes(after)
 result=subprocess.run([str(original.m.h.executable(build,'day_donor')),'./swap.swp'],cwd=directory,input=b'0 0\n',capture_output=True,timeout=20)
 (root/'donor.stdout').write_bytes(result.stdout);(root/'donor.stderr').write_bytes(result.stderr);assert b'HYBRID_DAY_RETURN' not in result.stdout and SHA(checkpoint.read_bytes())==oldsha
 rows.append(dict(label=label,actual_private_input_sha256=SHA(path.read_bytes()),original_private_input_sha256=SHA(before),returncode=result.returncode,ready=b'HYBRID_READY' in result.stdout,stderr=result.stderr.decode('utf8',errors='replace')))
assert rows[0]['ready'] and rows[0]['returncode'] in (0,100) and not rows[0]['stderr']
q=dict(status='ACTUAL_COMPILED_FOREIGN_ACTIVE_VAPOR_STARTUP_REFUSED' if not rows[1]['ready'] and rows[1]['returncode'] not in (0,100) else 'ACTUAL_COMPILED_FOREIGN_ACTIVE_VAPOR_STARTUP_ACCEPTED_UNQUALIFIED',actual_compiler_producer=q['source'],actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()),genuine_checkpoint_sha256=oldsha,rows=rows,compiler_executions=0,model_periods=0,accepted_model_days=0,canonical_admission=False)
(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'])

