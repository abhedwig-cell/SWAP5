"""Retain actual original parser failure and correct independent soil observations."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest();files={}
for opt in ('O0','O2'):
 for version in ('v2','v3'):
  for prefix,root in [('actual-build-'+opt+'-'+version,W/('snow-analytical-actual-soil-component-'+opt+'-'+version)),('actual-sample-'+opt+'-'+version,E/('explicit-bottom9-snow-analytical-model3-water-'+opt+'-actual-soil-samples-'+version))]:
   for path in root.rglob('*'):
    if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path.read_bytes()
 name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_MODEL3_WATER_'+opt+'_ACTUAL_SOIL_INDEPENDENT_V3.json';files[name]=(E/name).read_bytes()
for name in ('explicit-bottom9-snow-analytical-actual-soil-reference-v2.py','explicit-bottom9-snow-analytical-reference-contiguous-v1.py','explicit-bottom9-snow-analytical-actual-soil-reference-raw-v1.py'):files[name]=(E/name).read_bytes()
for source in ('464a0954553dd48e241130f709f8b88bcc33f4ef','878b6c08630a2be7adbfe2b95a2cb8ff83bc3815'):
 files['actual-original-component-source-'+source+'.tar']=subprocess.check_output(['git','archive',source,'--','tests/nomacro_drainage/explicit_bottom9_snow_analytical_reference_probe.f90','tests/nomacro_drainage/explicit_bottom9_snow_analytical_reference_samples.py','tests/nomacro_drainage/explicit_bottom9_snow_analytical_science.py'],cwd=R)
name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_TTUTIL_REFERENCE_RAW_V1';archive=P/(name+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for key,raw in files.items():z.writestr(key,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(files)
 for key,raw in files.items():assert z.read(key)==raw
raw=archive.read_bytes();q=dict(status='ACTUAL_ORIGINAL_TTUTIL_PARAMETER_LENGTH_REFUSAL_AND_DISTINCT_SOIL_O0_O2_REFERENCE_PASS_PRESERVED_NO_MODEL_REPLAY',archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members={key:dict(bytes=len(value),sha256=SHA(value)) for key,value in files.items()},failed_actual_component_source='464a0954553dd48e241130f709f8b88bcc33f4ef',corrected_actual_component_source='878b6c08630a2be7adbfe2b95a2cb8ff83bc3815',failure='Original RDFINR/RDFDOR require actual array count as input; the first independent wrapper passed zero. Actual stdout/stderr and complete failed compiled components retained.',actual_observations_per_optimization=770,actual_maximum_original_theta_stock_difference_cm=7.105427357601002e-15,absolute_stock_limit_cm=1e-10,model_executions=0,old_model_periods_replayed=0,canonical_admission=False)
(P/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n')
s=json.loads((P/'STATUS.json').read_text());s['snow_analytical_active_recovery'].update(status='ORIGINAL_ACTUAL_TTUTIL_DISTINCT_SOIL_REFERENCE_O0_O2_PASS_RESUME24_WITH6_GENUINE_COMPLETED_PERIODS',original_theta_stock_max_difference_cm=q['actual_maximum_original_theta_stock_difference_cm'],native_parser_failure_source=q['failed_actual_component_source'],native_parser_correct_source=q['corrected_actual_component_source'],native_parser_raw=name+'.json',completed_periods_to_reuse=dict(Windows=4,Ubuntu=2),new_model_periods_still_needed=18,next='Freeze corrected batch source and run local O0/O2 resumption with old first4d model3 water and actual completed model7 water. Ubuntu rehydrates original authenticated first4d compiled/scientific bytes from committed ZIPs without changing any producer or binding, then continues the same6case cohort. No model replay for observer changes.')
s['next_action']=s['snow_analytical_active_recovery']['next'];(P/'STATUS.json').write_text(json.dumps(s,indent=2)+'\n')
print(q['status'],q['bytes'],q['sha256'],len(files))

