"""Make the independent original component read the genuine actual soil data."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage'
text=(T/'explicit_bottom9_analytical_reference_probe.f90').read_text()
text=text.replace('integer::model,soil,j,ios,samples,unit','integer::model,soil,j,ios,samples,unit,actual_models(2),actual_count\n  logical::rdinqr\n  external::rdinqr,rdinit,rdfdor,rdfinr')
text=text.replace('character(len=2048)::argument','character(len=2048)::argument,actual_input')
text=text.replace('real(8)::head,w,capacity,k,dk,left_w,right_w,left_k,right_k,delta','real(8)::head,w,capacity,k,dk,left_w,right_w,left_k,right_k,delta,actual_ksatexm(2)')
low=text.index('  ! Exact two-soil coefficients');high=text.index('  iHWCKmodel=model',low)
text=text[:low]+"""  ! Read the actual two distinct soil rows using the original TTUTIL parser.
  ! No original retention, capacity or conductivity routine is replaced.
  call get_command_argument(3,actual_input)
  if(len_trim(actual_input)==0)error stop 'Missing actual soil input path'
  call rdinit(31,6,trim(actual_input))
  call rdfinr('IHWCKMODEL',1,11,actual_models,2,actual_count)
  if(actual_count/=2.or.any(actual_models/=model))error stop 'Foreign actual per-layer hydraulic model'
  if(rdinqr('ELAS').or.rdinqr('h_power').or.rdinqr('SWAP_SOILS_DB')) &
    error stop 'Unselected original constitutive component options'
  call actual_values('ORES',0d0,1d0,cofgen(1,1:2))
  call actual_values('OSAT',0d0,1d0,cofgen(2,1:2))
  call actual_values('KSATFIT',1d-5,1d5,cofgen(3,1:2))
  call actual_values('ALFA',1d-4,100d0,cofgen(4,1:2))
  call actual_values('LEXP',-25d0,50d0,cofgen(5,1:2))
  call actual_values('NPAR',1.001d0,9d0,cofgen(6,1:2))
  cofgen(7,1:2)=1d0-1d0/cofgen(6,1:2)
  cofgen(8,1:2)=cofgen(4,1:2)
  call actual_values('H_ENPR',-40d0,0d0,cofgen(9,1:2))
  cofgen(10,1:2)=-999d0
  call actual_values('KSATEXM',1d-5,1d5,actual_ksatexm)
  if(any(actual_ksatexm>cofgen(3,1:2)))error stop 'Unselected measured Ksat interpolation'
  call actual_values('ALFA_2',1d-4,100d0,cofgen(13,1:2))
  call actual_values('NPAR_2',1.001d0,9d0,cofgen(14,1:2))
  cofgen(15,1:2)=1d0-1d0/cofgen(14,1:2)
  call actual_values('OMEGA_1',1d-4,.9999d0,cofgen(16,1:2))
  cofgen(17,1:2)=1d0-cofgen(16,1:2)
  if(model==7.or.model==11)then
    call actual_values('H0',-5d7,-1d5,cofgen(18,1:2))
    cofgen(18,1:2)=-cofgen(18,1:2)
  end if
  if(model==11)then
    call actual_values('HA',-1d5,0d0,cofgen(19,1:2));cofgen(19,1:2)=-cofgen(19,1:2)
    call actual_values('APAR',-5d0,0d0,cofgen(20,1:2))
    call actual_values('OMEGA_K',1d-8,.1d0,cofgen(21,1:2))
    call rdfinr('SWVAPOR',0,1,actual_models,2,actual_count)
    if(actual_count/=2.or.any(actual_models/=0))error stop 'Unselected active vapor reference'
  end if
  close(31,iostat=ios)
  do soil=1,2
    write(*,'(a,1x,i0,21(1x,es25.17e3))')'ACTUAL_ORIGINAL_TTUTIL_SOIL_PARAMETERS',soil,cofgen(1:21,soil)
  end do
"""+text[high:]
text=text.replace('end program',"""contains
  subroutine actual_values(name,low,high,values)
    character(len=*),intent(in)::name
    real(8),intent(in)::low,high
    real(8),intent(out)::values(2)
    integer::count
    call rdfdor(name,low,high,values,2,count)
    if(count/=2.or..not.all(ieee_is_finite(values)))error stop 'Invalid actual original soil array'
  end subroutine
end program""")
(T/'explicit_bottom9_snow_analytical_reference_probe.f90').write_text(text)
text=(T/'explicit_bottom9_snow_analytical_reference_samples.py').read_text()
text=text.replace('explicit_bottom9_analytical_reference_probe.f90','explicit_bottom9_snow_analytical_reference_probe.f90')
text=text.replace("[str(executable),str(model),str(sample)]","[str(executable),str(model),str(sample),str(Path(prior['input_root'])/'swap.swp')]")
text=text.replace(" for i in range(1,len(heads)+1):assert observed[1,i]==observed[2,i]"," # Actual original soil layers are observed separately; equality is not assumed.")
text=text.replace("observations=[observed[1,i] for i in range(1,len(heads)+1)]","actual_soil_input_sha256=SHA((Path(prior['input_root'])/'swap.swp').read_bytes()),observations_by_layer={str(soil):[observed[soil,i] for i in range(1,len(heads)+1)] for soil in (1,2)}")
(T/'explicit_bottom9_snow_analytical_reference_samples.py').write_text(text)
print('ORIGINAL_TTUTIL_ACTUAL_DISTINCT_SOIL_REFERENCE_DRIVER_PERSISTED_NOT_YET_COMPILED')

