"""Release only archived owned disposable failed/preflight builds and preview."""
import hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).parent;W=E.parent;P=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01');TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';TOOL=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py')
for name in ('EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_SHORT_NATIVE_DISCOVERY_RAW_V1','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_TTUTIL_REFERENCE_RAW_V1'):
 q=json.loads((P/(name+'.json')).read_text());raw=(P/q['archive']).read_bytes();assert len(raw)==q['bytes'] and hashlib.sha256(raw).hexdigest()==q['sha256']
released=[]
for label in ('snow-analytical7-water-O0-preflight-v1','snow-analytical-actual-soil-component-O0-v2','snow-analytical-actual-soil-component-O2-v2'):
 target=(W/label).resolve();assert target.is_relative_to(W.resolve())
 command=['python','-B',str(TOOL),'release','--task',TASK,'--path',str(target)];done=subprocess.run(command,capture_output=True,text=True);assert done.returncode==0,(label,done.stderr);released.append(dict(path=str(target),original_tool_response=json.loads(done.stdout)))
(E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_ARCHIVED_DISPOSABLE_RELEASE_V1.json').write_text(json.dumps(released,indent=2)+'\n')
done=subprocess.run(['python','-B',str(TOOL),'cleanup','--task',TASK],capture_output=True,text=True);assert done.returncode==0,done.stderr;q=json.loads(done.stdout)
(E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_DISPOSABLE_CLEANUP_PREVIEW_V1.json').write_text(done.stdout)
print(json.dumps(dict(free_before=q['free_before'],candidates=[x for x in q['results'] if x['status']!='retained'],free_after=q['free_after']),indent=2))

