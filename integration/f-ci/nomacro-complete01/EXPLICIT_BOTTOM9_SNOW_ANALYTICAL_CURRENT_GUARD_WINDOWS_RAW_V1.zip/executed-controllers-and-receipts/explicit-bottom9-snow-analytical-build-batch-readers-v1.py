"""Reuse immutable qualified implementations with explicit new Snow source owner."""
from pathlib import Path
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');e=Path(__file__).parent;t=r/'tests/nomacro_drainage'
code=(e/'explicit-bottom9-snow-analytical-full35-independent-v2.py').read_text()
code=code.replace("R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')","R=Path(__file__).resolve().parents[2]")
(t/'explicit_bottom9_snow_analytical_science.py').write_text(code)
code=(t/'explicit_bottom9_snow_history_postimage.py').read_text()
code=code.replace('from explicit_bottom9_snow_history_source_v2 import','from explicit_bottom9_snow_analytical_source import')
code=code.replace("q['status'] in ('ACTUAL_EXPLICIT9_SNOW_HISTORY_PHYSICAL_NATIVE_OUTPUT_PERIOD_PASS_NOT_ADMITTED','ACTUAL_EXPLICIT9_SNOW_HISTORY_CALENDAR_PHYSICAL_NATIVE_OUTPUT_PERIOD_PASS_NOT_ADMITTED')","q['status']=='ACTUAL_EXPLICIT9_SNOW_ANALYTICAL_PHYSICAL_NATIVE_COLD_PREFLIGHT_PASS_NOT_ADMITTED'")
code=code.replace('ACTUAL_SNOW_HISTORY_INITIAL2_COMPLETE_GENERATED_AND_COMPILED_POSTIMAGE_PASS_NO_MODEL_PERIOD','ACTUAL_SNOW_ANALYTICAL_INITIAL2_COMPLETE_GENERATED_AND_COMPILED_POSTIMAGE_PASS_NO_MODEL_PERIOD')
(t/'explicit_bottom9_snow_analytical_postimage.py').write_text(code)
code=(t/'explicit_bottom9_analytical_reference_samples.py').read_text()
code=code.replace('from explicit_bottom9_analytical_source_inverse import complete_inverse,git,producer_epoch','from explicit_bottom9_snow_analytical_source import complete_inverse,git')
code=code.replace("assert producer_epoch(prior['source'])=='analytical-paired' and len(set(prior['layer_models']))==1","assert git('cat-file','-t',prior['source']).strip()==b'commit' and len(set(prior['layer_models']))==1")
code=code.replace(" and producer_epoch(component['source'])=='analytical-paired'"," and git('cat-file','-t',component['source']).strip()==b'commit'")
(t/'explicit_bottom9_snow_analytical_reference_samples.py').write_text(code)

