"""Seal actual guard-only Windows bridges and original official Linux guard ZIPs."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent;P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest();SOURCE='134760c0583a5eb31bdcaf1af0f5f2c4386c15fa'
name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CURRENT_GUARD_WINDOWS_RAW_V1';archive=P/(name+'.zip');assert not archive.exists();files={};locations={};batches=[]
for opt in ('O0','O2'):
 proof=E/('sna-guard-Windows-'+opt+'-v1');batch=json.loads((proof/'BATCH.json').read_text());assert batch['status'].startswith('ALL6_CURRENT_NO_VAPOR') and batch['source']==batch['actual_completion_head']==SOURCE and len(batch['contexts'])==6 and sum(q['reused_completed_current_bridge'] for q in batch['contexts'])==1
 batches.append(dict(optimization=opt,path='profiles/'+proof.name+'/BATCH.json'))
 for prefix,root in [('profiles/'+proof.name,proof),('compiled/'+('sna-guard-Windows-'+opt+'-v1'),W/('sna-guard-Windows-'+opt+'-v1'))]:
  locations[str(root)]=dict(archive=name,prefix=prefix)
  for path in sorted(root.rglob('*')):
   if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path.read_bytes()
 proto='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_NO_VAPOR_PROTOTYPES535_RAW_V1'
 locations[str(E/('explicit-bottom9-snow-analytical-no-vapor-guard-model11-water-'+opt+'-v1'))]=dict(archive=proto,prefix='actual-current-bridge-'+opt)
 locations[str(W/('snow-analytical-no-vapor-guard-model11-water-'+opt+'-v1'))]=dict(archive=proto,prefix='actual-current-compiled-'+opt)
for path in E.iterdir():
 if path.is_file() and path.suffix not in ('.zip','.tar') and path.name.startswith(('EXPLICIT_BOTTOM9_SNOW_ANALYTICAL','explicit-bottom9-snow-analytical')):files['executed-controllers-and-receipts/'+path.name]=path.read_bytes()
files['ACTUAL_ARCHIVE_LOCATIONS_V1.json']=(json.dumps(locations,indent=2)+'\n').encode()
files['actual-source134.tar']=subprocess.check_output(['git','archive',SOURCE,'--','app','src','tools','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','.github/workflows/nomacro-explicit-bottom9-snow-analytical-guard.yml'],cwd=R)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for key,raw in files.items():z.writestr(key,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(files)
 for key,raw in files.items():assert z.read(key)==raw
raw=archive.read_bytes();q=dict(status='ALL12_WINDOWS_CURRENT_NO_VAPOR_GUARD_WARM4_COLD4_7_SOURCE_COMPILED_PHYSICAL_NATIVE_OUTPUT_AND_FOREIGN_VAPOR_REFUSALS_PASS_RAW_NOT_ADMITTED',archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members={key:dict(bytes=len(value),sha256=SHA(value)) for key,value in files.items()},source=SOURCE,batches=batches,contexts=12,current_warm_days=48,current_cold_windows=12,current_cold_accepted_days=36,actual_foreign_active_vapor_refusals=4,completed_full35_periods_replayed=0,old_checkpoint_bindings_rewritten=False,canonical_admission=False)
(P/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n');print(q['status'],q['bytes'],q['sha256'],len(files),flush=True)
api=json.loads((E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_GUARD_UBUNTU134_ORIGINAL_ARTIFACTS_V1.json').read_text());run=json.loads((E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_GUARD_UBUNTU134_ORIGINAL_RUN_V1.json').read_text());assert run['head_sha']==SOURCE and run['status']=='completed' and run['conclusion']=='success'
for item in api['artifacts']:
 opt='O0' if '-O0-' in item['name'] else 'O2';name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_GUARD_UBUNTU_'+opt+'_ORIGINAL_V1';path=E/(name+'.zip');raw=path.read_bytes();assert len(raw)==item['size_in_bytes'] and SHA(raw)==item['digest'][7:];assert not (P/path.name).exists()
 with zipfile.ZipFile(path) as z:
  members={key:dict(bytes=len(z.read(key)),sha256=SHA(z.read(key))) for key in z.namelist()};assert len(members)==len(z.namelist());batch=json.loads(z.read('BATCH.json'));assert batch['source']==batch['actual_completion_head']==SOURCE and len(batch['contexts'])==6 and batch['status'].startswith('ALL6_CURRENT_NO_VAPOR')
 (P/path.name).write_bytes(raw)
 q=dict(status='ORIGINAL_OFFICIAL_ALL6_CURRENT_NO_VAPOR_NATIVE_GUARD_RESTART_BRIDGES_SUCCESS_RAW_NOT_ADMITTED',archive=path.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=path.name,bytes=len(raw),sha256=SHA(raw))],members=members,original_artifact=item,actual_source=SOURCE,actual_workflow=run['id'],optimization=opt,contexts=6,current_warm_days=24,current_cold_windows=6,current_cold_accepted_days=18,foreign_active_vapor_refusals=2,completed_full35_periods_replayed=0,old_checkpoint_bindings_rewritten=False,canonical_admission=False)
 (P/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n');print(q['status'],opt,len(raw),q['sha256'],len(members),flush=True)

