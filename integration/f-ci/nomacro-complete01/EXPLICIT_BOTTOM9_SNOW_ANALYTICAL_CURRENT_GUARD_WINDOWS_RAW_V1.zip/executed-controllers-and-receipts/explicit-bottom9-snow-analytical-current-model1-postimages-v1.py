"""Compile-only current legacy Snow1 history/calendars; never repeat old periods."""
import argparse,json,subprocess,sys,time
from contextlib import ExitStack
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from explicit_bottom9_archive_science import ReadView
from explicit_bottom9_compiled_postimage import compare
from explicit_bottom9_snow_analytical_source import complete_inverse,git
import experimental_project as experimental
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=('O0','O2'),required=True)
for key in ('build-root','output','reference-work'):p.add_argument('--'+key,type=Path,required=True)
a=p.parse_args();head=git('rev-parse','HEAD').decode().strip();source=complete_inverse();a.output.mkdir()
labels=('water-hys0-subdaily','water-hys1-step-reset','cde-hys0-monthly','cde-hys2-step-reset')
result=dict(status='RUNNING',source=head,source_proof=source,optimization=a.optimization,contexts=[],selected_current_model1_surfaces=list(labels),not_selected='Old unrelated AGE/nonSnow models and full physical periods: relevant actual source seams unchanged; no new PASS claim',model_executions=0,canonical_admission=False)
def save():(a.output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
def sources(root):return {p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in ('.f90','.f','.for','.inc')}
save()
try:
 with ExitStack() as stack:
  store=Archive(R/'integration/f-ci/nomacro-complete01','EXPLICIT_BOTTOM9_SNOW_HISTORY_WINDOWS_RAW_V1',stack);projection=json.loads(store.get('COMPILED_PROJECTION_V1.json'))
  batch_entry=next(item for item in store.record['batches'] if item['optimization']==a.optimization);batch=json.loads(store.get(batch_entry['path']))
  for label in labels:
   case=next(item for item in batch['contexts'] if item['label']==label)
   prefix='profiles/'+Path(case['profile']).relative_to(E).as_posix();raw=store.get(prefix+'/RESULT.json');oldprofile=json.loads(raw)
   entry=projection[oldprofile['build_root']];old=ReadView(store,entry['archive_prefix']);assert SHA((old/'BUILD.json').read_bytes())==entry['actual_BUILD_sha256']==oldprofile['actual_BUILD_sha256']
   input_prefix='profiles/'+Path(oldprofile['input_root']).relative_to(E).as_posix();out=a.output/label;out.mkdir();inputs=out/'input';inputs.mkdir()
   for filename,digest in oldprofile['input_inventory']:
    value=store.get(input_prefix+'/'+filename);assert SHA(value)==digest;target=inputs/filename;assert target.resolve().is_relative_to(inputs.resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(value)
   project=experimental.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1');build=a.build_root/label/'bundle'
   command=[sys.executable,'-B','tools/solute/run_water.py','--model',project.model,'--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy',project.time_step_policy,'--reference-work',str(a.reference_work),'--build-only','--donor-opt',a.optimization,'--kernel-opt',a.optimization,'--output',str(build)]
   start=time.monotonic();assert git('rev-parse','HEAD').decode().strip()==head
   with (out/'build.stdout').open('x') as stdout,(out/'build.stderr').open('x') as stderr:run=subprocess.run(command,cwd=R,stdout=stdout,stderr=stderr,timeout=300)
   assert run.returncode==0 and git('rev-parse','HEAD').decode().strip()==head
   left,right=sources(old),sources(build);assert left and left.keys()==right.keys();observed=[]
   for name,path in sorted(left.items()):
    original,new=path.read_bytes(),right[name].read_bytes();assert original.replace(b'\r\n',b'\n')==new.replace(b'\r\n',b'\n'),'Legacy complete generated source differs '+name
    observed.append(dict(file=name,original_sha256=SHA(original),current_sha256=SHA(new),original_bytes=len(original),current_bytes=len(new)))
   x=json.loads((old/'BUILD.json').read_text());y=json.loads((build/'BUILD.json').read_text())
   for field in ('donor_objects','donor_modules','ttutil_modules','ttutil_library','donor_flags','kernel_flags'):assert x['identity'][field]==y['identity'][field],field
   assert x['identity']['original_output']['native_codec']==y['identity']['original_output']['native_codec'] and 'analytical_snow_models' not in y['identity']['original_output']
   q=dict(status='ACTUAL_CURRENT_MODEL1_SNOW_HISTORY_CALENDAR_COMPLETE_SOURCE_WHOLE_COMPILED_NATIVE_FORMAT_PRESERVED_NO_MODEL_PERIOD',label=label,optimization=a.optimization,current_source=head,original_source=oldprofile['source'],original_archive=store.record['archive'],original_archive_sha256=store.record['sha256'],original_profile_member=prefix+'/RESULT.json',original_profile_sha256=SHA(raw),original_BUILD_sha256=SHA((old/'BUILD.json').read_bytes()),actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()),command=command,build_root=str(build),input_root=str(inputs),complete_generated_sources=observed,whole_compiled=compare(old,build),native_codec=y['identity']['original_output']['native_codec'],model_executions=0,seconds=time.monotonic()-start)
   (out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n');result['contexts'].append(dict(label=label,result=str(out/'RESULT.json'),build_root=str(build)));save();print(q['status'],label,a.optimization,flush=True)
  complete_inverse();assert len(result['contexts'])==4 and git('rev-parse','HEAD').decode().strip()==head
  result['status']='ALL4_CURRENT_MODEL1_SNOW_HISTORY_CALENDARS_SOURCE_COMPILED_AND_NATIVE_FORMAT_PRESERVED'
except Exception as error:result.update(status='FAILED',error=repr(error));raise
finally:save()

