"""Preserve the original four-platform stock-probe refusal without changing models."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
roots=[]
for opt in ('O0','O2'):
 roots.extend([('actual-Windows-'+opt,E/('explicit-bottom9-snow-analytical-batch-Windows-'+opt+'-v1')),('actual-compiled-Windows-'+opt,W/('snow-analytical-batch-Windows-'+opt+'-v1'))])
roots.extend([('model7-water-O0-build',W/'snow-analytical7-water-O0-model-native-v2'),('model7-water-O2-build',W/'snow-analytical7-water-O2-model-native-short-v1')])
for name in ('explicit-bottom9-snow-analytical7-water-O0-model-native-short-v2','explicit-bottom9-snow-analytical7-water-O0-model-native-controls-v2','explicit-bottom9-snow-analytical7-water-O0-full35-v2','explicit-bottom9-snow-analytical7-water-O2-model-native-short-v1','explicit-bottom9-snow-analytical7-water-O2-model-native-controls-v1','explicit-bottom9-snow-analytical7-water-O2-full35-v1'):roots.append((name,E/name))
files={}
for prefix,root in roots:
 assert root.is_dir()
 for path in sorted(root.rglob('*')):
  if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path
for path in E.iterdir():
 if path.is_file() and path.suffix not in ('.zip','.tar') and path.name.startswith(('EXPLICIT_BOTTOM9_SNOW_ANALYTICAL','explicit-bottom9-snow-analytical')):files['original-executed-controllers-and-receipts/'+path.name]=path
name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_FIRST4D_WINDOWS_NATIVE_AND_STOCK_REFUSAL_RAW_V1';archive=P/(name+'.zip');assert not archive.exists()
members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for key,path in sorted(files.items()):
  raw=path.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
 for source in ('6a0e2c6a4deb1bdfa1d079cc57ec14ca177cf0a1','4d284a5e543d29555bd1c5497a12b3a4b5408a13'):
  raw=subprocess.check_output(['git','archive',source,'--','app','src','tools','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface'],cwd=R);key='actual-Git-source-'+source+'.tar';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(members)
 for key,item in members.items():raw=z.read(key);assert SHA(raw)==item['sha256'] and len(raw)==item['bytes']
raw=archive.read_bytes();q=dict(status='ACTUAL_NATIVE_MODEL_DOMAIN_SUCCESS_AND_FOUR_PLATFORM_REFERENCE_PROBE_SOIL_IDENTITY_REFUSAL_PRESERVED_NOT_QUALIFIED',archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members=members,actual_batch_source='4d284a5e543d29555bd1c5497a12b3a4b5408a13',failure='Independent reused reference driver assumed identical analytical fixture soils. Actual original Snow has different layers and Ksat1. Stock difference8.22342557679822cm. Original models and absolute1e-10 guard unchanged.',no_model_period_replay_authorized_by_this_fix=True,canonical_admission=False)
(P/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n')
api=json.loads((E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_FIRST4D_UBUNTU_ARTIFACTS_ORIGINAL_API_V1.json').read_text())
for artifact in api['artifacts']:
 opt='O0' if '-O0-' in artifact['name'] else 'O2';name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_FIRST4D_UBUNTU_'+opt+'_ORIGINAL_V1';path=E/(name+'.zip');raw=path.read_bytes();assert SHA(raw)==artifact['digest'][7:] and len(raw)==artifact['size_in_bytes'];assert not (P/path.name).exists();(P/path.name).write_bytes(raw)
 with zipfile.ZipFile(path) as z:items={key:dict(bytes=len(z.read(key)),sha256=SHA(z.read(key))) for key in z.namelist()};assert len(items)==len(z.namelist())
 (P/(name+'.json')).write_text(json.dumps(dict(status='ORIGINAL_OFFICIAL_FIRST4D_STOCK_REFERENCE_REFUSAL_ARTIFACT_PRESERVED',archive=path.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=path.name,bytes=len(raw),sha256=SHA(raw))],members=items,original_artifact=artifact,actual_workflow=45298841048,actual_source='4d284a5e543d29555bd1c5497a12b3a4b5408a13',models_replayed=False,canonical_admission=False),indent=2)+'\n')
print(q['status'],q['bytes'],q['sha256'],len(members))

