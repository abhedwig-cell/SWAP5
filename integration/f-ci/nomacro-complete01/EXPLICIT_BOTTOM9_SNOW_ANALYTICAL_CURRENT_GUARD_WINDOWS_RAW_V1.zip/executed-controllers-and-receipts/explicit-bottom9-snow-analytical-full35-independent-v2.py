"""Independent complete 35day analytical Snow water/CDE ledgers and native decoding."""
import argparse,hashlib,json,subprocess,sys,zipfile
from decimal import Decimal,localcontext
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
import snow_undrained_forensics as frozen
from explicit_bottom9_snow_analytical_native import native
from ordinary_pond_evidence import physical
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--profile',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
q=json.loads((a.profile/'RESULT.json').read_text());assert q['days']==35 and q['status'].endswith('PASS_NOT_ADMITTED') and q['source']==q['actual_completion_head']==q['build']['actual_completion_head']
build=Path(q['build_root']);inputs=Path(q['input_root']);meta=json.loads((build/'BUILD.json').read_text());assert SHA((build/'BUILD.json').read_bytes())==q['actual_BUILD_sha256'] and meta['identity']['original_output']['analytical_snow_models']==q['layer_models']
for name,digest in q['input_inventory']:assert SHA((inputs/name).read_bytes())==digest==meta['inputs'][name]
decoder_path='tests/nomacro_drainage/explicit_bottom9_snow_analytical_native.py';decoder=subprocess.check_output(['git','show',q['source']+':'+decoder_path],cwd=R);assert (R/decoder_path).read_bytes().replace(b'\r\n',b'\n')==decoder
text=(inputs/'swap.swp').read_text(encoding='cp1252');s={key:frozen.scalar(text,key) for key in ('SWKIMPL','SWSNOW','SWSOLU','SWHYST','SWBOTB','SWDRA','SWCFBS','NPRINTDAY','SWRES')};dz=frozen.geometry((inputs/'swap.swp').read_bytes(),meta['project']['nodes']);warm=a.profile/'trajectory'
rows=lambda root:[json.loads(line) for line in (root/'daily.jsonl').read_text().splitlines()]
data=rows(warm);assert len(data)==35 and [row['day'] for row in data]==list(range(1,36))
windows=[(2,4),(7,9),(30,34)];assert [(item['start'],item['end']) for item in q['cold']]==windows
global_max=Decimal(0)
with localcontext() as c:
 c.prec=60
 for row in data:
  d=lambda value:Decimal(str(value));residual=sum(map(d,row['stock_start_cm']))+sum(map(d,row['external_flux_cm'][:7]))-sum(map(d,row['external_flux_cm'][7:]))-sum(map(d,row['stock_end_cm']));assert abs(residual)<=Decimal('1e-10');global_max=max(global_max,abs(residual));assert row['external_flux_cm'][-1]==0 and row['pressure_head_cm'][-1]==-1005.
def audit(root,observed):
 water=frozen.original.water(observed);soil=frozen.soil(root,len(observed));byday={row['day']:row for row in observed};seen=[]
 for path in sorted(root.glob('accepted-column-1-day-*.zip')):
  day=int(path.stem.rsplit('-',1)[1]);assert day in byday
  with zipfile.ZipFile(path) as z:
   m=json.loads(z.read('checkpoint.json'));assert m['binding']==meta['binding'] and m['receipt']==byday[day] and all(SHA(z.read(name))==digest for name,digest in m['files'].items());native(z.read('macro.bin'),byday[day],meta,s,dz)
  seen.append(day)
 chemical=None
 if s['SWSOLU']:
  from groundwater_snow_forensics import clock
  chemical=clock.ledger(observed,len(observed))
  class Files:
   def read(self,name):return (root/name).read_bytes()
  clock.daily(Files(),'',observed,meta['project']['nodes'])
 return dict(water=water,soil=soil,solute=chemical,native_samples=sorted(seen))
proof=audit(warm,data);assert proof['native_samples']==[2,4,7,9,30,34,35];cold=[]
for low,high in windows:
 root=a.profile/('own-'+str(low));actual=rows(root);assert physical(actual)==physical(data[low:high]);item=audit(root,actual);assert item['native_samples']==[high]
 with zipfile.ZipFile(warm/f'accepted-column-1-day-{high}.zip') as x,zipfile.ZipFile(root/f'accepted-column-1-day-{high}.zip') as y:assert all(x.read(name)==y.read(name) for name in ('macro.bin','result.end'))
 cold.append(item)
assert max(row['stock_end_cm'][2] for row in data)>0
result=dict(status='ACTUAL_ANALYTICAL_SNOW35_ALL_NODE_GLOBAL_SOIL_SOLUTE_NATIVE_EXACT_COLD_INDEPENDENT_PASS_NOT_ADMITTED',producer=q['source'],layer_models=q['layer_models'],kind=q['kind'],optimization=q['optimization'],days=35,warm=proof,cold=cold,decimal_global_maximum_absolute_residual_cm=str(global_max),absolute_water_limit_cm='1e-10',independent_native_reader_sha256=SHA(decoder),actual_BUILD_sha256=q['actual_BUILD_sha256'],compiler_executions=0,model_executions=0,canonical_admission=False)
with a.output.open('x') as stream:json.dump(result,stream,indent=2)
print(result['status'],q['kind'],q['layer_models'],str(global_max))

