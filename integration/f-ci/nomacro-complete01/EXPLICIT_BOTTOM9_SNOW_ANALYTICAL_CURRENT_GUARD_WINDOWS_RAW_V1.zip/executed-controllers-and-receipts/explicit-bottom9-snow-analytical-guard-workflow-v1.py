"""Derive a restart-only Linux workflow with genuine source505 data."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
text=(R/'.github/workflows/nomacro-explicit-bottom9-snow-analytical.yml').read_text()
text=text.replace('Original paired9 analytical Snow native composition','Native no-vapor boundary with exact original analytical Snow preservation')
text=text.replace('nomacro-explicit-bottom9-snow-analytical','nomacro-explicit-bottom9-snow-analytical-guard')
text=text.replace('codex/nomacro-explicit-bottom9-snow-analytical-guard01','codex/nomacro-explicit-bottom9-snow-analytical01')
text=text.replace('explicit-bottom9-snow-analytical-','explicit-bottom9-snow-analytical-guard-')
text=text.replace('nomacro-explicit-bottom9-snow-analytical-guard-guard','nomacro-explicit-bottom9-snow-analytical-guard')
text=text.replace('codex/nomacro-explicit-bottom9-snow-analytical-guard01','codex/nomacro-explicit-bottom9-snow-analytical01')
text=text.replace("root/'proof'","root/'guard-proof'").replace('$RUNNER_TEMP/proof','$RUNNER_TEMP/guard-proof').replace('runner.temp }}/proof','runner.temp }}/guard-proof')
text=text.replace("for stem in ('builds',):","for stem in ('guard-builds',):")
text=text.replace('git fetch --no-tags --depth=1 --filter=blob:none origin ','git fetch --no-tags --depth=1 --filter=blob:none origin 505954d2943b3f7f478efbb617c53f53dc5f5126 535b0ee491605b8e47a594977ccdfe21431359a7 ',1)
low=text.index('      - name: Reuse genuine completed first4d');high=text.index('      - name: Preserve actual compiled bytes',low)
text=text[:low]+"""      - name: Materialize genuine complete original source505 periods without replay
        run: |
          python3 -B tests/nomacro_drainage/explicit_bottom9_snow_analytical_reuse_positive505.py --optimization '${{ matrix.optimization }}' --proof "$RUNNER_TEMP/proof" --build-root "$RUNNER_TEMP/builds"
      - name: Qualify current native precondition with genuine fresh current origins
        run: |
          python3 -B tests/nomacro_drainage/explicit_bottom9_snow_analytical_guard_batch.py --positive-batch "$RUNNER_TEMP/proof/BATCH.json" --reference-work "$RUNNER_TEMP/provider" --proof "$RUNNER_TEMP/guard-proof" --build-root "$RUNNER_TEMP/guard-builds"
"""+text[high:]
lines=[line for line in text.splitlines() if '/EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_FIRST4D_UBUNTU_' not in line and '/EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_INPUTS_V1.' not in line]
at=next(i for i,line in enumerate(lines) if '      - name: Preserve actual source' in line)
lines[at:at]=['            /integration/f-ci/nomacro-complete01/'+name for name in ('EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_VAPOR_DOMAIN_GUARD_CONTRACT_V1.json','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_UBUNTU_O0_ORIGINAL_V2.json','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_UBUNTU_O0_ORIGINAL_V2.zip','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_UBUNTU_O2_ORIGINAL_V2.json','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_UBUNTU_O2_ORIGINAL_V2.zip')]
(R/'.github/workflows/nomacro-explicit-bottom9-snow-analytical-guard.yml').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines[:13]))

