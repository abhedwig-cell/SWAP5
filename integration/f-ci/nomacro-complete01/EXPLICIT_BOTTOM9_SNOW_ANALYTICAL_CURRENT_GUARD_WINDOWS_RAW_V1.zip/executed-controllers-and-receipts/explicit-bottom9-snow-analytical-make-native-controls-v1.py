"""Make reusable compiled native controls from the successful actual discovery test."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
code=(E/'explicit-bottom9-snow-analytical-model-native-controls-v2.py').read_text()
code=code.replace('import hashlib,json,struct,subprocess,sys,zipfile','import argparse,hashlib,json,struct,subprocess,sys,zipfile')
code=code.replace("R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent","R=Path(__file__).resolve().parents[2];P=R/'integration/f-ci/nomacro-complete01'\np=argparse.ArgumentParser()\nfor key in ('profile','output'):p.add_argument('--'+key,type=Path,required=True)\na=p.parse_args()")
code=code.replace("profile=E/'explicit-bottom9-snow-analytical7-water-O0-model-native-short-v2';qprofile=", "profile=a.profile;qprofile=")
code=code.replace("qprofile['layer_models']==[7,7] and qprofile['days']==2", "qprofile['layer_models'] and len(qprofile['layer_models'])==2 and qprofile['days'] in (2,35)")
code=code.replace("selected['analytical_snow_models']==[7,7] and selected['native_codec']=='S5AWI000'", "selected['analytical_snow_models']==qprofile['layer_models'] and selected['native_codec'].startswith('S5A')")
begin=code.index("old=E/'explicit-bottom9-snow-analytical7-water-O0-wrongmodel-startup-v1'")
end=code.index("out=E/",begin)
code=code[:begin]+"""archive=P/'EXPLICIT_BOTTOM9_SNOW_WINDOWS_RAW_V1.zip';record=json.loads(archive.with_suffix('.json').read_text());assert SHA(archive.read_bytes())==record['sha256']
with zipfile.ZipFile(archive) as z:
 nested=z.read('profiles/explicit-bottom9-snow-water-O0-v2-model-observe-v2/trajectory/accepted-column-1-day-2.zip')
import io
with zipfile.ZipFile(io.BytesIO(nested)) as z:foreign=z.read('macro.bin')
"""+code[end:]
code=code.replace("out=E/'explicit-bottom9-snow-analytical7-water-O0-model-native-controls-v2';out.mkdir()", "out=a.output;out.mkdir()")
code=code.replace("domain=(1,project.nodes,2,0,7,7)", "domain=(1,project.nodes,2,int(project.solute),*qprofile['layer_models'])")
(R/'tests/nomacro_drainage/explicit_bottom9_snow_analytical_native_controls.py').write_text(code)

