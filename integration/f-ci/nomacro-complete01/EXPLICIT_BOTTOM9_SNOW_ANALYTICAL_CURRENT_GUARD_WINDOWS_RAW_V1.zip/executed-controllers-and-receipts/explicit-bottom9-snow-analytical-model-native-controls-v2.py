"""Actual compiled original Snow/model7 native startup and 17 malformed domains."""
import hashlib,json,struct,subprocess,sys,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_scheduled_subsurface'),str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
import implicit_conductivity_runtime as original
from snow_undrained_state import validate_native
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
profile=E/'explicit-bottom9-snow-analytical7-water-O0-model-native-short-v2';qprofile=json.loads((profile/'RESULT.json').read_text())
assert qprofile['layer_models']==[7,7] and qprofile['days']==2 and qprofile['status'].endswith('PASS_NOT_ADMITTED')
build=Path(qprofile['build_root']);meta=json.loads((build/'BUILD.json').read_text());project=original.m.e.load(qprofile['input_root'],original_output=True,time_step_policy='original-adaptive-day-seed-v1');case=Path(project.input_directory);selected=meta['identity']['original_output']
assert selected['analytical_snow_models']==[7,7] and selected['native_codec']=='S5AWI000'
assert SHA((build/'BUILD.json').read_bytes())==qprofile['actual_BUILD_sha256']
for name,digest in meta['inputs'].items():assert original.m.sha(case/name)==digest
for name,digest in meta['identity']['donor_generated'].items():assert original.m.sha(build/name)==digest
for role in ('donor','kernel'):assert original.m.sha(original.m.h.executable(build,'day_'+role))==meta['executable_sha256'][role]
own=profile/'trajectory/accepted-column-1-day-2.zip';ownsha=SHA(own.read_bytes())
with zipfile.ZipFile(own) as z:good=z.read('macro.bin')
old=E/'explicit-bottom9-snow-analytical7-water-O0-wrongmodel-startup-v1';oldrecord=json.loads((old/'RESULT.json').read_text())
with zipfile.ZipFile(old/'actual-original-model1-day2.zip') as z:foreign=z.read('macro.bin')
assert SHA(foreign)==oldrecord['actual_foreign_native_sha256']
out=E/'explicit-bottom9-snow-analytical7-water-O0-model-native-controls-v2';out.mkdir()
domain=(1,project.nodes,2,0,7,7);count=len(domain);size=count*4;at=len(good)-96-2*size
assert struct.unpack_from('<'+str(2*count)+'i',good,at)==domain+domain
attacks=[('genuine-model1-native',foreign),('original-model1-codec',b'S5UWI000'+good[8:]),('missing-model-domain',good[:at]+good[at+2*size:]),('truncated',good[:-1]),('trailing',good+b'X')]
for both in (False,True):
 for index in range(count):
  raw=bytearray(good);value=domain[index]+1
  struct.pack_into('<i',raw,at+4*index,value)
  if both:struct.pack_into('<i',raw,at+size+4*index,value)
  attacks.append((('both-' if both else 'header-')+str(index),bytes(raw)))
assert len(attacks)==17
q=dict(status='RUNNING',actual_compiler_producer=qprofile['source'],actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()),original_checkpoint_sha256=ownsha,original_model1_native_sha256=SHA(foreign),compiled_refusals=[],compiler_executions=0,model_periods=0,accepted_model_days=0,canonical_admission=False,expected_actual_compiled_refusals=len(attacks))
def save():(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
def run(label,raw):
 target=out/label;target.mkdir();origin=target/'origin';receipt=original.m.h.verify_checkpoint(own,2,meta['binding'],origin)
 (origin/'macro.bin').write_bytes(raw)
 directory=target/'original';original.m.h.prepare_column(case,directory,original.m.h.ColumnStart('original',2,origin,receipt),True,True,project)
 r=subprocess.run([str(original.m.h.executable(build,'day_donor')),'./swap.swp'],cwd=directory,input=b'0 0\n',capture_output=True,timeout=20)
 (target/'donor.stdout').write_bytes(r.stdout);(target/'donor.stderr').write_bytes(r.stderr)
 assert b'HYBRID_DAY_RETURN' not in r.stdout and SHA(own.read_bytes())==ownsha
 return r
save()
try:
 goodrun=run('genuine-own-positive',good);assert goodrun.returncode in (0,100) and not goodrun.stderr and b'HYBRID_READY' in goodrun.stdout
 validate_native(good,selected,project.nodes);q['positive_actual_compiled_ready']=True;save()
 for label,raw in attacks:
  result=run(label,raw);diagnostic=result.stderr.decode('utf8',errors='replace')
  assert result.returncode not in (0,100) and 'ERROR STOP' in diagnostic and b'HYBRID_READY' not in result.stdout,(label,result.returncode,diagnostic)
  try:validate_native(raw,selected,project.nodes)
  except (ValueError,struct.error):pass
  else:raise AssertionError('Typed reader accepted actual malformed domain '+label)
  q['compiled_refusals'].append(dict(attack=label,returncode=result.returncode,diagnostic=diagnostic,actual_raw_sha256=SHA(raw),identical_raw_typed_refusal=True,accepted_model_days=0));save()
 q['status']='ACTUAL_COMPILED_ANALYTICAL_SNOW_MODEL_NATIVE_17_REFUSALS_AND_OWN_POSITIVE_PASS'
finally:save()
print(q['status'],len(q['compiled_refusals']))

