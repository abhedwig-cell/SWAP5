"""Seal official successful Linux archives without recompression or identity changes."""
import hashlib,json,zipfile
from pathlib import Path
E=Path(__file__).parent;P=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01');SHA=lambda b:hashlib.sha256(b).hexdigest()
api=json.loads((E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_UBUNTU505_ORIGINAL_ARTIFACTS_V2.json').read_text());run=json.loads((E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_UBUNTU505_ORIGINAL_RUN_V2.json').read_text());assert run['head_sha']=='505954d2943b3f7f478efbb617c53f53dc5f5126' and run['status']=='completed' and run['conclusion']=='success' and len(api['artifacts'])==2
for item in api['artifacts']:
 opt='O0' if '-O0-' in item['name'] else 'O2';name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_UBUNTU_'+opt+'_ORIGINAL_V2';path=E/(name+'.zip');raw=path.read_bytes();assert len(raw)==item['size_in_bytes'] and SHA(raw)==item['digest'][7:];assert not (P/path.name).exists()
 with zipfile.ZipFile(path) as z:
  members={key:dict(bytes=len(z.read(key)),sha256=SHA(z.read(key))) for key in z.namelist()};assert len(members)==len(z.namelist());batch=json.loads(z.read('BATCH.json'));assert batch['source']==batch['actual_completion_head']==run['head_sha'] and batch['status']=='ALL6_ANALYTICAL_SNOW_CONTEXTS_INDEPENDENT_NATIVE_COLD_CURRENT_COMPILED_AND_ORIGINAL_SAMPLES_PASS_NOT_ADMITTED' and batch['optimization']==opt and len(batch['contexts'])==6 and sum(x['completed_period_reused'] for x in batch['contexts'])==1
 (P/path.name).write_bytes(raw)
 q=dict(status='ORIGINAL_OFFICIAL_ANALYTICAL_SNOW6_SUCCESS_RAW_CENTRAL_CUSTODY_PREPARED_NOT_ADMITTED',archive=path.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=path.name,bytes=len(raw),sha256=SHA(raw))],members=members,original_artifact=item,actual_workflow=run['id'],actual_source=run['head_sha'],optimization=opt,contexts=6,original_completed_periods_reused=1,original_completed_periods_replayed=0,canonical_admission=False)
 (P/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n');print(q['status'],opt,len(raw),q['sha256'],len(members))

