"""Seal source505 full positive cohort and the extra inactive-vapor domain gap."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent;P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest();SOURCE='505954d2943b3f7f478efbb617c53f53dc5f5126'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==SOURCE
name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_WINDOWS_POSITIVE505_RAW_V1';archive=P/(name+'.zip');assert not archive.exists();files={};locations={};batches=[];legacy=[]
def add(root,prefix,store=name):
 root=Path(root);locations[str(root)]=dict(archive=store,prefix=prefix)
 if store==name:
  for path in sorted(root.rglob('*')):
   if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path
for opt in ('O0','O2'):
 proof=E/('explicit-bottom9-snow-analytical-batch-Windows-'+opt+'-v2');q=json.loads((proof/'BATCH.json').read_text());assert len(q['contexts'])==6 and q['status'].startswith('ALL6_') and q['source']==q['actual_completion_head']==SOURCE and sum(x['completed_period_reused'] for x in q['contexts'])==2;batches.append(dict(optimization=opt,path='profiles/'+proof.name+'/BATCH.json'))
 add(proof,'profiles/'+proof.name);build=W/('snow-analytical-batch-Windows-'+opt+'-v2');add(build,'compiled/'+build.name)
 proof=E/('explicit-bottom9-snow-analytical-legacy-model1-postimages-'+opt+'-v1');q=json.loads((proof/'RESULT.json').read_text());assert q['status']=='ALL4_CURRENT_MODEL1_SNOW_HISTORY_CALENDARS_SOURCE_COMPILED_AND_NATIVE_FORMAT_PRESERVED' and len(q['contexts'])==4;legacy.append(dict(optimization=opt,path='preservation/'+proof.name+'/RESULT.json'))
 add(proof,'preservation/'+proof.name);build=W/('snow-analytical-legacy-model1-postimages-'+opt+'-v1');add(build,'compiled/'+build.name)
 prior='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_FIRST4D_WINDOWS_NATIVE_AND_STOCK_REFUSAL_RAW_V1'
 add(E/('explicit-bottom9-snow-analytical-batch-Windows-'+opt+'-v1'),'actual-Windows-'+opt,prior);add(W/('snow-analytical-batch-Windows-'+opt+'-v1'),'actual-compiled-Windows-'+opt,prior)
 folder='explicit-bottom9-snow-analytical7-water-'+opt+('-full35-v2' if opt=='O0' else '-full35-v1');add(E/folder,folder,prior)
 build=W/('snow-analytical7-water-'+opt+('-model-native-v2' if opt=='O0' else '-model-native-short-v1'));add(build,'model7-water-'+opt+'-build',prior)
 ref='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_TTUTIL_REFERENCE_RAW_V1';add(E/('explicit-bottom9-snow-analytical-model3-water-'+opt+'-actual-soil-samples-v3'),'actual-sample-'+opt+'-v3',ref);add(W/('snow-analytical-actual-soil-component-'+opt+'-v3'),'actual-build-'+opt+'-v3',ref)
add(E/'explicit-bottom9-snow-analytical-preflight-inputs-v1/snow-analytical7-water-initial1','snow-analytical7-water-initial1','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_PREFLIGHT_INPUTS_V1')
add(E/'explicit-bottom9-snow-analytical-model11-active-vapor-startup-gap-v1','actual-model11-private-active-vapor-startup-gap')
gap=json.loads((E/'explicit-bottom9-snow-analytical-model11-active-vapor-startup-gap-v1/RESULT.json').read_text());assert gap['status']=='ACTUAL_COMPILED_FOREIGN_ACTIVE_VAPOR_STARTUP_ACCEPTED_UNQUALIFIED'
locations['C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider/build']=dict(archive='EXPLICIT_BOTTOM9_SNOW_HISTORY_WINDOWS_RAW_V1',prefix='original-provider-build')
for path in E.iterdir():
 if path.is_file() and path.suffix not in ('.zip','.tar') and path.name.startswith(('EXPLICIT_BOTTOM9_SNOW_ANALYTICAL','explicit-bottom9-snow-analytical')):files['executed-controllers-and-receipts/'+path.name]=path
members={};projection={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for key,path in sorted(files.items()):
  raw=path.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
  if path.name=='BUILD.json':projection[str(path.parent)]=dict(archive=name,prefix=key.rsplit('/',1)[0],actual_BUILD_sha256=SHA(raw))
 raw=subprocess.check_output(['git','archive',SOURCE,'--','app','src','tools','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','.github/workflows/nomacro-explicit-bottom9-snow-analytical.yml','reference/swap-4.3.1/hydraulic-corrections'],cwd=R);key='actual-source505.tar';z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
 for key,raw in [('actual-source505.commit',subprocess.check_output(['git','cat-file','commit',SOURCE],cwd=R)),('actual-provider-PREPARED.json',Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider/PREPARED.json').read_bytes()),('ACTUAL_ARCHIVE_LOCATIONS_V1.json',(json.dumps(locations,indent=2)+'\n').encode()),('ACTUAL_CURRENT_COMPILED_ARCHIVE_LOCATIONS_V1.json',(json.dumps(projection,indent=2)+'\n').encode())]:
  z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(members)
 for key,item in members.items():raw=z.read(key);assert SHA(raw)==item['sha256'] and len(raw)==item['bytes']
raw=archive.read_bytes();q=dict(status='ALL12_WINDOWS_POSITIVE505_SOURCE_NUMERIC_NATIVE_COLD_CURRENT_COMPILED_PASS_ADDITIONAL_FOREIGN_VAPOR_NATIVE_ACCEPTANCE_REQUIRES_GUARD_BRIDGE_NOT_ADMITTED',archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members=members,source=SOURCE,batches=batches,legacy_model1=legacy,contexts=12,compiled_closures=len(projection),native_samples=84,exact_cold_windows=36,initial2_compiled_postimages=12,unchanged_current_model1_compiled_postimages=8,completed_model_periods_reused=4,completed_model_periods_replayed=0,guard_gap=gap['status'],canonical_admission=False)
(P/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==SOURCE
print(q['status'],len(raw),q['sha256'],len(members),len(projection))

