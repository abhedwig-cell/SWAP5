"""Prepare actual canonical parameter/Snow cross-inputs; prove current frontend gap."""
import hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;P=R/'integration/f-ci/nomacro-complete01';sys.path.insert(0,str(R/'app/hybrid_water'));import experimental_project as project
SHA=lambda raw:hashlib.sha256(raw).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert head=='f9d499a03dbe477dfd97da4599f771b24f70ed0a'
root=E/'explicit-bottom9-snow-analytical-preflight-inputs-v1';root.mkdir();archives={}
for name in ('EXPLICIT_BOTTOM9_ANALYTICAL_INPUTS_V1','EXPLICIT_BOTTOM9_SNOW_INPUTS_V1','EXPLICIT_BOTTOM9_SNOW_HISTORY_CALENDAR_INPUTS_V3'):
 q=json.loads((P/(name+'.json')).read_text());raw=(P/(name+'.zip')).read_bytes();assert len(raw)==q['bytes'] and SHA(raw)==q['sha256'];z=zipfile.ZipFile(P/(name+'.zip'));assert len(z.namelist())==len(set(z.namelist()))==len(q['members']);archives[name]=(z,q)
def role(name,prefix):
 z,q=archives[name];files={}
 for item in z.namelist():
  if not item.startswith(prefix+'/'):continue
  raw=z.read(item);assert len(raw)==q['members'][item]['bytes'] and SHA(raw)==q['members'][item]['sha256'];files[Path(item).name]=raw
 assert len(files)==10 and 'swap.swp' in files;return files

def assignment(raw,key,value):
 pattern=rb'(?mi)^([ \t]*'+key.encode()+rb'[ \t]*=[ \t]*)[^!\r\n]*'
 result,count=re.subn(pattern,lambda m:m[1]+value.encode()+b' ',raw)
 if count==0:result=raw+b'\r\n'+key.encode()+b' = '+value.encode()+b'\r\n'
 assert count in (0,1);return result
contexts=[]
for kind in ('water','cde'):
 hydraulic=role('EXPLICIT_BOTTOM9_ANALYTICAL_INPUTS_V1','model7-'+kind+'-initial1');baseline=root/('original-analytical7-'+kind);baseline.mkdir()
 for name,raw in hydraulic.items():(baseline/name).write_bytes(raw)
 real=project.load(baseline,original_output=True,time_step_policy='original-adaptive-day-seed-v1');assert not real.macro and not real.age and real.solute==(kind=='cde')
 base=role('EXPLICIT_BOTTOM9_SNOW_INPUTS_V1',kind+'-initial1') if kind=='water' else role('EXPLICIT_BOTTOM9_SNOW_HISTORY_CALENDAR_INPUTS_V3','cde-initial1-hys2-step-reset')
 raw=assignment(base['swap.swp'],'SWHYST','0');old=hydraulic['swap.swp'];changes=[]
 for key in ('IHWCKMODEL','OSAT','ORES','ALFA','NPAR','LEXP','H_ENPR','KSATFIT','KSAT','KSATEXM','ELAS','ALFA_2','NPAR_2','OMEGA_1','H0','HA','APAR','OMEGA_K','SWVAPOR'):
  values=re.findall(rb'(?mi)^[ \t]*'+key.encode()+rb'[ \t]*=[ \t]*([^!\r\n]*)',old)
  assert len(values)<=1
  if values:
   value=values[0].strip().decode('cp1252');raw=assignment(raw,key,value);changes.append(dict(field=key,exact_canonical_numeric_spelling=value))
 assert any(x['field']=='IHWCKMODEL' and x['exact_canonical_numeric_spelling']=='7 7' for x in changes),changes
 base['swap.swp']=raw;folder=root/('snow-analytical7-'+kind+'-initial1');folder.mkdir()
 for name,value in base.items():(folder/name).write_bytes(value)
 try:project.load(folder,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
 except ValueError as error:diagnostic=str(error)
 else:raise AssertionError('Current unadmitted Snow/nonlinear combination unexpectedly accepted')
 contexts.append(dict(kind=kind,canonical_model7_baseline=str(baseline),actual_baseline_frontend_accepted=True,new_input=str(folder),actual_current_snow_frontend_refused=True,actual_refusal=diagnostic,parameters_copied_with_original_numeric_spelling=changes,input_inventory={n:SHA(v) for n,v in base.items()},SWHYST=0,SWSNOW=1,SWVAPOR=0,canonical_admission=False))
for z,q in archives.values():z.close()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==head
record=dict(status='TWO_ACTUAL_EXISTING_ANALYTICAL7_ACCEPTS_AND_TWO_ACTUAL_SNOW_ANALYTICAL7_FRONTEND_REFUSALS_INPUTS_PRESERVED_NO_MODELS',actual_current_source=head,actual_module=str(Path(project.__file__).resolve()),archives={name:q['sha256'] for name,(_,q) in archives.items()},contexts=contexts,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_PREFLIGHT_INPUTS_AND_ACTUAL_GAP_V1.json').open('x') as out:json.dump(record,out,indent=2)
print(record['status'])
