from pathlib import Path
import re
p=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/tests/nomacro_drainage/explicit_bottom9_snow_analytical_reference_probe.f90')
s=p.read_text()
s=re.sub(r"call actual_values\(([^\n]*),cofgen\((\d+),1:2\)\)",r'call actual_values(\1,\2)',s)
s=s.replace("call actual_values('KSATEXM',1d-5,1d5,actual_ksatexm)","call rdfdor('KSATEXM',1d-5,1d5,actual_ksatexm,2,actual_count)")
s=s.replace('subroutine actual_values(name,low,high,values)','subroutine actual_values(name,low,high,index)').replace('real(8),intent(out)::values(2)','integer,intent(in)::index\n    real(8)::values(2)')
s=s.replace("error stop 'Invalid actual original soil array'","error stop 'Invalid actual original soil array'\n    cofgen(index,1:2)=values")
p.write_text(s)

