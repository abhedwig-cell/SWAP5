"""Independent short coupled Snow/model7 water/native audit, never whole-period admission."""
import argparse,hashlib,json,subprocess,sys,zipfile
from decimal import Decimal,localcontext
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
import snow_undrained_forensics as frozen
from ordinary_pond_evidence import physical
SHA=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--profile',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();q=json.loads((a.profile/'RESULT.json').read_text());assert q['days']==2 and q['kind']=='water' and q['layer_models']==[7,7] and q['status']=='ACTUAL_EXPLICIT9_SNOW_ANALYTICAL_PHYSICAL_NATIVE_COLD_PREFLIGHT_PASS_NOT_ADMITTED'
assert q['source']==q['actual_completion_head']==q['build']['actual_completion_head'];build=Path(q['build_root']);inputs=Path(q['input_root']);meta=json.loads((build/'BUILD.json').read_text());assert SHA((build/'BUILD.json').read_bytes())==q['actual_BUILD_sha256'] and meta['identity']['model7_capacity'] is not None
for name,digest in q['input_inventory']:assert SHA((inputs/name).read_bytes())==digest==meta['inputs'][name]
path='tests/nomacro_drainage/snow_undrained_forensics.py';original=subprocess.check_output(['git','show','2500ed23990dff450e2da31b85c900c06e0506c3:'+path],cwd=R);assert (R/path).read_bytes().replace(b'\r\n',b'\n')==original
warm=a.profile/'trajectory';rows=[json.loads(line) for line in (warm/'daily.jsonl').read_text().splitlines()];assert len(rows)==2 and [r['day'] for r in rows]==[1,2];water=frozen.original.water(rows);soil=frozen.soil(warm,2);global_residual=[]
with localcontext() as c:
 c.prec=60
 for row in rows:
  d=lambda x:Decimal(str(x));residual=sum(map(d,row['stock_start_cm']))+sum(map(d,row['external_flux_cm'][:7]))-sum(map(d,row['external_flux_cm'][7:]))-sum(map(d,row['stock_end_cm']));assert abs(residual)<=Decimal('1e-10');global_residual.append(abs(residual));assert row['external_flux_cm'][-1]==0 and row['pressure_head_cm'][-1]==-1005.
text=(inputs/'swap.swp').read_text(encoding='cp1252');selectors={k:frozen.scalar(text,k) for k in ('SWKIMPL','SWSNOW','SWSOLU','SWHYST','SWBOTB','SWDRA','SWCFBS','NPRINTDAY','SWRES')};dz=frozen.geometry((inputs/'swap.swp').read_bytes(),meta['project']['nodes']);seen=[]
for day,row in enumerate(rows,1):
 with zipfile.ZipFile(warm/f'accepted-column-1-day-{day}.zip') as z:
  m=json.loads(z.read('checkpoint.json'));assert m['binding']==meta['binding'] and m['receipt']==row and all(SHA(z.read(name))==digest for name,digest in m['files'].items());frozen.native(z.read('macro.bin'),row,meta,selectors,dz);seen.append(day)
cold=a.profile/'own-1';actual=[json.loads(line) for line in (cold/'daily.jsonl').read_text().splitlines()];assert physical(actual)==physical(rows[1:2]);frozen.soil(cold,1)
with zipfile.ZipFile(warm/'accepted-column-1-day-2.zip') as x,zipfile.ZipFile(cold/'accepted-column-1-day-2.zip') as y:assert all(x.read(name)==y.read(name) for name in ('macro.bin','result.end'))
result=dict(status='SHORT_ACTUAL_SNOW_MODEL7_WATER_ALL_NODE_GLOBAL_SOIL_NATIVE_EXACT_COLD_INDEPENDENT_PASS_NOT_ADMITTED',producer=q['source'],days=2,actual_native_checkpoints=seen,actual_exact_cold_windows=1,actual_existing_capacity_correction=meta['identity']['model7_capacity'],original_frozen_reader_sha256=SHA(original),actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()),decimal_global_maximum_absolute_residual_cm=str(max(global_residual)),absolute_water_limit_cm='1e-10',water=water,soil=soil,wrong_model_native_domain_qualified=False,whole35_day_science_qualified=False,compiler_executions=0,model_executions=0,canonical_admission=False)
with a.output.open('x') as out:json.dump(result,out,indent=2)
print(result['status'],result['decimal_global_maximum_absolute_residual_cm'])
