"""Preserve actual short success and discovered compiled wrong-model acceptance."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent;P=R/'integration/f-ci/nomacro-complete01'
SHA=lambda b:hashlib.sha256(b).hexdigest()
files={}
for prefix,root in [('actual-build',W/'snow-analytical7-water-O0-preflight-v1'),('actual-two-day',E/'explicit-bottom9-snow-analytical7-water-O0-short-v1'),('actual-wrong-model-startup',E/'explicit-bottom9-snow-analytical7-water-O0-wrongmodel-startup-v1')]:
 for path in sorted(root.rglob('*')):
  if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path.read_bytes()
for name in ('EXPLICIT_BOTTOM9_SNOW_ANALYTICAL7_WATER_O0_SHORT_INDEPENDENT_V1.json','explicit-bottom9-snow-analytical-short-independent-v1.py','explicit-bottom9-snow-analytical7-wrongmodel-startup-v1.py','explicit-bottom9-snow-analytical-short-raw-seal-v1.py'):files[name]=(E/name).read_bytes()
q=json.loads(files['actual-two-day/RESULT.json']);assert q['source']=='9668ec3177ce7f9c454326370d809b1256820923'
wrong=json.loads(files['actual-wrong-model-startup/RESULT.json']);assert wrong['status']=='ACTUAL_COMPILED_FOREIGN_MODEL1_NATIVE_ACCEPTED_UNQUALIFIED' and not wrong['typed_reader_refused']
for path in subprocess.check_output(['git','ls-tree','-r','--name-only',q['source'],'--','app','src','tools','tests/nomacro_drainage/explicit_bottom9_snow_analytical_preflight.py','tests/nomacro_drainage/explicit_bottom9_snow_analytical_source.py'],cwd=R,text=True).splitlines():
 files['actual-producer-git/'+path]=subprocess.check_output(['git','show',q['source']+':'+path],cwd=R)
name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_SHORT_NATIVE_DISCOVERY_RAW_V1';archive=P/(name+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for key,raw in files.items():z.writestr(key,raw)
members={key:dict(bytes=len(raw),sha256=SHA(raw)) for key,raw in files.items()}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(members)
 for key,raw in files.items():assert z.read(key)==raw
raw=archive.read_bytes();record=dict(status='ACTUAL_TWO_DAY_MODEL7_SNOW_WATER_PASS_WITH_WRONG_MODEL_NATIVE_ACCEPTANCE_PRESERVED_NOT_QUALIFIED',source=q['source'],archive=archive.name,bytes=len(raw),sha256=SHA(raw),members=members,accepted_days=2,exact_cold_windows=1,compiled_wrong_model_native_accepted=True,typed_wrong_model_native_accepted=True,canonical_admission=False,whole35_day_qualified=False,required_next='Distinct bounded new analytical Snow native codec and actual compiled layer-model witness, retaining all old model1 native bytes')
(P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(record['status'],record['bytes'],record['sha256'],len(members))

