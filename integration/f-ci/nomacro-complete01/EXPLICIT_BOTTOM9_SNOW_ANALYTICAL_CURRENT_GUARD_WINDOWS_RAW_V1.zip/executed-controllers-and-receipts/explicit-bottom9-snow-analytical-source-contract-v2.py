"""Record exact bounded source changes against a genuine canonical object."""
import argparse,difflib,hashlib,json,subprocess
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
p=argparse.ArgumentParser();p.add_argument('--base',required=True);a=p.parse_args();SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *x:subprocess.check_output(['git',*x],cwd=R)
assert len(a.base)==40 and git('cat-file','-t',a.base).strip()==b'commit'
files={}
for name in ('prescribed_snow_boundary.py','snow_undrained.py','snow_undrained_state.py'):
 path='app/hybrid_water/'+name;before=git('show',a.base+':'+path).decode();after=(R/path).read_bytes().replace(b'\r\n',b'\n').decode();edits=[]
 for tag,low,high,left,right in difflib.SequenceMatcher(None,before,after,autojunk=False).get_opcodes():
  if tag!='equal':edits.append(dict(base_start=low,base_end=high,before=before[low:high],after=after[left:right]))
 files[path]=dict(before_lf_sha256=SHA(before.encode()),proposed_lf_sha256=SHA(after.encode()),ordered_literal_edits=edits)
added='app/hybrid_water/snow_analytical_native.f90';raw=(R/added).read_bytes().replace(b'\r\n',b'\n')
q=dict(status='EXPERIMENTAL_EXISTING_ANALYTICAL_SNOW_COMPOSITION_WITH_BOUNDED_MODEL_NATIVE_NOT_QUALIFIED',version=2,actual_canonical=a.base,files=files,added_files={added:dict(proposed_lf_sha256=SHA(raw))},scope='Paired9 explicit drainage0 Snow water/CDE hysteresis0, original analytical models1,3..11 and inactive vapor; existing model1/hysteresis native and equations preserved',physical_equations_changed=False,original_capacity_correction_changed=False,new_physical_state=False,native_format_changed=True,native_format_change_scope='Only new non-model1 Snow route: distinct S5A codec and actual per-layer model witness before unchanged root diagnostics',old_model1_native_format_unchanged=True,actual_discovery_producer='9668ec3177ce7f9c454326370d809b1256820923',actual_wrong_model_native_acceptance_preserved_in='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_SHORT_NATIVE_DISCOVERY_RAW_V1.json',native_model_domain_qualification='PENDING_ACTUAL_NEW_COMPILED_STARTUP_AND_COLD',canonical_admission=False)
(P/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n')
source='''"""Exact bounded new Snow analytical guards and model-native source ownership."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];CORE=BASE;git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT);SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def complete_inverse():
 path='integration/f-ci/nomacro-complete01/EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CONTRACT_V1.json';raw=(ROOT/path).read_bytes().replace(b'\\r\\n',b'\\n');assert raw==git('show','HEAD:'+path);q=json.loads(raw)
 assert q['actual_canonical']==CORE and q['version']==2 and not q['physical_equations_changed'] and q['old_model1_native_format_unchanged'] and q['native_format_changed']
 domains=('app','src','tools','reference');assert set(git('diff','--name-only',CORE,'HEAD','--',*domains).decode().splitlines())==set(q['files'])|set(q['added_files'])
 assert not git('status','--porcelain=v1','--untracked-files=all','--',*domains,'tests','.github')
 for path,item in q['files'].items():
  before=git('show',CORE+':'+path);actual=(ROOT/path).read_bytes().replace(b'\\r\\n',b'\\n');assert SHA(before)==item['before_lf_sha256'] and SHA(actual)==item['proposed_lf_sha256'] and actual==git('show','HEAD:'+path)
  original=before.decode();parts=[];cursor=0
  for edit in item['ordered_literal_edits']:
   low,high=edit['base_start'],edit['base_end'];assert cursor<=low<=high<=len(original) and original[low:high]==edit['before'];parts.extend((original[cursor:low],edit['after']));cursor=high
  parts.append(original[cursor:]);assert ''.join(parts).encode()==actual
 for path,item in q['added_files'].items():
  assert not git('ls-tree',CORE,'--',path);actual=(ROOT/path).read_bytes().replace(b'\\r\\n',b'\\n');assert SHA(actual)==item['proposed_lf_sha256'] and actual==git('show','HEAD:'+path)
 return dict(status='EXACT_BOUNDED_ANALYTICAL_SNOW_GUARDS_AND_MODEL_NATIVE_ALL_OTHER_EXECUTION_SOURCE_CANONICAL',actual_source=git('rev-parse','HEAD').decode().strip(),actual_canonical=CORE)
'''.replace('CORE=BASE','CORE='+repr(a.base))
(R/'tests/nomacro_drainage/explicit_bottom9_snow_analytical_source.py').write_text(source)
print(q['status'],a.base)

