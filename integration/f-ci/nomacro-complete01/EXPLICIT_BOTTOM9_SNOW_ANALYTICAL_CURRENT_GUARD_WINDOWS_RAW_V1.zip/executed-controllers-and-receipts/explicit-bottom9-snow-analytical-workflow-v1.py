"""Specialize the established Linux proof workflow for one analytical Snow batch."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
text=(R/'.github/workflows/nomacro-explicit-bottom9-snow-history.yml').read_text()
text=text.replace('Original paired9 Snow history and calendar composition','Original paired9 analytical Snow native composition')
text=text.replace('nomacro-explicit-bottom9-snow-history','nomacro-explicit-bottom9-snow-analytical')
text=text.replace('nomacro_explicit_bottom9_snow_history','nomacro_explicit_bottom9_snow_analytical')
text=text.replace('codex/nomacro-explicit-bottom9-snow-history01','codex/nomacro-explicit-bottom9-snow-analytical01')
text=text.replace('explicit_bottom9_snow_history_batch.py','explicit_bottom9_snow_analytical_batch.py')
text=text.replace('explicit-bottom9-snow-history-','explicit-bottom9-snow-analytical-')
text=text.replace('git fetch --no-tags --depth=1 --filter=blob:none origin ','git fetch --no-tags --depth=1 --filter=blob:none origin 04dc6b1cf3ddb4570c33b13ae20be746c8bcde54 ')
lines=text.splitlines()
lines=[line for line in lines if not ('/integration/f-ci/nomacro-complete01/EXPLICIT_BOTTOM9_SNOW_HISTORY_' in line)]
at=next(i for i,line in enumerate(lines) if '      - name: Preserve actual source' in line)
add=['            /integration/f-ci/nomacro-complete01/'+name for name in ('EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CONTRACT_V1.json','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_INPUTS_V1.zip','EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_INPUTS_V1.json','EXPLICIT_BOTTOM9_SNOW_WINDOWS_RAW_V1.zip','EXPLICIT_BOTTOM9_SNOW_WINDOWS_RAW_V1.json')]
lines[at:at]=add
(R/'.github/workflows/nomacro-explicit-bottom9-snow-analytical.yml').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines[:15]))

