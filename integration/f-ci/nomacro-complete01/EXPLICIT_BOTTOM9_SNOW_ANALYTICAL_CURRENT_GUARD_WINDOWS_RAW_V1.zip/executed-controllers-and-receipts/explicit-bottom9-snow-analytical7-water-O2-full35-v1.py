"""Run one new 35day Snow7 water context on its genuine unchanged compiled closure."""
import json,subprocess,sys,time
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_runtime import m,own
from explicit_bottom9_snow_analytical_source import complete_inverse,git
short=E/'explicit-bottom9-snow-analytical7-water-O2-model-native-short-v1'
old=json.loads((short/'RESULT.json').read_text());assert old['status'].endswith('PASS_NOT_ADMITTED') and old['days']==2 and old['layer_models']==[7,7]
control=json.loads((E/'explicit-bottom9-snow-analytical7-water-O2-model-native-controls-v1/RESULT.json').read_text());assert control['status']=='ACTUAL_COMPILED_ANALYTICAL_SNOW_MODEL_NATIVE_17_REFUSALS_AND_OWN_POSITIVE_PASS'
head=git('rev-parse','HEAD').decode().strip();assert old['source']==head==old['actual_completion_head'];complete_inverse()
build=Path(old['build_root']);reference=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');inputs=Path(old['input_root']);project=m.e.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1');m.validate_bundle(build,reference,project)
out=E/'explicit-bottom9-snow-analytical7-water-O2-full35-v1';out.mkdir();q={key:old[key] for key in ('source','composition_core','case','layer_models','hysteresis','kind','optimization','build_root','input_root','input_inventory','build','actual_BUILD_sha256')}
q.update(status='RUNNING',days=35,compiler_executions=0,genuine_existing_compiled_build_reused=True,canonical_admission=False)
def save():(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
start=time.monotonic();save()
try:
 windows=[(2,4),(7,9),(30,34)]
 q['trajectory'],data=m.trajectory(build,reference,project,out/'trajectory',35,{35,*(x for pair in windows for x in pair)},600);q['cold']=[];save()
 for low,high in windows:q['cold'].append(own(build,reference,project,out/'trajectory',data,low,high,out/('own-'+str(low))));save()
 complete_inverse();assert git('rev-parse','HEAD').decode().strip()==head
 q.update(status='ACTUAL_EXPLICIT9_SNOW_ANALYTICAL_PHYSICAL_NATIVE_COLD_PREFLIGHT_PASS_NOT_ADMITTED',snow_maximum_stock_cm=max(row['stock_end_cm'][2] for row in data),snow_minimum_stock_cm=min(row['stock_end_cm'][2] for row in data))
except Exception as error:q.update(status='FAILED',error=repr(error));raise
finally:q.update(seconds=time.monotonic()-start,actual_completion_head=git('rev-parse','HEAD').decode().strip());save()
print(q['status'],q['days'],q['seconds'])


