"""Probe actual compiled Snow7 startup with genuine own and original model1 native."""
import hashlib,io,json,os,subprocess,sys,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_scheduled_subsurface'),str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
import implicit_conductivity_runtime as original
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
profile=E/'explicit-bottom9-snow-analytical7-water-O0-short-v1'
qprofile=json.loads((profile/'RESULT.json').read_text());assert qprofile['layer_models']==[7,7] and qprofile['days']==2 and qprofile['status'].endswith('PASS_NOT_ADMITTED')
build=Path(qprofile['build_root']);meta=json.loads((build/'BUILD.json').read_text());project=original.m.e.load(qprofile['input_root'],original_output=True,time_step_policy='original-adaptive-day-seed-v1');case=Path(project.input_directory)
assert SHA((build/'BUILD.json').read_bytes())==qprofile['actual_BUILD_sha256']
for name,digest in meta['inputs'].items():assert original.m.sha(case/name)==digest
for name,digest in meta['identity']['donor_generated'].items():assert original.m.sha(build/name)==digest
for role in ('donor','kernel'):assert original.m.sha(original.m.h.executable(build,'day_'+role))==meta['executable_sha256'][role]
archive=R/'integration/f-ci/nomacro-complete01/EXPLICIT_BOTTOM9_SNOW_WINDOWS_RAW_V1.zip';manifest=json.loads(archive.with_suffix('.json').read_text());assert SHA(archive.read_bytes())==manifest['sha256']
member='profiles/explicit-bottom9-snow-water-O0-v2-model-observe-v2/trajectory/accepted-column-1-day-2.zip'
with zipfile.ZipFile(archive) as z:
 priorzip=z.read(member);priorprofile=json.loads(z.read('profiles/explicit-bottom9-snow-water-O0-v2-model-observe-v2/RESULT.json'))
with zipfile.ZipFile(io.BytesIO(priorzip)) as z:
 wrong=z.read('macro.bin');oldcheckpoint=json.loads(z.read('checkpoint.json'))
 assert all(SHA(z.read(name))==digest for name,digest in oldcheckpoint['files'].items())
own=profile/'trajectory/accepted-column-1-day-2.zip';own_sha=SHA(own.read_bytes())
with zipfile.ZipFile(own) as z:good=z.read('macro.bin')
out=E/'explicit-bottom9-snow-analytical7-water-O0-wrongmodel-startup-v1';out.mkdir()
(out/'actual-original-model1-day2.zip').write_bytes(priorzip)
q=dict(status='RUNNING',source=qprofile['source'],actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()),genuine_own_checkpoint_sha256=own_sha,original_archive=archive.name,original_archive_sha256=SHA(archive.read_bytes()),original_member=member,original_member_sha256=SHA(priorzip),original_model1_producer=priorprofile['source'],actual_foreign_native_sha256=SHA(wrong),actual_own_native_sha256=SHA(good),native_magic_equal=wrong[:8]==good[:8],original_binding=oldcheckpoint['binding'],own_binding=meta['binding'],compiler_executions=0,accepted_model_days=0,model_periods=0,canonical_admission=False)
def save():(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
def run(label,raw):
 target=out/label;target.mkdir();origin=target/'origin'
 receipt=original.m.h.verify_checkpoint(own,2,meta['binding'],origin)
 # Explicit negative-control mutation after genuine own checkpoint verification.
 # The source ZIP, envelope, binding and original receipt are never rewritten.
 (origin/'macro.bin').write_bytes(raw)
 directory=target/'original';original.m.h.prepare_column(case,directory,original.m.h.ColumnStart('original',2,origin,receipt),True,True,project)
 result=subprocess.run([str(original.m.h.executable(build,'day_donor')),'./swap.swp'],cwd=directory,input=b'0 0\n',capture_output=True,timeout=20)
 (target/'donor.stdout').write_bytes(result.stdout);(target/'donor.stderr').write_bytes(result.stderr)
 assert b'HYBRID_DAY_RETURN' not in result.stdout and SHA(own.read_bytes())==own_sha
 return dict(returncode=result.returncode,ready=b'HYBRID_READY' in result.stdout,stderr_sha256=SHA(result.stderr),stdout_sha256=SHA(result.stdout),stderr=result.stderr.decode('utf8',errors='replace'),accepted_model_days=0)
save()
try:
 q['positive']=run('genuine-own-positive',good);assert q['positive']['returncode'] in (0,100) and q['positive']['ready'] and not q['positive']['stderr'];save()
 q['foreign_model1']=run('genuine-model1-native-negative',wrong)
 refused=not q['foreign_model1']['ready'] and q['foreign_model1']['returncode'] not in (0,100) and 'ERROR STOP' in q['foreign_model1']['stderr']
 from snow_undrained_state import validate_native
 try:validate_native(wrong,meta['identity']['original_output'],project.nodes)
 except (ValueError,Exception) as err:q['typed_reader_refused']=True;q['typed_error']=repr(err)
 else:q['typed_reader_refused']=False
 q['status']='ACTUAL_COMPILED_FOREIGN_MODEL1_NATIVE_REFUSED' if refused else 'ACTUAL_COMPILED_FOREIGN_MODEL1_NATIVE_ACCEPTED_UNQUALIFIED'
 q['requires_bounded_constitutive_native_domain']=not refused
finally:save()
print(q['status'],q.get('typed_reader_refused'))

