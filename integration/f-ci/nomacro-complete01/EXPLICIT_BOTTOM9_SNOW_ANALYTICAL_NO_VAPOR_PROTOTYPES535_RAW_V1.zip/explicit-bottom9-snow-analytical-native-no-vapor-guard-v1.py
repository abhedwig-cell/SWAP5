"""Declare and implement only an inactive-vapor native-domain precondition."""
import hashlib,json,subprocess
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).parent;SOURCE='505954d2943b3f7f478efbb617c53f53dc5f5126';path='app/hybrid_water/snow_analytical_native.f90';SHA=lambda b:hashlib.sha256(b).hexdigest()
old=subprocess.check_output(['git','show',SOURCE+':'+path],cwd=R);assert (R/path).read_bytes().replace(b'\r\n',b'\n')==old
before=old.decode();edits=[dict(before='  use variables,only:swkimpl,swbotb\n',after='  use WC_K_models_04_11,only:NoVap\n  use variables,only:swkimpl,swbotb\n'),dict(before='    n=4+numlay;allocate(expected(n),header(n),witness(n))\n',after="    if(any((iHWCKmodel(1:numlay)>=8).and.(.not.NoVap(1:numlay)))) &\n       error stop 'Active vapor cannot use analytical Snow native'\n    n=4+numlay;allocate(expected(n),header(n),witness(n))\n")]
after=before
for edit in edits:assert after.count(edit['before'])==1;after=after.replace(edit['before'],edit['after'],1)
gap=(E/'explicit-bottom9-snow-analytical-model11-active-vapor-startup-gap-v1/RESULT.json').read_bytes();assert json.loads(gap)['status']=='ACTUAL_COMPILED_FOREIGN_ACTIVE_VAPOR_STARTUP_ACCEPTED_UNQUALIFIED'
q=dict(status='DECLARED_BOUNDED_NO_VAPOR_NATIVE_PRECONDITION_STRENGTHENING_NOT_YET_COMPILED',original_positive_source=SOURCE,source_file=path,original_complete_lf_sha256=SHA(old),proposed_complete_lf_sha256=SHA(after.encode()),literal_edits=edits,actual_gap_receipt_sha256=SHA(gap),physical_equations_changed=False,positive_path_state_mutations_added=False,native_format_changed=False,old_model1_generated_dependency_unchanged=True,required_current_integrated_evidence='Real current builds, genuine current4day warm prefixes and current4..7 cold native windows for all24 original contexts; exact original source505 receipt/native/output equivalence, no old checkpoint rebinding; direct compiled foreign-vapor refusal. Actual old initial2 postimages remain labelled with their original source.',original_35day_periods_to_replay=0,canonical_admission=False)
(P/'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_VAPOR_DOMAIN_GUARD_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n')
(R/path).write_text(after)
print(q['status'],q['proposed_complete_lf_sha256'])

