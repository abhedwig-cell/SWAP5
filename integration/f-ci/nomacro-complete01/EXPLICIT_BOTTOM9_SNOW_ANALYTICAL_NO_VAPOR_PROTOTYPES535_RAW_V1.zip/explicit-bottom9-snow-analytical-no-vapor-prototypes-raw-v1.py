"""Persist real native-domain prototypes and current-origin evidence."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent;P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest();files={}
for opt in ('O0','O2'):
 proof=E/('explicit-bottom9-snow-analytical-no-vapor-guard-model11-water-'+opt+'-v1');q=json.loads((proof/'RESULT.json').read_text());assert q['status'].startswith('ACTUAL_CURRENT_NATIVE_NO_VAPOR_GUARD') and q['source']=='535b0ee491605b8e47a594977ccdfe21431359a7'
 for prefix,root in [('actual-current-bridge-'+opt,proof),('actual-current-compiled-'+opt,W/('snow-analytical-no-vapor-guard-model11-water-'+opt+'-v1')),('actual-vapor-refusal-'+opt,E/('explicit-bottom9-snow-analytical-current-vapor-refusal-model11-water-'+opt+'-v1'))]:
  for path in root.rglob('*'):
   if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path.read_bytes()
for name in ('explicit-bottom9-snow-analytical-current-vapor-refusal-v1.py','explicit-bottom9-snow-analytical-native-no-vapor-guard-v1.py','explicit-bottom9-snow-analytical-no-vapor-prototypes-raw-v1.py'):files[name]=(E/name).read_bytes()
files['actual-source535-native-and-bridge.tar']=subprocess.check_output(['git','archive','535b0ee491605b8e47a594977ccdfe21431359a7','--','app/hybrid_water/snow_analytical_native.f90','tests/nomacro_drainage/explicit_bottom9_snow_analytical_guard_bridge.py','integration/f-ci/nomacro-complete01/EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_VAPOR_DOMAIN_GUARD_CONTRACT_V1.json'],cwd=R)
name='EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_NO_VAPOR_PROTOTYPES535_RAW_V1';archive=P/(name+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for key,raw in files.items():z.writestr(key,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(files)
 for key,raw in files.items():assert z.read(key)==raw
raw=archive.read_bytes();record=dict(status='ACTUAL535_O0_O2_NATIVE_NO_VAPOR_REFUSAL_AND_FRESH_CURRENT_BINDING_WARM4_COLD4_7_EXACT_PASS_NOT_ADMITTED',archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members={key:dict(bytes=len(value),sha256=SHA(value)) for key,value in files.items()},actual_compiler_producer='535b0ee491605b8e47a594977ccdfe21431359a7',original_full35_producer='505954d2943b3f7f478efbb617c53f53dc5f5126',new_binding_differs_from_original=True,original_checkpoint_rebound=False,original_full35_periods_replayed=0,changed_compiled_closure=['macropore.o','day_donor.exe'],all_unaffected_actual_kernel_object_module_publisher_code_data_exact=True,canonical_admission=False)
(P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
s=json.loads((P/'STATUS.json').read_text());s['snow_analytical_active_recovery'].update(status='NATIVE_NO_VAPOR_PROTOTYPES535_O0_O2_FRESH_CURRENT_ORIGIN_AND_FOREIGN_REFUSAL_PASS_ALL24_BRIDGES_NEXT',actual_native_no_vapor_prototype_source=record['actual_compiler_producer'],actual_native_no_vapor_prototype_archive=name+'.json',actual_new_binding_differs_from_original=True,original_checkpoint_binding_rewritten=False,actual_changed_compiled_closure=record['changed_compiled_closure'],actual_current_kernel_and_all_unaffected_compiled_code_exact=True,next='Freeze restart-only batch source and run24 fresh-current4day warm/current4..7 cold bridges preserving original24 full35 results and producer identities. Reuse completed535 water11 current bridges on Windows, with APP byte equality. Linux materializes original authenticated505 science/binaries from exact central raw ZIPs, then executes only changed native-boundary bridges. Verify current compiled active-vapor refusal for water/CDE model11. Do not rerun full35 periods.')
s['next_action']=s['snow_analytical_active_recovery']['next'];(P/'STATUS.json').write_text(json.dumps(s,indent=2)+'\n')
print(record['status'],record['bytes'],record['sha256'],len(files))

