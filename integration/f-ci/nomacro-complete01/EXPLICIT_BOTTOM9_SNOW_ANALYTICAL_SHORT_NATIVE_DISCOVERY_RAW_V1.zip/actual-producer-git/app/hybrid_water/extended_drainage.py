"""Experimental original extended-drain transaction/native composition.

The first integrated development route uses existing daily compatibility
output. Scientific/public qualification is owned by the migration evidence.
"""
from pathlib import Path
import hashlib
import math
import re
import struct

POLICY = 'original-extended-drainage-atomic-state-v1'
MODULE = 'hybrid_extended_drainage_state'
TERMINAL_MODULE = 'hybrid_extended_drain_terminal'
MAGIC = b'S5EDR001'
TEMPLATE = Path(__file__).with_name('extended_drainage_state.f90')
SURFACE_SOURCE_LF_SHA256 = '734aac3c4f186775be36b169cf4d6e63332f07d6f69ee5ebfc6be3d7f958b0df'


def corrected_surfacewater_source(original):
    """Preserve actual positive water instead of the proved legacy dry loss."""
    if hashlib.sha256(original.encode('cp1252')).hexdigest() != SURFACE_SOURCE_LF_SHA256:
        raise ValueError('Changed original extended surfacewater provider')
    old='            if (swstmax < 1.0d-7) then'
    assert original.count(old)==1
    return original.replace(old,'            if (swstmax <= 0.0d0) then',1)


def surfacewater_source(original):
    text=corrected_surfacewater_source(original)
    edits=[
        ('      use MOD_grid,      only: numnod, dz\n',
         '      use '+MODULE+',only:extended_drain_surface_flux\n      use MOD_grid,      only: numnod, dz\n'),
        ('            real(8)              :: swsttara,rday,wsmax,vtair\n',
         '            real(8)              :: extended_supply\n            real(8)              :: swsttara,rday,wsmax,vtair\n'),
        ('\n            overfl = .FALSE.\n', '\n            overfl = .FALSE.\n            extended_supply=0d0\n'),
        ('\n              swst = 0.0d0\n','\n              extended_supply=wsmax\n              swst = 0.0d0\n'),
        ('\n              swst = swstmax\n','\n              extended_supply=wsmax\n              swst = swstmax\n'),
        ('\n                swst = swsttara\n','\n                extended_supply=(swsttara-swstmax)/dt\n                swst = swsttara\n'),
        ('      !        ponding in case of extended drainage may limit timestep\n',
         '            call extended_drain_surface_flux(extended_supply,wdis)\n\n      !        ponding in case of extended drainage may limit timestep\n')]
    for old,new in edits:
        assert text.count(old)==1,old
        text=text.replace(old,new,1)
    return text


def terminal_source():
    # Reuse the admitted no-snow complete original double receipt. Only the
    # selected drainage dispatch differs; no store or physical flux is changed.
    from weather_terminal_receipt import source, MODULE as previous
    text=source();assert text.count('swdra/=1')==1
    text=text.replace(previous,TERMINAL_MODULE).replace('swdra/=1','swdra/=2').replace('WEATHER_TERMINAL_WATER','EXTENDED_DRAIN_TERMINAL_WATER')
    from extended_trial_receipt import render
    return render(text)


def outward_pond_source(source):
    """Compose the admitted exact linear solve only for its actual DRA2 law."""
    old='      use MOD_swap_base, only: swdra, swmacro, swpondmx'
    assert source.count(old)==1
    source=source.replace(old,'      use MOD_drain,only:wls\n'+old,1)
    edits=[('swdra/=2 .and. rsro>=1d-3','(swdra/=2.or.(wls<=pondmx.and.rsroexp==1d0)) .and. rsro>=1d-3'),
           ('else if (swdra /= 2 .AND. rsro>=1d-3','else if ((swdra/=2.or.(wls<=pondmx.and.rsroexp==1d0)) .AND. rsro>=1d-3')]
    for old,new in edits:
        assert source.count(old)==1,old
        source=source.replace(old,new,1)
    return source


def strict_trial_build(output, donor_build, patched, project):
    import implicit_conductivity_retry as retry
    implicit=bool(selection(project).get('swkimpl'))
    path=output/'headcalc.f90';text=path.read_text(encoding='cp1252')
    old='   use hybrid_step_budget, only: projected_water_residual';assert text.count(old)==1
    text=text.replace(old,'   use '+TERMINAL_MODULE+',only:terminal_water_residual\n'+old,1)
    # Eliminate the actual original piecewise pond law with its independently
    # checked derivative; conductivity remains fixed by explicit SWKIMPL0.
    tangent='extended_implicit_top_jacobian' if implicit else 'extended_pond_top_jacobian'
    text=text.replace(old,old+'\n   use MOD_top,only:'+tangent+'\n   use variables, only: tcum',1)
    old='   if (ftoph) dFdhM(1) = dFdhM(1) + kmean(1)/disnod(1)';assert text.count(old)==1
    if implicit:
        from extended_implicit_pond import headcalc
        text=headcalc(text)
    else:text=text.replace(old,'''   if (ftoph) then
      if (flrunoff) then
         dFdhM(1)=dFdhM(1)+extended_pond_top_jacobian(kmean(1)/disnod(1),dt)
      else
         dFdhM(1)=dFdhM(1)+kmean(1)/disnod(1)
      end if
   end if''',1)
    old='         if (abs(budget_total+budget_step)>1d-10*(t1900-budget_start+dt)) flnonconv=.true.'
    assert text.count(old)==1
    text=text.replace(old,old+'\n         if(abs(terminal_water_residual())>1d-10*(t1900-budget_start+dt))flnonconv=.true.',1)
    if implicit:
        assert text.count('   if (.NOT.fldtmin.or.(swmacro==0.and.swkimpl==1)) then')==1
    else:
        text=retry.headcalc_source(text);assert text.count('swmacro==0.and.swkimpl==1')==1
    old='      fldecdt = .TRUE.';assert text.count(old)==1
    text=text.replace(old,"""      if(dt<=dtmin)then
         write(*,'(a,14(1x,es25.17e3))') 'EXTENDED_DRAIN_NONCONVERGED', &
           t1900,dt,tcum,real(numbit,8),budget_start,budget_total,budget_step,terminal_water_residual(), &
           sum1,deviat,pond,pondm1,maxval(abs(F(1:NN))),maxval(abs(h(1:NN)-hold(1:NN)))
         write(*,'(a,6(1x,l1))') 'EXTENDED_DRAIN_NONCONVERGED_FLAGS', &
           ftoph,flrunoff,flnonconv,any(flnonconv1(1:NN)),any(flnonconv2(1:NN)),flnonconv3
      end if
"""+old,1)
    path.write_text(text if implicit else text.replace('swmacro==0.and.swkimpl==1','swmacro==0.and.swkimpl==0'),encoding='cp1252')
    path=output/'timecontrol.f90';text=(path if path.exists() else donor_build/'swap-selected/timecontrol.f90').read_text(encoding='cp1252')
    if implicit:
        assert text.count('if(swmacro==0.and.swkimpl==1)then')==1
    else:
        text=retry.time_source(text);assert text.count('swmacro==0.and.swkimpl==1')==1
        text=text.replace('swmacro==0.and.swkimpl==1','swmacro==0.and.swkimpl==0').replace('implicit original','extended-drain original').replace('Implicit original','Extended-drain original').replace('Named implicit policy','Named extended-drain policy')
    path.write_text(text,encoding='cp1252')
    path=output/'boundtop.f90'
    from extended_pond import render as converged_pond_source
    body=converged_pond_source(outward_pond_source(path.read_text(encoding='cp1252')))
    if implicit:
        from extended_implicit_pond import render as implicit_pond_source
        body=implicit_pond_source(body)
        if selection(project)['swsrf']==2:
            from extended_implicit_pond_switch import source as zero_pond_source
            body=zero_pond_source(body)
    path.write_text(body,encoding='cp1252')
    terminal=terminal_source()
    if project.original_output:
        from extended_output_receipt import terminal_source as output_terminal_source
        terminal=output_terminal_source(TERMINAL_MODULE)
    (output/(TERMINAL_MODULE+'.f90')).write_text(terminal,encoding='cp1252')
    if 'timecontrol' not in patched:patched.append('timecontrol')
    return patched


def describe(directory, selected, original_output):
    if selected.get('SWDRA') != 2:
        return None
    from experimental_project import one
    required = dict(SWMACRO=0, SWSOPHY=0, SWSNOW=0, SWFROST=0,
                    SWHEA=1, SWCALT=2, SWMETDETAIL=0, SWBBCFILE=0)
    if any(selected.get(k) != v for k,v in required.items()) or selected.get('SWBR',0) != 0:
        raise ValueError('Unqualified extended drainage process composition')
    if selected.get('SWKIMPL') not in (0,1):
        raise ValueError('Unqualified extended drainage conductivity policy')
    if selected.get('SWHYST') not in (0,1,2):
        raise ValueError('Unqualified extended drainage hydraulic history')
    if selected.get('SWHYST') and selected.get('SWDISCRVERT')!=0:
        raise ValueError('Extended drainage hydraulic history requires explicit original sublayers')
    if selected.get('SWSOLU')==2:
        raise ValueError('Extended drainage AGE retained-age dry-pond closure is not qualified')
    if selected.get('SWSOLU') not in (0,1) or selected.get('SWBOTB') != 6:
        raise ValueError('Extended drainage requires bounded water/CDE bottom6')
    directory = Path(directory)
    main = (directory/'swap.swp').read_text(encoding='cp1252')
    name = one(main,'DRFIL',r"'[^']+'").strip("'")
    prefix = one(main,'PATHDRAIN',r"'[^']*'").strip("'").strip()
    path = (directory/(prefix+name+'.dra')).resolve()
    if not path.is_relative_to(directory.resolve()) or not path.is_file():
        raise ValueError('Missing or external original extended drainage input')
    text = path.read_text(encoding='cp1252')
    def integer(key):return int(one(text,key,r'[+-]?\d+'))
    swsrf, swsec, levels, division = map(integer,('SWSRF','SWSEC','NRSRF','SWDIVD'))
    if swsrf not in (2,3) or swsec not in (1,2) or not 1 <= levels <= 25:
        raise ValueError('Unqualified extended surfacewater domain')
    if levels <= swsrf-2 or division not in (0,1) or selected['SWSOLU'] and division == 0:
        raise ValueError('Original extended drain partition is invalid')
    return dict(file=path.relative_to(directory.resolve()).as_posix(), levels=levels,
                swsrf=swsrf, swsec=swsec, nrpri=swsrf-2, nrsec=levels-(swsrf-2), swdivd=division,
                **({'swhyst':selected['SWHYST']} if selected['SWHYST'] else {}),
                **({'swkimpl':1} if selected['SWKIMPL'] else {}))


def selection(project):
    if not project.input_directory or project.macro:
        return None
    from experimental_project import inspect
    record = inspect(project.input_directory,original_output=project.original_output).get('extended_drainage')
    if record is not None and project.time_step_policy != 'original-adaptive-day-seed-v1':
        raise ValueError('Extended drainage requires original time stepping')
    if record is not None and record.get('swhyst') and not project.original_output:
        raise ValueError('Extended drainage hydraulic history requires explicit original-output state')
    return record


def enabled(project):return selection(project) is not None


def magic(project):
    selected=selection(project)
    if selected and selected.get('swkimpl'):return b'S5EHK001' if selected.get('swhyst') else b'S5EDK001'
    if selected and selected.get('swhyst'):return b'S5EDH001'
    return b'S5EDO001' if project.original_output else MAGIC


def domain(project):
    s = selection(project)
    return [1,project.nodes,s['levels'],s['swsrf'],s['swsec'],s['nrpri'],s['nrsec'],s['swdivd']]


def size(project):
    s = selection(project)
    return 92+16*(11+3*s['levels']+s['levels']*project.nodes)


def state_source_bytes(project):
    if not project.original_output:return TEMPLATE.read_bytes()
    from extended_output_receipt import state_source
    return state_source(TEMPLATE.read_text(encoding='cp1252')).encode('cp1252')


def metadata(project):
    if not enabled(project):return None
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    implicit=bool(selection(project).get('swkimpl'))
    return dict(policy=POLICY,source_sha256=sha(Path(__file__)),template_sha256=sha(TEMPLATE),
                terminal_renderer_sha256=sha(Path(__file__).with_name('weather_terminal_receipt.py')),
                terminal_template_sha256=sha(Path(__file__).with_name('terminal_water_receipt.f90')),
                strict_retry_source_sha256=sha(Path(__file__).with_name('implicit_conductivity_retry.py')),
                pond_tangent_provider_sha256=sha(Path(__file__).with_name('hybrid_step_budget.f90')),
                pond_conservation_renderer_sha256=sha(Path(__file__).with_name('original_pond_budget.py')),
                extended_pond_numerics_sha256=sha(Path(__file__).with_name('extended_pond.py')),
                extended_trial_receipt_sha256=sha(Path(__file__).with_name('extended_trial_receipt.py')),
                stable_trial_projection='Selected extended drainage: actual original nodal theta difference in real128; original exported double daily totals and1e-10 guards unchanged',
                positive_interception_renderer_sha256=sha(Path(__file__).with_name('implicit_interception_partition.py' if implicit else 'extended_interception.py')),
                **({'implicit_pond_renderer_sha256':sha(Path(__file__).with_name('extended_implicit_pond.py')),
                    'continuous_saturation_renderer_sha256':sha(Path(__file__).with_name('extended_implicit_saturation.py')),
                    'near_saturation_reference_correction':'Original analytic Mualem continued toSe1; removes proved discontinuous near-saturation constant-K shortcut; consistent actual derivative, unchanged water equations/guards',
                    'discontinuous_original_near_saturation_behavior_preserved':False,
                    'implicit_soil_pond_chain_rule':'J*(1+s)/(1+dt*G+s); original soil-mean derivative once, existing pond/supply slope, no accepted state'} if implicit else {}),
                exact_pond_scope='Original runoff() unchanged; exact linear outward solve or complete monotone original root bracket, with piecewise analytic tangent',
                **({'zero_pond_switch_renderer_sha256':sha(Path(__file__).with_name('extended_implicit_pond_switch.py')),
                    'zero_pond_reference_correction':'Original positive pond branch selected at h0>0; removes proved1e-6cm residual jump; original pond equation and all convergence/clock/balance limits unchanged',
                    'original_positive_head_deadband_preserved':False} if implicit and selection(project)['swsrf']==2 else {}),
                strict_trial_water_guard_cm=1e-10,strict_retry_clock_floor_ulps=8,
                **({'output_receipt_renderer_sha256':sha(Path(__file__).with_name('extended_output_receipt.py'))} if project.original_output else {}),
                codec=magic(project).decode(),domain=domain(project),bytes=size(project),
                ownership='Original MOD_drain dynamic values; exact rejected-trial restore, no new physical store',
                physical_equations_changed=False,original_surfacewater_lf_sha256=SURFACE_SOURCE_LF_SHA256,
                reference_defect_correction='Original positive storage is preserved; swstmax<=0 replaces lossy1e-7 dry cutoff',
                surface_inventory='Actual original branch supply/discharge; signed accepted transfers; prescribed-stage volume reaction explicit',
                original_cumulative_level_differences='Raw worker audit checked against actual daily transfers; cumulative origin is not physical restart state')


def state_witness(tokens, project, day):
    if len(tokens) < 3:raise ValueError('Missing original extended drain witness')
    clock=float(tokens[0]);adjustments=int(tokens[1]);count=int(tokens[2]);values=list(map(float,tokens[3:]))
    expected=(size(project)-92)//16
    if (clock != project.start_clock+day or count != expected or len(values) != count
            or adjustments < 0 or not all(map(math.isfinite,[clock,*values])) or min(values[2],values[4]) < 0):
        raise ValueError('Invalid original extended drain witness')
    return dict(adjustments=adjustments,values=values)


def validate_candidate(raw, receipt, project):
    if not enabled(project):return
    length=size(project);expected=domain(project);count=(length-92)//16
    if len(raw) < length+48 or raw[:8] != magic(project):
        raise ValueError('Foreign original extended drain codec')
    start=len(raw)-length
    header=struct.unpack_from('<8i',raw,start);copy=struct.unpack_from('<8i',raw,start+32)
    clock,clock_copy,adjustments,adjustment_copy=struct.unpack_from('<2d2i',raw,start+64)
    values=struct.unpack_from('<'+str(count)+'d',raw,start+88)
    witness=struct.unpack_from('<'+str(count)+'d',raw,start+88+8*count)
    trailer=struct.unpack_from('<i',raw,len(raw)-4)[0]
    if (list(header) != expected or header != copy or trailer != length
            or not math.isfinite(clock) or clock != clock_copy or clock != project.start_clock+receipt.get('day',-1)
            or adjustments != adjustment_copy or adjustments < 0
            or not all(map(math.isfinite,values)) or min(values[2],values[4]) < 0 or values != witness
            or dict(adjustments=adjustments,values=list(values)) != receipt.get('extended_drainage_state')):
        raise ValueError('Original extended drain native state differs from accepted receipt')
    if project.original_output:
        from extended_output_receipt import validate_candidate as validate_output_candidate
        validate_output_candidate(raw,receipt,project)


def flux_witness(tokens, project, receipt, origin):
    s=selection(project);r=s['levels']
    if len(tokens)!=13+2*r:raise ValueError('Incomplete actual original surfacewater ledger')
    clock=float(tokens[0]);steps=int(tokens[1]);rejected=int(tokens[2]);v=list(map(float,tokens[3:]))
    if clock!=project.start_clock+receipt['day'] or steps<1 or rejected<0 or not all(map(math.isfinite,[clock,*v])):
        raise ValueError('Invalid actual original surfacewater clock or values')
    start,end,secondary,primary,runoff,supply,discharge,reaction,iqdra,iruno=v[:10]
    original,independent=v[10:10+r],v[10+r:]
    if start!=origin['values'][2] or end!=receipt['extended_drainage_state']['values'][2] or min(start,end,supply,discharge)<0:
        raise ValueError('Original surfacewater inventory origin differs')
    if s['swsec']==2 and reaction!=0 or s['swsec']==1 and (supply!=0 or discharge!=0):
        raise ValueError('Mixed prescribed/simulated original surfacewater authority')
    flow=receipt['external_flux_cm']
    if iqdra!=flow[13] or iruno!=flow[8]:raise ValueError('Original soil/surface transfer witness differs')
    residual=math.fsum([start,-end,secondary,runoff,supply,-discharge,reaction])
    checks=[residual,math.fsum([secondary,primary,-iqdra]),math.fsum([runoff,-iruno]),
            math.fsum([*original,-iqdra]),math.fsum([*independent[s['nrpri']:],-secondary]),
            math.fsum([*independent[:s['nrpri']],-primary]),*(a-b for a,b in zip(original,independent))]
    combined=math.fsum([*receipt['stock_start_cm'],*(-x for x in receipt['stock_end_cm']),start,-end,
                       *flow[:7],*(-flow[i] for i in range(7,16) if i not in (8,13)),
                       -primary,supply,-discharge,reaction])
    if max(map(abs,[*checks,combined]))>1e-10:
        raise ValueError('Actual original secondary or combined water guard exceeded1e-10cm')
    return dict(stock_start_cm=start,stock_end_cm=end,secondary_exchange_cm=secondary,primary_exchange_cm=primary,
                runoff_from_soil_cm=runoff,supply_cm=supply,discharge_cm=discharge,prescribed_stage_reaction_cm=reaction,
                independent_level_exchange_cm=independent,
                independent_surface_residual_cm=residual,independent_combined_residual_cm=combined,
                accepted_steps=steps,rejected_steps=rejected,
                authority='original simulated surfacewater' if s['swsec']==2 else 'original prescribed-stage volume constraint')


def apply_build(output, donor_build, project, patched):
    if not enabled(project):return patched
    if project.original_output:
        from original_output import selection as output_selection
        selected_output=output_selection(project)
        if selected_output['nprintday']>1 or selected_output['flprintdt']:
            path=output/'integral.f90';text=path.read_text(encoding='cp1252')
            old="if(swmacro/=0.or.swsnow/=0.or.swdra/=1)error stop 'Foreign original trial receipt domain'"
            assert text.count(old)==1
            path.write_text(text.replace(old,old.replace('swdra/=1','swdra/=2'),1),encoding='cp1252')
    if project.original_output:
        from extended_output_receipt import integral_terms
        path=output/'integral.f90'
        path.write_text(integral_terms(path.read_text(encoding='cp1252'),
            (donor_build/'swap-selected/integral.f90').read_text(encoding='cp1252'),
            (donor_build/'swap-selected/watstor.f90').read_text(encoding='cp1252')),encoding='cp1252')
    patched=strict_trial_build(output,donor_build,patched,project)
    if selection(project).get('swkimpl'):
        from extended_implicit_saturation import source as continuous_saturation_source
        path=output/'MOD_MvG_functions.f90'
        path.write_text(continuous_saturation_source(path.read_text(encoding='cp1252')),encoding='cp1252')
    from extended_interception import render as positive_interception_source
    if selection(project).get('swkimpl'):
        # The existing implicit provider already preserves all modeled
        # interception and its positive-input partition. Do not overwrite it.
        path=output/'MOD_meteo.f90';assert path.is_file()
        from implicit_interception_partition import source as implicit_interception_source
        assert path.read_text(encoding='cp1252')==implicit_interception_source((donor_build/'swap-selected/MOD_meteo.f90').read_text(encoding='cp1252'))
    else:
        (output/'MOD_meteo.f90').write_text(positive_interception_source((donor_build/'swap-selected/MOD_meteo.f90').read_text(encoding='cp1252')),encoding='cp1252')
    (output/(MODULE+'.f90')).write_bytes(state_source_bytes(project))
    (output/'surfacewater.f90').write_text(surfacewater_source((donor_build/'swap-selected/surfacewater.f90').read_text(encoding='cp1252')),encoding='cp1252')
    path=output/'macropore.f90';text=path.read_text(encoding='cp1252')
    first=text.index('    subroutine hybrid_macro_checkpoint(')
    last=text.index('    end subroutine hybrid_macro_checkpoint',first)
    body=text[first:last];codecs=re.findall(r"'(S5[A-Z0-9]{6})'",body)
    assert len(codecs)==2 and len(set(codecs))==1
    body=body.replace(codecs[0],magic(project).decode())
    if selection(project).get('swhyst'):
        # Type the existing physical carry with the existing history domain.
        # Its second occurrence still precedes the complete calendar. Neither
        # call reads/writes a physical value or introduces a replacement store.
        for operation,restoring in [('read(unit,iostat=ios)', '.true.'),('write(unit)', '.false.')]:
            anchor='        '+operation+' h(1:numnod),theta(1:numnod),k(1:numnod+1),kmean(1:numnod+1),dimoca(1:numnod),gwl,volact'
            assert body.count(anchor)==1
            body=body.replace(anchor,'        call hybrid_output_hysteresis_checkpoint(unit,'+restoring+')\n'+anchor,1)
    old='      use MOD_grid, only: numnod';assert body.count(old)==1
    body=body.replace(old,'      use '+MODULE+',only:extended_drain_checkpoint\n'+old,1)
    for restoring,anchor in [('.true.','        read(unit,iostat=ios) trailing'),('.false.','      end if\n      close(unit)')]:
        assert body.count(anchor)==1
        body=body.replace(anchor,f'        call extended_drain_checkpoint(unit,{restoring})\n'+anchor,1)
    path.write_text(text[:first]+body+text[last:],encoding='cp1252')
    path=output/'swap.f90';text=path.read_text(encoding='cp1252')
    anchor='use MOD_drain,           only: drain'
    assert text.count(anchor)==1
    text=text.replace(anchor,'use '+MODULE+',only:extended_drain_trial_begin,extended_drain_trial_end\n'+anchor,1)
    anchor='         if (swdra > 0)    call drain(2)';assert text.count(anchor)==1
    text=text.replace(anchor,'         call extended_drain_trial_begin()\n'+anchor,1)
    anchor='         if (swdra == 2)   call drain(3)';assert text.count(anchor)==1
    text=text.replace(anchor,anchor+'\n         call extended_drain_trial_end(fldecdt)',1)
    path.write_text(text,encoding='cp1252')
    path=output/'swap_main.f90';text=path.read_text(encoding='cp1252')
    anchor='use MOD_grid, only: numnod';assert text.count(anchor)==1
    text=text.replace(anchor,'use '+MODULE+',only:extended_drain_witness,extended_drain_window_begin\n'+anchor,1)
    anchor='      call swap(iCaller, iTask, tstart_in, tend_in)';assert text.count(anchor)==1
    text=text.replace(anchor,'      call extended_drain_window_begin()\n'+anchor,1)
    lines=text.splitlines(keepends=True);assert sum("'HYBRID_HYDRAULIC'" in line for line in lines)==2
    text=''.join(line+('   call extended_drain_witness()\n' if "'HYBRID_HYDRAULIC'" in line else '') for line in lines)
    path.write_text(text,encoding='cp1252')
    # HeadCalc imports the selected MOD_top derivative; compile its actual
    # defining module before compiling the caller.
    if project.original_output:
        index=patched.index('integral')+1
        return ['MOD_meteo',*patched[:index],TERMINAL_MODULE,MODULE,'surfacewater','boundtop',
                *(name for name in patched[index:] if name not in ('boundtop','MOD_meteo'))]
    return ['MOD_meteo',TERMINAL_MODULE,MODULE,'surfacewater','boundtop',*(name for name in patched if name not in ('boundtop','MOD_meteo'))]
