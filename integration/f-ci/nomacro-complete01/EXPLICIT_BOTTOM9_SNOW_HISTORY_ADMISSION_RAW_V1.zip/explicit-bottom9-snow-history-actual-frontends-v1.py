import hashlib,json,os,subprocess,sys
from pathlib import Path
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C=Path('C:/Users/Veldh012/swap5-implicit-conductivity-canonical01');inputs=E/'explicit-bottom9-snow-history-inputs-v1';SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda root,*a:subprocess.check_output(['git',*a],cwd=root).decode().strip()
def snapshot(root):return dict(head=git(root,'rev-parse','HEAD'),status=git(root,'status','--porcelain=v1','--untracked-files=all','--ignored'),sparse=git(root,'sparse-checkout','list').splitlines())
before={name:snapshot(root) for name,root in [('parent',C),('current',R)]};assert before['parent']['head']=='2a14f2094bfbfb29c169eb6331da1d7829faa70a' and before['current']['head']=='262e9cbc3d44244d0e8ca720e0c7147228be3b98' and all(not q['status'] and len(q['sparse'])==14 for q in before.values())
code="""import json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'app/hybrid_water'))
import experimental_project as e
try:
 p=e.load(Path(sys.argv[1]),original_output=True,time_step_policy='original-adaptive-day-seed-v1')
except ValueError as error:
 print(json.dumps(dict(status='ACTUAL_ORIGINAL_PARENT_FRONTEND_REFUSED',reason=str(error))))
 raise SystemExit(23)
s=e.switches((Path(sys.argv[1])/'swap.swp').read_text(encoding='cp1252'))
print(json.dumps(dict(status='ACTUAL_CURRENT_FRONTEND_ACCEPTED',hysteresis=s['SWHYST'],snow=s['SWSNOW'],kind='cde' if p.solute else 'water',native_codec=e.auxiliary_magic(p).decode(),actual_frontend_module=str(Path(e.__file__).resolve()))))
"""
rows=[];env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
for folder in sorted(inputs.iterdir()):
 if not folder.is_dir():continue
 for label,root in [('parent',C),('current',R)]:
  command=[sys.executable,'-B','-c',code,str(folder)];p=subprocess.run(command,cwd=root,env=env,capture_output=True,timeout=30)
  stem='EXPLICIT_BOTTOM9_SNOW_HISTORY_FRONTEND_'+folder.name+'_'+label+'_V1'
  (E/(stem+'.stdout.txt')).write_bytes(p.stdout);(E/(stem+'.stderr.txt')).write_bytes(p.stderr)
  assert not p.stderr,(label,folder.name,p.stderr.decode(errors='replace'))
  observed=json.loads(p.stdout)
  if label=='parent':assert p.returncode==23 and observed['status']=='ACTUAL_ORIGINAL_PARENT_FRONTEND_REFUSED'
  else:assert p.returncode==0 and observed['status']=='ACTUAL_CURRENT_FRONTEND_ACCEPTED' and observed['hysteresis'] in (1,2) and observed['snow']==1
  rows.append(dict(role=folder.name,cwd=str(root),source=before[label]['head'],returncode=p.returncode,stdout_sha256=SHA(p.stdout),observation=observed))
assert len(rows)==16;after={name:snapshot(root) for name,root in [('parent',C),('current',R)]};assert after==before
sys.path.insert(0,str(R/'tests/nomacro_drainage'));from explicit_bottom9_snow_history_source import complete_inverse
source=complete_inverse()
record=dict(status='EIGHT_ACTUAL_CANONICAL_PARENT_REFUSALS_AND_EIGHT_ACTUAL_CURRENT_SNOW_HISTORY_ACCEPTS_REAL_SOURCE_MODULES_NO_MODELS',before=before,after=after,checks=rows,actual_source_inverse=source,model_executions=0,compiler_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_SNOW_HISTORY_ACTUAL_FRONTENDS_V1.json').open('x') as f:json.dump(record,f,indent=2)
print(record['status'])
