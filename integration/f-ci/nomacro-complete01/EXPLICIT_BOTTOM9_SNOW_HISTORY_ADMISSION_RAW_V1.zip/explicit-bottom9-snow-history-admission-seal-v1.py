"""Seal actual PR1791 admission only after CI, controls and real canonical proof."""
import argparse,hashlib,json,subprocess,zipfile
from pathlib import Path
CANDIDATE='f9d499a03dbe477dfd97da4599f771b24f70ed0a';PARENT='2a14f2094bfbfb29c169eb6331da1d7829faa70a';ANCHOR='4c63bb35487fef0745f44fedec507172e931b42d'
STATUS='BOUNDED_ORIGINAL_SNOW_HISTORY_CALENDARS_PAIRED9_PARENT280_AND_NEW56_SOURCE_RAW_NATIVE_COLD_WHOLE_COMPILED_POSTIMAGES_PASS'
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
p=argparse.ArgumentParser()
for key in ('repository','evidence'):p.add_argument('--'+key,type=Path,required=True)
a=p.parse_args();R=a.repository;E=a.evidence;P=R/'integration/f-ci/nomacro-complete01';files={};git=lambda *args:subprocess.check_output(['git',*args],cwd=R).decode().strip()
def keep(name):
 path=E/name;assert path.is_file() and not path.is_symlink();files[name]=path;return path
def load(name):return json.loads(keep(name).read_text())
pre=load('EXPLICIT_BOTTOM9_SNOW_HISTORY_PR1791_IMMEDIATE_PREMERGE_V1.json');assert pre['head']['sha']==CANDIDATE and pre['base']['sha']==PARENT and pre['mergeable'] and not pre['draft'];synthetic=pre['merge_commit_sha']
merged=load('EXPLICIT_BOTTOM9_SNOW_HISTORY_PR1791_ACTUAL_MERGE_API_V1.json');assert merged['merged'];canonical=merged['sha'];tree=git('rev-parse',CANDIDATE+'^{tree}')
for commit in (synthetic,canonical):assert git('show','-s','--format=%P',commit).split()==[PARENT,CANDIDATE] and git('rev-parse',commit+'^{tree}')==tree
negative=load('EXPLICIT_BOTTOM9_SNOW_HISTORY_FINAL_NEGATIVES_V1.json');assert negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED' and negative['candidate']==CANDIDATE and len(negative['controls'])==4
fixtures=None;patterns=None;observations={}
for label,head in [('EXPLICIT_BOTTOM9_SNOW_HISTORY_CANDIDATE_PUBLIC_V3',CANDIDATE),('EXPLICIT_BOTTOM9_SNOW_HISTORY_ACTUAL_CANONICAL_PUBLIC_V1',canonical)]:
 q=load(label+'.json');raw=keep(label+'.stdout.txt').read_bytes();assert not keep(label+'.stderr.txt').read_bytes();assert q['before']==q['after'] and q['before']['head']==head and not q['before']['status'] and len(q['before']['sparse'])==14 and len(q['before']['original_project_files'])==56 and q['returncode']==0 and q['compiler_executions']==q['model_executions']==0
 if fixtures is None:fixtures=q['before']['original_project_files'];patterns=q['before']['sparse']
 else:assert fixtures==q['before']['original_project_files'] and patterns==q['before']['sparse']
 actual=json.loads(raw);assert actual['status']==STATUS and actual['compiler_executions']==actual['model_executions']==0 and actual['functional_completion']=='PARTIAL' and actual['whole_scientific_equivalence']=='NOT_QUALIFIED' and actual['RC3_changed'] is False
 stats=actual['coadmission'];assert stats['contexts']==336 and stats['short35_contexts']==334 and stats['year367_contexts']==2 and stats['new_snow_history_calendar_contexts']==56 and stats['native_calendar_samples']==2358 and stats['exact_cold_windows']==1012 and stats['compiled_initialization_postimages']==279 and stats['prior_current_compiler_preservation_postimages']==12
 source=actual['actual_current_source'];assert source['actual_head']==head and source['source_anchor']==ANCHOR and source['Git_or_working_views_projected'] is False and len(actual['actual_new_raw_custody'])==3;assert actual['fresh_parent280_evidence']['total_bytes']>20*1024**3
 observations[label]=q
for label,head in [('EXPLICIT_BOTTOM9_SNOW_HISTORY_CANDIDATE_PUBLICATION_V3',CANDIDATE),('EXPLICIT_BOTTOM9_SNOW_HISTORY_ACTUAL_CANONICAL_PUBLICATION_V1',canonical)]:
 q=load(label+'.json');out=keep(label+'.stdout.txt').read_text();assert not keep(label+'.stderr.txt').read_bytes();assert q['before']==q['after'] and q['before']['head']==head and not q['before']['status'] and q['returncode']==0 and q['before']['sparse']==patterns and q['before']['original_project_files']==fixtures and 'PUBLICATION_REPLAY_SELECTED=false' in out
for item in negative['controls']:
 assert item['never_merge'] and item['actual_refusal'] and item['actual_one_file_delta'] and item['exact_parent']==CANDIDATE and git('show','-s','--format=%P',item['head'])==CANDIDATE and git('diff','--name-only',CANDIDATE,item['head'])==item['path'];assert git('ls-remote','origin','refs/heads/'+item['branch']).split()[0]==item['head']
 label='EXPLICIT_BOTTOM9_SNOW_HISTORY_FINAL_'+item['role']+'_NEGATIVE_PUBLIC_V1';q=load(label+'.json');error=keep(label+'.stderr.txt').read_bytes();keep(label+'.stdout.txt');assert q['before']==q['after'] and q['before']['head']==item['head'] and q['returncode'] not in (0,None) and b'AssertionError' in error and q['before']['sparse']==patterns and q['before']['original_project_files']==fixtures
label='EXPLICIT_BOTTOM9_SNOW_HISTORY_FINAL_PUBLICATION_NEGATIVE_SCOPE_V1';q=load(label+'.json');assert q['before']==q['after'] and q['returncode']==0 and 'PUBLICATION_REPLAY_SELECTED=true' in keep(label+'.stdout.txt').read_text() and not keep(label+'.stderr.txt').read_bytes()
checks=load('EXPLICIT_BOTTOM9_SNOW_HISTORY_FINAL_ALL_TERMINAL_CHECKS_V1.json');assert checks['total_count']==len(checks['check_runs'])>=26 and all(x['head_sha']==CANDIDATE and x['status']=='completed' and x['conclusion'] in ('success','skipped') for x in checks['check_runs'])
runs=load('EXPLICIT_BOTTOM9_SNOW_HISTORY_FINAL_ALL_TERMINAL_RUNS_V1.json');assert runs['total_count']==len(runs['workflow_runs'])>=13 and all(x['head_sha']==CANDIDATE and x['status']=='completed' and x['conclusion']=='success' for x in runs['workflow_runs'])
legacy=load('EXPLICIT_BOTTOM9_SNOW_HISTORY_FINAL_COMMIT_STATUSES_V1.json');assert legacy['total_count']==len(legacy['statuses']) and all(x['state']=='success' for x in legacy['statuses'])
logs=load('EXPLICIT_BOTTOM9_SNOW_HISTORY_FINAL_ORIGINAL_CI_LOGS_V1.json');assert logs['candidate']==CANDIDATE and len(logs['logs'])>=2
for entry in logs['logs']:
 raw=keep(entry['file']).read_bytes();assert len(raw)==entry['bytes'] and SHA(raw)==entry['sha256'] and CANDIDATE in raw.decode('utf8') and synthetic in raw.decode('utf8')
for path in sorted(E.iterdir()):
 if path.is_file() and path.name.startswith(('EXPLICIT_BOTTOM9_SNOW_HISTORY_','explicit-bottom9-snow-history-')) and path.suffix not in ('.zip','.tar'):files.setdefault(path.name,path)
extra={}
for path in ('tests/nomacro_drainage/explicit_bottom9_snow_history_verify.py','tests/nomacro_drainage/explicit_bottom9_snow_history_source_custody.py','tests/nomacro_drainage/explicit_bottom9_snow_history_negative_controls.py'):
 extra['actual-candidate-source/'+path]=subprocess.check_output(['git','show',CANDIDATE+':'+path],cwd=R)
name='EXPLICIT_BOTTOM9_SNOW_HISTORY_ADMISSION_RAW_V1';archive=P/(name+'.zip');assert not archive.exists() and not (P/(name+'.json')).exists();members={key:dict(bytes=path.stat().st_size,sha256=SHA(path.read_bytes())) for key,path in files.items()};members.update({key:dict(bytes=len(raw),sha256=SHA(raw)) for key,raw in extra.items()})
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for key,path in sorted(files.items()):z.write(path,key)
 for key,raw in sorted(extra.items()):z.writestr(key,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(members)
 for key,item in members.items():raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=archive.read_bytes();record=dict(status='ACTUAL_PR1791_CANONICAL336_SOURCE_RAW_PUBLIC_NATIVE_COLD_COMPILED_CONTROLS_AND_CI_ADMISSION_SEALED',archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members=members,PR=1791,candidate=CANDIDATE,canonical=canonical,source_anchor=ANCHOR,parent=PARENT,contexts=336,new_contexts=56,all_CI_checks=len(checks['check_runs']),all_CI_runs=len(runs['workflow_runs']),canonical_admission=True)
(P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
receipt=dict(status='ACTUAL_CANONICAL336_SNOW_HISTORY_CALENDAR_ADMISSION_VERIFIED',PR=1791,previous_canonical=PARENT,qualified_head=CANDIDATE,source_anchor=ANCHOR,synthetic_merge=synthetic,actual_merge=canonical,ordered_parents=[PARENT,CANDIDATE],whole_qualified_tree=tree,admission_archive_sha256=record['sha256'],contexts=336,new_contexts=56,native_calendar_samples=2358,exact_cold_windows=1012,compiled_initialization_postimages=279,prior_current_compiler_preservation_postimages=12,canonical_admission=True,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
(P/'EXPLICIT_BOTTOM9_SNOW_HISTORY_MERGE_RECEIPT_V1.json').write_text(json.dumps(receipt,indent=2)+'\n');print(name,len(raw),record['sha256'],len(members),canonical)
