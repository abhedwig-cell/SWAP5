import difflib,hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');BASE='2a14f2094bfbfb29c169eb6331da1d7829faa70a';SHA=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
snow='app/hybrid_water/prescribed_snow_boundary.py';physical='app/hybrid_water/prescribed_head_flux_boundary.py';backend=git('show',BASE+':app/hybrid_water/snow_undrained.py').decode();start=backend.index('    def one(key,default=None,quoted=False):');end=backend.index('    return dict(',start);body=backend[start:end]
old=git('show',BASE+':'+snow).decode();new=old.replace('selected=paired(directory,original_output,snow=True)',"selected=paired(directory,original_output,hysteresis=s.get('SWHYST'),snow=True)",1)
start=new.index(" daily={'NPRINTDAY':1");end=new.index(' return dict(selected,',start);daily=new[start:end]
assert "flags[0].strip().upper()" in daily and "'SWRES':1" in daily
new=new[:start]+" try:_validate_calendar(text)\n except ValueError:return None\n"+new[end:]
anchor='def selection(directory,original_output=True):';assert new.count(anchor)==1;new=new.replace(anchor,'def _validate_calendar(text):\n'+body+'\n\n'+anchor,1)
assert body in new and backend.count(body)==1
core=git('show',BASE+':'+physical).decode();oldguard='if hysteresis not in (0,1,2) or snow and hysteresis!=0:return None';newguard='if hysteresis not in (0,1,2):return None';assert core.count(oldguard)==1;changed=core.replace(oldguard,newguard,1)
files={physical:dict(before_lf_sha256=SHA(core.encode()),proposed_lf_sha256=SHA(changed.encode()),literal_old=oldguard,literal_new=newguard),snow:dict(before_lf_sha256=SHA(old.encode()),proposed_lf_sha256=SHA(new.encode()),literal_old=old,literal_new=new)}
patch=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+snow,tofile='b/'+snow)).encode()
with (E/'EXPLICIT_BOTTOM9_SNOW_HISTORY_CALENDAR_INCREMENT_V2.patch').open('xb') as f:
 current=(R/snow).read_text();assert current==old.replace('selected=paired(directory,original_output,snow=True)',"selected=paired(directory,original_output,hysteresis=s.get('SWHYST'),snow=True)",1)
 f.write(''.join(difflib.unified_diff(current.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+snow,tofile='b/'+snow)).encode())
contract=json.loads((R/'integration/f-ci/nomacro-complete01/EXPLICIT_BOTTOM9_SNOW_HISTORY_CONTRACT_V1.json').read_text());contract.update(status='BOUNDED_EXISTING_SNOW_HISTORY_AND_ORIGINAL_CALENDAR_CONFIGURATION_CONTRACT_PENDING_QUALIFICATION',files=files,calendar_validation_owner='app/hybrid_water/snow_undrained.py at actual canonical2a14f209',calendar_validation_body_lf_sha256=SHA(body.encode()),calendar_guard_body_copied_literal=True,physical_equations_changed=False,native_format_changed=False,already_completed_Windows_daily_source='262e9cbc3d44244d0e8ca720e0c7147228be3b98',already_completed_Windows_daily_contexts=8,prior_completed_model_periods_to_replay=0)
contract['new_domain'].update(SWHYST=[0,1,2],NPRINTDAY='1..1440 existing owner bounds',SWMONTH=[0,1],PERIOD='0..366 when not monthly',SWRES=[0,1],FLPRINTDT=[False,True],SWCSV=[0,1,2,3])
contract['tests'].update(Windows_O0_O2_new35day_contexts=28,Ubuntu_O0_O2_new35day_contexts=28,total_new_contexts=56,calendar_representatives='Each kind: history0 subdaily and monthly; history1 subdaily; history2 monthly. Additional water/history1 and CDE/history2 step/reset representatives. Both O0/O2 and platforms.',daily_Windows8_reused_without_model_replay=True)
with (E/'EXPLICIT_BOTTOM9_SNOW_HISTORY_CONTRACT_V2.json').open('x') as f:json.dump(contract,f,indent=2)
with (E/'EXPLICIT_BOTTOM9_SNOW_HISTORY_CALENDAR_PROPOSAL_V2.json').open('x') as f:json.dump(dict(status='PROPOSED_LITERAL_EXISTING_CALENDAR_VALIDATION_AND_EXISTING_TYPED_STATE_REUSE_NOT_APPLIED',actual_base=BASE,calendar_owner_body_sha256=SHA(body.encode()),new_snow_provider_lf_sha256=SHA(new.encode()),native_or_physical_state_changed=False),f,indent=2)
print('PROPOSED_EXISTING_LITERAL_CALENDAR_GUARD_56_CONTEXT_COHERENT_BATCH',SHA(body.encode()))
