import hashlib,json,re,shutil,subprocess,sys,os
from pathlib import Path
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path.insert(0,str(R/'app/hybrid_water'));import experimental_project as e
from prescribed_snow_boundary import selection
sys.path.insert(0,str(R/'tests/nomacro_drainage'));from explicit_bottom9_snow_history_source_v2 import complete_inverse,git
source=complete_inverse();head=source['actual_head'];target=E/'explicit-bottom9-snow-history-hard-guards-v1';target.mkdir();base=E/'explicit-bottom9-snow-history-calendar-inputs-v3/water-initial1-hys1-subdaily';rows=[]
controls=[('AGE','SWSOLU','2'),('implicit','SWKIMPL','1'),('drainage','SWDRA','1'),('frost','SWFROST','1'),('vapor','SWVAPOR','1 1'),('analytical3','IHWCKMODEL','3 3'),('analytical7','IHWCKMODEL','7 7'),('invalid-history','SWHYST','3'),('invalid-calendar','NPRINTDAY','0'),('invalid-format','SWCSV','4'),('invalid-step','FLPRINTDT','MAYBE'),('invalid-precision','NUM_DECIMALS','13')]
for label,key,value in [('positive',None,None),*controls]:
 path=target/label;path.mkdir()
 for item in base.iterdir():
  if item.is_file():shutil.copyfile(item,path/item.name)
 raw=(path/'swap.swp').read_bytes()
 if key:
  pattern=rb'(?mi)^([ \t]*'+key.encode()+rb'[ \t]*=[ \t]*)[^!\r\n]*';raw,count=re.subn(pattern,lambda m:m[1]+value.encode()+' '.encode(),raw);assert count==1,(label,key,count)
  (path/'swap.swp').write_bytes(raw)
 selected=selection(path,True);ok=False;reason=None
 try:project=e.load(path,original_output=True,time_step_policy='original-adaptive-day-seed-v1');ok=True
 except ValueError as error:reason=str(error)
 assert ok==(label=='positive') and (selected is not None)==(label=='positive'),(label,ok,selected)
 rows.append(dict(label=label,field=key,value=value,input_sha256=hashlib.sha256(raw).hexdigest(),frontend_accepted=ok,bounded_selection=selected,diagnostic=reason))
assert git('rev-parse','HEAD').decode().strip()==head;complete_inverse()
q=dict(status='ACTUAL_CURRENT_SNOW_HISTORY_POSITIVE_AND_TWELVE_UNQUALIFIED_DOMAIN_HARD_REFUSALS_PASS',source=head,checks=rows,compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_SNOW_HISTORY_HARD_GUARDS_V1.json').open('x') as f:json.dump(q,f,indent=2)
print(q['status'])
