"""Re-read unchanged original official Snow-history raw with actual locations."""
import argparse,hashlib,json,sys,zipfile,types
from pathlib import Path
from contextlib import ExitStack
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_snow_history_source_v2 import complete_inverse,git
from explicit_bottom9_snow_history_science_v2 import audit,native_controls
from explicit_bottom9_compiled_postimage import compare
from explicit_bottom9_analytical_central import capsule
from analytical_hydraulic_archives import SHA
p=argparse.ArgumentParser()
for n in ('archive','scratch','output'):p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--sha256',required=True);p.add_argument('--optimization',choices=('O0','O2'),required=True);a=p.parse_args()
source=complete_inverse();producer='6154891091824c9f0f64c9fff299ad320ccd9479'
assert not git('diff',producer,'HEAD','--','app','src','tools/solute','tools/vq','reference')
assert SHA(a.archive.read_bytes())==a.sha256 and a.scratch.is_dir() and not any(a.scratch.iterdir())
results=[];controls=[]
with ExitStack() as stack:
 z=stack.enter_context(zipfile.ZipFile(a.archive));names=z.namelist();assert len(names)==len(set(names))
 class Store:
  def get(self,n):return z.read(n)
 store=Store()
 # All blob/member/source checks in the admitted capsule reader execute unchanged;
 # the actual producer is the actual composition anchor for this new raw.
 check=types.FunctionType(capsule.__code__,dict(capsule.__globals__,ANALYTICAL_CORE=producer))
 cap=check(store,'source',producer,stack,'controller-source')
 original=cap.read('reference/swap-4.3.1/source-archives/SWAP.ZIP');assert SHA(original)=='1a2d798994c2990b397f9349317e3a26f40662fbcff55c9ea484dd638af45151'
 workflow=git('show',producer+':.github/workflows/nomacro-explicit-bottom9-snow-history.yml');assert z.read('actual-workflow.yml')==workflow
 assert z.read('actual-workflow-git-blob.txt').decode().strip()==hashlib.sha1(b'blob '+str(len(workflow)).encode()+b'\0'+workflow).hexdigest()
 prepared=json.loads(z.read('provider-PREPARED.json'));assert prepared['source_archives']['SWAP.ZIP']==SHA(original)
 for name,digest in prepared['provider_files'].items():
  if name.startswith('build/'):assert SHA(z.read('original-provider-build/'+name[len('build/'):]))==digest
 for name in names:
  path=a.scratch/name;assert path.resolve().is_relative_to(a.scratch.resolve());path.parent.mkdir(parents=True,exist_ok=True)
  with path.open('xb') as f:f.write(z.read(name))
 batch=json.loads(z.read('BATCH.json'));assert batch['source']==batch['actual_completion_head']==producer and batch['optimization']==a.optimization and len(batch['contexts'])==14 and batch['status']=='ALL14_SNOW_HISTORY_CALENDAR_CONTEXTS_INDEPENDENT_NATIVE_COLD_AND_INITIAL2_PASS_NOT_ADMITTED'
 projection=json.loads(z.read('COMPILED_PROJECTION_V1.json'));assert len(projection)==28
 prefix='/home/runner/work/_temp/proof/'
 def locate(value):
  assert value.startswith(prefix),value
  return a.scratch/value[len(prefix):]
 def built(value):
  item=projection[value];path=a.scratch/item['archive_prefix'];assert SHA((path/'BUILD.json').read_bytes())==item['actual_BUILD_sha256'];return path
 for role in batch['contexts']:
  profile=locate(role['profile']);post=locate(role['current_initial2_postimage']);q=json.loads((profile/'RESULT.json').read_text());c=json.loads((post/'RESULT.json').read_text());first,second=built(q['build_root']),built(c['build_root']);inputs=locate(q['input_root']);counter=locate(c['input_root'])
  assert q['source']==c['source']==c['actual_compiler_start_HEAD']==c['actual_compiler_end_HEAD']==producer and role['profile_producer']==producer
  assert c['profile']==role['profile'] and c['profile_RESULT_sha256']==SHA((profile/'RESULT.json').read_bytes()) and c['model_executions']==0
  assert SHA((first/'BUILD.json').read_bytes())==c['actual_initial1_BUILD_sha256'] and SHA((second/'BUILD.json').read_bytes())==c['actual_initial2_BUILD_sha256']
  assert {x.relative_to(counter).as_posix():SHA(x.read_bytes()) for x in counter.rglob('*') if x.is_file()}==c['input_inventory']
  for row in c['generated_sources']:
   left=(first/row['file']).read_bytes();right=(second/row['file']).read_bytes();assert SHA(left)==row['actual_initial1_sha256'] and SHA(right)==row['actual_initial2_sha256'] and left.replace(b'\r\n',b'\n')==right.replace(b'\r\n',b'\n')
  assert compare(first,second)==c['compiled']
  actual=audit(profile,dict(inputs=inputs,build=first));assert actual==json.loads(locate(role['independent']).read_text()) and SHA(locate(role['independent']).read_bytes())==role['independent_sha256']
  if role['native_controls']:
   actual_native=native_controls(locate(role['native_controls']),profile,dict(inputs=inputs,build=first));expected=a.scratch/(role['label']+'-'+a.optimization+'-NATIVE-INDEPENDENT.json');assert actual_native==json.loads(expected.read_text());controls.append(actual_native)
  if role['transactions']:
   t=json.loads((locate(role['transactions'])/'RESULT.json').read_text());assert t['status']=='ACTUAL_SNOW_HISTORY_CALENDAR_EXTERNAL_DISCARD_REPLAY_ACCEPT_RECOVER_PASS' and t['actual_compiler_producer']==t['actual_control_source']==producer and t['actual_BUILD_sha256']==SHA((first/'BUILD.json').read_bytes()) and t['transactions']==dict.fromkeys(('discard_no_day_advance','replay_exact','accept_exact','recovered_next_day_exact','origin_unchanged'),True)
  results.append(actual);print('ORIGINAL_OFFICIAL_CENTRAL_SNOW_HISTORY_ALL_NODE_NATIVE_COLD_WHOLE_COMPILED_PASS',role['label'],a.optimization,flush=True)
 assert len(results)==14 and len(controls)==4
record=dict(status='ALL14_ORIGINAL_OFFICIAL_SNOW_HISTORY_CONTEXTS_SOURCE_PROVIDER_ALL_NODE_SCIENCE_NATIVE_COLD_AND_WHOLE_COMPILED_CENTRAL_PASS_NOT_ADMITTED',optimization=a.optimization,actual_producer=producer,original_artifact_sha256=a.sha256,archive_members=len(names),contexts=results,native_controls=controls,compiler_executions=0,model_executions=0,canonical_admission=False)
with a.output.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(record['status'],a.optimization,flush=True)
