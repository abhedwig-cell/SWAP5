import hashlib,json,sys,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;P=R/'integration/f-ci/nomacro-complete01';sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from groundwater_snow_archive_storage import store_original
specs={'O0':(14867590581,70313069,'f00d6ba41ee6b91248fe8e9d0981c924e984d0ec628ab60da6496bab291ba6ac'),'O2':(14868715767,70796593,'cd56798404c1452cf1e8f0c0f0ebaddbba94308e129689739c4865ef57ab4b0f')}
for opt,(artifact,size,digest) in specs.items():
 name='EXPLICIT_BOTTOM9_SNOW_HISTORY_UBUNTU_'+opt+'_ORIGINAL_V1';archive=E/(name+'.zip');assert archive.stat().st_size==size and hashlib.sha256(archive.read_bytes()).hexdigest()==digest;members={}
 with zipfile.ZipFile(archive) as z:
  assert len(z.namelist())==len(set(z.namelist()))
  batch=json.loads(z.read('BATCH.json'));assert len(batch['contexts'])==14 and 'PASS_NOT_ADMITTED' in batch['status']
  for key in z.namelist():raw=z.read(key);members[key]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 stored=store_original(archive,P,name+'.zip');q=dict(**stored,members=members,actual_artifact=artifact,actual_run=45275139165,actual_producer='6154891091824c9f0f64c9fff299ad320ccd9479',optimization=opt,status='ORIGINAL_OFFICIAL_SNOW_HISTORY_CALENDAR_ARCHIVE_EXACT_BYTES_SEALED_NOT_ADMITTED',contexts=14,native_calendar_samples=98,exact_cold_windows=42,compiled_initialization_postimages=14,compiled_native_refusals=100,external_transactions=2,canonical_admission=False)
 with (P/(name+'.json')).open('x') as f:json.dump(q,f,indent=2);f.write('\n')
 print(name,size,digest,len(members),flush=True)
