"""Preserve every actual Windows producer, raw period, control and compiled closure."""
import json,subprocess,sys
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent;sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from initial_profile_frost_preserve import seal
from analytical_hydraulic_archives import SHA
files={};extra={};projection={};batches=[];prior=[]
def tree(path,prefix):
 assert path.is_dir() and not path.is_symlink()
 for child in sorted(path.rglob('*')):
  assert not child.is_symlink()
  if child.is_file():
   key=prefix+'/'+child.relative_to(path).as_posix();assert key not in files;files[key]=child

def build(value):
 path=Path(value)
 if str(path) not in projection:
  prefix='compiled/'+path.parent.parent.name+'/'+path.parent.name+'/'+path.name
  assert not any(x['archive_prefix']==prefix for x in projection.values()),prefix
  tree(path,prefix);projection[str(path)]=dict(archive_prefix=prefix,actual_BUILD_sha256=SHA((path/'BUILD.json').read_bytes()))
for opt in ('O0','O2'):
 root=E/f'explicit-bottom9-snow-history-full-{opt}-v1';q=json.loads((root/'BATCH.json').read_text());assert len(q['contexts'])==14 and q['status']=='ALL14_SNOW_HISTORY_CALENDAR_CONTEXTS_INDEPENDENT_NATIVE_COLD_AND_INITIAL2_PASS_NOT_ADMITTED';tree(root,'profiles/'+root.name);batches.append(dict(optimization=opt,path='profiles/'+root.name+'/BATCH.json'))
 for role in q['contexts']:
  profile=Path(role['profile']);first=json.loads((profile/'RESULT.json').read_text());build(first['build_root']);post=Path(role['current_initial2_postimage']);build(json.loads((post/'RESULT.json').read_text())['build_root'])
  if not profile.is_relative_to(root):tree(profile,'profiles/'+profile.name)
 root=E/f'explicit-bottom9-snow-history-prior-postimages-{opt}-v1';q=json.loads((root/'RESULT.json').read_text());assert len(q['contexts'])==6 and q['status']=='ALL6_OPT_CURRENT_SNOW_HISTORY_UNCHANGED_PARENT_WHOLE_COMPILED_POSTIMAGES_PASS_NO_MODEL_PERIODS';tree(root,'profiles/'+root.name);prior.append(dict(optimization=opt,path='profiles/'+root.name+'/RESULT.json'))
 for role in q['contexts']:build(role['build_root'])
# Retain the inactive-CDE original finding and its failed external assertion.
for path in sorted(E.iterdir()):
 name=path.name.lower()
 if path.is_dir() and name.startswith(('explicit-bottom9-snow-cal-','explicit-bottom9-snow-history-inputs-','explicit-bottom9-snow-history-calendar-inputs-','explicit-bottom9-snow-effective-cde-inputs-','explicit-bottom9-snow-history-hard-guards-','explicit-bottom9-snow-history-actual-source-')):
  prefix='profiles/'+path.name
  if not any(k.startswith(prefix+'/') for k in files):tree(path,prefix)
  if (path/'RESULT.json').is_file():
   q=json.loads((path/'RESULT.json').read_text())
   if q.get('build_root') and (Path(q['build_root'])/'BUILD.json').is_file():build(q['build_root'])
 elif path.is_file() and name.startswith(('explicit-bottom9-snow-history-','explicit_bottom9_snow_history_','explicit-bottom9-snow-cal-','explicit_bottom9_snow_calendar_','explicit_bottom9_snow_cal_','explicit-bottom9-snow-portable-')) and not name.endswith('.zip'):
  files['observations/'+path.name]=path
# Original provider is independently pinned by its PREPARED source inventory.
provider=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');tree(provider/'build','original-provider-build');files['provider-PREPARED.json']=provider/'PREPARED.json'
scope=('app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','tests/nomacro_mixtures','tests/saltfarm_newton','reference/swap-4.3.1','.github/workflows/nomacro-explicit-bottom9-snow-history.yml')
epochs={};objects={}
for head in ('262e9cbc3d44244d0e8ca720e0c7147228be3b98','b79a5bc64ec5806252c016185e925d424d65b66b','6154891091824c9f0f64c9fff299ad320ccd9479'):
 entries={}
 for line in subprocess.check_output(['git','ls-tree','-r',head,'--',*scope],cwd=R).decode().splitlines():
  meta,path=line.split('\t');mode,kind,digest=meta.split();assert kind=='blob';entries[path]=dict(mode=mode,git_blob=digest);objects[digest]=None
 epochs[head]=entries
p=subprocess.Popen(['git','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
try:
 for digest in objects:
  p.stdin.write((digest+'\n').encode());p.stdin.flush();header=p.stdout.readline().decode().split();assert header[:2]==[digest,'blob'];raw=p.stdout.read(int(header[2]));assert p.stdout.read(1)==b'\n';assert __import__('hashlib').sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==digest;extra['committed-source/blobs/'+digest]=raw
finally:p.stdin.close();assert p.wait(timeout=30)==0
extra['COMMITTED_SOURCE_INDEX_V1.json']=(json.dumps(dict(scope=scope,epochs=epochs,working_source_capture_claimed=False,actual_current_working_capture='profiles/explicit-bottom9-snow-history-actual-source-615-v1/RESULT.json'),indent=2)+'\n').encode()
extra['COMPILED_PROJECTION_V1.json']=(json.dumps(projection,indent=2)+'\n').encode();extra['actual-sealer.py']=Path(__file__).read_bytes()
name='EXPLICIT_BOTTOM9_SNOW_HISTORY_WINDOWS_RAW_V1';seal(W/'explicit-bottom9-snow-history-windows-seal-stage-v1'/(name+'.zip'),name,files,extra,dict(status='ALL28_WINDOWS_SNOW_HISTORY_CALENDAR_RAW_ALL_COMPILED_AND_FAILED_CONTROLS_PRESERVED_NOT_ADMITTED',batches=batches,prior=prior,contexts=28,compiled_closures=len(projection),compiled_initialization_postimages=28,prior_compiler_preservation_postimages=12,native_calendar_samples=196,exact_cold_windows=84,original_completed_model_periods_replayed=0,canonical_admission=False))
