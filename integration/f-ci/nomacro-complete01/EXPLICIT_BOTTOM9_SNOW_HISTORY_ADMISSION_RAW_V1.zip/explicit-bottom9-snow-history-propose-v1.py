import difflib,hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');BASE='2a14f2094bfbfb29c169eb6331da1d7829faa70a';SHA=lambda x:hashlib.sha256(x).hexdigest()
edits={
 'app/hybrid_water/prescribed_head_flux_boundary.py':('if hysteresis not in (0,1,2) or snow and hysteresis!=0:return None','if hysteresis not in (0,1,2):return None'),
 'app/hybrid_water/prescribed_snow_boundary.py':('selected=paired(directory,original_output,snow=True)',"selected=paired(directory,original_output,hysteresis=s.get('SWHYST'),snow=True)")}
parts=[];files={}
for path,(old,new) in edits.items():
 raw=subprocess.check_output(['git','show',BASE+':'+path],cwd=R);text=raw.decode();assert text.count(old)==1;changed=text.replace(old,new,1);assert changed.replace(new,old,1)==text
 parts.extend(difflib.unified_diff(text.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path));files[path]=dict(before_lf_sha256=SHA(raw),proposed_lf_sha256=SHA(changed.encode()),literal_old=old,literal_new=new)
patch=''.join(parts).encode()
with (E/'EXPLICIT_BOTTOM9_SNOW_HISTORY_PROPOSED_V1.patch').open('xb') as f:f.write(patch)
record=dict(status='PROPOSED_TWO_EXACT_ADMISSION_GUARD_EDITS_EXISTING_SNOW_HISTORY_AND_TYPED_NATIVE_UNCHANGED_NOT_APPLIED',actual_canonical=BASE,files=files,patch_sha256=SHA(patch),classification='B_EXISTING_PROCESS_COMPOSITION_WITH_C_EXISTING_TYPED_STATE_CONFIGURATION',new_domain=dict(SWBOTB=9,SWSNOW=1,SWHYST=[1,2],SWDRA=0,SWSOLU=[0,1],SWKIMPL=0,IHWCKMODEL=1,SWVAPOR=0,SWFROST=0,SWHEA=1,SWCALT=2,NPRINTDAY=1,SWRES=1,FLPRINTDT=False),physical_equations_changed=False,native_format_changed=False,new_physical_state=False,native_contract='Existing ordinary Snow-undrained domain and root witnesses already bind SWHYST and SWBOTB; original result.end retains all scanning state. Prove actual generated provider unchanged; never assume same magic alone is sufficient.',tests=dict(Windows_O0_O2_new35day_contexts=8,Ubuntu_O0_O2_new35day_contexts=8,each_native_checkpoints=7,each_exact_cold_windows=3,original_Snow_accumulation_melt_and_allnode_soil_global_CDE_ledgers=True,typed_native_and_external_transaction_refusals=True,unchanged_prior_whole_generated_compiled_postimages=True),current_vapor_thermal_failure='Separate unadmitted branch1069/6f1 preserves two300s censors and real original O0/O2 endpoint storage observations; no vapor, AGE, Frost, implicit or analytical crossadmission here.',global_counts='UNKNOWN',whole_completion='PARTIAL',whole_science='NOT_QUALIFIED',RC3_changed=False,model_executions=0,compiler_executions=0)
with (E/'EXPLICIT_BOTTOM9_SNOW_HISTORY_PROPOSED_V1.json').open('x') as f:json.dump(record,f,indent=2)
print(record['status'],SHA(patch))
