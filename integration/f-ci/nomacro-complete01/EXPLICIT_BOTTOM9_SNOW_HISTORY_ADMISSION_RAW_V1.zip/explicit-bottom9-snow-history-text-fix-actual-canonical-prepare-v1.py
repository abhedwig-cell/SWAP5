"""Move the owned actual canonical observer checkout only after exact merge gates."""
import argparse,hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).parent;C=Path('C:/Users/Veldh012/swap5-implicit-conductivity-canonical01');TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
p=argparse.ArgumentParser();p.add_argument('--canonical',required=True);p.add_argument('--candidate',required=True);p.add_argument('--tree',required=True);a=p.parse_args()
state=json.loads(Path('C:/Users/Veldh012/.codex/storage/swap5/state.json').read_text());norm=lambda p:str(Path(p).resolve()).casefold();owned=[r for r in state['resources'].values() if norm(r['path'])==norm(C)];assert len(owned)==1 and owned[0]['task']==TASK
for owner,task in state['tasks'].items():
 if owner!=TASK:
  for item in task.get('protects',[]):
   first,second=norm(item),norm(C);assert first!=second and not first.startswith(second+'\\') and not second.startswith(first+'\\'),'Other task has overlapping canonical observer dependency'
git=lambda *args:subprocess.check_output(['git',*args],cwd=C).decode().strip()
fixtures=json.loads((E/'EXPLICIT_BOTTOM9_COMBINED_CLEAN14_CHECKOUT_PREPARATION_V1.json').read_text())['actual_original_project_files']
def snap():
 files={name:hashlib.sha256((C/name).read_bytes()).hexdigest() for name in fixtures};assert files==fixtures and len(files)==56
 return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all','--ignored'),sparse=git('sparse-checkout','list').splitlines(),original_project_files=files)
before=snap();assert before['head']==a.candidate and not before['status'] and len(before['sparse'])==14
assert git('rev-parse',a.canonical+'^{tree}')==git('rev-parse',a.candidate+'^{tree}')==a.tree
assert git('show','-s','--format=%P',a.canonical).split()==['2500ed23990dff450e2da31b85c900c06e0506c3',a.candidate]
subprocess.run(['git','switch','--detach',a.canonical],cwd=C,check=True,capture_output=True)
after=snap();assert after['head']==a.canonical and after['tree']==a.tree and not after['status'] and before['sparse']==after['sparse']
with (E/'EXPLICIT_BOTTOM9_SNOW_HISTORY_TEXT_FIX_ACTUAL_CANONICAL_CHECKOUT_PREPARATION_V1.json').open('x') as f:json.dump(dict(status='REAL_ACTUAL_CANONICAL_OWNED_CLEAN14_WITH56_ORIGINAL_INPUTS_AND_NO_PROJECTION',before=before,after=after,repository=str(C)),f,indent=2)
print('ACTUAL_CANONICAL_CLEAN14_REAL_CHECKOUT',after['head'])
