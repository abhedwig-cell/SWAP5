"""Cancel only own superseded09d PR1792 runs after verifying current0b head."""
import http.client,json,os,subprocess
from pathlib import Path

ROOT='C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01'
EVIDENCE=Path(__file__).resolve().parent
OLD='09d5e3fb48cd2c725091bd8a1108f06e080f5520'
NEW='0b877946fdd389250c67a0bbddc02209e754b08a'
assert OLD!=NEW
r=subprocess.run(['git','credential','fill'],cwd=ROOT,input=b'protocol=https\nhost=github.com\npath=abhedwig-cell/SWAP5.git\n\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'),timeout=30)
if r.returncode:raise RuntimeError('Existing repository authentication unavailable; no credentials printed')
values=dict(line.split(b'=',1) for line in r.stdout.splitlines() if b'=' in line)
token=values.get(b'password')
if not token:raise RuntimeError('Existing repository authentication has no API secret; no credentials printed')


def api(method,path):
    connection=http.client.HTTPSConnection('api.github.com',timeout=60)
    connection.request(method,'/repos/abhedwig-cell/SWAP5/'+path,headers={'Authorization':'Bearer '+token.decode(),'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-owned-superseded-qualification-retirement'})
    response=connection.getresponse();code=response.status;raw=response.read();connection.close()
    if code not in (200,202,409):raise RuntimeError('GitHub owned-run action HTTP '+str(code)+'; no credentials printed')
    return code,json.loads(raw) if raw else None


_,pr=api('GET','pulls/1792')
assert pr['head']['sha']==NEW and not pr['merged'] and pr['state']=='open'
_,runs=api('GET','actions/runs?head_sha='+OLD+'&per_page=100')
assert runs['total_count']==len(runs['workflow_runs']) and len(runs['workflow_runs'])>=13
with (EVIDENCE/'EXPLICIT_BOTTOM9_SNOW_HISTORY_TEXT_FIX_SUPERSEDED09D_CI_ORIGINAL_API_V1.json').open('x') as stream:json.dump(runs,stream,indent=2)
record=dict(status='RUNNING',PR=1792,superseded=OLD,current=NEW,reason='Final candidate0b fixes the operational negative-control raw archive reference and adds an actual committed-path regression. Actual CRLF09d public and all original scientific results stay preserved; stop only own superseded09d PR1792 runs and never label their terminal outcomes as new0b qualification',runs=[])
target=EVIDENCE/'EXPLICIT_BOTTOM9_SNOW_HISTORY_TEXT_FIX_SUPERSEDED09D_CI_RETIREMENT_V1.json'
assert not target.exists()
try:
    for item in runs['workflow_runs']:
        assert item['head_sha']==OLD and item['event']=='pull_request' and item['head_branch']=='codex/nomacro-snow-history-text-custody-fix01'
        _,actual=api('GET','actions/runs/'+str(item['id']))
        assert actual['head_sha']==OLD and any(p['number']==1792 for p in actual['pull_requests'])
        row=dict(id=actual['id'],name=actual['name'],original_status=actual['status'],original_conclusion=actual['conclusion'])
        if actual['status']=='completed':row['action']='RETAINED_ACTUAL_TERMINAL_OUTCOME_NO_CANCELLATION'
        else:
            code,_=api('POST','actions/runs/'+str(item['id'])+'/cancel')
            row.update(action='REQUESTED_OWN_SUPERSEDED_RUN_CANCELLATION' if code==202 else 'CANCELLATION_RACED_TERMINAL_OR_NOT_CANCELLABLE',HTTP_status=code)
        record['runs'].append(row)
        target.write_text(json.dumps(record,indent=2)+'\n')
    record['status']='ONLY_OWN_SUPERSEDED_PR1792_RUNS_RETIRED_WITH_ORIGINAL_OUTCOMES_PRESERVED_NOT_A_CURRENT_PASS'
finally:
    target.write_text(json.dumps(record,indent=2)+'\n')
    del token,values,r
print(record['status'],len(record['runs']),sum(q.get('HTTP_status')==202 for q in record['runs']),flush=True)
