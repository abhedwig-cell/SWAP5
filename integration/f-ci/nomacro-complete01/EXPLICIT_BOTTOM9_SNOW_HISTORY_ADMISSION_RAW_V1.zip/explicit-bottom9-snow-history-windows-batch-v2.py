import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');SOURCE='262e9cbc3d44244d0e8ca720e0c7147228be3b98';TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';CLEANUP=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');SHA=lambda raw:hashlib.sha256(raw).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=('O0','O2'),required=True);a=p.parse_args();opt=a.optimization
git=lambda *args:subprocess.check_output(['git',*args],cwd=R).decode().strip()
assert git('rev-parse','HEAD')==SOURCE and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OMP_NUM_THREADS='1',TEMP=str(W/'active-python-scratch'),TMP=str(W/'active-python-scratch'));env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
target=E/('EXPLICIT_BOTTOM9_SNOW_HISTORY_WINDOWS_'+opt+'_BATCH_V2.json');assert not target.exists();record=dict(status='RUNNING',actual_source=SOURCE,optimization=opt,controller_sha256=SHA(Path(__file__).read_bytes()),contexts=[],canonical_admission=False,prior280_model_periods_replayed=0);started=time.monotonic()
save=lambda:target.write_text(json.dumps(record,indent=2)+'\n')
def run(command,label,timeout=1000):
 assert git('rev-parse','HEAD')==SOURCE and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
 with (E/(label+'.stdout.txt')).open('xb') as out,(E/(label+'.stderr.txt')).open('xb') as err:r=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=timeout)
 assert r.returncode==0,dict(label=label,returncode=r.returncode)
save()
try:
 for kind in ('water','cde'):
  for history in (1,2):
   label='explicit-bottom9-snow-history-'+kind+'-hys'+str(history)+'-'+opt+'-v1';profile=E/label;build=W/label;inputs=E/'explicit-bottom9-snow-history-inputs-v1'/(kind+'-initial1-hys'+str(history));record['active']=label;save()
   if opt=='O0' and kind=='water' and history==1:
    science=E/'EXPLICIT_BOTTOM9_SNOW_HISTORY_WATER_HYS1_O0_FIRST_INDEPENDENT_V1.json';q=json.loads(science.read_text());actual=json.loads((profile/'RESULT.json').read_text());assert q['producer']==actual['source']==SOURCE and 'PASS' in q['status'] and 'PASS' in actual['status'];reused=True
   else:
    assert opt=='O2', 'V2 resumes only the unstarted O2 cohort'
    registry=json.loads(Path('C:/Users/Veldh012/.codex/storage/swap5/state.json').read_text())
    owned=[r for r in registry['resources'].values() if Path(r['path']).resolve()==build.resolve()];assert len(owned)==1 and owned[0]['task']==TASK and owned[0]['source_ref']==SOURCE and owned[0]['variant']==opt
    science=E/('EXPLICIT_BOTTOM9_SNOW_HISTORY_'+kind.upper()+'_HYS'+str(history)+'_'+opt+'_INDEPENDENT_V1.json');reused=False
    run([sys.executable,'-B','tests/nomacro_drainage/explicit_bottom9_snow_history_runtime.py','--input',str(inputs),'--reference-work',str(J),'--build-root',str(build),'--output',str(profile),'--optimization',opt],label+'-runtime')
    run([sys.executable,'-B','tests/nomacro_drainage/explicit_bottom9_snow_history_science.py','--profile',str(profile),'--output',str(science)],label+'-reader')
    q=json.loads(science.read_text());actual=json.loads((profile/'RESULT.json').read_text())
   assert q['producer']==actual['source']==actual['actual_completion_head']==SOURCE and 'PASS' in q['status'] and q['actual_days']==35 and q['actual_exact_cold_windows']==3 and q['actual_native_checkpoints']==7
   record['contexts'].append(dict(kind=kind,hysteresis=history,optimization=opt,profile=str(profile),build=str(build),independent=str(science),independent_sha256=SHA(science.read_bytes()),already_completed_period_reused=reused,status=q['status']));save();print('ACTUAL_SNOW_HISTORY35_NATIVE_COLD_INDEPENDENT_PASS',kind,history,opt,flush=True)
 record.update(status='ALL4_WINDOWS_'+opt+'_SNOW_HISTORY35_ORIGINAL_LEDGER_NATIVE_AND_THREE_COLD_EACH_INDEPENDENT_PASS_NOT_ADMITTED',seconds=time.monotonic()-started);record.pop('active',None)
except Exception as error:record.update(status='FAILED_ACTUAL_WINDOWS_SNOW_HISTORY_BATCH_NOT_QUALIFIED',error=repr(error));raise
finally:record['actual_completion_head']=git('rev-parse','HEAD');save()
assert record['actual_completion_head']==SOURCE
print(record['status'],record['seconds'],flush=True)
