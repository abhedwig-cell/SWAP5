from pathlib import Path
E=Path(__file__).parent;source=(E/'explicit-bottom9-snow-history-windows-batch-v1.py').read_text();lines=[];count=0
for line in source.splitlines(keepends=True):
 if 'allocated=subprocess.run' in line:
  count+=1;indent=line[:len(line)-len(line.lstrip())]
  lines.append(indent+"assert opt=='O2', 'V2 resumes only the unstarted O2 cohort'\n")
  lines.append(indent+"registry=json.loads(Path('C:/Users/Veldh012/.codex/storage/swap5/state.json').read_text())\n")
  lines.append(indent+"owned=[r for r in registry['resources'].values() if Path(r['path']).resolve()==build.resolve()];assert len(owned)==1 and owned[0]['task']==TASK and owned[0]['source_ref']==SOURCE and owned[0]['variant']==opt\n")
 else:lines.append(line)
assert count==1;source=''.join(lines).replace('_BATCH_V1.json','_BATCH_V2.json')
with (E/'explicit-bottom9-snow-history-windows-batch-v2.py').open('x') as f:f.write(source)
