* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-23 22:07:02

Period             :  1900-01-01  until  2002-02-04 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        25.38 cm       0.2139E+01 mg/cm2
Initial :        22.27 cm       0.2187E+00 mg/cm2
            =============       =================
Change            3.11 cm       0.1920E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :     1.40    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.69
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.00
                             Crack flux        :     0.00
=========================    ============================
Sum            :     3.80    Sum               :     0.69


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.1920E+01    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.1920E+01    Sum            :  0.0000E+00

