import pathlib,json,re,csv,io,sys
from contextlib import ExitStack
R=pathlib.Path.cwd();E=pathlib.Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_analytical_parent_postimages import role,materialize
from analytical_hydraulic_archives import SHA
import experimental_project as experimental
root=E/'explicit-bottom9-snow-inputs-v1';root.mkdir();observed=[]
with ExitStack() as stack:
 for kind in ['water','cde']:
  archive,inputs,item,q,old=role(R/'integration/f-ci/nomacro-complete01',kind+'-pressure-daily','O0',stack)
  for initial in [1,2]:
   out=root/(kind+'-initial'+str(initial));original=materialize(inputs,item['inputs'],out,q['input_inventory'])
   text=(out/'swap.swp').read_bytes().decode('cp1252').replace('\r\n','\n').replace('\r','')
   changes=dict(SWSNOW=1,SWINCO=initial,SNOWINCO=0.4,GWLI=-1200.0)
   for key,value in changes.items():
    text,n=re.subn(r'(?mi)^([ \t]*'+key+r'[ \t]*=[ \t]*)[^!\n]*',lambda m:m[1]+str(value)+' ',text);assert n==1,(key,n)
   for pattern,body in [(r'(?mis)^[ \t]*HTB[ \t]*=[ \t]*\n.*?^[ \t]*\* End of table','  HTB =\n -0.5 -1199.5\n -195.0 -1005.0\n* End of table'),(r'(?mis)^[ \t]*DATE9A HBOT9[ \t]*\n.*?^[ \t]*\* End of table','DATE9A HBOT9\n2002-01-01 -1000.0\n2004-01-01 -1000.0\n* End of table'),(r'(?mis)^[ \t]*DATE9B QBOT9[ \t]*\n.*?^[ \t]*\* End of table','DATE9B QBOT9\n2002-01-01 0.0\n2004-01-01 0.0\n* End of table')]:
    text,n=re.subn(pattern,lambda m:body,text);assert n==1
   (out/'swap.swp').write_bytes(text.encode('cp1252'))
   lines=(out/'283.met').read_bytes().decode('cp1252').replace('\r\n','\n').replace('\r','').splitlines();found=0
   for index,line in enumerate(lines):
    if not line.strip() or line.lstrip().startswith('*'):continue
    fields=next(csv.reader([line]));
    if len(fields)!=12 or fields[0].strip().lower()=='station':continue
    day,month,year=map(int,fields[1:4])
    if year==2002 and (month==1 or month==2 and day<=4):
     fields[9]='2.0' if month==1 and day<=7 else '0.0';fields[10]='0.0';found+=1;lines[index]=','.join(fields)
   assert found==35
   (out/'283.met').write_bytes(('\n'.join(lines)+'\n').encode('cp1252'))
   refusal=None
   try:experimental.load(out,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
   except ValueError as error:refusal=str(error)
   assert refusal is not None,'Snow9 must be refused by unchanged parent source'
   observed.append(dict(kind=kind,initial=initial,input_root=str(out),source_archive=archive.record['archive'],source_archive_sha256=archive.record['sha256'],actual_original_inventory=original,actual_new_inventory={p.relative_to(out).as_posix():SHA(p.read_bytes()) for p in out.rglob('*') if p.is_file()},changes=changes,hydrostatic_pressure='h=-1200-z; bottom-table h=-1000 at200cm, qbot0; exact original initial1/2 alternatives',forcing='First7days2mm/d rainfall, remaining28days dry; actual original temperature/radiation/wind/humidity; prescribed ETref0',parent_refusal=refusal))
q=dict(status='FOUR_ACTUAL_HYDROSTATIC_DRY_PROFILE_SNOW9_INPUTS_PARENT_REFUSED_NO_BUILDS_OR_MODEL_PERIODS',actual_parent_head=__import__('subprocess').check_output(['git','rev-parse','HEAD'],text=True).strip(),inputs=observed,model_executions=0,compiler_executions=0,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_SNOW_INPUTS_V1.json').open('x') as f:json.dump(q,f,indent=2)
print(q['status'],[(x['kind'],x['initial'],x['parent_refusal']) for x in observed],flush=True)
