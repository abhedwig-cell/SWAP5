import pathlib,json,subprocess,sys,zipfile,hashlib,time,os
R=pathlib.Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=pathlib.Path(__file__).parent
C='C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py';TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';BASE='04dadca2bf52027ef9c72360684c86bd98aa77ff';P='C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
head=git('rev-parse','HEAD');branch=git('branch','--show-current');assert branch=='codex/nomacro-explicit-bottom9-snow01' and not git('status','--porcelain','--untracked-files=all','--ignored')
sparse=pathlib.Path(git('rev-parse','--git-path','info/sparse-checkout'));sparse=sparse if sparse.is_absolute() else R/sparse;patterns=sparse.read_bytes()
fixture_root=R/'reference/swap-4.3.1/projects';fixtures={p.relative_to(R).as_posix():p.read_bytes() for p in fixture_root.rglob('*') if p.is_file()};assert len(fixtures)==56
restore=E/'explicit-bottom9-snow-prior-parent-checkout-recovery-v1';restore.mkdir()
with zipfile.ZipFile(restore/'actual-56-fixture-bytes.zip','x') as z:
 for name,raw in fixtures.items():z.writestr(name,raw)
(restore/'BEFORE.json').write_text(json.dumps(dict(head=head,branch=branch,sparse=patterns.decode().splitlines(),fixtures={k:hashlib.sha256(v).hexdigest() for k,v in fixtures.items()}),indent=2))
roles=json.loads((E/'EXPLICIT_BOTTOM9_SNOW_PRIOR_ORIGINAL_INPUT_CUSTODY_V1.json').read_text());results=[];start=time.monotonic()
def compile_case(epoch,kind,opt):
 assert git('rev-parse','HEAD')==epoch
 label='explicit-bottom9-snow-prior-'+kind+'-'+opt+'-'+('actual-parent' if epoch==BASE else 'candidate')+'-v1';out=E/label;out.mkdir()
 root=pathlib.Path(json.loads(subprocess.check_output([sys.executable,'-B',C,'allocate','--task',TASK,'--kind','build','--name',label,'--variant',opt,'--source-ref',epoch,'--recipe','Actual '+epoch+' unchanged old '+kind+' Snow5/8 input, compile only '+opt+'; no inherited model period; compare full generated source and all compiled bodies'],text=True))['path']);inputs=pathlib.Path(next(r['input_root'] for r in roles if r['kind']==kind))
 command=[sys.executable,'-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy','original-adaptive-day-seed-v1','--reference-work',P,'--build-only','--donor-opt',opt,'--kernel-opt',opt,'--output',str(root/'bundle')]
 with (out/'build.stdout').open('x') as stdout,(out/'build.stderr').open('x') as stderr:done=subprocess.run(command,cwd=R,stdout=stdout,stderr=stderr,timeout=300)
 q=dict(status='ACTUAL_PRIOR_SNOW_COMPILE_ONLY_RETURNED',source=epoch,actual_start_HEAD=epoch,actual_end_HEAD=git('rev-parse','HEAD'),kind=kind,optimization=opt,build_root=str(root/'bundle'),input_root=str(inputs),returncode=done.returncode,command=command,model_executions=0,canonical_admission=False)
 (out/'RESULT.json').write_text(json.dumps(q,indent=2));results.append(dict(profile=str(out),**q));assert q['actual_end_HEAD']==epoch;done.check_returncode();return root/'bundle'
try:
 subprocess.run(['git','switch','--detach',BASE],cwd=R,check=True,stdout=subprocess.DEVNULL)
 assert sparse.read_bytes()==patterns and all((R/k).read_bytes()==v for k,v in fixtures.items())
 for opt in ['O0','O2']:
  for kind in ['water','cde']:compile_case(BASE,kind,opt);print('ACTUAL_PARENT_COMPILE_ONLY_PASS',kind,opt,flush=True)
finally:
 subprocess.run(['git','switch',branch],cwd=R,check=True,stdout=subprocess.DEVNULL)
 assert git('rev-parse','HEAD')==head and sparse.read_bytes()==patterns
 for name,raw in fixtures.items():
  if (R/name).read_bytes()!=raw:(R/name).write_bytes(raw)
 assert all((R/k).read_bytes()==v for k,v in fixtures.items())
 assert not git('status','--porcelain','--untracked-files=all','--ignored')
 (restore/'RESTORED.json').write_text(json.dumps(dict(status='ACTUAL_SNOW_BRANCH_HEAD_SPARSE56_FIXTURE_BITS_AND_CLEAN_WORKTREE_RESTORED',head=head,branch=branch,fixture_count=len(fixtures)),indent=2))
for opt in ['O0','O2']:
 for kind in ['water','cde']:compile_case(head,kind,opt);print('ACTUAL_CANDIDATE_COMPILE_ONLY_PASS',kind,opt,flush=True)
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_compiled_postimage import compare
comparisons=[]
for opt in ['O0','O2']:
 for kind in ['water','cde']:
  prior=next(x for x in results if x['source']==BASE and x['kind']==kind and x['optimization']==opt);current=next(x for x in results if x['source']==head and x['kind']==kind and x['optimization']==opt);a=pathlib.Path(prior['build_root']);b=pathlib.Path(current['build_root']);source=lambda root:{p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in ('.f90','.f','.for','.inc')};left,right=source(a),source(b);assert left.keys()==right.keys();source_records=[]
  for name,p in left.items():
   raw=p.read_bytes();new=right[name].read_bytes();assert raw.replace(b'\r\n',b'\n')==new.replace(b'\r\n',b'\n'),'Prior Snow generated source differs: '+name
   source_records.append(dict(file=name,actual_parent_sha256=hashlib.sha256(raw).hexdigest(),actual_candidate_sha256=hashlib.sha256(new).hexdigest()))
  binary=compare(a,b);comparisons.append(dict(kind=kind,optimization=opt,actual_parent=prior,actual_candidate=current,generated_sources=source_records,compiled=binary))
q=dict(status='ALL4_ACTUAL_PARENT_AND_CANDIDATE_PRIOR_SNOW5_8_COMPLETE_GENERATED_SOURCE_AND_COMPILED_POSTIMAGES_PASS_NO_MODEL_PERIODS',actual_parent=BASE,actual_candidate=head,comparisons=comparisons,actual_compile_only_builds=8,model_executions=0,seconds=time.monotonic()-start,checkout_restored=True,canonical_admission=False)
with (E/'EXPLICIT_BOTTOM9_SNOW_PRIOR_ACTUAL_PARENT_POSTIMAGES_V1.json').open('x') as out:json.dump(q,out,indent=2)
print(q['status'],q['seconds'],flush=True)
