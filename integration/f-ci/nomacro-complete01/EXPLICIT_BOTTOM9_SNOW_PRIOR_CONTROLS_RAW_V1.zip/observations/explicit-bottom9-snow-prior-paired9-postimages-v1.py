import pathlib,json,subprocess,sys,argparse
from contextlib import ExitStack
R=pathlib.Path.cwd();E=pathlib.Path(__file__).parent;C='C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_analytical_parent_postimages import role,materialize,audit
from explicit_bottom9_snow_source_inverse import complete_inverse,CORE,git
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=('O0','O2'),required=True);a=p.parse_args();complete_inverse();head=git('rev-parse','HEAD').decode().strip();name='explicit-bottom9-snow-prior-paired9-cde-monthly-'+a.optimization+'-v1';out=E/name;out.mkdir();inputs=E/(name+'-inputs')
root=pathlib.Path(json.loads(subprocess.check_output([sys.executable,'-B',C,'allocate','--task','01a1e8b4-228b-75f1-8ac4-b07ca1e15713','--kind','build','--name',name,'--variant',a.optimization,'--source-ref',head,'--recipe','Actual unchanged admitted paired9 CDE monthly input onnewSnow source, compile-only fullsource andwholecompiled comparison against original archive; no model periods'],text=True))['path'])
with ExitStack() as stack:
 archive,source,item,meta,old=role(R/'integration/f-ci/nomacro-complete01','cde-monthly',a.optimization,stack);inventory=materialize(source,item['inputs'],inputs,meta['input_inventory'])
 command=[sys.executable,'-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy','original-adaptive-day-seed-v1','--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--build-only','--donor-opt',a.optimization,'--kernel-opt',a.optimization,'--output',str(root/'bundle')]
 with (out/'build.stdout').open('x') as stdout,(out/'build.stderr').open('x') as stderr:done=subprocess.run(command,cwd=R,stdout=stdout,stderr=stderr,timeout=300)
 done.check_returncode();assert git('rev-parse','HEAD').decode().strip()==head
 # Reuse the complete byte comparator unchanged. Its descriptive analytical
 # anchor is the prior numerical code, not a relabelled current producer.
 original=audit(root/'bundle',old,meta,head)
 q=dict(status='ACTUAL_SNOW_SOURCE_PRIOR_PAIRED9_MONTHLY_COMPLETE_SOURCE_AND_COMPILED_POSTIMAGE_PASS_NO_MODEL_PERIOD',actual_compiler_start_HEAD=head,actual_compiler_end_HEAD=head,current_Snow_composition_core=CORE,original_unchanged_analytical_numerical_anchor=original['composition_source'],complete_original_byte_comparison=original,optimization=a.optimization,case='cde-monthly',archive=archive.record['archive'],archive_sha256=archive.record['sha256'],actual_old_profile=item['profile'],input_root=str(inputs),actual_input_inventory=inventory,build_root=str(root/'bundle'),model_executions=0,canonical_admission=False)
 with (out/'RESULT.json').open('x') as f:json.dump(q,f,indent=2)
 print(q['status'],a.optimization,flush=True)
