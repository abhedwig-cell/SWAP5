module hybrid_step_budget
  use MOD_grid, only: numnod, dz
  use MOD_swap_base, only: swsnow, swmacro
  use MOD_macropore, only: NumDm, ICpBtDm, WaSrMpDm, QExcMtxDmCp, QInTopLatDm, QInTopVrtDm, QOutDrRapCp
  use MOD_swap_mp, only: ICTopMP, FrArMtrx, swmbf
  use MOD_drain, only: qdrtot
  use MOD_irrigation, only: nird, qssdisum
  use MOD_meteo, only: nraidt
  use MOD_snow, only: melt
  use MOD_re_global, only: qrosum
  use variables, only: dt, theta, thetm1, pond, pondm1, qbot, swbotb, epd, reva, runon, runots
  implicit none
  private
  public :: projected_water_residual, apply_surface_lateral_limit, linear_pond_top_jacobian
contains
  pure real(8) function linear_pond_top_jacobian(conductance,step,pond,threshold,resistance) result(tangent)
    ! Eliminate the original linear PondRunoff storage equation analytically.
    ! Its derivative includes the response of pond to the first-node head.
    ! Conductivity is held fixed by the caller's original SWKIMPL0 contract.
    real(8), intent(in) :: conductance,step,pond,threshold,resistance
    real(8) :: runoff_tangent
    runoff_tangent=0d0
    if(pond>threshold) runoff_tangent=step/resistance
    tangent=conductance*(1d0+runoff_tangent)/(1d0+step*conductance+runoff_tangent)
  end function

  real(8) function projected_water_residual() result(residual)
    real(8) :: delta_matrix, delta_macro, new_stock, rapid, external
    integer :: domain, bottom

    ! Original nonmacro explicit bottom fluxes share the same candidate balance.
    ! Modes1/5 reconstruct qbot after HeadCalc and cannot use this receipt.
    ! Mode-2 is the original prescribed-flux fallback to free drainage.
    if (swmacro==0 .and. &
        (abs(swbotb)==2 .or. swbotb==4 .or. swbotb==6 .or. swbotb==7 .or. swbotb==9 .or. (swbotb==3 .and. swsnow==1))) then
      delta_matrix=sum((theta(1:numnod)-thetm1(1:numnod))*dz(1:numnod))
      external=dt*(nraidt+nird+runon+qssdisum+qbot-qrosum-epd-reva-qdrtot)-runots
      ! Snow updates its native ssnow/slw state once at day start, outside the
      ! water trial. The soil+pond receipt receives its melt flux explicitly;
      ! the independent complete-day receipt still includes the snow store.
      if (swsnow==1) external=external+dt*melt
      residual=delta_matrix+pond-pondm1-external
      return
    end if
    ! This receipt uses the instantaneous-bypass and original Cauchy routes.
    ! Snow, other macro models and reconstructed bottom fluxes need their own receipt.
    if (swmbf /= 1 .or. swsnow /= 0 .or. swbotb /= 3) error stop 'Unsupported day-budget donor configuration'
    delta_matrix = sum((theta(1:numnod)-thetm1(1:numnod))*FrArMtrx(1:numnod)*dz(1:numnod))
    rapid = sum(QOutDrRapCp(ICTopMP:ICpBtDm(1)))
    delta_macro = 0d0
    do domain = 1, NumDm
      bottom = ICpBtDm(domain)
      new_stock = WaSrMpDm(domain) + dt*(QInTopLatDm(domain) + QInTopVrtDm(domain) &
                  - sum(QExcMtxDmCp(domain,ICTopMP:bottom)))
      if (domain == 1) new_stock = new_stock - rapid*dt
      delta_macro = delta_macro + (max(0d0,new_stock) - WaSrMpDm(domain))
    end do
    external = dt*(nraidt+nird+runon+qssdisum+qbot-qrosum-epd-reva-qdrtot-rapid)-runots
    residual = delta_matrix + delta_macro + pond - pondm1 - external
  end function

  subroutine apply_surface_lateral_limit(volume)
    real(8), intent(in) :: volume
    real(8) :: booked

    booked = dt*sum(QInTopLatDm(1:NumDm))
    if (volume >= 0d0 .and. booked > volume) then
      QInTopLatDm(1:NumDm) = QInTopLatDm(1:NumDm)*(volume/booked)
    end if
  end subroutine
end module hybrid_step_budget
