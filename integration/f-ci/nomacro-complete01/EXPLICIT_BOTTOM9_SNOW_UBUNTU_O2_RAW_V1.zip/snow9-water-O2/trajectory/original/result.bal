* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-23 12:52:48

Period             :  1900-01-01  until  2002-02-04 
Depth soil profile :  200.00 cm

            Water storage
Final   :        23.67 cm
Initial :        22.27 cm
            =============
Change            1.40 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :     1.40    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.00
                             Crack flux        :     0.00
=========================    ============================
Sum            :     1.40    Sum               :     0.00
