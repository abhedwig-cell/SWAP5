import pathlib,json,sys,argparse,time
R=pathlib.Path.cwd();sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from explicit_bottom9_runtime import m,own
from analytical_hydraulic_archives import SHA
from prescribed_snow_boundary import enabled
p=argparse.ArgumentParser();p.add_argument('--profile',type=pathlib.Path,required=True);a=p.parse_args();out=a.profile;obs=json.loads((out/'BUILD_OBSERVE.json').read_text());assert obs['returncode']==0
build=pathlib.Path(obs['build_root']);inputs=pathlib.Path(obs['input_root']);reference=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');project=m.e.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1');assert enabled(project) and not project.age
q=dict(status='RUNNING_ACTUAL_SNOW9_FIRST35DAY_PILOT',source=obs['source'],case='explicit9-snow-'+obs['kind'],optimization=obs['optimization'],days=35,kind=obs['kind'],build_root=str(build),input_root=str(inputs),actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()),input_inventory=m.e.inventory(inputs),compiler_executions=0,canonical_admission=False)
def save():(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
save();started=time.monotonic()
try:
 m.validate_bundle(build,reference,project)
 windows=[(2,4),(7,9),(30,34)]
 q['trajectory'],data=m.trajectory(build,reference,project,out/'trajectory',35,{35,*(d for pair in windows for d in pair)},600);q['cold']=[];save()
 for low,high in windows:q['cold'].append(own(build,reference,project,out/'trajectory',data,low,high,out/('own-'+str(low))));save()
 q.update(status='ACTUAL_EXPLICIT9_SNOW_PHYSICAL_NATIVE_OUTPUT_PERIOD_PASS_NOT_ADMITTED',snow_maximum_stock_cm=max(r['stock_end_cm'][2] for r in data),snow_minimum_stock_cm=min(r['stock_end_cm'][2] for r in data),seconds=time.monotonic()-started)
except Exception as error:q.update(status='FAILED',error=repr(error),seconds=time.monotonic()-started);raise
finally:save()
print(q['status'],q['seconds'],q['snow_maximum_stock_cm'],flush=True)
