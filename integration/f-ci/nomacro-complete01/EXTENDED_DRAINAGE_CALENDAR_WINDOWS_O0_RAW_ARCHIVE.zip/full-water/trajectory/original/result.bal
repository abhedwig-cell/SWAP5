* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 20:12:29

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        82.17 cm
Initial :        75.19 cm
            =============
Change            6.98 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     3.97
Runon          :     0.00    Runoff            :    16.90
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     7.88
Bottom flux    :     0.00    Soil evaporation  :    13.87
                             Crack flux        :     0.00
                             Drainage level 1  :    13.08
                             Drainage level 2  :    12.73
                             Drainage level 3  :    11.17
=========================    ============================
Sum            :    86.58    Sum               :    79.60

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        79.75 cm
Initial :        82.17 cm
            =============
Change           -2.42 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     1.75
Runon          :     0.00    Runoff            :    30.41
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     5.21
Bottom flux    :     0.00    Soil evaporation  :    42.60
                             Crack flux        :     0.00
                             Drainage level 1  :    -0.84
                             Drainage level 2  :    -0.84
                             Drainage level 3  :    -0.84
=========================    ============================
Sum            :    71.98    Sum               :    77.44

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        81.90 cm
Initial :        79.75 cm
            =============
Change            2.16 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     1.06
Runon          :     0.00    Runoff            :    35.84
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.18
Bottom flux    :     0.00    Soil evaporation  :    46.21
                             Crack flux        :     0.00
                             Drainage level 1  :    -0.70
                             Drainage level 2  :    -0.70
                             Drainage level 3  :    -0.70
=========================    ============================
Sum            :    80.55    Sum               :    81.18
