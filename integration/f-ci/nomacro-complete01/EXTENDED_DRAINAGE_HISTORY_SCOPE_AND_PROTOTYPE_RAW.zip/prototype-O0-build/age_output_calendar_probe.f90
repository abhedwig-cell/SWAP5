subroutine hybrid_original_output_initial_emit()
use variables,only:volact,pond
use plant_interface,only:sicact
implicit none
write(*,'(a,12(1x,es25.17e3))')'HYBRID_STOCK_FLUX', &
 volact,pond,0d0,sicact,0d0,0d0,volact,pond,0d0,sicact,0d0,0d0
end subroutine
subroutine hybrid_age_output_day_emit()
use hybrid_age_output_state
use variables,only:volact,pond,daycum,t1900
use plant_interface,only:sicact
implicit none
real(8)::stocks(12),flow(16)
integer::status
call finish_output_receipt(hybrid_output_frame,[volact,pond,0d0,sicact,0d0,0d0],stocks,flow,status)
if(status/=OUTPUT_RECEIPT_OK)error stop 'Original output daily frame finish rejected'
write(*,'(a,12(1x,es25.17e3))')'HYBRID_STOCK_FLUX',stocks
write(*,'(a,16(1x,es25.17e3))')'HYBRID_EXTERNAL_FLUX',flow
write(*,'(a,1x,i0,1x,es25.17e3)')'ORIGINAL_DAILY_RECEIPT',daycum,t1900
end subroutine
