module hybrid_age_output_state
use iso_fortran_env,only:real64
use mod_original_output_receipt
implicit none
type(output_receipt_frame_t),save::hybrid_output_frame
integer,save::pending_header(20)=0
real(8),allocatable,save::pending_values(:)
logical,save::output_restore_pending=.false.
logical,save::output_crop_restore_pending=.false.
real(8),parameter::original_output_start_clock=37256d0
contains
subroutine output_assert_age_clock(day,period)
 integer,intent(in)::day
 real(8),intent(in)::period
 if(.not.output_restore_pending.or..not.allocated(pending_values))error stop 'Missing original output calendar owner'
 if(day/=pending_header(7))error stop 'Inconsistent original age output day'
 if(abs(period-pending_values(size(pending_values)))>0d0)error stop 'Inconsistent original age output period'
end subroutine
end module
