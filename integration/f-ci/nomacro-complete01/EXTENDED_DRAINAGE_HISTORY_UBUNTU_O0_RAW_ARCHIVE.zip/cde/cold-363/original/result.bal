* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 21:33:15

Period             :  2002-12-30  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.63 cm       0.2168E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            3.44 cm       0.2168E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.14
Runon          :     0.00    Runoff            :     1.46
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    27.98
Bottom flux    :     0.00    Soil evaporation  :    12.31
                             Crack flux        :     0.00
                             Drainage level 1  :    26.43
                             Drainage level 2  :    10.82
=========================    ============================
Sum            :    86.58    Sum               :    83.14


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2632E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2632E+02

