* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 21:31:02

Period             :  2002-12-30  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        81.14 cm
Initial :        72.37 cm
            =============
Change            8.78 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.01
Runon          :     0.00    Runoff            :    13.25
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     9.75
Bottom flux    :     0.00    Soil evaporation  :    13.47
                             Crack flux        :     0.00
                             Drainage level 1  :    13.21
                             Drainage level 2  :    12.73
                             Drainage level 3  :    11.39
=========================    ============================
Sum            :    86.58    Sum               :    77.80
