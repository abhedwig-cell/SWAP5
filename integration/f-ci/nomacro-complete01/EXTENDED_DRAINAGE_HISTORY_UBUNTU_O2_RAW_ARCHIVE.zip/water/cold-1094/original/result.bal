* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 21:22:29

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        81.35 cm
Initial :        78.98 cm
            =============
Change            2.38 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     3.09
Runon          :     0.00    Runoff            :    34.90
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     3.69
Bottom flux    :     0.00    Soil evaporation  :    40.74
                             Crack flux        :     0.00
                             Drainage level 1  :    -0.77
                             Drainage level 2  :    -0.77
                             Drainage level 3  :    -0.77
=========================    ============================
Sum            :    80.55    Sum               :    80.09
