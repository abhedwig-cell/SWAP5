* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 22:14:26

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.63 cm       0.2168E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            3.44 cm       0.2168E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.14
Runon          :     0.00    Runoff            :     1.46
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    27.98
Bottom flux    :     0.00    Soil evaporation  :    12.31
                             Crack flux        :     0.00
                             Drainage level 1  :    26.43
                             Drainage level 2  :    10.82
=========================    ============================
Sum            :    86.58    Sum               :    83.14


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2632E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2632E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.71 cm       0.1351E+02 mg/cm2
Initial :        78.63 cm       0.2168E+02 mg/cm2
            =============       =================
Change           -0.92 cm      -0.8173E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.45
Runon          :     0.00    Runoff            :     1.45
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    24.55
Bottom flux    :     0.00    Soil evaporation  :    14.42
                             Crack flux        :     0.00
                             Drainage level 1  :    26.28
                             Drainage level 2  :    -0.26
=========================    ============================
Sum            :    71.98    Sum               :    72.90


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.8173E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.8173E+01


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.18 cm       0.9133E+01 mg/cm2
Initial :        77.71 cm       0.1351E+02 mg/cm2
            =============       =================
Change           -0.53 cm      -0.4373E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :     0.00    Soil evaporation  :    14.50
                             Crack flux        :     0.00
                             Drainage level 1  :    24.58
                             Drainage level 2  :    -1.66
=========================    ============================
Sum            :    80.55    Sum               :    81.08


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4373E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.4373E+01

