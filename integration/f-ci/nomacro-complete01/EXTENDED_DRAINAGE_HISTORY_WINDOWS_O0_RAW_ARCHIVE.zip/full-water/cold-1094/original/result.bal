* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 22:14:22

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        81.38 cm
Initial :        78.98 cm
            =============
Change            2.41 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     3.04
Runon          :     0.00    Runoff            :    34.96
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     3.59
Bottom flux    :     0.00    Soil evaporation  :    40.79
                             Crack flux        :     0.00
                             Drainage level 1  :    -0.78
                             Drainage level 2  :    -0.78
                             Drainage level 3  :    -0.78
=========================    ============================
Sum            :    80.55    Sum               :    80.06
