* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 22:11:33

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        81.14 cm
Initial :        72.37 cm
            =============
Change            8.78 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.01
Runon          :     0.00    Runoff            :    13.25
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     9.75
Bottom flux    :     0.00    Soil evaporation  :    13.47
                             Crack flux        :     0.00
                             Drainage level 1  :    13.21
                             Drainage level 2  :    12.73
                             Drainage level 3  :    11.39
=========================    ============================
Sum            :    86.58    Sum               :    77.80

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        78.98 cm
Initial :        81.14 cm
            =============
Change           -2.17 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     2.72
Runon          :     0.00    Runoff            :    28.87
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     8.92
Bottom flux    :     0.00    Soil evaporation  :    39.41
                             Crack flux        :     0.00
                             Drainage level 1  :    -1.08
                             Drainage level 2  :    -1.08
                             Drainage level 3  :    -1.08
=========================    ============================
Sum            :    71.98    Sum               :    76.69

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        81.38 cm
Initial :        78.98 cm
            =============
Change            2.41 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     3.04
Runon          :     0.00    Runoff            :    34.96
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     3.59
Bottom flux    :     0.00    Soil evaporation  :    40.79
                             Crack flux        :     0.00
                             Drainage level 1  :    -0.78
                             Drainage level 2  :    -0.78
                             Drainage level 3  :    -0.78
=========================    ============================
Sum            :    80.55    Sum               :    80.06
