* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 00:01:34

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        81.91 cm
Initial :        79.68 cm
            =============
Change            2.23 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     1.06
Runon          :     0.00    Runoff            :    35.82
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.19
Bottom flux    :     0.00    Soil evaporation  :    46.11
                             Crack flux        :     0.00
                             Drainage level 1  :    -0.70
                             Drainage level 2  :    -0.70
                             Drainage level 3  :    -0.70
=========================    ============================
Sum            :    80.55    Sum               :    81.07
