module hybrid_extended_drain_terminal
  use iso_fortran_env,only:real128
  implicit none
  real(8),save::soil_origin_clock=-huge(0d0)
  real(8),allocatable,save::soil_origin_theta(:)
  private
  public::terminal_water_terms,terminal_water_residual
contains
  subroutine terminal_water_terms(terms)
    use MOD_integral,only:hybrid_extended_output_trial_terms
    real(8),intent(out)::terms(28)
    call hybrid_extended_output_trial_terms(terms)
  end subroutine
  real(8) function terminal_water_residual() result(residual)
    use variables,only:tcum,dt,t1900,theta,thetm1
    use MOD_grid,only:numnod,dz
    real(8) :: terms(28)
    real(8)::day_clock
    real(real128)::soil_change
    call terminal_water_terms(terms)
    day_clock=anint(t1900-tcum)
    if(day_clock/=soil_origin_clock)then
      if(allocated(soil_origin_theta))deallocate(soil_origin_theta)
      allocate(soil_origin_theta(numnod))
      soil_origin_theta=thetm1(1:numnod)
      soil_origin_clock=day_clock
    end if
    soil_change=sum((real(theta(1:numnod),real128)-real(soil_origin_theta,real128))*real(dz(1:numnod),real128))
    residual=real(sum(real(terms(1:16),real128))+sum(real(terms(18:22),real128)) &
                 +sum(real(terms(24:28),real128))-soil_change,8)
    if(tcum+dt>=1d0-1d-8)write(*,'(a,29(1x,es25.17e3))') 'EXTENDED_DRAIN_TERMINAL_WATER',real(sum(real(terms,real128)),8),terms
  end function
end module hybrid_extended_drain_terminal
