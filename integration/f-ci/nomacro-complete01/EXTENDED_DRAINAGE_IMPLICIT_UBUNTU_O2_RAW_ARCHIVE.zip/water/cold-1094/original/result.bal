* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 23:59:56

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        77.39 cm
Initial :        77.73 cm
            =============
Change           -0.34 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.14
Bottom flux    :     0.00    Soil evaporation  :    14.50
                             Crack flux        :     0.00
                             Drainage level 1  :    24.56
                             Drainage level 2  :    -1.84
=========================    ============================
Sum            :    80.55    Sum               :    80.89
