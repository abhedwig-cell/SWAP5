* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 23:59:55

Period             :  2002-12-30  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        78.63 cm
Initial :        75.19 cm
            =============
Change            3.45 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.14
Runon          :     0.00    Runoff            :     1.78
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    28.28
Bottom flux    :     0.00    Soil evaporation  :    12.40
                             Crack flux        :     0.00
                             Drainage level 1  :    26.21
                             Drainage level 2  :    10.33
=========================    ============================
Sum            :    86.58    Sum               :    83.13
