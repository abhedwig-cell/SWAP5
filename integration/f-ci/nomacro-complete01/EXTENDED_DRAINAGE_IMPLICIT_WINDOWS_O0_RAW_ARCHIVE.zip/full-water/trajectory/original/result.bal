* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 00:49:24

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        78.63 cm
Initial :        75.19 cm
            =============
Change            3.45 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.14
Runon          :     0.00    Runoff            :     1.78
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    28.28
Bottom flux    :     0.00    Soil evaporation  :    12.40
                             Crack flux        :     0.00
                             Drainage level 1  :    26.21
                             Drainage level 2  :    10.33
=========================    ============================
Sum            :    86.58    Sum               :    83.13

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        77.73 cm
Initial :        78.63 cm
            =============
Change           -0.90 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.45
Runon          :     0.00    Runoff            :     1.95
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    24.58
Bottom flux    :     0.00    Soil evaporation  :    14.57
                             Crack flux        :     0.00
                             Drainage level 1  :    26.24
                             Drainage level 2  :    -0.92
=========================    ============================
Sum            :    71.98    Sum               :    72.88

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        77.39 cm
Initial :        77.73 cm
            =============
Change           -0.34 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.14
Bottom flux    :     0.00    Soil evaporation  :    14.50
                             Crack flux        :     0.00
                             Drainage level 1  :    24.56
                             Drainage level 2  :    -1.84
=========================    ============================
Sum            :    80.55    Sum               :    80.89
