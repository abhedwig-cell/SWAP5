import json,os,subprocess,sys,time
from pathlib import Path
r=Path(sys.argv[1]);label=sys.argv[2];expected=sys.argv[3] if len(sys.argv)>3 else None;w=Path(__file__).parent;ev=w/'evidence';out=ev/(label+'.stdout.txt');err=ev/(label+'.stderr.txt');receipt=ev/(label+'.json')
assert not any(p.exists() for p in (out,err,receipt))
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def snap():return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--short','--ignored'),sparse=git('sparse-checkout','list').splitlines())
before=snap();assert not before['status'] and len(before['sparse'])==22
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',TEMP=str(w/'active-python-scratch'),TMP=str(w/'active-python-scratch'));env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH'];cmd=[sys.executable,'-B','tests/hupsel51/verify_successor.py'];t=time.monotonic()
with out.open('w',encoding='utf-8') as o,err.open('w',encoding='utf-8') as e:run=subprocess.run(cmd,cwd=r,env=env,stdout=o,stderr=e,timeout=1200)
after=snap();q=dict(command=cmd,cwd=str(r),before=before,after=after,elapsed_seconds=time.monotonic()-t,returncode=run.returncode,stdout_bytes=out.stat().st_size,stderr_bytes=err.stat().st_size,model_executions=0,expected_error=expected);receipt.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q));assert before==after
if expected:
 assert run.returncode!=0 and expected in err.read_text(encoding='utf-8')
else:
 assert run.returncode==0
 result=json.loads(out.read_text(encoding='utf-8'));assert result['status']=='BOUNDED_SECONDARY_EXTENDED_IMPLICIT_SOURCE_RAW_ADMISSION_PASS'
