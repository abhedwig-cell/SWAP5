from pathlib import Path
import subprocess,json,hashlib,shutil
w=Path(__file__).resolve().parents[1];d=Path(__file__).parent;ev=w/'evidence';provider=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');objects=provider/'build/swap-obj';ttutil=provider/'build/ttutil-obj';driver=d/'test_original_pond_switch.f90'
for opt in ('O0','O2'):
 old=w/('extended-implicit-'+opt+'-v1/full-v2/water/water');meta=json.loads((old/'BUILD.json').read_text())
 for variant in ('original','zero'):
  build=d/('component-'+opt+'-'+variant);build.mkdir();out=ev/('implicit-secondary-pond-switch-component-'+opt+'-'+variant+'-v1');out.mkdir()
  for p in old.iterdir():
   if p.suffix.lower() in ('.o','.mod','.smod','.f90','.dll'):shutil.copyfile(p,build/p.name)
  top=build/'boundtop.f90';text=top.read_text(encoding='cp1252');assert text.count('if (h0 <= 1.0d-6) then')==1
  if variant=='zero':top.write_text(text.replace('if (h0 <= 1.0d-6) then','if (h0 <= 0.0d0) then',1),encoding='cp1252')
  known={p.name for p in objects.glob('*.o')};actual=[build/p.name if (build/p.name).exists() else p for p in sorted(objects.glob('*.o')) if p.name!='swap_main.o'];actual += [p for p in sorted(build.glob('*.o')) if p.name not in known]
  flags=['gfortran',*meta['identity']['donor_flags'],'-I',str(build),'-I',str(objects),'-I',str(ttutil)];exe=build/'component.exe';commands=[flags+['-c','boundtop.f90'],flags+[str(driver),*map(str,actual),str(ttutil/'libttutil.a'),'-o',str(exe)]];logs=[]
  for cmd in commands:
   r=subprocess.run(cmd,cwd=build,capture_output=True,text=True,timeout=60);logs.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(out/'COMPILATION.json').write_text(json.dumps(logs,indent=2));r.check_returncode()
  r=subprocess.run([str(exe)],cwd=build,capture_output=True,text=True,timeout=30);(out/'actual.stdout').write_text(r.stdout);(out/'actual.stderr').write_text(r.stderr);r.check_returncode()
  for p in (top,driver,exe):shutil.copyfile(p,out/p.name)
  sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();q=dict(status='ACTUAL_COMPLETE_ORIGINAL_MOD_TOP_POND_SWITCH_COMPONENT',qualification=False,optimization=opt,variant=variant,source_sha256=sha(top),driver_sha256=sha(driver),executable_sha256=sha(exe),actual_cases=len(r.stdout.splitlines()),original_BUILD_sha256=sha(old/'BUILD.json'));(out/'RESULT.json').write_text(json.dumps(q,indent=2));print(opt,variant,q['actual_cases'])
