from pathlib import Path
import sys,json,time
w=Path(__file__).resolve().parents[1];source=Path(__file__).parent/'source';sys.path.insert(0,str(source/'tests/nomacro_drainage'))
import calendar_runtime as runtime
import implicit_forensics as science
m=runtime.m;opt=sys.argv[1];suffix='v2' if opt=='O0' else 'v1';profile=w/('evidence/implicit-extended-full-water-'+opt+'-v2');q=json.loads((profile/'RESULT.json').read_text());old=Path(q['build_root']);meta=json.loads((old/'BUILD.json').read_text());reference=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');project=m.e.load(profile/'input',original_output=True);_,case=m.validate_bundle(old,reference,project)
origin_profile=w/('evidence/implicit-secondary-zero-pond-seasonal-'+opt+'-v2');exe=Path(__file__).parent/('zero-pond-build-v2' if opt=='O0' else 'zero-pond-build-O2')/'diagnostic_donor.exe';assert m.sha(exe)==json.loads((origin_profile/'RESULT.json').read_text())['actual_debug_executable_sha256'];out=w/('evidence/implicit-secondary-zero-pond-tail-'+opt+'-v1');out.mkdir();(out/'trajectory').mkdir();receipt=m.h.verify_checkpoint(origin_profile/'trajectory/accepted-column-1-day-367.zip',367,meta['binding'],out/'origin');t=time.monotonic()
try:
 result=m.h.run(exe,m.h.executable(old,'day_kernel'),case,out/'trajectory',1096,checkpoint_day=367,origin=out/'origin',origin_receipt=receipt,runtime=True,publish_day=1096,checkpoint_binding=meta['binding'],model=project.model,project=project);status='RESEARCH_ZERO_POND_SWITCH_TAIL_CONTINUATION_PASS';error=None
except RuntimeError as e: status='RESEARCH_ZERO_POND_SWITCH_TAIL_CONTINUATION_FAILED';error=str(e);result=None
rows=m.rows(out/'trajectory');m.check(rows);data=dict(status=status,qualification=False,actual_start=367,actual_end=367+len(rows),actual_debug_executable_sha256=m.sha(exe),original_BUILD_sha256=m.sha(old/'BUILD.json'),actual_days=len(rows),independent_conservation=science.inventory(rows),seconds=time.monotonic()-t,error=error,result=result);(out/'RESULT.json').write_text(json.dumps(data,indent=2));print(data['status'],data['actual_days'])
