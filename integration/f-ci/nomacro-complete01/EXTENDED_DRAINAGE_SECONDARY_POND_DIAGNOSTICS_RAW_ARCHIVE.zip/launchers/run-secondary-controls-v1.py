from pathlib import Path
import subprocess,sys
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');w=Path(__file__).parent;opt=sys.argv[1]
for case in ('water','fixed'):
 profile=w/('evidence/secondary-pond-full-'+case+'-'+opt+'-v1')
 for kind,script in [('controls','extended_controls.py'),('source-controls','secondary_pond_controls.py')]:
  out=profile/kind;cmd=[sys.executable,'-B','tests/nomacro_drainage/'+script,'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--profile-root' if kind=='controls' else '--profile',str(profile),'--output',str(out)]
  if kind=='controls':cmd.append('--original-output')
  with (profile/(kind+'.stdout')).open('x') as o,(profile/(kind+'.stderr')).open('x') as e:v=subprocess.run(cmd,cwd=r,stdout=o,stderr=e,timeout=300)
  print(opt,case,kind,v.returncode,flush=True);v.check_returncode()
