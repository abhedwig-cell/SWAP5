from pathlib import Path
import subprocess,sys
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');w=Path(__file__).parent
for opt in ('O0','O2'):
 for s,h in ((0,0),(1,2)):
  profile=w/('evidence/implicit-ordinary-zero-s'+str(s)+'-h'+str(h)+'-'+opt+'-v1');out=w/('evidence/secondary-ordinary-current-s'+str(s)+'-h'+str(h)+'-'+opt+'-v1');cmd=[sys.executable,'-B','tests/nomacro_drainage/implicit_ordinary_current.py','--profile',str(profile),'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--output',str(out)]
  with (w/'evidence'/(out.name+'.stdout')).open('x') as o,(w/'evidence'/(out.name+'.stderr')).open('x') as e:v=subprocess.run(cmd,cwd=r,stdout=o,stderr=e,timeout=120)
  print(opt,s,h,v.returncode,flush=True);v.check_returncode()
