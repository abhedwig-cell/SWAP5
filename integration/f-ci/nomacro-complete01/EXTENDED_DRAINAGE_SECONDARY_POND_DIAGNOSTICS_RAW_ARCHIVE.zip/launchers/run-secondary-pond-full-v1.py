from pathlib import Path
import subprocess,sys,os,json
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');w=Path(__file__).parent;opt=sys.argv[1]
for case,hys in [('water',0),('fixed',2)]:
 name='secondary-pond-full-'+case+'-'+opt+'-v1';out=w/'evidence'/name;cmd=[sys.executable,'-B',str(r/'tests/nomacro_drainage/calendar_runtime.py'),'--case',case,'--mode','monthly' if case=='water' else 'daily','--format','2' if case=='water' else '3','--hysteresis',str(hys),'--implicit','--switch-window','--days','1096','--optimization',opt,'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--build-root',str(w/('secondary-pond-'+opt+'-v1')/case),'--output',str(out)]
 with (w/'evidence'/(name+'.stdout')).open('x') as o,(w/'evidence'/(name+'.stderr')).open('x') as e: v=subprocess.run(cmd,cwd=r,stdout=o,stderr=e,timeout=1200)
 print(case,opt,'returncode',v.returncode,flush=True)
