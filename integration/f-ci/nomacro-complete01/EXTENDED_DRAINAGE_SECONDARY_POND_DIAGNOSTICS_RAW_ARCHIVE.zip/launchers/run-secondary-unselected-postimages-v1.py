from pathlib import Path
import subprocess,sys,json
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');w=Path(__file__).parent;opt=sys.argv[1];ev=w/'evidence';ref='C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'
for kind,h in [('water',0),('cde',2)]:
 out=ev/('secondary-primary-postimage-'+kind+'-'+opt+'-v1');prior=ev/('implicit-primary-water-full-'+opt+'-v1' if kind=='water' else 'implicit-extended-full-cde-'+opt+'-v2');build=w/('secondary-pond-'+opt+'-v1')/'primary-postimage'/kind;args=[sys.executable,'-B','tests/nomacro_drainage/calendar_runtime.py','--case','automatic','--mode','monthly' if kind=='water' else 'daily','--format','2' if kind=='water' else '3','--hysteresis',str(h),'--implicit','--days','35','--optimization',opt,'--reference-work',ref,'--build-root',str(build),'--output',str(out)]
 if kind=='water':args.append('--water-only')
 commands=[args,[sys.executable,'-B','tests/nomacro_drainage/implicit_primary_postimage.py','--current',str(out),'--prior',str(prior),'--output',str(out/'POSTIMAGE_V1.json')]]
 for i,cmd in enumerate(commands):
  with (ev/(out.name+'-'+str(i)+'.stdout')).open('x') as o,(ev/(out.name+'-'+str(i)+'.stderr')).open('x') as e:v=subprocess.run(cmd,cwd=r,stdout=o,stderr=e,timeout=240)
  print(opt,kind,i,v.returncode,flush=True);v.check_returncode()
 kind,h=('water',0) if opt=='O0' else ('automatic',2);prior=ev/('implicit-final-off-'+kind+'-h'+str(h)+'-'+opt+'-v1');out=ev/('secondary-explicit-off-'+kind+'-'+opt+'-v1');cmd=[sys.executable,'-B','tests/nomacro_drainage/implicit_preservation.py','--prior-profile',str(prior),'--reference-work',ref,'--build-root',str(w/('secondary-pond-'+opt+'-v1')/'off-postimage'),'--output',str(out),'--optimization',opt]
 with (ev/(out.name+'.stdout')).open('x') as o,(ev/(out.name+'.stderr')).open('x') as e:v=subprocess.run(cmd,cwd=r,stdout=o,stderr=e,timeout=240)
 print(opt,'explicitoff',v.returncode,flush=True);v.check_returncode()
