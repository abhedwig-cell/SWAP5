from pathlib import Path
import sys,os,json,time
w=Path(__file__).resolve().parents[1]; source=Path(__file__).parent/'source';sys.path.insert(0,str(source/'tests/nomacro_drainage'))
import calendar_runtime as runtime
m=runtime.m
assert m.h.APP.resolve()==(source/'app/hybrid_water').resolve(),m.h.APP
profile=w/'evidence/implicit-extended-full-water-O0-v2';q=json.loads((profile/'RESULT.json').read_text());old=Path(q['build_root']);ref=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');meta=json.loads((old/'BUILD.json').read_text());project=m.e.load(profile/'input',original_output=True);_,case=m.validate_bundle(old,ref,project)
out=w/'evidence/implicit-secondary-replay280-O0-v1';out.mkdir();(out/'trajectory').mkdir();receipt=m.h.verify_checkpoint(profile/'trajectory/accepted-column-1-day-35.zip',35,meta['binding'],out/'origin');t=time.monotonic()
result=m.h.run(m.h.executable(old,'day_donor'),m.h.executable(old,'day_kernel'),case,out/'trajectory',280,checkpoint_day=35,origin=out/'origin',origin_receipt=receipt,runtime=True,publish_day=280,checkpoint_binding=meta['binding'],model=project.model,project=project)
rows=m.rows(out/'trajectory');prior=m.rows(profile/'trajectory');assert m.physical(rows)==m.physical(prior[35:280]);m.check(rows);data=dict(status='ACTUAL_ORIGINAL_SECONDARY_NATIVE_REPLAY_EXACT',qualification=False,original_BUILD_sha256=m.sha(old/'BUILD.json'),source=q['source'],start=35,end=280,days=len(rows),seconds=time.monotonic()-t,result=result);(out/'RESULT.json').write_text(json.dumps(data,indent=2));print(data['status'])
