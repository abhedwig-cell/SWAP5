* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 01:53:04

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        80.76 cm       0.1630E+02 mg/cm2
Initial :        79.65 cm       0.2053E+02 mg/cm2
            =============       =================
Change            1.11 cm      -0.4232E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     5.31
Runon          :     0.00    Runoff            :    32.32
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     8.90
Bottom flux    :     0.00    Soil evaporation  :    37.38
                             Crack flux        :     0.00
                             Drainage level 1  :    -1.54
                             Drainage level 2  :    -1.54
=========================    ============================
Sum            :    80.55    Sum               :    80.82


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4232E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.4232E+01

