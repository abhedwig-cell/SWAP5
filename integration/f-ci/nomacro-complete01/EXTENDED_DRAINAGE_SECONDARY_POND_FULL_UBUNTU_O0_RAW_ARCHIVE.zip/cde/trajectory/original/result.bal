* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 01:51:51

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        89.93 cm       0.2629E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change           14.75 cm       0.2629E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     3.68
Runon          :     0.00    Runoff            :    30.49
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.37
Bottom flux    :     0.00    Soil evaporation  :    18.33
                             Crack flux        :     0.00
                             Drainage level 1  :     9.48
                             Drainage level 2  :     9.48
=========================    ============================
Sum            :    86.58    Sum               :    71.83


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2171E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2171E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        79.65 cm       0.2053E+02 mg/cm2
Initial :        89.93 cm       0.2629E+02 mg/cm2
            =============       =================
Change          -10.28 cm      -0.5761E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     2.64
Runon          :     0.00    Runoff            :    28.85
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     8.84
Bottom flux    :     0.00    Soil evaporation  :    48.39
                             Crack flux        :     0.00
                             Drainage level 1  :    -1.22
                             Drainage level 2  :    -1.22
=========================    ============================
Sum            :    71.98    Sum               :    86.26


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.5761E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.5761E+01


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        80.76 cm       0.1630E+02 mg/cm2
Initial :        79.65 cm       0.2053E+02 mg/cm2
            =============       =================
Change            1.11 cm      -0.4232E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     5.31
Runon          :     0.00    Runoff            :    32.32
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     8.90
Bottom flux    :     0.00    Soil evaporation  :    37.38
                             Crack flux        :     0.00
                             Drainage level 1  :    -1.54
                             Drainage level 2  :    -1.54
=========================    ============================
Sum            :    80.55    Sum               :    80.82


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4232E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.4232E+01

