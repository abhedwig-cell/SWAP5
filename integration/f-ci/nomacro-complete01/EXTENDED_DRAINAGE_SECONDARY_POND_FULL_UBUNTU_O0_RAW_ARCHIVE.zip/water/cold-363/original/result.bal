* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 01:51:03

Period             :  2002-12-30  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        82.15 cm
Initial :        75.19 cm
            =============
Change            6.96 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     3.97
Runon          :     0.00    Runoff            :    16.78
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     7.96
Bottom flux    :     0.00    Soil evaporation  :    13.85
                             Crack flux        :     0.00
                             Drainage level 1  :    13.11
                             Drainage level 2  :    12.76
                             Drainage level 3  :    11.19
=========================    ============================
Sum            :    86.58    Sum               :    79.62
