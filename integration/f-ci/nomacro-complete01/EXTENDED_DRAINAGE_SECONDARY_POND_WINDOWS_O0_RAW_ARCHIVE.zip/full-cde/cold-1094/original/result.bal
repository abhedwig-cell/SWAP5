* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 02:33:32

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        80.75 cm       0.1627E+02 mg/cm2
Initial :        79.65 cm       0.2053E+02 mg/cm2
            =============       =================
Change            1.10 cm      -0.4261E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     5.34
Runon          :     0.00    Runoff            :    32.26
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     8.97
Bottom flux    :     0.00    Soil evaporation  :    37.32
                             Crack flux        :     0.00
                             Drainage level 1  :    -1.53
                             Drainage level 2  :    -1.53
=========================    ============================
Sum            :    80.55    Sum               :    80.83


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4261E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.4261E+01

