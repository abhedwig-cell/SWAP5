* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 02:33:30

Period             :  2002-12-30  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        89.93 cm       0.2629E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change           14.75 cm       0.2629E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     3.68
Runon          :     0.00    Runoff            :    30.49
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.37
Bottom flux    :     0.00    Soil evaporation  :    18.33
                             Crack flux        :     0.00
                             Drainage level 1  :     9.48
                             Drainage level 2  :     9.48
=========================    ============================
Sum            :    86.58    Sum               :    71.83


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2171E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2171E+02

