* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 02:25:29

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        82.15 cm
Initial :        75.19 cm
            =============
Change            6.96 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     3.97
Runon          :     0.00    Runoff            :    16.78
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     7.96
Bottom flux    :     0.00    Soil evaporation  :    13.85
                             Crack flux        :     0.00
                             Drainage level 1  :    13.11
                             Drainage level 2  :    12.76
                             Drainage level 3  :    11.19
=========================    ============================
Sum            :    86.58    Sum               :    79.62

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        79.68 cm
Initial :        82.15 cm
            =============
Change           -2.47 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     1.82
Runon          :     0.00    Runoff            :    30.32
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     5.45
Bottom flux    :     0.00    Soil evaporation  :    42.45
                             Crack flux        :     0.00
                             Drainage level 1  :    -0.85
                             Drainage level 2  :    -0.85
                             Drainage level 3  :    -0.85
=========================    ============================
Sum            :    71.98    Sum               :    77.49

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        81.90 cm
Initial :        79.68 cm
            =============
Change            2.22 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     1.06
Runon          :     0.00    Runoff            :    35.82
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.19
Bottom flux    :     0.00    Soil evaporation  :    46.13
                             Crack flux        :     0.00
                             Drainage level 1  :    -0.73
                             Drainage level 2  :    -0.73
                             Drainage level 3  :    -0.73
=========================    ============================
Sum            :    80.55    Sum               :    81.02
