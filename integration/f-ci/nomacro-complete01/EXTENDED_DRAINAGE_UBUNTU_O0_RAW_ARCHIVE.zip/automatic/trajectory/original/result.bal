* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 17:37:38

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.63 cm       0.2185E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            3.45 cm       0.2185E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.14
Runon          :     0.00    Runoff            :     1.80
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    28.22
Bottom flux    :     0.00    Soil evaporation  :    12.41
                             Crack flux        :     0.00
                             Drainage level 1  :    26.23
                             Drainage level 2  :    10.33
=========================    ============================
Sum            :    86.58    Sum               :    83.13


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2615E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2615E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.73 cm       0.1365E+02 mg/cm2
Initial :        78.63 cm       0.2185E+02 mg/cm2
            =============       =================
Change           -0.91 cm      -0.8203E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.45
Runon          :     0.00    Runoff            :     1.95
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    24.58
Bottom flux    :     0.00    Soil evaporation  :    14.58
                             Crack flux        :     0.00
                             Drainage level 1  :    26.24
                             Drainage level 2  :    -0.92
=========================    ============================
Sum            :    71.98    Sum               :    72.89


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.8203E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.8203E+01


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.39 cm       0.9195E+01 mg/cm2
Initial :        77.73 cm       0.1365E+02 mg/cm2
            =============       =================
Change           -0.33 cm      -0.4457E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.14
Bottom flux    :     0.00    Soil evaporation  :    14.50
                             Crack flux        :     0.00
                             Drainage level 1  :    24.57
                             Drainage level 2  :    -1.85
=========================    ============================
Sum            :    80.55    Sum               :    80.88


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4457E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.4457E+01

