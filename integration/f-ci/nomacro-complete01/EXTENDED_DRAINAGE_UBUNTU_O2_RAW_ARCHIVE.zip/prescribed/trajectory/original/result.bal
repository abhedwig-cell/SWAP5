* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 17:35:46

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.49 cm       0.2413E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            3.30 cm       0.2413E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.18
Runon          :     0.00    Runoff            :     1.25
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    29.71
Bottom flux    :     0.00    Soil evaporation  :    12.13
                             Crack flux        :     0.00
                             Drainage level 1  :    10.75
                             Drainage level 2  :    25.26
=========================    ============================
Sum            :    86.58    Sum               :    83.28


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2387E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2387E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.61 cm       0.1360E+02 mg/cm2
Initial :        78.49 cm       0.2413E+02 mg/cm2
            =============       =================
Change           -0.87 cm      -0.1053E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.47
Runon          :     0.00    Runoff            :     1.63
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    24.67
Bottom flux    :     0.00    Soil evaporation  :    14.54
                             Crack flux        :     0.00
                             Drainage level 1  :    19.63
                             Drainage level 2  :     5.92
=========================    ============================
Sum            :    71.98    Sum               :    72.85


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1053E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1053E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.57 cm       0.9020E+01 mg/cm2
Initial :        77.61 cm       0.1360E+02 mg/cm2
            =============       =================
Change           -0.05 cm      -0.4583E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.51
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :     0.00    Soil evaporation  :    14.49
                             Crack flux        :     0.00
                             Drainage level 1  :    31.54
                             Drainage level 2  :    -9.10
=========================    ============================
Sum            :    80.55    Sum               :    80.60


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4583E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.4583E+01

