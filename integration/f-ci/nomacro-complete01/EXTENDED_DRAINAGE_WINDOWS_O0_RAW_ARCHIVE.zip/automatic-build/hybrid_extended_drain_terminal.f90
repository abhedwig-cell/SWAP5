module hybrid_extended_drain_terminal
  use iso_fortran_env, only: real128
  implicit none
  real(8),save::soil_origin_clock=-huge(0d0)
  real(8),allocatable,save::soil_origin_theta(:)
  private
  public :: terminal_water_terms, terminal_water_residual
contains
  subroutine terminal_water_terms(terms)
    ! Project the native double ledger exported after original Integral(3).
    ! This is a trial-only receipt: no assignment to original physical state.
    use MOD_grid, only: numnod, dz
    use MOD_swap_base, only: swmacro, swsnow, swdra
    use MOD_integral, only: igrai,isnrai,igsnow,igird,irunon,iqssdi,iqbup, &
      iintc,iruno,iqrot,iepd,ievap,isubl,iqdra,iqbdo
    use MOD_meteo, only: graidt,nraidt,aintcdt
    use MOD_irrigation, only: gird,qssdi
    use MOD_drain, only: qdrtot
    use MOD_re_global, only: qrosum
    use plant_interface, only: sw_inter,sicact,siccap,crsflx_in,crsflx_out
    use variables, only: theta,pond,dt,runon,runots,qbot,epd,reva, &
      ivolbeg,ipondbeg,issnowbeg,isicbeg
    use ieee_arithmetic,only:ieee_is_finite
    real(8), intent(out) :: terms(28)
    real(8) :: ssdi,interception,canopy,qbotts
    integer :: node
    if(swmacro/=0.or.swsnow/=0.or.swdra/=2)error stop 'Unsupported weather terminal receipt domain'
    ssdi=iqssdi
    do node=1,numnod
      ssdi=ssdi+qssdi(node)*dt
    end do
    qbotts=qbot*dt
    interception=iintc+aintcdt*dt
    if(sw_inter==3)interception=iintc+crsflx_out*dt
    canopy=min(max(0d0,sicact+(crsflx_in-crsflx_out)*dt),siccap)
    terms(1:7)=[igrai+graidt*dt,isnrai,igsnow, &
      igird+gird*dt,irunon+runon*dt,ssdi,iqbup+max(0d0,qbotts)]
    terms(8:16)=-[interception,iruno+runots,iqrot+qrosum*dt,iepd+epd*dt, &
      ievap+reva*dt,isubl,iqdra+qdrtot*dt,0d0,iqbdo-min(0d0,qbotts)]
    terms(17:22)=[ivolbeg,ipondbeg,issnowbeg,isicbeg,0d0,0d0]
    terms(23:28)=-[sum(theta(1:numnod)*dz(1:numnod)),pond,0d0,canopy,0d0,0d0]
    if(.not.all(ieee_is_finite(terms)))error stop 'Nonfinite weather terminal water receipt'
  end subroutine

  real(8) function terminal_water_residual() result(residual)
    use variables,only:tcum,dt,t1900,theta,thetm1
    use MOD_grid,only:numnod,dz
    real(8) :: terms(28)
    real(8)::day_clock
    real(real128)::soil_change
    call terminal_water_terms(terms)
    ! Original double operations above remain separate. Extended precision only
    ! sums their exported values, independently of the hydraulic step sum.
    day_clock=anint(t1900-tcum)
    if(day_clock/=soil_origin_clock)then
      if(allocated(soil_origin_theta))deallocate(soil_origin_theta)
      allocate(soil_origin_theta(numnod))
      soil_origin_theta=thetm1(1:numnod)
      soil_origin_clock=day_clock
    end if
    soil_change=sum((real(theta(1:numnod),real128)-real(soil_origin_theta,real128))*real(dz(1:numnod),real128))
    residual=real(sum(real(terms(1:16),real128))+sum(real(terms(18:22),real128)) &
                 +sum(real(terms(24:28),real128))-soil_change,8)
    if(tcum+dt>=1d0-1d-8)write(*,'(a,29(1x,es25.17e3))') 'EXTENDED_DRAIN_TERMINAL_WATER',real(sum(real(terms,real128)),8),terms
  end function
end module
