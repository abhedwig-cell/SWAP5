* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 18:03:50

Period             :  2004-12-30  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.39 cm       0.9195E+01 mg/cm2
Initial :        77.65 cm       0.9246E+01 mg/cm2
            =============       =================
Change           -0.26 cm      -0.5094E-01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     0.15    Interception      :     0.05
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.01
Bottom flux    :     0.00    Soil evaporation  :     0.01
                             Crack flux        :     0.00
                             Drainage level 1  :     0.32
                             Drainage level 2  :     0.05
=========================    ============================
Sum            :     0.15    Sum               :     0.44


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.5094E-01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.5094E-01

