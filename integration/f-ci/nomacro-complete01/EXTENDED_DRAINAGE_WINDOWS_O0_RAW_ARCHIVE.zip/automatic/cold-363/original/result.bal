* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 18:03:45

Period             :  2002-12-30  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.63 cm       0.2185E+02 mg/cm2
Initial :        78.78 cm       0.2212E+02 mg/cm2
            =============       =================
Change           -0.15 cm      -0.2674E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     2.73    Interception      :     0.00
Runon          :     0.00    Runoff            :     1.12
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.02
                             Crack flux        :     0.00
                             Drainage level 1  :     1.05
                             Drainage level 2  :     0.69
=========================    ============================
Sum            :     2.73    Sum               :     2.88


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2674E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.2674E+00

