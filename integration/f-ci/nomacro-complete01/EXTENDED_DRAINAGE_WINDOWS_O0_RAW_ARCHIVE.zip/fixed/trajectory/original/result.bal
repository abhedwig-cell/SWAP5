* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 18:02:42

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        89.93 cm       0.2618E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change           14.74 cm       0.2618E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     3.68
Runon          :     0.00    Runoff            :    30.49
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.36
Bottom flux    :     0.00    Soil evaporation  :    18.38
                             Crack flux        :     0.00
                             Drainage level 1  :     9.46
                             Drainage level 2  :     9.46
=========================    ============================
Sum            :    86.58    Sum               :    71.84


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2182E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2182E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        79.98 cm       0.2068E+02 mg/cm2
Initial :        89.93 cm       0.2618E+02 mg/cm2
            =============       =================
Change           -9.95 cm      -0.5492E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     2.31
Runon          :     0.00    Runoff            :    29.29
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     7.26
Bottom flux    :     0.00    Soil evaporation  :    49.40
                             Crack flux        :     0.00
                             Drainage level 1  :    -1.17
                             Drainage level 2  :    -1.17
=========================    ============================
Sum            :    71.98    Sum               :    85.92


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.5492E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.5492E+01


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        81.78 cm       0.1766E+02 mg/cm2
Initial :        79.98 cm       0.2068E+02 mg/cm2
            =============       =================
Change            1.80 cm      -0.3024E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     3.62
Runon          :     0.00    Runoff            :    33.88
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     4.50
Bottom flux    :     0.00    Soil evaporation  :    41.17
                             Crack flux        :     0.00
                             Drainage level 1  :    -1.47
                             Drainage level 2  :    -1.47
=========================    ============================
Sum            :    80.55    Sum               :    80.23


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.3024E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.3024E+01

