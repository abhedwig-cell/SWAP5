module hybrid_weather_root_state
use ieee_arithmetic,only:ieee_is_finite
implicit none
private
public::weather_root_checkpoint,weather_root_apply,weather_root_witness
logical,save::pending=.false.
real(8),save::saved(2)=0d0,saved_clock=0d0
contains
subroutine weather_root_checkpoint(unit,restoring)
use variables,only:t1900
use MOD_re_global,only:alpwetnoddrz,alpdrynodrtz
integer,intent(in)::unit
logical,intent(in)::restoring
integer::header(8),copy(8),trailer,ios
real(8)::clock,values(2),witness(2)
if(restoring)then
 read(unit,iostat=ios)header,copy,clock,values,witness,trailer
 if(ios/=0)error stop 'Incomplete hourly root stress carry'
else
 header=[1,34,0,1,0,0,6,1];copy=header;clock=t1900
 values=[alpwetnoddrz,alpdrynodrtz];witness=values;trailer=108
end if
if(any(header/=[1,34,0,1,0,0,6,1]).or.any(header/=copy).or.trailer/=108) &
 error stop 'Foreign hourly root stress domain'
if(.not.ieee_is_finite(clock).or.clock/=t1900)error stop 'Foreign hourly root stress clock'
if(.not.all(ieee_is_finite(values)).or.any(values<0d0).or.any(values>1d0).or.any(values/=witness)) &
 error stop 'Invalid hourly root stress values'
if(restoring)then
 saved=values;saved_clock=clock;pending=.true.
else
 write(unit)header,copy,clock,values,witness,trailer
end if
end subroutine
subroutine weather_root_apply()
use variables,only:t1900
use MOD_re_global,only:alpwetnoddrz,alpdrynodrtz
if(.not.pending)return
if(t1900/=saved_clock)error stop 'Stale hourly root stress restoration'
alpwetnoddrz=saved(1);alpdrynodrtz=saved(2);pending=.false.
end subroutine
subroutine weather_root_witness()
use variables,only:t1900
use MOD_re_global,only:alpwetnoddrz,alpdrynodrtz
write(*,'(a,3(1x,es25.17e3))') 'HYBRID_WEATHER_ROOT_MEMORY',t1900,alpwetnoddrz,alpdrynodrtz
end subroutine
end module
