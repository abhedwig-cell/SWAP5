* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 18:03:06

Period             :  2002-12-30  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        82.17 cm
Initial :        80.85 cm
            =============
Change            1.32 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     2.73    Interception      :     0.00
Runon          :     0.00    Runoff            :     1.39
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.02
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
                             Drainage level 2  :     0.00
                             Drainage level 3  :     0.00
=========================    ============================
Sum            :     2.73    Sum               :     1.41
