* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 18:10:55

Period             :  2004-12-30  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        81.78 cm       0.1766E+02 mg/cm2
Initial :        81.81 cm       0.1766E+02 mg/cm2
            =============       =================
Change           -0.03 cm       0.0000E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     0.15    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.16
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.02
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
                             Drainage level 2  :     0.00
=========================    ============================
Sum            :     0.15    Sum               :     0.19


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.0000E+00

