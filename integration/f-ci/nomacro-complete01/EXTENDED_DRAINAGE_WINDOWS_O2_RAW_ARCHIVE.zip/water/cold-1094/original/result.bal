* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 18:03:22

Period             :  2004-12-30  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        81.90 cm
Initial :        81.94 cm
            =============
Change           -0.03 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     0.15    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.16
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.02
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
                             Drainage level 2  :     0.00
                             Drainage level 3  :     0.00
=========================    ============================
Sum            :     0.15    Sum               :     0.18
