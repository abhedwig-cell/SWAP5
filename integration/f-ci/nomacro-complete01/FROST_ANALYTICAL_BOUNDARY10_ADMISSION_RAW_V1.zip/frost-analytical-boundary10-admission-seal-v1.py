"""Seal observed actual signed canonical712 admission, without replay or rebinding."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
M='22520105f5a3ccac2bd2ae1b726f27b7b0d67b1e';C='fc2c49ce7ee866ca961e6189007287214d16189b';B='9af88c3de6198ddec40c2674dd1542a89fa9c0d7';S='f5add718dfd76a6d780199dbc88f830a670ad21d';A='8443d1d25e84dedd5a4de34912639b92247bcfeb'
SHA=lambda raw:hashlib.sha256(raw).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
read=lambda name:json.loads((E/name).read_text())
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
tree=git('rev-parse',M+'^{tree}').decode().strip()
for sha in [C,S,M]:assert git('rev-parse',sha+'^{tree}').decode().strip()==tree
for sha in [S,M]:
    assert git('show','-s','--format=%P',sha).decode().split()==[B,C]
    raw=(E/('FROST_ANALYTICAL_BOUNDARY10_PR1809_GENUINE_GIT_OBJECT_'+sha+'.bin')).read_bytes()
    assert raw==git('cat-file','commit',sha) and hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha
api=read('FROST_ANALYTICAL_BOUNDARY10_PR1809_ACTUAL_GIT_API_V1.json');assert api['sha']==M and api['verification']['verified'] and api['verification']['reason']=='valid'
coadmission=json.loads((E/'FROST_ANALYTICAL_BOUNDARY10_CANDIDATE_PUBLIC_V1.stdout.txt').read_text())['coadmission']
assert (coadmission['contexts'],coadmission['short35_contexts'],coadmission['native_calendar_samples'],coadmission['exact_cold_windows'])==(824,730,5414,2344)
observations={};fixtures=None
for role,version,head in [('CANDIDATE','V1',C),('ACTUAL_MERGE','V1',M)]:
    for scope in ['PUBLIC','PUBLICATION']:
        stem='FROST_ANALYTICAL_BOUNDARY10_'+role+'_'+scope+'_'+version;q=read(stem+'.json');out=(E/(stem+'.stdout.txt')).read_bytes()
        assert q['returncode']==0 and q['error'] is None and q['before']==q['after'] and not q['before']['status'] and not (E/(stem+'.stderr.txt')).read_bytes()
        before=q['before'];assert before['head']==head and before['tree']==tree and len(before['sparse'])==14 and len(before['original_project_files'])==56
        if fixtures is None:fixtures=before['original_project_files']
        assert fixtures==before['original_project_files']
        if scope=='PUBLIC':
            actual=json.loads(out);assert actual['coadmission']==coadmission and actual['compiler_executions']==actual['model_executions']==0
            assert len(actual['new_original_portable_science'])==4 and len(actual['additional_actual_local_science']['contexts'])==6
            contexts=[c for p in actual['new_original_portable_science'] for c in p['contexts']];assert len(contexts)==64
            assert sum(c['case']['days'] for c in contexts)==1872 and sum(c['native_samples'] for c in contexts)==400 and sum(c['exact_cold_windows'] for c in contexts)==176
            assert sum(c.get('controls',{}).get('actual_compiled_refusals',0) for c in contexts)==1844
            assert sum(len(c.get('controls',{}).get('transactions',[])) for c in contexts)==88
            posts=[c for p in actual['new_original_portable_science'] for c in p['unaffected_postimages']];assert len(posts)==32 and sum(c['whole_objects'] for c in posts)==808
        else:assert b'PUBLICATION_REPLAY_SELECTED=false' in out and q['ordinary_python_default_dont_write_bytecode'] is False and q['child_bytecode_environment_variables_absent']
        observations[stem]=q['seconds']
negative=read('FROST_ANALYTICAL_BOUNDARY10_FINAL1_NEGATIVES_V1.json');assert negative['candidate']==C and negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
assert len(negative['controls'])==4 and {x['role'] for x in negative['controls']}=={'SOURCE','RAW','INHERITED','PUBLICATION'}
for item in negative['controls']:
    assert item['actual_refusal'] and item['actual_one_file_delta'] and git('show','-s','--format=%P',item['head']).decode().split()==[C]
    assert git('diff','--name-only',C,item['head']).decode().splitlines()==[item['path']]
    if item['role']=='PUBLICATION':assert item['actual_publication_replay_selected']
ci=read('FROST_ANALYTICAL_BOUNDARY10_PR1809_FINAL_ALL_CI_API_V1.json');runs=ci['runs']['workflow_runs'];checks=ci['checks']['check_runs']
assert ci['runs']['total_count']==len(runs)==len({x['workflow_id'] for x in runs})==14 and all(x['head_sha']==C and x['status']=='completed' and x['conclusion']=='success' for x in runs)
assert ci['checks']['total_count']==len(checks)==45 and all(x['head_sha']==C and x['status']=='completed' and x['conclusion'] in ['success','skipped'] for x in checks)
assert sum(x['conclusion']=='success' for x in checks)==28 and sum(x['conclusion']=='skipped' for x in checks)==17
for role in ['CO2','DVS','LRV','TIMEINT_STARTUP','TIMEINT_INVERSE','FCI_MODULAR']:
    stem='FROST_ANALYTICAL_BOUNDARY10_PR1809_'+role+'_ORIGINAL_CI_V1.log';raw=(E/stem).read_bytes();q=read(stem+'.json')
    assert len(raw)==q['bytes'] and SHA(raw)==q['sha256'] and q['actual_source']==C and q['actual_checkout']==S and C.encode() in raw and S.encode() in raw
closure=read('FROST_ANALYTICAL_BOUNDARY10_PREMERGE_CLOSURE_V1.json');assert closure['actual_candidate']==C and closure['actual_parent']==B
selection=read('FROST_ANALYTICAL_BOUNDARY10_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json');assert selection['actual_parent']==B and selection['actual_candidate']==C and selection['unchanged_tracked_files']==1063 and not git('diff',B,C,'--',*selection['unchanged_dependency_paths'])
canonical_ci=read('FROST_ANALYTICAL_BOUNDARY10_ACTUAL_MERGE_ALL_CI_API_V1.json')
assert canonical_ci['total_count']==len(canonical_ci['workflow_runs'])==4
for run in canonical_ci['workflow_runs']:
    assert run['head_sha']==M and run['status']=='completed' and run['conclusion']=='success'
    jobs=read('FROST_ANALYTICAL_BOUNDARY10_ACTUAL_MERGE_CI_JOBS_'+str(run['id'])+'_V1.json')['jobs']
    assert jobs and all(j['status']=='completed' and j['conclusion'] in ['success','skipped'] for j in jobs)
name='FROST_ANALYTICAL_BOUNDARY10_ADMISSION_RAW_V1';archive=E/(name+'.zip');files={}
for path in E.iterdir():
    if not path.is_file() or path.suffix in ('.zip','.tar','.gz','.xz') or '.zip.part' in path.name or path.name.startswith(name):continue
    if path.name.startswith(('FROST_ANALYTICAL_BOUNDARY10_','frost-analytical-boundary10-')):files[path.name]=path
assert Path(__file__).name in files
members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for member,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members) and len(z.namelist())==len(set(z.namelist()))
    for member,item in members.items():
        raw=z.read(member);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and raw==files[member].read_bytes()
raw=archive.read_bytes();common=dict(canonical_admission=True,actual_merge=M,qualified_candidate=C,source_anchor=A,whole_tree=tree,coadmission=coadmission,scientific_change_class='B_COMPOSITION_OF_EXISTING_UNCHANGED_PHYSICAL_PROCESSES_AND_EXISTING_NUMERICAL_SEARCH',new_scientific_contexts=64,actual_portable_scientific_producers=['b4ffcc914453225562ffe0e847faa21a765432ce','9d53d55a0ae5aa7567ee62bfcbc60fece1629905','45bb6146f5800f4050e95feb5d1912ddfdd23d4d'],actual_local_scientific_producers=['b24cebc3993b0f350c7aef7fb773a177d00425ce'],scientific_producers_rebound=False,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
manifest=dict(status='ACTUAL_CANONICAL824_ORIGINAL_PUBLIC_ORDINARY_PUB_14CI45CHECKS_SIX_LOGS_REAL_NEGATIVES_AND_SIGNED_OBJECTS_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,actual_public_observations=observations,canonical_push_workflows_success=4,successful_workflows=14,successful_checks=28,skipped_checks=17,full_model_periods_replayed_for_metadata=0,local_six_contexts_counted_again=False,unchanged_MCSOL_model_replay='NOT_SELECTED_IMPACT_1063_EXACT_DEPENDENCY_FILES',**common)
receipt=dict(status='ACTUAL_CANONICAL824_ANALYTICAL_FROST_NATIVE_STATE_CALENDAR_ADMISSION_VERIFIED',PR=1809,previous_canonical=B,ordered_parents=[B,C],synthetic_merge=S,admission_archive_sha256=SHA(raw),**common)
# Serialize both complete descriptors before writing either one.
outputs=[(name+'.json',json.dumps(manifest,indent=2)+'\n'),('FROST_ANALYTICAL_BOUNDARY10_MERGE_RECEIPT_V1.json',json.dumps(receipt,indent=2)+'\n')]
for file,text in outputs:
    with (E/file).open('x',encoding='utf8') as out:out.write(text)
assert git('rev-parse','HEAD').decode().strip()==M
print(manifest['status'],len(raw),manifest['sha256'],len(members),flush=True)
