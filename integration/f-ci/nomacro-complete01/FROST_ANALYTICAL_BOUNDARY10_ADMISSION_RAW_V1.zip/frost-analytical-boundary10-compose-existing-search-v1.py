"""Compose existing analytical Newton operators in bounded zero-flux6 Frost."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess,sys
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;P=R/'integration/f-ci/nomacro-complete01';APP=R/'app/hybrid_water';T=R/'tests/nomacro_drainage'
G=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
SHA=lambda b:hashlib.sha256(b).hexdigest();BEFORE='211faea04c2c2dd172ecbbb619e81bfce241fe68';BASE='9af88c3de6198ddec40c2674dd1542a89fa9c0d7'
assert G('rev-parse','HEAD').decode().strip()==BEFORE and not G('status','--porcelain=v1','--untracked-files=all','--ignored')
sys.path.insert(0,str(APP));from model7_terminal_water import SEARCH
search_sha=SHA(SEARCH.encode())
warning=E.parent/'b10pond-v1/case7/science/trajectory/original/swap.wrn';assert warning.is_file() and b'No convergence was reached' in warning.read_bytes()
helper='''"""Reuse existing numerical search only for explicit non1 Frost bottom6."""
from pathlib import Path
import hashlib
from model7_terminal_water import SEARCH
PARENT_SHA='15bac3d3cc0ee41918b5c6bf53aa75f50c85a1bbc0f56db66431045ab9d87a69'
SEARCH_SHA='SEARCH_DIGEST'
IMPORT='   use hybrid_step_budget, only: projected_water_residual'
COMPOSED_IMPORT=IMPORT+', linear_pond_top_jacobian\\n   use variables, only: rsro, rsroexp, pondmx'
JACOBIAN='   if (ftoph) dFdhM(1) = dFdhM(1) + kmean(1)/disnod(1)'
COMPOSED_JACOBIAN='''+repr('''   if (ftoph) then
      if (flrunoff .and. rsroexp==1d0 .and. rsro>=1d-3) then
         dFdhM(1)=dFdhM(1)+linear_pond_top_jacobian(kmean(1)/disnod(1),dt,pond,pondmx,rsro)
      else
         dFdhM(1)=dFdhM(1)+kmean(1)/disnod(1)
      end if
   end if''')+'''


def selected(item):
    return bool(item and item.get('analytical_frost_models') and any(x!=1 for x in item['analytical_frost_models']) and item['bottom']==6 and item['implicit']==item['hysteresis']==0 and item['drainage'] in (0,1))


def metadata(item):
    if not selected(item):return None
    assert hashlib.sha256(SEARCH.encode()).hexdigest()==SEARCH_SHA
    return dict(policy='existing-explicit-analytical-zero-flux6-frost-search-composition-v1',provider_lf_sha256=hashlib.sha256(Path(__file__).read_bytes().replace(b'\\r\\n',b'\\n')).hexdigest(),complete_parent_headcalc_lf_sha256=PARENT_SHA,inherited_numerical_search_sha256=SEARCH_SHA,linear_pond_operator='hybrid_step_budget.linear_pond_top_jacobian',search_scope='Original analytical fully saturated closed-bottom flux null mode; original default-model1 numerical diagonal, no physical capacity change',absolute_water_limit_cm='1e-10',physical_equations_changed=False,accepted_state_or_flux_assignment_added=False,iteration_or_retry_limits_changed=False,new_native_state=False)


def source(before):
    assert hashlib.sha256(before.encode('cp1252')).hexdigest()==PARENT_SHA,'Foreign complete Frost zero-flux6 search parent'
    assert hashlib.sha256(SEARCH.encode()).hexdigest()==SEARCH_SHA
    edits=[(IMPORT,COMPOSED_IMPORT),(JACOBIAN,COMPOSED_JACOBIAN),('end subroutine jacobian_F',SEARCH+'end subroutine jacobian_F')]
    after=before
    for old,new in edits:
        assert after.count(old)==1,'Foreign existing Frost Newton seam'
        after=after.replace(old,new,1)
    return after


def inverse(after):
    before=after
    for old,new in [(IMPORT,COMPOSED_IMPORT),(JACOBIAN,COMPOSED_JACOBIAN),('end subroutine jacobian_F',SEARCH+'end subroutine jacobian_F')]:
        assert before.count(new)==1,'Foreign actual composed Frost Newton operator'
        before=before.replace(new,old,1)
    assert hashlib.sha256(before.encode('cp1252')).hexdigest()==PARENT_SHA and source(before)==after
    return before


def apply_build(output,item):
    if not selected(item):return
    path=Path(output)/'headcalc.f90';path.write_text(source(path.read_text(encoding='cp1252')),encoding='cp1252')


def validate(bundle,item):
    if selected(item):inverse((Path(bundle)/'headcalc.f90').read_text(encoding='cp1252'))
'''.replace('SEARCH_DIGEST',search_sha)
ast.parse(helper);assert not (APP/'frost_analytical_boundary_search.py').exists();(APP/'frost_analytical_boundary_search.py').write_text(helper)
path=APP/'frost_calendar_output.py';text=path.read_text();anchor="    providers.append('cde_interval_snow_state.f90' if project.solute else SNOW_PROVIDER+'.f90')";assert text.count(anchor)==1
text=text.replace(anchor,"    from frost_analytical_boundary_search import metadata as boundary_search_metadata\n    boundary_search=boundary_search_metadata(boundary)\n    if boundary_search is not None:providers.append('frost_analytical_boundary_search.py')\n"+anchor,1)
anchor='    return dict(policy=policy,native_codec=codec(project).decode(),**selected,';assert text.count(anchor)==1
text=text.replace(anchor,anchor+"\n        **({'analytical_boundary_search':boundary_search} if boundary_search is not None else {}),",1)
anchor="    patched=[*extra,*patched];patched.insert(patched.index('swap'),'age_output_calendar_probe');return patched";assert text.count(anchor)==1
text=text.replace(anchor,"    from frost_analytical_boundary_search import apply_build as boundary_search_build\n    boundary_search_build(output,input_selection(project.input_directory,project.original_output))\n"+anchor,1);ast.parse(text);path.write_text(text)
path=APP/'frost_analytical_composition.py';text=path.read_text();text+='\n    from frost_analytical_boundary_search import validate as validate_boundary_search\n    validate_boundary_search(bundle,item)\n';ast.parse(text);path.write_text(text)
old=json.loads((P/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V2.json').read_text());files={}
for file in [*old['files'],'app/hybrid_water/frost_analytical_boundary_search.py']:
    actual=(R/file).read_bytes().replace(b'\r\n',b'\n');item=dict(proposed_lf_sha256=SHA(actual))
    try:before=G('show',BASE+':'+file)
    except subprocess.CalledProcessError:item['added']=True
    else:
        text=before.decode();after=actual.decode();edits=[dict(base_start=i,base_end=j,before=text[i:j],after=after[k:l]) for tag,i,j,k,l in difflib.SequenceMatcher(None,text,after,autojunk=False).get_opcodes() if tag!='equal'];item.update(before_lf_sha256=SHA(before),ordered_literal_edits=edits)
    files[file]=item
proposal=dict(old,status='CURRENT_EIGHT_ACTUAL_SOURCE_FILES_COMPOSE_EXISTING_CLOSED_BOTTOM_NEWTON_OPERATORS_NOT_YET_QUALIFIED',files=files,actual_previous_source=BEFORE,actual_before_source=BASE,new_physical_equations=False,model_or_compiler_executions=0,search_proposal='FROST_ANALYTICAL_BOUNDARY10_SEARCH_COMPOSITION_DESIGN_V1.json')
(P/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V3.json').write_text(json.dumps(proposal,indent=2)+'\n')
path=T/'frost_analytical_boundary_input_contract.py';text=path.read_text();assert text.count('FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V2')==2;path.write_text(text.replace('FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V2','FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V3'))
design=dict(status='PROPOSED_EXISTING_NUMERICAL_OPERATOR_COMPOSITION_REQUIRES_REAL_O0_O2_VERIFICATION',classification='COMPOSITION_MISSING_AND_NUMERICAL_DEFECT',actual_before=BEFORE,actual_parent=BASE,complete_head_parent_sha256='15bac3d3cc0ee41918b5c6bf53aa75f50c85a1bbc0f56db66431045ab9d87a69',existing_search_sha256=search_sha,source='Existing model7_terminal_water.SEARCH and hybrid_step_budget.linear_pond_top_jacobian; unchanged literal operators already qualified outside Snow/Frost',evidence='Actual211faea model8D0bottom6 unbuffered33day reproduction retains four original No convergence was reached warnings on day33; first four portable refusals and all original data retained',original_unbuffered_warning_sha256=SHA(warning.read_bytes()),changed_case_indices=[3,5,7,8,10,12,14,15],unaffected_case_indices=[0,1,2,4,6,9,11,13],qualification_rule='Requalify eight actually changed non1 bottom6 cases as one coherent numerical coupling batch. Preserve eight other case configurations through current generated/source/object postimages; no unchanged model period replay.',limits_criteria_and_physical_equations_changed=False,artificial_mass_inventory_or_flux_correction=False,whole_functional_completion='PARTIAL',scientific_equivalence='NOT_QUALIFIED')
(P/'FROST_ANALYTICAL_BOUNDARY10_SEARCH_COMPOSITION_DESIGN_V1.json').write_text(json.dumps(design,indent=2)+'\n')
q=json.loads((P/'STATUS.json').read_text());q['frost_analytical_boundary10'].update(status='EXISTING_NUMERICAL_SEARCH_OPERATORS_COMPOSED_IN_EIGHT_NON1_BOTTOM6_CASES_NOT_YET_COMPILED',search_design='FROST_ANALYTICAL_BOUNDARY10_SEARCH_COMPOSITION_DESIGN_V1.json',source_proposal='FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V3.json',changed_case_indices=design['changed_case_indices'],unaffected_case_indices=design['unaffected_case_indices'])
q['closure03']=dict(active=True,same_work_unit=True,functional_completion_judgement='PARTIAL',NOMACRO_SCIENTIFIC_EQUIVALENCE='NOT_QUALIFIED',global_functional_inventory_counts='UNKNOWN',taxonomy=['FUNCTIONAL_MISSING','COMPOSITION_MISSING','GUARD_ONLY','NUMERICAL_DEFECT','LEGACY_DEFECT','SCIENTIFIC_DECISION','EVIDENCE_ONLY','NOT_HISTORICALLY_SUPPORTED','EXCLUDED_MACRO'],next='Finish coherent current boundary10 acceptance, then close finite source-dependency family inventory in existing GAP_MATRIX; keep verified legacy defects and scientific decisions distinct without unsupported exclusions.')
q['next_action']='Compile and execute actual local O0/O2 model8zero-flux6 on persisted search postimage; require35days, original1e-10 daily/prefix water/CDE, convergence without legacy continuation, native/cold. Then test year11 and model9drained endpoints, requalify all8changed configurations/profile as one batch. Do not replay8unaffected case periods.'
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n')
G('add','--sparse','--','app/hybrid_water','tests/nomacro_drainage/frost_analytical_boundary_input_contract.py',str(P.relative_to(R)));G('commit','-m','Compose existing exact pond Jacobian and saturated search for analytical Frost zero-flux6')
print('ACTUAL_NEW_SEARCH_SOURCE',G('rev-parse','HEAD').decode().strip(),flush=True)