"""Directed local actual public boundary10 build/runtime, strict original budgets."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
C='07e3851392ac641ba8a55f41f85dfc8212b91c79'
p=argparse.ArgumentParser();p.add_argument('--opt',choices=['O0','O2'],required=True);a=p.parse_args()
git=lambda *args:subprocess.check_output(['git',*args],cwd=R).decode().strip()
assert git('rev-parse','HEAD')==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from frost_analytical_boundary_inputs import prepare
from frost_boundary_convergence import require_convergence
cases=json.loads((R/'integration/f-ci/nomacro-complete01/FROST_ANALYTICAL_BOUNDARY10_INPUT_CONTRACT_PROPOSED_V1.json').read_text())['representative_cases']
env=dict(os.environ,OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TEMP=str(W/'active-python-scratch-v2'),TMP=str(W/'active-python-scratch-v2'));env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
for index in [0,6]:
    case=cases[index];name=case['name'];D=W/'frost-analytical-boundary10-local-science-v1'/(a.opt+'-'+name);D.mkdir()
    inputs=D/'inputs';prepare(case,inputs)
    build=W/('frost-analytical-boundary10-local-'+a.opt+'-v1')/name/'bundle'
    q=dict(status='RUNNING_ACTUAL_BOUNDARY10_NOT_QUALIFIED',actual_source=C,case=case,optimization=a.opt,input_root=str(inputs),build_root=str(build),canonical_admission=False)
    save=lambda:(D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
    def run(command,label,cap):
        started=time.perf_counter()
        with (D/(label+'.stdout')).open('xb') as out,(D/(label+'.stderr')).open('xb') as err:result=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=cap)
        q[label]=dict(command=command,returncode=result.returncode,seconds=time.perf_counter()-started);save();result.check_returncode();return q[label]
    save()
    try:
        command=[sys.executable,'-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy','original-adaptive-event-closure-v1','--reference-work',str(J),'--build-only','--donor-opt',a.opt,'--kernel-opt',a.opt,'--output',str(build)]
        record=run(command,'actual-public-build',300)
        (D/'BUILD_RESULT.json').write_text(json.dumps(dict(status='ACTUAL_PUBLIC_BOUNDARY_FROST_BUILD_NOT_QUALIFIED',actual_source=C,input_root=str(inputs),build_root=str(build),returncode=0,command=command,seconds=record['seconds']),indent=2)+'\n')
        run([sys.executable,'-B','tests/nomacro_drainage/frost_analytical_boundary_runtime.py','--build-record',str(D/'BUILD_RESULT.json'),'--reference-work',str(J),'--output',str(D/'science'),'--days',str(case['days'])],'actual-public-runtime',900)
        q['science']=json.loads((D/'science/RESULT.json').read_text());assert q['science']['status']=='ACTUAL_ANALYTICAL_BOUNDARY_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_MODEL_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED'
        q['original_convergence']=require_convergence(D/'science')
        assert git('rev-parse','HEAD')==C
        q['status']='ACTUAL_DIRECTED_BOUNDARY10_ORIGINAL_BUDGETS_TYPED_NATIVE_EXACT_COLD_PASS_NOT_ADMITTED'
    except Exception as exc:q.update(status='FAILED_ACTUAL_DIRECTED_BOUNDARY10_NOT_QUALIFIED',error=repr(exc));raise
    finally:save()
    print(q['status'],a.opt,name,flush=True)
