from pathlib import Path
import json,hashlib,subprocess,sys,datetime
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';E=Path('C:/Users/Veldh012/SWAP5-work/'+TASK+'-a9ded600/evidence');audit=Path('C:/Users/Veldh012/Opslagaudit-SWAP5-20261123/recheck.json');q=json.loads(audit.read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();rows=[]
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
for item in q['copies']:
 path=Path(item['path']);assert path.parent in [Path('C:/Users/Veldh012/swap5-complete01-evidence'),Path('C:/Users/Veldh012/swap5-coverage-evidence')]
 assert not path.is_symlink()
 if not path.exists():continue
 assert path.stat().st_size==item['bytes'] and sha(path)==item['sha256']
 parts=item.get('git_parts') or [dict(git_path=item['git_path'],bytes=item['bytes'],sha256=item['sha256'])];h=hashlib.sha256();total=0;retained=[]
 for part in parts:
  raw=subprocess.check_output(['git','show',head+':'+part['git_path']],cwd=R)
  assert len(raw)==part['bytes'] and hashlib.sha256(raw).hexdigest()==part['sha256'];h.update(raw);total+=len(raw)
  blob=subprocess.check_output(['git','rev-parse',head+':'+part['git_path']],cwd=R,text=True).strip();retained.append(dict(git_path=part['git_path'],git_blob=blob,bytes=len(raw),sha256=part['sha256']))
 assert total==item['bytes'] and h.hexdigest()==item['sha256']
 rows.append(dict(path=str(path),bytes=total,sha256=h.hexdigest(),retained_git_source=head,retained_git_parts=retained,authorization='Only this exact redundant local archive file; recheck current bytes and active dependencies immediately before deletion'))
 print('REDUNDANT_LOCAL_ARCHIVE_GIT_IDENTITY_VERIFIED',len(rows),path.name,flush=True)
for path in ['C:/Users/Veldh012/swap5-complete01-evidence','C:/Users/Veldh012/swap5-coverage-evidence']:
 p=subprocess.run([sys.executable,'-B',str(C),'unprotect','--task',TASK,'--path',path],capture_output=True,text=True);assert p.returncode==0,(p.stdout,p.stderr)
retained=['C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider',str(E),'C:/Users/Veldh012/swap5-complete01-evidence/implicit-age-dryout-component-O0-v1','C:/Users/Veldh012/swap5-complete01-evidence/implicit-age-dryout-component-O2-v1','C:/Users/Veldh012/swap5-complete01-evidence/implicit-groundwater-diagnostic-age-dryout-v2']
record=dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),task=TASK,state='ACTIVE_NOT_FINISHED',actual_checked_git_source=head,verified_redundant_local_archives=rows,verified_redundant_archive_bytes=sum(x['bytes'] for x in rows),broad_protection_removed_only_from_two_legacy_roots=True,required_dependencies_kept_protected=retained,all_other_files_and_directories='NOT_ASSESSED_FOR_DELETION; unique source/input/raw scientific evidence must remain; no blanket deletion authorization',current_local_build_release_receipt=str(E/'FROST_ANALYTICAL_BOUNDARY10_LOCAL_RESOURCE_CENTRAL_CUSTODY_V2.json'),current_raw2_central_archive='integration/f-ci/nomacro-complete01/FROST_ANALYTICAL_BOUNDARY10_LOCAL_WINDOWS_O0_O2_RAW_V2.json',current_raw2_sha256='175e4ddef38778bb60001b1449cf0fcb23ae343852206e06d9a7f98538346d13',no_model_periods_replayed=True)
out=Path('C:/Users/Veldh012/Opslagaudit-SWAP5-20261126/vrijgave-migratie.json');out.parent.mkdir(exist_ok=True)
with out.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('EXPLICIT_STORAGE_RELEASE_RECORDED',len(rows),record['verified_redundant_archive_bytes'],flush=True)
