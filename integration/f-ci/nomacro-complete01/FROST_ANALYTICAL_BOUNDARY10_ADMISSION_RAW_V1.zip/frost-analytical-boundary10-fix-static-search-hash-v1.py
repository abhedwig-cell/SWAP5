from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;P=R/'integration/f-ci/nomacro-complete01';APP=R/'app/hybrid_water';T=R/'tests/nomacro_drainage'
G=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
old='a96395142613ed8daf87c7cfcebfae7806d5cb3a';assert G('rev-parse','HEAD').decode().strip()==old
sys.path.insert(0,str(APP));from model7_terminal_water import SEARCH
actual=hashlib.sha256(SEARCH.encode()).hexdigest();design=json.loads((P/'FROST_ANALYTICAL_BOUNDARY10_SEARCH_COMPOSITION_DESIGN_V1.json').read_text());assert actual==design['existing_search_sha256']
path=APP/'frost_analytical_boundary_search.py';text=path.read_text();assert text.count("SEARCH_SHA='SEARCH_DIGEST'")==1;text=text.replace("SEARCH_SHA='SEARCH_DIGEST'","SEARCH_SHA='"+actual+"'",1);path.write_text(text)
q=json.loads((P/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V3.json').read_text());q['files']['app/hybrid_water/frost_analytical_boundary_search.py']['proposed_lf_sha256']=hashlib.sha256(path.read_bytes().replace(b'\r\n',b'\n')).hexdigest();q.update(actual_previous_source=old,status='ACTUAL_LITERAL_ACCEPTED_SEARCH_HASH_BOUND_BEFORE_ANY_COMPILATION_NOT_SCIENTIFICALLY_QUALIFIED')
(P/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V4.json').write_text(json.dumps(q,indent=2)+'\n')
path=T/'frost_analytical_boundary_input_contract.py';text=path.read_text();assert text.count('FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V3')==2;path.write_text(text.replace('FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V3','FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V4'))
refusal=dict(status='STATIC_PRECOMPILE_HASH_LITERAL_CORRECTED_NO_COMPILER_OR_MODEL_EXECUTION',actual_uncompiled_prototype=old,found='SEARCH_DIGEST literal remained in first concatenated draft section',actual_existing_SEARCH_sha256=actual,compiler_executions=0,model_executions=0,scientific_evidence_rebound=False)
with (E/'FROST_ANALYTICAL_BOUNDARY10_SEARCH_STATIC_HASH_LITERAL_REFUSAL_V1.json').open('x') as out:json.dump(refusal,out,indent=2);out.write('\n')
q=json.loads((P/'STATUS.json').read_text());q['frost_analytical_boundary10'].update(source_proposal='FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V4.json',static_uncompiled_hash_literal_correction='FROST_ANALYTICAL_BOUNDARY10_SEARCH_STATIC_HASH_LITERAL_REFUSAL_V1.json');(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n')
G('add','--sparse','--','app/hybrid_water/frost_analytical_boundary_search.py','tests/nomacro_drainage/frost_analytical_boundary_input_contract.py',str(P.relative_to(R)));G('commit','-m','Bind existing analytical search body hash before real compilation')
print('ACTUAL_SEARCH_BUILD_SOURCE',G('rev-parse','HEAD').decode().strip(),flush=True)