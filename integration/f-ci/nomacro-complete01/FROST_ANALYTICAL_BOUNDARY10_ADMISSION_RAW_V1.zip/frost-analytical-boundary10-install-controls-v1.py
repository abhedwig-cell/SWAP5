"""Persist controller-only drainage witness fix and coherent16-case controls."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;T=R/'tests/nomacro_drainage';P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
C='07e3851392ac641ba8a55f41f85dfc8212b91c79';assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
# Both actual D1 model periods/cold workers completed; original failed witness checks stay untouched.
failures={}
for opt in ['O0','O2']:
    D=E.parent/'frost-analytical-boundary10-local-science-v1'/(opt+'-model7-cde-d1-b8-dense')
    q=json.loads((D/'science/RESULT.json').read_text());error=(D/'actual-public-runtime.stderr').read_text()
    assert q['source']==C and q['duration_days']==35 and len(q['own'])==3 and q['error']=='AssertionError()'
    assert "thermal=struct.pack('<10i',1,nodes,0,solute,hys,1,1,0,1,2)" in error
    failures[opt]=dict(actual_scientific_source=C,completed_days=35,completed_cold_windows=3,failed_controller='hard-coded drainage0 thermal witness although selected actual drainage1',original_stdout_sha256=hashlib.sha256((D/'actual-public-runtime.stdout').read_bytes()).hexdigest(),original_stderr_sha256=hashlib.sha256((D/'actual-public-runtime.stderr').read_bytes()).hexdigest(),model_replay_needed=False)
with (E/'FROST_ANALYTICAL_BOUNDARY10_LOCAL_DRAINAGE_WITNESS_CONTROLLER_REFUSAL_V1.json').open('x') as out:json.dump(failures,out,indent=2)
path=T/'frost_analytical_boundary_runtime.py';text=path.read_text();old="thermal=struct.pack('<10i',1,nodes,0,solute,hys,1,1,0,1,2)";assert text.count(old)==1
path.write_text(text.replace(old,"thermal=struct.pack('<10i',1,nodes,0,solute,hys,1,1,selected['drainage'],1,2)"))
for name in ['frost_analytical_boundary_native_controls','frost_analytical_boundary_controls']:
    raw=(E/(name+'.PROPOSED_V1.py')).read_bytes();ast.parse(raw);(T/(name+'.py')).write_bytes(raw)
text=(T/'frost_analytical_extra_native.py').read_text().replace("b'S5UAW001',b'S5UAC001')","b'S5UAW001',b'S5UAC001',b'S5FAW001',b'S5FAC001')")
assert 'len(set(codecs))==22' in text;text=text.replace('len(set(codecs))==22','len(set(codecs))==24').replace('(45 if project.solute else 41)','(47 if project.solute else 43)')
(T/'frost_analytical_boundary_extra_native.py').write_text(text)
p=T/'frost_analytical_boundary_controls.py';text=p.read_text().replace('from frost_analytical_extra_native import','from frost_analytical_boundary_extra_native import').replace('(45 if project.solute else 41)','(47 if project.solute else 43)');p.write_text(text)
text=(T/'frost_analytical_input_contract.py').read_text().replace("BASE='f3faeaa540e7fd81686802414d53ff6686f3ce7b'","BASE='9af88c3de6198ddec40c2674dd1542a89fa9c0d7'").replace('FROST_ANALYTICAL_COMPOSITION09_SOURCE_PROPOSAL_V3','FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V2').replace("contract['actual_canonical_parent']","contract['actual_before_source']").replace('FROST_ANALYTICAL_COMPOSITION09_INPUT_CONTRACT_V1','FROST_ANALYTICAL_BOUNDARY10_INPUT_CONTRACT_PROPOSED_V1').replace('==12','==16')
old="c['drainage']==0 and c['bottom'] in (5,8)";new="((c['drainage']==0 and c['bottom']==6) or (c['drainage']==1 and c['bottom'] in (5,6,8)))";assert old in text;text=text.replace(old,new).replace('AND12_CASE','AND16_CASE').replace('ACTUAL_COMPLETE_ANALYTICAL_FROST','ACTUAL_COMPLETE_ANALYTICAL_BOUNDARY_FROST');(T/'frost_analytical_boundary_input_contract.py').write_text(text)
text=(T/'frost_analytical_case.py').read_text()
for old,new in [('from frost_analytical_inputs import','from frost_analytical_boundary_inputs import'),('from frost_analytical_input_contract import','from frost_analytical_boundary_input_contract import'),('frost_analytical_state_runtime.py','frost_analytical_boundary_runtime.py'),('frost_analytical_controls.py','frost_analytical_boundary_controls.py')]:assert old in text;text=text.replace(old,new)
anchor="        run(command,'actual-compiled-and-transaction-controls',300)"
assert anchor in text;text=text.replace(anchor,"        if case['full_legacy_native_controls']:command.append('--full-legacy-native-controls')\n        if case['active_frost_transactions']:command.append('--active-frost-transactions')\n"+anchor).replace('ACTUAL_ANALYTICAL_FROST','ACTUAL_ANALYTICAL_BOUNDARY_FROST').replace('ACTUAL_PUBLIC_ANALYTICAL_FROST','ACTUAL_PUBLIC_ANALYTICAL_BOUNDARY_FROST')
(T/'frost_analytical_boundary_case.py').write_text(text)
text=(T/'frost_analytical_portable.py').read_text().replace('from frost_analytical_input_contract import','from frost_analytical_boundary_input_contract import').replace('frost_analytical_case.py','frost_analytical_boundary_case.py').replace('==12','==16').replace('TWELVE','SIXTEEN').replace('ACTUAL_ANALYTICAL_FROST','ACTUAL_ANALYTICAL_BOUNDARY_FROST').replace('ACTUAL_PUBLIC_ANALYTICAL_FROST','ACTUAL_PUBLIC_ANALYTICAL_BOUNDARY_FROST');(T/'frost_analytical_boundary_portable.py').write_text(text)
for path in T.glob('frost_analytical_boundary*.py'):ast.parse(path.read_bytes())
q=json.loads((P/'STATUS.json').read_text());q['frost_analytical_boundary10'].update(status='FOUR_DIRECTED_ORIGINAL_PERIODS_COLD_COMPLETED_D1_CONTROLLER_WITNESS_CORRECTED_READONLY_AUDIT_NEXT',actual_scientific_source=C,water_free6_O0_O2='PASS',drained_model7_cde_O0_O2='35days/3cold completed; original incorrect controller drainage0 witness refused; retain failure and audit saved originals without model replay')
q['next_action']='Audit four saved local35day trajectories and exact cold/native originals on corrected controller; run compiled boundary-domain and selected original thermal/Snow/private controls; preserve originals before full16case portable qualification.'
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n')
git('add','--sparse','--',str(T.relative_to(R)),str((P/'STATUS.json').relative_to(R)));git('commit','-m','Verify actual drainage native witness and add proportional coherent boundary controls')
print('CONTROLLER_ONLY_POSTIMAGE_PERSISTED',git('rev-parse','HEAD').decode().strip(),flush=True)
