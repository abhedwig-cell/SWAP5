"""Persist explicit independent first-run audit without declaring full16 PASS."""
from pathlib import Path
import ast,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;P=R/'integration/f-ci/nomacro-complete01';T=R/'tests/nomacro_drainage'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()=='9d53d55a0ae5aa7567ee62bfcbc60fece1629905'
path=T/'frost_analytical_boundary_archive_science.py';text=path.read_text();at=text.index("if __name__=='__main__':")
text=text[:at]+'''
def first_portable(proof,platform,opt,verbose=False):
    with ExitStack() as stack:
        store=Archive(proof,f'FROST_ANALYTICAL_BOUNDARY10_FIRST_{platform.upper()}_{opt}_ORIGINAL_V1',stack)
        _,custody=captured_source(store,stack,PRODUCER,PRODUCER,f'.github/workflows/nomacro-frost-analytical-boundary10-{platform.lower()}.yml')
        contract=json.loads(git('show',PRODUCER+':'+P+'FROST_ANALYTICAL_BOUNDARY10_INPUT_CONTRACT_PROPOSED_V1.json'))
        assert json.loads(store.get('actual-input-contract.json'))==contract
        q=json.loads(store.get('current/RESULT.json'))
        assert q['status']=='FAILED_ANALYTICAL_FROST_PORTABLE_NOT_QUALIFIED' and q['source']==PRODUCER and q['platform']==platform and q['optimization']==opt
        assert len(q['contexts'])==7 and [c['case'] for c in q['contexts']]==contract['representative_cases'][:7]
        contexts=[]
        for case in contract['representative_cases'][:7]:
            contexts.append(case_audit(store,'current/'+case['name'],case,store,PRODUCER,opt))
            if verbose:print('INDEPENDENT_FIRST_ORIGINAL_BOUNDARY_CONTEXT_PASS',platform,opt,case['name'],flush=True)
        old=Archive(GitArchiveSource(R,BASE),f'FROST_ANALYTICAL_COMPOSITION09_{platform.upper()}_{opt}_ORIGINAL_V1',stack)
        postimages=inherited(store,old,opt);assert len(postimages)==4 and sum(x['whole_objects'] for x in postimages)==100
        case=contract['representative_cases'][7];assert case['effective_models']==[8,8] and case['drainage']==0 and case['bottom']==6
        folder=ReadView(store,'current/'+case['name']);failed=read(folder/'science/RESULT.json')
        assert failed['source']==failed['actual_controller_source']==PRODUCER and failed['status']=='FAILED_ACTUAL_ANALYTICAL_BOUNDARY_FROST_CALENDAR_NOT_QUALIFIED'
        rows=[json.loads(line) for line in (folder/'science/trajectory/daily.jsonl').read_text().splitlines()]
        assert len(rows)==33 and [x['day'] for x in rows]==list(range(1,34)) and all(x['committed'] for x in rows[:32]) and not rows[-1]['committed']
        assert abs(rows[-1]['independent_residual_cm'])>1e-10 and abs(rows[-1]['kernel_residual_cm'])>1e-10 and abs(rows[-1]['integrated_guard_residual_cm'])<=1e-10
        assert b'Rejected day 33' in (folder/'actual-public-runtime.stderr').read_bytes()
        return dict(status='INDEPENDENT_FIRST7_SUCCESSFUL_CONTEXTS_4_OLD09_POSTIMAGES_AND_TRUE_MODEL8_DAY33_REFUSAL_VERIFIED_NOT_ADMITTED',source=custody,platform=platform,optimization=opt,contexts=contexts,inherited_postimages=postimages,failed_case=case,actual_rejected_receipt=rows[-1],failed_case_prior_accepted_days=32,whole_batch_qualified=False,compiler_executions=0,model_executions=0,canonical_admission=False)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--first',action='store_true');p.add_argument('--platform',choices=['Windows','Ubuntu'],required=True);p.add_argument('--optimization',choices=['O0','O2'],required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    head=git('rev-parse','HEAD').decode().strip();q=dict(status='RUNNING_INDEPENDENT_BOUNDARY_ARCHIVE_AUDIT',actual_observer=head)
    try:q['audit']=(first_portable if a.first else portable)(GitArchiveSource(R,head),a.platform,a.optimization,True);q['status']=q['audit']['status']
    except Exception as error:q.update(status='FAILED_INDEPENDENT_BOUNDARY_ARCHIVE_AUDIT',error=repr(error));raise
    finally:
        assert git('rev-parse','HEAD').decode().strip()==head
        with a.output.open('x') as out:json.dump(q,out,indent=2);out.write('\\n')
    print(q['status'],flush=True)
'''
ast.parse(text);path.write_text(text)
q=json.loads((P/'STATUS.json').read_text());q['frost_analytical_boundary10'].update(first_official_raw_preserved=True,original_first_phase_source='b4ffcc914453225562ffe0e847faa21a765432ce',continuation_source='9d53d55a0ae5aa7567ee62bfcbc60fece1629905',continuation_runs=[45779239076,45779239084],new_admitted_contexts=0)
q['next_action']='Independently audit four immutable first-run official ZIPs at actual b4source:7successful contexts/4whole old09 postimages each and day33 model8refusal. Follow continuation9d53 runs45779239076/45779239084 through all8selectedcases without rerunning first28 periods. Preserve observed zero-flux6 nomenclature correction and diagnose pond disappearance cause.'
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n')
git('add','--sparse','--',str(P.relative_to(R)),str(path.relative_to(R)));git('commit','-m','Preserve four original portable artifacts and independently audit partial boundary outcomes')
print('ACTUAL_FIRST_INDEPENDENT_OBSERVER',git('rev-parse','HEAD').decode().strip(),flush=True)