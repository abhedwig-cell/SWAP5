"""Persist actual canonical09 admission and next coherent boundary10 source."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
M='9af88c3de6198ddec40c2674dd1542a89fa9c0d7';BR='codex/nomacro-frost-analytical-boundary10'
SHA=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
def read(n):return json.loads((E/n).read_text())
assert git('rev-parse','HEAD').decode().strip()==M and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
receipt=read('FROST_ANALYTICAL_COMPOSITION09_MERGE_RECEIPT_V1.json');assert receipt['actual_merge']==M and receipt['canonical_admission']
archive=E/'FROST_ANALYTICAL_COMPOSITION09_ADMISSION_RAW_V1.zip';assert SHA(archive.read_bytes())==receipt['admission_archive_sha256']
for scope in ['PUBLIC','PUBLICATION']:
    q=read('FROST_ANALYTICAL_COMPOSITION09_ACTUAL_MERGE_'+scope+'_V1.json')
    assert q['returncode']==0 and q['error'] is None and q['before']==q['after'] and q['before']['head']==M
git('switch','-c',BR,M)
names=['FROST_ANALYTICAL_COMPOSITION09_ADMISSION_RAW_V1.zip','FROST_ANALYTICAL_COMPOSITION09_ADMISSION_RAW_V1.json','FROST_ANALYTICAL_COMPOSITION09_MERGE_RECEIPT_V1.json',
'FROST_ANALYTICAL_DRAINAGE10_ORIGINAL_DISCOVERY_RAW_V1.zip','FROST_ANALYTICAL_DRAINAGE10_ORIGINAL_DISCOVERY_RAW_V1.json',
'FROST_ANALYTICAL_BOUNDARY10_FREE6_ORIGINAL_DISCOVERY_RAW_V1.zip','FROST_ANALYTICAL_BOUNDARY10_FREE6_ORIGINAL_DISCOVERY_RAW_V1.json',
'FROST_ANALYTICAL_BOUNDARY10_COHERENT_EXPANDED_DESIGN_V3.json','FROST_ANALYTICAL_BOUNDARY10_INPUT_CONTRACT_PROPOSED_V1.json','FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V2.json']
for name in names:
    assert not (P/name).exists();shutil.copyfile(E/name,P/name);assert (P/name).read_bytes()==(E/name).read_bytes()
doc='docs/science/NOMACRO_FROST_ANALYTICAL_COMPOSITION09.md';before=git('show',M+':'+doc).decode();after=before
edits=[('Qualified source science; canonical admission pending. Canonical parent is','Current / canonically admitted on signed canonical '+M+' through PR1808. Previous canonical parent is'),
('A real canonical merge receipt, not these source observations,\nwill establish admission. The prospective bounded coadmission is760 contexts.','The actual merge receipt establishes bounded canonical admission of760 contexts. Candidate PUBLIC921.703s/ordinaryPUB698.407s and actual canonical PUBLIC890.399s/ordinaryPUB747.131s pass with equal clean14-rule/56-fixture snapshots. All14 selected PR workflows and45 checks (28success17policy skips), four actual committed negative controls, six original CI logs, signed Git objects and all4 automatic canonical push workflows pass and are preserved in admission raw SHA'+receipt['admission_archive_sha256']+'.'),
('The next functional investigation is original drainage-on analytical Frost\ncomposition.','The next functional batch composes original free-bottom6 drainage0, including original default model1, and analytical non1 drainage1/SWDIVD1 bottoms5/6/8.')]
for old,new in edits:assert after.count(old)==1;after=after.replace(old,new,1)
(R/doc).write_text(after,encoding='utf8')
literal=[dict(base_start=i,base_end=j,before=before[i:j],after=after[k:l]) for tag,i,j,k,l in difflib.SequenceMatcher(None,before,after,autojunk=False).get_opcodes() if tag!='equal']
witness=dict(status='ACTUAL_CANONICAL760_PARENT_ADMISSION_METADATA_WITNESS',actual_parent=M,files={doc:dict(before_lf_sha256=SHA(before.encode()),proposed_lf_sha256=SHA(after.encode()),ordered_literal_edits=literal)},physical_source_changed=False,model_replays=0)
(P/'FROST_ANALYTICAL_BOUNDARY10_PARENT_METADATA_WITNESSES_V1.json').write_text(json.dumps(witness,indent=2)+'\n')
next_action='Install seven literal source postimages from SOURCE_PROPOSAL_V2 and corrected input factory V2; persist actual source then local O0/O2 original-budget/native/cold directed default-model1 D0bottom6 and model7CDE D1bottom8. Preserve unchanged09 through actual whole generated/object comparisons, no old period replay. Complete16-case coherent boundary10 portable and independent qualification before admission.'
q=json.loads((P/'STATUS.json').read_text());q.update(canonical=M,branch=BR,last_commit=M,active_functional_batch='frost_analytical_boundary10',next_action=next_action)
q['frost_analytical_composition09'].update(status='ACTUAL_CANONICAL760_ANALYTICAL_FROST_COMPOSITION_ADMITTED',actual_canonical=M,canonical_admission=True,new_admitted_contexts=48,merge_receipt='FROST_ANALYTICAL_COMPOSITION09_MERGE_RECEIPT_V1.json',admission_raw_sha256=receipt['admission_archive_sha256'],next_action='Bounded09 admitted; retain original producers and evidence, continue coherent boundary10.')
q['canonical760_actual_admission']=receipt
q['frost_analytical_boundary10']=dict(status='ORIGINAL16_ZERO_DAY_INITIALIZATIONS_PRESERVED_SOURCE_PREPARED_NOT_QUALIFIED',actual_canonical_parent=M,branch=BR,classification='B_COMPOSITION_OF_EXISTING_UNCHANGED_PROCESSES',design='FROST_ANALYTICAL_BOUNDARY10_COHERENT_EXPANDED_DESIGN_V3.json',input_contract='FROST_ANALYTICAL_BOUNDARY10_INPUT_CONTRACT_PROPOSED_V1.json',source_proposal='FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V2.json',new_qualified_contexts=0,new_admitted_contexts=0,canonical_admission=False,next_action=next_action)
q['completed'].append('PR1808 actual canonical9af88c3de6 admits bounded760 with48new analytical Frost contexts; clean actual PUBLIC/PUB,14PR45checks,4canonical workflows,4real negatives and signed original admission raw retained; next coherent free6/drainage1 batch selected.')
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n')
g=json.loads((P/'GAP_MATRIX.json').read_text())
g['frost_analytical_composition09'].update(status='BOUNDED_ANALYTICAL_FROST_D0_BOTTOM58_ACTUALLY_ADMITTED_CANONICAL760',classification='ADMITTED_BOUNDED_COMPOSITION_NOT_WHOLE_FAMILY',new_admitted_contexts=48,actual_canonical=M,merge_receipt='FROST_ANALYTICAL_COMPOSITION09_MERGE_RECEIPT_V1.json',whole_family_closed=False)
g['frost_analytical_boundary10']=dict(classification='MISSING_COMPOSITION_AND_OVERRESTRICTIVE_GUARD',status='ORIGINAL_DRAINAGE1_AND_FREE6_INITIALIZATIONS_PRESERVED_IMPLEMENTATION_REQUIRED',historical_support='Six D1 and ten D0/D1free6 actual original initializations;0modeldays. Nine free6 current refusals and one existing M1D1free6 positive preserved.',scope='D0free6 default/model1/3..11 mixed; D1SWDIVD1 non1bottom5/6/8; explicit/hys0/NoVap water/CDE Frost/Snow calendars',new_admitted_contexts=0,whole_family_closed=False)
g['migration_progress'].update(current_canonical=M,next_dependency_ordered_blocks=['Coherent free6 D0 and analytical D1SWDIVD1 bottom5/6/8 Frost water/CDE composition','Active vapor paired9 flux semantics requires scientific decision','Retained dry-surface AGE moment semantics','Genuine original SWKMEAN7 table data','Other historical family inventory remains incomplete'])
(P/'GAP_MATRIX.json').write_text(json.dumps(g,indent=2)+'\n')
git('add','--sparse','--',str(P.relative_to(R)),doc);git('commit','-m','Preserve actual canonical760 admission and coherent free6 drainage composition contract')
meta=git('rev-parse','HEAD').decode().strip()
proposal=read('FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V2.json');assert proposal['actual_before_source']==M
for file,item in proposal['files'].items():
    target=R/file;proposed=(E/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSED_V2'/target.name).read_bytes().replace(b'\r\n',b'\n')
    assert SHA(proposed)==item['proposed_lf_sha256']
    if not item.get('added'):
        old=git('show',M+':'+file).replace(b'\r\n',b'\n');assert SHA(old)==item['before_lf_sha256'] and target.read_bytes().replace(b'\r\n',b'\n')==old
        inverse=old.decode()
        for edit in reversed(item['ordered_literal_edits']):
            assert inverse[edit['base_start']:edit['base_end']]==edit['before']
            inverse=inverse[:edit['base_start']]+edit['after']+inverse[edit['base_end']:]
        assert inverse.encode()==proposed
    else:assert not target.exists()
    if target.suffix=='.py':ast.parse(proposed)
    target.write_bytes(proposed)
T=R/'tests/nomacro_drainage';shutil.copyfile(E/'frost_analytical_boundary_inputs.PROPOSED_V2.py',T/'frost_analytical_boundary_inputs.py')
runtime=(T/'frost_analytical_state_runtime.py').read_text()
old="assert selected and selected.get('analytical_frost_models') and selected['drainage']==0 and selected['implicit']==selected['hysteresis']==0"
new="assert selected and selected.get('analytical_frost_models') and selected['implicit']==selected['hysteresis']==0 and ((selected['drainage']==0 and selected['bottom']==6) or (selected['drainage']==1 and selected['bottom'] in (5,6,8)))"
assert runtime.count(old)==1;runtime=runtime.replace(old,new).replace('ACTUAL_ANALYTICAL_FROST_CALENDAR','ACTUAL_ANALYTICAL_BOUNDARY_FROST_CALENDAR')
(T/'frost_analytical_boundary_runtime.py').write_text(runtime)
q['frost_analytical_boundary10'].update(status='SOURCE_AND16_CASE_CONTRACT_INSTALLED_NOT_COMPILED_OR_SCIENTIFICALLY_QUALIFIED',metadata_commit=meta)
q['next_action']='Compile directed local O0/O2 new free6/D1 boundary cases through real public entry; run original1e-10 budgets, exact native/cold and required user output; no old model-period replay.'
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n')
git('add','--sparse','--','app/hybrid_water',str(T.relative_to(R)),str((P/'STATUS.json').relative_to(R)));git('commit','-m','Compose explicit original Frost free6 and analytical drainage1 native domains')
head=git('rev-parse','HEAD').decode().strip()
with (E/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_INSTALLED_V1.json').open('x') as out:json.dump(dict(status='ACTUAL_SOURCE_PERSISTED_NOT_COMPILED_OR_QUALIFIED',actual_source=head,metadata_commit=meta,parent=M,branch=BR,next_action=q['next_action']),out,indent=2)
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
print('PERSISTED_NEW_COHERENT_BOUNDARY10_SOURCE',head,flush=True)
