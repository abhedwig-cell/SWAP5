"""Prepare expanded genuine-M9 boundary10 source bytes without modifying R."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C='9af88c3de6198ddec40c2674dd1542a89fa9c0d7';OUT=E/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSED_V2';OUT.mkdir()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C
SHA=lambda raw:hashlib.sha256(raw).hexdigest();files={}
def original(name):return subprocess.check_output(['git','show',C+':app/hybrid_water/'+name],cwd=R).decode()
def change(text,before,after):
    assert text.count(before)==1,(before,text.count(before));return text.replace(before,after,1)
def save(name,before,after,added=False):
    if name.endswith('.py'):ast.parse(after)
    with (OUT/name).open('x',encoding='utf8',newline='\n') as out:out.write(after)
    q=dict(proposed_lf_sha256=SHA(after.encode()))
    if added:q['added']=True
    else:
        q['before_lf_sha256']=SHA(before.encode());q['ordered_literal_edits']=[dict(base_start=i,base_end=j,before=before[i:j],after=after[k:l]) for tag,i,j,k,l in difflib.SequenceMatcher(None,before,after,autojunk=False).get_opcodes() if tag!='equal']
    files['app/hybrid_water/'+name]=q
name='frost_analytical_composition.py';before=original(name);s=before
s=change(s,"NATIVE='frost_analytical_native'","NATIVE='frost_analytical_native'\nBOUNDARY_NATIVE='frost_analytical_boundary_native'\nBOUNDARY_POLICY='existing-explicit-analytical-frost-boundary568-drainage01-state-calendar-v1'\n\ndef boundary_domain(item):return item.get('drainage')==1 or item['bottom']==6\n\ndef native_provider(item):return BOUNDARY_NATIVE if boundary_domain(item) else NATIVE")
s=change(s,'def model_domain(active,values):','def model_domain(active,values,allow_model1=False):')
s=change(s,"    if len(rows)!=1 or re.fullmatch(r'[+-]?[0-9]+(?:[ \\t]+[+-]?[0-9]+)*[ \\t]*',rows[0]) is None:return None\n    models=list(map(int,rows[0].split()))", "    if not rows and allow_model1:\n        models=[1]  # Original ReadSwap default, never assigned to physical state here.\n    else:\n        if len(rows)!=1 or re.fullmatch(r'[+-]?[0-9]+(?:[ \\t]+[+-]?[0-9]+)*[ \\t]*',rows[0]) is None:return None\n        models=list(map(int,rows[0].split()))")
s=change(s,'if not models or all(x==1 for x in models) or any(', 'if not models or (all(x==1 for x in models) and not allow_model1) or any(')
s=change(s,"    from frost_undrained_state import selected as parent\n    item=parent(project)","    if not project.input_directory or not project.original_output or project.macro or project.age:return None\n    from frost_boundary_state_calendar import selection as parent\n    item=parent(project.input_directory,project.original_output)")
s=change(s,"    return b'S5UAC001' if item['kind']=='cde' else b'S5UAW001'", "    if item.get('drainage') not in (0,1):raise ValueError('Foreign analytical Frost drainage domain')\n    if boundary_domain(item):return b'S5FAC001' if item['kind']=='cde' else b'S5FAW001'\n    return b'S5UAC001' if item['kind']=='cde' else b'S5UAW001'")
s=change(s,"if item['bottom'] not in (5,8) or item['implicit']!=0 or item['hysteresis']!=0", "if item['bottom'] not in (5,6,8) or item.get('drainage') not in (0,1) or item['implicit']!=0 or item['hysteresis']!=0")
s=change(s,"Path(__file__).with_name(NATIVE+'.f90')","Path(__file__).with_name(native_provider(item)+'.f90')")
s=change(s,"expected=[2,nodes,len(models),int(item['kind']=='cde'),item['bottom'],*models]", "expected=([3,nodes,len(models),int(item['kind']=='cde'),item['bottom'],item['drainage'],int(item['drainage']==1),*models] if boundary_domain(item) else [2,nodes,len(models),int(item['kind']=='cde'),item['bottom'],*models])")
s=change(s,"return dict(policy=POLICY,models=item['analytical_frost_models'],native_header_version=2,native_header_integers=5+len(item['analytical_frost_models'])", "return dict(policy=item['policy'],models=item['analytical_frost_models'],native_header_version=3 if boundary_domain(item) else 2,native_header_integers=(7 if boundary_domain(item) else 5)+len(item['analytical_frost_models'])")
s=change(s,"for n in ['frost_analytical_composition.py',NATIVE+'.f90']", "for n in ['frost_analytical_composition.py',native_provider(item)+'.f90']")
s=change(s,"body=body.replace(anchors[0],anchors[0]+'\\n      use hybrid_frost_analytical_native,only:frost_analytical_domain_checkpoint',1)", "module='hybrid_frost_analytical_boundary_native' if boundary_domain(item) else 'hybrid_frost_analytical_native'\n    body=body.replace(anchors[0],anchors[0]+'\\n      use '+module+',only:frost_analytical_domain_checkpoint',1)")
s=change(s,"(Path(output)/(NATIVE+'.f90'))", "(Path(output)/(native_provider(item)+'.f90'))")
s=change(s,"(bundle/(NATIVE+'.f90'))", "(bundle/(native_provider(item)+'.f90'))")
save(name,before,s)
name='frost_undrained_state.py';before=original(name);s=before
s=change(s,"boundary.get('SWBOTB') in (5,8)","boundary.get('SWBOTB') in (5,6,8)\n                and (boundary.get('SWBOTB')!=6 or selectors.get('SWKIMPL')==selectors.get('SWHYST')==0)")
s=change(s,'domains.update(SWBOTB={5,8},','domains.update(SWBOTB={5,6,8},')
s=change(s,"    analytical=None\n    if models and re.fullmatch", "    analytical=None\n    if values['SWBOTB']==6:\n        from frost_analytical_composition import model_domain\n        analytical=model_domain(active,values,allow_model1=True)\n        if analytical is None:return None\n    elif models and re.fullmatch")
s=change(s,"        result.update(analytical_frost_models=analytical,policy=analytical_policy)", "        if values['SWBOTB']==6:\n            from frost_analytical_composition import BOUNDARY_POLICY\n            analytical_policy=BOUNDARY_POLICY\n        result.update(analytical_frost_models=analytical,policy=analytical_policy)")
save(name,before,s)
name='frost_boundary_state_calendar.py';before=original(name);s=before
s=change(s,"boundary.get('SWBOTB') in (5,8)","boundary.get('SWBOTB') in (5,6,8)\n                and (boundary.get('SWBOTB')!=6 or selectors.get('SWKIMPL')==selectors.get('SWHYST')==0)")
s=change(s,'domains.update(SWBOTB={5,8},','domains.update(SWBOTB={5,6,8},')
s=change(s,"if re.search(r'(?i)\\bIHWCKMODEL\\b',rest) or len(models)>1 or models and re.fullmatch(r'\\+?0*1(?:[ \\t]+\\+?0*1)*[ \\t]*',models[0]) is None:return None", "if re.search(r'(?i)\\bIHWCKMODEL\\b',rest) or len(models)>1:return None\n    analytical=None\n    if models and re.fullmatch(r'\\+?0*1(?:[ \\t]+\\+?0*1)*[ \\t]*',models[0]) is None:\n        from frost_analytical_composition import model_domain\n        analytical=model_domain(active,values)\n        if analytical is None:return None\n    if values['SWBOTB']==6 and analytical is None:return None")
s=change(s,"    return dict(boundary_state_calendar=True", "    result=dict(boundary_state_calendar=True")
s=change(s,"        requested_period=0 if monthly else values['PERIOD'],physical_equations_changed=False)", "        requested_period=0 if monthly else values['PERIOD'],physical_equations_changed=False)\n    if analytical is not None:\n        from frost_analytical_composition import BOUNDARY_POLICY\n        result.update(analytical_frost_models=analytical,policy=BOUNDARY_POLICY,drainage=1,requires_divdra=True)\n    return result")
s=change(s,"    return {('water',0):b'S5BCW001'", "    if selected.get('analytical_frost_models'):\n        from frost_analytical_composition import codec as analytical_codec\n        return analytical_codec(selected)\n    return {('water',0):b'S5BCW001'")
save(name,before,s)
name='frost_calendar_output.py';before=original(name);s=change(before,"    if boundary.get('analytical_frost_models'):providers+=['frost_analytical_composition.py','frost_analytical_native.f90']", "    if boundary.get('analytical_frost_models'):\n        from frost_analytical_composition import native_provider\n        providers+=['frost_analytical_composition.py',native_provider(boundary)+'.f90']");save(name,before,s)
name='frost_drainage_composition.py';before=original(name);s=change(before,"        result['providers']['frost_boundary_composition.py']=sha(folder/'frost_boundary_composition.py')", "        result['providers']['frost_boundary_composition.py']=sha(folder/'frost_boundary_composition.py')\n        if boundary.get('analytical_frost_models'):\n            from frost_analytical_composition import metadata as analytical_metadata\n            domain=analytical_metadata(boundary)\n            result.update(policy=boundary['policy'],analytical_frost_models=boundary['analytical_frost_models'],analytical_frost_native=domain)\n            result['providers'].update(domain['providers'])");save(name,before,s)
name='frost_implicit_plate_calendar.py';before=original(name);s=change(before,"    return bool(item and item['bottom'] in (5,8) and item['kind']=='water'\n                and (item['implicit']==1 or item.get('analytical_frost_models')))", "    return bool(item and item['kind']=='water'\n                and ((item['implicit']==1 and item['bottom'] in (5,8)) or item.get('analytical_frost_models')))");save(name,before,s)
save('frost_analytical_boundary_native.f90','',(E/'frost_analytical_boundary_native.PROPOSED_V2.f90').read_text(),True)
q=dict(status='EXPANDED_NEXT10_SEVEN_ACTUAL_PROPOSED_SOURCE_FILES_WITH_LITERAL_INVERSES_PREPARED_NOT_INSTALLED_OR_QUALIFIED',actual_before_source=C,files=files,native_codecs=['S5FAW001','S5FAC001'],scope='Original free6 SWDRA0 including default model1; original analytical non1 SWDRA1/SWDIVD1 bottom5/6/8. Explicit/hys0/NoVap/initial1,2/water,CDE/calendars. Keep old09 undrained bottom5,8 and existing model1 drainage1 free6 owners literal.',new_physical_equations=False,new_physical_state=False,physical_or_date_or_counter_assignment_added=False,model_or_compiler_executions=0,canonical_admission=False,precondition='Do not install until both actualM9observations pass. New genuine10branch must start at actualM9. Preserve09 through actual generated/whole-object postimages, not old scientific period replay; all new integration/cold/native/transaction qualification remains required.')
with (E/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_PROPOSAL_V2.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],len(files),flush=True)
