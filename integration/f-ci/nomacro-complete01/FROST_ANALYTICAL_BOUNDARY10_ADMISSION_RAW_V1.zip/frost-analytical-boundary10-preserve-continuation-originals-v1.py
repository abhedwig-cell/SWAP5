"""Preserve all remaining-case originals, including every refused trajectory."""
from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).resolve().parent;P=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01');SHA=lambda b:hashlib.sha256(b).hexdigest()
for platform,opt,identifier in [('UBUNTU','O0',15097562368),('UBUNTU','O2',15097124439),('WINDOWS','O0',15098345145),('WINDOWS','O2',15097323929)]:
    stem='FROST_ANALYTICAL_BOUNDARY10_CONTINUATION_OFFICIAL_ARTIFACT_'+str(identifier);official=json.loads((E/(stem+'.json')).read_text());archive=E/(stem+'.zip');raw=archive.read_bytes()
    assert len(raw)==official['artifact']['size_in_bytes']==official['bytes'] and SHA(raw)==official['sha256'] and 'sha256:'+SHA(raw)==official['artifact']['digest']
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist())==len(set(z.namelist()));members={n:dict(bytes=len(value),sha256=SHA(value)) for n in z.namelist() for value in [z.read(n)]}
        q=json.loads(z.read('current/RESULT.json'));assert q['source']=='9d53d55a0ae5aa7567ee62bfcbc60fece1629905' and q['status']=='FAILED_ANALYTICAL_FROST_PORTABLE_NOT_QUALIFIED'
        assert q['selected_case_indices']==list(range(8,16)) and len(q['contexts'])==len(q['refusals'])==4
        assert [x['index'] for x in q['refusals']]==[8,10,12,15]
        refused=[]
        for item in q['refusals']:
            rows=[json.loads(x) for x in z.read('current/'+item['case']['name']+'/science/trajectory/daily.jsonl').splitlines()]
            assert all(row['committed'] for row in rows[:-1]) and not rows[-1]['committed'] and abs(rows[-1]['independent_residual_cm'])>1e-10
            refused.append(dict(case=item['case'],index=item['index'],actual_refused_receipt=rows[-1],prior_accepted_days=len(rows)-1))
    name='FROST_ANALYTICAL_BOUNDARY10_CONTINUATION_'+platform+'_'+opt+'_ORIGINAL_V1';parts=[]
    for index,offset in enumerate(range(0,len(raw),25*1024**2),1):
        value=raw[offset:offset+25*1024**2];file=name+f'.zip.part{index:03d}'
        with (P/file).open('xb') as out:out.write(value)
        parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
    record=dict(status='FOUR_REMAINING_CONTEXTS_PASS_AND_FOUR_TRUE_WATER_REFUSALS_PRESERVED_NO_FALSE_FULL_BATCH_ADMISSION',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,official_artifact=official['artifact'],actual_source=q['source'],platform=platform,optimization=opt,selected_case_indices=q['selected_case_indices'],successful_contexts=[x['case'] for x in q['contexts']],refused_contexts=refused,new_admitted_contexts=0,zip_bytes_modified=False,canonical_admission=False)
    for root in [E,P]:
        with (root/(name+'.json')).open('x') as out:json.dump(record,out,indent=2);out.write('\n')
    print(name,len(raw),record['sha256'],len(members),flush=True)