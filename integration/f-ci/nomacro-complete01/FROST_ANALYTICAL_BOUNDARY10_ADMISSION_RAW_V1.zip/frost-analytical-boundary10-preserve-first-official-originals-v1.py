"""Seal exact four official ZIPs, including original numerical refusals."""
from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
SHA=lambda b:hashlib.sha256(b).hexdigest()
for platform,opt,identifier in [('UBUNTU','O0',15096214110),('UBUNTU','O2',15095989747),('WINDOWS','O0',15096831231),('WINDOWS','O2',15096433474)]:
    stem='FROST_ANALYTICAL_BOUNDARY10_FIRST_OFFICIAL_ARTIFACT_'+str(identifier);official=json.loads((E/(stem+'.json')).read_text());archive=E/(stem+'.zip');raw=archive.read_bytes()
    assert len(raw)==official['artifact']['size_in_bytes']==official['bytes'] and SHA(raw)==official['sha256'] and 'sha256:'+SHA(raw)==official['artifact']['digest']
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist())==len(set(z.namelist()));members={n:dict(bytes=len(value),sha256=SHA(value)) for n in z.namelist() for value in [z.read(n)]}
        q=json.loads(z.read('current/RESULT.json'));assert len(q['contexts'])==7 and q['source']=='b4ffcc914453225562ffe0e847faa21a765432ce' and q['status']=='FAILED_ANALYTICAL_FROST_PORTABLE_NOT_QUALIFIED'
        old=json.loads(z.read('current-inherited-postimages/RESULT.json'));assert len(old['contexts'])==4 and sum(len(c['objects']) for c in old['contexts'])==100
        rows=[json.loads(x) for x in z.read('current/model8-water-d0-b6-periodic/science/trajectory/daily.jsonl').splitlines()]
        assert len(rows)==33 and all(x['committed'] for x in rows[:32]) and not rows[-1]['committed'] and abs(rows[-1]['independent_residual_cm'])>1e-10
        rejection=rows[-1]
    name='FROST_ANALYTICAL_BOUNDARY10_FIRST_'+platform+'_'+opt+'_ORIGINAL_V1';parts=[]
    for index,offset in enumerate(range(0,len(raw),25*1024**2),1):
        value=raw[offset:offset+25*1024**2];file=name+f'.zip.part{index:03d}'
        with (P/file).open('xb') as out:out.write(value)
        parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
    record=dict(status='ORIGINAL_FIRST7_CONTEXTS_AND4_OLD09_POSTIMAGES_PASS_THEN_MODEL8_DAY33_WATER_REFUSAL_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,official_artifact=official['artifact'],actual_source=q['source'],platform=platform,optimization=opt,successful_primary_contexts=7,unchanged_old09_postimages=4,unchanged_whole_objects=100,first_refused_case_index=7,refused_day=33,prior_accepted_days_of_failed_case=32,actual_refused_receipt=rejection,new_admitted_contexts=0,scientific_producer_rebound=False,zip_bytes_modified=False,canonical_admission=False)
    for root in [E,P]:
        with (root/(name+'.json')).open('x') as out:json.dump(record,out,indent=2);out.write('\n')
    print(name,len(raw),record['sha256'],len(members),flush=True)