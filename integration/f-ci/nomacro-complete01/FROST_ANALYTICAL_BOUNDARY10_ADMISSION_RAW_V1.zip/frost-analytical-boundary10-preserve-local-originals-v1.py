"""Preserve six actual local contexts, original failures and whole builds once."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
H='b4ffcc914453225562ffe0e847faa21a765432ce';OLD='07e3851392ac641ba8a55f41f85dfc8212b91c79';AUDIT='628104dfbfdce0a374484b8721bb95b4530c6aa9'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==H and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
assert not git('diff',OLD,H,'--','app','src','tools','reference')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
files={};projection={};contexts=[];required={}
def add(root,prefix):
    assert root.is_dir()
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path
add(W/'frost-analytical-boundary10-local-science-v1','original07')
add(W/'b10ctl-v2','corrected628')
add(W/'b10post-v1','unchanged09-postimages628')
add(W/'b10c3-v1','active-drainage-b4')
for opt in ['O0','O2']:
    for root,prefix in [(W/('frost-analytical-boundary10-local-'+opt+'-v1'),'compiled-original07/'+opt),(W/('b10post-'+opt+'-v1'),'compiled-postimages628/'+opt),(W/('b10c3-'+opt+'-v1'),'compiled-active-b4/'+opt)]:
        add(root,prefix)
        for path in root.rglob('BUILD.json'):projection[str(path.parent)]=dict(archive_prefix=prefix+'/'+path.parent.relative_to(root).as_posix(),actual_BUILD_sha256=SHA(path.read_bytes()))
    q=json.loads((E/('FROST_ANALYTICAL_BOUNDARY10_DIRECTED_'+opt+'_READONLY_AUDIT_AND_CONTROLS_V2.json')).read_text());assert q['actual_controller_source']==AUDIT and len(q['contexts'])==2
    for item in q['contexts']:assert item['status'].endswith('PASS_NO_PERIOD_REPLAY') and item['actual_scientific_source']==OLD and len(item['native_samples'])==7
    q=json.loads((W/'b10c3-v1'/opt/'RESULT.json').read_text())
    assert q['actual_source']==H and q['status']=='ACTUAL_PUBLIC_ANALYTICAL_BOUNDARY_FROST_SCIENCE_NATIVE_AND_TRANSACTIONS_PASS_NOT_ADMITTED' and q['actual_drainage_outward_cm']>0
    assert len(q['science']['own'])==3 and len(q['science']['native_samples'])==7
    contexts.append(dict(optimization=opt,source=H,case=q['case'],actual_positive_drainage_cm=q['actual_drainage_outward_cm'],prefix='active-drainage-b4/'+opt))
with ExitStack() as stack:
    sdk=Archive(GitArchiveSource(R,'087fc67db3e1e58d45215522eb284e89cb6c12f1'),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
    for path in files.values():
        if path.name!='BUILD.json':continue
        meta=json.loads(path.read_text());identity=meta['identity'];assert identity['compiler_sha256']=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
        for key,subdir in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
            for n,digest in identity[key].items():
                member='original-provider-build/'+subdir+'/'+n;raw=sdk.get(member);assert SHA(raw)==digest and raw==(J/'build'/subdir/n).read_bytes();required[member]=dict(bytes=len(raw),sha256=digest)
        member='original-provider-build/ttutil-obj/libttutil.a';raw=sdk.get(member);assert SHA(raw)==identity['ttutil_library'] and raw==(J/'build/ttutil-obj/libttutil.a').read_bytes();required[member]=dict(bytes=len(raw),sha256=SHA(raw))
    for n in ['timecontrol.f90','divdra.f90']:
        member='original-provider-build/swap-selected/'+n;raw=sdk.get(member);assert raw==(J/'build/swap-selected'/n).read_bytes();required[member]=dict(bytes=len(raw),sha256=SHA(raw))
    dependency=dict(archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',actual_data_revision='087fc67db3e1e58d45215522eb284e89cb6c12f1',sha256=sdk.record['sha256'],actual_required_files=required)
add(E/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_B4_CAPTURE_V1','actual-source-b4')
for suffix in ['tar','json']:
    n='FROST_ANALYTICAL_BOUNDARY10_CONTROLLER_B4_CAPTURE_V1.'+suffix;files['actual-controller-b4/'+n]=E/n
snapshots={}
for sha,paths in [(OLD,['app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','tests/nomacro_mixtures','tests/saltfarm_newton','reference/swap-4.3.1']),(AUDIT,['tests/nomacro_drainage','tests/nomacro_scheduled_subsurface'])]:
    path=E/('FROST_ANALYTICAL_BOUNDARY10_GENUINE_GIT_SOURCE_'+sha+'.zip');assert not path.exists()
    subprocess.run(['git','archive','--format=zip','--output='+str(path),sha,'--',*paths],cwd=R,check=True)
    files['immutable-git-source/'+path.name]=path;snapshots[sha]=dict(file=path.name,sha256=SHA(path.read_bytes()),domain='IMMUTABLE_GIT_SOURCE_AT_REAL_COMMIT_NOT_HISTORIC_WORKING_BYTE_CAPTURE',paths=paths)
for path in E.iterdir():
    if path.is_file() and (path.name.startswith('frost-analytical-boundary10-') and path.suffix=='.py' or path.name.startswith('FROST_ANALYTICAL_BOUNDARY10_') and path.suffix=='.json'):
        files['controllers-and-records/'+path.name]=path
for name,value in [('COMPILED_PROJECTION_V1.json',projection),('LOCAL_PROVIDER_DEPENDENCY_V1.json',dependency),('GENUINE_GIT_SOURCE_SNAPSHOTS_V1.json',snapshots)]:
    file=E/('FROST_ANALYTICAL_BOUNDARY10_LOCAL_V1_'+name)
    with file.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
    files[name]=file
name='FROST_ANALYTICAL_BOUNDARY10_LOCAL_WINDOWS_O0_O2_RAW_V1';archive=E/(name+'.zip');members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for label,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(label,raw);members[label]=dict(bytes=len(raw),sha256=SHA(raw))
    for sha in [OLD,AUDIT,H]:
        raw=git('cat-file','commit',sha);member='genuine-commit/'+sha+'.bin';z.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(members)
    for n,item in members.items():raw=z.read(n);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=archive.read_bytes();parts=[]
for i,offset in enumerate(range(0,len(raw),25*1024**2),1):
    value=raw[offset:offset+25*1024**2];file=name+'.zip' if len(raw)<=25*1024**2 else name+f'.zip.part{i:03d}'
    with (P/file).open('xb') as out:out.write(value)
    parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
record=dict(status='SIX_ACTUAL_LOCAL_CONTEXTS_ORIGINAL_FAILURES_NATIVE_COLD_TRANSACTIONS_AND54_OLD09_OBJECTS_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_scientific_sources=[OLD,H],actual_corrected_original_controller=AUDIT,actual_current_preservation_source=H,source_identities_rebound=False,original_provider_dependency=dependency,primary_days=210,native_samples=42,exact_cold_windows=18,compiled_native_refusals=454,transactions=10,old09_whole_objects=54,old_model_period_replays=0,active_drainage_contexts=contexts,new_admitted_contexts=0,canonical_admission=False)
for root in [E,P]:
    with (root/(name+'.json')).open('x') as out:json.dump(record,out,indent=2);out.write('\n')
print(record['status'],len(raw),record['sha256'],len(members),flush=True)
