"""Preserve actual B24 local science, unbuffered refusal211 and current45 postimages."""
from pathlib import Path
from contextlib import ExitStack
import json,subprocess,sys,zipfile
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
HEAD='45bb6146f5800f4050e95feb5d1912ddfdd23d4d';SCI='b24cebc3993b0f350c7aef7fb773a177d00425ce';NEG='211faea04c2c2dd172ecbbb619e81bfce241fe68';OLD='b4ffcc914453225562ffe0e847faa21a765432ce'
G=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
assert G('rev-parse','HEAD').decode().strip()==HEAD and not G('diff',SCI,HEAD,'--','app','src','tools','reference') and not G('diff',OLD,NEG,'--','app','src','tools','reference')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
files={};projection={};contexts=[];provider={}
def add(root,prefix):
    assert root.is_dir()
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path
for label,prefix in [('b10s-v1','model8-search-local'),('b10edge-v1','year-and-drainage-search-local'),('b10pond-v1','original-unbuffered-211-refusal'),('b10old09-v2','current-old09-whole-postimages')]:add(W/label,prefix)
roots=[('b10pond-O0-v1','compiled-negative211/O0')]
for opt in ['O0','O2']:roots.extend([('b10s-'+opt+'-v1','compiled-search-model8/'+opt),('b10edge-'+opt+'-v1','compiled-search-endpoints/'+opt),('b10old09-'+opt+'-v2','compiled-current-old09/'+opt)])
for label,prefix in roots:
    root=W/label;add(root,prefix)
    for path in root.rglob('BUILD.json'):projection[str(path.parent)]=dict(archive_prefix=prefix+'/'+path.parent.relative_to(root).as_posix(),actual_BUILD_sha256=SHA(path.read_bytes()))
for opt in ['O0','O2']:
    for root,prefix in [(W/'b10s-v1'/opt,'model8-search-local/'+opt),(W/'b10edge-v1'/(opt+'-c10'),'year-and-drainage-search-local/'+opt+'-c10'),(W/'b10edge-v1'/(opt+'-c8'),'year-and-drainage-search-local/'+opt+'-c8')]:
        q=json.loads((root/'RESULT.json').read_text());assert q['actual_source']==SCI and q['status']=='ACTUAL_PUBLIC_ANALYTICAL_BOUNDARY_FROST_SCIENCE_NATIVE_AND_TRANSACTIONS_PASS_NOT_ADMITTED'
        assert q['original_convergence']['unconverged_continuations']==0 and len(q['controls']['analytical_boundary_refusals'])==18
        contexts.append(dict(case=q['case'],optimization=opt,actual_source=SCI,archive_prefix=prefix,primary_days=q['case']['days'],native_samples=len(q['science']['native_samples']),exact_cold_windows=len(q['science']['own']),compiled_refusals=18,transactions=1+int(q['case']['active_frost_transactions']),original_budgets=q['science']['independent_original_budgets']))
    q=json.loads((E/('FROST_ANALYTICAL_BOUNDARY10_UNCHANGED_09_MODEL7_'+opt+'_POSTIMAGE_V3.json')).read_text());assert q['actual_current_source']==HEAD and q['model_executions']==0 and len(q['whole_objects'])==27
negative=json.loads((W/'b10pond-v1/case7/RESULT.json').read_text());assert negative['actual_source']==NEG and negative['status'].startswith('FAILED_')
warning=(W/'b10pond-v1/case7/science/trajectory/original/swap.wrn').read_bytes();assert warning.count(b'No convergence was reached')==4
with ExitStack() as stack:
    sdk=Archive(GitArchiveSource(R,'087fc67db3e1e58d45215522eb284e89cb6c12f1'),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
    for path in files.values():
        if path.name!='BUILD.json':continue
        identity=json.loads(path.read_text())['identity'];assert identity['compiler_sha256']=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
        for key,subdir in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
            for n,digest in identity[key].items():
                member='original-provider-build/'+subdir+'/'+n;raw=sdk.get(member);assert SHA(raw)==digest and raw==(J/'build'/subdir/n).read_bytes();provider[member]=dict(bytes=len(raw),sha256=digest)
        member='original-provider-build/ttutil-obj/libttutil.a';raw=sdk.get(member);assert SHA(raw)==identity['ttutil_library'] and raw==(J/'build/ttutil-obj/libttutil.a').read_bytes();provider[member]=dict(bytes=len(raw),sha256=SHA(raw))
    for n in ['timecontrol.f90','divdra.f90']:
        member='original-provider-build/swap-selected/'+n;raw=sdk.get(member);assert raw==(J/'build/swap-selected'/n).read_bytes();provider[member]=dict(bytes=len(raw),sha256=SHA(raw))
    dependency=dict(archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',actual_data_revision='087fc67db3e1e58d45215522eb284e89cb6c12f1',sha256=sdk.record['sha256'],actual_required_files=provider)
add(E/'FROST_ANALYTICAL_BOUNDARY10_SOURCE_B24_CAPTURE_V2','actual-source-B24')
for suffix in ['tar','json']:
    n='FROST_ANALYTICAL_BOUNDARY10_CONTROLLER_B24_CAPTURE_V2.'+suffix;files['actual-controller-B24/'+n]=E/n
for path in E.iterdir():
    if path.is_file() and (path.name.startswith('frost-analytical-boundary10-') and path.suffix=='.py' or path.name.startswith('FROST_ANALYTICAL_BOUNDARY10_') and path.suffix=='.json' and not path.name.startswith('FROST_ANALYTICAL_BOUNDARY10_LOCAL_WINDOWS_O0_O2_RAW_')):
        files['controllers-and-records/'+path.name]=path
for name,value in [('COMPILED_PROJECTION_V1.json',projection),('LOCAL_PROVIDER_DEPENDENCY_V1.json',dependency)]:
    file=E/('FROST_ANALYTICAL_BOUNDARY10_LOCAL_V2_'+name)
    with file.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
    files[name]=file
name='FROST_ANALYTICAL_BOUNDARY10_LOCAL_WINDOWS_O0_O2_RAW_V2';archive=E/(name+'.zip');members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for label,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(label,raw);members[label]=dict(bytes=len(raw),sha256=SHA(raw))
    for sha in [SCI,HEAD,NEG]:
        raw=G('cat-file','commit',sha);label='genuine-commit/'+sha+'.bin';z.writestr(label,raw);members[label]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(members)
    for label,item in members.items():raw=z.read(label);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=archive.read_bytes();parts=[]
for i,offset in enumerate(range(0,len(raw),25*1024**2),1):
    value=raw[offset:offset+25*1024**2];file=name+'.zip' if len(raw)<=25*1024**2 else name+f'.zip.part{i:03d}'
    with (P/file).open('xb') as out:out.write(value)
    parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
record=dict(status='SIX_REAL_B24_SEARCH_CONTEXTS_164DAYS_36NATIVE_16COLD_108REFUSALS_8TRANSACTIONS_AND54_CURRENT_OLD09_OBJECTS_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_scientific_source=SCI,actual_current_old09_postimage_source=HEAD,actual_unbuffered_causal_refusal_source=NEG,original_negative_physical_source_identity_equal_to_B4=True,source_identities_rebound=False,source_capsule_actual_head=SCI,contexts=contexts,original_provider_dependency=dependency,primary_days=164,native_samples=36,exact_cold_windows=16,compiled_refusals=108,transactions=8,unchanged_old09_whole_objects=54,negative_original_convergence_warnings=4,old_unchanged_model_periods_replayed=0,new_admitted_contexts=0,canonical_admission=False)
for root in [E,P]:
    with (root/(name+'.json')).open('x') as out:json.dump(record,out,indent=2);out.write('\n')
print(record['status'],len(raw),record['sha256'],len(members),flush=True)