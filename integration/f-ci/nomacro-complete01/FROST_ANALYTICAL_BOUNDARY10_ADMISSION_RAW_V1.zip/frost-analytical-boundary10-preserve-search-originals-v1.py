from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).resolve().parent;P=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01');SHA=lambda b:hashlib.sha256(b).hexdigest()
for platform,opt,identifier in [('UBUNTU','O0',15098784403),('UBUNTU','O2',15100561380),('WINDOWS','O0',15100386253),('WINDOWS','O2',15099744153)]:
    stem='FROST_ANALYTICAL_BOUNDARY10_SEARCH_OFFICIAL_ARTIFACT_'+str(identifier);official=json.loads((E/(stem+'.json')).read_text());archive=E/(stem+'.zip');raw=archive.read_bytes()
    assert len(raw)==official['artifact']['size_in_bytes']==official['bytes'] and SHA(raw)==official['sha256'] and 'sha256:'+SHA(raw)==official['artifact']['digest']
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist())==len(set(z.namelist()));members={n:dict(bytes=len(value),sha256=SHA(value)) for n in z.namelist() for value in [z.read(n)]}
        q=json.loads(z.read('current/RESULT.json'));post=json.loads(z.read('current-unaffected-postimages/RESULT.json'))
        assert q['source']=='45bb6146f5800f4050e95feb5d1912ddfdd23d4d' and len(q['contexts'])==8 and not q['refusals']
        assert q['selected_case_indices']==[3,5,7,8,10,12,14,15]
        assert post['actual_source']==q['source'] and len(post['contexts'])==8 and post['model_executions']==0
    name='FROST_ANALYTICAL_BOUNDARY10_SEARCH_'+platform+'_'+opt+'_ORIGINAL_V1';parts=[]
    for index,offset in enumerate(range(0,len(raw),25*1024**2),1):
        value=raw[offset:offset+25*1024**2];file=name+f'.zip.part{index:03d}'
        with (P/file).open('xb') as out:out.write(value)
        parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
    record=dict(status='OFFICIAL_EIGHT_CHANGED_PERIODS_AND_EIGHT_UNAFFECTED_WHOLE_OBJECT_POSTIMAGES_PRESERVED_PENDING_INDEPENDENT_AUDIT',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,official_artifact=official['artifact'],actual_source=q['source'],platform=platform,optimization=opt,selected_case_indices=q['selected_case_indices'],successful_contexts=[x['case'] for x in q['contexts']],new_admitted_contexts=0,zip_bytes_modified=False,canonical_admission=False)
    for root in [E,P]:
        with (root/(name+'.json')).open('x') as out:json.dump(record,out,indent=2);out.write('\n')
    print(name,len(raw),record['sha256'],len(members),q['status'],flush=True)
