"""Read actual saved source07 trajectories; compiled controls, no period replay."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;W=E.parent;J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
C='07e3851392ac641ba8a55f41f85dfc8212b91c79';H='628104dfbfdce0a374484b8721bb95b4530c6aa9'
p=argparse.ArgumentParser();p.add_argument('--opt',choices=['O0','O2'],required=True);a=p.parse_args()
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_analytical_boundary_runtime import snapshots,m,budgets
from frost_analytical_boundary_native_controls import native
from frost_analytical_calendar_native import native as calendar_native
from frost_analytical_boundary_extra_native import extra
from frost_undrained_state_controls import transaction,active_frost_start
from frost_boundary_convergence import require_convergence
git=lambda *args:subprocess.check_output(['git',*args],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==H and not git('diff',C,H,'--','app','src','tools','reference')
results=[]
for name,full_legacy in [('default-model1-water-d0-b6-dense',True),('model7-cde-d1-b8-dense',False)]:
    D=W/'frost-analytical-boundary10-local-science-v1'/(a.opt+'-'+name);profile=D/'science';buildrec=json.loads((D/'BUILD_RESULT.json').read_text());original=json.loads((profile/'RESULT.json').read_text())
    assert buildrec['actual_source']==original['source']==C and original['duration_days']==35 and len(original['own'])==3
    before={str(p.relative_to(profile)):hashlib.sha256(p.read_bytes()).hexdigest() for p in profile.rglob('*') if p.is_file()}
    project=m.e.load(buildrec['input_root'],original_output=True,time_step_policy='original-adaptive-event-closure-v1');build=Path(buildrec['build_root']);meta,_=m.validate_bundle(build,J,project)
    data=m.rows(profile/'trajectory');assert len(data)==35
    samples=snapshots(profile/'trajectory',meta,data,original['selection'],{2,4,19,23,30,34,35})
    out=W/'b10ctl-v2'/(a.opt+('-w' if full_legacy else '-c'));out.mkdir()
    q=dict(status='RUNNING_READONLY_AUDIT_AND_ACTUAL_COMPILED_CONTROLS',actual_controller_source=H,actual_scientific_source=C,original_science_path=str(profile),original_science_status=original['status'],original_failed_observer_preserved=original['status'].startswith('FAILED'),native_samples=samples,budgets=budgets(profile/'trajectory',original['kind'],35),convergence=require_convergence(profile),model_period_replay=0,accepted_mutant_model_days=0,actual_BUILD_sha256=hashlib.sha256((build/'BUILD.json').read_bytes()).hexdigest())
    save=lambda:(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n');save()
    try:
        if full_legacy:
            prior=json.loads((D/'corrected-readonly-native-controls-v1/RESULT.json').read_text())
            assert prior['actual_controller_source']==H and prior['actual_scientific_source']==C and len(prior['boundary_refusals'])==18 and len(prior['calendar_thermal_refusals'])==39 and 'WinError 3' in prior['error']
            q['boundary_refusals']=prior['boundary_refusals'];q['calendar_thermal_refusals']=prior['calendar_thermal_refusals'];q['original_control_observation_reused_from']=str(D/'corrected-readonly-native-controls-v1/RESULT.json');save()
        else:
            q['boundary_refusals']=native(build,J,project,profile/'trajectory',out/'boundary-native');save();assert len(q['boundary_refusals'])==18
        if full_legacy:
            q['snow_private_refusals']=extra(m,build,J,project,profile/'trajectory',out/'snow-private-native');save();assert len(q['snow_private_refusals'])==43
        else:q['legacy_native_selection']='NOT_SELECTED_IMPACT_UNCHANGED_REPRESENTATIVE_CDE_D1BOTTOM6_WILL_OWN_FULL_SUITE'
        q['snow_transaction']=transaction(build,J,project,profile/'trajectory',data,out/'snow-transaction',2,True);save()
        q['actual_active_frost_start']=active_frost_start(profile/'trajectory/accepted-column-1-day-19.zip',project);save()
        q['active_frost_transaction']=transaction(build,J,project,profile/'trajectory',data,out/'active-frost-transaction',19,False);save()
        after={str(p.relative_to(profile)):hashlib.sha256(p.read_bytes()).hexdigest() for p in profile.rglob('*') if p.is_file()};assert before==after
        q.update(status='ACTUAL_SAVED_ORIGINAL35DAYS_7NATIVE_3EXACT_COLD_COMPILED_DOMAIN_AND_SNOW_FROST_TRANSACTIONS_PASS_NO_PERIOD_REPLAY',unchanged_original_science_files=before,canonical_admission=False)
        assert git('rev-parse','HEAD').decode().strip()==H
    except Exception as exc:q.update(status='FAILED_READONLY_AUDIT_OR_ACTUAL_COMPILED_CONTROL_NOT_QUALIFIED',error=repr(exc));raise
    finally:save()
    results.append(q);print(q['status'],a.opt,name,flush=True)
with (E/('FROST_ANALYTICAL_BOUNDARY10_DIRECTED_'+a.opt+'_READONLY_AUDIT_AND_CONTROLS_V2.json')).open('x') as output:json.dump(dict(status='TWO_ORIGINAL_DIRECTED_CONTEXTS_READONLY_AND_COMPILED_CONTROLS_PASS',actual_controller_source=H,contexts=results,model_period_replays=0,canonical_admission=False),output,indent=2)
