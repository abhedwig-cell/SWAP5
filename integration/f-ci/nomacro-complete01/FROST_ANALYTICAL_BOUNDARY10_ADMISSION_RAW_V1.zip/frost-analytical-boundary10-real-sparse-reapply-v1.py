from pathlib import Path
import hashlib,json,shutil,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent
G=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
def state():
    sparse=Path(G('rev-parse','--git-path','info/sparse-checkout').decode().strip());sparse=sparse if sparse.is_absolute() else R/sparse
    return dict(head=G('rev-parse','HEAD').decode().strip(),tree=G('rev-parse','HEAD^{tree}').decode().strip(),status=G('status','--porcelain=v1','--untracked-files=all','--ignored').decode(),sparse=sparse.read_text().splitlines(),original_projects={p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()})
before=state();assert before['head']=='211faea04c2c2dd172ecbbb619e81bfce241fe68' and not before['status'] and len(before['sparse'])==14 and len(before['original_projects'])==56
paths={p.relative_to(R).as_posix():p.stat().st_size for p in (R/'integration/f-ci/nomacro-complete01').glob('FROST_ANALYTICAL_BOUNDARY10_*.zip.part*')};free=shutil.disk_usage(R).free
G('sparse-checkout','reapply');after=state();assert before==after
removed={p:n for p,n in paths.items() if not (R/p).exists()}
q=dict(status='GENUINE_SPARSE_REAPPLY_SAME_HEAD_TREE14_RULES56_FIXTURES_CLEAN_TRACKED_COPIES_ONLY',before=before,after=after,removed_materialized_clean_tracked_archive_parts=removed,logical_removed_bytes=sum(removed.values()),actual_net_free_bytes=shutil.disk_usage(R).free-free,Git_evidence_blobs_preserved=True,original_E_archives_untouched=True,source_identity_projection=False)
with (E/'FROST_ANALYTICAL_BOUNDARY10_REAL_SPARSE_REAPPLY_V1.json').open('x') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],len(removed),sum(removed.values()),q['actual_net_free_bytes'],flush=True)