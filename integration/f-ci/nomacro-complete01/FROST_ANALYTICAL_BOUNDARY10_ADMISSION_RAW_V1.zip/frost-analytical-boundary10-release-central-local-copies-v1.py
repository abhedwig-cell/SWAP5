"""Release own reproducible directories after every central byte is freshly checked."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');CLEAN=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='b24cebc3993b0f350c7aef7fb773a177d00425ce'
resources=[('frost-analytical-boundary10-local-science-v1','original07'),('b10ctl-v2','corrected628'),('b10post-v1','unchanged09-postimages628'),('b10c3-v1','active-drainage-b4')]
for opt in ['O0','O2']:
    resources.extend([('frost-analytical-boundary10-local-'+opt+'-v1','compiled-original07/'+opt),('b10post-'+opt+'-v1','compiled-postimages628/'+opt),('b10c3-'+opt+'-v1','compiled-active-b4/'+opt)])
checked=[]
with ExitStack() as stack:
    store=Archive(GitArchiveSource(R,head),'FROST_ANALYTICAL_BOUNDARY10_LOCAL_WINDOWS_O0_O2_RAW_V1',stack);assert store.record['sha256']=='41e041226a26aa6552e46ea24ea2678234d7eb25fa8c41ab400e287720a0c043'
    for label,prefix in resources:
        root=(W/label).resolve();assert root.is_relative_to(W.resolve()) and not root.is_symlink()
        expected={n[len(prefix)+1:]:item for n,item in store.record['members'].items() if n.startswith(prefix+'/')}
        actual={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()};assert expected and set(expected)==set(actual)
        for name,path in actual.items():
            raw=path.read_bytes();item=expected[name];assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and raw==store.get(prefix+'/'+name)
        checked.append(dict(path=str(root),archive_prefix=prefix,files=len(actual),bytes=sum(x['bytes'] for x in expected.values()),central_archive_sha256=store.record['sha256']))
with (E/'FROST_ANALYTICAL_BOUNDARY10_LOCAL_RESOURCE_CENTRAL_CUSTODY_V1.json').open('x') as out:json.dump(dict(actual_current_source=head,owned_resources=checked,total_bytes=sum(x['bytes'] for x in checked),unique_originals_E_and_shared_SDK_J_untouched=True),out,indent=2);out.write('\n')
for item in checked:
    result=subprocess.run([sys.executable,'-B',str(CLEAN),'release','--task',TASK,'--path',item['path']],cwd=CLEAN.parents[2],capture_output=True,text=True);assert result.returncode==0,(item,result.stdout,result.stderr)
for mode,args in [('PREVIEW',[]),('APPLY',['--apply'])]:
    q=subprocess.run([sys.executable,'-B',str(CLEAN),'cleanup','--task',TASK,*args],cwd=CLEAN.parents[2],capture_output=True,text=True)
    with (E/('FROST_ANALYTICAL_BOUNDARY10_OWN_RELEASED_CLEANUP_'+mode+'_V1.json')).open('x') as out:out.write(q.stdout)
    with (E/('FROST_ANALYTICAL_BOUNDARY10_OWN_RELEASED_CLEANUP_'+mode+'_V1.stderr')).open('x') as out:out.write(q.stderr)
    assert q.returncode in (0,3),(q.returncode,q.stderr)
    if mode=='APPLY':
        report=json.loads(q.stdout);print('OWN_CENTRALLY_VERIFIED_RELEASED_RESOURCE_CLEANUP',len(checked),'deleted',sum(x['status']=='deleted' for x in report['results']),'net_free_bytes',report['net_free_change'],'blocked',report['blocked_count'],flush=True)