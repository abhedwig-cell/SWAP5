"""Release own reproducible directories after every central byte is freshly checked."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');CLEAN=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='e9092e4e4e' or head.startswith('e9092e4e4e')
resources=[('b10pond-v1','original-unbuffered-211-refusal'),('b10s-v1','model8-search-local'),('b10edge-v1','year-and-drainage-search-local'),('b10old09-v2','current-old09-whole-postimages')]
resources.append(('b10pond-O0-v1','compiled-negative211/O0'))
for opt in ['O0','O2']:
    resources.extend([('b10s-'+opt+'-v1','compiled-search-model8/'+opt),('b10edge-'+opt+'-v1','compiled-search-endpoints/'+opt),('b10old09-'+opt+'-v2','compiled-current-old09/'+opt)])
checked=[]
with ExitStack() as stack:
    store=Archive(GitArchiveSource(R,head),'FROST_ANALYTICAL_BOUNDARY10_LOCAL_WINDOWS_O0_O2_RAW_V2',stack);assert store.record['sha256']=='175e4ddef38778bb60001b1449cf0fcb23ae343852206e06d9a7f98538346d13'
    for label,prefix in resources:
        root=(W/label).resolve();assert root.is_relative_to(W.resolve()) and not root.is_symlink()
        expected={n[len(prefix)+1:]:item for n,item in store.record['members'].items() if n.startswith(prefix+'/')}
        actual={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()};assert expected and set(expected)==set(actual)
        for name,path in actual.items():
            raw=path.read_bytes();item=expected[name];assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and raw==store.get(prefix+'/'+name)
        checked.append(dict(path=str(root),archive_prefix=prefix,files=len(actual),bytes=sum(x['bytes'] for x in expected.values()),central_archive_sha256=store.record['sha256']))
with (E/'FROST_ANALYTICAL_BOUNDARY10_LOCAL_RESOURCE_CENTRAL_CUSTODY_V2.json').open('x') as out:json.dump(dict(actual_current_source=head,owned_resources=checked,total_bytes=sum(x['bytes'] for x in checked),unique_originals_E_and_shared_SDK_J_untouched=True),out,indent=2);out.write('\n')
for item in checked:
    result=subprocess.run([sys.executable,'-B',str(CLEAN),'release','--task',TASK,'--path',item['path']],cwd=CLEAN.parents[2],capture_output=True,text=True);assert result.returncode==0,(item,result.stdout,result.stderr)
for mode,args in [('PREVIEW',[]),('APPLY',['--apply'])]:
    q=subprocess.run([sys.executable,'-B',str(CLEAN),'cleanup','--task',TASK,*args],cwd=CLEAN.parents[2],capture_output=True,text=True)
    with (E/('FROST_ANALYTICAL_BOUNDARY10_OWN_RELEASED_CLEANUP_'+mode+'_V2.json')).open('x') as out:out.write(q.stdout)
    with (E/('FROST_ANALYTICAL_BOUNDARY10_OWN_RELEASED_CLEANUP_'+mode+'_V2.stderr')).open('x') as out:out.write(q.stderr)
    assert q.returncode in (0,3),(q.returncode,q.stderr)
    if mode=='APPLY':
        report=json.loads(q.stdout);print('OWN_CENTRALLY_VERIFIED_RELEASED_RESOURCE_CLEANUP',len(checked),'deleted',sum(x['status']=='deleted' for x in report['results']),'net_free_bytes',report['net_free_change'],'blocked',report['blocked_count'],flush=True)