"""Continue only original unexecuted cases8..15, preserve every refusal."""
from pathlib import Path
import ast,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).resolve().parent;T=R/'tests/nomacro_drainage'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
H='e184c906a86f59253a5d98d777cf5bd0d46be33d';B4='b4ffcc914453225562ffe0e847faa21a765432ce'
assert git('rev-parse','HEAD').decode().strip()==H and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
path=T/'frost_analytical_boundary_portable.py';text=path.read_text()
text=text.replace("    a=p.parse_args();","    p.add_argument('--first-case',type=int,default=0);p.add_argument('--last-case',type=int,default=16);p.add_argument('--continue-after-refusal',action='store_true')\n    a=p.parse_args();")
text=text.replace("contexts=[],canonical_admission=False)","contexts=[],refusals=[],selected_case_indices=list(range(a.first_case,a.last_case)),canonical_admission=False)")
anchor="        for index,case in enumerate(contract['representative_cases']):";assert anchor in text
text=text.replace(anchor,"        assert 0<=a.first_case<a.last_case<=len(contract['representative_cases'])\n"+anchor+"\n            if index not in range(a.first_case,a.last_case):continue")
old="            result.check_returncode();item=json.loads((folder/'RESULT.json').read_text())";assert old in text
text=text.replace(old,"            if result.returncode:\n                q['refusals'].append(dict(case=case,index=index,returncode=result.returncode,actual_result=str(folder/'RESULT.json'),controller_stdout=str(a.output/(case['name']+'.controller.stdout')),controller_stderr=str(a.output/(case['name']+'.controller.stderr'))));save()\n                if a.continue_after_refusal:continue\n                result.check_returncode()\n            item=json.loads((folder/'RESULT.json').read_text())")
text=text.replace("assert source()[0]==head and len(q['contexts'])==16","assert source()[0]==head and len(q['contexts'])+len(q['refusals'])==a.last_case-a.first_case\n        assert not q['refusals'],'Original selected cases refused; all raw results retained'")
text=text.replace("q['status']='SIXTEEN_ACTUAL_ANALYTICAL_BOUNDARY_FROST_PORTABLE_PERIODS_NATIVE_COLD_AND_TRANSACTIONS_PASS_NOT_ADMITTED'","q['status']=('SIXTEEN_ACTUAL_ANALYTICAL_BOUNDARY_FROST_PORTABLE_PERIODS_NATIVE_COLD_AND_TRANSACTIONS_PASS_NOT_ADMITTED' if (a.first_case,a.last_case)==(0,16) else 'SELECTED_EIGHT_ACTUAL_ANALYTICAL_BOUNDARY_FROST_CONTINUATION_PERIODS_NATIVE_COLD_AND_TRANSACTIONS_PASS_NOT_ADMITTED')")
ast.parse(text);path.write_text(text)
for platform in ['ubuntu','windows']:
    path=R/('.github/workflows/nomacro-frost-analytical-boundary10-'+platform+'.yml');text=path.read_text()
    lines=[line for line in text.splitlines() if 'tests/nomacro_drainage/frost_analytical_boundary_inherited_postimages.py' not in line]
    text='\n'.join(lines)+'\n';selected=[line for line in text.splitlines() if 'frost_analytical_boundary_portable.py' in line];assert len(selected)==1
    text=text.replace(selected[0],selected[0]+' --first-case 8 --last-case 16 --continue-after-refusal')
    python='python3' if platform=='ubuntu' else 'python';needle="          "+python+" -B tests/nomacro_drainage/frost_analytical_boundary_portable.py"
    check="          "+python+" -B -c "+'"'+"import subprocess; assert not subprocess.check_output(['git','diff','"+B4+"','HEAD','--','app','src','tools','reference'])"+'"'+"\n"
    assert needle in text;text=text.replace(needle,check+needle);path.write_text(text)
label=dict(status='ORIGINAL_BOTTOM6_SEMANTICS_VERIFIED_LABEL_CORRECTION_ONLY',actual_original_source=B4,original_declaration='SWBOTB6: Bottom flux equals zero; SWBOTB7: Free drainage of soil profile',prior_free6_label_incorrect=True,physical_inputs_or_selectors_changed=False,scientific_results_rebound=False,correct_current_label='zero-flux lower boundary6',original_immutable_labels_retained=True)
(P/'FROST_ANALYTICAL_BOUNDARY10_BOTTOM6_LABEL_CORRECTION_V1.json').write_text(json.dumps(label,indent=2)+'\n')
path=R/'docs/science/NOMACRO_FROST_ANALYTICAL_BOUNDARY10.md';text=path.read_text().replace('free6','zero-flux bottom6').replace('free-bottom6','zero-flux bottom6')
text+='\nThe exact original declaration identifies SWBOTB6 as zero bottom flux, while7 is free drainage. Earlier proposed free6 labels were incorrect; all original decks and actual numeric selectors remain unchanged and original labels remain in their immutable evidence. First sourceb4 completed7cases/profile and4old09 postimages/profile before model8D0bottom6 failed the strict independent water day33 receipt on all4profiles: actual1.7118e-7 versus integrated guard9.22e-11. This is an unresolved numerical failure, not an admitted context or a proven legacy defect. Every original artifact is preserved. The continuation runs only previously unexecuted cases8..15 on an exact unchanged app/src/tools/reference surface; it records every refusal and continues through the selected cohort without fabricating PASS.\n';path.write_text(text)
q=json.loads((P/'STATUS.json').read_text());q['frost_analytical_boundary10'].update(status='ORIGINAL_MODEL8_ZERO_FLUX6_DAY33_NUMERICAL_FAILURE_PRESERVED_REMAINING8_CASES_SELECTED',bottom6_semantics='ZERO_BOTTOM_FLUX_NOT_FREE_DRAINAGE',first_portable_source=B4,first_portable_runs=[45776274657,45776274830],continuation_case_indices=list(range(8,16)),first28_successful_periods_replayed=False)
q['next_action']='Push actual continuation source; follow two new workflows through all8 remaining cases/profile while preserving all first28 successful contexts and400whole old09 objects. Independently audit original phase1 and continuation. Diagnose model8zero-flux6 day33 exact pond disappearance without state/tolerance/flux repair.'
(P/'STATUS.json').write_text(json.dumps(q,indent=2)+'\n')
git('add','--sparse','--',str(P.relative_to(R)),str(path.relative_to(R)),str((T/'frost_analytical_boundary_portable.py').relative_to(R)),'.github/workflows/nomacro-frost-analytical-boundary10-ubuntu.yml','.github/workflows/nomacro-frost-analytical-boundary10-windows.yml')
git('commit','-m','Continue remaining eight boundary cases and retain model8 strict water refusal')
print('ACTUAL_CONTINUATION_SOURCE',git('rev-parse','HEAD').decode().strip(),flush=True)
