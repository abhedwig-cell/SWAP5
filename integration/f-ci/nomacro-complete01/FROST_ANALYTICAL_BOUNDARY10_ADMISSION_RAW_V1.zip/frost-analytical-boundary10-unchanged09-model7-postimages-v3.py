"""Recompile actual model7 source postimages after input-only grammar narrowing."""
from pathlib import Path
from contextlib import ExitStack
import argparse,json,os,subprocess,sys,time
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=['O0','O2'],required=True);a=p.parse_args();opt=a.optimization
C='45bb6146f5800f4050e95feb5d1912ddfdd23d4d';OLD='dd7596685c91074789ab56e9a3ecb3d4a4ef4b4c';name='model7-7-cde-b8-p1';D=W/'b10old09-v2'/'corrected-policy-v3'/(opt+'-model7-current-postimage');D.mkdir(parents=True);inputs=D/'inputs';build=W/('b10old09-'+opt+'-v2')/name/'bundle'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
from explicit_bottom9_archive_science import ReadView
git=lambda *x:subprocess.check_output(['git',*x],cwd=R).decode().strip();assert git('rev-parse','HEAD')==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
env=dict(os.environ,OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
q=dict(status='RUNNING_ACTUAL_MODEL7_POSTIMAGE_NO_PERIOD_REPLAY',actual_current_source=C,original_scientific_source=OLD,optimization=opt,model_executions=0,object_normalization=False)
save=lambda:(D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');save()
try:
    with ExitStack() as stack:
        old=Archive(GitArchiveSource(R,C),'FROST_ANALYTICAL_COMPOSITION09_LOCAL_WINDOWS_O0_O2_RAW_V1',stack);assert old.record['sha256']=='7cb587035b9194fcf5d550931a455781c4f6cfebeb0c884cf7bebc206967bfc5'
        prefix='current/'+opt+'-'+name;report=json.loads(old.get(prefix+'/science/RESULT.json'));assert report['source']==report['actual_controller_source']==OLD and report['duration_days']==35
        projection=json.loads(old.get('COMPILED_PROJECTION_V1.json'));parent=ReadView(old,projection[report['build_root']]['archive_prefix']);before=json.loads((parent/'BUILD.json').read_text());inputs.mkdir()
        for path in ReadView(old,prefix+'/inputs').rglob('*'):
            if path.is_file():
                target=inputs/path.relative_to(ReadView(old,prefix+'/inputs'));target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes())
        command=[sys.executable,'-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy','original-adaptive-event-closure-v1','--reference-work',str(J),'--build-only','--donor-opt',opt,'--kernel-opt',opt,'--output',str(build)]
        started=time.perf_counter()
        with (D/'actual-build.stdout').open('xb') as out,(D/'actual-build.stderr').open('xb') as err:result=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=300)
        q['actual_build']=dict(command=command,returncode=result.returncode,seconds=time.perf_counter()-started,root=str(build));save();result.check_returncode()
        meta=json.loads((build/'BUILD.json').read_text());q['actual_BUILD_sha256']=SHA((build/'BUILD.json').read_bytes());q['original_BUILD_sha256']=SHA((parent/'BUILD.json').read_bytes());q['original_archive_sha256']=old.record['sha256']
        for key in ['compiler','compiler_sha256','target','donor_flags','kernel_flags','donor_generated','donor_objects','donor_modules','ttutil_modules','ttutil_library']:
            assert meta['identity'][key]==before['identity'][key],('Actual unchanged model7 source/SDK/flags',key)
        assert meta['inputs']==before['inputs']
        for n,digest in meta['identity']['donor_generated'].items():assert (build/n).read_bytes()==(parent/n).read_bytes() and SHA((build/n).read_bytes())==digest
        objects={p.name for p in build.glob('*.o')};assert objects=={p.name for p in parent.glob('*.o')} and objects
        q['whole_objects']=[]
        for n in sorted(objects):
            raw=(build/n).read_bytes();assert raw==(parent/n).read_bytes(),('Actual model7 whole-object differs',n);q['whole_objects'].append(dict(file=n,bytes=len(raw),sha256=SHA(raw)))
        q.update(status='CURRENT_ACTUAL_MODEL7_COMPLETE_GENERATED_SOURCES_SAME_COMPILER_AND_WHOLE_OBJECTS_PASS_NO_PERIOD_REPLAY',actual_compiler=meta['identity']['compiler'],actual_compiler_sha256=meta['identity']['compiler_sha256'],original_primary_days_inherited=35,original_native_samples_inherited=7,original_exact_cold_windows_inherited=3)
    assert git('rev-parse','HEAD')==C
except Exception as exc:q.update(status='FAILED_ACTUAL_MODEL7_POSTIMAGE_NOT_QUALIFIED',error=repr(exc));raise
finally:save()
with (E/('FROST_ANALYTICAL_BOUNDARY10_UNCHANGED_09_MODEL7_'+opt+'_POSTIMAGE_V3.json')).open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],opt,len(q['whole_objects']),flush=True)
