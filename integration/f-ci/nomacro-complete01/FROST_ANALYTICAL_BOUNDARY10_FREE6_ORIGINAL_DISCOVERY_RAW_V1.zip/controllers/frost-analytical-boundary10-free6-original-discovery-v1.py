"""Original free-bottom6 Frost reachability for the coherent next boundary batch."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=W/'frost-analytical-boundary10-original-free6-discovery-v1';C='084a3b5d194fecc9f0aa606e46c51b34a7f0662f';SHA=lambda raw:hashlib.sha256(raw).hexdigest()
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_analytical_inputs import prepare
from original_output_baseline import assignment
from experimental_project import load
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C and not any(D.iterdir())
probes={0:W/'frost-undrained-state08-initialization-probe-O0-v1/corrected-module-import-v2/original_initialization_probe.exe',1:W/'frost-analytical-drainage10-original-init-O0-v1/original_drainage_initialization_probe.exe'}
assert SHA(probes[0].read_bytes())=='dee4a94a5e0e92d07c9aee2a4790fc5178f159f7e81ad316fcaa58b6a6f28b5e'
q=dict(status='RUNNING_ORIGINAL_FREE6_FROST_DISCOVERY_ZERO_MODEL_DAYS',actual_observer=C,contexts=[],probe_executable_sha256={str(k):SHA(v.read_bytes()) for k,v in probes.items()},compiler_executions=0,model_days=0,scientific_qualification=False)
env=dict(os.environ,OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
for drainage in [0,1]:
    for models,kind in [([1,1],'water'),([3,3],'water'),([7,7],'cde'),([11],'water'),([7,3],'cde')]:
        name='d'+str(drainage)+'-model'+'-'.join(map(str,models))+'-'+kind+'-b6';folder=D/name;folder.mkdir();inputs=folder/'inputs'
        case=dict(name=name,models=models,kind=kind,bottom=5,initial=1,calendar='dense',reset=1,start=None,days=35,implicit=0,hysteresis=0,drainage=0)
        prepare(case,inputs);path=inputs/'swap.swp';text=assignment(path.read_text(encoding='cp1252'),'SWBOTB',6);text=assignment(text,'SWDRA',drainage);path.write_text(text,encoding='cp1252');case.update(bottom=6,drainage=drainage)
        public=dict(actual_source=C,entry='experimental_project.load',model_days=0)
        try:project=load(inputs,original_output=True,time_step_policy='original-adaptive-event-closure-v1');public.update(status='PUBLIC_READER_ACCEPTED_NOT_SCIENTIFICALLY_QUALIFIED',model=project.model)
        except ValueError as error:public.update(status='ACTUAL_CURRENT_PUBLIC_READER_REFUSED',error=repr(error))
        with (folder/'original-init.stdout').open('xb') as stdout,(folder/'original-init.stderr').open('xb') as stderr:result=subprocess.run([str(probes[drainage])],cwd=inputs,env=env,stdout=stdout,stderr=stderr,timeout=45)
        raw=(folder/'original-init.stdout').read_bytes();phases=[x for x in raw.decode('cp1252',errors='replace').splitlines() if x.startswith('ORIGINAL_INIT_PHASE ')]
        good=result.returncode==0 and 'ORIGINAL_INIT_PHASE AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS' in phases
        q['contexts'].append(dict(case=case,public_reader=public,original_returncode=result.returncode,original_initialized=good,original_phases=phases,input_file_sha256={p.relative_to(inputs).as_posix():SHA(p.read_bytes()) for p in inputs.rglob('*') if p.is_file()},original_stdout_sha256=SHA(raw),original_stderr_sha256=SHA((folder/'original-init.stderr').read_bytes()),model_days=0))
        (D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n');print('ORIGINAL_FREE6_FROST_INITIALIZATION',name,good,public['status'],flush=True)
q.update(status='TEN_ORIGINAL_FREE6_FROST_INITIALIZATION_AND_PUBLIC_OBSERVATIONS_PRESERVED_ZERO_DAYS_NOT_QUALIFIED',all_original_initialized=all(x['original_initialized'] for x in q['contexts']),public_refusals=sum(x['public_reader']['status']=='ACTUAL_CURRENT_PUBLIC_READER_REFUSED' for x in q['contexts']))
(D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
with (E/'FROST_ANALYTICAL_BOUNDARY10_FREE6_ORIGINAL_DISCOVERY_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],q['all_original_initialized'],q['public_refusals'],flush=True)
