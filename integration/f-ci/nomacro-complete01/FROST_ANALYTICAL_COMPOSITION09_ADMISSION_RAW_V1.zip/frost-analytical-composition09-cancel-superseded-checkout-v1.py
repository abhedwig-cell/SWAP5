"""Cancel only the verified superseded own FCI run still in initial checkout."""
from pathlib import Path
import base64,json,os,subprocess,urllib.request
E=Path(__file__).resolve().parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
old='38196200968a7f640ab2b5b06861691f09f922d5';current='084a3b5d194fecc9f0aa606e46c51b34a7f0662f'
env=dict(os.environ,GIT_TERMINAL_PROMPT='0')
raw=subprocess.check_output(['git','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',cwd=R,env=env)
credential=dict(line.split('=',1) for line in raw.decode().splitlines() if '=' in line)
headers={'Authorization':'Basic '+base64.b64encode((credential['username']+':'+credential['password']).encode()).decode(),'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-evidence-custody'}
def api(path,method='GET'):
    assert path.startswith('/repos/abhedwig-cell/SWAP5/actions/')
    req=urllib.request.Request('https://api.github.com'+path,headers=headers,method=method)
    with urllib.request.urlopen(req,timeout=45) as response:
        data=response.read();return response.status,json.loads(data) if data else None
path='/repos/abhedwig-cell/SWAP5/actions/runs/45763767156'
_,run=api(path);_,jobs=api(path+'/jobs?per_page=100');_,successor=api('/repos/abhedwig-cell/SWAP5/actions/runs/45765004759')
assert run['head_sha']==old and successor['head_sha']==current and run['head_branch']==successor['head_branch']=='codex/nomacro-frost-analytical-composition09'
assert run['status']!='completed' and jobs['jobs']
for job in jobs['jobs']:
    assert job['name']=='selection-preflight'
    for step in job.get('steps',[]):
        if step['status'] in ['completed','in_progress']:assert step['name'] in ['Set up job','Run actions/checkout@v4']
q=dict(status='VERIFIED_SUPERSEDED_OWN_FCI_CHECKOUT_ONLY_CANCEL_REQUEST',actual_old_source=old,actual_successor_source=current,original_run=run,original_jobs=jobs,actual_successor_run=successor,scientific_model_steps_started=False,reason='Superseded read-only archive metadata type-dispatch admission candidate. Cancel only observed selection-preflight initial checkout; current final admission run stays active.')
with (E/'FROST_ANALYTICAL_COMPOSITION09_SUPERSEDED_FCI_CANCEL_REQUEST_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
code,body=api(path+'/cancel','POST');assert code==202
with (E/'FROST_ANALYTICAL_COMPOSITION09_SUPERSEDED_FCI_CANCEL_RESPONSE_V1.json').open('x',encoding='utf8') as out:json.dump(dict(status=code,response=body,actual_run=run['id'],actual_old_source=old,current_run_preserved=successor['id']),out,indent=2);out.write('\n')
print('SUPERSEDED_OWN_FCI_CHECKOUT_CANCEL_REQUEST_ACCEPTED_CURRENT_RUN_PRESERVED',flush=True)
