"""Install bounded original analytical Frost composition with complete text inverses."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';APP=R/'app/hybrid_water'
BASE='f3faeaa540e7fd81686802414d53ff6686f3ce7b';BEFORE='e5a0c50460de8f7839d6accf76161bb79afaa1fc'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==BEFORE and not git('diff',BASE,'HEAD','--','app','src','tools','reference')
files={name:(APP/name).read_text() for name in ['frost_undrained_state.py','frost_calendar_output.py','model7_capacity.py','daily_coupling.py']}
def edit(name,before,after):
    assert files[name].count(before)==1,(name,before,files[name].count(before));files[name]=files[name].replace(before,after,1)
old="    if re.search(r'(?i)\\bIHWCKMODEL\\b',rest) or len(models)>1 or models and re.fullmatch(r'\\+?0*1(?:[ \\t]+\\+?0*1)*[ \\t]*',models[0]) is None:return None\n"
new="    if re.search(r'(?i)\\bIHWCKMODEL\\b',rest) or len(models)>1:return None\n    analytical=None\n    if models and re.fullmatch(r'\\+?0*1(?:[ \\t]+\\+?0*1)*[ \\t]*',models[0]) is None:\n        from frost_analytical_composition import model_domain\n        analytical=model_domain(active,values)\n        if analytical is None:return None\n"
edit('frost_undrained_state.py',old,new)
edit('frost_undrained_state.py','    return dict(undrained_frost=True,boundary_state_calendar=True,frost_calendar=True,','    result=dict(undrained_frost=True,boundary_state_calendar=True,frost_calendar=True,')
edit('frost_undrained_state.py','                physical_equations_changed=False,requires_divdra=False)\n','                physical_equations_changed=False,requires_divdra=False)\n    if analytical is not None:\n        from frost_analytical_composition import POLICY as analytical_policy\n        result.update(analytical_frost_models=analytical,policy=analytical_policy)\n    return result\n')
edit('frost_undrained_state.py',"    return {('water',0):b'S5UDW001'", "    if item.get('analytical_frost_models'):\n        from frost_analytical_composition import codec as analytical_codec\n        return analytical_codec(item)\n    return {('water',0):b'S5UDW001'")
edit('frost_undrained_state.py',"    if item['implicit']:\n        from implicit_frost_root_state import metadata as root_metadata", "    if item.get('analytical_frost_models'):\n        from frost_analytical_composition import metadata as analytical_metadata\n        domain=analytical_metadata(item)\n        result.update(policy=item['policy'],analytical_frost_models=item['analytical_frost_models'],analytical_frost_native=domain)\n        result['providers'].update(domain['providers'])\n    if item['implicit']:\n        from implicit_frost_root_state import metadata as root_metadata")
edit('frost_undrained_state.py','    implicit_validate(bundle,project)\n','    implicit_validate(bundle,project)\n    from frost_analytical_composition import validate as analytical_validate\n    analytical_validate(bundle,project)\n')
edit('frost_calendar_output.py','    return dict(thermal_output=True,thermal_calendar=True,frost_calendar=True,',"    return dict(**({'analytical_frost_models':selected['analytical_frost_models']} if selected.get('analytical_frost_models') else {}),thermal_output=True,thermal_calendar=True,frost_calendar=True,")
edit('frost_calendar_output.py',"    if boundary.get('undrained_frost'):providers+=['frost_undrained_state.py','frost_undrained_terminal_water.py']", "    if boundary.get('undrained_frost'):providers+=['frost_undrained_state.py','frost_undrained_terminal_water.py']\n    if boundary.get('analytical_frost_models'):providers+=['frost_analytical_composition.py','frost_analytical_native.f90']")
edit('frost_calendar_output.py','    return text\n\n\ndef apply_build', '    from frost_analytical_composition import render_macro as analytical_macro\n    return analytical_macro(text,project)\n\n\ndef apply_build')
anchor="    path=output/'macropore.f90';path.write_text(render_macro(path.read_text(encoding='cp1252'),project),encoding='cp1252')"
edit('frost_calendar_output.py',anchor,anchor+"\n    from frost_analytical_composition import write_provider as analytical_provider\n    analytical_provider(output,project)")
edit('model7_capacity.py','def analytical_models(project):\n','def analytical_models(project):\n    from frost_analytical_composition import selected as analytical_frost\n    composed=analytical_frost(project)\n    if composed is not None:return tuple(composed[\'analytical_frost_models\'])\n')
anchor='            checked = h.verify_checkpoint(candidate, self._day+1, host.binding, ready)\n'
edit('daily_coupling.py',anchor,anchor+"            if (self.meta['identity'].get('frost_drainage_composition') or {}).get('analytical_frost_models'):\n                from frost_analytical_composition import validate_candidate as validate_analytical_frost\n                validate_analytical_frost((ready/'macro.bin').read_bytes(),self.project)\n")
anchor="        # Verify the bytes actually being published, not only the retained ZIP.\n"
edit('daily_coupling.py',anchor,anchor+"        if (self.meta['identity'].get('frost_drainage_composition') or {}).get('analytical_frost_models'):\n            from frost_analytical_composition import validate_candidate as validate_analytical_frost\n            validate_analytical_frost((ready/'macro.bin').read_bytes(),self.project)\n")
for name,text in files.items():ast.parse(text);(APP/name).write_text(text,encoding='utf8')
for name in ['frost_analytical_composition.py','frost_analytical_native.f90']:files[name]=(APP/name).read_text()
contracts={}
for name,text in files.items():
    path='app/hybrid_water/'+name;raw=text.encode();prior=subprocess.run(['git','show',BASE+':'+path],cwd=R,capture_output=True)
    if prior.returncode:
        assert name in ['frost_analytical_composition.py','frost_analytical_native.f90'];contracts[path]=dict(added=True,proposed_lf_sha256=hashlib.sha256(raw).hexdigest());continue
    before=prior.stdout.decode();literal=[]
    for tag,i,j,k,l in difflib.SequenceMatcher(None,before,text,autojunk=False).get_opcodes():
        if tag!='equal':literal.append(dict(base_start=i,base_end=j,before=before[i:j],after=text[k:l]))
    contracts[path]=dict(before_lf_sha256=hashlib.sha256(prior.stdout).hexdigest(),proposed_lf_sha256=hashlib.sha256(raw).hexdigest(),ordered_literal_edits=literal)
q=dict(status='IMPLEMENTED_PERSISTENCE_AND_FIRST_PUBLIC_QUALIFICATION_PENDING',actual_canonical_parent=BASE,actual_metadata_source=BEFORE,classification='B_COMPOSITION_OF_EXISTING_UNCHANGED_PROCESSES',files=contracts,physical_implementations='UNCHANGED_ORIGINAL_ANALYTICAL_AND_QUALIFIED_MODEL7_CAPACITY_FROST_BOUNDARY_CALENDAR_CDE',native_header_version=2,native_header='version,nodes,layers,solute,bottom,effective_per_layer_models; duplicated',native_codecs=['S5UAW001','S5UAC001'],no_active_vapor=True,no_implicit_or_hysteresis=True,new_physical_state=False,physical_equations_changed=False,mass_or_convergence_limits_changed=False,canonical_admission=False,new_qualified_contexts=0)
(P/'FROST_ANALYTICAL_COMPOSITION09_SOURCE_PROPOSAL_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
# The runtime remains the same real public worker/budget/cold algorithm; add only
# its independent typed analytical header check and truthful new status label.
old=(R/'tests/nomacro_drainage/frost_undrained_state_runtime.py').read_text();text=old.replace('from frost_history_state_central import original_history','from frost_history_state_central import original_history\nfrom frost_analytical_composition import native_domain')
needle="            raw=z.read('macro.bin');assert raw[:8]==expected_magic";assert text.count(needle)==1;text=text.replace(needle,needle+'\n            native_domain(raw,selected,nodes)',1)
needle="assert selected and selected.get('undrained_frost') and selected['drainage']==0";assert text.count(needle)==1;text=text.replace(needle,"assert selected and selected.get('analytical_frost_models') and selected['drainage']==0 and selected['implicit']==selected['hysteresis']==0",1)
text=text.replace('ACTUAL_UNDRAINED_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED','ACTUAL_ANALYTICAL_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_MODEL_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED').replace('RUNNING_ACTUAL_UNDRAINED_FROST_CALENDAR_NOT_QUALIFIED','RUNNING_ACTUAL_ANALYTICAL_FROST_CALENDAR_NOT_QUALIFIED').replace('FAILED_ACTUAL_UNDRAINED_FROST_CALENDAR_NOT_QUALIFIED','FAILED_ACTUAL_ANALYTICAL_FROST_CALENDAR_NOT_QUALIFIED')
ast.parse(text);(R/'tests/nomacro_drainage/frost_analytical_state_runtime.py').write_text(text,encoding='utf8')
status=json.loads((P/'STATUS.json').read_text());status['last_commit']=BEFORE;status['frost_analytical_composition09'].update(status='BOUNDED_SOURCE_AND_TYPED_NATIVE_IMPLEMENTED_FIRST_PUBLIC_O0_O2_QUALIFICATION_PENDING',source_contract='FROST_ANALYTICAL_COMPOSITION09_SOURCE_PROPOSAL_V1.json',native_codecs=q['native_codecs'],native_header_version=2,first_runtime='tests/nomacro_drainage/frost_analytical_state_runtime.py');status['next_action']='Capture actual committed09 producer source; first real O0/O2 public model7 CDE bottom8 Frost35 and model3 water bottom5/year scopes, unchanged1e-10 conservation/native/cold; preserve every original failure; do not claim admission from implementation.'
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8')
gap=json.loads((P/'GAP_MATRIX.json').read_text());gap['frost_analytical_composition09']['implementation']='BOUNDED_SOURCE_AND_TYPED_NATIVE_INSTALLED_PENDING_FIRST_PUBLIC_BUILD_AND_RUNTIME';gap['next_coherent_batches']=[{**item,'priority':i+1} for i,item in enumerate(gap['next_coherent_batches'])];(P/'GAP_MATRIX.json').write_text(json.dumps(gap,indent=2)+'\n',encoding='utf8')
paths=['app/hybrid_water/'+name for name in files]+['tests/nomacro_drainage/frost_analytical_state_runtime.py']+[str((P/name).relative_to(R)) for name in ['FROST_ANALYTICAL_COMPOSITION09_SOURCE_PROPOSAL_V1.json','STATUS.json','GAP_MATRIX.json']]
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--sparse','--']+paths,cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Compose original explicit analytical Frost with typed per-layer native state'],cwd=R,check=True)
head=git('rev-parse','HEAD').decode().strip()
with (E/'FROST_ANALYTICAL_COMPOSITION09_IMPLEMENTED_SOURCE_V1.json').open('x',encoding='utf8') as out:json.dump(dict(actual_source=head,actual_canonical_parent=BASE,source_contract=q,scientific_qualification=False,canonical_admission=False),out,indent=2);out.write('\n')
print('PERSISTED_BOUNDED_ANALYTICAL_FROST_TYPED_SOURCE_NOT_YET_TESTED',head,flush=True)
