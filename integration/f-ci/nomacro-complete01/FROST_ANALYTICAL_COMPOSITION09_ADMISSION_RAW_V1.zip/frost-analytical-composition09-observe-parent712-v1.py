from pathlib import Path
import json,subprocess,sys,time
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_analytical_parent_admission import parent_admission
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();q=dict(actual_observer=head,status='RUNNING_ORIGINAL_CANONICAL712_ADMISSION_AUDIT',compiler_executions=0,model_executions=0);start=time.perf_counter()
try:q['audit']=parent_admission();q['status']=q['audit']['status']
except Exception as error:q.update(status='FAILED_ORIGINAL_CANONICAL712_ADMISSION_AUDIT',error=repr(error));raise
finally:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
    q['seconds']=time.perf_counter()-start
    with (E/'FROST_ANALYTICAL_COMPOSITION09_PARENT712_INDEPENDENT_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],q['seconds'],flush=True)
