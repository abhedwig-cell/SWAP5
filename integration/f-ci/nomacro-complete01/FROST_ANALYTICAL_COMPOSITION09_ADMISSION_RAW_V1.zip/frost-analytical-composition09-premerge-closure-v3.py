"""Final actual candidate checks with parent selection read from accepted archive."""
from pathlib import Path
from contextlib import ExitStack
import json,hashlib,subprocess,sys
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive
from frost_boundary_git_archive import GitArchiveSource
C='084a3b5d194fecc9f0aa606e46c51b34a7f0662f';M='f3faeaa540e7fd81686802414d53ff6686f3ce7b';git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
with ExitStack() as stack:
    archive=Archive(GitArchiveSource(R,C),'FROST_UNDRAINED_STATE08_ADMISSION_RAW_V1',stack);assert archive.record['sha256']=='6974226ed874b4751ec7ee4f0403cf50a5fbfa2b638147c940963af25500d786'
    old=json.loads(archive.get('FROST_UNDRAINED_STATE08_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json'))
paths=old['unchanged_dependency_paths'];assert not git('diff',M,C,'--',*paths);rows=git('ls-tree','-rl',C,'--',*paths);assert len(rows.splitlines())==1063
q=dict(old,actual_parent=M,actual_candidate=C,actual_git_ls_tree_sha256=hashlib.sha256(rows).hexdigest(),original_selection='FROST_UNDRAINED_STATE08_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json',actual_observer_head=C)
assert q['actual_git_ls_tree_sha256']==old['actual_git_ls_tree_sha256'] and q['current_model_replay']=='NOT_SELECTED_IMPACT' and not q['fresh_current_MCSOL_scientific_PASS_claimed']
with (E/'FROST_ANALYTICAL_COMPOSITION09_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
ci=json.loads((E/'FROST_ANALYTICAL_COMPOSITION09_PR1808_FINAL_ALL_CI_API_V2.json').read_text());runs=ci['runs']['workflow_runs'];checks=ci['checks']['check_runs'];assert len(runs)==len({x['workflow_id'] for x in runs})==14 and all(x['head_sha']==C and x['status']=='completed' and x['conclusion']=='success' for x in runs);assert len(checks)==45 and all(x['head_sha']==C and x['status']=='completed' and x['conclusion'] in ['success','skipped'] for x in checks);assert sum(x['conclusion']=='success' for x in checks)==28
for mode in ['PUBLIC','PUBLICATION']:
    name='FROST_ANALYTICAL_COMPOSITION09_CANDIDATE_'+mode+'_V2';q=json.loads((E/(name+'.json')).read_text());assert q['returncode']==0 and q['error'] is None and q['before']==q['after'] and q['before']['head']==C and not q['before']['status'] and len(q['before']['sparse'])==14 and len(q['before']['original_project_files'])==56 and not (E/(name+'.stderr.txt')).read_bytes()
negative=json.loads((E/'FROST_ANALYTICAL_COMPOSITION09_FINAL1_NEGATIVES_V1.json').read_text());assert negative['candidate']==C and len(negative['controls'])==4 and all(x['actual_refusal'] for x in negative['controls'])
for item in negative['controls']:assert git('show','-s','--format=%P',item['head']).decode().split()==[C] and git('diff','--name-only',C,item['head']).decode().splitlines()==[item['path']]
for role in ['CO2','DVS','LRV','FCI_MODULAR','TIMEINT_STARTUP','TIMEINT_INVERSE']:
    label='FROST_ANALYTICAL_COMPOSITION09_PR1808_'+role+'_ORIGINAL_CI_V2.log';raw=(E/label).read_bytes();q=json.loads((E/(label+'.json')).read_text());assert q['actual_source']==C and len(raw)==q['bytes'] and hashlib.sha256(raw).hexdigest()==q['sha256'] and C.encode() in raw and q['actual_checkout'].encode() in raw
S='18f55ac859e3d447eb26f632dd3624ddd5efcb76';assert git('show','-s','--format=%P',S).decode().split()==[M,C];tree=git('rev-parse',C+'^{tree}').decode().strip();assert git('rev-parse',S+'^{tree}').decode().strip()==tree
q=dict(status='ACTUAL_CURRENT_CANDIDATE760_ALL_SCIENCE_PUBLIC_PUB_FOUR_REAL_NEGATIVES14CI45CHECKS_AND_SIGNED_SYNTHETIC_TREE_VERIFIED',actual_candidate=C,actual_parent=M,actual_signed_synthetic=S,qualified_whole_tree=tree,source_anchor='7f8ee2a8131bcaab54a486fc546c519c244faa74',candidate_public_seconds=921.7033974998631,candidate_publication_seconds=698.4070360995829,model_or_compiler_executions=0,canonical_admission=False)
with (E/'FROST_ANALYTICAL_COMPOSITION09_PREMERGE_CLOSURE_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'])
