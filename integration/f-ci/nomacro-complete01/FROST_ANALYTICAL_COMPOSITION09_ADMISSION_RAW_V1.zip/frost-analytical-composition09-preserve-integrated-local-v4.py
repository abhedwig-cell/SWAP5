"""Preserve actual BC4 valid year warm/native/exact cold observations without replay."""
from pathlib import Path
from contextlib import ExitStack
import json,subprocess,sys,zipfile
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');C='23dd30d6a2bbf062a8b6a23ea2089399526db6a4'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
from frost_analytical_composition import native_domain
files={};projection={};provider={};contexts=[]
def add(root,prefix):
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path
D=W;add(W/'frost-analytical-composition09-twelve-original-readers-v1','original-reader-zero-days')
with ExitStack() as stack:
    sdk=Archive(GitArchiveSource(R,'087fc67db3e1e58d45215522eb284e89cb6c12f1'),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
    for opt in ['O0','O2']:
        root=W/('frost-analytical-composition09-local-'+opt+'-v4');add(root,'compiled/'+opt)
        D=W/('frost-analytical-composition09-local-science-'+opt+'-v4');add(D,'current/'+opt)
        for kind in ['case-0','case-9']:
            folder=D/kind;q=json.loads((folder/'RESULT.json').read_text())
            assert q['actual_source']==C and q['status']=='ACTUAL_PUBLIC_ANALYTICAL_FROST_SCIENCE_NATIVE_AND_TRANSACTIONS_PASS_NOT_ADMITTED'
            build=Path(q['build_root']);science=q['science'];controls=q['controls'];case=q['case']
            assert science['source']==science['actual_controller_source']==C
            assert len(science['own'])==(3 if kind=='case-0' else 2) and len(science['native_samples'])==(7 if kind=='case-0' else 4)
            assert controls['status']=='ACTUAL_ANALYTICAL_FROST_COMPILED_NATIVE_AND_EXTERNAL_TRANSACTIONS_PASS_NOT_ADMITTED' and len(controls['analytical_model_refusals'])==14
            assert len(controls['calendar_thermal_refusals'])==(39 if kind=='case-0' else 44) and len(controls['snow_private_codec_refusals'])==(41 if kind=='case-0' else 45)
            item=dict(case=case,optimization=opt,status=q['status'],actual_source=C,archive_prefix='current/'+opt+'/'+kind,primary_days=case['days'],native_samples=len(science['native_samples']),exact_cold_windows=len(science['own']),actual_compiled_refusals=94 if kind=='case-0' else 103,original_budgets=science['independent_original_budgets'],original_convergence=q['original_convergence'])
            meta=json.loads((build/'BUILD.json').read_text());identity=meta['identity'];assert identity['compiler_sha256']=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
            projection[str(build)]=dict(archive_prefix='compiled/'+opt+'/'+kind+'/bundle',actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()))
            for key,subdir in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
                for n,digest in identity[key].items():
                    member='original-provider-build/'+subdir+'/'+n;raw=sdk.get(member);assert SHA(raw)==digest and raw==(J/'build'/subdir/n).read_bytes();provider[member]=dict(bytes=len(raw),sha256=digest)
            member='original-provider-build/ttutil-obj/libttutil.a';raw=sdk.get(member);assert SHA(raw)==identity['ttutil_library'] and raw==(J/'build/ttutil-obj/libttutil.a').read_bytes();provider[member]=dict(bytes=len(raw),sha256=SHA(raw));contexts.append(item)
    dependency=dict(archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',actual_data_revision='087fc67db3e1e58d45215522eb284e89cb6c12f1',sha256=sdk.record['sha256'],actual_required_files=provider)
add(E/'FROST_ANALYTICAL_COMPOSITION09_SOURCE_BYTES_V4','source')
for n in ['FROST_ANALYTICAL_COMPOSITION09_CONTROLLER_SOURCE_V4.tar','FROST_ANALYTICAL_COMPOSITION09_CONTROLLER_SOURCE_V4.json','frost-analytical-composition09-twelve-original-readers-v1.py',Path(__file__).name]:files['controllers/'+n]=E/n
for path in E.glob('FROST_ANALYTICAL_COMPOSITION09_E00_PREFLIGHT_ORIGINAL_REFUSAL_V1.*'):files['original-preflight-refusal/'+path.name]=path
for name,value in [('COMPILED_PROJECTION_V1.json',projection),('LOCAL_PROVIDER_DEPENDENCY_V1.json',dependency)]:
    file=E/('FROST_ANALYTICAL_COMPOSITION09_V4_'+name)
    with file.open('x',encoding='utf8') as out:json.dump(value,out,indent=2);out.write('\n')
    files[name]=file
name='FROST_ANALYTICAL_COMPOSITION09_LOCAL_WINDOWS_O0_O2_RAW_V4';archive=E/(name+'.zip');members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for label,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(label,raw);members[label]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=subprocess.check_output(['git','cat-file','commit',C],cwd=R);z.writestr('genuine-producer-commit.bin',raw);members['genuine-producer-commit.bin']=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for label,item in members.items():raw=z.read(label);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=archive.read_bytes();parts=[]
if len(raw)<=25*1024**2:
    file=name+'.zip'
    with (P/file).open('xb') as out:out.write(raw)
    parts=[dict(file=file,bytes=len(raw),sha256=SHA(raw))]
else:
    for i,offset in enumerate(range(0,len(raw),25*1024**2),1):
        value=raw[offset:offset+25*1024**2];file=name+f'.zip.part{i:03d}'
        with (P/file).open('xb') as out:out.write(value)
        parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
record=dict(status='ACTUAL_MODEL3_AND_MIXED73_CDE94_PRIMARY22_NATIVE10_COLD394_COMPILED_REFUSALS_AND_TRANSACTIONS_PASS_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_source=C,contexts=contexts,original_provider_dependency=dependency,primary_days=94,exact_cold_windows=10,native_samples=22,compiled_native_refusals=394,model7_primary_days_replayed=0,canonical_admission=False,new_admitted_contexts=0)

text=json.dumps(record,indent=2)+'\n'
for root in [E,P]:
    with (root/(name+'.json')).open('x',encoding='utf8') as out:out.write(text)
print(record['status'],len(raw),record['sha256'],len(members),flush=True)
