"""Preserve verified official analytical Frost artifact bytes without rewriting ZIPs."""
from pathlib import Path
import argparse,hashlib,json,zipfile
E=Path(__file__).resolve().parent;P=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01')
p=argparse.ArgumentParser();p.add_argument('--platform',choices=['UBUNTU','WINDOWS'],required=True);p.add_argument('--optimization',choices=['O0','O2'],required=True);p.add_argument('--bytes',type=int,required=True);p.add_argument('--sha256',required=True);p.add_argument('--artifact-id',type=int,required=True);p.add_argument('--run-id',type=int,required=True);a=p.parse_args()
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
name='FROST_ANALYTICAL_COMPOSITION09_'+a.platform+'_'+a.optimization+'_ORIGINAL_V1'
source=E/('FROST_ANALYTICAL_COMPOSITION09_'+a.platform+'_'+a.optimization+'_OFFICIAL_ARTIFACT_V1.zip')
raw=source.read_bytes();assert len(raw)==a.bytes and SHA(raw)==a.sha256
members={}
with zipfile.ZipFile(source) as z:
    names=z.namelist();assert len(names)==len(set(names)) and all(not x.startswith('/') and '..' not in Path(x).parts for x in names)
    for n in names:
        value=z.read(n);members[n]=dict(bytes=len(value),sha256=SHA(value))
    q=json.loads(z.read('current/RESULT.json'));assert q['source']=='a2df828cf19dea76a9012c7cb13f14db0cdbbe08' and q['platform'].upper()==a.platform and q['optimization']==a.optimization and len(q['contexts'])==12
    assert q['status']=='TWELVE_ACTUAL_ANALYTICAL_FROST_PORTABLE_PERIODS_NATIVE_COLD_AND_TRANSACTIONS_PASS_NOT_ADMITTED'
parts=[]
for i,offset in enumerate(range(0,len(raw),25*1024**2),1):
    value=raw[offset:offset+25*1024**2];file=name+f'.zip.part{i:03d}'
    with (P/file).open('xb') as out:out.write(value)
    parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
record=dict(status='ORIGINAL_OFFICIAL_ANALYTICAL_FROST_ARTIFACT_BYTES_PRESERVED_INDEPENDENT_SCIENCE_PENDING_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_source=q['source'],actual_run=a.run_id,actual_artifact=a.artifact_id,official_size_and_sha256_verified=True,original_ZIP_bytes_rewritten=False,scientific_producer_rebound=False,canonical_admission=False)
for root in [E,P]:
    with (root/(name+'.json')).open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
print(name,len(raw),SHA(raw),len(members),flush=True)
