"""Prove each owned reproducible09 file centrally before explicit resource release."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';CLEAN=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');actor=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert actor=='084a3b5d194fecc9f0aa606e46c51b34a7f0662f'
resources=[]
for version in [1,2,3,5]:
    resources.append(('frost-analytical-composition09-local-science-v'+str(version),'V'+str(version),'current'))
    for opt in ['O0','O2']:resources.append(('frost-analytical-composition09-local-'+opt+'-v'+str(version),'V'+str(version),'compiled/'+opt))
for opt in ['O0','O2']:
    resources.extend([('frost-analytical-composition09-local-science-'+opt+'-v4','V4','current/'+opt),('frost-analytical-composition09-local-'+opt+'-v4','V4','compiled/'+opt)])
resources.extend([('frost-analytical-composition09-twelve-original-readers-v1','V4','original-reader-zero-days'),('frost-analytical-composition09-public-reader-controls-v1','V5','public-reader')])
rows=[]
with ExitStack() as stack:
    stores={v:Archive(GitArchiveSource(R,actor),'FROST_ANALYTICAL_COMPOSITION09_LOCAL_WINDOWS_O0_O2_RAW_'+v,stack) for v in ['V1','V2','V3','V4','V5']}
    for name,version,prefix in resources:
        root=W/name;assert root.is_dir() and not root.is_symlink();store=stores[version];files=[]
        for path in sorted(root.rglob('*')):
            assert not path.is_symlink()
            if not path.is_file():continue
            member=prefix+'/'+path.relative_to(root).as_posix();actual=path.read_bytes();central=store.get(member);assert actual==central,(name,member)
            files.append(dict(file=path.relative_to(root).as_posix(),member=member,bytes=len(actual),sha256=SHA(actual)))
        assert files
        rows.append(dict(owned_root=str(root),central_data_revision=actor,central_archive=store.record['archive'],central_archive_sha256=store.record['sha256'],files=files,total_bytes=sum(x['bytes'] for x in files),no_further_live_physical_build_dependency=True))
q=dict(status='ALL18_OWNED09_REPRODUCIBLE_DIRECTORIES_EVERY_FILE_FRESH_EXACT_TO_FROZEN_CENTRAL_RAW_BEFORE_RELEASE',actual_observer=actor,resources=rows,required_unique_raw_and_source_centrally_preserved=True,original08initialization_probe_and_current10resources_stay_active=True)
assert len(rows)==18
with (E/'FROST_ANALYTICAL_COMPOSITION09_RESOURCE_CENTRAL_CUSTODY_BEFORE_RELEASE_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
for item in rows:
    response=subprocess.run(['python','-B',str(CLEAN),'release','--task',TASK,'--path',item['owned_root']],capture_output=True,text=True)
    with (E/('FROST_ANALYTICAL_COMPOSITION09_RELEASE_'+Path(item['owned_root']).name+'_V1.json')).open('x',encoding='utf8') as out:out.write(response.stdout)
    assert response.returncode==0,response.stdout+response.stderr
print(q['status'],len(rows),sum(x['total_bytes'] for x in rows),flush=True)
