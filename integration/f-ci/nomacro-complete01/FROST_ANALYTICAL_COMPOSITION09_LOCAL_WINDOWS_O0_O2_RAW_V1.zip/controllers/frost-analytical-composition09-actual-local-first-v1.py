"""First real public analytical Frost build and original-budget/native/cold run."""
from pathlib import Path
import json,os,shutil,subprocess,sys,time
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
C='dd7596685c91074789ab56e9a3ecb3d4a4ef4b4c';opt='O0';name='model7-7-cde-b8-p1'
D=W/'frost-analytical-composition09-local-science-v1'/(opt+'-'+name);D.mkdir()
inputs=D/'inputs';shutil.copytree(W/'frost-analytical-composition09-reader-discovery-v1'/name/'inputs',inputs)
build=W/'frost-analytical-composition09-local-O0-v1'/name/'bundle'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert git('rev-parse','HEAD')==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=dict(status='RUNNING_FIRST_ACTUAL_PUBLIC_ANALYTICAL_FROST_NOT_QUALIFIED',actual_source=C,optimization=opt,case=name,input_root=str(inputs),build_root=str(build),days=35,canonical_admission=False)
save=lambda:(D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
env=dict(os.environ,OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
def run(command,label,cap):
    started=time.perf_counter()
    with (D/(label+'.stdout')).open('xb') as out,(D/(label+'.stderr')).open('xb') as err:result=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=cap)
    q[label]=dict(command=command,returncode=result.returncode,seconds=time.perf_counter()-started);save();result.check_returncode();return q[label]
save()
try:
    command=[sys.executable,'-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy','original-adaptive-event-closure-v1','--reference-work',str(J),'--build-only','--donor-opt',opt,'--kernel-opt',opt,'--output',str(build)]
    record=run(command,'actual-public-build',300);report=dict(status='ACTUAL_PUBLIC_ANALYTICAL_FROST_BUILD_COMPLETE_NOT_SCIENTIFICALLY_QUALIFIED',actual_source=C,input_root=str(inputs),build_root=str(build),returncode=0,command=command,seconds=record['seconds'])
    (D/'BUILD_RESULT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    run([sys.executable,'-B','tests/nomacro_drainage/frost_analytical_state_runtime.py','--build-record',str(D/'BUILD_RESULT.json'),'--reference-work',str(J),'--output',str(D/'science'),'--days','35'],'actual-public-runtime',900)
    q['science']=json.loads((D/'science/RESULT.json').read_text());assert q['science']['status']=='ACTUAL_ANALYTICAL_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_MODEL_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED'
    sys.path.insert(0,str(R/'tests/nomacro_drainage'));from frost_boundary_convergence import require_convergence
    q['original_convergence']=require_convergence(D/'science');assert git('rev-parse','HEAD')==C
    q['status']='ACTUAL_FIRST_PUBLIC_ANALYTICAL_FROST_CDE_MODEL7_ORIGINAL_BUDGETS_TYPED_NATIVE_AND_EXACT_COLD_PASS_NOT_ADMITTED'
except Exception as exc:q.update(status='FAILED_ACTUAL_FIRST_PUBLIC_ANALYTICAL_FROST_NOT_QUALIFIED',error=repr(exc));raise
finally:save()
print(q['status'],C,flush=True)
