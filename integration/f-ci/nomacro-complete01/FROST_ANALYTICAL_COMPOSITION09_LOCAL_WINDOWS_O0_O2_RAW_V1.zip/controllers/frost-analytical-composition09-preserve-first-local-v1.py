"""Preserve two true model7 periods and original scalar-SWVAPOR zero-day refusals."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
C='dd7596685c91074789ab56e9a3ecb3d4a4ef4b4c';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
name='FROST_ANALYTICAL_COMPOSITION09_LOCAL_WINDOWS_O0_O2_RAW_V1';files={};projection={};provider={};contexts=[]
def add(root,prefix):
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path
D=W/'frost-analytical-composition09-local-science-v1';add(D,'current')
with ExitStack() as stack:
    sdk=Archive(GitArchiveSource(R,'087fc67db3e1e58d45215522eb284e89cb6c12f1'),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
    for opt in ['O0','O2']:
        root=W/('frost-analytical-composition09-local-'+opt+'-v1');add(root,'compiled/'+opt)
        for case in ['model7-7-cde-b8-p1','model11-scalar-water-b8-p2-dates-r0-year']:
            folder=D/(opt+'-'+case);q=json.loads((folder/'RESULT.json').read_text());assert q['actual_source']==C
            build=Path(q['build_root']);meta=json.loads((build/'BUILD.json').read_text());identity=meta['identity'];assert identity['compiler_sha256']=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
            projection[str(build)]=dict(archive_prefix='compiled/'+opt+'/'+case+'/bundle',actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()))
            for key,subdir in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
                for n,digest in identity[key].items():
                    member='original-provider-build/'+subdir+'/'+n;raw=sdk.get(member);assert SHA(raw)==digest and raw==(J/'build'/subdir/n).read_bytes();provider[member]=dict(bytes=len(raw),sha256=digest)
            member='original-provider-build/ttutil-obj/libttutil.a';raw=sdk.get(member);assert SHA(raw)==identity['ttutil_library'] and raw==(J/'build/ttutil-obj/libttutil.a').read_bytes();provider[member]=dict(bytes=len(raw),sha256=SHA(raw))
            science=json.loads((folder/'science/RESULT.json').read_text());assert science['source']==science['actual_controller_source']==C
            if case.startswith('model7'):
                assert science['status']=='ACTUAL_ANALYTICAL_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_MODEL_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED' and science['duration_days']==35
                assert len(science['native_samples'])==7 and len(science['own'])==3 and q['original_convergence']['unconverged_continuations']==0
                item=dict(case=case,optimization=opt,actual_source=C,status='ACTUAL35_ORIGINAL_BUDGET_NATIVE_MODEL_COLD_AND_OUTPUT_PASS_NOT_ADMITTED',primary_days=35,native_samples=7,exact_cold_windows=3,original_budgets=science['independent_original_budgets'])
            else:
                assert q['status']=='FAILED_ACTUAL_PUBLIC_ANALYTICAL_FROST_NOT_QUALIFIED' and 'HYBRID_READY' in science['error']
                errors=list((folder/'science').rglob('swap.err'));assert len(errors)==1
                error=errors[0].read_bytes();assert b'INTEGER array SWVAPOR' in error and b'this variable is scalar' in error and b'precisely     2' in error
                stdout=(folder/'science/trajectory/original/donor.stdout').read_bytes();assert b'HYBRID_READY' not in stdout and b'HYBRID_DAY_RETURN' not in stdout
                assert all(not p.read_bytes().strip() for p in (folder/'science').rglob('daily.jsonl')) and not list((folder/'science').rglob('accepted-*.zip'))
                item=dict(case=case,optimization=opt,actual_source=C,status='GENUINE_ORIGINAL_RDFINR_REQUIRES_LAYER_ARRAY_SCALAR_SWVAPOR_REFUSED_ZERO_MODEL_DAYS',primary_days=0,native_samples=0,exact_cold_windows=0,original_error_sha256=SHA(error),public_build_completed=True,original_scalar_IHWCKMODEL_is_separate_and_supported=True)
            contexts.append(item)
    dependency=dict(archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',actual_data_revision='087fc67db3e1e58d45215522eb284e89cb6c12f1',sha256=sdk.record['sha256'],actual_required_files=provider)
add(E/'FROST_ANALYTICAL_COMPOSITION09_SOURCE_BYTES_V1','source')
for n in ['FROST_ANALYTICAL_COMPOSITION09_CONTROLLER_SOURCE_V1.tar','FROST_ANALYTICAL_COMPOSITION09_CONTROLLER_SOURCE_V1.json','FROST_ANALYTICAL_COMPOSITION09_ACTUAL_PUBLIC_READER_V1.json','frost-analytical-composition09-actual-local-first-v1.py','frost-analytical-composition09-actual-local-followups-v1.py',Path(__file__).name]:files['controllers/'+n]=E/n
for label,value in [('COMPILED_PROJECTION_V1.json',projection),('LOCAL_PROVIDER_DEPENDENCY_V1.json',dependency)]:
    path=E/('FROST_ANALYTICAL_COMPOSITION09_'+label)
    with path.open('x',encoding='utf8') as out:json.dump(value,out,indent=2);out.write('\n')
    files[label]=path
members={};archive=E/(name+'.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for label,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(label,raw);members[label]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=subprocess.check_output(['git','cat-file','commit',C],cwd=R);z.writestr('genuine-producer-commit.bin',raw);members['genuine-producer-commit.bin']=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for label,item in members.items():raw=z.read(label);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=archive.read_bytes();parts=[]
for i,offset in enumerate(range(0,len(raw),25*1024**2),1):
    value=raw[offset:offset+25*1024**2];file=name+f'.zip.part{i:03d}'
    with (P/file).open('xb') as out:out.write(value)
    parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
record=dict(status='TWO_ACTUAL_MODEL7_O0_O2_PERIODS_AND_TWO_ORIGINAL_SCALAR_SWVAPOR_INIT_REFUSALS_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_scientific_source=C,contexts=contexts,original_provider_dependency=dependency,primary_days=70,native_samples=14,exact_cold_windows=6,accepted_model11_scalar_SWVAPOR_days=0,compiled_native_controls='PENDING',independent_and_portable_qualification='PENDING',new_admitted_contexts=0,canonical_admission=False)
text=json.dumps(record,indent=2)+'\n'
for root in [E,P]:
    with (root/(name+'.json')).open('x',encoding='utf8') as out:out.write(text)
print(record['status'],len(raw),record['sha256'],len(members),flush=True)
