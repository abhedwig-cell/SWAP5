"""Additional actual source-dd public O0/O2 profiles; never replay first O0 period."""
from pathlib import Path
import argparse,json,os,re,shutil,subprocess,sys,time
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=['O0','O2'],required=True);p.add_argument('--case',choices=['model7-dense','model11-scalar-year'],required=True);a=p.parse_args();opt=a.optimization
assert (opt,a.case)!=('O0','model7-dense'),'Original completed O0 period must be inherited'
C='b57134372c66c10ada81e2ca580306855ef4fe46';git=lambda *x:subprocess.check_output(['git',*x],cwd=R).decode().strip()
assert git('rev-parse','HEAD')==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_undrained_state_inputs import prepare
from original_output_baseline import assignment
name='model7-7-cde-b8-p1' if a.case=='model7-dense' else 'model11-scalar-water-b8-p2-dates-r0-year'
case=dict(kind='cde' if a.case=='model7-dense' else 'water',bottom=8,implicit=0,hysteresis=0,initial=1 if a.case=='model7-dense' else 2,calendar='dense' if a.case=='model7-dense' else 'dates',reset=1 if a.case=='model7-dense' else 0,start=None if a.case=='model7-dense' else '2002-12-25',days=35 if a.case=='model7-dense' else 12,drainage=0)
D=W/'frost-analytical-composition09-local-science-v2'/(opt+'-'+name);D.mkdir();inputs=D/'inputs'
if a.case=='model7-dense':shutil.copytree(W/'frost-analytical-composition09-reader-discovery-v1'/'model7-7-cde-b8-p1'/'inputs',inputs)
else:
    prepare(case,inputs);path=inputs/'swap.swp';text=path.read_text(encoding='cp1252')
    parameters=dict(iHWCKmodel='11',SWVAPOR='0 0',ALFA_2='.005 .003',NPAR_2='1.5 1.6',OMEGA_1='.8 .8',H0='-1e6 -1e6',HA='-10.0 -10.0',APAR='-1.5 -1.5',OMEGA_K='.01 .01')
    for key,value in parameters.items():text=assignment(text,key,value) if re.search(r'(?mi)^[ \t]*'+key+r'[ \t]*=',text) else text+'\n'+key+' = '+value+'\n'
    path.write_text(text,encoding='cp1252')
    for crop in inputs.glob('*.crp'):crop.write_text(assignment(crop.read_text(encoding='cp1252'),'SWSALINITY',0),encoding='cp1252')
build=W/('frost-analytical-composition09-local-'+opt+'-v2')/name/'bundle'
q=dict(status='RUNNING_ACTUAL_FOLLOWUP_PUBLIC_ANALYTICAL_FROST_NOT_QUALIFIED',actual_source=C,optimization=opt,case=case,name=name,input_root=str(inputs),build_root=str(build),days=case['days'],canonical_admission=False,completed_original_O0_period_replayed=False)
save=lambda:(D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
env=dict(os.environ,OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
def run(command,label,cap):
    started=time.perf_counter()
    with (D/(label+'.stdout')).open('xb') as out,(D/(label+'.stderr')).open('xb') as err:result=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=cap)
    q[label]=dict(command=command,returncode=result.returncode,seconds=time.perf_counter()-started);save();result.check_returncode();return q[label]
save()
try:
    command=[sys.executable,'-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy','original-adaptive-event-closure-v1','--reference-work',str(J),'--build-only','--donor-opt',opt,'--kernel-opt',opt,'--output',str(build)]
    record=run(command,'actual-public-build',300);report=dict(status='ACTUAL_PUBLIC_ANALYTICAL_FROST_BUILD_COMPLETE_NOT_SCIENTIFICALLY_QUALIFIED',actual_source=C,input_root=str(inputs),build_root=str(build),returncode=0,command=command,seconds=record['seconds'])
    (D/'BUILD_RESULT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    command=[sys.executable,'-B','tests/nomacro_drainage/frost_analytical_state_runtime.py','--build-record',str(D/'BUILD_RESULT.json'),'--reference-work',str(J),'--output',str(D/'science'),'--days',str(case['days'])]
    if case['start']:command.append('--year-seam')
    run(command,'actual-public-runtime',900);q['science']=json.loads((D/'science/RESULT.json').read_text());assert q['science']['status']=='ACTUAL_ANALYTICAL_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_MODEL_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED'
    from frost_boundary_convergence import require_convergence
    q['original_convergence']=require_convergence(D/'science');assert git('rev-parse','HEAD')==C
    q['status']='ACTUAL_PUBLIC_ANALYTICAL_FROST_ORIGINAL_BUDGETS_TYPED_PER_LAYER_NATIVE_EXACT_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED'
except Exception as exc:q.update(status='FAILED_ACTUAL_PUBLIC_ANALYTICAL_FROST_NOT_QUALIFIED',error=repr(exc));raise
finally:save()
print(q['status'],name,opt,C,flush=True)
