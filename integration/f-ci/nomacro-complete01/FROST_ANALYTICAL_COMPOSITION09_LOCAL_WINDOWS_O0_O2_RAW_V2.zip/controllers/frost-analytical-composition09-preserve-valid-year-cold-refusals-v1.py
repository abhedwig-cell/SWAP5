"""Preserve actual valid year primaries, failed cold origins and current postimages."""
from pathlib import Path
from contextlib import ExitStack
import json,subprocess,sys,zipfile
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');C='b57134372c66c10ada81e2ca580306855ef4fe46'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
from frost_analytical_composition import native_domain
files={};projection={};provider={};contexts=[]
def add(root,prefix):
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path
D=W/'frost-analytical-composition09-local-science-v2';add(D,'current')
with ExitStack() as stack:
    sdk=Archive(GitArchiveSource(R,'087fc67db3e1e58d45215522eb284e89cb6c12f1'),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
    for opt in ['O0','O2']:
        root=W/('frost-analytical-composition09-local-'+opt+'-v2');add(root,'compiled/'+opt)
        for kind in ['model7-current-postimage','model11-scalar-water-b8-p2-dates-r0-year']:
            folder=D/(opt+'-'+kind);q=json.loads((folder/'RESULT.json').read_text())
            if kind=='model7-current-postimage':
                assert q['actual_current_source']==C and q['status']=='CURRENT_ACTUAL_MODEL7_COMPLETE_GENERATED_SOURCES_SAME_COMPILER_AND_WHOLE_OBJECTS_PASS_NO_PERIOD_REPLAY' and len(q['whole_objects'])==27 and q['model_executions']==0
                build=Path(q['actual_build']['root']);item=dict(case=kind,optimization=opt,status=q['status'],original_scientific_source=q['original_scientific_source'],actual_current_compiler_source=C,whole_objects=q['whole_objects'],new_primary_days=0)
            else:
                assert q['actual_source']==C and q['status']=='FAILED_ACTUAL_PUBLIC_ANALYTICAL_FROST_NOT_QUALIFIED';build=Path(q['build_root']);s=json.loads((folder/'science/RESULT.json').read_text());warm=folder/'science/trajectory'
                assert s['source']==s['actual_controller_source']==C and s['duration_days']==12 and s['independent_original_budgets']['days']==12
                assert len((warm/'daily.jsonl').read_text().splitlines())==12 and not s['own']
                cold=folder/'science/own-2/original';error=(cold/'donor.stderr').read_bytes();assert b'Inconsistent original interval date pointer' in error and b'HYBRID_READY' not in (cold/'donor.stdout').read_bytes() and b'HYBRID_DAY_RETURN' not in (cold/'donor.stdout').read_bytes()
                samples=[]
                for day in [2,5,9,12]:
                    with zipfile.ZipFile(warm/f'accepted-column-1-day-{day}.zip') as z:
                        frame=json.loads(z.read('checkpoint.json'));assert all(SHA(z.read(n))==digest for n,digest in frame['files'].items());native_domain(z.read('macro.bin'),s['selection'],34)
                    samples.append(day)
                item=dict(case=kind,optimization=opt,status='ACTUAL12_PRIMARY_BUDGETS_AND_NATIVE_MODEL_DOMAIN_PASS_ORIGINAL_DATE_POINTER_COLD_REFUSAL_NOT_QUALIFIED',actual_source=C,primary_days=12,native_samples=samples,exact_cold_windows=0,cold_refusal_original_stderr_sha256=SHA(error),original_budgets=s['independent_original_budgets'])
            meta=json.loads((build/'BUILD.json').read_text());identity=meta['identity'];assert identity['compiler_sha256']=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
            projection[str(build)]=dict(archive_prefix='compiled/'+opt+'/'+build.parent.name+'/bundle',actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()))
            for key,subdir in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
                for n,digest in identity[key].items():
                    member='original-provider-build/'+subdir+'/'+n;raw=sdk.get(member);assert SHA(raw)==digest and raw==(J/'build'/subdir/n).read_bytes();provider[member]=dict(bytes=len(raw),sha256=digest)
            member='original-provider-build/ttutil-obj/libttutil.a';raw=sdk.get(member);assert SHA(raw)==identity['ttutil_library'] and raw==(J/'build/ttutil-obj/libttutil.a').read_bytes();provider[member]=dict(bytes=len(raw),sha256=SHA(raw));contexts.append(item)
    dependency=dict(archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',actual_data_revision='087fc67db3e1e58d45215522eb284e89cb6c12f1',sha256=sdk.record['sha256'],actual_required_files=provider)
add(E/'FROST_ANALYTICAL_COMPOSITION09_SOURCE_BYTES_V2','source')
for n in ['FROST_ANALYTICAL_COMPOSITION09_CONTROLLER_SOURCE_V2.tar','FROST_ANALYTICAL_COMPOSITION09_CONTROLLER_SOURCE_V2.json','frost-analytical-composition09-actual-local-followups-v2.py','frost-analytical-composition09-model7-current-postimages-v1.py',Path(__file__).name]:files['controllers/'+n]=E/n
for name,value in [('COMPILED_PROJECTION_V1.json',projection),('LOCAL_PROVIDER_DEPENDENCY_V1.json',dependency)]:
    file=E/('FROST_ANALYTICAL_COMPOSITION09_V2_'+name)
    with file.open('x',encoding='utf8') as out:json.dump(value,out,indent=2);out.write('\n')
    files[name]=file
name='FROST_ANALYTICAL_COMPOSITION09_LOCAL_WINDOWS_O0_O2_RAW_V2';archive=E/(name+'.zip');members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for label,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(label,raw);members[label]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=subprocess.check_output(['git','cat-file','commit',C],cwd=R);z.writestr('genuine-producer-commit.bin',raw);members['genuine-producer-commit.bin']=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for label,item in members.items():raw=z.read(label);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=archive.read_bytes();parts=[]
if len(raw)<=25*1024**2:
    file=name+'.zip'
    with (P/file).open('xb') as out:out.write(raw)
    parts=[dict(file=file,bytes=len(raw),sha256=SHA(raw))]
else:
    for i,offset in enumerate(range(0,len(raw),25*1024**2),1):
        value=raw[offset:offset+25*1024**2];file=name+f'.zip.part{i:03d}'
        with (P/file).open('xb') as out:out.write(value)
        parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
record=dict(status='ACTUAL24_VALID_MODEL11_PRIMARY_DAYS_TWO_ORIGINAL_DATE_POINTER_COLD_REFUSALS_AND54_MODEL7_WHOLE_POSTIMAGES_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_source=C,contexts=contexts,original_provider_dependency=dependency,primary_model11_days=24,exact_model11_cold_windows=0,model7_current_postimages=2,model7_whole_objects=54,model7_primary_days_replayed=0,canonical_admission=False,new_admitted_contexts=0)
text=json.dumps(record,indent=2)+'\n'
for root in [E,P]:
    with (root/(name+'.json')).open('x',encoding='utf8') as out:out.write(text)
print(record['status'],len(raw),record['sha256'],len(members),flush=True)
