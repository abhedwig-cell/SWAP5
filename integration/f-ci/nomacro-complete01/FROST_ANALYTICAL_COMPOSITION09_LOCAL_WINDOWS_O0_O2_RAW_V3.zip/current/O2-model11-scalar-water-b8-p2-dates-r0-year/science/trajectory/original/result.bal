* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-26 05:38:55

Period             :  2002-12-25  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.73 cm
Initial :        97.55 cm
            =============
Change          -20.83 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :     5.27    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :   -28.47    Soil evaporation  :     0.02
                             Crack flux        :     0.00
=========================    ============================
Sum            :   -20.80    Sum               :     0.02
