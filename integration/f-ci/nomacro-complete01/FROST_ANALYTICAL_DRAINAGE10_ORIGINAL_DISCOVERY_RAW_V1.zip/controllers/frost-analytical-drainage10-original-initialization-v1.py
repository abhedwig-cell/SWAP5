"""Original drainage-on process initialization probe; no physical model days."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
B=W/'frost-analytical-drainage10-original-init-O0-v1';D=W/'frost-analytical-drainage10-original-discovery-v2';C='38196200968a7f640ab2b5b06861691f09f922d5';SHA=lambda raw:hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C
assert not any(B.iterdir()) and not any(D.iterdir())
old=W/'frost-undrained-state08-initialization-probe-O0-v1/corrected-module-import-v2';original=(old/'probe.f90').read_text();assert SHA((old/'probe.f90').read_bytes())=='4ab1a6bb4143c6bf04fb09354c56552fdc79a828703d797274b08f3688084a52'
assert original.count("if(swdra/=0)error stop 'Unexpected drainage'")==1
source=original.replace('use MOD_solute, only: solute','use MOD_solute, only: solute\nuse MOD_drain, only: drain').replace("if(swdra/=0)error stop 'Unexpected drainage'","if(swdra/=1)error stop 'Unexpected original basic drainage domain'\ncall Drain(1)\ncall mark('AFTER_ORIGINAL_BASIC_DRAINAGE_INITIALIZATION')")
(B/'probe.f90').write_text(source,encoding='ascii')
env=dict(os.environ,OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH'];compiler=shutil.which('gfortran',path=env['PATH']);objects=sorted(p for p in (J/'build/swap-obj').glob('*.o') if p.name!='swap_main.o');oldmeta=json.loads((old/'BUILD_DIAGNOSTIC.json').read_text())
assert SHA(Path(compiler).read_bytes())==oldmeta['compiler_sha256']=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
assert {p.name:SHA(p.read_bytes()) for p in objects}==oldmeta['original_objects']
exe=B/'original_drainage_initialization_probe.exe';command=[compiler,'-O0','-g','-fbacktrace','-ffree-line-length-none','-I',str(J/'build/swap-obj'),'-I',str(J/'build/ttutil-obj'),'probe.f90',*map(str,objects),str(J/'build/ttutil-obj/libttutil.a'),'-o',str(exe)]
q=dict(status='BUILDING_ACTUAL_ORIGINAL_DRAINAGE_INITIALIZATION_PROBE_NOT_QUALIFIED',actual_controller_source=C,driver_sha256=SHA(source.encode()),original_driver_sha256=SHA((old/'probe.f90').read_bytes()),original_probe_producer=oldmeta['actual_controller_source'],compiler_sha256=SHA(Path(compiler).read_bytes()),original_objects=oldmeta['original_objects'],original_library_sha256=SHA((J/'build/ttutil-obj/libttutil.a').read_bytes()),command=command,model_days=0,cases=[],scientific_qualification=False)
start=time.perf_counter();result=subprocess.run(command,cwd=B,env=env,capture_output=True,timeout=60)
(B/'compile.stdout').write_bytes(result.stdout);(B/'compile.stderr').write_bytes(result.stderr);q.update(compiler_returncode=result.returncode,compiler_seconds=time.perf_counter()-start)
(B/'BUILD_DIAGNOSTIC.json').write_text(json.dumps(q,indent=2)+'\n');result.check_returncode();q['executable_sha256']=SHA(exe.read_bytes())
prior=json.loads((E/'FROST_ANALYTICAL_DRAINAGE10_ORIGINAL_DISCOVERY_V1.json').read_text())
for item in prior['contexts']:
    name=item['name'];folder=D/name;folder.mkdir();worker=folder/'original-worker';shutil.copytree(W/'frost-analytical-drainage10-original-discovery-v1'/name/'inputs',worker)
    start=time.perf_counter();result=subprocess.run([str(exe)],cwd=worker,env=env,capture_output=True,timeout=45)
    (folder/'original-init.stdout').write_bytes(result.stdout);(folder/'original-init.stderr').write_bytes(result.stderr)
    phases=[line for line in result.stdout.decode('cp1252',errors='replace').splitlines() if line.startswith('ORIGINAL_INIT_PHASE ')]
    initialized=result.returncode==0 and 'ORIGINAL_INIT_PHASE AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS' in phases
    q['cases'].append(dict(name=name,case=item['case'],input_sha256=item['input_inventory'],public_reader_original=item['public_reader'],returncode=result.returncode,phases=phases,original_initialized=initialized,stdout_sha256=SHA(result.stdout),stderr_sha256=SHA(result.stderr),seconds=time.perf_counter()-start,model_days=0))
    print('ORIGINAL_DRAINAGE_INITIALIZATION_OBSERVATION',name,result.returncode,initialized,flush=True)
q.update(status='SIX_ORIGINAL_BASIC_DRAINAGE_ANALYTICAL_FROST_INITIALIZATION_OBSERVATIONS_PRESERVED_NOT_QUALIFIED',all_original_initialized=all(x['original_initialized'] for x in q['cases']),first_attempt_refusal='Original drainage0-only diagnostic controller guard, not a legacy physical/read failure')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C
for path in [B/'RESULT.json',D/'RESULT.json',E/'FROST_ANALYTICAL_DRAINAGE10_ORIGINAL_DISCOVERY_V2.json']:
    with path.open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],q['all_original_initialized'],flush=True)
