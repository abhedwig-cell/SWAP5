from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;C=Path('C:/Users/Veldh012/swap5-implicit-conductivity-canonical01')
git=lambda *a:subprocess.check_output(['git',*a],cwd=C).decode().strip()
assert git('rev-parse','HEAD')=='1c3b8725548c836c9a73570c2579dd6cdc683217'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
p=Path(git('rev-parse','--git-path','info/sparse-checkout'));p=p if p.is_absolute() else C/p;patterns=p.read_bytes();assert len(patterns.splitlines())==14
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={p.relative_to(C).as_posix():sha(p) for p in (C/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()};assert len(inputs)==56
archives={p.relative_to(C).as_posix():sha(p) for p in (C/'integration/f-ci/nomacro-complete01').iterdir() if p.is_file() and ('.zip' in p.name)}
head='9936bcda75eb920d67aa74e47018baf39ab18f78'
assert git('rev-parse',head+'^{tree}')=='b70bb40894c548c94a0356a056d3fc4ad08169d3'
assert git('show','-s','--format=%P',head)=='1c3b8725548c836c9a73570c2579dd6cdc683217 2e9dc651b13e54eca0ba91a867d0849dd7904959'
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','switch','--detach',head],cwd=C,capture_output=True,check=True)
missing=[n for n in archives if not (C/n).is_file()]
for i in range(0,len(missing),20):subprocess.run(['git','restore','--source='+head,'--worktree','--ignore-skip-worktree-bits','--',*missing[i:i+20]],cwd=C,capture_output=True,check=True)
assert p.read_bytes()==patterns and {p.relative_to(C).as_posix():sha(p) for p in (C/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()}==inputs
assert all(sha(C/n)==v for n,v in archives.items())
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
(E/'FROST_BOUNDARY03_ACTUAL_CANONICAL_DEPENDENCIES_V1.json').write_text(json.dumps(dict(actual_merge=head,tree=git('rev-parse','HEAD^{tree}'),original_project_files=inputs,sparse_patterns_unchanged=14,old_materialized_archives=archives,restored_explicit_missing=missing,compiler_executions=0,model_executions=0),indent=2)+'\n')
print('ACTUAL_SIGNED_MERGE_CANONICAL_CLEAN14_56_READY',len(archives))

