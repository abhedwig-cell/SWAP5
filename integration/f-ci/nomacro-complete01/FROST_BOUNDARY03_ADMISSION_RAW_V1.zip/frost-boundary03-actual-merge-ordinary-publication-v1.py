from pathlib import Path
E=Path(__file__).parent
source=E/'frost-calendar-state02-candidate-normal-python-publication-observe-v3.py'
text=source.read_text();before="output=E/'FROST_CALENDAR_STATE02_CANDIDATE_PUBLICATION_V3'"
assert text.count(before)==1
text=text.replace(before,"output=E/'FROST_BOUNDARY03_ACTUAL_MERGE_PUBLICATION_V1'")
exec(compile(text,str(source),'exec'),{'__file__':str(source),'__name__':'__main__'})

