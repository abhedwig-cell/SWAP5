"""Join actual parent receipt with functional source repair and original failures."""
import difflib,hashlib,json,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).parent
base='3250f0c59337334994b0e8edda624afe8f91b11f';sha=lambda b:hashlib.sha256(b).hexdigest()
q=json.loads((P/'FROST_BOUNDARY03_CONTRACT_V1.json').read_text());files={}
names=['frost_boundary_composition.py','experimental_project.py','implicit_frost_composition.py','frost_drainage_composition.py','implicit_frost_root_state.py','implicit_snow_root_carry.py']
for name in names:
 path='app/hybrid_water/'+name;raw=(R/path).read_bytes().replace(b'\r\n',b'\n');item=dict(added=name=='frost_boundary_composition.py',proposed_lf_sha256=sha(raw))
 if not item['added']:
  old=subprocess.check_output(['git','show',base+':'+path],cwd=R);a=old.decode();b=raw.decode()
  edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=True).get_opcodes() if op!='equal']
  item.update(before_lf_sha256=sha(old),ordered_literal_edits=edits)
 files[path]=item
q.update(files=files,status='FIRST_EXPLICIT_FULL35_FOUR_PLATFORM_OPT_CONTEXTS_PASS_IMPLICIT_PRIVATE_OWNER_OVERLAP_REPAIRED_NOT_QUALIFIED',
 dependency_admission='ACTUAL_CANONICAL500_PUBLIC_AND_ORDINARY_PUBLICATION_ALL17CI_FOUR_NEGATIVES_AND_SIGNED_OBJECT_ADMISSION_SEALED',
 admission_receipt='FROST_CALENDAR_STATE02_MERGE_RECEIPT_V1.json',
 first_scientific_source='16988131766408867b0c1fa94a3a45cabe68b6fe',
 private_owner_correction='Existing generic implicit Snow rate carry must decline exactly the selected Frost boundary58 domain, whose own typed Frost rate carry is installed later. No codec allowlist or double state owner.',
 no_replay_rule='Keep the four completed explicit water bottom5 full35 contexts. Fresh current generated/compiled postimages must match their actual original CI artifacts before inheritance; run only the seven missing contexts per opt/platform.')
(P/'FROST_BOUNDARY03_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n')
for osname,runid in [('ubuntu',45627300645),('windows',45627301016)]:
 path=R/'.github/workflows'/('nomacro-frost-boundary03-'+osname+'.yml');text=path.read_text();anchor='      - name: Preserve real source and prepare original provider\n'
 assert text.count(anchor)==1
 name='frost-boundary03-'+('windows-' if osname=='windows' else '')+'${{ matrix.optimization }}-16988131766408867b0c1fa94a3a45cabe68b6fe'
 step='      - name: Obtain exact original completed first scientific context\n        uses: actions/download-artifact@v4\n        with:\n          github-token: ${{ github.token }}\n          repository: abhedwig-cell/SWAP5\n          run-id: '+str(runid)+'\n          name: '+name+'\n          path: ${{ runner.temp }}/previous-proof\n'
 text=text.replace(anchor,step+anchor,1)
 anchor='frost_boundary_portable.py --platform '+('Ubuntu' if osname=='ubuntu' else 'Windows')
 assert text.count(anchor)==1;text=text.replace(anchor,anchor+' --previous-proof "$RUNNER_TEMP/previous-proof"')
 path.write_text(text)
status=json.loads((P/'STATUS.json').read_text());receipt=json.loads((P/'FROST_CALENDAR_STATE02_MERGE_RECEIPT_V1.json').read_text())
status['frost_calendar_state02_recovery'].update(canonical_admission_sealed=True,
 actual_canonical_public_and_ordinary_publication='PASS476.8750015_AND430.1179172_SECONDS_CLEAN14_56_UNCHANGED',
 admission_archive_sha256=receipt['admission_archive_sha256'],receipt='FROST_CALENDAR_STATE02_MERGE_RECEIPT_V1.json',next='Completed bounded admission; carry receipt with this functional batch.')
status['completed'].append('PR1801 actualcanonical1c3b8725548c836c9a73570c2579dd6cdc683217 exact8d/3250parents and d20tree;17workflowsSUCCESS31checksPASS17skip;4realpushednegativesrefused. Actualclean14/56 PUBLIC476.8750015s and ordinaryPUB430.1179172s PASS. Admission raw7679011B SHA5fc94d202dc7b7d1de61418e25f96384eea667f49d63aacd4d86f1da163310a6. Bounded original Frost calendars admitted; coadmission500. WholeclosurePARTIAL/scienceNOT_QUALIFIED/fixedRC3unchanged.')
status['frost_boundary03_recovery'].update(first_scientific_source='16988131766408867b0c1fa94a3a45cabe68b6fe',first_workflows=[45627300645,45627301016],first_completed_full35_contexts=4,
 first_failure='Other first context implicit water builder refused duplicate generic Snow root codec before models; source repair adds exact selected Frost private-owner exclusion.',
 next='Push source-bound repaired seven-missing-context cohorts with original four full35 reuse only after exact fresh generated/compiled postimage proof; retain all failed original artifacts and compiled control/admission work still open.')
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
gap=json.loads((P/'GAP_MATRIX.json').read_text());gap['migration_progress']['current_canonical']=receipt['actual_merge']
gap['frost_hysteresis_state_composition'].update(status='ACTUALLY_ADMITTED_PR1800_CANONICAL8DBE472_CONTEXT_RECEIPT_SEALED',scope='Bounded original model1 Frost primaryDIVD1 bottom6 explicit/fittedimplicit water/CDE, hys0/1/2 initial1/2, dense daily; actual prior parent source/evidence/native admission preserved.',whole_family_closed=False)
gap['frost_calendar_state_composition']=dict(status='ACTUALLY_ADMITTED_PR1801_CANONICAL1C3B500_CONTEXT_RECEIPT_SEALED',classification='BOUNDED_EXISTING_CALENDAR_AND_STATE_COMPOSITION',actual_canonical=receipt['actual_merge'],scope='Model1 Snow/Frost primaryDIVD1 bottom6 water/CDE hys0/1/2 initial1/2 explicit/fittedimplicit NPRINTDAY1 regular/monthly/explicit dates and reset; no subdaily/perstep.',receipt='FROST_CALENDAR_STATE02_MERGE_RECEIPT_V1.json',whole_family_closed=False)
def walk(value):
 if isinstance(value,dict):
  if value.get('id')=='frost-open-domains':
   value['current_availability']='Bounded dense Frost and original initialization/hysteresis and regular/monthly/explicit-date state composition admitted through PR1800/1801 on actual1c3b8725548c836c9a73570c2579dd6cdc683217. Boundary5/8 existing-state composition currently implemented, not qualified. Other chemical, AGE, subdaily/perstep, closed/front and broader boundary domains remain open.'
  for item in value.values():walk(item)
 elif isinstance(value,list):
  for item in value:walk(item)
walk(gap);gap['frost_boundary58_composition']=dict(status='FOUR_FIRST_FULL35_CONTEXTS_PASS_PRIVATE_OWNER_REPAIR_PENDING_COMPOSITION_QUALIFICATION',classification='MISSING_COMPOSITION',scope=q['scope'],contract='FROST_BOUNDARY03_CONTRACT_V1.json',whole_family_closed=False)
(P/'GAP_MATRIX.json').write_text(json.dumps(gap,indent=2)+'\n')
print('ACTUAL500_ADMISSION_JOINED_WITH_SIX_FILE_FROST_BOUNDARY_SOURCE_REPAIR_AND_COVERAGE')
