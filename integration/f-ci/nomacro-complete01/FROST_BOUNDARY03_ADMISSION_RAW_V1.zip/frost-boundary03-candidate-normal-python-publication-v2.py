"""Run the actual publication entry with ordinary Python bytecode defaults."""
from pathlib import Path
E=Path(__file__).parent
source=E/'frost-calendar-state02-candidate-normal-python-publication-observe-v3.py'
raw=source.read_text();before="output=E/'FROST_CALENDAR_STATE02_CANDIDATE_PUBLICATION_V3'"
assert raw.count(before)==1
code=raw.replace(before,"output=E/'FROST_BOUNDARY03_CANDIDATE_PUBLICATION_V2'")
exec(compile(code,str(source),'exec'),{'__file__':str(source),'__name__':'__main__'})

