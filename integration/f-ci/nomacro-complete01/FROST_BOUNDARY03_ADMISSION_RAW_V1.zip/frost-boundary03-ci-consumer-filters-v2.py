from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()=='3a69ddde0411dd455dea7b0f1ebeea1777d50a21'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
for name in ('PUBLIC','PUBLICATION'):
 q=json.loads((E/('FROST_BOUNDARY03_CANDIDATE_'+name+'_V1.json')).read_text());assert q['returncode']==0 and q['before']==q['after']
P=R/'integration/f-ci/nomacro-complete01';p=P/'FROST_BOUNDARY03_CONTRACT_V1.json';q=json.loads(p.read_text());assert 'ci_consumer_filters' not in q
q['ci_consumer_filters']={}
for name in ('mc-sol01-swp-reader.yml','mc-sol01-column-input.yml'):
 path='.github/workflows/'+name;a=git('show','HEAD:'+path).decode();before="      - 'app/solute_column/**'\n";assert a.count(before)==2
 b=a.replace(before,before+"      - 'tests/nomacro_drainage/frost_boundary_*.py'\n")
 (R/path).write_text(b,encoding='utf8',newline='\n')
 q['ci_consumer_filters'][path]=dict(before_lf_sha256=hashlib.sha256(a.encode()).hexdigest(),proposed_lf_sha256=hashlib.sha256(b.encode()).hexdigest(),ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if op!='equal'],reason='Existing verify_successor consumer must select changed Frost boundary source authority; no model/scientific dependency changes.')
p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8',newline='\n')
p=R/'tests/nomacro_drainage/frost_boundary_source_custody.py';s=p.read_text();a="    adapters=contract['read_only_archive_api']\n";assert s.count(a)==1
s=s.replace(a,a+"    adapters={**adapters,**contract['ci_consumer_filters']}\n")
p.write_text(s,encoding='utf8',newline='\n')
p=R/'tests/nomacro_drainage/frost_boundary_verify.py';s=p.read_text();old="SEALED='2fea6763df667db098374ebfac379b4c23d82f94'";assert s.count(old)==1;p.write_text(s.replace(old,"SEALED='"+'0'*40+"'"),encoding='utf8',newline='\n')
print('EXACT_TWO_EXISTING_CI_CONSUMER_SELECTORS_RECORDED_NO_APP_OR_SCIENCE_CHANGE')
