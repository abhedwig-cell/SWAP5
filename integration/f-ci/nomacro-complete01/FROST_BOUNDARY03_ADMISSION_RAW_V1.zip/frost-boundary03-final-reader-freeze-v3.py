from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).parent
path='app/hybrid_water/implicit_frost_source_guard.py';raw=(R/path).read_bytes().replace(b'\r\n',b'\n')
old=subprocess.check_output(['git','show','3250f0c59337334994b0e8edda624afe8f91b11f:'+path],cwd=R);a=old.decode();b=raw.decode()
q=json.loads((P/'FROST_BOUNDARY03_CONTRACT_V1.json').read_text());assert len(q['files'])==7
q['files'][path]=dict(added=False,before_lf_sha256=hashlib.sha256(old).hexdigest(),proposed_lf_sha256=hashlib.sha256(raw).hexdigest(),
 ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=True).get_opcodes() if op!='equal'])
q['read_only_source_guard_result']='FROST_BOUNDARY03_REAL_COMPILED_HEADCALC_SOURCE_GUARD_V2.json'
(P/'FROST_BOUNDARY03_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n')
shutil.copyfile(E/q['read_only_source_guard_result'],P/q['read_only_source_guard_result'])
print('ACTUAL_PRODUCTION_VALIDATOR_FROZEN_WITH_ORIGINAL_COMPILED_POSITIVES_AND_REFUSED_NUMERICAL_MUTANTS')
