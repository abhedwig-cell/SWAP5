"""Join complete independent evidence and explicit reader APIs with live recovery."""
from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).parent
sha=lambda raw:hashlib.sha256(raw).hexdigest();base='1c3b8725548c836c9a73570c2579dd6cdc683217'
contract=json.loads((P/'FROST_BOUNDARY03_CONTRACT_V1.json').read_text());adapters={}
for path in ('tests/nomacro_drainage/analytical_hydraulic_archives.py','tests/nomacro_drainage/frost_calendar_state_windows_local_science.py'):
 before=subprocess.check_output(['git','show',base+':'+path],cwd=R);after=(R/path).read_bytes().replace(b'\r\n',b'\n');a=before.decode();b=after.decode()
 adapters[path]=dict(before_lf_sha256=sha(before),proposed_lf_sha256=sha(after),
  ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=True).get_opcodes() if op!='equal'])
contract.update(read_only_archive_api=adapters,status='ALL24_INDEPENDENT_BUDGET_NATIVE_COLD_CONTROLS_AND_CURRENT_POSTIMAGES_PASS_PUBLIC_SOURCE_OWNER_PENDING',
 complete_scientific_source='3a30d3829d0355b316f93cc69daa280f01034817',
 actual_workflows=[45633407125,45633407248],independent_cohort='FROST_BOUNDARY03_COMPLETE24_CENTRAL_V1.json',
 new_public_owner='tests/nomacro_drainage/frost_boundary_verify.py',
 archive_api='Explicit immutable GitArchiveSource at real40-character Git revision. Filesystem API unchanged; actual single/multipart member bytes match. No pretend filesystem/source/head or mutable index projection.',
 next='Freeze actual current source, install four literal public callbacks, run actual clean14/56 PUBLIC and ordinary Python publication, four real committed/pushed negatives, applicable final-head CI, then actual canonical merge observers. Historical closure remains PARTIAL.')
(P/'FROST_BOUNDARY03_CONTRACT_V1.json').write_text(json.dumps(contract,indent=2)+'\n')
for name in ('FROST_BOUNDARY03_COMPLETE24_CENTRAL_V1.json','FROST_BOUNDARY03_REAL_GIT_ARCHIVE_API_CONTROLS_V1.json','FROST_BOUNDARY03_ACTUAL_CANONICAL500_PARENT_ADMISSION_V1.json'):
 assert not (P/name).exists();shutil.copyfile(E/name,P/name)
inherited=json.loads((E/'FROST_BOUNDARY03_FRESH_ALL_CANONICAL500_INHERITED_BYTES_V1.json').read_text())
summary=dict(status=inherited['status'],files=len(inherited['files']),total_bytes=inherited['total_bytes'],actual_parent=inherited['actual_parent'],
 actual_full_fresh_result_sha256=sha((E/'FROST_BOUNDARY03_FRESH_ALL_CANONICAL500_INHERITED_BYTES_V1.json').read_bytes()),
 fresh_eol_inventory_executions=1,compiler_executions=0,model_executions=0)
(P/'FROST_BOUNDARY03_INITIAL_PARENT_BYTE_CUSTODY_V1.json').write_text(json.dumps(summary,indent=2)+'\n')
joint=R/'tests/nomacro_drainage/initial_profile_age_groundwater_verify.py';raw=joint.read_text()
for name in ('guard_previous_source','verify','strip_current_evidence','publication_dependencies_unchanged'):
 args='text' if name=='strip_current_evidence' else ''
 before=' import frost_calendar_state_verify as calendar_owner\n return calendar_owner.'+name+'('+args+')\n'
 after=' import frost_boundary_verify as boundary_owner\n return boundary_owner.'+name+'('+args+')\n'
 assert raw.count(before)==1;raw=raw.replace(before,after,1)
joint.write_text(raw)
status=json.loads((P/'STATUS.json').read_text());status['last_commit']='3a30d3829d0355b316f93cc69daa280f01034817'
status['frost_boundary03_recovery'].update(complete_scientific_source=status['last_commit'],complete_workflows=[45633407125,45633407248],
 complete_workflows_status='BOTH_O0_O2_JOBS_SUCCESS_ON_BOTH_PLATFORMS',independent_contexts=24,primary_days=840,
 native_samples=168,exact_cold_windows=72,actual_compiled_refusals=1196,actual_transaction_contexts=48,
 prior_contexts_reused_without_full_period_replay=20,independent_evidence='FROST_BOUNDARY03_COMPLETE24_CENTRAL_V1.json',
 fresh_inherited_parent_files=summary['files'],fresh_inherited_parent_bytes=summary['total_bytes'],
 next='Commit/freeze actual source and self-only seal; real clean14/56 PUBLIC and ordinary publication; four one-file committed/pushed source/raw/inherited/publication negatives; final-head CI and actual merge observations. Use current branch and owning chat lifecycle; do not finish or delete active resources.')
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
gap=json.loads((P/'GAP_MATRIX.json').read_text());gap['frost_boundary58_composition'].update(status='ALL24_SOURCE_SCIENCE_AND_CURRENT_POSTIMAGES_INDEPENDENTLY_PASS_PUBLIC_ADMISSION_PENDING',scope=contract['scope'],
 whole_family_closed=False,primary_days=840,actual_compiled_refusals=1196,
 qualification='FROST_BOUNDARY03_COMPLETE24_CENTRAL_V1.json',admission='ACTUAL_FINAL_MERGE_RECEIPT_REQUIRED')
(P/'GAP_MATRIX.json').write_text(json.dumps(gap,indent=2)+'\n')
print('INDEPENDENT24_AND_REAL_CANONICAL500_CUSTODY_PERSISTED_FOUR_LITERAL_PUBLIC_CALLBACKS_INSTALLED')
