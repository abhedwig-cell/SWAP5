"""Freeze seven actual APP files, retain read-only failures and select controls."""
import difflib,hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest();base='3250f0c59337334994b0e8edda624afe8f91b11f'
api=json.loads((E/'FROST_BOUNDARY03_SECOND_ORIGINAL_ARTIFACTS_API_V2.json').read_text())
for item in api['artifacts']:
 platform='WINDOWS' if 'windows' in item['name'] else 'UBUNTU';opt='O0' if '-O0-' in item['name'] else 'O2'
 name='FROST_BOUNDARY03_'+platform+'_'+opt+'_ORIGINAL_V2';path=E/(name+'.zip');raw=path.read_bytes()
 assert len(raw)==item['size_in_bytes'] and sha(raw)==item['digest'].split(':')[1]
 with zipfile.ZipFile(path) as z:
  members={key:dict(bytes=len(z.read(key)),sha256=sha(z.read(key))) for key in z.namelist()}
  cohort=json.loads(z.read('current/RESULT.json'));assert cohort['status']=='FAILED_ACTUAL_FROST_BOUNDARY_COHORT_NOT_QUALIFIED'
  assert cohort['contexts'][0]['completed_full35_reused_without_model_replay'] and cohort['contexts'][1]['returncode']==1
 assert not (P/(name+'.zip')).exists();shutil.copyfile(path,P/(name+'.zip'))
 record=dict(status='ORIGINAL_CURRENT_COMPILED_POSTIMAGE_PASS_AND_READ_ONLY_SOURCE_GUARD_REFUSAL_PRESERVED_NOT_ADMITTED',
  archive=name+'.zip',bytes=len(raw),sha256=sha(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=sha(raw))],
  members=members,official_artifact=item,actual_source=api['source'],new_accepted_full_periods=0,
  original_completed_context_preserved_by_current_compiled_postimage=True,cohort_qualified=False)
 (P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
q=json.loads((P/'FROST_BOUNDARY03_CONTRACT_V1.json').read_text());names=[Path(p).name for p in q['files']]+['implicit_frost_source_guard.py'];files={}
for name in names:
 path='app/hybrid_water/'+name;raw=(R/path).read_bytes().replace(b'\r\n',b'\n');item=dict(added=name=='frost_boundary_composition.py',proposed_lf_sha256=sha(raw))
 if not item['added']:
  old=subprocess.check_output(['git','show',base+':'+path],cwd=R);a=old.decode();b=raw.decode()
  item.update(before_lf_sha256=sha(old),ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=True).get_opcodes() if op!='equal'])
 files[path]=item
q.update(files=files,status='FOUR_CURRENT_COMPLETE_COMPILED_POSTIMAGES_AND_EXACT_QUALIFIED_HEADCALC_RECONSTRUCTION_PASS_NOT_QUALIFIED',
 read_only_source_guard_correction='Original boundary5/8 trial receipt was already installed. Reconstruct via exact existing boundary5 inverse and canonical8 form; complete ordinary HeadCalc SHA remains frozen. Actual failed-source O0/O2 generated5 bodies reconstruct exactly; an expression corruption is refused. No numerical producer source changed.',
 next='Execute seven missing full35/cold contexts per platform/opt, retain all independent failures; apply actual compiled native/root/active transactions to eight contexts including preserved original first binaries with their genuine original identities.')
(P/'FROST_BOUNDARY03_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n')
for name in ('ubuntu','windows'):
 path=R/'.github/workflows'/('nomacro-frost-boundary03-'+name+'.yml');text=path.read_text();old='Run eight actual original lower-boundary full35 and own cold contexts'
 assert text.count(old)==1;text=text.replace(old,'Run missing full35 contexts and actual compiled native and transaction controls')
 path.write_text(text)
status=json.loads((P/'STATUS.json').read_text());status['last_commit']='05c588fd75d7b66c9a37b86bcdacf115c9e2b7b4'
status['frost_boundary03_recovery'].update(second_scientific_source=api['source'],second_workflows=[45628685020,45628687299],
 second_failure='All four new generated/compiled postimage comparisons PASS; the newly compiled implicit boundary5 body was refused by its read-only inherited source reconstruction before model days. Actual O0/O2 generated bodies reconstruct the exact frozen ordinary HeadCalc after the literal boundary receipt inverse; corrupted expression is refused.',
 next='Push third source freeze, run seven missing contexts and compiled native/root/transaction controls; observe terminal outcomes and preserve original bytes. Source/raw admission and whole historical completion remain open.')
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
print('SEVEN_ACTUAL_APP_FILES_FROZEN_FOUR_ORIGINAL_REFUSAL_ARTIFACTS_RETAINED_AND_NATIVE_CONTROLS_SELECTED')
