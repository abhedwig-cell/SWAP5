from pathlib import Path
from contextlib import ExitStack
import argparse,json,sys,time
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive
from frost_boundary_archive_science import case_audit
p=argparse.ArgumentParser();p.add_argument('--platform',required=True);p.add_argument('--optimization',required=True);a=p.parse_args()
name='FROST_BOUNDARY03_'+a.platform.upper()+'_'+a.optimization+'_ORIGINAL_V3';started=time.perf_counter();observed=[]
with ExitStack() as stack:
 store=Archive(R/'integration/f-ci/nomacro-complete01',name,stack)
 for key in store.record['successful_case_names']:
  parts=key.split('-');case=dict(name=key,kind=parts[0],bottom=int(parts[1][-1]),implicit=int(parts[2][-1]))
  q=case_audit(store,key,case);observed.append(q);print('INDEPENDENT_ARCHIVE_PASS',key,a.platform,a.optimization,flush=True)
q=dict(status='FIVE_ACTUAL_FULL35_INDEPENDENT_DECIMAL_NATIVE_COLD_SOURCE_AND_ACTIVE_CONTROLS_PASS',
 platform=a.platform,optimization=a.optimization,contexts=observed,seconds=time.perf_counter()-started,
 compiler_executions=0,model_executions=0)
(E/('FROST_BOUNDARY03_'+a.platform.upper()+'_'+a.optimization+'_FIRST_FIVE_CENTRAL_V1.json')).write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],q['seconds'],flush=True)
