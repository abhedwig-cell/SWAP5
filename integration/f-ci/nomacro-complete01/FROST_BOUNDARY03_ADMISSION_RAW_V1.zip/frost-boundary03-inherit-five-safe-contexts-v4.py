"""Retain actual five completed contexts through fresh whole postimages."""
from pathlib import Path
import ast,textwrap
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');p=R/'tests/nomacro_drainage/frost_boundary_portable.py';raw=p.read_text()
start=raw.index("            old=json.loads((a.previous_proof/'current/RESULT.json').read_text())")
end=raw.index('        for bottom,kind,implicit in itertools.product',start)
block=raw[start:end]
old="            prior=old['contexts'][0];name='water-bottom5-implicit0-hys2-initial2'\n            assert old['source']=='16988131766408867b0c1fa94a3a45cabe68b6fe'\n            assert prior['case']==name and prior['returncode']==0\n            science=prior['science'];assert science['source']==old['source']\n            assert science['status']=='CANDIDATE_ACTUAL_FROST_SWDIVD1_WATER_SHORT_PASS_NOT_ADMITTED'\n"
assert block.count(old)==1
replacement="            assert old['source']=='6049f82bcf265ef17de2ff86a69b4ef4c33f768f'\n            completed=[x for x in old['contexts'] if x.get('compiled_controls',{}).get('returncode')==0]\n            assert len(completed)==5\n"
block=block.replace(old,replacement,1)
begin=block.index("            folder=a.output/'preservation'")
prefix=block[:begin];body=block[begin:]
body=body.replace("folder=a.output/'preservation';folder.mkdir();inputs=folder/'inputs';prepare('water',0,5,inputs)","folder=a.output/'preservation'/name;folder.mkdir(parents=True);inputs=folder/'inputs';prepare(kind,implicit,bottom,inputs)")
body=body.replace("build=a.build_root/'current-explicit-preservation'","build=a.build_root/'current-preservation'/name")
body=body.replace("record=dict(case=name,source=old['source'],actual_current_compiler=head,","record=dict(case=name,source=science['source'],actual_current_compiler=head,")
body=body.replace("                        original_science= science,current_generated_compiled=comparison,","                        original_science=science,current_generated_compiled=comparison,\n                        compiled_controls=prior['compiled_controls'],")
assert "prepare('water',0,5" not in body and 'compiled_controls=prior' in body
intro="            for prior in completed:\n                name=prior['case'];parts=name.split('-');kind=parts[0];bottom=int(parts[1][-1]);implicit=int(parts[2][-1])\n                assert bottom in (5,8) and kind in ('water','cde') and not (bottom==8 and implicit)\n                profile=a.previous_proof/'current'/name/'science'\n                science=json.loads((profile/'RESULT.json').read_text())\n                assert science['source'] in ('16988131766408867b0c1fa94a3a45cabe68b6fe','6049f82bcf265ef17de2ff86a69b4ef4c33f768f')\n                assert science['status']=='CANDIDATE_ACTUAL_FROST_SWDIVD1_'+kind.upper()+'_SHORT_PASS_NOT_ADMITTED'\n"
raw=raw[:start]+prefix+intro+textwrap.indent(body,'    ')+raw[end:]
old="        for bottom,kind,implicit in itertools.product((5,8),('water','cde'),(0,1)):\n            assert source()==head"
assert raw.count(old)==1;raw=raw.replace(old,old.replace('            assert source()==head','            if bottom==8 and implicit:continue\n            assert source()==head'))
old="            if a.previous_proof is not None and name=='water-bottom5-implicit0-hys2-initial2':continue"
assert raw.count(old)==1;raw=raw.replace(old,"            if name in {x['case'] for x in q['contexts']}:continue")
start=raw.index('        if a.previous_proof is not None:\n            # Materialize the actual original accepted case')
end=raw.index("        assert len(q['contexts'])==8",start)
raw=raw[:start]+raw[end:];raw=raw.replace("assert len(q['contexts'])==8","assert len(q['contexts'])==6")
raw=raw.replace('EIGHT_ACTUAL_FROST_BOUNDARY_FULL35_COLD_COMPILED_NATIVE_AND_TRANSACTIONS_PASS_NOT_ADMITTED','SIX_ACTUAL_BOUNDED_FROST_BOUNDARY_FULL35_COLD_COMPILED_NATIVE_AND_TRANSACTIONS_PASS_NOT_ADMITTED')
ast.parse(raw);p.write_text(raw);print('FIVE_ACTUAL_COMPLETE_CONTEXTS_REUSED_ONLY_AFTER_CURRENT_FULL_COMPILED_POSTIMAGES_ONE_MISSING_SCIENCE_SELECTED')
