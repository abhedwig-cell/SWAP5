from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='06396239eb3e58dda449ec122e01241c092298fe'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
for name in ('PUBLIC','PUBLICATION'):
 q=json.loads((E/('FROST_BOUNDARY03_CANDIDATE_'+name+'_V2.json')).read_text());assert q['before']==q['after'] and q['before']['head']==head and q['returncode']==0
P=R/'integration/f-ci/nomacro-complete01';p=P/'FROST_BOUNDARY03_CONTRACT_V1.json';q=json.loads(p.read_text());assert len(q.pop('ci_consumer_filters'))==2
q['ci_dependency_materialization']={}
line='            /integration/f-ci/nomacro-complete01/FROST_BOUNDARY03_*.json\n'
for name in ('mc-sol01-swp-reader.yml','mc-sol01-column-input.yml'):
 path='.github/workflows/'+name;a=git('show','1c3b8725548c836c9a73570c2579dd6cdc683217:'+path).decode();anchor='            /integration/f-ci/nomacro-complete01/FROST_CALENDAR_STATE02_*\n';assert a.count(anchor)==1
 b=a.replace(anchor,anchor+line)
 (R/path).write_text(b,encoding='utf8',newline='\n')
 q['ci_dependency_materialization'][path]=dict(before_lf_sha256=hashlib.sha256(a.encode()).hexdigest(),proposed_lf_sha256=hashlib.sha256(b.encode()).hexdigest(),ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if op!='equal'],reason='Materialize only current frozen JSON declarations for existing source authority. Full scientific ZIP payload remains actual immutable Git API bytes. Original path triggers, commands, limits and test bodies unchanged.')
p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8',newline='\n')
p=R/'tests/nomacro_drainage/frost_boundary_source_custody.py';s=p.read_text();assert s.count("contract['ci_consumer_filters']")==1;p.write_text(s.replace("contract['ci_consumer_filters']","contract['ci_dependency_materialization']"),encoding='utf8',newline='\n')
p=R/'tests/nomacro_drainage/frost_boundary_verify.py';s=p.read_text();old="SEALED='dccb2d2a64502190eb7a9ac73e1effb9eb24bdc2'";assert s.count(old)==1;s=s.replace(old,"SEALED='"+'0'*40+"'")
old='def strip_current_evidence(text):return previous.strip_current_evidence(text)';assert s.count(old)==1
new='def strip_current_evidence(text):\n    line='+repr(line)+'\n    assert text.count(line)==1\n    return previous.strip_current_evidence(text.replace(line,\'\',1))'
p.write_text(s.replace(old,new),encoding='utf8',newline='\n')
print('TWO_EXACT_JSON_ONLY_SPARSE_DEPENDENCIES_ORIGINAL_WORKFLOW_TRIGGERS_AND_COMMANDS_RETAINED')
