"""Retry only the exact cancelled checkout job after connector transport failure."""
import http.client,json,os,subprocess
from pathlib import Path
E=Path(__file__).parent;R='C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01'
run_id=45647458297;job_id=139322202625;candidate='74ecc55765df548e758605f3566bc93558a6fefb'
r=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\npath=abhedwig-cell/SWAP5.git\n\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'),timeout=30)
assert r.returncode==0,'Existing repository authentication unavailable; no credentials printed'
values=dict(line.split(b'=',1) for line in r.stdout.splitlines() if b'=' in line);token=values.get(b'password');assert token
headers={'Authorization':'Bearer '+token.decode(),'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-exact-cancelled-checkout-job-recovery'}
def request(method,path):
 connection=http.client.HTTPSConnection('api.github.com',timeout=60);connection.request(method,'/repos/abhedwig-cell/SWAP5'+path,body=b'' if method=='POST' else None,headers=headers);response=connection.getresponse();status=response.status;raw=response.read();connection.close();return status,json.loads(raw) if raw else None
status,run=request('GET','/actions/runs/'+str(run_id));assert status==200 and run['head_sha']==candidate
status,jobs=request('GET','/actions/runs/'+str(run_id)+'/jobs?filter=latest&per_page=100');assert status==200
q=dict(repository='abhedwig-cell/SWAP5',run_id=run_id,job_id=job_id,actual_candidate=candidate,before_run=run,before_jobs=jobs,connector_rerun_failed_twice=True,credentials_printed=False)
active=any(v['status']!='completed' for v in jobs['jobs'])
if active:q.update(status='RETRY_ALREADY_ACTIVE_NO_DUPLICATE_POST',post_sent=False)
else:
 assert run['conclusion']=='cancelled' and any(v['id']==job_id and v['conclusion']=='cancelled' for v in jobs['jobs'])
 assert len(jobs['jobs'])==1, 'Never rerun any successful sibling job'
 status,body=request('POST','/actions/runs/'+str(run_id)+'/rerun');q.update(status='EXACT_CANCELLED_JOB_RERUN_API_ACCEPTED' if status in (201,202) else 'EXACT_JOB_RERUN_API_REFUSED',post_sent=True,http_status=status,response=body)
del token,values,r,headers
with (E/'FROST_BOUNDARY03_PR1802_LRV_SINGLE_JOB_WORKFLOW_RERUN_REQUEST_V2.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2)
print(json.dumps({k:v for k,v in q.items() if k not in ('before_run','before_jobs')}))
assert q['status'] in ('EXACT_CANCELLED_JOB_RERUN_API_ACCEPTED','RETRY_ALREADY_ACTIVE_NO_DUPLICATE_POST')

