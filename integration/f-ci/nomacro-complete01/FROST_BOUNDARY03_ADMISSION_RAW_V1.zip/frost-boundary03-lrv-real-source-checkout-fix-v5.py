from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);assert git('rev-parse','HEAD').decode().strip()=='a01ae34248fda2b3abdb074a0f3d768ff3dbc334'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
path='.github/workflows/swap431-root-lrv-constant.yml';a=git('show','HEAD:'+path).decode();anchor='      - uses: actions/checkout@v4\n'
block='''        with:
          filter: blob:none
          sparse-checkout-cone-mode: false
          sparse-checkout: |
            /src/
            /tests/fmig431/
            /tests/physics/
            /tests/fsi/
            /.github/workflows/
'''
assert a.count(anchor)==1;b=a.replace(anchor,anchor+block);assert b.replace(block,'',1)==a==git('show','1c3b8725548c836c9a73570c2579dd6cdc683217:'+path).decode()
(R/path).write_text(b,encoding='utf8',newline='\n')
p=P/'FROST_BOUNDARY03_CONTRACT_V1.json';q=json.loads(p.read_text());assert path not in q['ci_dependency_materialization']
q['ci_dependency_materialization'][path]=dict(before_lf_sha256=hashlib.sha256(a.encode()).hexdigest(),proposed_lf_sha256=hashlib.sha256(b.encode()).hexdigest(),ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if op!='equal'],reason='Original constant-LRV qualifier reads onlysrc, tests/fmig431, tests/physics and tests/fsi. Keep exact historical job, timeout, compiler installation, O0/O2 commands and test bodies; fetch real source blobs lazily and materialize this complete actual dependency surface. Prior final-head run cancelled after25min while unfiltered repository fetch had not completed, before any compiler/model; rerun API routes returned500.')
q['status']='ALL24_SCIENCE_PRESERVED_STRICT_ARCHIVED_COMMIT_READER_AND_COMPLETE_SMALL_LRV_SOURCE_CHECKOUT_FIX_CURRENT_HEAD_GATES_PENDING'
p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8',newline='\n')
p=R/'tests/nomacro_drainage/frost_boundary_verify.py';s=p.read_text();old="SEALED='61f099f4c5ea2a496e6da5d6d55ca57d93192fea'";assert s.count(old)==1;p.write_text(s.replace(old,"SEALED='"+'0'*40+"'"),encoding='utf8',newline='\n')
p=P/'STATUS.json';s=json.loads(p.read_text());s['next_action']='Freeze exact strict archive-Git reader plus literal LRV source-checkout dependency surface. Run current-head PUBLIC/ordinary publication and four genuine new pushed negatives; collect all current applicable CI and exact original eight job logs. No physical period replay for either read-only/checkout repair. Continue independent batch04 remaining32cases after preserving first-cohort raw and day22water guard failure.'
s['frost_boundary03_last_read_only_repairs']=dict(archived_temporary_commit='Two genuine exact Git objects and10corruptions checked as archived data; actual canonical object still checked in real Git.',LRV_checkout='Complete actualsrc/fmig431/physics/fsi dependency paths; historical job commands/timeouts/compilers untouched.',APP_src_tools_reference_changed=False,scientific_full_period_replays=0,previous_a01_PUBLIC_seconds=593.6505351997912,previous_a01_ordinary_PUBLICATION_seconds=481.294422800187)
p.write_text(json.dumps(s,indent=2)+'\n',encoding='utf8',newline='\n');print('EXACT_LRV_SOURCE_CHECKOUT_FIX_FROZEN_ORIGINAL_JOB_AND_ALL_COMPILE_TEST_BODIES_UNCHANGED')
