from pathlib import Path
E=Path(__file__).parent;s=(E/'frost-boundary03-resumable-real-negatives-v5.py').read_text()
s=s.replace("C='74ecc55765df548e758605f3566bc93558a6fefb'","C='a01ae34248fda2b3abdb074a0f3d768ff3dbc334'")
low=s.index("out=E/'FROST_BOUNDARY03_BOTHCI_FINAL_NEGATIVES_V3.json'");high=s.index('save=lambda:',low)
s=s[:low]+"""out=E/'FROST_BOUNDARY03_A01_FINAL_NEGATIVES_V1.json'
if out.exists():
 q=json.loads(out.read_text());assert q['candidate']==C and q['owner_task']=='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
else:
 for role in PATHS:
  branch='codex/nomacro-frost-boundary-negative-'+role.lower()+'02'
  assert not git('ls-remote','--heads','origin','refs/heads/'+branch)
  assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=R).returncode==1
 q=dict(status='RUNNING',candidate=C,owner_task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713',never_merge=True,controls=[],compiler_executions=0,model_executions=0)
"""+s[high:]
s=s.replace('FROST_BOUNDARY03_CANDIDATE_PUBLIC_V3','FROST_BOUNDARY03_CANDIDATE_PUBLIC_V4').replace('FROST_BOUNDARY03_CANDIDATE_PUBLICATION_V3','FROST_BOUNDARY03_CANDIDATE_PUBLICATION_V4')
s=s.replace("+role.lower()+'01'","+role.lower()+'02'")
old="   if role=='PUBLICATION':changed=original+b'\\n \\n';recipe=dict(append_only_JSON_whitespace=True,original_document_values_unchanged=True)\n   else:\n    assert role=='INHERITED';offset=len(original)//2;"
new="   if role=='SOURCE':\n    before=b'SWHYST=2, SWINCO=2, NPRINTDAY=1';assert original.count(before)==1;changed=original.replace(before,b'SWHYST=2, SWINCO=1, NPRINTDAY=1',1);recipe=dict(original_expression=before.decode(),never_merge_test_guard='Unqualified initialization1 for bounded03 boundary58')\n   elif role=='PUBLICATION':changed=original+b'\\n \\n';recipe=dict(append_only_JSON_whitespace=True,original_document_values_unchanged=True)\n   else:\n    assert role in ('RAW','INHERITED');offset=len(original)//2;"
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('FROST_BOUNDARY03_BOTHCI_RESUME3_','FROST_BOUNDARY03_A01_FINAL_')
s=s.replace('   for attempt in (1,2,3):','   first_attempt=len(item.get(\'resumed_push_attempts\',[]))+1\n   for attempt in range(first_attempt,first_attempt+3):').replace('    if attempt==3:response.check_returncode()','    if attempt==first_attempt+2:response.check_returncode()')
compile(s,'strict-actual-a01-four-controls','exec');p=E/'frost-boundary03-a01-real-negative-controls-v6.py';assert not p.exists();p.write_text(s,encoding='utf8');print('FOUR_NEW_ACTUAL_A01_BRANCH02_CONTROLS_PREPARED_UNIQUE_EVIDENCE_NAMES_NO_OLD_RESULTS_REWRITTEN')
