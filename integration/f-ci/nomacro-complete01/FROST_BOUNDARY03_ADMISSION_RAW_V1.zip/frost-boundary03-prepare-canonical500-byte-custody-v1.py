from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage'
raw=(T/'frost_calendar_state_inherited_custody.py').read_text()
assert raw.count("BASE='8dbe3db7c7832dd6a1f86c4275cd43f054552df3'")==1
raw=raw.replace("BASE='8dbe3db7c7832dd6a1f86c4275cd43f054552df3'","BASE='1c3b8725548c836c9a73570c2579dd6cdc683217'")
raw=raw.replace('admitted472','admitted500').replace('ALL_ACTUAL_CANONICAL472_','ALL_ACTUAL_CANONICAL500_')
target=T/'frost_boundary_inherited_custody.py'
with target.open('x',encoding='utf8') as f:f.write(raw)
