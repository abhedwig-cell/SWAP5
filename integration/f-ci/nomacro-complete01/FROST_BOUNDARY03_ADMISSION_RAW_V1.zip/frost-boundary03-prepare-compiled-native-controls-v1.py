"""Retain existing real native attacks, binding the new actual boundary codec."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage'
text=(T/'frost_history_state_root_controls.py').read_text()
edits={
 '"""Actual compiled native revision2 root-tail refusals; no accepted model days."""':'"""Actual compiled Frost boundary58 root-tail refusals; no accepted days."""',
 "    expected = b'S5FIC002' if project.solute else b'S5FIW002'":"    from frost_boundary_composition import selection,codec\n    selected=selection(project.input_directory,project.original_output)\n    assert selected and selected['implicit']==1\n    expected=codec(selected)",
 '    assert mode in (0,1)':'    assert mode==2',
 '[4,project.nodes,int(project.solute),1,mode,6,1,0]':"[4,project.nodes,int(project.solute),1,mode,selected['bottom'],1,0]",
 "b'S5FIC001' if project.solute else b'S5FIW001'":"b'S5FIC002' if project.solute else b'S5FIW002'",
 "b'S5FDC001' if project.solute else b'S5FDW001'":"b'S5FBC001' if project.solute else b'S5FBW001'",
 "'ACTUAL_COMPILED_IMPLICIT_FROST_ROOT_NATIVE_REFUSALS_PASS'":"'ACTUAL_COMPILED_IMPLICIT_FROST_BOUNDARY_ROOT_NATIVE_REFUSALS_PASS'",
 "        actual_BUILD_sha256=m.sha(build/'BUILD.json'), original_checkpoint_sha256=before,":"        actual_compiler_source=profile['source'],actual_boundary=selected['bottom'],\n        actual_BUILD_sha256=m.sha(build/'BUILD.json'), original_checkpoint_sha256=before,"
}
for before,after in edits.items():
 assert text.count(before)==1,before
 text=text.replace(before,after,1)
with (T/'frost_boundary_root_controls.py').open('x',encoding='utf8') as f:f.write(text)
text=(T/'frost_history_state_controls.py').read_text()
text=text.replace('"""Actual native attacks and transactions for the new bounded Frost states."""','"""Real compiled native, root and transaction controls for Frost boundary58."""')
assert text.count('frost_history_state_root_controls.py')==1
text=text.replace('frost_history_state_root_controls.py','frost_boundary_root_controls.py')
text=text.replace('ACTUAL_FROST_STATE_COMPILED_NATIVE_ROOT_SNOW_AND_ACTIVE_FROST_TRANSACTIONS_PASS_NOT_ADMITTED','ACTUAL_FROST_BOUNDARY_COMPILED_NATIVE_ROOT_SNOW_AND_ACTIVE_TRANSACTIONS_PASS_NOT_ADMITTED')
with (T/'frost_boundary_controls.py').open('x',encoding='utf8') as f:f.write(text)
print('NEW_BOUNDARY_REAL_COMPILED_NATIVE_AND_ACTIVE_TRANSACTION_CONTROLLERS_PREPARED')
