from pathlib import Path
E=Path(__file__).parent
raw=(E/'frost-calendar-state02-genuine-signed-object-import-v1.py').read_text()
assert raw.count('FROST_CALENDAR_STATE02_PR1801_')==1
with (E/'frost-boundary03-genuine-signed-object-import-v1.py').open('x',encoding='utf8') as f:
 f.write(raw.replace('FROST_CALENDAR_STATE02_PR1801_','FROST_BOUNDARY03_PR1802_'))
