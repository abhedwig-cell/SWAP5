from pathlib import Path
E=Path(__file__).parent
raw=(E/'frost-calendar-state02-both-ci-negative-controls-v3.py').read_text()
raw=raw.replace('FROST_CALENDAR_STATE02','FROST_BOUNDARY03').replace('frost-calendar','frost-boundary')
raw=raw.replace('codex/nomacro-frost-calendar-negative-','codex/nomacro-frost-boundary-negative-')
raw=raw.replace("role.lower()+'02'","role.lower()+'01'")
raw=raw.replace("'app/hybrid_water/frost_calendar_state.py'","'app/hybrid_water/frost_boundary_composition.py'")
raw=raw.replace('FROST_BOUNDARY03_UBUNTU_O0_ORIGINAL_V1.zip.part001','FROST_BOUNDARY03_UBUNTU_O0_ORIGINAL_V4.zip.part001')
raw=raw.replace('FROST_BOUNDARY03_CANDIDATE_PUBLIC_V3','FROST_BOUNDARY03_CANDIDATE_PUBLIC_V1').replace('FROST_BOUNDARY03_CANDIDATE_PUBLICATION_V3','FROST_BOUNDARY03_CANDIDATE_PUBLICATION_V1')
raw=raw.replace("result['coadmission']['contexts'] == 500","result['coadmission']['contexts'] == 524")
old="            proof_paths = git('diff','--name-only','8dbe3db7c7832dd6a1f86c4275cd43f054552df3',candidate,'--','integration/f-ci/nomacro-complete01').splitlines()\n            missing = [p for p in proof_paths + [path] if not (root/p).is_file()]"
new="            # Actual source/raw readers use the explicit immutable Git API.\n            # Materialize only the single genuine mutation target, not whole archives.\n            missing = [path] if not (root/path).is_file() else []"
assert raw.count(old)==1;raw=raw.replace(old,new,1)
old="                old = b'domains.update(SWHYST={0,1,2},'\n                assert original.count(old) == 1\n                changed = original.replace(old, old.replace(b'{0,1,2}', b'{0,1,2,3}'), 1)\n                recipe = dict(original_expression=old.decode(), never_merge_test_guard='SWHYST domain expanded to 0,1,2,3')"
new="                old = b'SWHYST=2, SWINCO=2, NPRINTDAY=1'\n                assert original.count(old) == 1\n                changed = original.replace(old, b'SWHYST=2, SWINCO=1, NPRINTDAY=1', 1)\n                recipe = dict(original_expression=old.decode(), never_merge_test_guard='Unqualified pressure initialization1 selected for boundary58')"
assert raw.count(old)==1;raw=raw.replace(old,new,1)
start=raw.index("            dependency_names=(")
end=raw.index("    assert git('rev-parse','HEAD') == candidate and clean()",start)
raw=raw[:start]+raw[end:]
target=E/'frost-boundary03-real-negative-controls-v1.py'
with target.open('x',encoding='utf8') as f:f.write(raw)
print('FOUR_REAL_SINGLE_FILE_COMMITTED_PUSHED_NEVER_MERGE_CONTROLS_PREPARED')
