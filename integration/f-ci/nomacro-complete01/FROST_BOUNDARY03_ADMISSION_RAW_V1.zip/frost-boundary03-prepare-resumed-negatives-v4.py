from pathlib import Path
E=Path(__file__).parent;s=(E/'frost-boundary03-real-negative-controls-v3.py').read_text(encoding='utf-8-sig')
old="    for branch in branches.values():\n        assert not git('ls-remote', '--heads', 'origin', 'refs/heads/'+branch)\n        assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch], cwd=root).returncode == 1"
new="""    failed = json.loads((evidence/'FROST_BOUNDARY03_BOTHCI_FINAL_NEGATIVES_V1.json').read_text())
    assert failed['candidate']==candidate and len(failed['controls'])==1
    assert failed['controls'][0]['head']=='332b7963ae8548399f61e428b0e1195f739e6fd2'
    assert failed['controls'][0]['status']=='ACTUAL_COMMITTED_PENDING_PUSH'
    for role,branch in branches.items():
        remote=git('ls-remote','--heads','origin','refs/heads/'+branch)
        if role=='SOURCE':
            assert git('rev-parse',branch)==failed['controls'][0]['head']
            assert git('show','-s','--format=%P',branch)==candidate
            assert not remote or remote.split()[0]==failed['controls'][0]['head']
        else:
            assert not remote
            assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=root).returncode==1"""
assert s.count(old)==1;s=s.replace(old,new)
old="            subprocess.run(['git','switch','-c',branches[role]], cwd=root, check=True, capture_output=True)";new="            subprocess.run(['git','switch',*([branches[role]] if role=='SOURCE' else ['-c',branches[role]])],cwd=root,check=True,capture_output=True)";assert s.count(old)==1;s=s.replace(old,new)
old='            original = file.read_bytes()';new="            original = subprocess.check_output(['git','show',candidate+':'+path],cwd=root) if role=='SOURCE' else file.read_bytes()";assert s.count(old)==1;s=s.replace(old,new)
old="            subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m',\n                            'NEVER MERGE bounded existing Frost calendar '+role.lower()+' public negative'], cwd=root, check=True, capture_output=True)";new="            if role!='SOURCE':\n    "+old;assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('FROST_BOUNDARY03_BOTHCI_FINAL_NEGATIVES_V1.json','FROST_BOUNDARY03_BOTHCI_FINAL_NEGATIVES_V2.json',1) if False else s
# Retain the first failed report as immutable; only the new output declaration changes.
old="    record_path = evidence/'FROST_BOUNDARY03_BOTHCI_FINAL_NEGATIVES_V1.json'";assert s.count(old)==1;s=s.replace(old,"    record_path = evidence/'FROST_BOUNDARY03_BOTHCI_FINAL_NEGATIVES_V2.json'")
s=s.replace('_PUSH_V1','_PUSH_V2').replace('_PUBLIC_V1','_PUBLIC_V2').replace('_SCOPE_V1','_SCOPE_V2')
s=s.replace("    save = lambda:","    record['prior_failed_push_report']='FROST_BOUNDARY03_BOTHCI_FINAL_NEGATIVES_V1.json'\n    save = lambda:")
compile(s,'resumed-real-negatives-v4','exec')
p=E/'frost-boundary03-real-negative-controls-v4.py';assert not p.exists();p.write_text(s,encoding='utf8');print('RESUME_EXACT_EXISTING_SOURCE_NEGATIVE_NO_NEW_COMMIT_NO_OLD_EVIDENCE_OVERWRITE')
