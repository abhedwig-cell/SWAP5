from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).parent;P=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01')
api=json.loads((E/'FROST_BOUNDARY03_FOURTH_ORIGINAL_ARTIFACTS_API_V4.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for item in api['artifacts']:
 platform='WINDOWS' if 'windows' in item['name'] else 'UBUNTU';opt='O0' if '-O0-' in item['name'] else 'O2'
 name='FROST_BOUNDARY03_'+platform+'_'+opt+'_ORIGINAL_V4';raw=(E/(name+'.zip')).read_bytes()
 assert len(raw)==item['size_in_bytes'] and sha(raw)==item['digest'].split(':')[1]
 with zipfile.ZipFile(E/(name+'.zip')) as z:
  assert len(z.namelist())==len(set(z.namelist()));members={n:dict(bytes=len(z.read(n)),sha256=sha(z.read(n))) for n in z.namelist()}
  q=json.loads(z.read('current/RESULT.json'));assert q['status']=='SIX_ACTUAL_BOUNDED_FROST_BOUNDARY_FULL35_COLD_COMPILED_NATIVE_AND_TRANSACTIONS_PASS_NOT_ADMITTED'
  assert q['source']==api['source'] and len(q['contexts'])==6 and all(x['compiled_controls']['returncode']==0 for x in q['contexts'])
  assert sum(x.get('completed_full35_reused_without_model_replay',False) for x in q['contexts'])==5
 parts=[]
 for start in range(0,len(raw),25*1024*1024):
  piece=raw[start:start+25*1024*1024];filename=name+'.zip.part'+str(len(parts)+1).zfill(3)
  with (P/filename).open('xb') as f:f.write(piece)
  parts.append(dict(file=filename,bytes=len(piece),sha256=sha(piece)))
 record=dict(status='ORIGINAL_SIX_SELECTED_BOUNDARY_CONTEXTS_SOURCE_COMPILED_POSTIMAGE_FULL35_COLD_NATIVE_AND_TRANSACTIONS_PRESERVED_NOT_ADMITTED',
  archive=name+'.zip',bytes=len(raw),sha256=sha(raw),parts=parts,members=members,official_artifact=item,
  actual_source=api['source'],actual_workflow_run=item['workflow_run']['id'],
  original_completed_contexts_inherited_without_model_replay=5,new_full35_contexts=1,canonical_admission=False)
 (P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(name,len(raw),sha(raw),flush=True)
