"""Preserve four original failed CI archives and their completed first contexts."""
import hashlib,json,shutil,zipfile
from pathlib import Path
E=Path(__file__).parent;P=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01')
api=json.loads((E/'FROST_BOUNDARY03_FIRST_ORIGINAL_ARTIFACTS_API_V1.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for item in api['artifacts']:
 platform='WINDOWS' if 'windows' in item['name'] else 'UBUNTU';opt='O0' if '-O0-' in item['name'] else 'O2'
 name='FROST_BOUNDARY03_'+platform+'_'+opt+'_ORIGINAL_V1';path=E/(name+'.zip');raw=path.read_bytes()
 assert len(raw)==item['size_in_bytes'] and sha(raw)==item['digest'].split(':')[1]
 with zipfile.ZipFile(path) as z:
  assert len(z.namelist())==len(set(z.namelist()));members={k:dict(bytes=len(z.read(k)),sha256=sha(z.read(k))) for k in z.namelist()}
  q=json.loads(z.read('current/RESULT.json'));assert q['status']=='FAILED_ACTUAL_FROST_BOUNDARY_COHORT_NOT_QUALIFIED'
  assert len(q['contexts'])==2 and q['contexts'][0]['returncode']==0 and q['contexts'][1]['returncode']==1
 assert not (P/(name+'.zip')).exists();shutil.copyfile(path,P/(name+'.zip'))
 record=dict(status='ORIGINAL_FAILED_COHORT_WITH_ACTUAL_COMPLETED_FIRST_FULL35_AND_COLD_PRESERVED_NOT_ADMITTED',
  archive=name+'.zip',bytes=len(raw),sha256=sha(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=sha(raw))],
  members=members,official_artifact=item,actual_source=api['source'],actual_complete_full35_contexts=1,
  build_refusal_before_second_model=True,cohort_qualified=False)
 (P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(name,len(raw),sha(raw),flush=True)
