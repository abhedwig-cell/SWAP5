"""Preserve actual20 qualified contexts and numeric refusal; freeze bounded six."""
import difflib,hashlib,json,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest();base='3250f0c59337334994b0e8edda624afe8f91b11f'
api=json.loads((E/'FROST_BOUNDARY03_THIRD_ORIGINAL_ARTIFACTS_API_V3.json').read_text());summaries=[]
for item in api['artifacts']:
 platform='WINDOWS' if 'windows' in item['name'] else 'UBUNTU';opt='O0' if '-O0-' in item['name'] else 'O2'
 name='FROST_BOUNDARY03_'+platform+'_'+opt+'_ORIGINAL_V3';path=E/(name+'.zip');raw=path.read_bytes()
 assert len(raw)==item['size_in_bytes'] and sha(raw)==item['digest'].split(':')[1]
 with zipfile.ZipFile(path) as z:
  assert len(z.namelist())==len(set(z.namelist()));members={k:dict(bytes=len(z.read(k)),sha256=sha(z.read(k))) for k in z.namelist()}
  q=json.loads(z.read('current/RESULT.json'));assert q['status']=='FAILED_ACTUAL_FROST_BOUNDARY_COHORT_NOT_QUALIFIED'
  successful=[x['case'] for x in q['contexts'] if x.get('compiled_controls',{}).get('returncode')==0];assert len(successful)==5
  failed='current/water-bottom8-implicit1-hys2-initial2/science/trajectory/'
  assert z.read(failed+'daily.jsonl')==b'' and b'Implicit original retry reached clock resolution' in z.read(failed+'original/donor.stderr')
 parts=[]
 for start in range(0,len(raw),25*1024*1024):
  piece=raw[start:start+25*1024*1024];filename=name+'.zip.part'+str(len(parts)+1).zfill(3)
  with (P/filename).open('xb') as f:f.write(piece)
  parts.append(dict(file=filename,bytes=len(piece),sha256=sha(piece)))
 record=dict(status='ORIGINAL_PARTIAL_COHORT_FIVE_SAFE_FULL35_NATIVE_CONTEXTS_AND_ZERO_DAY_IMPLICIT8_NUMERICAL_REFUSAL_PRESERVED_NOT_ADMITTED',
  archive=name+'.zip',bytes=len(raw),sha256=sha(raw),parts=parts,members=members,official_artifact=item,
  actual_source=api['source'],original_cohort_status=q['status'],successful_case_names=successful,
  implicit8_water_accepted_days=0,implicit8_water_actual_failure='Implicit original retry reached clock resolution',cohort_qualified=False)
 (P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');summaries.append(dict(platform=platform,optimization=opt,archive_sha256=sha(raw),successful_case_names=successful))
contract=json.loads((P/'FROST_BOUNDARY03_CONTRACT_V1.json').read_text());names=[Path(p).name for p in contract['files']]+['implicit_snow_cde_root_carry.py'];files={}
for name in names:
 path='app/hybrid_water/'+name;raw=(R/path).read_bytes().replace(b'\r\n',b'\n');item=dict(added=name=='frost_boundary_composition.py',proposed_lf_sha256=sha(raw))
 if not item['added']:
  old=subprocess.check_output(['git','show',base+':'+path],cwd=R);a=old.decode();b=raw.decode()
  item.update(before_lf_sha256=sha(old),ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=True).get_opcodes() if op!='equal'])
 files[path]=item
contract.update(files=files,status='TWENTY_FULL35_NATIVE_CONTEXTS_PASS_IMPLICIT5_CDE_OWNER_CORRECTED_IMPLICIT8_HARD_REFUSED_NOT_ADMITTED',
 scope='Model1 Snow/Frost numerical heat2, primaryDRA1/DIVD1; explicit water/CDE bottom5/8 and fitted implicit water/CDE bottom5 only; hys2 initialization2, original dense daily reset1 output. Implicit bottom8 remains hard-refused.',
 retained_implicit8=dict(water_status='NUMERICAL_FAILURE',actual_producer=api['source'],actual_zero_day_failure='Implicit original retry reached clock resolution',platform_opt_contexts=4,
  cde_status='MISSING_COMPOSITION_NOT_NUMERICALLY_TESTED',no_tolerance_or_flux_substitution=True),
 first_twenty_complete_science_and_compiled_controls=summaries,
 cde_private_owner_correction='Generic existing Snow CDE root carry declines exactly selected Frost boundary domain; its actual typed Frost owner remains sole state owner.',
 next='Use fresh current complete generated/compiled postimages to inherit each five completed contexts per opt/platform; run only missing implicit CDE bottom5 full35/cold/native/transaction case. No full-period replay for metadata or source-reader changes.')
(P/'FROST_BOUNDARY03_CONTRACT_V1.json').write_text(json.dumps(contract,indent=2)+'\n')
for osname,runid in [('ubuntu',45630288165),('windows',45630288321)]:
 path=R/'.github/workflows'/('nomacro-frost-boundary03-'+osname+'.yml');text=path.read_text()
 oldrun='45628685020' if False else ('45627300645' if osname=='ubuntu' else '45627301016')
 assert 'run-id: '+oldrun in text;text=text.replace('run-id: '+oldrun,'run-id: '+str(runid))
 text=text.replace('16988131766408867b0c1fa94a3a45cabe68b6fe','6049f82bcf265ef17de2ff86a69b4ef4c33f768f')
 text=text.replace('Obtain exact original completed first scientific context','Obtain five exact completed scientific and native-control contexts')
 path.write_text(text)
status=json.loads((P/'STATUS.json').read_text());status['last_commit']=api['source']
status['frost_boundary03_recovery'].update(third_scientific_source=api['source'],third_workflows=[45630288165,45630288321],
 successful_full35_and_native_transaction_contexts=20,
 retained_blocker='Implicit water bottom8 actual O0/O2 Windows/Ubuntu trials reach clock resolution before accepted day1. Original CDE bottom8 was blocked by generic CDE root ownership before numerical execution; no claim of measured CDE numerical failure. Both remain excluded from bounded admission.',
 next='Source-frozen six-domain cohort: prove twenty completed current postimages, execute only four missing implicit CDE bottom5 contexts with own cold/native/transactions; build independent archive reader and parent500 source/raw owner. No full previous periods replayed.')
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
gap=json.loads((P/'GAP_MATRIX.json').read_text());gap['frost_boundary58_composition'].update(status='TWENTY_SAFE_FULL35_NATIVE_CONTEXTS_PASS_SIX_DOMAIN_CDE_COMPLETION_PENDING',scope=contract['scope'],
 retained_numerical_failure='Water implicit bottom8 source6049f82bcf, four O0/O2 Windows/Ubuntu zero-day clock-resolution refusals; CDE counterpart not numerically executed and remains MISSING_COMPOSITION.')
(P/'GAP_MATRIX.json').write_text(json.dumps(gap,indent=2)+'\n')
print('TWENTY_GENUINE_FULL35_NATIVE_CONTEXTS_PRESERVED_EIGHT_APP_FILES_FROZEN_AND_UNQUALIFIED_IMPLICIT8_CLOSED')
