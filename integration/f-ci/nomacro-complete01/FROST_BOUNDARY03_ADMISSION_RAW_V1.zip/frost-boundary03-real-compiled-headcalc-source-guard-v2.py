"""Actual production complete-source validator: real compiled positives/mutants."""
from pathlib import Path
import hashlib,json,sys,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path.insert(0,str(R/'app/hybrid_water'))
from implicit_frost_source_guard import qualified_water_headcalc,TERMINAL_PARTS
from implicit_frost_surface_conductivity import restore
from ordinary_pond_source_guard import HEADS
sha=lambda s:hashlib.sha256(s.encode('cp1252')).hexdigest();observed=[]
for opt in ('O0','O2'):
 archive=E/('FROST_BOUNDARY03_UBUNTU_'+opt+'_ORIGINAL_V2.zip')
 with zipfile.ZipFile(archive) as z:
  actual=z.read('compiled/water-bottom5-implicit1-hys2-initial2/bundle/headcalc.f90').decode('cp1252').replace('\r\n','\n');source=restore(actual)
  for part in TERMINAL_PARTS:
   assert source.count(part)==1;source=source.replace(part,'',1)
  result=qualified_water_headcalc(source,5);assert sha(result)==HEADS['water']
  assert qualified_water_headcalc(result,8)==result
  anchor='kmean(NN+1)';assert anchor in source
  changed=source.replace(anchor,'kmean(NN)',1)
  try:qualified_water_headcalc(changed,5)
  except ValueError as error:assert str(error)=='Foreign complete actual implicit Frost HeadCalc parent'
  else:raise AssertionError('Actual complete-source production validator accepted altered numerical expression')
  observed.append(dict(optimization=opt,actual_compiled_source='05c588fd75d7b66c9a37b86bcdacf115c9e2b7b4',archive=archive.name,
   actual_headcalc_lf_sha256=sha(actual),complete_canonical_water_sha256=sha(result),
   actual_production_complete_source_validator_refused_changed_expression=True))
q=dict(status='ACTUAL_COMPILED_O0_O2_COMPLETE_SOURCE_PRODUCTION_VALIDATOR_POSITIVES_AND_NUMERICAL_MUTANTS_PASS',
 observations=observed,compiler_executions=0,model_executions=0,physical_source_rewritten=False)
(E/'FROST_BOUNDARY03_REAL_COMPILED_HEADCALC_SOURCE_GUARD_V2.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'])
