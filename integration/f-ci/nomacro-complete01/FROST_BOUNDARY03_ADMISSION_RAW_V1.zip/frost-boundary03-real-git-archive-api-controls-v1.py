from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from analytical_hydraulic_archives import Archive
from frost_boundary_git_archive import GitArchiveSource
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();data=GitArchiveSource(R,head)
assert str(data).startswith('GitArchiveSource('+head+':') and not hasattr(data,'__fspath__')
observed=[]
for name in ('FROST_BOUNDARY03_UBUNTU_O0_ORIGINAL_V1','FROST_BOUNDARY03_UBUNTU_O0_ORIGINAL_V3'):
 with ExitStack() as stack:
  disk=Archive(R/'integration/f-ci/nomacro-complete01',name,stack);git=Archive(data,name,stack)
  assert disk.record==git.record and disk.names==git.names
  for member in disk.names:assert disk.get(member)==git.get(member)
  observed.append(dict(name=name,parts=len(git.record['parts']),members=len(git.names),sha256=git.record['sha256'],all_actual_git_and_working_archive_member_bytes_exact=True))
for path in ('../elsewhere','/absolute','C:/outside'):
 try:GitArchiveSource(R,head,path)
 except AssertionError:pass
 else:raise AssertionError('Unsafe Git archive prefix accepted')
q=dict(status='GENUINE_GIT_AND_FILESYSTEM_SINGLE_MULTIPART_ORIGINAL_ARCHIVES_ALL_MEMBERS_EXACT_UNSAFE_PREFIXES_REFUSED',
 actual_git_revision=head,observations=observed,pretend_filesystem_or_HEAD=False,compiler_executions=0,model_executions=0)
(E/'FROST_BOUNDARY03_REAL_GIT_ARCHIVE_API_CONTROLS_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'])
