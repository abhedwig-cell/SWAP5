from pathlib import Path
import subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
path=R/'tests/nomacro_drainage/frost_boundary_verify.py';raw=path.read_text()
before="SEALED='"+'0'*40+"'";assert raw.count(before)==1
path.write_text(raw.replace(before,"SEALED='"+head+"'",1));print(head)
