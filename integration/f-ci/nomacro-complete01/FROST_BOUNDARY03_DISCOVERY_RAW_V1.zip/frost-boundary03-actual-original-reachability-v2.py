"""Actual original executable reachability; no modern or equivalence qualification."""
import hashlib,json,shutil,subprocess,sys,time,zipfile
from pathlib import Path
E=Path(__file__).parent;W=E.parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'tests/nomacro_scheduled_subsurface'))
from original_output_baseline import assignment
J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
exe=J/'build/swap_b0_gfortran.exe'
sha=lambda b:hashlib.sha256(b).hexdigest()
exe_sha=sha(exe.read_bytes());preparation=sha((J/'PREPARED.json').read_bytes())
q=dict(status='RUNNING_ACTUAL_ORIGINAL_REACHABILITY_NOT_QUALIFIED',executable=str(exe),
 executable_sha256=exe_sha,provider_preparation_sha256=preparation,
 compiler_executions=0,original_model_executions=0,modern_model_executions=0,cases=[],
 scientific_equivalence='NOT_QUALIFIED',mass_balance_qualification_claimed=False)
out=E/'FROST_BOUNDARY03_ACTUAL_ORIGINAL_REACHABILITY_V2.json'
save=lambda:out.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
try:
 for case in json.loads((E/'FROST_BOUNDARY03_CURRENT_PUBLIC_REFUSAL_DISCOVERY_V1.json').read_text())['cases']:
  key=case['case'];folder=W/'frost-boundary03-actual-original-full35-v2'/key
  shutil.copytree(W/'frost-boundary03-original-reader-probes-v1'/key,folder)
  p=folder/'swap.swp';p.write_text(assignment(p.read_text(encoding='cp1252'),'TEND','2002-02-04'),encoding='cp1252')
  inventory={p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(folder.rglob('*')) if p.is_file()}
  start=time.perf_counter()
  q['original_model_executions']+=1;save()
  try:
   result=subprocess.run([str(exe),'./swap.swp'],cwd=folder,capture_output=True,timeout=30)
   (folder/'original.stdout.bin').write_bytes(result.stdout);(folder/'original.stderr.bin').write_bytes(result.stderr)
   observation=dict(case=key,input_inventory=inventory,returncode=result.returncode,
    seconds=time.perf_counter()-start,original_swap_ok=(folder/'swap.ok').is_file(),
    stderr_sha256=sha(result.stderr),stdout_sha256=sha(result.stdout),censored=False)
  except subprocess.TimeoutExpired as error:
   (folder/'original.stdout.bin').write_bytes(error.stdout or b'');(folder/'original.stderr.bin').write_bytes(error.stderr or b'')
   observation=dict(case=key,input_inventory=inventory,seconds=time.perf_counter()-start,censored=True,original_swap_ok=False)
  q['cases'].append(observation);save();print(key,observation.get('returncode'),'swap.ok',observation['original_swap_ok'],flush=True)
 assert sha(exe.read_bytes())==exe_sha and sha((J/'PREPARED.json').read_bytes())==preparation
 q['status']='ACTUAL_ORIGINAL_REACHABILITY_OBSERVED_NOT_SCIENTIFICALLY_QUALIFIED'
finally:
 save()
 archive=E/'FROST_BOUNDARY03_ACTUAL_ORIGINAL_FULL35_RAW_V2.zip';members={}
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for p in sorted((W/'frost-boundary03-actual-original-full35-v2').rglob('*')):
   if p.is_file():
    key=p.relative_to(W/'frost-boundary03-actual-original-full35-v2').as_posix();raw=p.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=sha(raw))
  for p in (exe,J/'PREPARED.json',Path(__file__),out):
   key='actual-provider-and-controller/'+p.name;raw=p.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=sha(raw))
 with zipfile.ZipFile(archive) as z:
  assert set(z.namelist())==set(members)
  for key,item in members.items():assert sha(z.read(key))==item['sha256']
 raw=archive.read_bytes();manifest=dict(archive=archive.name,bytes=len(raw),sha256=sha(raw),members=members)
 (E/'FROST_BOUNDARY03_ACTUAL_ORIGINAL_FULL35_RAW_V2.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(q['status'],len(q['cases']),flush=True)
