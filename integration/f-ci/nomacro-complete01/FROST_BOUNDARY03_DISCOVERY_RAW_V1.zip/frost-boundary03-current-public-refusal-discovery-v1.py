"""Capture actual current public refusals; zero compiler/model/original-reader runs."""
import hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
E=Path(__file__).parent
W=E.parent/'frost-boundary03-original-reader-probes-v1'
sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'tools/solute')]
from frost_history_state_inputs import prepare
from original_output_baseline import assignment
import experimental_project
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
head=git('rev-parse','HEAD');assert head=='3250f0c59337334994b0e8edda624afe8f91b11f'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
records=[]
for bottom in (5,8):
 for kind in ('water','cde'):
  for implicit in (0,1):
   key=f'{kind}-bottom{bottom}-implicit{implicit}-hys2-initial2'
   inputs=W/key;prepare(kind,1,2,implicit,inputs)
   p=inputs/'swap.swp';text=p.read_text(encoding='cp1252')
   text=assignment(assignment(text,'SWHYST',2),'SWBOTB',bottom)
   if bottom==5 and not re.search(r'(?mi)^\s*DATE5\s+HBOT5',text):
    text+='\nDATE5 HBOT5\n2002-01-01 -100.0\n2004-12-31 -100.0\n* End of table\n'
   if bottom==8 and not re.search(r'(?mi)^\s*HPLATE\s*=',text):text+='\nHPLATE = -50.0\n'
   p.write_text(text,encoding='cp1252')
   try:experimental_project.inspect(inputs,original_output=True)
   except ValueError as error:refusal=str(error)
   else:raise AssertionError('Previously bounded Frost boundary unexpectedly admitted')
   inventory={v.relative_to(inputs).as_posix():dict(bytes=v.stat().st_size,sha256=sha(v.read_bytes())) for v in sorted(inputs.rglob('*')) if v.is_file()}
   records.append(dict(case=key,bottom=bottom,kind=kind,implicit=implicit,actual_public_refusal=refusal,inputs=inventory))
assert git('rev-parse','HEAD')==head and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
out=E/'FROST_BOUNDARY03_CURRENT_PUBLIC_REFUSAL_DISCOVERY_V1.json'
q=dict(status='EIGHT_ACTUAL_PUBLIC_REFUSALS_CAPTURED_NOT_ORIGINAL_READER_OR_SCIENTIFIC_QUALIFICATION',source=head,
 cases=records,compiler_executions=0,model_executions=0,original_reader_executions=0,
 next='Review actual refusal layer, register source contract and select smallest real production/original-reader probe; no admission claim.')
out.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
archive=E/'FROST_BOUNDARY03_ORIGINAL_DISCOVERY_INPUTS_V1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(W.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(W).as_posix())
with zipfile.ZipFile(archive) as z:
 for case in records:
  for name,item in case['inputs'].items():assert sha(z.read(case['case']+'/'+name))==item['sha256']
print(q['status'],[(x['case'],x['actual_public_refusal']) for x in records],flush=True)
