from pathlib import Path
import ast,hashlib,json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'app/hybrid_water'))
import experimental_project as project
import frost_boundary_composition as boundary
import implicit_frost_root_state as root
baseline='3250f0c59337334994b0e8edda624afe8f91b11f'
old=subprocess.check_output(['git','show',baseline+':app/hybrid_water/implicit_frost_root_state.py'],cwd=R)
scope={'__file__':str(R/'app/hybrid_water/implicit_frost_root_state.py')};exec(compile(old,'actual-parent-root','exec'),scope)
for solute in (False,True):
 for mode in (0,1,2):assert root.source(solute,mode)==scope['source'](solute,mode)
cases=[]
for item in json.loads((E/'FROST_BOUNDARY03_CURRENT_PUBLIC_REFUSAL_DISCOVERY_V1.json').read_text())['cases']:
 folder=E.parent/'frost-boundary03-original-reader-probes-v1'/item['case']
 selected=boundary.selection(folder,True);assert selected and selected['bottom']==item['bottom']
 actual=project.load(folder,original_output=True,time_step_policy='original-adaptive-event-closure-v1')
 assert actual.solute==(item['kind']=='cde')
 from frost_drainage_composition import codec,metadata
 assert codec(actual)==boundary.codec(selected)
 meta=metadata(actual);assert meta['boundary_composition']['bottom']==item['bottom']
 if item['implicit']:
  assert root.boundary(actual)==item['bottom']
  generated=root.source(actual.solute,2,root.boundary(actual))
  assert '(swbotb/='+str(item['bottom'])+'.or.swfrost/=1' in generated
 cases.append(dict(case=item['case'],selection=selected,codec=codec(actual).decode()))
for path in subprocess.check_output(['git','diff','--name-only',baseline,'--','app'],cwd=R,text=True).splitlines():ast.parse((R/path).read_text())
q=dict(status='EIGHT_REAL_PUBLIC_LOAD_METADATA_AND_SIX_EXACT_PARENT_ROOT_SOURCES_PASS_NOT_QUALIFIED',cases=cases,
 old_bottom6_generated_sources_exact=6,compiler_executions=0,model_executions=0)
(E/'FROST_BOUNDARY03_FIRST_FRONTEND_SOURCE_CHECK_V1.json').write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],flush=True)
