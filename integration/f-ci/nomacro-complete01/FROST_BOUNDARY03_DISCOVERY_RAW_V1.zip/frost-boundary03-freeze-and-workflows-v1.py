"""Freeze actual five-file APP delta and select four real platform/opt cohorts."""
from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
P=R/'integration/f-ci/nomacro-complete01';base='3250f0c59337334994b0e8edda624afe8f91b11f'
files=['frost_boundary_composition.py','experimental_project.py','implicit_frost_composition.py',
       'frost_drainage_composition.py','implicit_frost_root_state.py']
contract=json.loads((P/'FROST_BOUNDARY03_CONTRACT_V1.json').read_text());records={}
sha=lambda b:hashlib.sha256(b).hexdigest()
for name in files:
 path='app/hybrid_water/'+name;raw=(R/path).read_bytes().replace(b'\r\n',b'\n')
 item=dict(added=name=='frost_boundary_composition.py',proposed_lf_sha256=sha(raw))
 if not item['added']:
  old=subprocess.check_output(['git','show',base+':'+path],cwd=R);a=old.decode();b=raw.decode()
  edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if op!='equal']
  item.update(before_lf_sha256=sha(old),ordered_literal_edits=edits)
 records[path]=item
contract.update(status='IMPLEMENTED_EIGHT_PUBLIC_LOADS_AND_SIX_EXACT_DEFAULT_ROOT_SOURCES_PASS_NOT_QUALIFIED',files=records,
 actual_dependency_merge='1c3b8725548c836c9a73570c2579dd6cdc683217',
 dependency_admission='ALL17_CANDIDATE_CI_PASS_ACTUAL_MERGE_PUBLIC_OBSERVATIONS_RUNNING',
 local_large_job_preflight=dict(free_gib=46.898563385009766,required_gib=50,ok=False,compiler_executions=0),
 next='Four actual Windows/Ubuntu O0/O2 source-bound full35/cold cohorts; compiled active/refusal qualification and independent archive admission still required.')
(P/'FROST_BOUNDARY03_CONTRACT_V1.json').write_text(json.dumps(contract,indent=2)+'\n')
for osname in ('ubuntu','windows'):
 old='nomacro-frost-calendar-state02'+('-windows' if osname=='windows' else '')+'.yml'
 raw=(R/'.github/workflows'/old).read_text()
 raw=raw.replace('codex/nomacro-frost-calendar-state02','codex/nomacro-frost-boundary03')
 raw=raw.replace('nomacro-frost-calendar-state02-windows','nomacro-frost-boundary03-windows')
 raw=raw.replace('nomacro-frost-calendar-state02.yml','nomacro-frost-boundary03-ubuntu.yml')
 raw=raw.replace('nomacro-frost-calendar-state02-${{','nomacro-frost-boundary03-ubuntu-${{')
 raw=raw.replace('frost-calendar-state02-','frost-boundary03-')
 raw=raw.replace('8dbe3db7c7832dd6a1f86c4275cd43f054552df3','1c3b8725548c836c9a73570c2579dd6cdc683217')
 raw=raw.replace('name: Remaining Windows Frost calendar and daily conservation','name: Original Frost boundary58 Windows full35 and native state')
 raw=raw.replace('name: Bounded Frost calendar and daily terminal conservation','name: Original Frost boundary58 Ubuntu full35 and native state')
 raw=raw.replace('Validate actual daily provider and run selected calendar controls','Run eight actual original lower-boundary full35 and own cold contexts')
 lines=raw.splitlines();output=[]
 for line in lines:
  if 'extra=()' in line or "then extra+=(--exclude-case" in line:continue
  if 'frost_calendar_state_portable.py' in line:
   prefix='          python -B' if osname=='windows' else '          python3 -B'
   line=prefix+' tests/nomacro_drainage/frost_boundary_portable.py --platform '+('Windows' if osname=='windows' else 'Ubuntu')+' --reference-work "$RUNNER_TEMP/provider" --build-root "$RUNNER_TEMP/builds" --output "$RUNNER_TEMP/proof/current" --optimization \'${{ matrix.optimization }}\''
  output.append(line)
 target=R/'.github/workflows'/('nomacro-frost-boundary03-'+osname+'.yml');assert not target.exists();target.write_text('\n'.join(output)+'\n')
print('FIVE_ACTUAL_APP_FILES_FROZEN_AND_TWO_ORIGINAL_BYTE_PRESERVING_WORKFLOWS_PREPARED')
