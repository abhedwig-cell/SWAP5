"""Discriminate original execution failure from new boundary selection."""
import hashlib,json,shutil,subprocess,sys,time,zipfile
from pathlib import Path
E=Path(__file__).parent;W=E.parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'tests/nomacro_scheduled_subsurface'))
from original_output_baseline import assignment
source=W/'frost-boundary03-original-reader-probes-v1/water-bottom5-implicit0-hys2-initial2'
target=W/'frost-boundary03-actual-original-full35-v2/original-bottom6-control'
shutil.copytree(source,target)
p=target/'swap.swp';text=p.read_text(encoding='cp1252')
text=assignment(assignment(text,'SWBOTB',6),'TEND','2002-02-04');p.write_text(text,encoding='cp1252')
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={p.relative_to(target).as_posix():sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}
exe=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider/build/swap_b0_gfortran.exe')
start=time.perf_counter();r=subprocess.run([str(exe),'./swap.swp'],cwd=target,capture_output=True,timeout=30)
(target/'original.stdout.bin').write_bytes(r.stdout);(target/'original.stderr.bin').write_bytes(r.stderr)
q=dict(status='ACTUAL_UNCHANGED_BOTTOM6_ORIGINAL_EXECUTION_CONTROL_NOT_QUALIFIED',
 source_case=str(source),actual_control=str(target),input_sha256=inputs,
 executable_sha256=sha(exe.read_bytes()),returncode=r.returncode,seconds=time.perf_counter()-start,
 swap_ok=(target/'swap.ok').is_file(),compiler_executions=0,original_model_executions=1,
 allowed_input_changes=['SWBOTB5_TO6','TEND_TO35DAY'],mass_balance_qualification_claimed=False)
out=E/'FROST_BOUNDARY03_ORIGINAL_BOTTOM6_CONTROL_V1.json';out.write_text(json.dumps(q,indent=2)+'\n')
with zipfile.ZipFile(E/'FROST_BOUNDARY03_ORIGINAL_BOTTOM6_CONTROL_RAW_V1.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(target.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(target).as_posix())
 z.write(out,out.name);z.write(Path(__file__),Path(__file__).name)
print(q['status'],q['returncode'],q['swap_ok'],r.stderr.decode(errors='replace')[:180],flush=True)
