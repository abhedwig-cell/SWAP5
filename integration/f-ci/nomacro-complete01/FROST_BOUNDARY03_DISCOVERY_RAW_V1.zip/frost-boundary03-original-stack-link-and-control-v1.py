"""Relink original objects with explicit stack; no physical code changes."""
import hashlib,json,shutil,subprocess,sys,time,zipfile
from pathlib import Path
E=Path(__file__).parent;W=E.parent;J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
build=W/'frost-boundary03-original-stack-only-O2-v1';assert build.is_dir()
sha=lambda b:hashlib.sha256(b).hexdigest()
prepared=json.loads((J/'PREPARED.json').read_text());objects=sorted((J/'build/swap-obj').glob('*.o'))
library=J/'build/ttutil-obj/libttutil.a';assert objects
inventory={}
for p in objects+[library]:
 relative=p.relative_to(J).as_posix();raw=p.read_bytes();assert sha(raw)==prepared['provider_files'][relative]
 inventory[relative]=dict(bytes=len(raw),sha256=sha(raw))
exe=build/'swap_original_stack256.exe';assert not exe.exists()
command=['gfortran','-Wl,--stack,268435456','-o',str(exe),*[str(p) for p in objects],str(library)]
start=time.perf_counter();r=subprocess.run(command,capture_output=True,timeout=45)
(build/'link.stdout.bin').write_bytes(r.stdout);(build/'link.stderr.bin').write_bytes(r.stderr)
q=dict(status='ORIGINAL_STACK_ONLY_RELINK_RUNNING_NOT_QUALIFIED',command=command,
 original_compiled_inputs=inventory,link_returncode=r.returncode,link_seconds=time.perf_counter()-start,
 changed_source_files=[],object_compilations=0,link_executions=1,original_model_executions=0,
 stack_reserve_bytes=268435456,provider_original_stack_reserve_bytes=2097152)
out=E/'FROST_BOUNDARY03_ORIGINAL_STACK_CONTROL_V1.json'
save=lambda:out.write_text(json.dumps(q,indent=2)+'\n')
save();r.check_returncode();q['executable_sha256']=sha(exe.read_bytes())
# Match the actual failed bottom6 control inputs exactly, including dates.
source=W/'frost-boundary03-actual-original-full35-v2/original-bottom6-control'
folder=build/'actual-bottom6-control';folder.mkdir()
prior=json.loads((E/'FROST_BOUNDARY03_ORIGINAL_BOTTOM6_CONTROL_V1.json').read_text())
for relative,digest in prior['input_sha256'].items():
 p=source/relative;assert sha(p.read_bytes())==digest
 destination=folder/relative;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,destination)
q['control_input_sha256']=prior['input_sha256'];q['original_model_executions']=1;save()
start=time.perf_counter();r=subprocess.run([str(exe),'./swap.swp'],cwd=folder,capture_output=True,timeout=45)
(folder/'original.stdout.bin').write_bytes(r.stdout);(folder/'original.stderr.bin').write_bytes(r.stderr)
q.update(status='ORIGINAL_STACK_ONLY_RELINK_AND_SAME_INPUT_BOTTOM6_OBSERVED_NOT_QUALIFIED',
 control_returncode=r.returncode,control_seconds=time.perf_counter()-start,control_swap_ok=(folder/'swap.ok').is_file())
save()
with zipfile.ZipFile(E/'FROST_BOUNDARY03_ORIGINAL_STACK_CONTROL_RAW_V1.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(build.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(build).as_posix())
 z.write(out,out.name);z.write(Path(__file__),Path(__file__).name)
print(q['status'],q['control_returncode'],q['control_swap_ok'],flush=True)
