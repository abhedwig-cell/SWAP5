"""Persist original failed observations and concrete next functional recovery."""
from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
sha=lambda b:hashlib.sha256(b).hexdigest();name='FROST_BOUNDARY03_DISCOVERY_RAW_V1';members={}
paths=[p for p in E.iterdir() if p.is_file() and (p.name.startswith('FROST_BOUNDARY03_') or p.name.startswith('frost-boundary03-'))]
with zipfile.ZipFile(P/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(paths):
  raw=p.read_bytes();z.writestr(p.name,raw);members[p.name]=dict(bytes=len(raw),sha256=sha(raw))
 contract=E.parent/'frost-boundary03-input-contract-v1/actual'
 for p in sorted(contract.rglob('*')):
  if p.is_file():
   key='first-input-contract/'+p.relative_to(contract).as_posix();raw=p.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=sha(raw))
with zipfile.ZipFile(P/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,item in members.items():assert sha(z.read(key))==item['sha256']
raw=(P/(name+'.zip')).read_bytes()
manifest=dict(status='ACTUAL_ORIGINAL_FAILURES_REFUSALS_STACK_NEGATIVE_AND_FIRST_INPUT_CONTRACT_PRESERVED_NOT_QUALIFIED',
 archive=name+'.zip',bytes=len(raw),sha256=sha(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=sha(raw))],members=members)
(P/(name+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
status=json.loads((P/'STATUS.json').read_text())
status.update(canonical='1c3b8725548c836c9a73570c2579dd6cdc683217',branch='codex/nomacro-frost-boundary03',
 active_functional_batch='FROST_BOUNDARY03',last_commit='8396cc3d97',
 status='PARTIAL',functional_completeness='PARTIAL',scientific_equivalence='NOT_QUALIFIED')
status['frost_calendar_state02_recovery']=dict(PR=1801,actual_merge='1c3b8725548c836c9a73570c2579dd6cdc683217',
 qualified_candidate='3250f0c59337334994b0e8edda624afe8f91b11f',source_anchor='38d01129d73e9128c93e10d61153970676a2fcf7',
 whole_tree='d20d8d776c52b1e5a6b95d500b5547f78a519f6b',candidate_public_pass=True,ordinary_publication_pass=True,
 all_workflows_success=17,successful_checks=31,skipped_checks=17,four_actual_pushed_negatives_refused=True,
 actual_canonical_public_and_ordinary_publication='RUNNING_CLEAN14_AND56_ORIGINAL_INPUTS',canonical_admission_sealed=False,
 actual_observer_checkout='C:/Users/Veldh012/swap5-implicit-conductivity-canonical01',
 next='Observe actual merge PUBLIC/PUB to completion, run external frost-calendar-state02-admission-seal-v1.py, commit its receipt/raw with this functional batch.')
status['frost_boundary03_recovery']=dict(contract='FROST_BOUNDARY03_CONTRACT_V1.json',discovery_raw_sha256=manifest['sha256'],
 implementation='BOUNDED_EIGHT_PUBLIC_LOADS_FOUR_CODECS_FOURTEEN_DECLINES_AND_SIX_EXACT_DEFAULT_PROVIDERS_PASS_NOT_QUALIFIED',
 storage_preflight='46.898563GiB_FREE_BELOW50_LARGE_LOCAL_JOB_NOT_STARTED',
 next='Push actual source and two source-capturing Windows/Ubuntu O0/O2 scientific workflows; preserve all outcomes. Qualify actual full35/cold/native state and compiled refusal/transaction controls before source/raw admission. No prior complete periods replayed.',
 exclusions='Original full executable initialization crash persists for old bottom6 with unchanged objects and large-stack relink; no boundary-specific physical defect or equivalence claim.')
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
print(manifest['status'],manifest['bytes'],manifest['sha256'],flush=True)
