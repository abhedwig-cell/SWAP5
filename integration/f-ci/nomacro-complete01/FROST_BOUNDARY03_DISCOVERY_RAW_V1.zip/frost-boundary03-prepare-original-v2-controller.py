from pathlib import Path
E=Path(__file__).parent
raw=(E/'frost-boundary03-actual-original-reachability-v1.py').read_text()
changes={
 'frost-boundary03-actual-original-three-day-v1':'frost-boundary03-actual-original-full35-v2',
 'FROST_BOUNDARY03_ACTUAL_ORIGINAL_REACHABILITY_V1':'FROST_BOUNDARY03_ACTUAL_ORIGINAL_REACHABILITY_V2',
 'FROST_BOUNDARY03_ACTUAL_ORIGINAL_THREE_DAY_RAW_V1':'FROST_BOUNDARY03_ACTUAL_ORIGINAL_FULL35_RAW_V2',
 "'TEND','2002-01-03'":"'TEND','2002-02-04'"}
for before,after in changes.items():
 assert before in raw
 raw=raw.replace(before,after)
target=E/'frost-boundary03-actual-original-reachability-v2.py'
with target.open('x',encoding='utf8') as f:f.write(raw)
