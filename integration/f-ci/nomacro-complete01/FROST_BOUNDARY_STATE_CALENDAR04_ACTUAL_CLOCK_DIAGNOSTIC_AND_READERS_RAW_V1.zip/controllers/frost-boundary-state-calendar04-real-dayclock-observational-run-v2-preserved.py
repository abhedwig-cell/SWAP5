from pathlib import Path
import contextlib,hashlib,json,shutil,subprocess,sys,zipfile,time
E=Path(__file__).parent;D=E.parent/'frost-boundary-state-calendar04-dayclock-causal-v1';R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider/build')
B=D/'original-bundle';TRACE=D/'trace-bundle-v2';SHA=lambda b:hashlib.sha256(b).hexdigest()
J=D/'original-provider-build'
sys.path.insert(0,str(R/'app/hybrid_water'))
import daily_host as h,experimental_project as e
meta=json.loads((B/'BUILD.json').read_text())
assert SHA(h.executable(B,'day_donor').read_bytes())==meta['executable_sha256']['donor']
assert SHA(h.executable(B,'day_kernel').read_bytes())==meta['executable_sha256']['kernel']
provider={}
with zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_WINDOWS_O0_ORIGINAL_V1.zip') as z:
 for n in z.namelist():
  if n.startswith('original-provider-build/'):
   rel=n[len('original-provider-build/'):];raw=z.read(n);target=J/rel;target.parent.mkdir(parents=True,exist_ok=True)
   if target.exists():assert target.read_bytes()==raw
   else:target.write_bytes(raw)
   assert target.read_bytes()==raw
   if n.endswith('.o') or n.endswith('.a'):provider[rel]=SHA(raw)
assert len(provider)>200
shutil.copytree(B,TRACE)
path=TRACE/'timecontrol.f90';raw=path.read_bytes();text=raw.decode('cp1252')
anchor='      if (1.d0 - tcum > dtCrit) then'
assert text.count(anchor)==1
diagnostic="""      if (1.d0-tcum <= dtCrit) then
         write(*,'(a,4(1x,es25.17e3))') 'DAYCLOCK_OBSERVATION',tcum,t1900,dt,dtCrit
      end if
"""
path.write_text(text.replace(anchor,diagnostic+anchor),encoding='cp1252')
commands=[]
def run(cmd):
 commands.append(cmd);p=subprocess.run(cmd,cwd=TRACE,capture_output=True)
 i=len(commands);(D/f'compile-{i}.stdout').write_bytes(p.stdout);(D/f'compile-{i}.stderr').write_bytes(p.stderr);p.check_returncode()
run(['gfortran',*meta['identity']['donor_flags'],'-I',str(J/'swap-obj'),'-I',str(J/'ttutil-obj'),'-c','timecontrol.f90'])
objects={p.name:p for p in (J/'swap-obj').glob('*.o')}
objects.update({p.name:p for p in TRACE.glob('*.o')})
exe=TRACE/'day_donor_trace.exe'
run(['gfortran','-o',str(exe),*[str(objects[k]) for k in sorted(objects)],str(J/'ttutil-obj/libttutil.a')])
project=e.load(D/'original-inputs',original_output=True,time_step_policy='original-adaptive-event-closure-v1')
out=D/'observational-run-v2';out.mkdir();rows=[]
started=time.perf_counter()
try:
 with contextlib.ExitStack() as stack:
  host=h.DailyHost(stack,exe,h.executable(B,'day_kernel'),D/'original-inputs',out,[h.ColumnStart('original',0,None,None)],checkpoint_enabled=False,runtime=True,binding=None,model=project.model,project=project)
  for day in range(1,23):
   row=host.step(1);rows.append(row)
   with (out/'daily.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   if not row['committed']:break
  host.close()
finally:
 report=dict(status='OBSERVATIONAL_DIAGNOSTIC_ONLY_NOT_QUALIFIED',original_source='71806beaee8e532af407ab88298b7bde4ac766c2',source_archive_sha256=SHA((E/'FROST_BOUNDARY_STATE_CALENDAR04_WINDOWS_O0_ORIGINAL_V1.zip').read_bytes()),original_metadata=meta,original_timecontrol_sha256=SHA(raw),observed_timecontrol_sha256=SHA(path.read_bytes()),source_edit=dict(before=anchor,after=diagnostic+anchor),changes_to_physics_or_time_arithmetic=0,unchanged_provider_objects=provider,commands=commands,diagnostic_executable_sha256=SHA(exe.read_bytes()),model_seconds=time.perf_counter()-started,rows=rows,canonical_admission=False)
 report['restart_publication']='NOT_SELECTED_DIAGNOSTIC_NO_CHECKPOINTS_NO_BINDING_NO_RESTART_CLAIM'
 (D/'RESULT_V2.json').write_text(json.dumps(report,indent=2)+'\n')
log=(out/'original/donor.stdout').read_text()
print('\n'.join(x for x in log.splitlines() if x.startswith('DAYCLOCK_OBSERVATION')))
print('LAST_ROW',json.dumps(rows[-1]))

