"""Reapply the existing genuine sparse checkout; retain all named live inputs."""
from pathlib import Path
import hashlib,json,subprocess,time
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='a47de6d5e1d3334098d69b001c09e27146fe84ce'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
sp=Path(git('rev-parse','--git-path','info/sparse-checkout').decode().strip());sp=sp if sp.is_absolute() else R/sp;patterns=sp.read_bytes();assert len(patterns.splitlines())==14
fixtures=lambda:{p.relative_to(R).as_posix():SHA(p.read_bytes()) for p in (R/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()}
inputs=fixtures();assert len(inputs)==56
required={}
# Active04 evidence readers explicitly consume immutable GitArchiveSource data.
# Runtime source and all56 original input fixtures remain actual working files.
# The separate canonical observer C retains its original named dependencies.
canonical=Path('C:/Users/Veldh012/swap5-implicit-conductivity-canonical01')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=canonical).decode().strip()=='9936bcda75eb920d67aa74e47018baf39ab18f78'
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all','--ignored'],cwd=canonical)
index={}
for entry in git('ls-files','--stage','-z').split(b'\0'):
 if not entry:continue
 header,path=entry.split(b'\t',1);mode,digest,stage=header.decode().split();assert stage=='0';index[path.decode()]=digest
before={}
for p in P.iterdir():
 if not p.is_file() or '.zip' not in p.name:continue
 name=p.relative_to(R).as_posix();assert name in index and not p.is_symlink();raw=p.read_bytes()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==index[name]
 assert int(git('cat-file','-s',index[name]))==len(raw)
 before[name]=dict(bytes=len(raw),blob=index[name],sha256=SHA(raw))
print('ALL_MATERIALIZED_ARCHIVE_COPIES_EXACTLY_HELD_IN_GIT',len(before),sum(x['bytes'] for x in before.values()),flush=True)
r=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','sparse-checkout','reapply'],cwd=R,capture_output=True)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_SPARSE_REAPPLY_V3.stdout.txt').write_bytes(r.stdout);(E/'FROST_BOUNDARY_STATE_CALENDAR04_SPARSE_REAPPLY_V3.stderr.txt').write_bytes(r.stderr);r.check_returncode()
assert sp.read_bytes()==patterns and git('rev-parse','HEAD').decode().strip()==head
missing=[p for p in required if not (R/p).is_file()]
print('RESTORING_ONLY_NAMED_LIVE_CANONICAL_DEPENDENCIES',len(missing),flush=True)
for i in range(0,len(missing),10):
 subprocess.run(['git','restore','--source='+head,'--worktree','--ignore-skip-worktree-bits','--',*missing[i:i+10]],cwd=R,capture_output=True,check=True)
 print('NAMED_DEPENDENCIES_RESTORED',min(i+10,len(missing)),'/',len(missing),flush=True)
for name,digest in required.items():assert SHA((R/name).read_bytes())==digest
removed={p:v for p,v in before.items() if not (R/p).exists()};assert not set(removed)&set(required)
for item in removed.values():assert int(git('cat-file','-s',item['blob']))==item['bytes']
assert sp.read_bytes()==patterns and fixtures()==inputs and git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=dict(status='GENUINE_UNCHANGED14_SPARSE_CHECKOUT_REMATERIALIZED_NAMED_LIVE_INPUTS_ALL_REMOVED_COPIES_STILL_EXACT_IN_GIT',actual_head=head,sparse_patterns_unchanged=14,original_project_files=inputs,named_live_dependencies_restored=missing,named_live_dependencies_exact=required,removed_clean_excluded_working_archive_copies=removed,removed_copy_bytes=sum(x['bytes'] for x in removed.values()),source_HEAD_index_and_input_identity_projected=False,compiler_executions=0,model_executions=0)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_GENUINE_SPARSE_ARCHIVE_COPY_CUSTODY_V3.json').write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],len(removed),q['removed_copy_bytes'],flush=True)


