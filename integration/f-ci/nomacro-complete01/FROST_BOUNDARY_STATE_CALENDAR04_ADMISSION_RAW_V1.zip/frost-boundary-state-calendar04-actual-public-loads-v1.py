from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent
sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
import experimental_project as public
import frost_boundary_state_calendar as new
from frost_calendar_output import codec,metadata
from implicit_frost_root_state import metadata as root_metadata
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='b7d347ec9c95193f571e79f149543667871d82bf'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
contract=json.loads((R/'integration/f-ci/nomacro-complete01/FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text())
out=E/'FROST_BOUNDARY_STATE_CALENDAR04_ACTUAL_PUBLIC_LOADS_V1.json';q=dict(status='RUNNING_ACTUAL_PUBLIC_READER_NOT_QUALIFIED',source=head,cases=[],compiler_executions=0,model_executions=0,canonical_admission=False)
save=lambda:out.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
try:
 for case in contract['representative_cases']:
  folder=W/'frost-boundary-state-calendar04-reader-discovery-v2'/case['name']
  project=public.load(folder,original_output=True,time_step_policy='original-adaptive-event-closure-v1')
  selected=new.selection(folder,True);assert selected and selected['bottom']==case['bottom'] and selected['hysteresis']==case['hysteresis'] and selected['initial']==case['initial']
  code=codec(project);assert len(code)==8 and code.decode() in contract['native_codecs'];meta=metadata(project);assert meta['native_codec']==code.decode() and meta['policy']==new.POLICY
  root=root_metadata(project)
  if case['implicit']:
   assert root and root['bytes']==96
   from implicit_snow_root_carry import enabled as generic_water
   from implicit_snow_cde_root_carry import enabled as generic_cde
   assert not generic_water(project) and not generic_cde(project)
  else:assert root is None
  q['cases'].append(dict(case=case,selection=selected,codec=code.decode(),root=root));save()
 q['status']='TWELVE_ACTUAL_PUBLIC_LOADS_SHARED_FROST_CALENDAR_OWNER_AND_UNIQUE_IMPLICIT_ROOT_PASS_NOT_SCIENTIFICALLY_QUALIFIED'
except Exception as error:q.update(status='FAILED_ACTUAL_PUBLIC_LOAD_NO_QUALIFICATION',error=repr(error));raise
finally:save()
assert len(q['cases'])==12 and git('rev-parse','HEAD').decode().strip()==head
print(q['status'],flush=True)
