"""Preserve genuine admission only after exact final-head and canonical gates."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
E=Path(__file__).resolve().parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
P=R/'integration/f-ci/nomacro-complete01'
candidate='e66867c5de454f45fd8d4adde31f68454c61cf9c'
parent='9936bcda75eb920d67aa74e47018baf39ab18f78'
synthetic='18e31348e7e72fadc564c3046ce3645578bd46b1'
anchor='f28db55d7653d6029e870af45cc97ff310c5ffd4'
tree='e8bd491bbf37828528958c9ea4e982c0afac3bf8'
SHA=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((E/n).read_text())
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
api=read('FROST_BOUNDARY_STATE_CALENDAR04_PR1803_ACTUAL_GIT_API_V1.json')
actual=api['sha']
assert api['tree']['sha']==tree and [p['sha'] for p in api['parents']]==[parent,candidate]
for head in (candidate,synthetic,actual):
 assert git('rev-parse',head+'^{tree}')==tree
for head in (synthetic,actual):
 raw=(E/('FROST_BOUNDARY_STATE_CALENDAR04_PR1803_GENUINE_GIT_OBJECT_'+head+'.bin')).read_bytes()
 assert raw==subprocess.check_output(['git','cat-file','commit',head],cwd=R)
 assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==head
expected=json.loads((E/'FROST_BOUNDARY_STATE_CALENDAR04_CANDIDATE_PUBLIC_V2.stdout.txt').read_text())['coadmission']
assert (expected['contexts'],expected['short35_contexts'],expected['native_calendar_samples'],expected['exact_cold_windows'])==(568,546,3886,1672)
assert git('rev-parse','HEAD')==actual and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
observations={}
inputs=None
for role,version,head in [('CANDIDATE','V2',candidate),('ACTUAL_MERGE','V1',actual)]:
 for scope in ('PUBLIC','PUBLICATION'):
  label=f'FROST_BOUNDARY_STATE_CALENDAR04_{role}_{scope}_{version}'
  q=read(label+'.json');raw=(E/(label+'.stdout.txt')).read_bytes()
  assert q['returncode']==0 and q['before']==q['after']
  before=q['before'];assert before['head']==head and before['tree']==tree and not before['status']
  assert len(before['sparse'])==14 and len(before['original_project_files'])==56
  assert not (E/(label+'.stderr.txt')).read_bytes()
  if inputs is None:inputs=before['original_project_files']
  assert inputs==before['original_project_files']
  if scope=='PUBLIC':assert json.loads(raw)['coadmission']==expected
  else:
   assert b'PUBLICATION_REPLAY_SELECTED=false' in raw
   assert q['ordinary_python_default_dont_write_bytecode'] is False
   assert q['child_bytecode_environment_variables_absent']
  observations[label]=q['seconds']
negative=read('FROST_BOUNDARY_STATE_CALENDAR04_FINAL_NEGATIVES_V1.json')
assert negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
assert negative['candidate']==candidate and len(negative['controls'])==4
assert {q['role'] for q in negative['controls']}=={'SOURCE','RAW','INHERITED','PUBLICATION'}
for q in negative['controls']:
 assert q['actual_refusal'] and q['actual_one_file_delta'] and q['exact_parent']==candidate
 assert git('show','-s','--format=%P',q['head'])==candidate
 assert git('diff','--name-only',candidate,q['head'])==q['path']
ci=read('FROST_BOUNDARY_STATE_CALENDAR04_PR1803_FINAL_ALL_CI_API_V1.json')
runs=ci['runs']['workflow_runs'];checks=ci['checks']['check_runs']
assert len(runs)==15 and len({x['workflow_id'] for x in runs})==15
assert all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion']=='success' for x in runs)
assert len(checks)==ci['checks']['total_count']
assert all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion'] in ('success','skipped') for x in checks)
for role in ('CO2','DVS','LRV','TIMEINT_STARTUP','TIMEINT_INVERSE','FCI_MODULAR','POND'):
 label=f'FROST_BOUNDARY_STATE_CALENDAR04_PR1803_{role}_ORIGINAL_CI_V1.log'
 q=read(label+'.json');raw=(E/label).read_bytes()
 assert len(raw)==q['bytes'] and SHA(raw)==q['sha256']
 assert q['actual_source']==candidate
 assert candidate.encode() in raw and synthetic.encode() in raw
selection=read('FROST_BOUNDARY_STATE_CALENDAR04_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json')
assert selection['actual_current_head']==candidate and selection['actual_parent']==parent and selection['unchanged_tracked_files']==1063
assert not git('diff',parent,actual,'--',*selection['unchanged_dependency_paths'])
assert len(checks)==46 and sum(x['conclusion']=='success' for x in checks)==29 and sum(x['conclusion']=='skipped' for x in checks)==17
name='FROST_BOUNDARY_STATE_CALENDAR04_ADMISSION_RAW_V1';members={}
# Science archives are already committed once, with exact byte manifests. Preserve
# the original observer/CI/failure records and actual controllers here, not copies
# of those large scientific ZIPs.
paths=[p for p in E.iterdir() if p.is_file() and p.name.startswith('FROST_BOUNDARY_STATE_CALENDAR04_')
       and p.suffix in ('.json','.txt','.log','.bin')]
paths += [p for p in E.iterdir() if p.is_file() and p.name.startswith('frost-boundary-state-calendar04-') and p.suffix=='.py']
paths += [E/'frost_boundary_state_calendar_metadata.py']
paths += [p for p in E.glob('FROST_BOUNDARY_STATE_CALENDAR04_PR1803_FCI_MODULAR_ORIGINAL_CI_V1.log.*') if p.suffix in ('.zip','.gz')]
with zipfile.ZipFile(E/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):
  raw=p.read_bytes();assert p.name not in members
  z.writestr(p.name,raw);members[p.name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(E/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,item in members.items():
  raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=(E/(name+'.zip')).read_bytes();digest=SHA(raw);parts=[];chunk=25*1024*1024
for index,offset in enumerate(range(0,len(raw),chunk),1):
 piece=raw[offset:offset+chunk];file=name+'.zip'+('.part'+str(index).zfill(3) if len(raw)>chunk else '');(P/file).write_bytes(piece);assert (P/file).read_bytes()==piece;parts.append(dict(file=file,bytes=len(piece),sha256=SHA(piece)))
manifest=dict(status='ACTUAL_CANONICAL568_ORIGINAL_PUBLIC_ORDINARY_PUB_CI_NEGATIVES_AND_SIGNED_OBJECTS_PRESERVED',
 archive=name+'.zip',bytes=len(raw),sha256=digest,
 parts=parts,members=members,
 canonical_admission=True,actual_merge=actual,qualified_candidate=candidate,source_anchor=anchor,
 whole_tree=tree,coadmission=expected,actual_public_observations=observations,
 successful_workflows=len(runs),successful_checks=sum(x['conclusion']=='success' for x in checks),
 skipped_checks=sum(x['conclusion']=='skipped' for x in checks),
 full_model_periods_replayed_for_CI_or_observer_repairs=0,unchanged_MCSOL_model_replay='NOT_SELECTED_IMPACT_1063_EXACT_DEPENDENCY_FILES',
 whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',
 global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
receipt=dict(status='ACTUAL_CANONICAL568_FROST_BOUNDARY_STATE_CALENDAR_ADMISSION_VERIFIED',PR=1803,
 actual_merge=actual,qualified_candidate=candidate,source_anchor=anchor,whole_tree=tree,
 previous_canonical=parent,ordered_parents=[parent,candidate],synthetic_merge=synthetic,
 admission_archive_sha256=digest,coadmission=expected,canonical_admission=True,
 whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',
 global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
for filename,value in [(name+'.json',manifest),('FROST_BOUNDARY_STATE_CALENDAR04_MERGE_RECEIPT_V1.json',receipt)]:
 with (P/filename).open('x',encoding='utf8') as f:json.dump(value,f,indent=2);f.write('\n')
print(manifest['status'],len(raw),digest,len(members),flush=True)




