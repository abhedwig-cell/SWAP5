from pathlib import Path
from contextlib import ExitStack
import json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive
from frost_boundary_state_calendar_central import local_source
from frost_boundary_state_calendar_archive_science import case_audit
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();data=GitArchiveSource(R,head)
case=[x for x in json.loads((R/'integration/f-ci/nomacro-complete01/FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text())['representative_cases'] if x['name']=='cde-b8-i0-h0-p2-regular-r1'][0]
producer='dfb4337cb5fffcf70b1fa20a672683c6ea034690';results=[]
with ExitStack() as stack:
 original=Archive(data,'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
 current=Archive(data,'FROST_BOUNDARY_STATE_CALENDAR04_TRIAL_FLUX_LOCAL_WINDOWS_RAW_V1',stack)
 provenance=local_source(current,producer,'trial')
 for opt in ['O0','O2']:
  results.append(case_audit(current,'current/'+opt+'/'+case['name'],'compiled/'+opt+'/'+case['name']+'/bundle',original,case,producer,opt,trial_flux=True))
q=dict(status='INDEPENDENT_TWO_ACTUAL_CORRECTED_LOCAL_CONTEXTS_BUDGETS_NATIVE_COLD_CONTROLS_ZERO_CONVERGENCE_WARNINGS_PASS_NOT_ADMITTED',data_ref=head,actual_producer=producer,contexts=results,source_custody=provenance,compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_TRIAL_FLUX_LOCAL_INDEPENDENT_V1.json').write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],flush=True)
