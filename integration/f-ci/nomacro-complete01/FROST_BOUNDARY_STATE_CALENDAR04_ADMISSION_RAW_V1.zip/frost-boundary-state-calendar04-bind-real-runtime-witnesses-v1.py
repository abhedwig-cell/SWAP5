from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
path=P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json';q=json.loads(path.read_text());assert 'read_only_runtime_witnesses' not in q
edits={
 'tests/nomacro_drainage/frost_calendar_state_runtime.py':[("header=(4,nodes,solute,1,hys,6,1,0)","header=(4,nodes,solute,1,hys,selected.get('bottom',6),1,0)")],
 'tests/nomacro_drainage/frost_calendar_state_root_controls.py':[("    mode=m.e.switches((Path(profile['input_root'])/'swap.swp').read_text(encoding='cp1252'))['SWHYST']","    selected=m.e.switches((Path(profile['input_root'])/'swap.swp').read_text(encoding='cp1252'))\n    mode=selected['SWHYST'];bottom=selected['SWBOTB'];assert bottom in (5,6,8)"),("[4,project.nodes,int(project.solute),1,mode,6,1,0]","[4,project.nodes,int(project.solute),1,mode,bottom,1,0]")],
 'tests/nomacro_drainage/frost_calendar_state_extra_native.py':[("codecs=(b'S5FCW001',b'S5FCC001',b'S5FCW002',b'S5FCC002',b'S5FDW001',b'S5FDC001',b'S5FIW002',b'S5FIC002')","codecs=(b'S5FCW001',b'S5FCC001',b'S5FCW002',b'S5FCC002',b'S5FDW001',b'S5FDC001',b'S5FIW002',b'S5FIC002',\n            b'S5FBW001',b'S5FBC001',b'S5FBW002',b'S5FBC002',b'S5BCW001',b'S5BCC001',b'S5BCW002',b'S5BCC002')")]
}
q['read_only_runtime_witnesses']={}
for path,pairs in edits.items():
 a=git('show','HEAD:'+path).decode();b=a
 for old,new in pairs:assert b.count(old)==1,(path,old);b=b.replace(old,new,1)
 compile(b,path,'exec');q['read_only_runtime_witnesses'][path]=dict(before_lf_sha256=SHA(a.encode()),proposed_lf_sha256=SHA(b.encode()),ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if op!='equal'],scope='Read actual selected bottom in existing native witness; add real foreign codec controls. Existing independent budgets, periods, process source and 1e-10 guards unchanged.')
 (R/path).write_text(b,encoding='utf8',newline='\n')
q['status']='APP_AND_REAL_PUBLIC_INPUT_SCOPE_PASS_TARGETED_COMPILED_SCIENCE_PENDING';q['implementation_source']='b7d347ec9c95193f571e79f149543667871d82bf'
(P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8',newline='\n')
raw=(E.parent/'frost-boundary-state-calendar04-input-contract-v1/cases/RESULT.json').read_bytes();result=json.loads(raw);assert len(result['cases'])==12 and len(result['declines'])==13 and len(result['parent'])==6
(P/'FROST_BOUNDARY_STATE_CALENDAR04_INPUT_CONTRACT_V1.json').write_bytes(raw)
status=json.loads((P/'STATUS.json').read_text());status['frost_boundary_state_calendar04'].update(status='APP_PERSISTED_TWELVE_REAL_PUBLIC_LOADS_THIRTEEN_REFUSALS_SIX_OLD_SELECTIONS_AND_UNCHANGED_ROOT_SOURCE_PASS_SCIENCE_PENDING',implementation_source=q['implementation_source'],actual_reader_source=result['source'],input_contract='FROST_BOUNDARY_STATE_CALENDAR04_INPUT_CONTRACT_V1.json',changed_APP_files=len(q['files']),new_physical_state=False)
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8',newline='\n')
print('THREE_EXACT_READ_ONLY_NATIVE_WITNESS_ADAPTERS_FROZEN_NO_MODEL_REPLAY',len(q['files']),flush=True)
