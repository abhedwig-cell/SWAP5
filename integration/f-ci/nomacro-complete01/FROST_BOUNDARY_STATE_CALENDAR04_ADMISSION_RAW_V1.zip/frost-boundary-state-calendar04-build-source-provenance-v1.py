from pathlib import Path
import json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
B=E.parent/'frost-boundary-state-calendar04-water-smoke-O0-v1'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
actual=git('rev-parse','HEAD').decode().strip();registered='2e79dc38aba368aeb1cfc5278d7286ad81d014cb'
assert actual=='3feb51229a980331bc12be2d1d265bef7ae6691a'
assert not git('diff',registered,actual,'--','app','src','tools','reference')
assert git('diff','--name-only',registered,actual).decode().splitlines()==['tests/nomacro_drainage/frost_boundary_state_calendar_portable.py']
q=dict(status='REAL_CURRENT_HEAD_AND_REGISTERED_REPRODUCIBLE_CLI_SOURCE_ANCHOR_BOTH_RECORDED',registered_source_ref=registered,actual_build_HEAD=actual,added_controller='tests/nomacro_drainage/frost_boundary_state_calendar_portable.py',actual_public_builder_APP_src_tools_reference_bytes_unchanged=True,registry_re_registration_refused_due_existing_owned_resource_overlap=True,registry_modified_outside_shared_tool=False,source_or_HEAD_identity_projected=False,recipe='Actual current portable controller invokes the exact same public run_water.py builder, APP and original inputs as the registered2e79 source anchor; all actual build/science records retain genuine3feb HEAD.')
raw=json.dumps(q,indent=2)+'\n';(B/'SOURCE_PROVENANCE.json').write_text(raw,encoding='utf8');(E/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_BUILD_SOURCE_PROVENANCE_V1.json').write_text(raw,encoding='utf8');print(q['status'])
