from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive
SHA=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();data=GitArchiveSource(R,head);records=[]
with ExitStack() as stack:
 stores={}
 def get(name):
  if name not in stores:stores[name]=Archive(data,name,stack)
  return stores[name]
 name='FROST_BOUNDARY_STATE_CALENDAR04_TRIAL_DISCOVERY_AND_POSTIMAGES_RAW_V1';store=get(name);m=store.record
 for dependency,claim in m['exact_original_byte_dependencies'].items():assert get(dependency).record['sha256']==claim['sha256']
 for key,item in m['physical_inventory'].items():
  if key.startswith('controllers/'):continue
  path=W/key;assert path.is_relative_to(W) and path.is_file();raw=path.read_bytes();assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
  if 'member' in item:original=store.get(item['member'])
  else:
   d=item['inherited_exact_original_bytes'];original=get(d['archive']).get(d['member'])
  assert raw==original;records.append(dict(path=str(path),sha256=item['sha256'],central_original_bytes_exact=True))
 corrected=get('FROST_BOUNDARY_STATE_CALENDAR04_TRIAL_FLUX_LOCAL_WINDOWS_RAW_V1')
 for root in corrected.record['physical_inventory']:
  path=Path(root['original_path']);assert path.is_relative_to(W)
  for p in path.rglob('*'):
   if p.is_file():
    key=root['archive_prefix']+'/'+p.relative_to(path).as_posix();raw=p.read_bytes();assert corrected.get(key)==raw
    records.append(dict(path=str(p),sha256=SHA(raw),central_original_bytes_exact=True))
q=dict(status='ALL_CURRENT_LOCAL_DISCOVERY_POSTIMAGE_FAILURES_READERS_AND_CORRECTED_SCIENCE_BYTES_EXACT_IN_REAL_CURRENT_GIT_ARCHIVES',data_ref=head,files=records,compiler_executions=0,model_executions=0)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_CENTRAL_CUSTODY_BEFORE_RELEASE_V2.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],len(records),flush=True)
