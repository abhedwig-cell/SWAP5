from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';tool=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';SHA=lambda b:hashlib.sha256(b).hexdigest()
name='FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLOCK_LOCAL_WINDOWS_RAW_V1';m=json.loads((P/(name+'.json')).read_text());pieces=[]
for x in m['parts']:
 raw=subprocess.check_output(['git','show','0fae846dec07fb3b1a317a55b975accbbf110128:integration/f-ci/nomacro-complete01/'+x['file']],cwd=R);assert len(raw)==x['bytes'] and SHA(raw)==x['sha256'];pieces.append(raw)
assert SHA(b''.join(pieces))==m['sha256'] and SHA((E/(name+'.zip')).read_bytes())==m['sha256'];verified=[]
with zipfile.ZipFile(E/(name+'.zip')) as z:
 for item in m['physical_inventory']:
  root=Path(item['original_path']);count=0
  for p in root.rglob('*'):
   assert not p.is_symlink()
   if p.is_file():
    key=item['archive_prefix']+'/'+p.relative_to(root).as_posix();raw=p.read_bytes();assert raw==z.read(key) and SHA(raw)==m['members'][key]['sha256'];count+=1
  verified.append(dict(path=str(root),files=count,original_archive_sha256=m['sha256']))
# Old retained local water builds will become superseded by these released v3 builds.
old=json.loads((E/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_CENTRAL_BYTE_CUSTODY_V1.json').read_text())
old_manifest=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1.json').read_text())
with zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1.zip') as z:
 for opt in ('O0','O2'):
  root=W/f'frost-boundary-state-calendar04-water-smoke-{opt}-v1'
  for p in root.rglob('*'):
   if p.is_file():
    key='compiled/'+opt+'/'+p.relative_to(root).as_posix();assert p.read_bytes()==z.read(key) and SHA(p.read_bytes())==old_manifest['members'][key]['sha256']
allowed={str(Path(x['path'])).lower() for x in verified}|{str(W/f'frost-boundary-state-calendar04-water-smoke-{o}-v1').lower() for o in ('O0','O2')}
for item in verified:
 r=subprocess.run(['python','-B',str(tool),'release','--task',task,'--path',item['path']],capture_output=True);r.check_returncode()
preview=subprocess.run(['python','-B',str(tool),'cleanup','--task',task],capture_output=True);q=json.loads(preview.stdout)
eligible=[x for x in q['results'] if x['status'].startswith('eligible')]
assert eligible and all(str(Path(x['path'])).lower() in allowed for x in eligible)
r=subprocess.run(['python','-B',str(tool),'cleanup','--apply','--task',task],capture_output=True)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_PLATE_LOCAL_BYTE_CUSTODY_V1.json').write_text(json.dumps(dict(status='EVERY_RELEASED_CURRENT_FILE_EXACT_IN_CENTRAL_GIT_HELD_RAW_ARCHIVE',source='0fae846dec07fb3b1a317a55b975accbbf110128',verified=verified),indent=2)+'\n')
(E/'FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLEANUP_APPLIED_V1.json').write_bytes(r.stdout)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLEANUP_APPLIED_V1.stderr.txt').write_bytes(r.stderr)
q=json.loads(r.stdout);print(json.dumps(dict(returncode=r.returncode,net_free_change=q['net_free_change'],blocked_count=q['blocked_count'],deleted=[x['path'] for x in q['results'] if x['status']=='deleted'],blocked=[x for x in q['results'] if x['status']=='blocked']),indent=2))

