from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;W=E.parent;cleanup=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py')
q=json.loads((E/'FROST_CALENDAR_STATE02_BUILD_CENTRAL_BYTE_CUSTODY_V1.json').read_text());expected={str(W/f'frost-calendar-state02-cde-implicit-regular-year-hys1-initial2-{o}-daily-v2') for o in ('O0','O2')};checked=[]
for x in q['resources']:
 if x['path'] not in expected:continue
 root=Path(x['path']);files={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()};assert set(files)=={v['path'] for v in x['inventory']}
 for v in x['inventory']:assert files[v['path']].stat().st_size==v['bytes'] and hashlib.sha256(files[v['path']].read_bytes()).hexdigest()==v['sha256'] and v['preserved']
 checked.append(x['path'])
assert set(checked)==expected
r=subprocess.run(['python','-B',str(cleanup),'cleanup','--apply','--task','01a1e8b4-228b-75f1-8ac4-b07ca1e15713'],capture_output=True)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_OWN_FINISHED_RESOURCE_CLEANUP_V1.stdout.json').write_bytes(r.stdout)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_OWN_FINISHED_RESOURCE_CLEANUP_V1.stderr.txt').write_bytes(r.stderr)
out=json.loads(r.stdout);print(json.dumps(dict(returncode=r.returncode,net_free_change=out['net_free_change'],blocked_count=out['blocked_count'],results=[x for x in out['results'] if x['status']!='retained']),indent=2))

