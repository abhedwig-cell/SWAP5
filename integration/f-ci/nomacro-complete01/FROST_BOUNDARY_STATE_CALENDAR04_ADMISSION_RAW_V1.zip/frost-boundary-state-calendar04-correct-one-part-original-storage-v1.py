"""Correct only the storage filename of genuine one-part original ZIP bytes."""
from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='a47de6d5e1d3334098d69b001c09e27146fe84ce';assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
changes=[]
for path in P.glob('FROST_BOUNDARY_STATE_CALENDAR04_*.json'):
 q=json.loads(path.read_text());parts=q.get('parts')
 if not isinstance(parts,list) or len(parts)!=1 or parts[0]['file']==q['archive']:continue
 old=parts[0]['file'];new=q['archive'];assert old==new+'.part001' and Path(old).name==old and Path(new).name==new
 rel='integration/f-ci/nomacro-complete01/';before=git('show',head+':'+path.relative_to(R).as_posix());raw=git('show',head+':'+rel+old)
 assert len(raw)==parts[0]['bytes']==q['bytes'] and SHA(raw)==parts[0]['sha256']==q['sha256']
 target=P/new;assert not target.exists();target.write_bytes(raw)
 original_blob=git('rev-parse',head+':'+rel+old).decode().strip();actual_blob=git('hash-object',str(target)).decode().strip();assert original_blob==actual_blob
 parts[0]['file']=new;path.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
 subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','rm','--sparse','--',rel+old],cwd=R,capture_output=True,check=True)
 changes.append(dict(manifest=path.name,original_manifest_sha256=SHA(before),old_storage_file=old,new_storage_file=new,original_and_new_blob=original_blob,actual_archive_sha256=SHA(raw),actual_original_archive_bytes_changed=False,original_producer_and_artifact_ids_changed=False))
assert len(changes)==7,len(changes)
q=dict(status='SEVEN_ORIGINAL_SINGLE_PART_ZIPS_RENAMED_TO_STANDARD_ARCHIVE_API_LAYOUT_ALL_BYTES_EXACT',actual_parent=head,changes=changes,compiler_executions=0,model_executions=0,scientific_periods_replayed=0,canonical_admission=False)
for root in (P,E):(root/'FROST_BOUNDARY_STATE_CALENDAR04_SINGLE_PART_STORAGE_CUSTODY_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(q['status'],flush=True)

