from pathlib import Path
import json,zipfile
from decimal import Decimal,localcontext
E=Path(__file__).parent;prefix='current/cde-b8-i0-h0-p2-regular-r1/science/trajectory/'
for host in ('UBUNTU','WINDOWS'):
 for opt in ('O0','O2'):
  with zipfile.ZipFile(E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_ORIGINAL_V1.zip') as z:
   paths=[n for n in z.namelist() if n.startswith(prefix) and n.endswith('daily.jsonl')];assert len(paths)==1
   rows=[json.loads(line,parse_float=Decimal) for line in z.read(paths[0]).decode().splitlines()];row=rows[-1]
   print(host,opt,'rows',len(rows),'lastkeys',list(row))
   values={key:value for key,value in row.items() if key in ('day','committed','residual_cm','kernel_residual_cm','water_residual_cm','solute_start_mg_cm2','solute_end_mg_cm2','solute_ledger_mg_cm2','water_guard','solute_guard','reason','rejection','error','status') or any(x in key for x in ('resid','conver','reject','error','success'))}
   print(json.dumps(values,default=str))
   for name in z.namelist():
    if name.startswith(prefix) and name.endswith('EVENTS.json'):print(name,z.read(name).decode()[-800:])
