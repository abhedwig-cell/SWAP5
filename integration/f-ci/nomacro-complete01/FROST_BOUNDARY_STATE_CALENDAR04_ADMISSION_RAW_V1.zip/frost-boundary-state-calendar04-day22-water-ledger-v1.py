from pathlib import Path
import json,zipfile
E=Path(__file__).parent;prefix='current/cde-b8-i0-h0-p2-regular-r1/science/trajectory/'
with zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_UBUNTU_O0_ORIGINAL_V1.zip') as z:
 rows=[json.loads(x) for x in z.read(prefix+'daily.jsonl').decode().splitlines()]
 for row in rows[-2:]:print(json.dumps({k:v for k,v in row.items() if k not in ('pressure_head_cm','uptake_terms_cm')}))
 names=[n for n in z.namelist() if n.startswith(prefix) and n.endswith(('donor.stdout','kernel.stdout'))];print('OUTPUT_MEMBERS',names)
 for name in names[:3]:
  lines=z.read(name).decode(errors='replace').splitlines();print(name,'\n'.join([x for x in lines[-100:] if x.startswith('HYBRID_')])[-3500:])
