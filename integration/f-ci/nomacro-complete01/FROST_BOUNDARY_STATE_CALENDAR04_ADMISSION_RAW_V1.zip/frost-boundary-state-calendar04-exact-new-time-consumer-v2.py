from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';path='app/hybrid_water/daily_coupling.py'
q=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text());old=subprocess.check_output(['git','show','74ecc55765df548e758605f3566bc93558a6fefb:'+path],cwd=R)
assert path not in q['files'];q['files'][path]=dict(added=False,before_lf_sha256=hashlib.sha256(old).hexdigest(),proposed_lf_sha256=None,ordered_literal_edits=[])
q['numerical_plate_event_closure']['actual_build_failures_retained']={'7cc40bfedb':'Expected complete Frost hash differs from uncomposed original time-event closure hash; builder refused before compilation.','c555f7974c':'Public build succeeded; source consumer correctly refused new compiled TimeControl before any model run because exact postimage validator still expected old time source.'}
q['numerical_plate_event_closure']['exact_new_time_source_consumer']='daily_coupling validates full new emitted bytes by the same strict renderer only for selected new explicitplate; no unchanged-parent source guard removed.'
(P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
exec(compile((E/'frost-boundary-state-calendar04-freeze-plate-numerical-fix-v1.py').read_text(),'freeze','exec'),{'__file__':str(E/'frost-boundary-state-calendar04-freeze-plate-numerical-fix-v1.py')})

