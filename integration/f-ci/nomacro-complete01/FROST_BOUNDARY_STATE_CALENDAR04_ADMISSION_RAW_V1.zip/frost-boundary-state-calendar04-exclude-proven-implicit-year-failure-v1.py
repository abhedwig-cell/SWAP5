from pathlib import Path
import json
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';p=P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json';q=json.loads(p.read_text());cases=q['representative_cases'];assert len(cases)==12
blocked=cases.pop();assert blocked['name']=='cde-b5-i1-h2-p2-regular-r0-year-seam'
q['known_numerically_blocked_cases']=[blocked];q['blocked_new_implicit_hysteresis2_calendar_domain']=dict(classification='NUMERICAL_FAILURE',actual_source='dcae412aae8f65acb48b1e37431334c2c522c071',day=5,accepted_days=4,actual_four_original_failures='Implicit original retry reached clock resolution',hard_public_exclusion='New implicit hysteresis2 calendars remain closed; original admitted boundary03 hysteresis2 initial2 dense route is unchanged.',raw='FROST_BOUNDARY_STATE_CALENDAR04_THIRD_ORIGINALS_DIAGNOSTIC_V3.json',solver_bounds_or_restart_mass_limits_changed=False)
q['postimage_candidate_scope']=dict(representative_cases=11,contexts_if_all_gates_pass=44,full35_contexts=36,year12_contexts=8,whole_functional_completion='PARTIAL',canonical_admission=False)
p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
exec(compile((E/'frost-boundary-state-calendar04-freeze-plate-numerical-fix-v1.py').read_text(),'freeze','exec'),{'__file__':str(E/'frost-boundary-state-calendar04-freeze-plate-numerical-fix-v1.py')})
print('KNOWN_IMPLICIT_YEAR_FAILURE_PUBLIC_DOMAIN_CLOSED_OLD_DENSE_PARENT_RETAINED')

