from pathlib import Path
import zipfile,json,hashlib
E=Path(__file__).parent;D=E.parent/'frost-boundary-state-calendar04-dayclock-causal-v1';case='cde-b8-i0-h0-p2-regular-r1'
z=zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_WINDOWS_O0_ORIGINAL_V1.zip')
prefix='compiled/'+case+'/bundle/'
count=0
for n in z.namelist():
 if n.startswith(prefix):
  p=D/'original-bundle'/n[len(prefix):];p.parent.mkdir(parents=True,exist_ok=True);b=z.read(n)
  if p.exists():assert p.read_bytes()==b
  else:p.write_bytes(b)
  count+=1
for n in z.namelist():
 if n.startswith('current/'+case+'/inputs/'):
  p=D/'original-inputs'/n.split('/inputs/',1)[1];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
q=json.loads((D/'original-bundle/BUILD.json').read_text())
print('PRESERVED_EXACT_ORIGINAL_FAILED_BUNDLE',count,'TOP_KEYS',list(q))
for k,v in q.items():
 if any(x in k.lower() for x in ('command','link','compile','exe','path','build')):print(k,json.dumps(v)[:5000])
print('OBJECTS', [p.name for p in (D/'original-bundle').glob('*.o')][:12])

