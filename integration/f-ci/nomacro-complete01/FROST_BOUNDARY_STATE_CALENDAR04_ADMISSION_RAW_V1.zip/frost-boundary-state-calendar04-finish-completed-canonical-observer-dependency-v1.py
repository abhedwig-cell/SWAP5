"""End the completed canonical03 observer dependency; keep active work in R."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');C=Path('C:/Users/Veldh012/swap5-implicit-conductivity-canonical01');tool=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
git=lambda repo,*a:subprocess.check_output(['git',*a],cwd=repo)
head='9936bcda75eb920d67aa74e47018baf39ab18f78';assert git(C,'rev-parse','HEAD').decode().strip()==head
assert not git(C,'status','--porcelain=v1','--untracked-files=all','--ignored')
state=json.loads(Path('C:/Users/Veldh012/.codex/storage/swap5/state.json').read_text());owned=[x for x in state['resources'].values() if Path(x['path'])==C];assert len(owned)==1 and owned[0]['task']==task
prefix='integration/f-ci/nomacro-complete01/';receipt=json.loads(git(R,'show','HEAD:'+prefix+'FROST_BOUNDARY03_MERGE_RECEIPT_V1.json'));m=json.loads(git(R,'show','HEAD:'+prefix+'FROST_BOUNDARY03_ADMISSION_RAW_V1.json'))
assert receipt['actual_merge']==head and receipt['canonical_admission'] is True
raw=git(R,'show','HEAD:'+prefix+m['archive']);assert hashlib.sha256(raw).hexdigest()==m['sha256']==receipt['admission_archive_sha256']
import io,zipfile
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 for name,item in m['members'].items():
  b=z.read(name);assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
 for role in ('PUBLIC','PUBLICATION'):
  label='FROST_BOUNDARY03_ACTUAL_MERGE_'+role+'_V1';q=json.loads(z.read(label+'.json'));assert q['before']==q['after'] and q['before']['head']==head and q['returncode']==0 and len(q['before']['sparse'])==14 and len(q['before']['original_project_files'])==56
source=lambda root:{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()}
assert source(C)==source(R) and len(source(R))==56
record=dict(status='COMPLETED_OWN_CANONICAL524_OBSERVER_NO_LONGER_A_PHYSICAL_DEPENDENCY',actual_canonical=head,actual_archive=m['sha256'],every_original_admission_member_verified=True,actual_public_and_ordinary_publication_before_after_verified=True,unique_original_project_inputs_remain_exact_in_active_R=True,all_remaining_C_files_clean_tracked_and_retained_by_Git=True,completed_checkout=str(C),active_checkout=str(R),next_actual_canonical_observation='After candidate qualification and genuine merge, switch the single active R checkout normally to the actual signed merge and run real PUBLIC and ordinary publication there; no fake identity or additional baseline required.',main_task_remains_active=True)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_COMPLETED_CANONICAL_OBSERVER_CUSTODY_V1.json').write_text(json.dumps(record,indent=2)+'\n')
for command in ('unprotect','release'):
 p=subprocess.run(['python','-B',str(tool),command,'--task',task,'--path',str(C)],capture_output=True);assert p.returncode==0,p.stderr.decode();print(p.stdout.decode().strip(),flush=True)
print(record['status'],flush=True)

