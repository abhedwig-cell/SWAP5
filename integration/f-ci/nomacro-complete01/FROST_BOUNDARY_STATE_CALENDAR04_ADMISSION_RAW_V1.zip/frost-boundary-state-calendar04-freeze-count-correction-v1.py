from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;P=R/'integration/f-ci/nomacro-complete01'
for opt in ('O0','O2'):
 f=E.parent/'frost-boundary-state-calendar04-water-smoke-v1'/opt/'water-b5-i0-h0-p1-regular-r0'
 sci=json.loads((f/'science/RESULT.json').read_text());assert sci['source']=='3feb51229a980331bc12be2d1d265bef7ae6691a' and sci['status']=='ACTUAL_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED'
 failed=json.loads((f/'controls/RESULT.json').read_text());assert failed['status']=='FAILED_ACTUAL_FROST_CALENDAR_CONTROLS_NOT_QUALIFIED' and len(failed['existing_calendar_thermal_refusals'])==39
 assert 'assert len(checks)==(31 if project.solute else 27)' in (f/'controls-controller/controller.stderr').read_text()
path='tests/nomacro_drainage/frost_calendar_state_extra_native.py';a=subprocess.check_output(['git','show','74ecc55765df548e758605f3566bc93558a6fefb:'+path],cwd=R).decode();b=(R/path).read_text();compile(b,path,'exec')
p=P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json';q=json.loads(p.read_text());q['read_only_runtime_witnesses'][path]=dict(before_lf_sha256=hashlib.sha256(a.encode()).hexdigest(),proposed_lf_sha256=hashlib.sha256(b.encode()).hexdigest(),ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if op!='equal'],scope='Sixteen distinct known codecs, fifteen actual foreign codec refusals, unchanged20Snow attacks and four extra CDE-private attacks. Correct explicit totals35water/39CDE; no native check or physical limit weakened.')
q['local_scientific_progress']=dict(actual_compiler_source='3feb51229a980331bc12be2d1d265bef7ae6691a',Windows_O0_full35_and_cold='PASS',Windows_O2_full35_and_cold='PASS',native_refusal_controller='Actual39existing and35expanded raw refusals completed before stale aggregate count assertion; raw data and failed reports retained; independent read-only recovery and previously unexecuted real transactions pending.',compiler_or_model_replay_for_count_correction=False)
p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8',newline='\n');print('READ_ONLY_TOTALS_CORRECTED_FROZEN_BOTH_REAL_PERIODS_PRESERVED_NO_APP_CHANGE')
