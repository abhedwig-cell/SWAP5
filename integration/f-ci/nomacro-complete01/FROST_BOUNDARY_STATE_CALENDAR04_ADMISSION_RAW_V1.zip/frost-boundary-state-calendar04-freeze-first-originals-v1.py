from pathlib import Path
import hashlib,json,subprocess,zipfile
from decimal import Decimal
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
SOURCE='71806beaee8e532af407ab88298b7bde4ac766c2';SHA=lambda b:hashlib.sha256(b).hexdigest()
contract=json.loads(subprocess.check_output(['git','show',SOURCE+':integration/f-ci/nomacro-complete01/FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json'],cwd=R))
summary=dict(status='FIRST_ORIGINAL_COHORTS_FAILED_PROFILE_RETAINED_COMPLETED_PRECEDING_PERIODS_PRESERVED_NOT_ADMITTED',actual_source=SOURCE,archives=[],completed_contexts=0,completed_primary_days=0,native_samples=0,exact_cold_windows=0,actual_compiled_refusals=0,transaction_contexts=0,failed_profile='cde-b8-i0-h0-p2-regular-r1',failure_classification='NUMERICAL_FAILURE_WATER_GUARD_REJECTION_ROOT_CAUSE_NOT_PROVEN',failed_profiles=[])
for host in ('UBUNTU','WINDOWS'):
 api=json.loads((E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_FIRST_ORIGINAL_ARTIFACTS_API_V1.json').read_text())
 for opt in ('O0','O2'):
  name=f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_ORIGINAL_V1';path=E/(name+'.zip');raw=path.read_bytes();matches=[x for x in api['artifacts'] if '-'+opt+'-' in x['name']];assert len(matches)==1;artifact=matches[0]
  assert len(raw)==artifact['size_in_bytes'] and 'sha256:'+SHA(raw)==artifact['digest'];members={}
  with zipfile.ZipFile(path) as z:
   assert len(set(z.namelist()))==len(z.namelist())
   for item in z.infolist():
    assert not item.is_dir() and not item.filename.startswith('/') and '..' not in item.filename.split('/');data=z.read(item.filename);assert len(data)==item.file_size;members[item.filename]=dict(bytes=len(data),sha256=SHA(data))
   q=json.loads(z.read('current/RESULT.json'));assert q['source']==SOURCE and q['status']=='FAILED_ACTUAL_BOUNDARY_STATE_CALENDAR_NOT_QUALIFIED'
   workflow=f'.github/workflows/nomacro-frost-boundary-state-calendar04-{host.lower()}.yml';actual=z.read('actual-workflow.yml');expected=subprocess.check_output(['git','show',SOURCE+':'+workflow],cwd=R);assert actual==expected and SHA(actual)==contract['original_scientific_workflows'][workflow]['sha256']
   complete=[x for x in q['contexts'] if x['science'] and x['controls']];assert len(complete)==(3 if host=='UBUNTU' else 2)
   for item in complete:
    sci,ctrl=item['science'],item['controls'];assert sci['source']==SOURCE and sci['status']=='ACTUAL_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED' and ctrl['status']=='ACTUAL_FROST_CALENDAR_COMPILED_NATIVE_SNOW_CDE_ROOT_AND_TRANSACTIONS_PASS_NOT_ADMITTED'
    summary['completed_contexts']+=1;summary['completed_primary_days']+=sci['duration_days'];summary['native_samples']+=len(sci['native_samples']);summary['exact_cold_windows']+=len(sci['own']);summary['actual_compiled_refusals']+=len(ctrl['existing_calendar_thermal_refusals'])+len(ctrl['new_snow_private_and_codec_refusals'])+(len(ctrl['root']['refusals']) if ctrl.get('root') else 0);summary['transaction_contexts']+=2
   prefix='current/'+summary['failed_profile']+'/science/';failed=json.loads(z.read(prefix+'RESULT.json'));assert failed['error']=="ValueError('Rejected day 22')"
   rows=[json.loads(line,parse_float=Decimal) for line in z.read(prefix+'trajectory/daily.jsonl').decode().splitlines()];last=rows[-1]
   assert len(rows)==22 and sum(x['committed'] for x in rows)==21 and last['day']==22 and not last['committed'] and last['revision']==21
   assert abs(last['independent_residual_cm'])>Decimal('1e-10') and abs(last['kernel_residual_cm'])>Decimal('1e-10') and abs(last['solute_independent_residual_mg_cm2'])<=Decimal('1e-10')
   summary['failed_profiles'].append(dict(platform=host,optimization=opt,accepted_days=21,rejected_day=22,water_residual_cm=str(last['independent_residual_cm']),kernel_residual_cm=str(last['kernel_residual_cm']),chemical_residual_mg_cm2=str(last['solute_independent_residual_mg_cm2']),original_integrated_guard_residual_cm=str(last['integrated_guard_residual_cm']),budget_step_retries=last['budget_step_retries'],actual_cause='NOT_PROVEN',no_tolerance_or_inventory_or_flux_correction=True))
  chunk=25*1024*1024;parts=[dict(file=name+'.zip.part'+str(i//chunk+1).zfill(3),bytes=len(raw[i:i+chunk]),sha256=SHA(raw[i:i+chunk])) for i in range(0,len(raw),chunk)]
  manifest=dict(status='OFFICIAL_ORIGINAL_FAILED_COHORT_AND_COMPLETE_PRECEDING_SCIENCE_BYTES_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,original_artifact_id=artifact['id'],original_artifact_digest=artifact['digest'],original_science_source=SOURCE,original_workflow_record=workflow,original_cohort_status=q['status'],completed_contexts=len(complete),failed_profile=summary['failed_profile'],parts_to_be_materialized_in_central_Git_when_returning_to_owned_batch04=True,canonical_admission=False)
  with (E/(name+'.json')).open('x',encoding='utf8') as f:json.dump(manifest,f,indent=2);f.write('\n')
  summary['archives'].append(dict(name=name,sha256=SHA(raw),bytes=len(raw),members=len(members),completed_contexts=len(complete)))
assert (summary['completed_contexts'],summary['completed_primary_days'],summary['native_samples'],summary['exact_cold_windows'],summary['actual_compiled_refusals'],summary['transaction_contexts'])==(10,350,70,30,776,20)
summary.update(local_completed_contexts=2,total_with_local_completed_contexts=12,total_with_local_primary_days=420,remaining_unexecuted_contexts=32,failed_repeated_contexts=4,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
with (E/'FROST_BOUNDARY_STATE_CALENDAR04_FIRST_ORIGINALS_AND_DAY22_DIAGNOSTIC_V1.json').open('x',encoding='utf8') as f:json.dump(summary,f,indent=2);f.write('\n')
print(summary['status'],summary['completed_contexts'],summary['completed_primary_days'],summary['remaining_unexecuted_contexts'],flush=True)
