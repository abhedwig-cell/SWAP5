from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
SOURCE='0fae846dec07fb3b1a317a55b975accbbf110128';SHA=lambda b:hashlib.sha256(b).hexdigest()
summary=dict(status='FOURTH_REAL_PLATE_COHORTS_COMPLETE_ALL_ORIGINAL_BYTES_PRESERVED_NOT_ADMITTED',source=SOURCE,complete=[],failures=[],archives=[],canonical_admission=False)
for host in ('UBUNTU','WINDOWS'):
 api=json.loads((E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_FOURTH_ORIGINAL_ARTIFACTS_API_V4.json').read_text())
 for opt in ('O0','O2'):
  name=f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_ORIGINAL_V4';raw=(E/(name+'.zip')).read_bytes()
  art=[a for a in api['artifacts'] if '-'+opt+'-' in a['name']];assert len(art)==1;art=art[0]
  assert len(raw)==art['size_in_bytes'] and 'sha256:'+SHA(raw)==art['digest'];members={}
  with zipfile.ZipFile(E/(name+'.zip')) as z:
   assert len(set(z.namelist()))==len(z.namelist())
   for i in z.infolist():
    assert not i.is_dir() and not i.filename.startswith('/') and '..' not in i.filename.split('/')
    b=z.read(i.filename);assert len(b)==i.file_size;members[i.filename]=dict(bytes=len(b),sha256=SHA(b))
   q=json.loads(z.read('current/RESULT.json'));assert q['source']==SOURCE and q['status']=='ACTUAL_SELECTED_BOUNDARY_STATE_CALENDAR_PERIODS_NATIVE_COLD_AND_CONTROLS_PASS_NOT_ADMITTED'
   workflow=f'.github/workflows/nomacro-frost-boundary-state-calendar04-{host.lower()}.yml'
   assert z.read('actual-workflow.yml').replace(b'\r\n',b'\n')==subprocess.check_output(['git','show','0fae846dec07fb3b1a317a55b975accbbf110128:'+workflow],cwd=R)
   for x in q['contexts']:
    case=x['case']['name'];prefix='current/'+case+'/science/'
    if x['science'] and (x['controls'] or x['case']['days']==12):
     s=x['science'];c=x['controls'];assert s['source']==SOURCE
     summary['complete'].append(dict(platform=host,optimization=opt,case=case,days=s['duration_days'],native=len(s['native_samples']),cold=len(s['own']),refusals=(len(c['existing_calendar_thermal_refusals'])+len(c['new_snow_private_and_codec_refusals'])+(len(c['root']['refusals']) if c.get('root') else 0)) if c else 0,transactions=2 if c else 0))
    else:
     s=json.loads(z.read(prefix+'RESULT.json'));f=dict(platform=host,optimization=opt,case=case,error=s.get('error'),root_cause='NOT_PROVEN',classification='NUMERICAL_FAILURE_IMPLICIT_CLOCK_RESOLUTION_DAY5')
     if prefix+'trajectory/daily.jsonl' in members:
      rows=[json.loads(t) for t in z.read(prefix+'trajectory/daily.jsonl').splitlines()]
      f.update(accepted_days=sum(r['committed'] for r in rows),last_row=rows[-1] if rows else None)
     summary['failures'].append(f)
  parts=[];chunk=25*1024*1024
  for n,offset in enumerate(range(0,len(raw),chunk),1):
   b=raw[offset:offset+chunk];file=name+'.zip.part'+str(n).zfill(3);path=P/file
   if path.exists():assert path.read_bytes()==b
   else:path.write_bytes(b)
   assert SHA(path.read_bytes())==SHA(b);parts.append(dict(file=file,bytes=len(b),sha256=SHA(b)))
  assert b''.join((P/x['file']).read_bytes() for x in parts)==raw
  m=dict(status='OFFICIAL_ORIGINAL_COMPLETE_PLATE_COHORT_ALL_BYTES_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,original_artifact_id=art['id'],original_artifact_digest=art['digest'],original_science_source=SOURCE,original_workflow_record=workflow,original_cohort_status=q['status'],canonical_admission=False)
  for target in (E/(name+'.json'),P/(name+'.json')):target.write_text(json.dumps(m,indent=2)+'\n',encoding='utf8')
  summary['archives'].append(dict(name=name,bytes=len(raw),sha256=SHA(raw)))
summary['completed_contexts']=len(summary['complete'])
for key in ('days','native','cold','refusals','transactions'):summary[key]=sum(x[key] for x in summary['complete'])
assert summary['completed_contexts']==14 and summary['days']==398
summary.update(plate_completed_with_local=16,plate_days_with_local=468,unaffected_bottom5_period_contexts=28,unaffected_bottom5_inheritance='PENDING_ACTUAL_POSTIMAGE_GATES',candidate_total_if_all_admission_gates_pass=44,known_implicit_year_failures_retained=4,new_failed_contexts=len(summary['failures']),unexecuted_contexts=0,whole_completion='PARTIAL',equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
for target in (E,P): (target/'FROST_BOUNDARY_STATE_CALENDAR04_FOURTH_ORIGINALS_DIAGNOSTIC_V4.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print('PRESERVED_FOURTH_ORIGINALS',summary['completed_contexts'],summary['days'],'FAILED',len(summary['failures']),'UNEXECUTED',summary['unexecuted_contexts'])



