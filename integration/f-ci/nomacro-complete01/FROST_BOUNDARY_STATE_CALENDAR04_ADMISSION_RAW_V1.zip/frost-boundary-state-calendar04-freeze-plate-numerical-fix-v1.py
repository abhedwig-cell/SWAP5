from pathlib import Path
import difflib,hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
q=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text());base='74ecc55765df548e758605f3566bc93558a6fefb'
for path,item in q['files'].items():
 raw=(R/path).read_bytes().replace(b'\r\n',b'\n');unchanged=item['proposed_lf_sha256']==SHA(raw);item['proposed_lf_sha256']=SHA(raw)
 if item['added'] or unchanged:continue
 old=subprocess.check_output(['git','show',base+':'+path],cwd=R);assert SHA(old)==item['before_lf_sha256']
 a,b=old.decode(),raw.decode();edits=[]
 for tag,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
  if tag!='equal':edits.append(dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]))
 item['ordered_literal_edits']=edits
q['status']='ACTUAL_DAY_CLOCK_REDUCTION_DEFECT_REPRODUCED_EXPLICIT_PLATE_FIX_IMPLEMENTED_NOT_QUALIFIED'
q['numerical_plate_event_closure']=dict(classification='A_NUMERICAL_TIME_EXECUTION_REPAIR',scope='Only new boundary_state_calendar selection with explicit SWBOTB8; parent03, all bottom5 and implicit routes unchanged',original_source='71806beaee8e532af407ab88298b7bde4ac766c2',actual_observation='RESULT_V2.json in clock diagnostic archive',observed_day=22,actual_integrated_duration='0.999999992172108332',existing_dtCrit='1e-8 unchanged',water_limit_cm='1e-10 unchanged',original_defect='TimeControl task5 reduces to dtmin and returns without reapplying event closure; task3 accepts near-EOD while once-daily Snow already advanced full day.',failed_counterfactual='Print event alignment alone did not fix the real failure; RESULT_V3 preserved.',successful_counterfactual='Same original compiled closure plus print alignment and existing event rule after failed-step reduction completes35days; diagnostic only, no restart or independent qualification claim.',model_equations_changed=False,mass_flux_stock_or_residual_corrections=False,implicit_retry_limit_changed=False,required_new_science='Windows/Ubuntu O0/O2 four representative explicit plate configurations; local original failed regular case O0/O2 first.',unaffected_evidence='Reuse bottom5 periods only after exact current emitted physical postimage comparison; no metadata-only full-period replay.',diagnostic_archive='FROST_BOUNDARY_STATE_CALENDAR04_ACTUAL_CLOCK_DIAGNOSTIC_AND_READERS_RAW_V1.json')
q['third_scientific_epoch'].update(status='ALL_TERMINAL_FAILED_ORIGINAL_BYTES_PRESERVED',source='dcae412aae8f65acb48b1e37431334c2c522c071',Ubuntu_run=45666500370,Windows_run=45666500285,completed_contexts=10,completed_primary_days=166,total_completed_all_unchanged_source_epochs=38,failed_implicit_year_contexts=4,failure='Implicit original retry reached clock resolution at day5, four original platform/optimization contexts; bounds unchanged.',diagnostic='FROST_BOUNDARY_STATE_CALENDAR04_THIRD_ORIGINALS_DIAGNOSTIC_V3.json')
(P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for name in ('STATUS.json','GAP_MATRIX.json'):
 s=json.loads((P/name).read_text());s['frost_boundary_state_calendar04'].update(status=q['status'],third_epoch=q['third_scientific_epoch'],plate_clock_repair=q['numerical_plate_event_closure'])
 if name=='STATUS.json':
  s['canonical']='9936bcda75eb920d67aa74e47018baf39ab18f78';s['branch']='codex/nomacro-frost-boundary-state-calendar04'
  s['next_action']='Finish live actual canonical03 PUBLIC and ordinary publication observers at9936bcda75 then admission seal. Run actual new public plate clock repair O0/O2 local first; execute affected16contexts onWindows/Ubuntu. Preserve untouched bottom5 science through actual emitted postimage comparison. Investigate independent implicit5 year-seam day5 clock-resolution refusal; no retry/mass thresholds changed.'
 (P/name).write_text(json.dumps(s,indent=2)+'\n',encoding='utf8')
print('EXPLICIT_NUMERICAL_REPAIR_CONTRACT_FROZEN_UNCHANGED_MASS_AND_RETRY_LIMITS')

