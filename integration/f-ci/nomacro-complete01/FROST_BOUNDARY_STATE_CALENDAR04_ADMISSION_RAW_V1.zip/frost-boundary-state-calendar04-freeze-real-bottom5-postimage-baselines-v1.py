from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
c=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text());records={};archives={}
for host in ('WINDOWS','UBUNTU'):
 for opt in ('O0','O2'):
  for index in (0,1,4,5):
   case=c['representative_cases'][index];name=case['name'];version=1 if index<2 else 2;manifest=f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_ORIGINAL_V{version}.json'
   prefix='compiled/'+name+'/bundle/';inputs='current/'+name+'/inputs/';anchor='511d207f7ab9c0d543b5edab7aa7ad649c6896ce' if version==1 else 'bc79f1dd87ec89198a27f5a3b28c3b722d08236c'
   if host=='WINDOWS' and index==0:manifest='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1.json';prefix=f'compiled/{opt}/{name}/bundle/';inputs=f'current/{opt}/{name}/inputs/'
   raw=subprocess.check_output(['git','show',anchor+':integration/f-ci/nomacro-complete01/'+manifest],cwd=R);m=json.loads(raw);path=E/m['archive']
   if str(path) not in archives:
    assert SHA(path.read_bytes())==m['sha256'];archives[str(path)]=zipfile.ZipFile(path)
   z=archives[str(path)];b=z.read(prefix+'BUILD.json');assert SHA(b)==m['members'][prefix+'BUILD.json']['sha256'];meta=json.loads(b);files={}
   for file,digest in meta['identity']['donor_generated'].items():
    b=z.read(prefix+file);assert SHA(b)==digest==m['members'][prefix+file]['sha256'];obj=Path(file).with_suffix('.o').as_posix();o=z.read(prefix+obj);assert SHA(o)==m['members'][prefix+obj]['sha256']
    files[file]=dict(original_raw_sha256=SHA(b),original_LF_sha256=SHA(b.replace(b'\r\n',b'\n')),object_file=obj,original_object_sha256=SHA(o))
   records[host+'/'+opt+'/'+name]=dict(original_manifest=manifest,original_manifest_anchor=anchor,original_manifest_sha256=SHA(raw),original_archive_sha256=m['sha256'],original_compiler_source=m.get('original_science_source',m.get('actual_compiler_source')),original_BUILD_sha256=SHA(z.read(prefix+'BUILD.json')),compiler={k:meta['identity'][k] for k in ('compiler','compiler_sha256','target','donor_flags','kernel_flags')},generated=files,inputs={key[len(inputs):]:value for key,value in m['members'].items() if key.startswith(inputs)})
for z in archives.values():z.close()
q=dict(status='ACTUAL_IMMUTABLE_ORIGINAL_RAW_AND_LF_SOURCE_IDENTITIES_AND_UNALTERED_OBJECT_HASHES',normalization='Only CRLF to LF for explicitly separate textual source identity; raw identities remain original and compiled object equality is never normalized.',compiler_identity_must_match_for_compiled_object_inheritance=True,records=records,compiler_executions=0,model_executions=0,canonical_admission=False)
for root in (P,E):(root/'FROST_BOUNDARY_STATE_CALENDAR04_BOTTOM5_PHYSICAL_POSTIMAGE_BASELINES_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(q['status'],len(records))

