from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
SOURCE='dcae412aae8f65acb48b1e37431334c2c522c071';SHA=lambda b:hashlib.sha256(b).hexdigest()
summary=dict(status='THIRD_REAL_COHORTS_FAILED_COMPLETE_PRECEDING_PERIODS_PRESERVED_NOT_ADMITTED',source=SOURCE,complete=[],failures=[],archives=[],canonical_admission=False)
for host in ('UBUNTU','WINDOWS'):
 api=json.loads((E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_THIRD_ORIGINAL_ARTIFACTS_API_V3.json').read_text())
 for opt in ('O0','O2'):
  name=f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_ORIGINAL_V3';raw=(E/(name+'.zip')).read_bytes()
  art=[a for a in api['artifacts'] if '-'+opt+'-' in a['name']];assert len(art)==1;art=art[0]
  assert len(raw)==art['size_in_bytes'] and 'sha256:'+SHA(raw)==art['digest'];members={}
  with zipfile.ZipFile(E/(name+'.zip')) as z:
   assert len(set(z.namelist()))==len(z.namelist())
   for i in z.infolist():
    assert not i.is_dir() and not i.filename.startswith('/') and '..' not in i.filename.split('/')
    b=z.read(i.filename);assert len(b)==i.file_size;members[i.filename]=dict(bytes=len(b),sha256=SHA(b))
   q=json.loads(z.read('current/RESULT.json'));assert q['source']==SOURCE and q['status']=='FAILED_ACTUAL_BOUNDARY_STATE_CALENDAR_NOT_QUALIFIED'
   workflow=f'.github/workflows/nomacro-frost-boundary-state-calendar04-{host.lower()}.yml'
   assert z.read('actual-workflow.yml').replace(b'\r\n',b'\n')==subprocess.check_output(['git','show','bc79f1dd87ec89198a27f5a3b28c3b722d08236c:'+workflow],cwd=R)
   for x in q['contexts']:
    case=x['case']['name'];prefix='current/'+case+'/science/'
    if x['science'] and (x['controls'] or x['case']['days']==12):
     s=x['science'];c=x['controls'];assert s['source']==SOURCE
     summary['complete'].append(dict(platform=host,optimization=opt,case=case,days=s['duration_days'],native=len(s['native_samples']),cold=len(s['own']),refusals=(len(c['existing_calendar_thermal_refusals'])+len(c['new_snow_private_and_codec_refusals'])+(len(c['root']['refusals']) if c.get('root') else 0)) if c else 0,transactions=2 if c else 0))
    else:
     s=json.loads(z.read(prefix+'RESULT.json'));f=dict(platform=host,optimization=opt,case=case,error=s.get('error'),root_cause='NOT_PROVEN',classification='NUMERICAL_FAILURE_IMPLICIT_CLOCK_RESOLUTION_DAY5')
     if prefix+'trajectory/daily.jsonl' in members:
      rows=[json.loads(t) for t in z.read(prefix+'trajectory/daily.jsonl').splitlines()]
      f.update(accepted_days=sum(r['committed'] for r in rows),last_row=rows[-1] if rows else None)
     summary['failures'].append(f)
  parts=[];chunk=25*1024*1024
  for n,offset in enumerate(range(0,len(raw),chunk),1):
   b=raw[offset:offset+chunk];file=name+'.zip.part'+str(n).zfill(3);path=P/file
   if path.exists():assert path.read_bytes()==b
   else:path.write_bytes(b)
   assert SHA(path.read_bytes())==SHA(b);parts.append(dict(file=file,bytes=len(b),sha256=SHA(b)))
  assert b''.join((P/x['file']).read_bytes() for x in parts)==raw
  m=dict(status='OFFICIAL_ORIGINAL_FAILED_COHORT_ALL_BYTES_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,original_artifact_id=art['id'],original_artifact_digest=art['digest'],original_science_source=SOURCE,original_workflow_record=workflow,original_cohort_status=q['status'],canonical_admission=False)
  for target in (E/(name+'.json'),P/(name+'.json')):target.write_text(json.dumps(m,indent=2)+'\n',encoding='utf8')
  summary['archives'].append(dict(name=name,bytes=len(raw),sha256=SHA(raw)))
summary['completed_contexts']=len(summary['complete'])
for key in ('days','native','cold','refusals','transactions'):summary[key]=sum(x[key] for x in summary['complete'])
assert summary['completed_contexts']==10 and summary['days']==166
summary.update(total_completed_with_first_second_and_local=38,previous_known_failure_contexts=6,new_failed_contexts=len(summary['failures']),unexecuted_contexts=0,whole_completion='PARTIAL',equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
for target in (E,P): (target/'FROST_BOUNDARY_STATE_CALENDAR04_THIRD_ORIGINALS_DIAGNOSTIC_V3.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print('PRESERVED_THIRD_ORIGINALS',summary['completed_contexts'],summary['days'],'FAILED',len(summary['failures']),'UNEXECUTED',summary['unexecuted_contexts'])


