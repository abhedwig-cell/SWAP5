from pathlib import Path
import difflib,hashlib,json,subprocess
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';base='74ecc55765df548e758605f3566bc93558a6fefb'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
SHA=lambda b:hashlib.sha256(b).hexdigest()
q=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text())
paths=set(q['files'])|{'app/hybrid_water/daily_host.py','app/hybrid_water/frost_boundary_terminal_trial.py'}
for path in sorted(paths):
 raw=(R/path).read_bytes().replace(b'\r\n',b'\n');exists=subprocess.run(['git','cat-file','-e',base+':'+path],cwd=R,capture_output=True).returncode==0
 item=dict(q['files'].get(path,{}));item.update(added=not exists,proposed_lf_sha256=SHA(raw))
 if exists:
  old=git('show',base+':'+path);a=old.decode();b=raw.decode();al=a.splitlines(keepends=True);bl=b.splitlines(keepends=True)
  offsets=[0]
  for line in al:offsets.append(offsets[-1]+len(line))
  item['before_lf_sha256']=SHA(old);item['ordered_literal_edits']=[dict(base_start=offsets[i],base_end=offsets[j],before=''.join(al[i:j]),after=''.join(bl[k:l])) for tag,i,j,k,l in difflib.SequenceMatcher(None,al,bl,autojunk=False).get_opcodes() if tag!='equal']
 q['files'][path]=item
diagnostic=json.loads((W/'frost-boundary-state-calendar04-dayclock-causal-v1/trial-flux-counterfactual-v2/RESULT.json').read_text())
assert diagnostic['accepted_days']==35 and diagnostic['failure'] is None and not diagnostic['convergence_warnings']
record=dict(status='REPRODUCED_STALE_TERMINAL_TRIAL_FLUX_DIAGNOSTIC_FIX_35_DAYS_ZERO_CONVERGENCE_WARNINGS_NOT_QUALIFIED',actual_original_source='0566877f3d1ef27a472c4fae6f5275e8e76871a4',discovery_HEAD=git('rev-parse','HEAD').decode().strip(),plate04_warning_scan=json.loads((E/'FROST_BOUNDARY_STATE_CALENDAR04_PLATE_ORIGINAL_CONVERGENCE_WARNING_SCAN_V1.json').read_text()),parent03_warning_scan=json.loads((E/'FROST_BOUNDARY_STATE_CALENDAR04_PARENT524_CONVERGENCE_WARNING_DISCOVERY_V1.json').read_text()),counterfactual=diagnostic,scope='Explicit Frost/SWDIVD1 SWBOTB8 only, both existing03 dense and new04 calendars; implicit and bottom5 physical postimages unchanged',new_interface='Private terminal_water_trial_terms receives actual original trial flux; new trial_residual getter. Existing terminal_water_terms and terminal_water_residual signatures and global-qbot behavior preserved.',actual_observed_global_qbot=0.0,actual_observed_candidate_bottom_cm_d=-3.26025943986953637,physical_equations_changed=False,stock_flux_or_residual_correction=False,tolerances_changed=False,clock='Restore already qualified original explicit Frost TimeControl. Prior clock-only fix still produced daily convergence warnings and is superseded.',parent03_disposition='Eight explicit plate35day contexts have original No convergence warnings. Historical prior admission remains recorded; their current convergence qualification is reopened and cannot be inherited.',canonical_admission=False)
name='FROST_BOUNDARY_STATE_CALENDAR04_TERMINAL_TRIAL_DISCOVERY_V1.json';(P/name).write_text(json.dumps(record,indent=2)+'\n')
q.update(status='EXPLICIT_PLATE_TERMINAL_TRIAL_FLUX_CORRECTED_NOT_QUALIFIED',classification='A_NUMERICAL_CONVERGENCE_GUARD_RECEIPT_REPAIR_AND_B_EXISTING_PROCESS_COMPOSITION',design=record['scope']+'; actual candidate lower flux is supplied to the unchanged day/interval terminal receipt. No physical-state or conservation correction. Existing original clock restored.',numerical_trial_receipt_repair=dict(record=name,scope=record['scope'],required_qualification='24 actual Windows/Ubuntu O0/O2 explicit plate contexts: four new04 and two reopened03 cases; whole periods, native, cold, transactions and zero convergence warnings. Unchanged bottom5 uses exact compiled postimages.'),numerical_plate_event_closure=dict(status='SUPERSEDED_AFTER_CONVERGENCE_WARNING_DISCOVERY',original_record=q['numerical_plate_event_closure']))
(P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n')
for name in ['STATUS.json','GAP_MATRIX.json']:
 p=P/name;s=json.loads(p.read_text());s['frost_boundary_state_calendar04'].update(status=q['status'],convergence_discovery=record['status'],convergence_discovery_record='FROST_BOUNDARY_STATE_CALENDAR04_TERMINAL_TRIAL_DISCOVERY_V1.json',current_plate_qualification='NOT_QUALIFIED_16_NEW_CONTEXTS_HAVE_468_ORIGINAL_CONVERGENCE_WARNINGS',parent03_explicit_plate_convergence='REOPENED_8_CONTEXTS_280_PRIMARY_DAYS_WITH_WARNINGS',trial_receipt_repair=q['numerical_trial_receipt_repair'],same_compiler_bottom5_postimages='16_CONTEXTS_432_EXACT_OBJECT_COMPARISONS_ZERO_MODELS',plate_clock_repair_disposition='SUPERSEDED_ORIGINAL_FROST_TIMECONTROL_RESTORED')
 if name=='STATUS.json':
  s['last_commit']=git('rev-parse','HEAD').decode().strip();s['next_action']='Actual public corrected explicit plate O0/O2 local original failed case first, including whole35/native/cold/compiled refusals/transactions and new zero-convergence-warning gate. Then affected24 Windows/Ubuntu contexts incl reopened03. Preserve all original failed clock-only scientific evidence; inherit only unchanged bottom5 actual postimages.'
 p.write_text(json.dumps(s,indent=2)+'\n')
print('TRIAL_RECEIPT_CONTRACT_AND_REOPENED_PARENT_CONVERGENCE_PERSISTED')
