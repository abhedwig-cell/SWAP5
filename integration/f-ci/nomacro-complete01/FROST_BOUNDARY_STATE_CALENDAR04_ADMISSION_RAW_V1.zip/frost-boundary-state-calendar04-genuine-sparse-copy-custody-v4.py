"""Reapply unchanged real sparse patterns after the completed real negatives."""
from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='e66867c5de454f45fd8d4adde31f68454c61cf9c' and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
negative=json.loads((E/'FROST_BOUNDARY_STATE_CALENDAR04_FINAL_NEGATIVES_V1.json').read_text());assert negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
sparse=Path(git('rev-parse','--git-path','info/sparse-checkout').decode().strip());sparse=sparse if sparse.is_absolute() else R/sparse;patterns=sparse.read_bytes();assert len(patterns.decode().splitlines())==14
fixtures=lambda:{p.relative_to(R).as_posix():SHA(p.read_bytes()) for p in (R/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()}
originals=fixtures();assert len(originals)==56
rows={}
for row in git('ls-tree','-r',head,'--','integration/f-ci/nomacro-complete01').decode().splitlines():
 meta,path=row.split('\t',1)
 if '.zip' not in Path(path).name or not (R/path).is_file():continue
 mode,kind,digest=meta.split();raw=(R/path).read_bytes();assert kind=='blob' and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==digest
 rows[path]=dict(bytes=len(raw),sha256=SHA(raw),actual_git_blob=digest)
before=shutil.disk_usage(R.anchor).free
response=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','sparse-checkout','reapply'],cwd=R,capture_output=True);response.check_returncode()
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1','--untracked-files=all','--ignored') and sparse.read_bytes()==patterns and fixtures()==originals
removed=[dict(path=path,**item) for path,item in rows.items() if not (R/path).exists()]
q=dict(status='GENUINE_SPARSE_REAPPLY_UNCHANGED14_PATTERNS56_FIXTURES_SAME_REAL_HEAD_INDEX_ORIGINAL_ARCHIVE_BYTES_IN_GIT',actual_head=head,patterns_sha256=SHA(patterns),before_materialized_archives=len(rows),after_materialized_original_archives=len(rows)-len(removed),removed_reproducible_working_copies=removed,total_removed_working_bytes=sum(x['bytes'] for x in removed),free_before=before,free_after=shutil.disk_usage(R.anchor).free,stdout=response.stdout.decode(errors='replace'),stderr=response.stderr.decode(errors='replace'),source_or_filesystem_identity_projected=False,compiler_executions=0,model_executions=0)
q['actual_net_free_change']=q['free_after']-before
(E/'FROST_BOUNDARY_STATE_CALENDAR04_GENUINE_SPARSE_ARCHIVE_COPY_CUSTODY_V4.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],len(removed),q['actual_net_free_change'],flush=True)
