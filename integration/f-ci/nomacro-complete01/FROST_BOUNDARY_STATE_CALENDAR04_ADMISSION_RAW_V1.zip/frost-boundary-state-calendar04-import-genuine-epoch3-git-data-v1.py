"""Recover exact missing real Git objects after the bounded smart-Git fetch stalled."""
from pathlib import Path
from datetime import datetime
import hashlib,http.client,itertools,json,os,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
BASE='83810c95b433bf48f8b1bc7c87b005dbe24af197';TARGET='dcae412aae8f65acb48b1e37431334c2c522c071'
HEAD='0566877f3d1ef27a472c4fae6f5275e8e76871a4'
git=lambda *a,**kw:subprocess.check_output(['git',*a],cwd=R,**kw)
assert git('rev-parse','HEAD').decode().strip()==HEAD
q=json.loads((E/'FROST_BOUNDARY_STATE_CALENDAR04_GENUINE_EPOCH3_COMMIT_API_V1.json').read_text());assert q['sha']==TARGET and [x['sha'] for x in q['parents']]==[BASE] and q['verification']['reason']=='unsigned'
digest=lambda kind,raw:hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
identity=lambda item,tz:(item['name']+' <'+item['email']+'> '+str(int(datetime.fromisoformat(item['date'].replace('Z','+00:00')).timestamp()))+' '+tz).encode()
matches=set()
for author_tz,committer_tz,message,encoding in itertools.product(('+0000','-0000','+0100'),('+0000','-0000','+0100'),{q['message'],q['message']+'\n',q['message'].rstrip('\n')+'\n'},(b'',b'encoding UTF-8\n')):
 raw=b'tree '+q['tree']['sha'].encode()+b'\n'+b''.join(b'parent '+x['sha'].encode()+b'\n' for x in q['parents'])+b'author '+identity(q['author'],author_tz)+b'\ncommitter '+identity(q['committer'],committer_tz)+b'\n'+encoding+b'\n'+message.encode()
 if digest('commit',raw)==TARGET:matches.add(raw)
assert len(matches)==1,'No unique exact original Git commit bytes; no object or HEAD written'
commit=matches.pop();objects={('commit',TARGET):commit};responses={}
r=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\npath=abhedwig-cell/SWAP5.git\n\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'),timeout=30);assert r.returncode==0
values=dict(x.split(b'=',1) for x in r.stdout.splitlines() if b'=' in x);token=values.get(b'password');assert token
headers={'Authorization':'Bearer '+token.decode(),'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-genuine-exact-Git-data-recovery'}
def get(kind,sha):
 c=http.client.HTTPSConnection('api.github.com',timeout=60);c.request('GET','/repos/abhedwig-cell/SWAP5/git/'+kind+'/'+sha,headers=headers);response=c.getresponse();status=response.status;raw=response.read();c.close();assert status==200,('Git data GET failed',kind,sha,status);data=json.loads(raw);assert data['sha']==sha;responses[kind+'/'+sha]=data;return data
wanted={'.github/workflows/nomacro-frost-boundary-state-calendar04-ubuntu.yml','.github/workflows/nomacro-frost-boundary-state-calendar04-windows.yml','integration/f-ci/nomacro-complete01/FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json','tests/nomacro_drainage/frost_boundary_state_calendar_inputs.py'}
def tree(sha,prefix=''):
 data=get('trees',sha);assert not data.get('truncated');entries=data['tree']
 raw=b''.join(x['mode'].lstrip('0').encode()+b' '+x['path'].encode()+b'\0'+bytes.fromhex(x['sha']) for x in entries)
 assert digest('tree',raw)==sha,'Original Git tree bytes did not match exact SHA'
 objects[('tree',sha)]=raw
 for x in entries:
  path=prefix+x['path']
  if x['type']=='tree' and any(name.startswith(path+'/') for name in wanted):tree(x['sha'],path+'/')
  elif x['type']=='blob' and path in wanted:
   import base64
   item=get('blobs',x['sha']);assert item['encoding']=='base64';raw=base64.b64decode(item['content']);assert len(raw)==item['size'] and digest('blob',raw)==x['sha'];objects[('blob',x['sha'])]=raw
tree(q['tree']['sha']);del token,values,r,headers
directory=E/'FROST_BOUNDARY_STATE_CALENDAR04_EPOCH3_GENUINE_GIT_OBJECT_DATA_V1';directory.mkdir();inventory=[]
for (kind,sha),raw in objects.items():
 assert digest(kind,raw)==sha
 path=directory/(kind+'-'+sha+'.bin');path.write_bytes(raw)
 assert git('hash-object','-t',kind,'--stdin',input=raw).decode().strip()==sha
 assert git('hash-object','-t',kind,'-w','--stdin',input=raw).decode().strip()==sha and git('cat-file',kind,sha)==raw
 inventory.append(dict(kind=kind,sha=sha,bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),file=path.name))
assert set(git('diff','--name-only',BASE,TARGET).decode().splitlines())==wanted
assert not git('diff',BASE,TARGET,'--','app','src','tools','reference') and git('rev-parse','HEAD').decode().strip()==HEAD
record=dict(status='GENUINE_ORIGINAL_COMMIT_SIX_TREES_THREE_BLOBS_EXACT_GIT_SHA_IMPORTED_NO_SOURCE_OR_HEAD_PROJECTION',original_API_commit=TARGET,actual_before_HEAD=HEAD,objects=inventory,original_tree_and_blob_API_responses=responses,changed_paths=sorted(wanted),APP_src_tools_reference_changed=False,actual_input_template_changed=True,Git_object_bytes_rewritten_to_match_a_different_identity=False)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_GENUINE_EPOCH3_GIT_OBJECT_RECOVERY_V1.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
assert git('rev-parse','HEAD').decode().strip()==HEAD
print('GENUINE_EPOCH3_OBJECTS_IMPORTED_ACTUAL_CHECKOUT_HEAD_UNCHANGED',len(objects),TARGET,flush=True)

