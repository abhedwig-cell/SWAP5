from pathlib import Path
import json,zipfile
E=Path(__file__).parent
for platform in ('UBUNTU','WINDOWS'):
 for opt in ('O0','O2'):
  with zipfile.ZipFile(E/f'FROST_BOUNDARY_STATE_CALENDAR04_{platform}_{opt}_ORIGINAL_V1.zip') as z:
   names=z.namelist();root=json.loads(z.read('current/RESULT.json'))
   print(json.dumps(dict(platform=platform,optimization=opt,status=root['status'],source=root['source'],cases=[dict(case=x['case']['name'],science=x['science'] and x['science']['status'],controls=x['controls'] and x['controls']['status']) for x in root['contexts']]),indent=2))
   target='current/cde-b8-i0-h0-p2-regular-r1/'
   for name in names:
    if name.startswith(target) and name.endswith(('science/RESULT.json','science-controller/controller.stderr')):
     raw=z.read(name).decode(errors='replace');print(name,raw[-4000:])
   stderr=[n for n in names if n.startswith(target+'science/') and n.endswith('.stderr') and z.getinfo(n).file_size]
   for name in stderr[-2:]:print(name,z.read(name).decode(errors='replace')[-1400:])
