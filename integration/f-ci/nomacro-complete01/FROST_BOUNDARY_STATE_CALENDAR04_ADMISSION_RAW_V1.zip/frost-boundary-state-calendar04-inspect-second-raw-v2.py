from pathlib import Path
import json,zipfile,hashlib
E=Path(__file__).parent
for host in ('UBUNTU','WINDOWS'):
 for opt in ('O0','O2'):
  p=E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_ORIGINAL_V2.zip'
  with zipfile.ZipFile(p) as z:
   q=json.loads(z.read('current/RESULT.json'))
   print(host,opt,'ROOT',q['status'],'SOURCE',q['source'])
   print('CONTEXTS',json.dumps([dict(case=x['case']['name'],science=x['science'] and x['science']['status'],controls=x['controls'] and x['controls']['status']) for x in q['contexts']]))
   for n in z.namelist():
    if n.endswith('science-controller/controller.stderr') and z.getinfo(n).file_size:
     print(n,z.read(n).decode(errors='replace')[-3500:])

