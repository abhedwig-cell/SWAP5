from pathlib import Path
import zipfile,json
E=Path(__file__).parent
for host in ('UBUNTU','WINDOWS'):
 for opt in ('O0','O2'):
  with zipfile.ZipFile(E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_ORIGINAL_V3.zip') as z:
   q=json.loads(z.read('current/RESULT.json'));print(host,opt,q['status'])
   for x in q['contexts']:
    name=x['case']['name'];prefix='current/'+name+'/science/'
    s=json.loads(z.read(prefix+'RESULT.json'));print(name,s['status'],s.get('error'))
    if not x['science']:
     for n in z.namelist():
      if n.startswith(prefix) and (n.endswith('donor.stderr') or n.endswith('donor.stdout')) and z.getinfo(n).file_size:print(n,z.read(n).decode(errors='replace')[-1800:])

