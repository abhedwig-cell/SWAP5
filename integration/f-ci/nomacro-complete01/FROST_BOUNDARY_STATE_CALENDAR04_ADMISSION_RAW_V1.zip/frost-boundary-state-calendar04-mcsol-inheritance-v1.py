"""Select current authority checks while inheriting unchanged MC-SOL model bodies."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
base='9936bcda75eb920d67aa74e47018baf39ab18f78';head=git('rev-parse','HEAD').decode().strip()
paths=['app/solute_column','tools/solute','src','reference','tests/nut-sol','examples/solute_column','.github/workflows/mc-sol01-swp-reader.yml','.github/workflows/mc-sol01-column-input.yml']
assert not git('diff',base,head,'--',*paths)
old=git('ls-tree','-r',base,'--',*paths);current=git('ls-tree','-r',head,'--',*paths);assert old==current
logs=[]
with ExitStack() as stack:
 store=Archive(GitArchiveSource(R,head),'FROST_BOUNDARY03_ADMISSION_RAW_V1',stack)
 for role in ['MCSOL_SWP','MCSOL_COLUMN']:
  name='FROST_BOUNDARY03_PR1802_'+role+'_ORIGINAL_CI_V2.log';raw=store.get(name);receipt=json.loads(store.get(name+'.json'))
  assert len(raw)==receipt['bytes'] and SHA(raw)==receipt['sha256'] and b'2e9dc651b13e54eca0ba91a867d0849dd7904959' in raw
  logs.append(dict(role=role,original_actual_candidate='2e9dc651b13e54eca0ba91a867d0849dd7904959',archive_sha256=store.record['sha256'],member=name,bytes=len(raw),sha256=SHA(raw)))
assert git('rev-parse','HEAD').decode().strip()==head
q=dict(status='UNCHANGED_MCSOL_SCIENTIFIC_MODEL_RUNNERS_INPUTS_AND_WORKFLOWS_EXACT_INHERITED_CURRENT_SHARED_AUTHORITY_SEPARATELY_SELECTED',actual_current_head=head,actual_parent=base,unchanged_dependency_paths=paths,complete_dependency_tree_sha256=SHA(current),unchanged_tracked_files=len(current.splitlines()),original_actual_success_logs=logs,current_MCSOL_model_replay='NOT_SELECTED_IMPACT',current_shared_public_and_publication_authority='SELECTED_ACTUAL_CURRENT_HEAD_GATES_MUST_PASS',compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],q['unchanged_tracked_files'],flush=True)
