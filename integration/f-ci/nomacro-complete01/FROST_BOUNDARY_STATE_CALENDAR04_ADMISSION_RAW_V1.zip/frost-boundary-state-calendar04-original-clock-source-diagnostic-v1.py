from pathlib import Path
import json,zipfile
from decimal import Decimal,localcontext
E=Path(__file__).parent;case='cde-b8-i0-h0-p2-regular-r1'
with zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_UBUNTU_O0_ORIGINAL_V1.zip') as z:
 for name in z.namelist():
  if case in name and name.endswith('timecontrol.f90'):
   s=z.read(name).decode('cp1252');lines=s.splitlines();print('ACTUAL_COMPILED_SOURCE',name)
   for i,line in enumerate(lines):
    if 'dtevent' in line.lower() and ('if (' in line.lower() or 'dt =' in line.lower()):print('\n'.join(lines[max(0,i-2):i+4]))
  if name.startswith('current/'+case+'/inputs/') and name.endswith('.met'):
   lines=z.read(name).decode('cp1252').splitlines();print('ACTUAL_MET_SOURCE',name,'\n'.join(lines[:3]+lines[20:27]))
 rows=[json.loads(line,parse_float=Decimal) for line in z.read('current/'+case+'/science/trajectory/daily.jsonl').decode().splitlines()]
 with localcontext() as context:
  context.prec=80;row=rows[-1];nominal=Decimal('0.07');elapsed=row['external_flux_cm'][1]/nominal;snow_loss=row['stock_start_cm'][2]-row['stock_end_cm'][2];predicted=snow_loss*(1-elapsed)
  print(json.dumps(dict(hypothesis='Supported numerical signature only; actual MET nominal and actual compiled TimeControl must be checked before runtime causality claim',observed_water_residual=str(row['independent_residual_cm']),assumed_nominal_precipitation_cm=str(nominal),inferred_elapsed_day_fraction=str(elapsed),unconsumed_day_fraction=str(1-elapsed),snow_storage_loss_cm=str(snow_loss),predicted_snow_daily_vs_integrated_mismatch_cm=str(predicted),observed_minus_predicted_cm=str(row['independent_residual_cm']-predicted)),indent=2))
