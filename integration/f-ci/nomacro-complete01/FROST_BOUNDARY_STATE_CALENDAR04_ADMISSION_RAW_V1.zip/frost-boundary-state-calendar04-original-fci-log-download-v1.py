"""Fetch the original completed job log; credentials and redirect stay in memory."""
from pathlib import Path
import gzip,hashlib,io,json,os,subprocess,urllib.error,urllib.parse,urllib.request,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');job=139492801079
endpoint=f'https://api.github.com/repos/abhedwig-cell/SWAP5/actions/jobs/{job}/logs'
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never')
credential=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\npath=abhedwig-cell/SWAP5.git\n\n',cwd=R,env=env,text=True,capture_output=True)
if credential.returncode:raise RuntimeError('Existing local Git credential unavailable')
values=dict(line.split('=',1) for line in credential.stdout.splitlines() if '=' in line)
if not values.get('password'):raise RuntimeError('Existing local Git credential has no token')
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,request,fp,code,message,headers,newurl):return None
request=urllib.request.Request(endpoint,headers={'Authorization':'Bearer '+values['password'],'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','Accept-Encoding':'identity','User-Agent':'SWAP5-original-evidence'})
location=None
try:
 try:
  with urllib.request.build_opener(NoRedirect()).open(request,timeout=45) as response:raw=response.read();content_type=response.headers.get('Content-Type','')
 except urllib.error.HTTPError as error:
  if error.code not in (301,302,303,307,308):raise RuntimeError('Original log API HTTP '+str(error.code)) from None
  location=error.headers['Location']
 if location:
  target=urllib.parse.urlparse(location)
  if target.scheme!='https' or not target.hostname or not (target.hostname.endswith('.blob.core.windows.net') or target.hostname.endswith('.githubusercontent.com')):raise RuntimeError('Unexpected original-log download host')
  # A new request deliberately has no Authorization header from the API call.
  with urllib.request.urlopen(urllib.request.Request(location,headers={'Accept-Encoding':'identity'}),timeout=45) as response:raw=response.read();content_type=response.headers.get('Content-Type','')
except RuntimeError:raise
except Exception as error:raise RuntimeError('Original log transfer failed: '+type(error).__name__) from None
values.clear();request=None;location=None;credential=None
name='FROST_BOUNDARY_STATE_CALENDAR04_PR1803_FCI_MODULAR_ORIGINAL_CI_V1.log';path=E/name;assert not path.exists();transport_sha=hashlib.sha256(raw).hexdigest();transport_bytes=len(raw);encoding='ORIGINAL_PLAIN_LOG_HTTP_BYTES'
if raw.startswith(b'PK\x03\x04'):
 (E/(name+'.zip')).write_bytes(raw)
 with zipfile.ZipFile(io.BytesIO(raw)) as archive:
  members=[n for n in archive.namelist() if not n.endswith('/')];assert len(members)==1;raw=archive.read(members[0])
 encoding='ORIGINAL_ZIP_PRESERVED_AND_SINGLE_JOB_MEMBER_BYTES'
elif raw.startswith(b'\x1f\x8b'):
 (E/(name+'.gz')).write_bytes(raw);raw=gzip.decompress(raw);encoding='ORIGINAL_GZIP_PRESERVED_AND_DECOMPRESSED_JOB_BYTES'
assert b'e66867c5de454f45fd8d4adde31f68454c61cf9c' in raw and b'18e31348e7e72fadc564c3046ce3645578bd46b1' in raw
with path.open('xb') as stream:stream.write(raw)
record=dict(status='ORIGINAL_CURRENT_FCI_MODULAR_SUCCESS_JOB_LOG_HTTP_BYTES_PRESERVED',role='FCI_MODULAR',job_id=job,run_id=45692100058,actual_source='e66867c5de454f45fd8d4adde31f68454c61cf9c',actual_synthetic='18e31348e7e72fadc564c3046ce3645578bd46b1',file=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),original_transport_bytes=transport_bytes,original_transport_sha256=transport_sha,content_type=content_type,storage=encoding,api=endpoint,credential_or_signed_redirect_stored=False)
(E/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(record['status'],len(raw),record['sha256'],flush=True)
