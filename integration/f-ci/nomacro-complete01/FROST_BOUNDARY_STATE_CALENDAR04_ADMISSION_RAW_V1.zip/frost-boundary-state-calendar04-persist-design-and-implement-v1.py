"""Persist exact bounded composition contract before changing its real APP files."""
from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;P=R/'integration/f-ci/nomacro-complete01'
BASE='74ecc55765df548e758605f3566bc93558a6fefb';CANON='1c3b8725548c836c9a73570c2579dd6cdc683217'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==BASE and git('branch','--show-current').decode().strip()=='codex/nomacro-frost-boundary-state-calendar04'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
n=json.loads((E/'FROST_BOUNDARY03_BOTHCI_FINAL_NEGATIVES_V3.json').read_text());assert n['candidate']==BASE and n['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
proposed={};original={}
def edit(path,before,after):
 if path not in proposed:original[path]=git('show',BASE+':'+path).decode();proposed[path]=original[path]
 assert proposed[path].count(before)==1,(path,before)
 proposed[path]=proposed[path].replace(before,after,1)
path='app/hybrid_water/frost_boundary_composition.py'
edit(path,'def input_domain(selectors, boundary, original_output):\n','def input_domain(selectors, boundary, original_output):\n    from frost_boundary_state_calendar import input_domain as composed_domain\n    if composed_domain(selectors,boundary,original_output):return True\n')
edit(path,'def selection(directory, original_output=True):\n','def selection(directory, original_output=True):\n    from frost_boundary_state_calendar import selection as composed_selection\n    composed=composed_selection(directory,original_output)\n    if composed is not None:return composed\n')
edit(path,'def codec(selected):\n','def codec(selected):\n    if selected.get(\'boundary_state_calendar\'):\n        from frost_boundary_state_calendar import codec as composed_codec\n        return composed_codec(selected)\n')
edit(path,'    return dict(selected, source_sha256=hashlib.sha256(','    result=dict(selected, source_sha256=hashlib.sha256(')
edit(path,'        native_codec=codec(selected).decode())','        native_codec=codec(selected).decode())\n    if selected.get(\'boundary_state_calendar\'):\n        from frost_boundary_state_calendar import source_identity\n        result[\'state_calendar_provider_sha256\']=source_identity()\n    return result')
path='app/hybrid_water/frost_calendar_state.py'
edit(path,'def selection(directory,original_output=True):\n','def selection(directory,original_output=True):\n    from frost_boundary_state_calendar import selection as composed_selection\n    composed=composed_selection(directory,original_output)\n    if composed is not None:return composed\n')
path='app/hybrid_water/frost_calendar_output.py'
edit(path,"    return CODECS[(selected['implicit'],selected['kind'])]","    if selected.get('boundary_state_calendar'):\n        from frost_boundary_state_calendar import codec as composed_codec\n        return composed_codec(selected)\n    return CODECS[(selected['implicit'],selected['kind'])]")
edit(path,'    providers=[Path(__file__).name,','    boundary=input_selection(project.input_directory,project.original_output)\n    policy=boundary[\'policy\'] if boundary.get(\'boundary_state_calendar\') else POLICY\n    providers=[Path(__file__).name,')
edit(path,"    providers.append('cde_interval_snow_state.f90' if project.solute else SNOW_PROVIDER+'.f90')","    if boundary.get('boundary_state_calendar'):providers+=['frost_boundary_state_calendar.py','frost_boundary_composition.py']\n    providers.append('cde_interval_snow_state.f90' if project.solute else SNOW_PROVIDER+'.f90')")
edit(path,'    return dict(policy=POLICY,native_codec=codec(project).decode(),**selected,','    return dict(policy=policy,native_codec=codec(project).decode(),**selected,')
path='app/hybrid_water/frost_boundary_state_calendar.py';s=(E/'frost-boundary-state-calendar04-new-selector-v2.py').read_text(encoding='utf-8-sig')
low=s.index('def codec(selected):');high=s.index('\n\ndef source_identity()',low)
s=s[:low]+"def codec(selected):\n    return {('water',0):b'S5BCW001',('cde',0):b'S5BCC001',\n            ('water',1):b'S5BCW002',('cde',1):b'S5BCC002'}[(selected['kind'],selected['implicit'])]\n"+s[high:]
assert not (R/path).exists();proposed[path]=s
SHA=lambda s:hashlib.sha256(s.encode()).hexdigest()
files={}
for path,s in proposed.items():
 compile(s,path,'exec');a=original.get(path);item=dict(added=a is None,proposed_lf_sha256=SHA(s))
 if a is not None:item.update(before_lf_sha256=SHA(a),ordered_literal_edits=[dict(base_start=i,base_end=j,before=a[i:j],after=s[k:l]) for op,i,j,k,l in difflib.SequenceMatcher(None,a,s,autojunk=False).get_opcodes() if op!='equal'])
 files[path]=item
discovery=json.loads((E/'FROST_BOUNDARY_STATE_CALENDAR04_READER_DISCOVERY_V2.json').read_text());cases=[{k:v for k,v in item.items() if k in ('name','kind','bottom','implicit','hysteresis','initial','calendar','reset','start','days')} for item in discovery['cases']];assert len(cases)==12
contract=dict(status='PERSISTED_PROPOSED_EXISTING_PROCESS_COMPOSITION_NOT_TESTED_OR_QUALIFIED',work_unit='SWAP5-NOMACRO-COMPLETE01',batch='FROST_BOUNDARY_STATE_CALENDAR04',classification='B_EXISTING_PROCESS_COMPOSITION_WITH_C_CONFIGURATION_REUSE',dependency_candidate=BASE,dependency_PR=1802,actual_canonical_at_start=CANON,dependency_admission='FINAL_HEAD_PUBLIC_ORDINARY_PUBLICATION_FOUR_REAL_NEGATIVES_PASS_CI_AND_ACTUAL_CANONICAL_ADMISSION_PENDING',scope='Model1 numerical heat2 Snow/Frost primaryDRA1/DIVD1, explicit original boundary5/8 or fitted implicit5; existing hysteresis0/1/2 and initialization1/2, original monthly/dates/regular/dense reset output. Old dense hys2/initial2 boundary03 dispatch remains literal.',design='One existing Frost calendar/state owner composes all newly selected configurations, including dense requests, with four distinct existing-frame codec tags. Existing root provider already validates actual bottom and hysteresis through its owning selector. No process Fortran, physical state, mass/convergence limit, correction or fallback is changed.',native_codecs=['S5BCW001','S5BCC001','S5BCW002','S5BCC002'],representative_cases=cases,files=files,held_fixed=['src','tools','reference','implicit_frost_root_state.py','implicit_frost_surface_conductivity.py','frost_divdra_overlap.py','frost_reference.py','all parent scientific raw bytes'],qualification='Real public loads and excluded-mode controls; preserve old named selection/default root bytes and exact parent source inverse; targeted actual O0/O2 build and scientific smoke then independent Ubuntu/Windows complete selected periods, original daily/prefix budgets, active Snow/Frost, complete native/cold/user output, compiled refusals and real transactions. Reuse parent periods only through actual unchanged dependency/postimage evidence. Final public/CI/merge admission requires genuine parent PR1802 receipt.',original_reference_limit='Prior original executable and same-object stack-only relink crash at initialization including existing boundary6 control; preserve those failed/censored raw, no repeat merely metadata and no legacy equivalence claim.',compiler_executions=0,model_executions=0,canonical_admission=False,functional_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
name='FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json';assert not (P/name).exists();(P/name).write_text(json.dumps(contract,indent=2)+'\n',encoding='utf8',newline='\n')
for suffix in ('.zip','.json'):shutil.copyfile(E/('FROST_BOUNDARY_STATE_CALENDAR04_DISCOVERY_RAW_V1'+suffix),P/('FROST_BOUNDARY_STATE_CALENDAR04_DISCOVERY_RAW_V1'+suffix))
status=json.loads((P/'STATUS.json').read_text());status.update(canonical=CANON,canonical_head=CANON,active_branch='codex/nomacro-frost-boundary-state-calendar04',next_code_change='Compose the existing Frost boundary/calendar/state owners for the twelve source-backed representative configurations; first actual public reader admission then targeted real O0/O2 build/science.',recovery_point='Design and original reader-discovery input bytes are persisted before APP edits. Parent PR1802 final candidate74ecc passes real PUBLIC, ordinary publication and four pushed negatives; current CI and genuine actual merge admission still required.',next_action='Persist APP selection/codec composition, verify twelve actual public loads, run registered capacity-checked real O0/O2 builds and targeted scientific/native checks; continue polling existing PR1802 final-head CI and admit only after all gates. No old model replay merely metadata.')
status['frost_boundary_state_calendar04']=dict(status='PROPOSED_DESIGN_PERSISTED_BEFORE_IMPLEMENTATION',contract=name,dependency_candidate=BASE,dependency_PR=1802,canonical_admission=False,representative_contexts_per_platform_optimization=12)
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8',newline='\n')
gap=json.loads((P/'GAP_MATRIX.json').read_text());old=gap['next_coherent_batches'];gap['next_coherent_batches']=[dict(priority=1,family='Original Frost boundary/hysteresis/initialization/calendar composition',classification='MISSING_COMPOSITION',status='ACTIVE_FROST_BOUNDARY_STATE_CALENDAR04; twelve actual current public reader refusals; existing unchanged state/physical owners can be composed as one block. Parent1802 final CI/admission pending.'),*[dict(item,priority=i+2) for i,item in enumerate(old[1:])]]
gap['frost_boundary_state_calendar04']=dict(status='MISSING_COMPOSITION_DESIGN_PERSISTED_NO_QUALIFICATION_CLAIM',contract=name,whole_family_closed=False,global_family_and_gap_counts='UNKNOWN')
(P/'GAP_MATRIX.json').write_text(json.dumps(gap,indent=2)+'\n',encoding='utf8',newline='\n')
targets=[str((P/p).relative_to(R)) for p in (name,'FROST_BOUNDARY_STATE_CALENDAR04_DISCOVERY_RAW_V1.zip','FROST_BOUNDARY_STATE_CALENDAR04_DISCOVERY_RAW_V1.json','STATUS.json','GAP_MATRIX.json')]
subprocess.run(['git','add','--sparse','--',*targets],cwd=R,check=True,capture_output=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Persist coherent Frost boundary state/calendar contract and original reader discovery'],cwd=R,check=True,capture_output=True)
anchor=git('rev-parse','HEAD').decode().strip();print('PROPOSED_CONTRACT_AND_ACTUAL_DISCOVERY_PERSISTED',anchor,flush=True)
for path,s in proposed.items():(R/path).write_text(s,encoding='utf8',newline='\n')
subprocess.run(['git','diff','--check'],cwd=R,check=True,capture_output=True)
subprocess.run(['git','add','--',*proposed],cwd=R,check=True,capture_output=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Compose original Frost boundaries with existing hydraulic state and calendar owners'],cwd=R,check=True,capture_output=True)
head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
print('FIVE_APP_CONFIGURATION_FILES_PERSISTED_NOT_YET_TESTED_OR_QUALIFIED',head,flush=True)
