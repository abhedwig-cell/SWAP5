from pathlib import Path
import hashlib,json,re
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).parent
records={}
for platform in ('ubuntu','windows'):
 old=R/f'.github/workflows/nomacro-frost-boundary03-{platform}.yml';s=old.read_text()
 s=s.replace('frost-boundary03','frost-boundary-state-calendar04').replace('Frost boundary58','Frost boundary state/calendar')
 s=s.replace('branches: [codex/nomacro-frost-boundary-state-calendar04]','branches: [codex/nomacro-frost-boundary-state-calendar04-science01]')
 s=s.replace('timeout-minutes: 45','timeout-minutes: '+('90' if platform=='windows' else '60'))
 s,count=re.subn(r'      - name: Obtain five exact completed scientific and native-control contexts\n.*?(?=      - name: Preserve real source)', '',s,flags=re.S);assert count==1
 s=s.replace('Run missing full35 contexts and actual compiled native and transaction controls','Run selected original boundary state/calendar periods and actual compiled controls')
 oldcommand='tests/nomacro_drainage/frost_boundary_portable.py --platform '+('Windows' if platform=='windows' else 'Ubuntu')+' --previous-proof "$RUNNER_TEMP/previous-proof"'
 newcommand='tests/nomacro_drainage/frost_boundary_state_calendar_portable.py --platform '+('Windows' if platform=='windows' else 'Ubuntu')
 if platform=='windows':newcommand+=' --exclude-case water-b5-i0-h0-p1-regular-r0'
 assert s.count(oldcommand)==1;s=s.replace(oldcommand,newcommand)
 target=R/f'.github/workflows/nomacro-frost-boundary-state-calendar04-{platform}.yml';assert not target.exists();target.write_text(s,encoding='utf8',newline='\n')
 records[target.relative_to(R).as_posix()]=dict(sha256=hashlib.sha256(s.encode()).hexdigest(),platform=platform,expected_contexts_per_optimization=11 if platform=='windows' else 12,completed_local_Windows_water_context_excluded_without_replay=platform=='windows',trigger='Explicit push of persisted scientific source to codex/nomacro-frost-boundary-state-calendar04-science01; no metadata-only numerical retrigger')
p=P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json';q=json.loads(p.read_text());q['original_scientific_workflows']=records;q['qualification_plan_counts']=dict(contexts=48,primary_days=1404,native_samples=276,exact_cold_windows=120,actual_compiled_refusals_expected=3144,transaction_contexts_expected=72,counts_are_target_not_completed=True,local_Windows_water_full35_contexts=2,remaining_Windows_CI_contexts=22,Ubuntu_CI_contexts=24)
p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8',newline='\n');print('GENUINE_TWO_PLATFORM_WORKFLOWS_PREPARED_NO_REPEAT_OF_LOCAL_WINDOWS_PERIODS')
