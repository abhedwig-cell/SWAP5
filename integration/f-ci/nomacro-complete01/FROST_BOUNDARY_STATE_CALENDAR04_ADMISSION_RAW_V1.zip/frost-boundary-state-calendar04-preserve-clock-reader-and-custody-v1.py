from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
names=['FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1','FROST_BOUNDARY_STATE_CALENDAR04_WINDOWS_O0_ORIGINAL_V1']
prior={};sources={}
for name in names:
 m=json.loads((P/(name+'.json')).read_text());sources[name]=dict(archive_sha256=m['sha256'],manifest_sha256=SHA((P/(name+'.json')).read_bytes()))
 assert SHA((E/(name+'.zip')).read_bytes())==m['sha256']
 with zipfile.ZipFile(E/(name+'.zip')) as z:
  for key,item in m['members'].items():
   if item['sha256'] not in prior:
    data=z.read(key);assert len(data)==item['bytes'] and SHA(data)==item['sha256'];prior[item['sha256']]=dict(original_archive=name,member=key,bytes=len(data))
roots=['frost-boundary-state-calendar04-dayclock-causal-v1','frost-boundary-state-calendar04-input-contract-v1','frost-boundary-state-calendar04-input-contract-v2']
name='FROST_BOUNDARY_STATE_CALENDAR04_ACTUAL_CLOCK_DIAGNOSTIC_AND_READERS_RAW_V1';archive=E/(name+'.zip');inventory={};new={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for root in roots:
  for path in sorted((W/root).rglob('*')):
   assert not path.is_symlink()
   if not path.is_file():continue
   raw=path.read_bytes();digest=SHA(raw);key=root+'/'+path.relative_to(W/root).as_posix()
   if digest in prior:storage=dict(inherited_exact_original_bytes=prior[digest])
   else:
    member='raw/'+digest
    if digest not in new:z.writestr(member,raw);new[digest]=dict(member=member,bytes=len(raw),sha256=digest)
    storage=dict(member=member)
   inventory[key]=dict(bytes=len(raw),sha256=digest,**storage)
 for path in E.glob('frost-boundary-state-calendar04-*dayclock*.py'):
  raw=path.read_bytes();key='controllers/'+path.name;z.writestr(key,raw);new[key]=dict(member=key,bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
 for item in new.values():
  raw=z.read(item['member']);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
 for root in roots:
  for p in (W/root).rglob('*'):
   if p.is_file():
    item=inventory[root+'/'+p.relative_to(W/root).as_posix()];assert SHA(p.read_bytes())==item['sha256']
raw=archive.read_bytes();chunk=25*1024*1024;parts=[]
for i,offset in enumerate(range(0,len(raw),chunk),1):
 data=raw[offset:offset+chunk];file=name+'.zip.part'+str(i).zfill(3);(P/file).write_bytes(data);assert (P/file).read_bytes()==data;parts.append(dict(file=file,bytes=len(data),sha256=SHA(data)))
m=dict(status='ACTUAL_ORIGINAL_CLOCK_REJECTION_AND_COUNTERFACTUAL_AND_FULL_READER_BYTES_PRESERVED_NOT_QUALIFIED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members={v['member']:dict(bytes=v['bytes'],sha256=v['sha256']) for v in new.values()},physical_inventory=inventory,exact_original_byte_dependencies=sources,canonical_admission=False,diagnostic_not_a_qualification=True,failed_counterfactual_V3_retained=True,observational_V2_rejects_day22=True,counterfactual_V5_35days_only_diagnostic=True)
for root in (E,P):(root/(name+'.json')).write_text(json.dumps(m,indent=2)+'\n',encoding='utf8')
# Central Git-held original local science: audit every physical file before release.
central=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_CENTRAL_V1.json').read_text());m=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1.json').read_text())
parts=[subprocess.check_output(['git','show','bc79f1dd87ec89198a27f5a3b28c3b722d08236c:integration/f-ci/nomacro-complete01/'+x['file']],cwd=R) for x in m['parts']]
assert SHA(b''.join(parts))==m['sha256'];audited=[]
with zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1.zip') as z:
 for x in central['physical_inventory']:
  root=Path(x['original_path'])
  if not root.is_relative_to(W):continue
  count=0
  for p in root.rglob('*'):
   if not p.is_file():continue
   raw=p.read_bytes();key=x['archive_prefix']+'/'+p.relative_to(root).as_posix();assert raw==z.read(key) and SHA(raw)==m['members'][key]['sha256'];count+=1
  audited.append(dict(path=str(root),files=count,all_current_bytes_equal_actual_central_Git_held_archive=True))
q=dict(status='OWN_LOCAL_SCIENCE_AND_BUILDS_ALL_CURRENT_BYTES_IN_CENTRAL_GIT_ARCHIVE',resources=audited,central_archive_sha256=m['sha256'],source='bc79f1dd87ec89198a27f5a3b28c3b722d08236c',compiler_executions=0,model_executions=0)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_CENTRAL_BYTE_CUSTODY_V1.json').write_text(json.dumps(q,indent=2)+'\n')
print('PRESERVED_DIAGNOSTIC_READERS',len(raw),'INVENTORY',len(inventory),'AUDITED_RESOURCES',len(audited))

