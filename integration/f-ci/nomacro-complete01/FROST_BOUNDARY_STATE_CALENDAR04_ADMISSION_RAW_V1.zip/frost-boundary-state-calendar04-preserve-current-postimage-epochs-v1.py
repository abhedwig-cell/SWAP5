from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from frost_calendar_state_portable_custody import source as custody
baseline=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_BOTTOM5_PHYSICAL_POSTIMAGE_BASELINES_V1.json').read_text())
host,opt,version=sys.argv[1],sys.argv[2],int(sys.argv[3]);source={2:'85916d054cc0da21baa054ac3a50d40950be49ad',3:'f640d61b63734117e561f0e5240eec83a2996ad7'}[version]
api=json.loads((E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_POSTIMAGES_ORIGINAL_ARTIFACTS_API_V{version}.json').read_text());a=[x for x in api['artifacts'] if '-'+opt+'-' in x['name']];assert len(a)==1;artifact=a[0]
name=f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_POSTIMAGES_ORIGINAL_V{version}';raw=(E/(name+'.zip')).read_bytes();assert len(raw)==artifact['size_in_bytes'] and artifact['digest']=='sha256:'+SHA(raw) and artifact['workflow_run']['head_sha']==source
members={};contexts=[]
with zipfile.ZipFile(E/(name+'.zip')) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 for n in z.namelist():
  assert not n.endswith('/') and '..' not in n.split('/');b=z.read(n);members[n]=dict(bytes=len(b),sha256=SHA(b))
 class Original:
  names=z.namelist()
  def get(self,n):return z.read(n)
 workflow=f'.github/workflows/nomacro-frost-boundary-state-calendar04-postimages-{host.lower()}.yml'
 with ExitStack() as stack:_,provenance=custody(Original(),stack,source,source,workflow)
 q=json.loads(z.read('current/RESULT.json'));assert q['source']==source and q['model_executions']==0
 if version==2:
  assert q['status']=='FAILED_ACTUAL_BOTTOM5_POSTIMAGE_PRESERVATION_NOT_ADMITTED' and len(q['contexts'])==1
 else:assert q['status']=='ACTUAL_SELECTED_BOTTOM5_PHYSICAL_BRANCHES_PUBLIC_GENERATED_AND_COMPILED_POSTIMAGES_EXACT_NO_MODEL_REPLAY_NOT_ADMITTED' and len(q['contexts'])==(3 if host=='UBUNTU' else 2)
 for item in q['contexts']:
  case=item['case'];assert item['returncode']==0 and item['model_executions']==0 and '--build-only' in item['command']
  prefix='compiled/'+case+'/bundle/';meta=json.loads(z.read(prefix+'BUILD.json'));base=baseline['records'][host+'/'+opt+'/'+case]
  assert {k:meta['identity'][k] for k in base['compiler']}==base['compiler'];assert set(meta['identity']['donor_generated'])==set(base['generated'])
  current_host=subprocess.check_output(['git','show',source+':app/hybrid_water/daily_host.py'],cwd=R);dispatch=b'    from frost_boundary_terminal_trial import apply_build as plate_terminal_build\n    patched=plate_terminal_build(output,project,patched)\n';assert current_host.count(dispatch)==1
  assert current_host.replace(dispatch,b'',1)==subprocess.check_output(['git','show','3feb51229a980331bc12be2d1d265bef7ae6691a:app/hybrid_water/daily_host.py'],cwd=R)
  sources={};objects={}
  for file,witness in base['generated'].items():
   actual=z.read(prefix+file);assert SHA(actual)==meta['identity']['donor_generated'][file] and SHA(actual.replace(b'\r\n',b'\n'))==witness['original_LF_sha256']
   obj=z.read(prefix+witness['object_file']);assert SHA(obj)==witness['original_object_sha256']
   sources[file]=dict(actual_raw_sha256=SHA(actual),actual_LF_sha256=SHA(actual.replace(b'\r\n',b'\n')),original_LF_sha256=witness['original_LF_sha256']);objects[witness['object_file']]=dict(actual_sha256=SHA(obj),original_sha256=witness['original_object_sha256'])
  for n,digest in meta['inputs'].items():assert SHA(z.read('current/'+case+'/inputs/'+n))==digest
  contexts.append(dict(case=case,actual_source=source,actual_BUILD_sha256=SHA(z.read(prefix+'BUILD.json')),original_controller_status=q['status'],whole_generated_sources=sources,whole_compiled_objects=objects,same_original_compiler=True,exact_two_line_dispatch_inverse=True,compiler_executions_for_this_read_only_recovery=0,model_executions=0))
parts=[];chunk=25*1024*1024
for i,offset in enumerate(range(0,len(raw),chunk),1):
 b=raw[offset:offset+chunk];file=name+'.zip'+('.part'+str(i).zfill(3) if len(raw)>chunk else '');(P/file).write_bytes(b);assert (P/file).read_bytes()==b;parts.append(dict(file=file,bytes=len(b),sha256=SHA(b)))
m=dict(status='ORIGINAL_CURRENT_COMPILED_POSTIMAGE_AND_FAILED_CONTROLLER_BYTES_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,original_artifact_id=artifact['id'],original_science_source=source,original_workflow=workflow,canonical_admission=False)
report=dict(status='ACTUAL_CURRENT_BOTTOM5_WHOLE_PHYSICAL_POSTIMAGES_EXACT_SAME_COMPILER_ZERO_MODELS',archive=name,original_archive_sha256=m['sha256'],actual_source=source,host=host,optimization=opt,contexts=contexts,source_controller_workflow_and_provider_custody=provenance,compiler_executions=0,model_executions=0,canonical_admission=False)
for root in [E,P]:
 (root/(name+'.json')).write_text(json.dumps(m,indent=2)+'\n');(root/(name+'_AUDIT.json')).write_text(json.dumps(report,indent=2)+'\n')
print('ORIGINAL_CURRENT_POSTIMAGES_VERIFIED',host,opt,version,len(contexts),sum(len(x['whole_compiled_objects']) for x in contexts),flush=True)
