from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest();SOURCE='36be92ae8aa7fe56b604c685d55af32c4a89f3b4'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from explicit_bottom9_archive_science import ReadView
from frost_boundary_convergence import require_convergence
host=sys.argv[1];api=json.loads((E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_ORIGINAL_ARTIFACTS_API_V5.json').read_text());results=[]
for opt in ['O0','O2']:
 name=f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_ORIGINAL_V5';path=E/(name+'.zip');raw=path.read_bytes();items=[x for x in api['artifacts'] if '-'+opt+'-' in x['name']];assert len(items)==1;artifact=items[0]
 assert artifact['workflow_run']['head_sha']==SOURCE and artifact['size_in_bytes']==len(raw) and artifact['digest']=='sha256:'+SHA(raw)
 members={}
 with zipfile.ZipFile(path) as z:
  assert len(z.namelist())==len(set(z.namelist()))
  for n in z.namelist():
   assert not n.endswith('/') and '..' not in n.split('/');b=z.read(n);members[n]=dict(bytes=len(b),sha256=SHA(b))
  workflow=f'.github/workflows/nomacro-frost-boundary-state-calendar04-{host.lower()}.yml';assert z.read('actual-workflow.yml')==subprocess.check_output(['git','show',SOURCE+':'+workflow],cwd=R)
  class Original:
   names=z.namelist()
   def get(self,n):return z.read(n)
  store=Original();q=json.loads(z.read('current/RESULT.json'));assert q['source']==SOURCE and q['status']=='ACTUAL_SELECTED_BOUNDARY_STATE_CALENDAR_PERIODS_NATIVE_COLD_AND_CONTROLS_PASS_NOT_ADMITTED' and len(q['contexts'])==(6 if host=='UBUNTU' else 5)
  contexts=[]
  for x in q['contexts']:
   case=x['case'];prefix='current/'+case['name'];convergence=require_convergence(ReadView(store,prefix+'/science'));assert x['convergence']['unconverged_continuations']==0
   assert x['science']['source']==SOURCE and x['science']['duration_days' if not x.get('reopened_parent') else 'phase']==(case['days'] if not x.get('reopened_parent') else 'short')
   assert x['controls'] is not None if case['days']==35 else x['controls'] is None
   contexts.append(dict(case=case,reopened_parent=bool(x.get('reopened_parent')),convergence=convergence))
 parts=[];chunk=25*1024*1024
 for i,offset in enumerate(range(0,len(raw),chunk),1):
  b=raw[offset:offset+chunk];file=name+'.zip'+('.part'+str(i).zfill(3) if len(raw)>chunk else '');(P/file).write_bytes(b);assert (P/file).read_bytes()==b;parts.append(dict(file=file,bytes=len(b),sha256=SHA(b)))
 m=dict(status='OFFICIAL_ORIGINAL_CORRECTED_TRIAL_FLUX_AND_REOPENED_PARENT_SCIENCE_ALL_BYTES_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,original_artifact_id=artifact['id'],original_science_source=SOURCE,original_workflow=workflow,canonical_admission=False)
 for root in [P,E]:(root/(name+'.json')).write_text(json.dumps(m,indent=2)+'\n')
 results.append(dict(optimization=opt,archive=name,sha256=m['sha256'],bytes=len(raw),contexts=contexts))
 print('ORIGINAL_FIFTH_EPOCH_VERIFIED',host,opt,len(contexts),len(raw),len(members),flush=True)
for root in [P,E]:(root/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_ORIGINAL_FIFTH_EPOCH_V1.json').write_text(json.dumps(dict(status='ORIGINAL_WHOLE_ARCHIVES_AND_CONVERGENCE_DIAGNOSTICS_PASS_NOT_ADMITTED',actual_source=SOURCE,archives=results),indent=2)+'\n')
