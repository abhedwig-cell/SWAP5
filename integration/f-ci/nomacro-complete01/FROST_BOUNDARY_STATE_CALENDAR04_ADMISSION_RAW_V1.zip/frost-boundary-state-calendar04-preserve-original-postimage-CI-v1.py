from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SOURCE='eab8d6e6bfa9c962c91a834f05fe4faa2ddd5d10';SHA=lambda b:hashlib.sha256(b).hexdigest()
baseline=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_BOTTOM5_PHYSICAL_POSTIMAGE_BASELINES_V1.json').read_text());summary=dict(status='FOUR_ORIGINAL_POSTIMAGE_CI_JOBS_WHOLE_SOURCES_AND_OBJECTS_EXACT_NOT_ADMITTED',actual_source=SOURCE,contexts=[],archives=[],model_executions=0,canonical_admission=False)
for host in ('UBUNTU','WINDOWS'):
 api=json.loads((E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_POSTIMAGES_ORIGINAL_ARTIFACTS_API_V1.json').read_text())
 for opt in ('O0','O2'):
  name=f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_{opt}_POSTIMAGES_ORIGINAL_V1';raw=(E/(name+'.zip')).read_bytes();art=[x for x in api['artifacts'] if '-'+opt+'-' in x['name']];assert len(art)==1;art=art[0]
  assert len(raw)==art['size_in_bytes'] and 'sha256:'+SHA(raw)==art['digest'];members={}
  with zipfile.ZipFile(E/(name+'.zip')) as z:
   assert len(z.namelist())==len(set(z.namelist()))
   for n in z.namelist():
    assert not n.endswith('/') and '..' not in n.split('/');b=z.read(n);members[n]=dict(bytes=len(b),sha256=SHA(b))
   q=json.loads(z.read('current/RESULT.json'));assert q['status']=='ACTUAL_SELECTED_BOTTOM5_PHYSICAL_BRANCHES_PUBLIC_GENERATED_AND_COMPILED_POSTIMAGES_EXACT_NO_MODEL_REPLAY_NOT_ADMITTED' and q['source']==SOURCE and q['model_executions']==0
   assert len(q['contexts'])==(4 if host=='UBUNTU' else 3)
   workflow=f'.github/workflows/nomacro-frost-boundary-state-calendar04-postimages-{host.lower()}.yml';assert z.read('actual-workflow.yml')==subprocess.check_output(['git','show',SOURCE+':'+workflow],cwd=R)
   for x in q['contexts']:
    assert x['actual_current_source']==SOURCE and x['returncode']==0 and x['model_executions']==0 and x['original_inputs_exact'] and '--build-only' in x['command']
    case=x['case'];prefix='compiled/'+case+'/bundle/';b=baseline['records'][host+'/'+opt+'/'+case];meta=json.loads(z.read(prefix+'BUILD.json'))
    assert SHA(z.read(prefix+'BUILD.json'))==x['actual_BUILD_sha256'] and {k:meta['identity'][k] for k in b['compiler']}==b['compiler']
    assert set(meta['identity']['donor_generated'])==set(b['generated'])==set(x['whole_current_generated_sources'])
    for file,item in b['generated'].items():
     data=z.read(prefix+file);obj=z.read(prefix+item['object_file']);assert SHA(data)==meta['identity']['donor_generated'][file]==x['whole_current_generated_sources'][file]['current_raw_sha256']
     assert SHA(data.replace(b'\r\n',b'\n'))==item['original_LF_sha256'] and SHA(obj)==item['original_object_sha256'] and x['whole_current_compiled_objects'][item['object_file']]['exact']
    summary['contexts'].append(dict(platform=host,optimization=opt,**x))
  parts=[];chunk=25*1024*1024
  for i,offset in enumerate(range(0,len(raw),chunk),1):
   data=raw[offset:offset+chunk];file=name+'.zip.part'+str(i).zfill(3);(P/file).write_bytes(data);assert (P/file).read_bytes()==data;parts.append(dict(file=file,bytes=len(data),sha256=SHA(data)))
  m=dict(status='OFFICIAL_ORIGINAL_COMPLETE_COMPILED_POSTIMAGES_AND_PROVIDER_BYTES_PRESERVED_NO_MODEL_EXECUTIONS',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,original_artifact_id=art['id'],original_science_source=SOURCE,original_workflow=workflow,canonical_admission=False)
  for root in (P,E):(root/(name+'.json')).write_text(json.dumps(m,indent=2)+'\n',encoding='utf8')
  summary['archives'].append(dict(name=name,bytes=len(raw),sha256=SHA(raw),artifact=art['id']))
assert len(summary['contexts'])==14
summary['whole_compiled_object_comparisons']=sum(len(x['whole_current_compiled_objects']) for x in summary['contexts'])
for root in (P,E):(root/'FROST_BOUNDARY_STATE_CALENDAR04_SAME_COMPILER_ORIGINAL_CI_POSTIMAGES_V1.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(summary['status'],len(summary['contexts']),summary['whole_compiled_object_comparisons'])

