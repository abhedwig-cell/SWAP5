from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
name='FROST_BOUNDARY_STATE_CALENDAR04_PUBLIC_WIRE_ORIGINAL_RAW_V1';files=[]
for role in ['PUBLIC','PUBLICATION']:
 stem='FROST_BOUNDARY_STATE_CALENDAR04_CANDIDATE_'+role+'_V1'
 files += [stem+s for s in ['.json','.stdout.txt','.stderr.txt']]
files += ['FROST_BOUNDARY_STATE_CALENDAR04_PUBLIC_WIRE_DISCOVERY_V1.json','frost-boundary-state-calendar04-actual-current-observer-v1.py','frost-boundary-state-calendar04-install-genuine-metadata-api-v1.py','frost_boundary_state_calendar_metadata.py','frost-boundary-state-calendar04-preserve-original-public-wire-v1.py']
members={}
with zipfile.ZipFile(E/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n in files:
  raw=(E/n).read_bytes();z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(E/(name+'.zip')) as z:
 for n,q in members.items():b=z.read(n);assert len(b)==q['bytes'] and SHA(b)==q['sha256']
raw=(E/(name+'.zip')).read_bytes();assert len(raw)<25*1024*1024;(P/(name+'.zip')).write_bytes(raw)
q=dict(status='ORIGINAL_PUBLIC568_CONTENT_SUCCESS_BROKEN_JSON_WIRE_AND_ORDINARY_PUBLICATION_PASS_FULL_STREAMS_PRESERVED_NOT_ADMISSION',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,original_source='78321fbe84d240c32e5dba96479f825349b1dc1a',canonical_admission=False,scientific_replays_for_repair=0)
for root in [P,E]:(root/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n')
docs=dict(status='DOCUMENTATION_SOURCE_CHECKS_AND_STRICT_MKDOCS_BUILD_PASS',actual_source='78321fbe84d240c32e5dba96479f825349b1dc1a',commands=[['python','-B','tools/docs/check_docs.py'],['python','-B','-m','mkdocs','build','--strict','--site-dir','C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600/frost-boundary-state-calendar04-docs-site-v2']],returncodes=[0,0],reported_mkdocs_seconds=34.82,model_executions=0,compiler_executions=0)
for root in [P,E]:(root/'FROST_BOUNDARY_STATE_CALENDAR04_DOCS_CHECKS_V1.json').write_text(json.dumps(docs,indent=2)+'\n')
print(q['status'],len(raw),len(members),flush=True)
