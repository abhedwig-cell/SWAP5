from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).parent;W=E.parent;SHA=lambda b:hashlib.sha256(b).hexdigest()
name='FROST_BOUNDARY_STATE_CALENDAR04_DISCOVERY_RAW_V1';members={};files={}
for version in (1,2):
 report=E/f'FROST_BOUNDARY_STATE_CALENDAR04_READER_DISCOVERY_V{version}.json';q=json.loads(report.read_text())
 assert q['actual_source']=='74ecc55765df548e758605f3566bc93558a6fefb' and len(q['cases'])==12 and q['model_executions']==q['compiler_executions']==0
 root=W/f'frost-boundary-state-calendar04-reader-discovery-v{version}'
 for case in q['cases']:
  for path,meta in case['input_files'].items():
   p=root/case['name']/path;raw=p.read_bytes();assert len(raw)==meta['bytes'] and SHA(raw)==meta['sha256']
   files[f'original-reader-probe-v{version}/{case["name"]}/{path}']=p
 files[report.name]=report
for p in E.glob('frost-boundary-state-calendar04-*.py'):files[p.name]=p
for p in E.glob('FROST_BOUNDARY_STATE_CALENDAR04_NEXT_BATCH_*.json'):files[p.name]=p
note=dict(status='DISCOVERY_ONLY_NO_MODEL_NO_ADMISSION',actual_reader_source='74ecc55765df548e758605f3566bc93558a6fefb',
 v1_limitation='Initial boundary5 probe templates duplicated an existing DATE5 table. Current public reader refused earlier at missing composition guards. These bytes are preserved as input-template failure evidence; they do not establish valid physical input or numerical behavior.',
 v2='The original single DATE5 table is retained. Twelve current public guard refusals and separate proposed selector outcomes are preserved. Full original provider/table validation is still required after implementation.',
 no_current_namespace_or_HEAD_projection=True,compiler_executions=0,model_executions=0)
payloads={key:p.read_bytes() for key,p in files.items()};payloads['DISCOVERY_LIMITATIONS.json']=json.dumps(note,indent=2).encode()
with zipfile.ZipFile(E/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for key,raw in sorted(payloads.items()):z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(E/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,meta in members.items():
  raw=z.read(key);assert len(raw)==meta['bytes'] and SHA(raw)==meta['sha256']
raw=(E/(name+'.zip')).read_bytes();q=dict(status='REAL_INPUT_GUARD_DISCOVERY_AND_INITIAL_TEMPLATE_FAILURE_BYTES_PRESERVED_NO_MODEL_OR_SCIENCE_CLAIM',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,actual_reader_source='74ecc55765df548e758605f3566bc93558a6fefb',compiler_executions=0,model_executions=0)
(E/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],len(raw),q['sha256'],len(members))
