"""Preserve both real local periods, original failed controls and exact binaries."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;W=E.parent;P=R/'integration/f-ci/nomacro-complete01';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
COMPILER='3feb51229a980331bc12be2d1d265bef7ae6691a';head=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored') and not git('diff',COMPILER,head,'--','app','src','tools','reference')
name='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1';archive=E/(name+'.zip');assert not archive.exists()
source=E/'FROST_BOUNDARY_STATE_CALENDAR04_ACTUAL_COMPILER_3feb51229a_SOURCE_DATA_V1.tar';assert not source.exists()
subprocess.run(['git','archive','--format=tar','--output='+str(source),COMPILER,'--','app','src','tools','tests','.github'],cwd=R,check=True)
commit=git('cat-file','commit',COMPILER);assert hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==COMPILER
contexts=[];files={};inventory=[]
def add_tree(root,prefix):
 assert root.is_dir() and not root.is_symlink()
 for path in sorted(root.rglob('*')):
  assert not path.is_symlink()
  if path.is_file():
   key=prefix+'/'+path.relative_to(root).as_posix();assert key not in files;files[key]=path
 inventory.append(dict(original_path=str(root),archive_prefix=prefix))
for opt in ('O0','O2'):
 data=W/'frost-boundary-state-calendar04-water-smoke-v1'/opt;case=data/'water-b5-i0-h0-p1-regular-r0'
 sci=json.loads((case/'science/RESULT.json').read_text());controls=json.loads((case/'completed-controls-v2/RESULT.json').read_text())
 assert sci['source']==COMPILER and sci['status']=='ACTUAL_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED' and sci['duration_days']==35
 assert len(sci['native_samples'])==7 and len(sci['own'])==3
 assert controls['status']=='ACTUAL_FROST_CALENDAR_COMPILED_NATIVE_SNOW_CDE_ROOT_AND_TRANSACTIONS_PASS_NOT_ADMITTED'
 assert len(controls['existing_calendar_thermal_refusals'])==39 and len(controls['new_snow_private_and_codec_refusals'])==35 and controls['full_model_periods_replayed']==controls['compiled_native_refusal_processes_reexecuted']==0
 contexts.append(dict(case='water-b5-i0-h0-p1-regular-r0',platform='Windows',optimization=opt,actual_compiler_source=COMPILER,actual_control_recovery_source=controls['actual_controller_source'],actual_science=sci,actual_controls=controls,original_failed_cohort_record=json.loads((data/'RESULT.json').read_text()),archive_case_prefix='current/'+opt+'/water-b5-i0-h0-p1-regular-r0',actual_science_and_compiler_are_local_not_GitHub_CI=True))
 add_tree(data,'current/'+opt)
 build=W/('frost-boundary-state-calendar04-water-smoke-'+opt+'-v1');add_tree(build,'compiled/'+opt)
add_tree(J/'build','original-provider-build');files['provider-PREPARED.json']=J/'PREPARED.json'
files['source/actual-compiler-git-archive-'+COMPILER+'.tar']=source
for path in E.glob('frost-boundary-state-calendar04-*.py'):files['controllers/'+path.name]=path
for path in E.glob('FROST_BOUNDARY_STATE_CALENDAR04_*.json'):files['observations/'+path.name]=path
payloads={'source/actual-compiler-commit-'+COMPILER+'.bin':commit}
source_record=dict(status='EXPLICIT_GIT_DATA_ARCHIVE_OF_REAL_PREVIOUS_COMPILER_SOURCE_NOT_A_CURRENT_CHECKOUT_PROJECTION',actual_compiler_commit=COMPILER,tree=git('rev-parse',COMPILER+'^{tree}').decode().strip(),source_archive_sha256=SHA(source.read_bytes()),collection_repository_HEAD=head,repository_HEAD_unchanged=True,app_src_tools_reference_postimages_still_exact=True)
payloads['source/ACTUAL_COMPILER_SOURCE_IDENTITY.json']=json.dumps(source_record,indent=2).encode()
summary=dict(status='TWO_REAL_LOCAL_WINDOWS_O0_O2_FULL35_NATIVE_COLD_AND_COMPLETE_COMPILED_CONTROLS_PASS_NOT_ADMITTED',contexts=contexts,primary_days=70,native_samples=14,exact_cold_windows=6,actual_compiled_refusals=148,transaction_contexts=4,full_model_periods_replayed_for_read_only_count_correction=0,refusal_processes_reexecuted_for_read_only_count_correction=0,actual_compiler_source=COMPILER,source=source_record,physical_inventory=inventory,canonical_admission=False,functional_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
payloads['LOCAL_COMPLETE_SELECTED_COHORT.json']=json.dumps(summary,indent=2).encode();members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for key,path in sorted(files.items()):
  raw=path.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
 for key,raw in sorted(payloads.items()):assert key not in members;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(members)
 for key,meta in members.items():
  raw=z.read(key);assert len(raw)==meta['bytes'] and SHA(raw)==meta['sha256']
raw=archive.read_bytes();parts=[];chunk=25*1024*1024
for offset in range(0,len(raw),chunk):
 filename=name+'.zip.part'+str(offset//chunk+1).zfill(3);piece=raw[offset:offset+chunk];path=P/filename;assert not path.exists();path.write_bytes(piece);parts.append(dict(file=filename,bytes=len(piece),sha256=SHA(piece)))
manifest=dict(status='ACTUAL_LOCAL_WINDOWS_SCIENCE_COMPILERS_INPUTS_NATIVE_RAW_FAILURES_AND_METADATA_RECOVERY_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_compiler_source=COMPILER,actual_current_collection_source=head,local_contexts=2,primary_days=70,canonical_admission=False)
(P/(name+'.json')).write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8');(E/(name+'.json')).write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
(P/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_CENTRAL_V1.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
assert git('rev-parse','HEAD').decode().strip()==head
print(manifest['status'],len(raw),SHA(raw),len(members),len(parts),flush=True)
