from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
source='0566877f3d1ef27a472c4fae6f5275e8e76871a4';name='FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLOCK_LOCAL_WINDOWS_RAW_V1';files={};inventory=[];complete=[]
def add(root,prefix):
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():files[prefix+'/'+p.relative_to(root).as_posix()]=p
 inventory.append(dict(original_path=str(root),archive_prefix=prefix))
data=W/'frost-boundary-state-calendar04-plate-clock-public-v1';add(data,'current')
for opt in ('O0','O2'):
 for version in (1,2,3):add(W/f'frost-boundary-state-calendar04-plate-clock-{opt}-v{version}',f'compiled/{opt}/v{version}')
 root=data/(opt+'-v3');q=json.loads((root/'RESULT.json').read_text())
 assert q['source']==source and q['status']=='ACTUAL_SELECTED_BOUNDARY_STATE_CALENDAR_PERIODS_NATIVE_COLD_AND_CONTROLS_PASS_NOT_ADMITTED'
 assert len(q['contexts'])==1;s=q['contexts'][0]['science'];c=q['contexts'][0]['controls'];assert s['duration_days']==35 and len(s['native_samples'])==7 and len(s['own'])==3 and len(c['existing_calendar_thermal_refusals'])==44 and len(c['new_snow_private_and_codec_refusals'])==39 and c['snow_transaction']['replay_exact'] and c['frost_calendar_transaction']['replay_exact']
 complete.append(dict(platform='Windows',optimization=opt,actual_compiler_and_science_source=source,actual_science=s,actual_controls=c))
for commit in ('7cc40bfedbf5838adc57f53058fb2027618b41ba','c555f7974c9463be458a4fce18d63131c8f06782',source):
 target=E/('FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLOCK_ACTUAL_SOURCE_'+commit+'.tar')
 assert not target.exists();subprocess.run(['git','archive','--format=tar','--output='+str(target),commit,'--','app','src','tools','tests','.github'],cwd=R,check=True)
 files['sources/'+target.name]=target
 target=E/('FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLOCK_ACTUAL_COMMIT_'+commit+'.bin');target.write_bytes(subprocess.check_output(['git','cat-file','commit',commit],cwd=R));files['sources/'+target.name]=target
for p in E.glob('frost-boundary-state-calendar04-*.py'):files['controllers/'+p.name]=p
for p in E.glob('FROST_BOUNDARY_STATE_CALENDAR04_*.json'):files['observations/'+p.name]=p
members={}
with zipfile.ZipFile(E/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for key,p in sorted(files.items()):
  raw=p.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(E/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,v in members.items():raw=z.read(key);assert len(raw)==v['bytes'] and SHA(raw)==v['sha256']
raw=(E/(name+'.zip')).read_bytes();parts=[];chunk=25*1024*1024
for i,offset in enumerate(range(0,len(raw),chunk),1):
 piece=raw[offset:offset+chunk];file=name+'.zip.part'+str(i).zfill(3);(P/file).write_bytes(piece);assert (P/file).read_bytes()==piece;parts.append(dict(file=file,bytes=len(piece),sha256=SHA(piece)))
manifest=dict(status='TWO_REAL_PUBLIC_PLATE_CLOCK_REPAIR_FULL35_WITH_RAW_FAILED_PRIOR_ATTEMPTS_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_scientific_source=source,physical_inventory=inventory,compiler_recipe='Actual public portable O0/O2 same strict original J provider and unchanged mass/state/retry limits',canonical_admission=False)
summary=dict(status=manifest['status'],contexts=complete,primary_days=70,native_samples=14,exact_cold_windows=6,compiled_refusals=166,transaction_contexts=4,actual_source=source,raw=manifest['sha256'],prior_failed_before_model_attempts_preserved=4,accepted_failed_periods_relabelled=0,canonical_admission=False)
for root in (P,E):
 (root/(name+'.json')).write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
 (root/'FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLOCK_LOCAL_WINDOWS_CENTRAL_V1.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(manifest['status'],len(raw),manifest['sha256'],len(members))

