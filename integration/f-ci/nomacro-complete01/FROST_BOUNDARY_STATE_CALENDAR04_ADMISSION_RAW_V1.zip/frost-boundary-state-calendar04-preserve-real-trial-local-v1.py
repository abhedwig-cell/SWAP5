from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
source='dfb4337cb5fffcf70b1fa20a672683c6ea034690';name='FROST_BOUNDARY_STATE_CALENDAR04_TRIAL_FLUX_LOCAL_WINDOWS_RAW_V1';files={};inventory=[]
def add(root,prefix):
 assert root.is_dir()
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():files[prefix+'/'+p.relative_to(root).as_posix()]=p
 inventory.append(dict(original_path=str(root),archive_prefix=prefix))
data=W/'frost-boundary-state-calendar04-trial-flux-public-v1';add(data,'current')
for opt in ['O0','O2']:
 add(W/f'frost-boundary-state-calendar04-trial-flux-{opt}-v1','compiled/'+opt)
 q=json.loads((data/opt/'RESULT.json').read_text());assert q['source']==source and q['status']=='ACTUAL_SELECTED_BOUNDARY_STATE_CALENDAR_PERIODS_NATIVE_COLD_AND_CONTROLS_PASS_NOT_ADMITTED'
 assert len(q['contexts'])==1 and q['contexts'][0]['convergence']['unconverged_continuations']==0
target=E/('FROST_BOUNDARY_STATE_CALENDAR04_TRIAL_FLUX_ACTUAL_SOURCE_'+source+'.tar')
assert not target.exists();subprocess.run(['git','archive','--format=tar','--output='+str(target),source,'--','app','src','tools','tests','.github'],cwd=R,check=True);files['sources/'+target.name]=target
target=E/('FROST_BOUNDARY_STATE_CALENDAR04_TRIAL_FLUX_ACTUAL_COMMIT_'+source+'.bin');target.write_bytes(subprocess.check_output(['git','cat-file','commit',source],cwd=R));files['sources/'+target.name]=target
files['controllers/'+Path(__file__).name]=Path(__file__)
members={}
with zipfile.ZipFile(E/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for key,p in sorted(files.items()):
  raw=p.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(E/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,v in members.items():raw=z.read(key);assert len(raw)==v['bytes'] and SHA(raw)==v['sha256']
raw=(E/(name+'.zip')).read_bytes();parts=[];chunk=25*1024*1024
for i,offset in enumerate(range(0,len(raw),chunk),1):
 piece=raw[offset:offset+chunk];file=name+'.zip'+('.part'+str(i).zfill(3) if len(raw)>chunk else '');(P/file).write_bytes(piece);assert (P/file).read_bytes()==piece;parts.append(dict(file=file,bytes=len(piece),sha256=SHA(piece)))
provider=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1.json').read_text())
manifest=dict(status='TWO_REAL_PUBLIC_PLATE_TRIAL_FLUX_FULL35_NATIVE_COLD_CONTROLS_ZERO_CONVERGENCE_WARNINGS_ORIGINAL_BYTES_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_scientific_source=source,physical_inventory=inventory,original_provider_dependency=dict(archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',sha256=provider['sha256']),compiler_recipe='Actual public portable O0/O2 same strict original J provider and unchanged mass/state/retry limits; actual trial boundary flux only; original TimeControl',canonical_admission=False)
for root in [P,E]:(root/(name+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
print(manifest['status'],len(raw),manifest['sha256'],len(members),flush=True)
