from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
sources=['FROST_BOUNDARY_STATE_CALENDAR04_ACTUAL_CLOCK_DIAGNOSTIC_AND_READERS_RAW_V1','FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLOCK_LOCAL_WINDOWS_RAW_V1','FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1']
prior={};dependencies={};archives={}
for name in sources:
 m=json.loads((P/(name+'.json')).read_text());assert SHA((E/(name+'.zip')).read_bytes())==m['sha256'];archives[name]=zipfile.ZipFile(E/(name+'.zip'));dependencies[name]=dict(sha256=m['sha256'],manifest_sha256=SHA((P/(name+'.json')).read_bytes()))
 for n,item in m['members'].items():prior.setdefault(item['sha256'],dict(archive=name,member=n,bytes=item['bytes']))
roots=['frost-boundary-state-calendar04-input-contract-v3','frost-boundary-state-calendar04-bottom5-postimages-v1','frost-boundary-state-calendar04-current-local-water-postimage-v3']
roots += ['frost-boundary-state-calendar04-'+label+'-'+opt+'-'+version for label,version in [('bottom5-postimages','v1'),('bottom5-postimages','v2'),('current-water-postimage','v3')] for opt in ['O0','O2']]
roots += ['frost-boundary-state-calendar04-dayclock-causal-v1/'+n for n in ['headcalc-guard-observation-v1','headcalc-guard-observation-v2','trial-flux-counterfactual-v1','trial-flux-counterfactual-v2']]
name='FROST_BOUNDARY_STATE_CALENDAR04_TRIAL_DISCOVERY_AND_POSTIMAGES_RAW_V1';archive=E/(name+'.zip');inventory={};members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def preserve(key,raw):
  digest=SHA(raw)
  if digest in prior:
   original=prior[digest];assert archives[original['archive']].read(original['member'])==raw;storage=dict(inherited_exact_original_bytes=original)
  else:
   member='raw/'+digest
   if member not in members:z.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=digest)
   storage=dict(member=member)
  inventory[key]=dict(bytes=len(raw),sha256=digest,**storage)
 for root in roots:
  assert (W/root).is_dir(),root
  for p in sorted((W/root).rglob('*')):
   assert not p.is_symlink()
   if p.is_file():preserve(root+'/'+p.relative_to(W/root).as_posix(),p.read_bytes())
 for p in E.glob('frost-boundary-state-calendar04-*headcalc*.py'):preserve('controllers/'+p.name,p.read_bytes())
 for n in ['frost-boundary-state-calendar04-trial-flux-counterfactual-v1.py','frost-boundary-state-calendar04-trial-flux-counterfactual-v2.py','frost-boundary-state-calendar04-freeze-trial-receipt-v1.py','frost-boundary-state-calendar04-preserve-trial-discovery-and-postimages-v1.py','FROST_BOUNDARY_STATE_CALENDAR04_PARENT524_CONVERGENCE_WARNING_DISCOVERY_V1.json','FROST_BOUNDARY_STATE_CALENDAR04_PLATE_ORIGINAL_CONVERGENCE_WARNING_SCAN_V1.json']:preserve('controllers/'+n,(E/n).read_bytes())
with zipfile.ZipFile(archive) as z:
 for n,item in members.items():assert SHA(z.read(n))==item['sha256'] and len(z.read(n))==item['bytes']
for z in archives.values():z.close()
raw=archive.read_bytes();chunk=25*1024*1024;parts=[]
for i,offset in enumerate(range(0,len(raw),chunk),1):
 b=raw[offset:offset+chunk];file=name+'.zip'+('.part'+str(i).zfill(3) if len(raw)>chunk else '');(P/file).write_bytes(b);assert (P/file).read_bytes()==b;parts.append(dict(file=file,bytes=len(b),sha256=SHA(b)))
record=dict(status='ORIGINAL_TRIAL_DIAGNOSTICS_AND_POSTIMAGE_SUCCESS_FAILURE_AND_INPUT_BYTES_PRESERVED_NOT_QUALIFIED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,physical_inventory=inventory,exact_original_byte_dependencies=dependencies,collection_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),canonical_admission=False)
for root in [E,P]:(root/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print('PRESERVED_ORIGINALS',len(raw),len(inventory),len(members),flush=True)
