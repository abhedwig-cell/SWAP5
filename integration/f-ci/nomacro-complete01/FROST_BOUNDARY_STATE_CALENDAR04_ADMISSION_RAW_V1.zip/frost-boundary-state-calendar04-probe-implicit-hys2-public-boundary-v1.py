from pathlib import Path
import json,sys,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');W=E.parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_boundary_state_calendar_inputs import prepare
import experimental_project as public
import frost_boundary_state_calendar as owner
q=json.loads((R/'integration/f-ci/nomacro-complete01/FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text());base=q['known_numerically_blocked_cases'][0];rows=[]
for kind in ('water','cde'):
 for calendar in ('regular','monthly','dates'):
  case=dict(base,kind=kind,calendar=calendar,reset=1,start=None,name='guard-probe-'+kind+'-'+calendar)
  folder=W/'frost-boundary-state-calendar04-input-contract-v3'/case['name'];prepare(case,folder)
  row=dict(case=case,actual_new_composition_selection=owner.selection(folder,True))
  try:
   project=public.load(folder,original_output=True,time_step_policy='original-adaptive-event-closure-v1');row.update(public_load='ACCEPTED',actual_model=project.model)
  except ValueError as error:row.update(public_load='REFUSED',error=str(error))
  rows.append(row)
out=dict(actual_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),probes=rows,compiler_executions=0,model_executions=0)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_IMPLICIT_HYS2_PUBLIC_BOUNDARY_PROBES_V1.json').write_text(json.dumps(out,indent=2)+'\n')
print([(x['case']['kind'],x['case']['calendar'],x['public_load']) for x in rows])

