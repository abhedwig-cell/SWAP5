"""Actual unchanged public reader refusals and separate proposed selector probe."""
from pathlib import Path
import importlib.util,json,hashlib,subprocess,sys,re
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
W=E.parent/'frost-boundary-state-calendar04-reader-discovery-v2'
sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_calendar_state_inputs import prepare
from original_output_baseline import assignment
import experimental_project as public
spec=importlib.util.spec_from_file_location('proposed_new_boundary_configuration_selector',E/'frost-boundary-state-calendar04-new-selector-v1.py');proposal=importlib.util.module_from_spec(spec);spec.loader.exec_module(proposal)
cases=[('water',5,0,0,1,'regular',0,None,35),('cde',5,0,1,2,'monthly',1,None,35),
 ('water',8,0,1,1,'dates',1,None,35),('cde',8,0,0,2,'regular',1,None,35),
 ('water',5,1,1,1,'monthly',1,None,35),('cde',5,1,0,2,'dates',1,None,35),
 ('water',5,0,0,1,'dense',1,None,35),('cde',8,0,1,2,'dense',1,None,35),('cde',5,1,1,1,'dense',1,None,35),
 ('water',5,0,2,2,'monthly',1,'2002-12-26',12),('cde',8,0,2,2,'dates',0,'2002-12-26',12),
 ('cde',5,1,2,2,'regular',0,'2002-12-26',12)]
records=[];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='74ecc55765df548e758605f3566bc93558a6fefb'
for kind,bottom,implicit,hys,initial,calendar,reset,start,days in cases:
 name=f'{kind}-b{bottom}-i{implicit}-h{hys}-p{initial}-{calendar}-r{reset}'+('-year-seam' if start else '')
 folder=W/name;assert not folder.exists();prepare(kind,hys,initial,implicit,'regular' if calendar=='dense' else calendar,folder,reset=reset,start=start)
 p=folder/'swap.swp';s=p.read_text(encoding='cp1252');s=assignment(s,'SWBOTB',bottom)
 if calendar=='dense':s=assignment(s,'PERIOD',1)
 if bottom==5 and not re.search(r'(?mi)^\s*DATE5\s+HBOT5',s):s+='\nDATE5 HBOT5\n2002-01-01 -100.0\n2004-12-31 -100.0\n* End of table\n'
 if bottom==8:s+='\nHPLATE = -50.0\n'
 p.write_text(s,encoding='cp1252')
 selected=proposal.selection(folder,True);assert selected is not None,name
 try:public.load(folder,original_output=True,time_step_policy='original-adaptive-event-closure-v1')
 except ValueError as error:refusal=str(error)
 else:raise AssertionError('New missing composition unexpectedly already admitted '+name)
 records.append(dict(name=name,kind=kind,bottom=bottom,implicit=implicit,hysteresis=hys,initial=initial,calendar=calendar,reset=reset,start=start,days=days,actual_public_refusal=refusal,proposed_selector=selected,input_files={p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in folder.rglob('*') if p.is_file()}))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
q=dict(status='TWELVE_REAL_CURRENT_PUBLIC_REFUSALS_SEPARATE_PROPOSED_SELECTOR_RECOGNIZED_NO_MODEL_OR_SCIENTIFIC_CLAIM',actual_source=head,cases=records,compiler_executions=0,model_executions=0,source_or_filesystem_identity_projected=False)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_READER_DISCOVERY_V2.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8');print(q['status'],flush=True)

