"""Observe the genuine original final HeadCalc criteria without changing equations."""
from pathlib import Path
import contextlib,hashlib,json,shutil,subprocess,sys,time,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=W/'frost-boundary-state-calendar04-dayclock-causal-v1'/'headcalc-guard-observation-v2';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider/build');B=W/'frost-boundary-state-calendar04-plate-clock-O0-v3/cde-b8-i0-h0-p2-regular-r1/bundle';case='cde-b8-i0-h0-p2-regular-r1';SHA=lambda b:hashlib.sha256(b).hexdigest()
D.mkdir();trace=D/'bundle';shutil.copytree(B,trace);meta=json.loads((B/'BUILD.json').read_text())
for n,digest in meta['identity']['donor_objects'].items():assert SHA((J/'swap-obj'/n).read_bytes())==digest
assert SHA((J/'ttutil-obj/libttutil.a').read_bytes())==meta['identity']['ttutil_library']
inputs=D/'inputs';inputs.mkdir()
with zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLOCK_LOCAL_WINDOWS_RAW_V1.zip') as z:
 prefix='current/O0-v3/'+case+'/inputs/'
 for n in z.namelist():
  if n.startswith(prefix):
   p=inputs/n[len(prefix):];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
for n,digest in meta['inputs'].items():assert SHA((inputs/n).read_bytes())==digest
path=trace/'headcalc.f90';original=path.read_bytes();text=original.decode('cp1252').replace('\r\n','\n')
a='!  criteria';assert text.count(a)==1;text=text.replace(a,'   logical :: observed_original_physical_nonconvergence\n\n'+a)
a='      if (budget_enabled .and. .not.flnonconv) then';assert text.count(a)==1;text=text.replace(a,'      observed_original_physical_nonconvergence=flnonconv\n'+a)
a='!     continue without convergence !!!';assert text.count(a)==1
observation="""      write(*,'(a,4(1x,l1),9(1x,es25.17e3),3(1x,i0))') 'CVG_OBSERVATION', &
        observed_original_physical_nonconvergence,budget_enabled,fldtmin,flboth, &
        tcum,dt,t1900,terminal_water_residual(),budget_total+budget_step, &
        1d-10*(t1900-budget_start+dt),sum1,qbot,-kmean(NN+1)*hgrad(NN+1),numbit,MaxIt,MaxIt1
"""
text=text.replace(a,a+'\n'+observation);path.write_text(text,encoding='cp1252')
commands=[]
def run(cmd):
 commands.append(cmd);p=subprocess.run(cmd,cwd=trace,capture_output=True)
 (D/f'compiler-{len(commands)}.stdout').write_bytes(p.stdout);(D/f'compiler-{len(commands)}.stderr').write_bytes(p.stderr);p.check_returncode()
run(['gfortran',*meta['identity']['donor_flags'],'-I',str(J/'swap-obj'),'-I',str(J/'ttutil-obj'),'-c','headcalc.f90'])
objects={p.name:p for p in (J/'swap-obj').glob('*.o')};objects.update({p.name:p for p in trace.glob('*.o')})
exe=trace/'day_donor_guard_observation.exe';run(['gfortran','-o',str(exe),*[str(objects[n]) for n in sorted(objects)],str(J/'ttutil-obj/libttutil.a')])
sys.path.insert(0,str(R/'app/hybrid_water'));import daily_host as h,experimental_project as e
assert SHA(h.executable(B,'day_donor').read_bytes())==meta['executable_sha256']['donor'] and SHA(h.executable(B,'day_kernel').read_bytes())==meta['executable_sha256']['kernel']
project=e.load(inputs,original_output=True,time_step_policy='original-adaptive-event-closure-v1');out=D/'actual-run';out.mkdir();started=time.perf_counter()
with contextlib.ExitStack() as stack:
 host=h.DailyHost(stack,exe,h.executable(B,'day_kernel'),inputs,out,[h.ColumnStart('original',0,None,None)],checkpoint_enabled=False,runtime=True,binding=None,model=project.model,project=project)
 row=host.step(1);host.close()
(out/'actual-day1.json').write_text(json.dumps(row,indent=2)+'\n')
with zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLOCK_LOCAL_WINDOWS_RAW_V1.zip') as z:prior=json.loads(z.read('current/O0-v3/'+case+'/science/trajectory/daily.jsonl').splitlines()[0])
assert row==prior
report=dict(status='ACTUAL_HEADCALC_OBSERVATIONAL_ONE_DAY_MATCHES_ORIGINAL_ALL_FIELDS_NOT_QUALIFIED',actual_original_compiler_source='0566877f3d1ef27a472c4fae6f5275e8e76871a4',actual_collection_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),original_HeadCalc_sha256=SHA(original),observational_HeadCalc_sha256=SHA(path.read_bytes()),equations_thresholds_or_flags_changed=False,new_local_observation_variable_only=True,commands=commands,actual_whole_day_equal_original=True,model_seconds=time.perf_counter()-started,checkpoint_publication='NOT_SELECTED_DIAGNOSTIC',canonical_admission=False,row=row)
(D/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
for line in (out/'original/donor.stdout').read_text().splitlines():
 if line.startswith('CVG_OBSERVATION'):print(line)
print(report['status'],flush=True)


