"""Resume actual never-merge controls, preserving every original push attempt."""
import argparse,hashlib,json,re,subprocess,sys,time
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
parser=argparse.ArgumentParser();parser.add_argument('--candidate',required=True);parser.add_argument('--version',required=True);args=parser.parse_args();C=args.candidate;assert re.fullmatch('[0-9a-f]{40}',C);SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
clean=lambda:not git('status','--porcelain=v1','--untracked-files=all','--ignored')
PATHS={'SOURCE':'app/hybrid_water/frost_boundary_terminal_trial.py','RAW':'integration/f-ci/nomacro-complete01/FROST_BOUNDARY_STATE_CALENDAR04_UBUNTU_O0_ORIGINAL_V5.zip.part001','INHERITED':'integration/f-ci/nomacro-complete01/INITIAL_PROFILE_FROST_ADMISSION_RAW_V1.zip','PUBLICATION':'docs/publication/P2E09_REFERENCE_ONLY_THRESHOLD_FREEZE_PREREGISTRATION.json'}
out=E/'FROST_BOUNDARY_STATE_CALENDAR04_FINAL_NEGATIVES_V1.json'
if out.exists():
 q=json.loads(out.read_text());assert q['candidate']==C and q['owner_task']=='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
else:
 for role in PATHS:
  branch='codex/nomacro-frost-boundary-state-calendar-negative-'+role.lower()+'01'
  assert not git('ls-remote','--heads','origin','refs/heads/'+branch)
  assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=R).returncode==1
 q=dict(status='RUNNING',candidate=C,owner_task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713',never_merge=True,controls=[],compiler_executions=0,model_executions=0)
save=lambda:out.write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
positive=json.loads((E/('FROST_BOUNDARY_STATE_CALENDAR04_CANDIDATE_PUBLIC_'+args.version+'.json')).read_text());assert positive['before']==positive['after'] and positive['before']['head']==C and positive['returncode']==0
pub=json.loads((E/('FROST_BOUNDARY_STATE_CALENDAR04_CANDIDATE_PUBLICATION_'+args.version+'.json')).read_text());assert pub['before']==pub['after'] and pub['before']['head']==C and pub['returncode']==0
assert git('rev-parse','HEAD')==C and clean()
def run(args):
 if args[0]=='git':args=args[:1]+['-c','gc.auto=0','-c','maintenance.auto=false']+args[1:]
 return subprocess.run(args,cwd=R,check=True,capture_output=True)
def observe(label,publication=False):
 args=[sys.executable,'-B',str(R/'tests/nomacro_drainage/explicit_bottom9_combined_public_observe.py'),'--cwd',str(R),'--output',str(E/label)]
 if publication:args.append('--publication')
 result=subprocess.run(args,cwd=R,capture_output=True,timeout=3700)
 (E/(label+'-observer.stdout.txt')).write_bytes(result.stdout);(E/(label+'-observer.stderr.txt')).write_bytes(result.stderr);result.check_returncode()
 value=json.loads((E/(label+'.json')).read_text());assert value['before']==value['after'] and value['before']['head']==git('rev-parse','HEAD')
 assert value['before']['sparse']==positive['before']['sparse'] and value['before']['original_project_files']==positive['before']['original_project_files']
 return value
save()
try:
 for role,path in PATHS.items():
  assert clean();run(['git','switch','--detach',C]);branch='codex/nomacro-frost-boundary-state-calendar-negative-'+role.lower()+'01'
  item=next((v for v in q['controls'] if v['role']==role),None)
  if item is None:
   assert not git('ls-remote','--heads','origin','refs/heads/'+branch)
   run(['git','switch','-c',branch]);target=R/path
   if not target.is_file():run(['git','restore','--source='+C,'--worktree','--ignore-skip-worktree-bits','--',path])
   assert clean() and target.is_file() and not target.is_symlink()
   original=target.read_bytes()
   if role=='SOURCE':
    before=b"selected['bottom']==8";assert original.count(before)==1;changed=original.replace(before,b"selected['bottom']==5",1);recipe=dict(original_expression=before.decode(),never_merge_test_guard='Wrong actual trial guard dispatch boundary5 in place of qualified explicit plate8; never execute models')
   elif role=='PUBLICATION':changed=original+b'\n \n';recipe=dict(append_only_JSON_whitespace=True,original_document_values_unchanged=True)
   else:
    assert role in ('RAW','INHERITED');offset=len(original)//2;changed=bytearray(original);changed[offset]^=1;changed=bytes(changed);recipe=dict(offset=offset,xor_hex='01',old_byte=original[offset],new_byte=changed[offset])
   target.write_bytes(changed);run(['git','add','--sparse','--',path]);run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','NEVER MERGE Frost boundary '+role.lower()+' actual public negative'])
   item=dict(role=role,path=path,branch=branch,head=git('rev-parse','HEAD'),exact_parent=C,actual_original_file_sha256=SHA(original),actual_mutated_file_sha256=SHA(changed),mutation_recipe=recipe,status='ACTUAL_COMMITTED_PENDING_PUSH',never_merge=True);q['controls'].append(item);save()
  else:run(['git','switch',branch])
  assert git('rev-parse','HEAD')==item['head'] and git('show','-s','--format=%P',item['head'])==C and git('diff','--name-only',C,item['head'])==path and clean()
  remote=git('ls-remote','--heads','origin','refs/heads/'+branch)
  assert not remote or remote.split()[0]==item['head']
  if item.get('actual_refusal'):
   assert remote and item['status']=='ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_REFUSED'
   item['prior_success_inherited_without_control_replay']=True;save();continue
  if not remote:
   first_attempt=len(item.get('resumed_push_attempts',[]))+1
   for attempt in range(first_attempt,first_attempt+3):
    response=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-c','pack.threads=2','push','origin','HEAD:refs/heads/'+branch],cwd=R,capture_output=True,timeout=180)
    label=f'FROST_BOUNDARY_STATE_CALENDAR04_FINAL_{role}_PUSH_ATTEMPT{attempt}'
    for suffix,raw in (('.stdout.txt',response.stdout),('.stderr.txt',response.stderr)):
     with (E/(label+suffix)).open('xb') as f:f.write(raw)
    item.setdefault('resumed_push_attempts',[]).append(dict(returncode=response.returncode,stdout=label+'.stdout.txt',stderr=label+'.stderr.txt'));save()
    if response.returncode==0:break
    if attempt==first_attempt+2:response.check_returncode()
    time.sleep(2)
  assert git('ls-remote','--heads','origin','refs/heads/'+branch).split()[0]==item['head'];item['status']='ACTUAL_COMMITTED_PUSHED_PENDING_PUBLIC_REFUSAL';save()
  label='FROST_BOUNDARY_STATE_CALENDAR04_FINAL_'+role+'_PUBLIC_V1';value=observe(label);error=(E/(label+'.stderr.txt')).read_bytes()
  assert value['status']=='ACTUAL_PUBLIC_COMMAND_RETURNED' and value['returncode'] not in (None,0) and b'AssertionError' in error
  item.update(status='ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_REFUSED',actual_refusal=True,actual_one_file_delta=True,actual_public_seconds=value['seconds'],actual_public_returncode=value['returncode'],actual_public_stderr_sha256=SHA(error),actual_observation=label);save()
  if role=='PUBLICATION':
   label='FROST_BOUNDARY_STATE_CALENDAR04_FINAL_PUBLICATION_SCOPE_V1';value=observe(label,True);assert value['returncode']==0 and 'PUBLICATION_REPLAY_SELECTED=true' in (E/(label+'.stdout.txt')).read_text() and not (E/(label+'.stderr.txt')).read_bytes();item['actual_publication_replay_selected']=True;save()
  print('ACTUAL_COMMITTED_PUSHED_CLEAN14_NEGATIVE_REFUSED',role,item['head'],item['actual_public_seconds'],flush=True)
 assert len(q['controls'])==4 and all(v['actual_refusal'] for v in q['controls']);q['status']='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
except Exception as error:q.update(status='FAILED_ACTUAL_NEGATIVE_CAMPAIGN_NOT_QUALIFIED',error=repr(error));raise
finally:
 save()
 if clean():run(['git','switch','--detach',C])
run(['git','switch','codex/nomacro-frost-boundary-state-calendar04']);assert clean() and git('rev-parse','HEAD')==C
print(q['status'],flush=True)

