from pathlib import Path
import json,zipfile,hashlib
E=Path(__file__).parent;W=E.parent;case='cde-b5-i0-h1-p2-monthly-r1';B=W/'frost-boundary-state-calendar04-bottom5-postimages-O0-v1'/case/'bundle'
with zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_WINDOWS_O0_ORIGINAL_V1.zip') as z:
 p='compiled/'+case+'/bundle/';old=json.loads(z.read(p+'BUILD.json'));current=json.loads((B/'BUILD.json').read_text())
 print('OLD_COMPILER',old['identity']['compiler'],old['identity']['compiler_sha256'],old['identity']['donor_flags'])
 print('NEW_COMPILER',current['identity']['compiler'],current['identity']['compiler_sha256'],current['identity']['donor_flags'])
 for name in current['identity']['donor_generated']:
  a=z.read(p+name);b=(B/name).read_bytes()
  if a!=b:print('SOURCE_DIFF',name,'LF_EXACT',a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),len(a),len(b))
 name='divdra.o';a=z.read(p+name);b=(B/name).read_bytes();print('OBJECT_EXAMPLE',len(a),len(b),'DIFFERENT_BYTES',sum(x!=y for x,y in zip(a,b)),'FIRST_DIFFERENCES',[(i,x,y) for i,(x,y) in enumerate(zip(a,b)) if x!=y][:15])
 print('PROVIDER_HEADER',old['identity']['donor_objects'].get('readswap.o'),current['identity']['donor_objects'].get('readswap.o'))
 (E/'FROST_BOUNDARY_STATE_CALENDAR04_ORIGINAL_CDE_MONTHLY_DIVDRA_O0.o').write_bytes(a)

