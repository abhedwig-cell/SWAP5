from pathlib import Path
import json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
old=json.loads((E/'FROST_BOUNDARY_STATE_CALENDAR04_STATUS_BEFORE_PARENT524_MERGE_V1.json').read_text())
s=json.loads(subprocess.check_output(['git','show','9936bcda75eb920d67aa74e47018baf39ab18f78:integration/f-ci/nomacro-complete01/STATUS.json'],cwd=R))
s['frost_boundary_state_calendar04']=old['frost_boundary_state_calendar04']
for key in ('next_action','recovery_point'):s[key]=old[key]
s.update(canonical='9936bcda75eb920d67aa74e47018baf39ab18f78',branch='codex/nomacro-frost-boundary-state-calendar04',canonical524_actual_admission=json.loads((P/'FROST_BOUNDARY03_MERGE_RECEIPT_V1.json').read_text()))
if 'frost_boundary03' in s:s['frost_boundary03'].update(canonical_admission=True,actual_merge=s['canonical'],final_current_head_ci='16_SUCCESS_30_SUCCESSFUL_CHECKS_17_SKIPPED',actual_canonical_PUBLIC_and_ordinary_publication='PASS',receipt='FROST_BOUNDARY03_MERGE_RECEIPT_V1.json')
s['frost_boundary_state_calendar04'].update(parent_actual_canonical_admission='COMPLETE524',parent_current_head_applicable_CI='16_SUCCESS',parent_actual_canonical=s['canonical'],local_clock_repair_actual_source='0566877f3d1ef27a472c4fae6f5275e8e76871a4',local_clock_repair_Windows_O0_O2='FULL35_NATIVE_COLD_COMPILED_REFUSALS_AND_TRANSACTIONS_PASS_NOT_ADMITTED')
(P/'STATUS.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf8')
g=json.loads((P/'GAP_MATRIX.json').read_text());g['frost_boundary_state_calendar04'].update(parent_actual_canonical=s['canonical'],parent_actual_canonical_admission='COMPLETE524')
(P/'GAP_MATRIX.json').write_text(json.dumps(g,indent=2)+'\n',encoding='utf8')
print('ACTUAL_PARENT524_STATUS_RECONCILED_WITH_OWN_ACTIVE04_NO_SCIENCE_PROJECTION')

