from pathlib import Path
import json,hashlib
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
raw=(W/'frost-boundary-state-calendar04-input-contract-v3/cases/RESULT.json').read_bytes();r=json.loads(raw)
assert r['source']=='a5ce23a703177dd4e2c90fd0aa9c3eadd9d494b6' and len(r['cases'])==11 and len(r['declines'])==14 and len(r['parent'])==6 and r['compiler_executions']==r['model_executions']==0
name='FROST_BOUNDARY_STATE_CALENDAR04_INPUT_CONTRACT_V2.json';(P/name).write_bytes(raw);(E/name).write_bytes(raw)
q=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text())
q['current_public_reader']=dict(status=r['status'],record=name,sha256=hashlib.sha256(raw).hexdigest(),actual_source=r['source'],recognized_cases=11,actual_hard_refusals=14,old_parent_selections_unchanged=6,compiler_executions=0,model_executions=0)
q['source_scope_guard_delta_after_science']=dict(scientific_source='0fae846dec07fb3b1a317a55b975accbbf110128',actual_narrowed_reader_source=r['source'],only_new_APP_delta="One additional implicit SWKIMPL1/SWHYST2 refusal predicate in new composition's input_domain; no generated numerical source arithmetic changes.",actual_11_accepted_and_14_refused_cases_verified=True,old_03_dense_hysteresis2_implicit_path_retained=True)
(P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
s=json.loads((P/'STATUS.json').read_text());s['frost_boundary_state_calendar04']['current_public_reader']=q['current_public_reader'];s['frost_boundary_state_calendar04']['bottom5_postimage_comparison_issue']=dict(status='EXPLICIT_COMPILED_DIFF_NOT_WAIVED',cause='Original Windows scientific CI compilerRev7 differs from current localRev4; copied source raw CRLF differs but actual LF bodies matched in inspected original CDE sample.',next='Run dedicated CI with original actual compiler identity and exact whole object byte equality. Keep raw and LF hashes separate.')
(P/'STATUS.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf8')
print('CURRENT_NARROWED_READER_11_ACCEPTED_14_REFUSED_6_PARENT_OWNERS_RETAINED')

