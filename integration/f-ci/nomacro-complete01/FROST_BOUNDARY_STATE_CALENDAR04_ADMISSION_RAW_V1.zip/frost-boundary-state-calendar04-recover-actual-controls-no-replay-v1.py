"""Independently recover executed native refusals; run only missing transactions."""
from pathlib import Path
import argparse,hashlib,json,struct,subprocess,sys,zipfile
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_calendar_state_controls import m,transaction
from frost_boundary_state_calendar_input_contract import source
SHA=lambda b:hashlib.sha256(b).hexdigest();COMPILER='3feb51229a980331bc12be2d1d265bef7ae6691a'
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=('O0','O2'),required=True);args=p.parse_args()
base=E.parent/'frost-boundary-state-calendar04-water-smoke-v1'/args.optimization/'water-b5-i0-h0-p1-regular-r0'
out=base/'completed-controls-v2';out.mkdir();profile=base/'science';full=profile/'trajectory';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
head,contract=source();assert not subprocess.check_output(['git','diff',COMPILER,head,'--','app','src','tools','reference'],cwd=R)
science=json.loads((profile/'RESULT.json').read_text());assert science['source']==COMPILER and science['status']=='ACTUAL_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED'
old=json.loads((base/'controls/RESULT.json').read_text());assert old['actual_compiler_source']==COMPILER and old['actual_controller_source']==COMPILER and old['status']=='FAILED_ACTUAL_FROST_CALENDAR_CONTROLS_NOT_QUALIFIED' and len(old['existing_calendar_thermal_refusals'])==39
trace=(base/'controls-controller/controller.stderr').read_bytes();assert b'assert len(checks)==(31 if project.solute else 27)' in trace
producer=subprocess.check_output(['git','show',COMPILER+':tests/nomacro_drainage/frost_calendar_state_extra_native.py'],cwd=R)
assert b"b'S5BCW001',b'S5BCC001',b'S5BCW002',b'S5BCC002'" in producer and b'assert len(checks)==(31 if project.solute else 27)' in producer
build=Path(science['build_root']);project=m.e.load(science['input_root'],original_output=True,time_step_policy='original-adaptive-event-closure-v1');assert not project.solute
meta,_=m.validate_bundle(build,J,project);assert m.sha(build/'BUILD.json')==old['actual_BUILD_sha256']
checkpoint=full/'accepted-column-1-day-4.zip';checkpoint_hash=m.sha(checkpoint)
with zipfile.ZipFile(checkpoint) as archive:
 declaration=json.loads(archive.read('checkpoint.json'));assert declaration['binding']==meta['binding']
 for name,digest in declaration['files'].items():assert SHA(archive.read(name))==digest
 good=archive.read('macro.bin');result_end=archive.read('result.end')
assert good[:8]==b'S5BCW001';expected=struct.pack('<4i',1,project.nodes,0,7);assert good.count(expected+expected)==1;at=good.index(expected+expected)
codecs=(b'S5FCW001',b'S5FCC001',b'S5FCW002',b'S5FCC002',b'S5FDW001',b'S5FDC001',b'S5FIW002',b'S5FIC002',b'S5FBW001',b'S5FBC001',b'S5FBW002',b'S5FBC002',b'S5BCW001',b'S5BCC001',b'S5BCW002',b'S5BCC002')
attacks=[('foreign-codec-'+x.decode(),x) for x in codecs if x!=good[:8]]+ [('snow-domain-'+str(i),i) for i in range(4)]+[('snow-header-witness',None),('snow-missing-block',None)]+[('snow-nan-'+str(i),i) for i in range(7)]+[('snow-negative-'+str(i),i) for i in range(7)]
assert len(attacks)==35 and {p.name for p in (base/'controls/extra-native').iterdir() if p.is_dir()}=={name for name,_ in attacks}
recovered=[]
for label,index in attacks:
 target=base/'controls/extra-native'/label;bad=bytearray(good)
 if label.startswith('foreign-codec-'):bad[:8]=index
 elif label.startswith('snow-domain-'):
  value=struct.unpack_from('<i',bad,at+4*index)[0]+1
  for offset in (at,at+16):struct.pack_into('<i',bad,offset+4*index,value)
 elif label=='snow-header-witness':struct.pack_into('<i',bad,at+16,2)
 elif label=='snow-missing-block':del bad[at:at+88]
 else:struct.pack_into('<d',bad,at+32+8*index,float('nan') if label.startswith('snow-nan-') else -1.)
 assert bytes(bad)!=good and (target/'origin/macro.bin').read_bytes()==bytes(bad)
 assert (target/'origin/result.end').read_bytes()==result_end
 errors=list(target.rglob('donor.stderr'));outputs=list(target.rglob('donor.stdout'));assert errors and outputs
 diagnostic='\n'.join(path.read_text(errors='replace') for path in errors);assert 'ERROR STOP' in diagnostic
 assert not list(target.rglob('accepted-*.zip')) and all('HYBRID_READY' not in path.read_text() and 'HYBRID_DAY_RETURN' not in path.read_text() for path in outputs)
 recovered.append(dict(attack=label,status='ACTUAL_COMPILED_NATIVE_REFUSED',diagnostic=diagnostic,original_raw_directory=str(target),actual_mutant_sha256=SHA(bytes(bad)),actual_original_macro_sha256=SHA(good),raw_files={p.relative_to(target).as_posix():dict(bytes=p.stat().st_size,sha256=SHA(p.read_bytes())) for p in [*errors,*outputs]}))
assert m.sha(checkpoint)==checkpoint_hash
q=dict(old,status='RUNNING_MISSING_REAL_TRANSACTIONS_AFTER_INDEPENDENT_ORIGINAL_REFUSAL_RECOVERY',actual_controller_source=head,actual_external_recovery_controller_sha256=SHA(Path(__file__).read_bytes()),actual_external_recovery_controller=Path(__file__).name,original_failed_report_sha256=SHA((base/'controls/RESULT.json').read_bytes()),original_failed_trace_sha256=SHA(trace),original_controller_git_source=COMPILER,original_extra_native_producer_sha256=SHA(producer),new_snow_private_and_codec_refusals=recovered,full_model_periods_replayed=0,compiled_native_refusal_processes_reexecuted=0,original_failed_report_modified=False)
def save():(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
try:
 data=m.rows(full);assert len(data)==35
 q['snow_transaction']=transaction(build,J,project,full,data,out/'snow-transactions',4,True);save()
 q['frost_calendar_transaction']=transaction(build,J,project,full,data,out/'frost-calendar-transactions',4,False);save()
 assert m.validate_bundle(build,J,project)[0]==meta and m.sha(checkpoint)==checkpoint_hash and source()[0]==head
 q['status']='ACTUAL_FROST_CALENDAR_COMPILED_NATIVE_SNOW_CDE_ROOT_AND_TRANSACTIONS_PASS_NOT_ADMITTED'
except Exception as error:q.update(status='FAILED_ORIGINAL_RAW_RECOVERY_OR_MISSING_TRANSACTIONS_NOT_QUALIFIED',error=repr(error));raise
finally:save()
print(q['status'],args.optimization,len(recovered),q['full_model_periods_replayed'],q['compiled_native_refusal_processes_reexecuted'],flush=True)
