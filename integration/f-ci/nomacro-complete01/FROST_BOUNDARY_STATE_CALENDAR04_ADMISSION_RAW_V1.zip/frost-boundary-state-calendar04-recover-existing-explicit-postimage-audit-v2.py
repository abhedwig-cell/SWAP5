from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P='integration/f-ci/nomacro-complete01/';SHA=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
compiler='a0c418a52fbaaba3d9acbaf0be4f49d96edf94db'
assert not subprocess.check_output(['git','diff',compiler,head,'--','app','src','tools','reference'],cwd=R)
c=json.loads((R/P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text());items=[]
for opt in ('O0','O2'):
 for index in (0,1):
  case=c['representative_cases'][index];name=case['name'];B=W/f'frost-boundary-state-calendar04-bottom5-postimages-{opt}-v1'/name/'bundle';I=W/'frost-boundary-state-calendar04-bottom5-postimages-v1'/opt/name/'inputs';meta=json.loads((B/'BUILD.json').read_text())
  if index==0:mname='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1.json';prefix=f'compiled/{opt}/{name}/bundle/';inputs=f'current/{opt}/{name}/inputs/'
  else:mname=f'FROST_BOUNDARY_STATE_CALENDAR04_WINDOWS_{opt}_ORIGINAL_V1.json';prefix=f'compiled/{name}/bundle/';inputs=f'current/{name}/inputs/'
  anchor='511d207f7ab9c0d543b5edab7aa7ad649c6896ce';raw=subprocess.check_output(['git','show',anchor+':'+P+mname],cwd=R);m=json.loads(raw)
  assert all(SHA(p.read_bytes())==m['members'][inputs+p.relative_to(I).as_posix()]['sha256'] for p in I.rglob('*') if p.is_file())
  sources={};objects={}
  for file,digest in meta['identity']['donor_generated'].items():
   assert SHA((B/file).read_bytes())==digest;sources[file]=dict(current=digest,original=m['members'][prefix+file]['sha256'],exact=digest==m['members'][prefix+file]['sha256'])
   obj=Path(file).with_suffix('.o').as_posix();digest=SHA((B/obj).read_bytes());objects[obj]=dict(current=digest,original=m['members'][prefix+obj]['sha256'],exact=digest==m['members'][prefix+obj]['sha256'])
  items.append(dict(case=name,optimization=opt,actual_compiler_source=compiler,actual_read_only_controller=head,build=str(B),original_manifest=mname,original_manifest_git_anchor=anchor,original_manifest_sha256=SHA(raw),original_archive_sha256=m['sha256'],entire_current_generated_sources_exact=sources,entire_current_compiled_objects_exact=objects,original_inputs_exact=True))
out=dict(status='ACTUAL_GENERATED_SOURCES_EXACT_COMPILED_OBJECT_DIFFERENCES_NOT_WAIVED',contexts=items,compiler_executions=0,model_executions=0,original_failed_controller_metadata_anchor_error_preserved=True,canonical_admission=False)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_WINDOWS_EXPLICIT_BOTTOM5_POSTIMAGES_V2.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['status'],[(x['case'],x['optimization'],[n for n,v in x['entire_current_generated_sources_exact'].items() if not v['exact']],[n for n,v in x['entire_current_compiled_objects_exact'].items() if not v['exact']]) for x in items])

