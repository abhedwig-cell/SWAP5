from pathlib import Path
import zipfile,json
E=Path(__file__).parent;out=[]
for host in ('UBUNTU','WINDOWS'):
 for opt in ('O0','O2'):
  for version in (3,4):
   path=E/f'FROST_BOUNDARY03_{host}_{opt}_ORIGINAL_V{version}.zip'
   with zipfile.ZipFile(path) as z:
    found=[]
    for n in z.namelist():
     if '/science/trajectory/original/' in n and n.lower().endswith('.wrn'):
      lines=[s for s in z.read(n).decode('cp1252',errors='replace').splitlines() if 'no convergence was reached' in s.lower()]
      if lines:found.append(dict(member=n,count=len(lines),first=lines[0]))
    out.append(dict(archive=path.name,warning_files=found))
(E/'FROST_BOUNDARY_STATE_CALENDAR04_PARENT524_CONVERGENCE_WARNING_DISCOVERY_V1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

