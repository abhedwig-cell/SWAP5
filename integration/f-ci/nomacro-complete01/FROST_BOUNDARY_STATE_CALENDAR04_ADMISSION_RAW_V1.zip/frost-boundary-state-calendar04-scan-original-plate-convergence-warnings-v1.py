from pathlib import Path
import json,zipfile
E=Path(__file__).parent;out=[]
paths=[E/f'FROST_BOUNDARY_STATE_CALENDAR04_{h}_{o}_ORIGINAL_V4.zip' for h in ('UBUNTU','WINDOWS') for o in ('O0','O2')]
paths.append(E/'FROST_BOUNDARY_STATE_CALENDAR04_PLATE_CLOCK_LOCAL_WINDOWS_RAW_V1.zip')
for path in paths:
 with zipfile.ZipFile(path) as z:
  findings=[]
  for n in z.namelist():
   if '/science/trajectory/original/' in n and n.lower().endswith(('.log','.err','.stdout','.wrn','.war')):
    lines=[line for line in z.read(n).decode('cp1252',errors='replace').splitlines() if 'no convergence was reached' in line.lower()]
    if lines:findings.append(dict(member=n,count=len(lines),first=lines[0],last=lines[-1]))
  out.append(dict(archive=path.name,original_warning_files=findings))
(E/'FROST_BOUNDARY_STATE_CALENDAR04_PLATE_ORIGINAL_CONVERGENCE_WARNING_SCAN_V1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

