from pathlib import Path
import zipfile,json
E=Path(__file__).parent
for host,case in [('WINDOWS','water-b5-i0-h2-p2-monthly-r1-year-seam'),('UBUNTU','cde-b8-i0-h1-p2-dense-r1')]:
 with zipfile.ZipFile(E/f'FROST_BOUNDARY_STATE_CALENDAR04_{host}_O0_ORIGINAL_V2.zip') as z:
  prefix='current/'+case+'/science/trajectory/'
  for n in z.namelist():
   if n.startswith(prefix) and ('stdout' in n or n.endswith('.end') or n.endswith('.err')) and z.getinfo(n).file_size:
    b=z.read(n).decode(errors='replace');print(n,b[-7000:])
  if host=='UBUNTU':
   rows=[json.loads(t) for t in z.read(prefix+'daily.jsonl').splitlines()];print('REJECTED',json.dumps(rows[-1]))

