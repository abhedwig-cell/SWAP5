from pathlib import Path
import hashlib,json
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
q=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text());cases=q['representative_cases'];plate=[cases[i]['name'] for i in (2,3,7,10)];selections={}
for host in ('ubuntu','windows'):
 path=R/f'.github/workflows/nomacro-frost-boundary-state-calendar04-{host}.yml';text=path.read_text()
 lines=text.splitlines(True);found=0;selected=plate if host=='ubuntu' else [x for x in plate if x!=cases[3]['name']]
 for i,line in enumerate(lines):
  if 'frost_boundary_state_calendar_portable.py --platform ' in line:
   start=line.index(' --case ');end=line.index(' --reference-work ',start);lines[i]=line[:start]+' '+ ' '.join('--case '+x for x in selected)+line[end:];found+=1
 assert found==1;text=''.join(lines);path.write_text(text,encoding='utf8',newline='\n')
 q['original_scientific_workflows'][path.relative_to(R).as_posix()]['sha256']=hashlib.sha256(text.encode()).hexdigest();selections[host]=selected
q['fourth_scientific_epoch']=dict(status='LOCAL_O0_O2_FULL35_NATIVE_COLD_AND_CONTROLS_PASS_AFFECTED_PLATE_CI_PREPARED',source_anchor='060c66cb8343019e9b9f5ef0be07ddd9f61311f4',local_science_source='0566877f3d1ef27a472c4fae6f5275e8e76871a4',local_complete_contexts=2,local_primary_days=70,local_refusals=166,local_transactions=4,workflow_cases=selections,remaining_affected_contexts=14,original_failed_implicit_year_unchanged=True,unchanged_bottom5_full_periods_selected_for_replay=0,unaffected_bottom5_actual_postimage_preservation_gate='PENDING',canonical_admission=False)
q['status']='REAL_PLATE_CLOCK_LOCAL_O0_O2_COMPLETE_AFFECTED14_CI_PREPARED_IMPLICIT_YEAR_NUMERICAL_FAILURE_OPEN'
(P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for name in ('STATUS.json','GAP_MATRIX.json'):
 s=json.loads((P/name).read_text());s['frost_boundary_state_calendar04'].update(status=q['status'],fourth_epoch=q['fourth_scientific_epoch'])
 if name=='STATUS.json':
  s['last_commit']='0566877f3d1ef27a472c4fae6f5275e8e76871a4'
  s['next_action']='Push genuine current integrated source to SCIref for remaining14affectedplate contexts; poll until terminal and preserve actual original artifacts. Establish real unchanged bottom5 emitted-postimage preservation before inheriting28periods. Investigate implicit5 hysteresis2 year-seam day5 clock-resolution failure or retain coherent hard exclusion. Implement independent04 source/raw/parent524 owner and final current/canonical gates after scientific scope is established.'
  s['recovery_point']='Canonical9936bcda75 actual524 all final gates+receipt/raw sealed. Current newAPP matches actual local056 compiler/science. Real public plate regular O0/O2 now complete full35+14native+6cold+166refusals+4transactions. Earlier day22/day25/implicitday5 failures and before-model implementation failures remain preserved. Source workflow now selects affected plate contexts only; no prior bottom5 full-period replay.'
 (P/name).write_text(json.dumps(s,indent=2)+'\n',encoding='utf8')
print('FOURTH_REAL_SCIENCE_SELECTION',selections)

