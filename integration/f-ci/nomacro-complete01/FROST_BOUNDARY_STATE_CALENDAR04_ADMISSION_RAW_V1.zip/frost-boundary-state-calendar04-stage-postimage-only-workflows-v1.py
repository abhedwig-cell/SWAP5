from pathlib import Path
import json,hashlib
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';workflows={}
for host in ('ubuntu','windows'):
 old=f'nomacro-frost-boundary-state-calendar04-{host}.yml';new=f'nomacro-frost-boundary-state-calendar04-postimages-{host}.yml';p=R/'.github/workflows'/old;text=p.read_text()
 text=text.replace('Original Frost boundary state/calendar '+('Ubuntu' if host=='ubuntu' else 'Windows')+' full35 and native state','Unchanged Frost bottom5 actual compiled postimages '+host)
 text=text.replace(old,new).replace('group: nomacro-frost-boundary-state-calendar04-'+host+'-','group: nomacro-frost-boundary-state-calendar04-postimages-'+host+'-')
 lines=text.splitlines(True);found=0
 for i,line in enumerate(lines):
  if 'frost_boundary_state_calendar_portable.py --platform ' in line:
   platform='Windows' if host=='windows' else 'Ubuntu';command='python' if host=='windows' else 'python3'
   selected='' if host=='ubuntu' else ' --case cde-b5-i0-h1-p2-monthly-r1 --case water-b5-i1-h1-p1-monthly-r1 --case cde-b5-i1-h0-p2-dates-r1'
   lines[i]='          '+command+' -B tests/nomacro_drainage/frost_boundary_state_calendar_bottom5_postimages.py --platform '+platform+selected+' --reference-work "$RUNNER_TEMP/provider" --build-root "$RUNNER_TEMP/builds" --output "$RUNNER_TEMP/proof/current" --optimization '+"""'"""+"${{ matrix.optimization }}"+"""'"""+'\n';found+=1
 assert found==1;text=''.join(lines).replace('Run selected original boundary state/calendar periods and actual compiled controls','Build unchanged bottom5 postimages with zero model executions').replace('name: frost-boundary-state-calendar04-','name: frost-boundary-state-calendar04-postimages-')
 path=R/'.github/workflows'/new;path.write_text(text,encoding='utf8',newline='\n');workflows[path.relative_to(R).as_posix()]=dict(sha256=hashlib.sha256(text.encode()).hexdigest(),model_executions=0)
q=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text());q['bottom5_postimage_workflows']=workflows
q['fourth_scientific_epoch'].update(status='ALL_FOUR_REAL_CI_JOBS_PASS_ORIGINAL_RAW_ALL_BYTES_PRESERVED',actual_source='0fae846dec07fb3b1a317a55b975accbbf110128',Ubuntu_run=45671144167,Windows_run=45671144337,completed_CI_contexts=14,completed_total_plate_contexts=16,primary_plate_days_with_local=468)
q['status']='ELEVEN_CASE44_CANDIDATE_SCIENCE_COMPLETE_POSTIMAGE_AND_INDEPENDENT_ADMISSION_PENDING_KNOWN_IMPLICIT_HYS2_HARD_CLOSED'
(P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for name in ('STATUS.json','GAP_MATRIX.json'):
 s=json.loads((P/name).read_text());s['frost_boundary_state_calendar04'].update(status=q['status'],fourth_epoch=q['fourth_scientific_epoch'],known_implicit_hys2_failure=q['blocked_new_implicit_hysteresis2_calendar_domain'],bottom5_postimage_workflows=workflows,proposed_contexts=44,canonical_admission=False)
 if name=='STATUS.json':s['next_action']='Run actual narrowed reader and known-numerical hard refusal. Push dedicated bottom5 postimage workflows (own paths only, no full-period replay) for same original compiler identities and strict whole object hashes; retain raw/LF identities separately. Independently audit all44 scientific contexts and raw/source/parent524 custody; implement04 owner, final public/ordinary publication/four real negatives/current CI/canonical gates. Reopen implicit hys2 calendars only after its genuine day5 clock-resolution cause is solved and qualified.'
 (P/name).write_text(json.dumps(s,indent=2)+'\n',encoding='utf8')
print('DEDICATED_ZERO_MODEL_COMPILED_POSTIMAGE_WORKFLOWS_STAGED',list(workflows))

