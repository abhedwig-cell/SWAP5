from pathlib import Path
import json,hashlib,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).parent
q=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').read_text())
names=[c['name'] for c in q['representative_cases']]
for host in ('ubuntu','windows'):
 path=R/f'.github/workflows/nomacro-frost-boundary-state-calendar04-{host}.yml'
 text=path.read_text();before='--exclude-case water-b5-i0-h0-p1-regular-r0 --exclude-case cde-b5-i0-h1-p2-monthly-r1 --exclude-case water-b8-i0-h1-p1-dates-r1 --exclude-case cde-b8-i0-h0-p2-regular-r1'
 after=' '.join('--case '+x for x in names[(8 if host=='ubuntu' else 9):])
 assert text.count(before)==1;text=text.replace(before,after)
 path.write_text(text,encoding='utf8',newline='\n')
 q['original_scientific_workflows'][path.relative_to(R).as_posix()]['sha256']=hashlib.sha256(text.encode()).hexdigest()
q['status']='TWENTYEIGHT_COMPLETE_CONTEXTS_RETAINED_KNOWN_DAY22_DAY25_NUMERICAL_FAILURES_OPEN_YEAR_INPUT_TEMPLATE_CORRECTED'
q['second_scientific_epoch']['status']='FAILED_ORIGINALS_PRESERVED'
q['second_scientific_epoch']['diagnostic']='FROST_BOUNDARY_STATE_CALENDAR04_SECOND_ORIGINALS_DIAGNOSTIC_V2.json'
q['third_scientific_epoch']=dict(status='PREPARED_MISSING_CASES_ONLY',Ubuntu_cases=names[8:],Windows_cases=names[9:],prior_completed_periods_replayed=0,APP_src_tools_reference_unchanged=True,changed_controller='tests/nomacro_drainage/frost_boundary_state_calendar_inputs.py',input_fix='Shift genuine varying DATE5 table by same start-date offset already applied to IRDATE; values/order preserved.',previous_failed_year_case='INVALID_TEST_TEMPLATE_ORIGINAL_READER_REFUSAL',numerical_day22_day25_failure_waived=False)
(P/'FROST_BOUNDARY_STATE_CALENDAR04_CONTRACT_V1.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for filename in ('STATUS.json','GAP_MATRIX.json'):
 x=json.loads((P/filename).read_text());section=x['frost_boundary_state_calendar04'];section.update(status=q['status'],second_epoch=q['second_scientific_epoch'],third_epoch=q['third_scientific_epoch'],completed_full_period_contexts=28,canonical_admission=False)
 if filename=='STATUS.json':
  x['next_action']='Run third genuine scientific epoch only for missing cases after actual input contract; continue current candidate2e9 PR1802 three pending CI gates, collect final original CI logs then actual merge/canonical observers. Investigate day22/day25 actual daily elapsed-time mismatch; no tolerance/flux/inventory correction.'
  x['recovery_point']='Original second-epoch source838 four ZIPs all bytes/member SHA verified, centrally split.16additional full35 periods, total28; known4day22 +2Ubuntu day25 failures;2Windows year cases invalid original DATE5 template corrected,12unexecuted contexts. No family closure or actual canonical admission claimed.'
 (P/filename).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
print('ACTUAL_MISSING_CASE_SELECTION_AND_YEAR_BOUNDARY_TABLE_FIX_RECORDED')

