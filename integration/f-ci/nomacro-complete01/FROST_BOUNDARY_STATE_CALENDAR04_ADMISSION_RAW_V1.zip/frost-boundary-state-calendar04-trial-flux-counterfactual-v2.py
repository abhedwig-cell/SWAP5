"""Diagnostic only: supply actual Richards trial flux to the existing receipt."""
from pathlib import Path
import contextlib,hashlib,json,shutil,subprocess,sys,time,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
root=W/'frost-boundary-state-calendar04-dayclock-causal-v1'
D=root/'trial-flux-counterfactual-v2';D.mkdir()
J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider/build')
B=W/'frost-boundary-state-calendar04-plate-clock-O0-v3/cde-b8-i0-h0-p2-regular-r1/bundle'
SHA=lambda b:hashlib.sha256(b).hexdigest()
trace=D/'bundle';shutil.copytree(B,trace);meta=json.loads((B/'BUILD.json').read_text())
for n,d in meta['identity']['donor_objects'].items():assert SHA((J/'swap-obj'/n).read_bytes())==d
assert SHA((J/'ttutil-obj/libttutil.a').read_bytes())==meta['identity']['ttutil_library']
inputs=D/'inputs';shutil.copytree(root/'headcalc-guard-observation-v2/inputs',inputs)
for n,d in meta['inputs'].items():assert SHA((inputs/n).read_bytes())==d
def edit(path,changes):
 s=path.read_text(encoding='cp1252')
 for a,b in changes:
  assert s.count(a)==1,(path,a,s.count(a));s=s.replace(a,b)
 path.write_text(s,encoding='cp1252')
edit(trace/'terminal_water_receipt.f90',[
 ('  public :: terminal_water_terms, terminal_water_residual','  public :: terminal_water_terms, terminal_water_residual, terminal_water_trial_residual'),
 ('  subroutine terminal_water_terms(terms)','  subroutine terminal_water_trial_terms(terms,candidate_bottom_cm_d)'),
 ('    real(8), intent(out) :: terms(28)','    real(8), intent(in) :: candidate_bottom_cm_d\n    real(8), intent(out) :: terms(28)'),
 ('    qbotts=qbot*dt','    qbotts=candidate_bottom_cm_d*dt'),
 ('  real(8) function terminal_water_residual() result(residual)',
  '''  subroutine terminal_water_terms(terms)
    use variables, only: qbot
    real(8),intent(out)::terms(28)
    call terminal_water_trial_terms(terms,qbot)
  end subroutine

  real(8) function terminal_water_trial_residual(candidate_bottom_cm_d) result(residual)
    real(8),intent(in)::candidate_bottom_cm_d
    real(8)::terms(28)
    call terminal_water_trial_terms(terms,candidate_bottom_cm_d)
    residual=real(sum(real(terms,real128)),8)
  end function

  real(8) function terminal_water_residual() result(residual)''')])
edit(trace/'headcalc.f90',[
 ('   use hybrid_terminal_water_receipt, only: terminal_water_residual','   use hybrid_terminal_water_receipt, only: terminal_water_trial_residual'),
 ('            if(abs(terminal_water_residual())>1d-10)flnonconv=.true.',
 '''            if(flboth)then
               if(abs(terminal_water_trial_residual(-kmean(NN+1)*hgrad(NN+1)))>1d-10)flnonconv=.true.
            else
               if(abs(terminal_water_trial_residual(0d0))>1d-10)flnonconv=.true.
            end if''')])
# Restore the actual qualified original clock, not the later two-edit repair.
original_time=(root/'original-bundle/timecontrol.f90').read_bytes().replace(b'\r\n',b'\n')
assert SHA(original_time)=='14403e7f9b0a9434388b62fb00c4ef672ac004f7d54ab3c8fbbb8fdd5364b472'
(trace/'timecontrol.f90').write_bytes(original_time)
commands=[]
def run(cmd):
 commands.append(cmd);p=subprocess.run(cmd,cwd=trace,capture_output=True)
 (D/f'compiler-{len(commands)}.stdout').write_bytes(p.stdout);(D/f'compiler-{len(commands)}.stderr').write_bytes(p.stderr);p.check_returncode()
for n in ['terminal_water_receipt','headcalc','timecontrol']:
 run(['gfortran',*meta['identity']['donor_flags'],'-I',str(J/'swap-obj'),'-I',str(J/'ttutil-obj'),'-c',n+'.f90'])
objects={p.name:p for p in (J/'swap-obj').glob('*.o')};objects.update({p.name:p for p in trace.glob('*.o')})
exe=trace/'day_donor_trial_flux_counterfactual.exe'
run(['gfortran','-o',str(exe),*[str(objects[n]) for n in sorted(objects)],str(J/'ttutil-obj/libttutil.a')])
sys.path.insert(0,str(R/'app/hybrid_water'));import daily_host as h,experimental_project as e
project=e.load(inputs,original_output=True,time_step_policy='original-adaptive-event-closure-v1')
out=D/'actual-run';out.mkdir();started=time.perf_counter();rows=[];failure=None
try:
 with contextlib.ExitStack() as stack:
  host=h.DailyHost(stack,exe,h.executable(B,'day_kernel'),inputs,out,[h.ColumnStart('original',0,None,None)],checkpoint_enabled=False,runtime=True,binding=None,model=project.model,project=project)
  for day in range(1,36):
   row=host.step(1);rows.append(row)
   with (out/'daily.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print('ACTUAL_DIAGNOSTIC_DAY',day,'kernel_residual_cm',row['kernel_residual_cm'],flush=True)
  host.close()
except Exception as exc:failure=repr(exc)
warnings=[]
for p in out.rglob('*'):
 if p.is_file() and p.suffix.lower() in {'.log','.err','.stdout','.wrn','.war'}:
  for line in p.read_text(errors='replace').splitlines():
   if 'No convergence was reached' in line:warnings.append({'file':str(p.relative_to(out)),'line':line})
report=dict(status='DIAGNOSTIC_ONLY_NOT_QUALIFIED',source_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),original_build_source='0566877f3d1ef27a472c4fae6f5275e8e76871a4',accepted_days=len(rows),failure=failure,convergence_warnings=warnings,original_timecontrol_sha256=SHA(original_time),commands=commands,seconds=time.perf_counter()-started,changed_sources={n:SHA((trace/n).read_bytes()) for n in ['terminal_water_receipt.f90','headcalc.f90','timecontrol.f90']},checkpoint_publication='NOT_SELECTED_DIAGNOSTIC',equations_or_tolerances_changed=False)
(D/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'commands','changed_sources','convergence_warnings'}},indent=2),flush=True)
print('CONVERGENCE_WARNING_COUNT',len(warnings),flush=True)
