from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
name='FROST_BOUNDARY_STATE_CALENDAR04_ACTUAL_CLOCK_DIAGNOSTIC_AND_READERS_RAW_V1';m=json.loads((P/(name+'.json')).read_text())
raw=b''.join(subprocess.check_output(['git','show','7cc40bfedbf5838adc57f53058fb2027618b41ba:integration/f-ci/nomacro-complete01/'+x['file']],cwd=R) for x in m['parts']);assert SHA(raw)==m['sha256']
for key,item in m['physical_inventory'].items():assert SHA((W/key).read_bytes())==item['sha256']
for root in ('frost-boundary-state-calendar04-input-contract-v1','frost-boundary-state-calendar04-input-contract-v2'):
 actual={root+'/'+p.relative_to(W/root).as_posix() for p in (W/root).rglob('*') if p.is_file()};assert actual=={k for k in m['physical_inventory'] if k.startswith(root+'/')}
print('READER_AND_DIAGNOSTIC_CURRENT_BYTES_MATCH_GIT_ARCHIVE',len(m['physical_inventory']))

