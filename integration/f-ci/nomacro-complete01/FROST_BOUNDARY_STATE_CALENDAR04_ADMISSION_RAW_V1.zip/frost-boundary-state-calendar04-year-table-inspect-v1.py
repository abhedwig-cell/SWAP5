from pathlib import Path
import zipfile,re
E=Path(__file__).parent
with zipfile.ZipFile(E/'FROST_BOUNDARY_STATE_CALENDAR04_WINDOWS_O0_ORIGINAL_V2.zip') as z:
 n='current/water-b5-i0-h2-p2-monthly-r1-year-seam/inputs/swap.swp'
 text=z.read(n).decode('cp1252')
 lines=text.splitlines();start=next(i for i,line in enumerate(lines) if line.strip().startswith('DATE5'));print('\n'.join(lines[start:start+8]))

