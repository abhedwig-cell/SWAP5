from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
name='FROST_BOUNDARY_STATE_CALENDAR04_CURRENT_LOCAL_POSTIMAGE_RAW_V4';roots=['frost-boundary-state-calendar04-current-local-water-postimage-v4']+['frost-boundary-state-calendar04-current-water-postimage-'+o+'-v4' for o in ['O0','O2']];members={};inventory=[];source='85916d054cc0da21baa054ac3a50d40950be49ad'
tar=E/('FROST_BOUNDARY_STATE_CALENDAR04_CURRENT_LOCAL_POSTIMAGE_ACTUAL_SOURCE_'+source+'.tar');assert not tar.exists();subprocess.run(['git','archive','--format=tar','--output='+str(tar),source,'--','app','src','tools','tests','.github'],cwd=R,check=True)
with zipfile.ZipFile(E/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def add(key,raw):z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
 for root in roots:
  inventory.append(dict(original_path=str(W/root),archive_prefix=root))
  for p in sorted((W/root).rglob('*')):
   assert not p.is_symlink()
   if p.is_file():add(root+'/'+p.relative_to(W/root).as_posix(),p.read_bytes())
 add('sources/'+tar.name,tar.read_bytes());add('sources/actual-compiler-commit-'+source+'.bin',subprocess.check_output(['git','cat-file','commit',source],cwd=R))
 for n in ['frost-boundary-state-calendar04-preserve-local-postimage-v4.py','frost-boundary-state-calendar04-recover-current-built-water-postimages-v4.py','FROST_BOUNDARY_STATE_CALENDAR04_CURRENT_BUILT_WATER_POSTIMAGES_V4.json']:add('controllers/'+n,(E/n).read_bytes())
with zipfile.ZipFile(E/(name+'.zip')) as z:
 for n,item in members.items():b=z.read(n);assert len(b)==item['bytes'] and SHA(b)==item['sha256']
raw=(E/(name+'.zip')).read_bytes();assert len(raw)<25*1024*1024;(P/(name+'.zip')).write_bytes(raw);assert (P/(name+'.zip')).read_bytes()==raw
q=dict(status='CURRENT_LOCAL_COMPILED_POSTIMAGES_AND_ORIGINAL_READ_ONLY_GUARD_FAILURE_ALL_BYTES_PRESERVED_ZERO_MODELS',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,physical_inventory=inventory,actual_compiler_source=source,canonical_admission=False)
for root in [E,P]:(root/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],len(raw),len(members),flush=True)
