from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
baseline=json.loads((P/'FROST_BOUNDARY_STATE_CALENDAR04_BOTTOM5_PHYSICAL_POSTIMAGE_BASELINES_V1.json').read_text());out=[];name='water-b5-i0-h0-p1-regular-r0'
dispatch=b'    from frost_boundary_terminal_trial import apply_build as plate_terminal_build\n    patched=plate_terminal_build(output,project,patched)\n'
for opt in ['O0','O2']:
 folder=W/'frost-boundary-state-calendar04-current-local-water-postimage-v4'/opt;prior=json.loads((folder/'RESULT.json').read_text());assert prior['status']=='FAILED_ACTUAL_BOTTOM5_POSTIMAGE_PRESERVATION_NOT_ADMITTED' and len(prior['contexts'])==1
 item=prior['contexts'][0];assert item['returncode']==0 and item['model_executions']==0
 B=W/f'frost-boundary-state-calendar04-current-water-postimage-{opt}-v4'/name/'bundle';meta=json.loads((B/'BUILD.json').read_text());b=baseline['records']['WINDOWS/'+opt+'/'+name]
 current=subprocess.check_output(['git','show',prior['source']+':app/hybrid_water/daily_host.py'],cwd=R);assert current.count(dispatch)==1
 old='3feb51229a980331bc12be2d1d265bef7ae6691a';assert current.replace(dispatch,b'',1)==subprocess.check_output(['git','show',old+':app/hybrid_water/daily_host.py'],cwd=R)
 assert not subprocess.check_output(['git','diff',old,prior['source'],'--','src','tools','reference','app/hybrid_water/implicit_frost_root_state.py','app/hybrid_water/donor_sources.py'],cwd=R)
 assert {k:meta['identity'][k] for k in b['compiler']}==b['compiler']
 sources={};objects={}
 for file,witness in b['generated'].items():
  raw=(B/file).read_bytes();assert SHA(raw)==meta['identity']['donor_generated'][file] and SHA(raw.replace(b'\r\n',b'\n'))==witness['original_LF_sha256']
  object_file=witness['object_file'];raw_object=(B/object_file).read_bytes();assert SHA(raw_object)==witness['original_object_sha256']
  sources[file]=dict(actual_raw_sha256=SHA(raw),actual_LF_sha256=SHA(raw.replace(b'\r\n',b'\n')),original_LF_sha256=witness['original_LF_sha256']);objects[object_file]=dict(actual_sha256=SHA(raw_object),original_sha256=witness['original_object_sha256'])
 out.append(dict(optimization=opt,actual_original_compiler_source=prior['source'],actual_BUILD_sha256=SHA((B/'BUILD.json').read_bytes()),original_failure_retained=True,exact_literal_original_host_inverse=True,whole_generated_sources=sources,whole_compiled_objects=objects,model_executions=0,recompilations=0))
q=dict(status='TWO_ALREADY_COMPILED_CURRENT_BOTTOM5_CONTEXTS_EXACT_WHOLE_PHYSICAL_POSTIMAGES_SAME_COMPILER_NO_RECOMPILE_NO_MODELS',contexts=out,actual_compiled_object_comparisons=sum(len(x['whole_compiled_objects']) for x in out),model_executions=0,compiler_executions=0,canonical_admission=False)
(E/'FROST_BOUNDARY_STATE_CALENDAR04_CURRENT_BUILT_WATER_POSTIMAGES_V4.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],q['actual_compiled_object_comparisons'],flush=True)
