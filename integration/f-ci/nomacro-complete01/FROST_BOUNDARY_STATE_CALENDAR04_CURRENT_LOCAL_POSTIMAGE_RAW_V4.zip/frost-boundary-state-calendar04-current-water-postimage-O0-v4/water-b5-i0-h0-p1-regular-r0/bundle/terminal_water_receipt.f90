module hybrid_terminal_water_receipt
  use iso_fortran_env, only: real128
  implicit none
  private
  public :: terminal_water_terms, terminal_water_residual
contains
  subroutine terminal_water_terms(terms)
    ! Project the native double ledger exported after original Integral(3).
    ! This is a trial-only receipt: no assignment to original physical state.
    use MOD_grid, only: numnod, dz
    use MOD_swap_base, only: swmacro, swsnow, swdra
    use hybrid_age_output_state, only: hybrid_output_frame
    use MOD_meteo, only: graidt,nraidt,aintcdt
    use MOD_irrigation, only: gird,qssdi
    use MOD_snow, only: gsnow,snrai,subl,ssnow
    use MOD_drain, only: qdrtot
    use MOD_re_global, only: qrosum
    use plant_interface, only: sw_inter,sicact,siccap,crsflx_in,crsflx_out
    use variables, only: theta,pond,dt,runon,runots,qbot,epd,reva
    real(8), intent(out) :: terms(28)
    real(8) :: ssdi,interception,canopy,qbotts
    integer :: node
    if(swmacro/=0.or.swsnow/=1.or.swdra/=1)error stop 'Unsupported terminal water receipt domain'
    if(.not.hybrid_output_frame%active)error stop 'Missing actual original day receipt for Frost terminal trial'
    ssdi=hybrid_output_frame%flow_cm(6)
    do node=1,numnod
      ssdi=ssdi+qssdi(node)*dt
    end do
    qbotts=qbot*dt
    interception=hybrid_output_frame%flow_cm(8)+aintcdt*dt
    if(sw_inter==3)interception=hybrid_output_frame%flow_cm(8)+crsflx_out*dt
    canopy=min(max(0d0,sicact+(crsflx_in-crsflx_out)*dt),siccap)
    terms(1:7)=[hybrid_output_frame%flow_cm(1)+graidt*dt,hybrid_output_frame%flow_cm(2)+snrai*dt,hybrid_output_frame%flow_cm(3)+gsnow*dt, &
      hybrid_output_frame%flow_cm(4)+gird*dt,hybrid_output_frame%flow_cm(5)+runon*dt,ssdi,hybrid_output_frame%flow_cm(7)+max(0d0,qbotts)]
    terms(8:16)=-[interception,hybrid_output_frame%flow_cm(9)+runots,hybrid_output_frame%flow_cm(10)+qrosum*dt,hybrid_output_frame%flow_cm(11)+epd*dt, &
      hybrid_output_frame%flow_cm(12)+reva*dt,hybrid_output_frame%flow_cm(13)+subl*dt,hybrid_output_frame%flow_cm(14)+qdrtot*dt,0d0,hybrid_output_frame%flow_cm(16)-min(0d0,qbotts)]
    terms(17:22)=[hybrid_output_frame%start_stock_cm(1),hybrid_output_frame%start_stock_cm(2),hybrid_output_frame%start_stock_cm(3),hybrid_output_frame%start_stock_cm(4),0d0,0d0]
    terms(23:28)=-[sum(theta(1:numnod)*dz(1:numnod)),pond,ssnow,canopy,0d0,0d0]
  end subroutine

  real(8) function terminal_water_residual() result(residual)
    real(8) :: terms(28)
    call terminal_water_terms(terms)
    ! Original double operations above remain separate. Extended precision only
    ! sums their exported values, independently of the hydraulic step sum.
    residual=real(sum(real(terms,real128)),8)
  end function
end module
