* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-25 17:38:10

Period             :  2002-12-28  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        79.55 cm
Initial :        92.60 cm
            =============
Change          -13.06 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :     5.26    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :   -25.28    Soil evaporation  :     0.02
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :   -17.62    Sum               :     0.02
