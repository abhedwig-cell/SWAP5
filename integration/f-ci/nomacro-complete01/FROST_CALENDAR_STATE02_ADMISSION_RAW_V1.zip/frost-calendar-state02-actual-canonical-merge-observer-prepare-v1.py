"""Advance actual protected canonical observer and restore only named dependencies."""
import argparse,hashlib,json,subprocess
from pathlib import Path
C=Path('C:/Users/Veldh012/swap5-implicit-conductivity-canonical01');E=Path(__file__).parent
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=C).decode().strip()
def main():
 p=argparse.ArgumentParser();p.add_argument('--actual-merge',required=True);p.add_argument('--candidate',required=True);a=p.parse_args();baseline=json.loads((E/'FROST_CALENDAR_STATE02_CANONICAL_DEPENDENCIES_BEFORE_PR1801_V1.json').read_text());assert git('rev-parse','HEAD')==baseline['actual_canonical'] and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
 sparse=Path(git('rev-parse','--git-path','info/sparse-checkout'));sparse=sparse if sparse.is_absolute() else C/sparse;patterns=sparse.read_bytes();assert len(patterns.splitlines())==14
 fixtures=lambda:{p.relative_to(C).as_posix():SHA(p) for p in (C/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()};inputs=fixtures();assert len(inputs)==56
 assert git('rev-parse',a.actual_merge+'^{tree}')==git('rev-parse',a.candidate+'^{tree}')
 assert git('show','-s','--format=%P',a.actual_merge).split()==[baseline['actual_canonical'],a.candidate]
 for path,digest in baseline['existing_materialized_archive_hashes'].items():assert SHA(C/path)==digest
 subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','switch','--detach',a.actual_merge],cwd=C,check=True,capture_output=True)
 paths=dict(baseline['existing_materialized_archive_hashes'])
 for name in baseline['new_required_archive_names']:
  q=json.loads((C/'integration/f-ci/nomacro-complete01'/(name+'.json')).read_text())
  for item in q['parts']:
   path='integration/f-ci/nomacro-complete01/'+item['file'];assert path not in paths or paths[path]==item['sha256'];paths[path]=item['sha256']
 missing=[path for path in paths if not (C/path).is_file()]
 for start in range(0,len(missing),20):subprocess.run(['git','restore','--source='+a.actual_merge,'--worktree','--ignore-skip-worktree-bits','--',*missing[start:start+20]],cwd=C,check=True,capture_output=True)
 for path,digest in paths.items():assert SHA(C/path)==digest
 assert sparse.read_bytes()==patterns and fixtures()==inputs and not git('status','--porcelain=v1','--untracked-files=all','--ignored') and git('rev-parse','HEAD')==a.actual_merge
 q=dict(status='ACTUAL_CANONICAL_PR1801_SOURCE_TREE_AND_NAMED_ARCHIVE_DEPENDENCIES_READY_CLEAN14',actual_merge=a.actual_merge,qualified_candidate=a.candidate,actual_checkout=str(C),before=baseline['actual_canonical'],whole_tree=git('rev-parse','HEAD^{tree}'),restored_explicit_paths=missing,archive_hashes=paths,original_project_files=inputs,sparse_patterns_unchanged=14,compiler_executions=0,model_executions=0)
 out=E/'FROST_CALENDAR_STATE02_EXACT_MERGE_OBSERVER_DEPENDENCIES_V1.json';assert not out.exists();out.write_text(json.dumps(q,indent=2)+'\n');print(q['status'],len(paths),flush=True)
if __name__=='__main__':main()
