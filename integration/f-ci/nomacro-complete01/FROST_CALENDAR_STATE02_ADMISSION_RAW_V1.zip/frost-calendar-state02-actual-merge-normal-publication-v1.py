"""Observe the genuine canonical merge with ordinary Python defaults."""
from pathlib import Path
import runpy
E = Path(__file__).resolve().parent
source = E/'frost-calendar-state02-candidate-normal-python-publication-observe-v3.py'
raw = source.read_text()
old = "output=E/'FROST_CALENDAR_STATE02_CANDIDATE_PUBLICATION_V3'"
assert raw.count(old) == 1
# This changes only the external controller's output name, never model/source bytes.
code = raw.replace(old, "output=E/'FROST_CALENDAR_STATE02_ACTUAL_MERGE_PUBLICATION_V1'")
exec(compile(code, str(source), 'exec'), {'__file__': str(source), '__name__': '__main__'})
