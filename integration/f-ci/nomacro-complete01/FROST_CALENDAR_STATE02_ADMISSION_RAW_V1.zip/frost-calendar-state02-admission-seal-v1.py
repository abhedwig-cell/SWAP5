"""Preserve genuine admission only after exact final-head and canonical gates."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
E=Path(__file__).resolve().parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
P=R/'integration/f-ci/nomacro-complete01'
candidate='3250f0c59337334994b0e8edda624afe8f91b11f'
parent='8dbe3db7c7832dd6a1f86c4275cd43f054552df3'
synthetic='ecd8ad97ca5a6e19239ebd06fe0547711cf3ec68'
anchor='38d01129d73e9128c93e10d61153970676a2fcf7'
tree='d20d8d776c52b1e5a6b95d500b5547f78a519f6b'
SHA=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((E/n).read_text())
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
api=read('FROST_CALENDAR_STATE02_PR1801_ACTUAL_GIT_API_V1.json')
actual=api['sha']
assert api['tree']['sha']==tree and [p['sha'] for p in api['parents']]==[parent,candidate]
for head in (candidate,synthetic,actual):
 assert git('rev-parse',head+'^{tree}')==tree
for head in (synthetic,actual):
 raw=(E/('FROST_CALENDAR_STATE02_PR1801_GENUINE_GIT_OBJECT_'+head+'.bin')).read_bytes()
 assert raw==subprocess.check_output(['git','cat-file','commit',head],cwd=R)
 assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==head
expected=dict(contexts=500,short35_contexts=486,year367_contexts=2,
 new_short_calendar_contexts=12,new_frost_calendar_state_contexts=28,
 native_calendar_samples=3450,exact_cold_windows=1484,compiled_initialization_postimages=375,
 current_unselected_dense_compiled_postimages=4,previous_canonical=parent)
observations={}
inputs=None
for role,version,head in [('CANDIDATE','V3',candidate),('ACTUAL_MERGE','V1',actual)]:
 for scope in ('PUBLIC','PUBLICATION'):
  label=f'FROST_CALENDAR_STATE02_{role}_{scope}_{version}'
  q=read(label+'.json');raw=(E/(label+'.stdout.txt')).read_bytes()
  assert q['returncode']==0 and q['before']==q['after']
  before=q['before'];assert before['head']==head and before['tree']==tree and not before['status']
  assert len(before['sparse'])==14 and len(before['original_project_files'])==56
  assert not (E/(label+'.stderr.txt')).read_bytes()
  if inputs is None:inputs=before['original_project_files']
  assert inputs==before['original_project_files']
  if scope=='PUBLIC':assert json.loads(raw)['coadmission']==expected
  else:
   assert b'PUBLICATION_REPLAY_SELECTED=false' in raw
   assert q['ordinary_python_default_dont_write_bytecode'] is False
   assert q['child_bytecode_environment_variables_absent']
  observations[label]=q['seconds']
negative=read('FROST_CALENDAR_STATE02_BOTHCI_FINAL_NEGATIVES_V1.json')
assert negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
assert negative['candidate']==candidate and len(negative['controls'])==4
assert {q['role'] for q in negative['controls']}=={'SOURCE','RAW','INHERITED','PUBLICATION'}
for q in negative['controls']:
 assert q['actual_refusal'] and q['actual_one_file_delta'] and q['exact_parent']==candidate
 assert git('show','-s','--format=%P',q['head'])==candidate
 assert git('diff','--name-only',candidate,q['head'])==q['path']
ci=read('FROST_CALENDAR_STATE02_PR1801_FINAL_ALL_CI_API_V1.json')
runs=ci['runs']['workflow_runs'];checks=ci['checks']['check_runs']
assert len(runs)==17 and len({x['workflow_id'] for x in runs})==17
assert all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion']=='success' for x in runs)
assert len(checks)==ci['checks']['total_count']
assert all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion'] in ('success','skipped') for x in checks)
for role in ('CO2','DVS','LRV','TIMEINT_STARTUP','TIMEINT_INVERSE','FCI_MODULAR','MCSOL_SWP','MCSOL_COLUMN'):
 label=f'FROST_CALENDAR_STATE02_PR1801_{role}_ORIGINAL_CI_V1.log'
 q=read(label+'.json');raw=(E/label).read_bytes()
 assert len(raw)==q['bytes'] and SHA(raw)==q['sha256']
 assert q['actual_candidate']==candidate and q['actual_synthetic']==synthetic
 assert candidate.encode() in raw and synthetic.encode() in raw
name='FROST_CALENDAR_STATE02_ADMISSION_RAW_V1';members={}
# Science archives are already committed once, with exact byte manifests. Preserve
# the original observer/CI/failure records and actual controllers here, not copies
# of those large scientific ZIPs.
paths=[p for p in E.iterdir() if p.is_file() and p.name.startswith('FROST_CALENDAR_STATE02_')
       and p.suffix in ('.json','.txt','.log','.bin')]
paths += [p for p in E.iterdir() if p.is_file() and p.name.startswith('frost-calendar-state02-') and p.suffix=='.py']
with zipfile.ZipFile(P/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):
  raw=p.read_bytes();assert p.name not in members
  z.writestr(p.name,raw);members[p.name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(P/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,item in members.items():
  raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=(P/(name+'.zip')).read_bytes();digest=SHA(raw)
manifest=dict(status='ACTUAL_CANONICAL500_ORIGINAL_PUBLIC_ORDINARY_PUB_CI_NEGATIVES_AND_SIGNED_OBJECTS_PRESERVED',
 archive=name+'.zip',bytes=len(raw),sha256=digest,
 parts=[dict(file=name+'.zip',bytes=len(raw),sha256=digest)],members=members,
 canonical_admission=True,actual_merge=actual,qualified_candidate=candidate,source_anchor=anchor,
 whole_tree=tree,coadmission=expected,actual_public_observations=observations,
 successful_workflows=len(runs),successful_checks=sum(x['conclusion']=='success' for x in checks),
 skipped_checks=sum(x['conclusion']=='skipped' for x in checks),
 full_model_periods_replayed_for_CI_or_observer_repairs=0,
 whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',
 global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
receipt=dict(status='ACTUAL_CANONICAL500_FROST_CALENDAR_ADMISSION_VERIFIED',PR=1801,
 actual_merge=actual,qualified_candidate=candidate,source_anchor=anchor,whole_tree=tree,
 previous_canonical=parent,ordered_parents=[parent,candidate],synthetic_merge=synthetic,
 admission_archive_sha256=digest,coadmission=expected,canonical_admission=True,
 whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',
 global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
for filename,value in [(name+'.json',manifest),('FROST_CALENDAR_STATE02_MERGE_RECEIPT_V1.json',receipt)]:
 with (P/filename).open('x',encoding='utf8') as f:json.dump(value,f,indent=2);f.write('\n')
print(manifest['status'],len(raw),digest,len(members),flush=True)
