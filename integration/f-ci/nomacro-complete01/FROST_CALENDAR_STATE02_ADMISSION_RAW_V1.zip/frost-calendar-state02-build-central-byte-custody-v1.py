"""Read-only per-file custody audit; does not release or delete resources."""
import contextlib,hashlib,json,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from frost_calendar_state_windows_local_science import LogicalArchive
registry=json.loads(Path('C:/Users/Veldh012/.codex/storage/swap5/state.json').read_text())
with contextlib.ExitStack() as stack:
 store=LogicalArchive(R/'integration/f-ci/nomacro-complete01','FROST_CALENDAR_STATE02_WINDOWS_LOCAL_RAW_V1',stack)
 bindings=json.loads(store.get('ACTUAL_ARCHIVE_LOCATIONS_V1.json'))
 bindings={k.replace('\\','/').rstrip('/'):v['prefix'].rstrip('/') for k,v in bindings.items()}
 results=[];verified_objects={}
 for identifier,item in registry['resources'].items():
  path=Path(item['path'])
  if item['task']!=TASK or item['kind']!='build' or not path.name.startswith('frost-calendar-state02-') or not path.exists():continue
  assert path.resolve().is_relative_to(E.parent.resolve()) and not path.is_symlink()
  files=[p for p in sorted(path.rglob('*')) if p.is_file()]
  assert all(not p.is_symlink() for p in files)
  def audit(p):
   absolute=p.resolve().as_posix();matches=[k for k in bindings if absolute==k or absolute.startswith(k+'/')]
   raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest()
   row=dict(path=p.relative_to(path).as_posix(),bytes=len(raw),sha256=digest)
   if not matches:return dict(**row,preserved=False,reason='No original archive path binding')
   prefix=max(matches,key=len);logical=bindings[prefix]+absolute[len(prefix):]
   expected=store.names.get(logical)
   return dict(**row,logical_archive_path=logical,preserved=expected==dict(bytes=len(raw),sha256=digest))
  with ThreadPoolExecutor(max_workers=8) as pool:rows=list(pool.map(audit,files))
  # Hash the actual archived payload too; metadata alone does not establish custody.
  for row in rows:
   if row['preserved'] and row['sha256'] not in verified_objects:
    raw=store.get(row['logical_archive_path']);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];verified_objects[row['sha256']]=row['bytes']
  result=dict(resource=identifier,path=str(path),source_ref=item['source_ref'],recipe=item['recipe'],
   files=len(rows),bytes=sum(x['bytes'] for x in rows),all_original_bytes_centrally_preserved=bool(rows) and all(x['preserved'] for x in rows),inventory=rows)
  results.append(result);print(path.name,result['files'],result['bytes'],result['all_original_bytes_centrally_preserved'],flush=True)
 q=dict(status='READ_ONLY_CENTRAL_COMMITTED_ARCHIVE_PER_FILE_BUILD_CUSTODY_AUDIT',
  actual_candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
  archive_sha256=store.record['sha256'],archive_logical_inventory_sha256=store.record['members']['LOGICAL_FILE_INVENTORY_V1.json']['sha256'],
  resources=results,verified_unique_archived_payloads=len(verified_objects),
  bytes_custodied=sum(x['bytes'] for x in results if x['all_original_bytes_centrally_preserved']),
  release_performed=False,deletion_performed=False)
 (E/'FROST_CALENDAR_STATE02_BUILD_CENTRAL_BYTE_CUSTODY_V1.json').write_text(json.dumps(q,indent=2)+'\n')
 print(q['status'],q['bytes_custodied'],flush=True)
