"""Audit newly superseded parent builds before shared eligible cleanup."""
import hashlib,json,subprocess,sys
from pathlib import Path
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from frost_calendar_state_parent_archive import CanonicalLogicalArchive
audit=json.loads((E/'FROST_CALENDAR_STATE02_BUILD_CENTRAL_BYTE_CUSTODY_V1.json').read_text())
paths={str(Path(x['path']).resolve()) for x in audit['resources'] if x['all_original_bytes_centrally_preserved']}
preview=json.loads((E/'FROST_CALENDAR_STATE02_BUILD_CLEANUP_PREVIEW_V1.json').read_text())
extra=[x for x in preview['results'] if x['status'].startswith('eligible') and str(Path(x['path']).resolve()) not in paths]
assert {Path(x['path']).name for x in extra}=={'frost-history-state01-default-canonical-implicit-water-O0-v1','frost-history-state01-default-canonical-implicit-cde-O2-v1'}
store=CanonicalLogicalArchive('FROST_HYSTERESIS_STATE01_WINDOWS_RAW_V1')
bindings=json.loads(store.get('ACTUAL_ARCHIVE_LOCATIONS_V1.json'));bindings={k.replace('\\','/').rstrip('/'):v['prefix'].rstrip('/') for k,v in bindings.items()}
rows=[]
for item in extra:
 root=Path(item['path']).resolve();assert root.is_relative_to(E.parent.resolve())
 for p in root.rglob('*'):
  assert not p.is_symlink()
  if not p.is_file():continue
  absolute=p.resolve().as_posix();matches=[k for k in bindings if absolute==k or absolute.startswith(k+'/')];assert matches,absolute
  key=max(matches,key=len);logical=bindings[key]+absolute[len(key):]
  raw=p.read_bytes();assert raw==store.get(logical)
  rows.append(dict(path=str(p),logical_archive_path=logical,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 paths.add(str(root))
(E/'FROST_CALENDAR_STATE02_SUPERSEDED_PARENT_BUILD_CUSTODY_V2.json').write_text(json.dumps(dict(actual_canonical='8dbe3db7c7832dd6a1f86c4275cd43f054552df3',archive_sha256=store.record['sha256'],files=rows),indent=2)+'\n')
tool='C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py'
cmd=[sys.executable,'-B',tool,'cleanup','--task','01a1e8b4-228b-75f1-8ac4-b07ca1e15713']
r=subprocess.run(cmd,capture_output=True);q=json.loads(r.stdout)
(E/'FROST_CALENDAR_STATE02_BUILD_CLEANUP_PREVIEW_V2.json').write_bytes(r.stdout)
assert all(str(Path(x['path']).resolve()) in paths for x in q['results'] if x['status'].startswith('eligible'))
r=subprocess.run(cmd+['--apply'],capture_output=True)
(E/'FROST_CALENDAR_STATE02_BUILD_CLEANUP_APPLIED_V2.json').write_bytes(r.stdout)
(E/'FROST_CALENDAR_STATE02_BUILD_CLEANUP_APPLIED_V2.stderr.txt').write_bytes(r.stderr)
q=json.loads(r.stdout)
print(json.dumps(dict(returncode=r.returncode,free_after=q['free_after'],net_free_change=q['net_free_change'],results=[x for x in q['results'] if x['status']!='retained']),indent=2),flush=True)
