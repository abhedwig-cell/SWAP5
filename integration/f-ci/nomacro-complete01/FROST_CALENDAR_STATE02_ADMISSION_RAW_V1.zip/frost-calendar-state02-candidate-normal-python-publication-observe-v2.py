"""Run the real publication entry with ordinary bytecode defaults, clean14."""
from pathlib import Path
import subprocess,sys,os,time,json,hashlib
R=Path.cwd();E=Path(__file__).resolve().parent;output=E/'FROST_CALENDAR_STATE02_CANDIDATE_PUBLICATION_V2';git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
def snapshot():
 p=Path(git('rev-parse','--git-path','info/sparse-checkout'));p=p if p.is_absolute() else R/p
 return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all','--ignored'),sparse=p.read_text().splitlines(),original_project_files={p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'reference/swap-4.3.1/projects').rglob('*') if p.is_file()})
before=snapshot();assert not before['status'] and len(before['sparse'])==14 and len(before['original_project_files'])==56
env=dict(os.environ,GITHUB_EVENT_NAME='pull_request');removed={key:env.pop(key,None) for key in ('PYTHONDONTWRITEBYTECODE','PYTHONPYCACHEPREFIX')}
probe=subprocess.run([sys.executable,'-c','import sys; print(sys.dont_write_bytecode)'],env=env,capture_output=True,check=True);assert probe.stdout.strip()==b'False' and not probe.stderr
command=[sys.executable,'tests/nomacro_drainage/frost_publication_scope.py'];start=time.perf_counter()
with output.with_suffix('.stdout.txt').open('xb') as stdout,output.with_suffix('.stderr.txt').open('xb') as stderr:r=subprocess.run(command,cwd=R,env=env,stdout=stdout,stderr=stderr,timeout=3600)
q=dict(status='ACTUAL_ORDINARY_PYTHON_PUBLICATION_COMMAND_RETURNED',command=command,returncode=r.returncode,seconds=time.perf_counter()-start,before=before,after=snapshot(),ordinary_python_default_dont_write_bytecode=False,child_bytecode_environment_variables_absent=True,entry_point_owns_no_bytecode_writes=True,compiler_executions=0,model_executions=0)
output.with_suffix('.json').write_text(json.dumps(q,indent=2)+'\n');assert q['before']==q['after'] and r.returncode==0 and b'PUBLICATION_REPLAY_SELECTED=false' in output.with_suffix('.stdout.txt').read_bytes() and not output.with_suffix('.stderr.txt').read_bytes();print(q['status'],q['seconds'],q['before']['head'])
