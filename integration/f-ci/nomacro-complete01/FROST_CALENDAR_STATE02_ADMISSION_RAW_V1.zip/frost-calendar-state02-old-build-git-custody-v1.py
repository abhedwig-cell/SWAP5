from pathlib import Path
import json,hashlib,subprocess,zipfile,io
R=Path("C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01");W=Path("C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600");E=W/"evidence";P=R/"integration/f-ci/nomacro-complete01";BASE="8dbe3db7c7832dd6a1f86c4275cd43f054552df3";TASK="01a1e8b4-228b-75f1-8ac4-b07ca1e15713";PREFIX="integration/f-ci/nomacro-complete01/"
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def gitfile(name):return subprocess.check_output(["git","show",BASE+":"+PREFIX+name],cwd=R)
class GitArchive:
 def __init__(self,name,record):
  actual=json.loads(gitfile(name+".json"));assert actual==record;parts=[]
  for item in actual["parts"]:
   raw=gitfile(item["file"]);assert len(raw)==item["bytes"] and SHA(raw)==item["sha256"];parts.append(raw)
  raw=b"".join(parts);assert len(raw)==actual["bytes"] and SHA(raw)==actual["sha256"];self.z=zipfile.ZipFile(io.BytesIO(raw));self.record=actual
  assert len(self.z.namelist())==len(set(self.z.namelist())) and set(self.z.namelist())==set(actual["members"])
 def get(self,name):
  raw=self.z.read(name);item=self.record["members"][name];assert len(raw)==item["bytes"] and SHA(raw)==item["sha256"];return raw
catalog={};declarations={}
for path in P.glob("*WINDOWS*RAW*.json"):
 if not path.name.startswith(("FROST_DRAINAGE_","FROST_IMPLICIT_","SNOW58_","GROUNDWATER_SNOW_","IMPLICIT_SNOW_","SNOW_UNDRAINED_","WATER_SNOW_GROUNDWATER_")):continue
 q=json.loads(path.read_text());declarations[path.stem]=q
 for member,item in q["members"].items():catalog.setdefault((item["bytes"],item["sha256"]),(path.stem,member))
registry=json.loads(Path("C:/Users/Veldh012/.codex/storage/swap5/state.json").read_text());rows=[];opened={};verified={}
for resource in registry["resources"].values():
 path=Path(resource["path"])
 if resource.get("task")!=TASK or resource["kind"]!="build" or resource.get("released") or resource.get("status")=="deleted" or not path.exists():continue
 if path.parent!=W or path.name.startswith(("frost-calendar-","ria12-","explicit-bottom9-vapor")):continue
 files=[];missing=[]
 for p in sorted(path.rglob("*")):
  if not p.is_file():continue
  assert not p.is_symlink();raw=p.read_bytes();key=(len(raw),SHA(raw));hit=catalog.get(key)
  if not hit:missing.append(p.relative_to(path).as_posix());continue
  name,member=hit;files.append(dict(file=p.relative_to(path).as_posix(),bytes=key[0],sha256=key[1],central_archive=name,central_member=member))
 complete=bool(files) and not missing
 if complete:
  for item in files:
   key=(item["bytes"],item["sha256"])
   if key in verified:continue
   name=item["central_archive"]
   if name not in opened:opened[name]=GitArchive(name,declarations[name])
   raw=opened[name].get(item["central_member"]);assert raw==(path/item["file"]).read_bytes();verified[key]=True
 rows.append(dict(path=str(path),files=files,unmatched=missing,all_actual_bytes_freshly_verified_in_accepted_central_archives=complete,source_ref=resource.get("source_ref"),recipe=resource.get("recipe")))
 print("CHECKED",path.name,len(files),len(missing),complete,flush=True)
q=dict(status="FRESH_OLD_BUILD_RESOURCE_ACTUAL_CANONICAL_GIT_ARCHIVE_BYTE_CUSTODY_COMPLETE",actual_canonical=BASE,resources=rows,central_archives={n:dict(sha256=x.record["sha256"],bytes=x.record["bytes"]) for n,x in opened.items()},model_executions=0,compiler_executions=0)
out=E/"FROST_CALENDAR_STATE02_OLDER_BUILD_CANONICAL_GIT_BYTE_CUSTODY_V1.json";assert not out.exists();out.write_text(json.dumps(q,indent=2)+"\n");ok=[x for x in rows if x["all_actual_bytes_freshly_verified_in_accepted_central_archives"]];print("COMPLETE",len(ok),sum(f["bytes"] for x in ok for f in x["files"]),flush=True)
