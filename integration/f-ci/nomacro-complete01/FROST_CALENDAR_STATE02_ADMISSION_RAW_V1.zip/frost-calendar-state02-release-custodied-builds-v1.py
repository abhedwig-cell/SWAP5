"""Release only our fully archived completed build copies via shared policy."""
import json,subprocess,sys
from pathlib import Path
E=Path(__file__).parent
TOOL=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py')
TASK='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
audit=json.loads((E/'FROST_CALENDAR_STATE02_BUILD_CENTRAL_BYTE_CUSTODY_V1.json').read_text())
assert audit['actual_candidate']=='3250f0c59337334994b0e8edda624afe8f91b11f'
assert audit['archive_sha256']=='392e04277161e7cbacc67fc4a995d4b572bd182a7961671b097662fce573e811'
selected=[x for x in audit['resources'] if x['all_original_bytes_centrally_preserved']]
assert len(selected)==len(audit['resources'])==21
for x in selected:
 p=Path(x['path']).resolve();assert p.is_relative_to(E.parent.resolve()) and p.name.startswith('frost-calendar-state02-')
 r=subprocess.run([sys.executable,'-B',str(TOOL),'release','--task',TASK,'--path',str(p)],capture_output=True,check=True)
 (E/('FROST_CALENDAR_STATE02_BUILD_RELEASE_'+x['resource']+'_V1.json')).write_bytes(r.stdout)
preview=subprocess.run([sys.executable,'-B',str(TOOL),'cleanup','--task',TASK],capture_output=True)
(E/'FROST_CALENDAR_STATE02_BUILD_CLEANUP_PREVIEW_V1.json').write_bytes(preview.stdout)
q=json.loads(preview.stdout);paths={str(Path(x['path']).resolve()) for x in selected}
eligible=[x for x in q['results'] if x['status'] not in ('retained','blocked')]
assert all(str(Path(x['path']).resolve()) in paths for x in eligible),eligible
applied=subprocess.run([sys.executable,'-B',str(TOOL),'cleanup','--apply','--task',TASK],capture_output=True)
(E/'FROST_CALENDAR_STATE02_BUILD_CLEANUP_APPLIED_V1.json').write_bytes(applied.stdout)
(E/'FROST_CALENDAR_STATE02_BUILD_CLEANUP_APPLIED_V1.stderr.txt').write_bytes(applied.stderr)
q=json.loads(applied.stdout)
print(json.dumps(dict(returncode=applied.returncode,net_free_change=q['net_free_change'],
 results=[x for x in q['results'] if x['status']!='retained']),indent=2),flush=True)
