"""Restore exact declared sparse archive dependencies after switching branch."""
from pathlib import Path
import hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='3250f0c59337334994b0e8edda624afe8f91b11f'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
names=['FROST_CALENDAR_STATE02_'+n for n in ['WINDOWS_LOCAL_RAW_V1','WINDOWS_CI_O0_ORIGINAL_V1','WINDOWS_CI_O2_ORIGINAL_V1','UBUNTU_O0_ORIGINAL_V1','UBUNTU_O2_ORIGINAL_V1']]+['FROST_HYSTERESIS_STATE01_ADMISSION_RAW_V1']
items={}
for name in names:
 for part in json.loads((R/'integration/f-ci/nomacro-complete01'/(name+'.json')).read_text())['parts']:
  relative='integration/f-ci/nomacro-complete01/'+part['file'];p=R/relative
  if not p.is_file():git('restore','--source='+head,'--worktree','--ignore-skip-worktree-bits','--',relative)
  raw=p.read_bytes();assert len(raw)==part['bytes'] and hashlib.sha256(raw).hexdigest()==part['sha256'];items[relative]=part
assert len(items)==14 and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=dict(status='EXACT_FOURTEEN_DECLARED_ARCHIVE_PARTS_RESTORED_AFTER_SWITCH_TO_NAMED_CANDIDATE_BRANCH',head=head,parts=items,compiler_executions=0,model_executions=0)
(Path(__file__).parent/'FROST_CALENDAR_STATE02_NAMED_CANDIDATE_DEPENDENCIES_V4.json').write_text(json.dumps(q,indent=2)+'\n')
print(q['status'])
