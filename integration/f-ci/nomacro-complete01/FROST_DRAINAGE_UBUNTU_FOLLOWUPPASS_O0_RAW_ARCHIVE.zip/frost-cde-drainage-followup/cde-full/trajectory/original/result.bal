* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 19:16:45

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.85 cm       0.2569E+02 mg/cm2
Initial :        97.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -19.34 cm       0.2569E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     5.91
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    49.09
=========================    ============================
Sum            :    86.58    Sum               :   105.92


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.7655E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2308E+02
=========================    ============================
Sum         :  0.4877E+02    Sum            :  0.2308E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.02 cm       0.1239E+02 mg/cm2
Initial :        77.85 cm       0.2569E+02 mg/cm2
            =============       =================
Change           -1.83 cm      -0.1330E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     4.65
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     6.00    Transpiration     :    14.79
Bottom flux    :     0.00    Soil evaporation  :    16.94
                             Crack flux        :     0.00
                             Drainage level 1  :    43.44
=========================    ============================
Sum            :    77.98    Sum               :    79.81


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.6440E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1394E+02
=========================    ============================
Sum         :  0.6440E+00    Sum            :  0.1394E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.49 cm       0.8221E+01 mg/cm2
Initial :        76.02 cm       0.1239E+02 mg/cm2
            =============       =================
Change           -0.54 cm      -0.4170E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :    11.31
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    29.61
Bottom flux    :     0.00    Soil evaporation  :    13.07
                             Crack flux        :     0.00
                             Drainage level 1  :    27.09
=========================    ============================
Sum            :    80.55    Sum               :    81.09


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.6776E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4848E+01
=========================    ============================
Sum         :  0.6776E+00    Sum            :  0.4848E+01

