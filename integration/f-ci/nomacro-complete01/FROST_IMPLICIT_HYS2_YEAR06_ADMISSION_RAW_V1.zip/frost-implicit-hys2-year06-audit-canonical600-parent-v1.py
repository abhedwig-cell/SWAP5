"""Read-only genuine parent admission observer with frozen real HEAD."""
from pathlib import Path
import json,subprocess,sys,time
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
git=lambda *x:subprocess.check_output(['git',*x],cwd=R).decode().strip()
head=git('rev-parse','HEAD');started=time.perf_counter()
from frost_implicit_hys2_parent_admission import parent_admission
q=parent_admission();assert git('rev-parse','HEAD')==head
result=dict(actual_observer=head,actual_parent='47124f4de18a752fc466d50e2752e843548e5fea',seconds=time.perf_counter()-started,result=q,compiler_executions=0,model_executions=0)
with (E/'FROST_IMPLICIT_HYS2_YEAR06_CANONICAL600_PARENT_AUDIT_V1.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(q['status'],result['seconds'],flush=True)
