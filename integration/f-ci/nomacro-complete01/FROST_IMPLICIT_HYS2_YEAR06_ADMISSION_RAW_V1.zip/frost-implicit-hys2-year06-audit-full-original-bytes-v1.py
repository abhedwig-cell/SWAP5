"""Independent original-byte64 matrix observer; stable genuine HEAD, no models."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
git=lambda *x:subprocess.check_output(['git',*x],cwd=R).decode().strip()
def snapshot():return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),index=git('write-tree'),status=git('status','--porcelain=v1','--untracked-files=all','--ignored'))
before=snapshot();assert not before['status']
assert not git('diff','23850bf112e4312745b056e5517b95e13e2af53b','HEAD','--','app','src','tools','reference')
from frost_boundary_git_archive import GitArchiveSource
from frost_implicit_hys2_central import audit
started=time.perf_counter();error=None;q=None
try:
 q=audit(GitArchiveSource(R,before['head']),True)
 with (E/'FROST_IMPLICIT_HYS2_YEAR06_COMPLETE64_CENTRAL_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
except Exception as exc:error=repr(exc);raise
finally:
 after=snapshot();report=dict(status='INDEPENDENT_ORIGINAL64_AND_CURRENT32_AUDIT_PASS' if error is None else 'FAILED_READ_ONLY_AUDIT_NOT_QUALIFIED',before=before,after=after,error=error,seconds=time.perf_counter()-started,actual_auditor_LF_sha256=hashlib.sha256((R/'tests/nomacro_drainage/frost_implicit_hys2_central.py').read_bytes().replace(b'\r\n',b'\n')).hexdigest(),compiler_executions=0,model_executions=0)
 with (E/'FROST_IMPLICIT_HYS2_YEAR06_COMPLETE64_OBSERVATION_V1.json').open('x',encoding='utf8') as f:json.dump(report,f,indent=2);f.write('\n')
 assert before==after
if q:print(q['status'],report['seconds'],q['native_samples'],q['exact_cold_windows'],q['actual_compiled_refusals'],flush=True)
