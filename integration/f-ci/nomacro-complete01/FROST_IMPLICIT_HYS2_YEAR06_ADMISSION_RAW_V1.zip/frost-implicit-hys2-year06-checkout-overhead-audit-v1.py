"""Observe selected workflow checkout overhead without changing current CI or HEAD."""
from pathlib import Path
import hashlib,json,subprocess,yaml
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
names=['docs.yml','f-mig431-int12-d.yml','f-mig431-int12-e.yml','f-mig431-low08a-qualification.yml','fci-canonical.yml','swap431-crop-rootgrow-dvs.yml','f-pe-zero-waste01-poison.yml','f-pe-timeint16.yml','swap431-root-oxygen-emp.yml','f-gc42-live-whole-window-service.yml','f-mig431-int12-p0.yml','swap431-crop-co2.yml','swap431-root-lrv-constant.yml','f-ci110-performance-admission.yml']
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='cb712974e37e41256877d9770a0af071afe241dd'
rows=[]
for name in names:
 path='.github/workflows/'+name;raw=git('show',head+':'+path);source=yaml.safe_load(raw)
 for job,body in source['jobs'].items():
  for index,step in enumerate(body.get('steps',[])):
   if not str(step.get('uses','')).startswith('actions/checkout@'):continue
   config=step.get('with',{})
   rows.append(dict(path=path,actual_git_source=head,whole_workflow_sha256=hashlib.sha256(raw).hexdigest(),job=job,step_index=index,action=step['uses'],checkout=config,partial_clone=bool(config.get('filter')),sparse_checkout=bool(config.get('sparse-checkout')),all_run_commands_sha256=hashlib.sha256(json.dumps([s['run'] for s in body.get('steps',[]) if 'run' in s],ensure_ascii=False).encode()).hexdigest()))
assert git('rev-parse','HEAD').decode().strip()==head
q=dict(status='READ_ONLY_SELECTED_CURRENT_CHECKOUT_CONFIGURATION_OBSERVED_NO_CHANGE_OR_SPEEDUP_CLAIM',actual_source=head,workflows=14,checkout_steps=rows,unfiltered_unsparse_checkouts=sum(not x['partial_clone'] and not x['sparse_checkout'] for x in rows),current_CI_modified=False,compiler_executions=0,model_executions=0,next_action='After current real candidate observations/admission, consider literal checkout-only workflow inverses and actual command/dependency preservation. Never substitute an incomplete tree or projected source identity.')
with (E/'FROST_IMPLICIT_HYS2_YEAR06_SELECTED_CHECKOUT_OVERHEAD_AUDIT_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],q['unfiltered_unsparse_checkouts'],'of',len(rows),flush=True)
