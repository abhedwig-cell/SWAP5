"""Keep workflow head, actual job checkout and original model producer distinct."""
from pathlib import Path
import hashlib,json
E=Path(__file__).resolve().parent
C='cb712974e37e41256877d9770a0af071afe241dd';S='c65c7eb92cdc82ab786f62cb96bf376404e45130'
api=json.loads((E/'FROST_IMPLICIT_HYS2_YEAR06_PR1805_SYNTHETIC_OFFICIAL_GIT_API_V1.json').read_text())
assert api['sha']==S and api['verification']['verified'] and api['tree']['sha']=='a1c7b85e9a446cb3891cd3b115b63f9469668e7e'
rows=[]
for role in ('CO2','DVS','LRV','TIMEINT_STARTUP','TIMEINT_INVERSE','FCI_MODULAR'):
 name=f'FROST_IMPLICIT_HYS2_YEAR06_PR1805_{role}_ORIGINAL_CI_V1.log';raw=(E/name).read_bytes();meta=json.loads((E/(name+'.json')).read_text())
 assert len(raw)==meta['bytes'] and hashlib.sha256(raw).hexdigest()==meta['sha256'] and C.encode() in raw and S.encode() in raw
 head_lines=[line for line in raw.decode('utf8').splitlines() if 'HEAD is now at '+S[:7] in line]
 assert head_lines,role
 rows.append(dict(role=role,original_file=name,original_bytes=len(raw),original_sha256=meta['sha256'],workflow_run_head_sha=C,actual_job_checkout_HEAD=S,actual_checkout_line=head_lines[0],compatibility_actual_source_field_semantics='GitHub workflow_run.head_sha, not actual job checkout HEAD'))
q=dict(status='ALL_SIX_ORIGINAL_CI_LOGS_DISTINGUISH_WORKFLOW_HEAD_REAL_SIGNED_CHECKOUT_AND_ORIGINAL_MODEL_PRODUCER',roles=rows,actual_signed_checkout_tree=api['tree']['sha'],original_scientific_model_producer='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6',actual_current_canonical='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c',source_identity_rebound=False,HEAD_or_filesystem_projected=False,compiler_executions=0,model_executions=0)
with (E/'FROST_IMPLICIT_HYS2_YEAR06_PR1805_CI_CHECKOUT_IDENTITIES_V2.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],len(rows),flush=True)
