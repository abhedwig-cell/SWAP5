"""Prove local disposable copies exactly match the committed original archive."""
from pathlib import Path
from contextlib import ExitStack
import json,subprocess,sys
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive,SHA
M='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert git('rev-parse','HEAD')==M
resources=[]
with ExitStack() as stack:
 archive=Archive(GitArchiveSource(R,M),'FROST_IMPLICIT_HYS2_YEAR06_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
 assert archive.record['sha256']=='ce9c0992116ac2e59a34b6dd073fc9e5f7ae08dadc731374889801678b08463d' and archive.record['actual_scientific_source']=='23850bf112e4312745b056e5517b95e13e2af53b'
 for name,prefix,kind in [('frost-implicit-hys2-year06-local-science-v1','current','debug'),('frost-implicit-hys2-year06-local-O0-v1','compiled/O0','build'),('frost-implicit-hys2-year06-local-O2-v1','compiled/O2','build')]:
  root=W/name;assert root.is_dir() and root.resolve().parent==W.resolve() and not root.is_symlink()
  files={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()};expected={n[len(prefix)+1:] for n in archive.names if n.startswith(prefix+'/')}
  assert files.keys()==expected
  size=0
  for rel,p in sorted(files.items()):
   assert not p.is_symlink();actual=p.read_bytes();assert actual==archive.get(prefix+'/'+rel);size+=len(actual)
  resources.append(dict(path=str(root),kind=kind,files=len(files),bytes=size,archive_prefix=prefix,all_original_bytes_exact=True))
 assert git('rev-parse','HEAD')==M
 q=dict(status='ALL_OWNED_LOCAL_SCIENCE_AND_BUILD_COPIES_FRESH_EXACT_COMMITTED_ORIGINAL_BYTES_BEFORE_RELEASE',actual_data_revision=M,archive='FROST_IMPLICIT_HYS2_YEAR06_LOCAL_WINDOWS_O0_O2_RAW_V1',archive_sha256=archive.record['sha256'],actual_original_scientific_source=archive.record['actual_scientific_source'],resources=resources,shared_provider_J_not_released=True,unique_E_evidence_not_registered_disposable=True,compiler_executions=0,model_executions=0)
 with (E/'FROST_IMPLICIT_HYS2_YEAR06_LOCAL_CENTRAL_CUSTODY_BEFORE_RELEASE_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
 print(q['status'],sum(x['files'] for x in resources),sum(x['bytes'] for x in resources),flush=True)
