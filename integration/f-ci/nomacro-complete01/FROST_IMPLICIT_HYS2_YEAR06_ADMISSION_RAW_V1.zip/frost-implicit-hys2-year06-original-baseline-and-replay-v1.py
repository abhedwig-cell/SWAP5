"""Next block: genuine original failed bottom5 component, no public bypass."""
from pathlib import Path,PurePosixPath
from contextlib import ExitStack
import hashlib,json,os,subprocess,sys,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=W/'frost-implicit-hys2-year06-original-failure-v1'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive,SHA
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert head=='cb5946a6d8205462d96495a39611f72f570db58a'
base='087fc67db3e1e58d45215522eb284e89cb6c12f1';producer='dcae412aae8f65acb48b1e37431334c2c522c071';name='cde-b5-i1-h2-p2-regular-r0-year-seam';prefix='current/'+name;inventory=[]
with ExitStack() as stack:
 store=Archive(GitArchiveSource(R,base),'FROST_BOUNDARY_STATE_CALENDAR04_WINDOWS_O0_ORIGINAL_V3',stack)
 record=json.loads(store.get(prefix+'/science/RESULT.json'));assert record['source']==producer
 rows=[json.loads(line) for line in store.get(prefix+'/science/trajectory/daily.jsonl').splitlines()];assert len(rows)==4 and all(row['committed'] for row in rows)
 assert b'Implicit original retry reached clock resolution' in store.get(prefix+'/science/trajectory/original/donor.stderr')
 projection=json.loads(store.get('COMPILED_PROJECTION_V1.json'));build_prefix=projection[record['build_root']]['archive_prefix'];meta=json.loads(store.get(build_prefix+'/BUILD.json'));assert SHA(store.get(build_prefix+'/BUILD.json'))==projection[record['build_root']]['actual_BUILD_sha256']
 for original,destination in [(prefix+'/',D/'original-failed-profile'),(build_prefix+'/',D/'original-bundle'),('original-provider-build/',D/'original-provider-build')]:
  for member in sorted(store.names):
   if not member.startswith(original):continue
   relative=PurePosixPath(member[len(original):]);assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
   target=destination/relative.as_posix();assert target.resolve().is_relative_to(D.resolve());raw=store.get(member);target.parent.mkdir(parents=True,exist_ok=True)
   if target.exists():assert target.read_bytes()==raw
   else:target.write_bytes(raw)
   inventory.append(dict(archive_member=member,actual_copy=str(target),bytes=len(raw),sha256=SHA(raw)))
 archive_sha=store.record['sha256']
B=D/'original-bundle';O=D/'original-donor-replay-v1';O.mkdir();exe=B/'day_donor.exe';assert SHA(exe.read_bytes())==meta['executable_sha256']['donor']
for n,v in meta['identity']['donor_generated'].items():assert SHA((B/n).read_bytes())==v
for n,v in meta['identity']['donor_objects'].items():assert SHA((D/'original-provider-build/swap-obj'/n).read_bytes())==v
assert SHA((D/'original-provider-build/ttutil-obj/libttutil.a').read_bytes())==meta['identity']['ttutil_library']
inputs={}
for name in meta['inputs']:
 original=D/'original-failed-profile/science/trajectory/original'/name;raw=original.read_bytes();target=O/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);inputs[name]=SHA(raw)
request=b''.join((str(day)+' -1\n').encode() for day in range(1,6))+b'0 -1\n';(O/'donor.request').write_bytes(request)
env=dict(os.environ,OMP_NUM_THREADS='1',PATH='C:/msys64/ucrt64/bin;'+os.environ.get('PATH',''));started=time.perf_counter();code=None;error=None
try:
 with (O/'donor.stdout').open('xb') as out,(O/'donor.stderr').open('xb') as err:
  child=subprocess.run([str(exe),'./swap.swp'],cwd=O,env=env,input=request,stdout=out,stderr=err,timeout=180);code=child.returncode
except subprocess.TimeoutExpired:error='EXPLICIT_180_SECOND_DIAGNOSTIC_CENSOR'
stdout=(O/'donor.stdout').read_bytes();stderr=(O/'donor.stderr').read_bytes();returned=sum(line.startswith(b'HYBRID_DAY_RETURN') for line in stdout.splitlines())
runtime={n:SHA((Path('C:/msys64/ucrt64/bin')/n).read_bytes()) for n in ['libgfortran-5.dll','libquadmath-0.dll','libgcc_s_seh-1.dll','libwinpthread-1.dll'] if (Path('C:/msys64/ucrt64/bin')/n).is_file()}
q=dict(status='ORIGINAL_IMPLICIT_HYS2_BOTTOM5_YEAR_COMPONENT_FAILURE_REPLAY_DIAGNOSTIC_NOT_QUALIFIED',actual_collection_head=head,actual_historical_data_revision=base,actual_original_source=producer,actual_original_archive_sha256=archive_sha,actual_original_compiler=meta['identity']['compiler'],actual_original_compiler_sha256=meta['identity']['compiler_sha256'],original_executable_sha256=SHA(exe.read_bytes()),original_executable_unchanged=True,original_archived_accepted_days=4,actual_donor_returned_days=returned,returncode=code,error=error,clock_resolution_failure=b'Implicit original retry reached clock resolution' in stderr,model_seconds=time.perf_counter()-started,request=request.decode(),inputs=inputs,actual_runtime_DLLs=runtime,original_runtime_DLL_equality='UNKNOWN_ORIGINAL_DLL_HASHES_NOT_CAPTURED',physical_inventory=inventory,kernel_accepted_days=0,compiler_executions=0,public_admission=False,checkpoint_publication=False,source_or_namespace_or_filesystem_projection=False,physical_equations_state_flags_tolerances_changed=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==head
for root in [E,O]:(root/'FROST_IMPLICIT_HYS2_YEAR06_ORIGINAL_BASELINE_REPLAY_V1.json').write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],returned,code,q['clock_resolution_failure'],q['model_seconds'],len(inventory),flush=True)
