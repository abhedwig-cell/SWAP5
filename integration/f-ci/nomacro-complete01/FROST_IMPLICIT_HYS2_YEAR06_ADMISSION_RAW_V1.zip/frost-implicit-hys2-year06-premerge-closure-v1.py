"""Close actual candidate, fourteen selected CI, real controls and signed merge."""
from pathlib import Path
import json,hashlib,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='cb712974e37e41256877d9770a0af071afe241dd';BASE='47124f4de18a752fc466d50e2752e843548e5fea';SYNTHETIC='c65c7eb92cdc82ab786f62cb96bf376404e45130'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip();SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD')==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
ci=json.loads((E/'FROST_IMPLICIT_HYS2_YEAR06_PR1805_FINAL_ALL_CI_API_V1.json').read_text());runs=ci['runs']['workflow_runs'];checks=ci['checks']['check_runs']
assert ci['runs']['total_count']==len(runs)==14 and all(x['head_sha']==C and x['status']=='completed' and x['conclusion']=='success' for x in runs)
assert ci['checks']['total_count']==len(checks)==45 and all(x['head_sha']==C and x['status']=='completed' and x['conclusion'] in ['success','skipped'] for x in checks)
positive={}
for role in ['PUBLIC','PUBLICATION']:
 stem='FROST_IMPLICIT_HYS2_YEAR06_CANDIDATE_'+role+'_V1';q=json.loads((E/(stem+'.json')).read_text());raw=(E/(stem+'.stdout.txt')).read_bytes()
 assert q['before']==q['after'] and q['before']['head']==C and q['before']['tree']==git('rev-parse',C+'^{tree}') and q['returncode']==0 and q['error'] is None
 assert not q['before']['status'] and len(q['before']['sparse'])==14 and len(q['before']['original_project_files'])==56 and not (E/(stem+'.stderr.txt')).read_bytes()
 if role=='PUBLIC':assert json.loads(raw)['coadmission']['contexts']==648
 else:assert q['ordinary_python_default_dont_write_bytecode'] is False and q['child_bytecode_environment_variables_absent'] and b'PUBLICATION_REPLAY_SELECTED=false' in raw
 positive[role]=dict(actual_head=C,seconds=q['seconds'],stdout_sha256=SHA(raw))
negative=json.loads((E/'FROST_IMPLICIT_HYS2_YEAR06_FINAL_NEGATIVES_V1.json').read_text());assert negative['candidate']==C and negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
assert len(negative['controls'])==4 and {x['role'] for x in negative['controls']}=={'SOURCE','RAW','INHERITED','PUBLICATION'}
for item in negative['controls']:
 assert item['actual_refusal'] and item['actual_one_file_delta'] and git('show','-s','--format=%P',item['head'])==C and git('diff','--name-only',C,item['head'])==item['path']
 assert git('ls-remote','--heads','origin','refs/heads/'+item['branch']).split()[0]==item['head']
synthetic=json.loads((E/'FROST_IMPLICIT_HYS2_YEAR06_PR1805_SYNTHETIC_OFFICIAL_GIT_API_V1.json').read_text());assert synthetic['sha']==SYNTHETIC and synthetic['verification']['verified'] and synthetic['verification']['reason']=='valid'
assert [p['sha'] for p in synthetic['parents']]==[BASE,C] and synthetic['tree']['sha']==git('rev-parse',C+'^{tree}')==git('rev-parse',SYNTHETIC+'^{tree}')
logs=[]
for role in ['CO2','DVS','LRV','FCI_MODULAR','TIMEINT_STARTUP','TIMEINT_INVERSE']:
 name='FROST_IMPLICIT_HYS2_YEAR06_PR1805_'+role+'_ORIGINAL_CI_V1.log';raw=(E/name).read_bytes();q=json.loads((E/(name+'.json')).read_text())
 assert len(raw)==q['bytes'] and SHA(raw)==q['sha256'] and C.encode() in raw and SYNTHETIC.encode() in raw
 logs.append(dict(role=role,file=name,bytes=len(raw),sha256=SHA(raw)))
selection=json.loads((E/'FROST_IMPLICIT_HYS2_YEAR06_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json').read_text());assert selection['actual_current_head']==C and selection['actual_parent']==BASE and selection['current_MCSOL_model_replay']=='NOT_SELECTED_IMPACT' and selection['unchanged_tracked_files']==1063
assert not git('diff',BASE,C,'--',*selection['unchanged_dependency_paths'])
canonical=json.loads((E/'FROST_IMPLICIT_HYS2_YEAR06_PREMERGE_CANONICAL_API_V1.json').read_text());assert canonical['object']['sha']==BASE
q=dict(status='ACTUAL_CANDIDATE_PUBLIC_ORDINARY_PUBLICATION_FOUR_REAL_NEGATIVES_SELECTED14_CI_AND_SIGNED_SYNTHETIC_PREMERGE_CLOSURE_PASS',actual_candidate=C,actual_tree=git('rev-parse',C+'^{tree}'),actual_canonical_before_merge=BASE,actual_synthetic=SYNTHETIC,CI_runs=len(runs),CI_checks=len(checks),CI_success_checks=sum(x['conclusion']=='success' for x in checks),CI_skipped_checks=sum(x['conclusion']=='skipped' for x in checks),actual_positive_observers=positive,actual_primary_current_CI_logs=logs,unaffected_MCSOL_model_replay='NOT_SELECTED_IMPACT_1063_DEPENDENCY_FILES_EXACT',POND_current_model_replay='NOT_SELECTED_EXISTING_PRIVATE_FROST_PATH_SELECTION_PARENT_SUCCESS_RETAINED',canonical_admission=False,whole_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
(E/'FROST_IMPLICIT_HYS2_YEAR06_PREMERGE_CLOSURE_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],q['CI_runs'],q['CI_checks'],flush=True)
