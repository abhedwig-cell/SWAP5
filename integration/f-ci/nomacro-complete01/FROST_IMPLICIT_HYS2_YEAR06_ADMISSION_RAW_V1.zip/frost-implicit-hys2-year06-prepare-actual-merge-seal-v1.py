"""Prepare later actual-merge observer and admission seal without running them."""
from pathlib import Path
E=Path(__file__).resolve().parent
def put(name,s):
 compile(s,name,'exec')
 with (E/name).open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(E/'frost-implicit-hys2-year06-actual-candidate-observer-v1.py').read_text().replace('FROST_IMPLICIT_HYS2_YEAR06_CANDIDATE_','FROST_IMPLICIT_HYS2_YEAR06_ACTUAL_MERGE_')
put('frost-implicit-hys2-year06-actual-merge-observer-v1.py',s)
s=(E/'frost-implicit-plate05-admission-seal-v1.py').read_text()
for before,after in {
 'FROST_IMPLICIT_PLATE05':'FROST_IMPLICIT_HYS2_YEAR06',
 'frost-implicit-plate05-':'frost-implicit-hys2-year06-',
 'frost_implicit_plate_metadata.py':'frost_implicit_hys2_metadata.py',
 'cb5946a6d8205462d96495a39611f72f570db58a':'cb712974e37e41256877d9770a0af071afe241dd',
 '087fc67db3e1e58d45215522eb284e89cb6c12f1':'47124f4de18a752fc466d50e2752e843548e5fea',
 '06b31c0ea8d0bb087441be1dab0d1f1ad9236fcc':'c65c7eb92cdc82ab786f62cb96bf376404e45130',
 '81f4f9ad7d7debf7bddc17e991e689341a28192c':'427974eb7b669856da9876ad39ba73bed5d437a5',
 'c8ca41ee58a52cb57074485ba7a812bfbed56181':'a1c7b85e9a446cb3891cd3b115b63f9469668e7e',
 'PR1804':'PR1805','PR=1804':'PR=1805',
 '(600,570,4070,1752)':'(648,602,4326,1864)',
 'CANONICAL600':'CANONICAL648',
 'FROST_IMPLICIT_PLATE_ADMISSION_VERIFIED':'FROST_IMPLICIT_HYS2_BOUNDARY_ADMISSION_VERIFIED',
}.items():
 assert before in s,before;s=s.replace(before,after)
put('frost-implicit-hys2-year06-admission-seal-v1.py',s)
print('ACTUAL_CANONICAL_OBSERVER_AND_ORIGINAL_ADMISSION_SEAL_PREPARED_NO_ADMISSION_CLAIM')
