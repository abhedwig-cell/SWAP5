"""Add next source/evidence authorities; original earlier scientific readers stay literal."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');T=R/'tests/nomacro_drainage'
def put(name,s):
 compile(s,name,'exec')
 with (T/name).open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(T/'frost_implicit_plate_inherited_custody.py').read_text().replace('087fc67db3e1e58d45215522eb284e89cb6c12f1','47124f4de18a752fc466d50e2752e843548e5fea').replace('568','600')
put('frost_implicit_hys2_inherited_custody.py',s)
s=(T/'frost_implicit_plate_parent_admission.py').read_text()
s=s.replace('from frost_boundary_state_calendar_parent_admission import archived_commit,parent_admission as prior_admission','from frost_boundary_state_calendar_parent_admission import archived_commit\nfrom frost_implicit_plate_parent_admission import parent_admission as prior_admission')
for old,new in {
 '087fc67db3e1e58d45215522eb284e89cb6c12f1':'47124f4de18a752fc466d50e2752e843548e5fea',
 'e66867c5de454f45fd8d4adde31f68454c61cf9c':'cb5946a6d8205462d96495a39611f72f570db58a',
 '18e31348e7e72fadc564c3046ce3645578bd46b1':'06b31c0ea8d0bb087441be1dab0d1f1ad9236fcc',
 '6ea2618bb8115ba18b1222aa92d18b5f10647af330703faad6a44882ca9f7455':'413af4b36a23ba07972ec04d7ed385ea82d1d4fc46b64e42edeaab7c83a5d6e4',
 '9936bcda75eb920d67aa74e47018baf39ab18f78':'087fc67db3e1e58d45215522eb284e89cb6c12f1',
 'FROST_BOUNDARY_STATE_CALENDAR04':'FROST_IMPLICIT_PLATE05','PR1803':'PR1804',
 "('CANDIDATE','V2',CANDIDATE)":"('CANDIDATE','V1',CANDIDATE)",
 'len(runs)==15':'len(runs)==14','len(checks)==46':'len(checks)==45',
 "sum(x['conclusion']=='success' for x in checks)==29":"sum(x['conclusion']=='success' for x in checks)==28",
 ",'POND'":"",'CANONICAL568':'CANONICAL600','canonical568':'canonical600',
 '15CI_SEVEN_LOGS':'14CI_SIX_LOGS','PRIOR524':'PRIOR568','prior_524_admission':'prior_568_admission',
}.items():
 assert old in s,old
 s=s.replace(old,new)
put('frost_implicit_hys2_parent_admission.py',s)
s=(T/'frost_implicit_plate_source_custody.py').read_text()
s=s.replace('from frost_boundary_state_calendar_source_custody import DOMAINS as PARENT_DOMAINS','from frost_implicit_plate_source_custody import DOMAINS as PARENT_DOMAINS')
s=s.replace('frost_implicit_plate_input_contract','frost_implicit_hys2_input_contract').replace('frost_implicit_plate_metadata','frost_implicit_hys2_metadata')
s=s.replace('087fc67db3e1e58d45215522eb284e89cb6c12f1','47124f4de18a752fc466d50e2752e843548e5fea').replace('87081fd3e70063ae7f60d8606b6d36675257a160','23850bf112e4312745b056e5517b95e13e2af53b')
s=s.replace("SELF='tests/nomacro_drainage/frost_implicit_plate_verify.py'","SELF='tests/nomacro_drainage/frost_implicit_hys2_verify.py'")
s=s.replace('docs/science/NOMACRO_FROST_IMPLICIT_PLATE05.md','docs/science/NOMACRO_FROST_IMPLICIT_HYS2_YEAR06.md')
s=s.replace('FROST_IMPLICIT_PLATE05_CONTRACT','FROST_IMPLICIT_HYS2_YEAR06_CONTRACT')
s=s.replace("adapters=contract['read_only_runtime_witnesses']","adapters=contract.get('read_only_runtime_witnesses',{})")
s=s.replace("before=' import frost_boundary_state_calendar_verify as state_calendar_owner\\n return state_calendar_owner.'+name+'('+args+')\\n'", "before=' import frost_implicit_plate_verify as plate_owner\\n return plate_owner.'+name+'('+args+')\\n'")
s=s.replace("after=' import frost_implicit_plate_verify as plate_owner\\n return plate_owner.'+name+'('+args+')\\n'", "after=' import frost_implicit_hys2_verify as hys2_owner\\n return hys2_owner.'+name+'('+args+')\\n'")
s=s.replace('REAL_IMPLICIT_PLATE_HEAD','REAL_IMPLICIT_HYS2_BOUNDARY_HEAD')
put('frost_implicit_hys2_source_custody.py',s)
print('PREPARED_REAL_SOURCE_CANONICAL600_PARENT_AND_FRESH_INHERITED_AUTHORITIES_NOT_YET_WIRED')
