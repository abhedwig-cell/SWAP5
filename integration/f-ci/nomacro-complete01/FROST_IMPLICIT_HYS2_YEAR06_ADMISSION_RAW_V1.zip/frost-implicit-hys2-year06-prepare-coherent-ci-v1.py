"""Prepare reviewable next-phase files outside the frozen actual-merge checkout."""
from pathlib import Path
E=Path(__file__).resolve().parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
D=E/'FROST_IMPLICIT_HYS2_YEAR06_CI_DRAFT_V1'
D.mkdir(exist_ok=False)
def put(name,s):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):compile(s,name,'exec')
test='tests/nomacro_drainage/'
s=(R/(test+'frost_implicit_plate_input_contract.py')).read_text()
s=s.replace('frost_implicit_plate_metadata','frost_implicit_hys2_metadata').replace('frost_implicit_plate_inputs','frost_implicit_hys2_inputs').replace('FROST_IMPLICIT_PLATE05','FROST_IMPLICIT_HYS2_YEAR06')
s=s.replace("BASE='087fc67db3e1e58d45215522eb284e89cb6c12f1'","BASE='47124f4de18a752fc466d50e2752e843548e5fea'")
s=s.replace("selected['bottom']==8", "selected['bottom']==case['bottom']")
start=s.index("    for kind in ('water','cde'):")
end=s.index('    assert source()[0]==head',start)
s=s[:start]+s[end:]
s=s.replace('ACTUAL_IMPLICIT_PLATE_PUBLIC_DOMAIN','ACTUAL_IMPLICIT_HYS2_BOUNDARY_PUBLIC_DOMAIN')
s=s.replace('Actual public plate input domain','Actual public implicit HYS2 boundary input domain')
put(test+'frost_implicit_hys2_input_contract.py',s)
s=(R/(test+'frost_implicit_plate_inherited_postimages.py')).read_text()
s=s.replace('from frost_implicit_plate_input_contract import source','from frost_implicit_hys2_input_contract import source\nfrom frost_implicit_plate_metadata import read as read_parent')
s=s.replace("head,contract=source();cases=[c for c in contract['representative_cases'] if c['name'] in NAMES];assert len(cases)==4", "head,_=source();contract=read_parent('FROST_IMPLICIT_PLATE05_CONTRACT_V1.json');cases=contract['representative_cases'];assert len(cases)==8")
s=s.replace("            old=Archive(GitArchiveSource(R,head),f'FROST_IMPLICIT_PLATE05_{a.platform.upper()}_{a.optimization}_ORIGINAL_V1',stack)\n            original_projection=json.loads(old.get('COMPILED_PROJECTION_V1.json'))\n            for case in cases:", "            archives={v:Archive(GitArchiveSource(R,head),f'FROST_IMPLICIT_PLATE05_{a.platform.upper()}_{a.optimization}_ORIGINAL_V{v}',stack) for v in (1,2)}\n            for case in cases:\n                old=archives[1 if case['name'] in NAMES else 2]\n                original_projection=json.loads(old.get('COMPILED_PROJECTION_V1.json'))")
s=s.replace('FOUR_CURRENT_UNCHANGED_IMPLICIT_PLATE','EIGHT_CURRENT_UNCHANGED_IMPLICIT_PLATE')
put(test+'frost_implicit_hys2_inherited_postimages.py',s)
for host in ('windows','ubuntu'):
 name=f'.github/workflows/nomacro-frost-implicit-plate05-{host}.yml'
 s=(R/name).read_text().replace('Original implicit Frost plate state/calendar','Original implicit Frost hysteresis2 boundary state/calendar')
 s=s.replace('codex/nomacro-frost-implicit-plate05','codex/nomacro-frost-implicit-hys2-calendar06')
 s=s.replace('nomacro-frost-implicit-plate05','nomacro-frost-implicit-hys2-year06')
 s=s.replace('087fc67db3e1e58d45215522eb284e89cb6c12f1','47124f4de18a752fc466d50e2752e843548e5fea')
 s=s.replace('FROST_IMPLICIT_PLATE05_CONTRACT','FROST_IMPLICIT_HYS2_YEAR06_CONTRACT')
 s=s.replace('frost_implicit_plate_input_contract.py','frost_implicit_hys2_input_contract.py').replace('frost_implicit_plate_inherited_postimages.py','frost_implicit_hys2_inherited_postimages.py').replace('frost_implicit_plate_portable.py','frost_implicit_hys2_portable.py')
 selections=' --case water-b8-i1-h0-p1-regular-r0 --case water-b8-i1-h1-p2-monthly-r1 --case water-b8-i1-h1-p1-dates-r0-year-seam --case cde-b8-i1-h0-p2-monthly-r1-year-seam'
 assert selections in s;s=s.replace(selections,'')
 s=s.replace('frost-implicit-plate05-','frost-implicit-hys2-year06-')
 put(f'.github/workflows/nomacro-frost-implicit-hys2-year06-{host}.yml',s)
print('PREPARED_INPUT_INVERSE_16CASES_UNCHANGED8_POSTIMAGES_AND_FOUR_COHERENT_SCIENTIFIC_JOBS',D)
