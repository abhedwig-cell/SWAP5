"""Prepare distinct future observer/control controllers; do not execute any gate."""
from pathlib import Path
E=Path(__file__).resolve().parent
s=(E/'frost-implicit-plate05-actual-merge-observer-v1.py').read_text()
s=s.replace('FROST_IMPLICIT_PLATE05_ACTUAL_MERGE_','FROST_IMPLICIT_HYS2_YEAR06_CANDIDATE_')
s=s.replace("['contexts']==600","['contexts']==648")
observer=E/'frost-implicit-hys2-year06-actual-candidate-observer-v1.py'
with observer.open('x',encoding='utf8',newline='\n') as f:f.write(s)
compile(s,str(observer),'exec')
s=(E/'frost-implicit-plate05-real-negative-controls-v1.py').read_text()
s=s.replace('FROST_IMPLICIT_PLATE05','FROST_IMPLICIT_HYS2_YEAR06')
s=s.replace('codex/nomacro-frost-implicit-plate-negative-','codex/nomacro-frost-implicit-hys2-negative-')
s=s.replace("'RAW':'integration/f-ci/nomacro-complete01/FROST_IMPLICIT_HYS2_YEAR06_UBUNTU_O0_ORIGINAL_V2.zip.part001'", "'RAW':'integration/f-ci/nomacro-complete01/'+json.loads((R/'integration/f-ci/nomacro-complete01/FROST_IMPLICIT_HYS2_YEAR06_UBUNTU_O0_ORIGINAL_V1.json').read_text())['parts'][0]['file']")
assert 'ORIGINAL_V2.zip.part001' not in s
s=s.replace("before=b\"selected['bottom']==8\";assert original.count(before)==1;changed=original.replace(before,b\"selected['bottom']==5\",1)", "before=b\"selected['bottom']==5\";assert original.count(before)==1;changed=original.replace(before,b\"selected['bottom']==6\",1)")
s=s.replace('Wrong actual trial guard dispatch boundary5 in place of qualified plate8','Wrong actual implicit5 trial dispatch to unqualified boundary6')
s=s.replace("run(['git','switch','codex/nomacro-frost-implicit-plate05'])", "run(['git','switch','codex/nomacro-frost-implicit-hys2-calendar06'])")
out=E/'frost-implicit-hys2-year06-real-negative-controls-v1.py'
with out.open('x',encoding='utf8',newline='\n') as f:f.write(s)
compile(s,str(out),'exec')
s=(E/'frost-implicit-plate05-preserve-original-ci-artifact-v1.py').read_text().replace('FROST_IMPLICIT_PLATE05_','FROST_IMPLICIT_HYS2_YEAR06_')
out=E/'frost-implicit-hys2-year06-preserve-original-ci-artifact-v1.py'
with out.open('x',encoding='utf8',newline='\n') as f:f.write(s)
compile(s,str(out),'exec')
print('PREPARED_FUTURE_ACTUAL_CANDIDATE_ORDINARY_PUBLICATION_FOUR_REAL_NEGATIVES_AND_ORIGINAL_ARTIFACT_SEALER_NO_GATE_EXECUTED')
