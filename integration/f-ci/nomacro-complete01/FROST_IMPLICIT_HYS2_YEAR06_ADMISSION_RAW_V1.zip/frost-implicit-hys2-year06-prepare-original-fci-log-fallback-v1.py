"""Prepare the proven original HTTP log fallback without executing it."""
from pathlib import Path
E=Path(__file__).resolve().parent
s=(E/'frost-implicit-plate05-original-fci-log-download-v1.py').read_text()
for before,after in {
 '139554672878':'139592531898','45711785942':'45722785636',
 'FROST_IMPLICIT_PLATE05_PR1804':'FROST_IMPLICIT_HYS2_YEAR06_PR1805',
 'cb5946a6d8205462d96495a39611f72f570db58a':'cb712974e37e41256877d9770a0af071afe241dd',
 '06b31c0ea8d0bb087441be1dab0d1f1ad9236fcc':'c65c7eb92cdc82ab786f62cb96bf376404e45130',
}.items():
 assert before in s,before;s=s.replace(before,after)
out=E/'frost-implicit-hys2-year06-original-fci-log-download-v1.py'
with out.open('x',encoding='utf8',newline='\n') as f:f.write(s)
compile(s,str(out),'exec');print('ORIGINAL_HTTP_FCI_LOG_FALLBACK_PREPARED_NOT_EXECUTED')
