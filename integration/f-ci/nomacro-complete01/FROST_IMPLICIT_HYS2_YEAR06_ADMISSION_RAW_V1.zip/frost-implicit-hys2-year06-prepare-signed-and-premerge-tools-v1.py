"""Prepare distinct genuine signed-object and final closure tools."""
from pathlib import Path
E=Path(__file__).resolve().parent
def put(name,s):
 compile(s,name,'exec')
 with (E/name).open('x',encoding='utf8',newline='\n') as f:f.write(s)
s=(E/'frost-implicit-plate05-genuine-signed-object-import-v1.py').read_text().replace('FROST_IMPLICIT_PLATE05_PR1804','FROST_IMPLICIT_HYS2_YEAR06_PR1805')
put('frost-implicit-hys2-year06-genuine-signed-object-import-v1.py',s)
s=(E/'frost-implicit-plate05-premerge-closure-v1.py').read_text()
for before,after in {
 'FROST_IMPLICIT_PLATE05':'FROST_IMPLICIT_HYS2_YEAR06','PR1804':'PR1805',
 'cb5946a6d8205462d96495a39611f72f570db58a':'cb712974e37e41256877d9770a0af071afe241dd',
 '087fc67db3e1e58d45215522eb284e89cb6c12f1':'47124f4de18a752fc466d50e2752e843548e5fea',
 '06b31c0ea8d0bb087441be1dab0d1f1ad9236fcc':'c65c7eb92cdc82ab786f62cb96bf376404e45130',
 "['contexts']==600":"['contexts']==648",
}.items():
 assert before in s,before;s=s.replace(before,after)
put('frost-implicit-hys2-year06-premerge-closure-v1.py',s)
print('GENUINE_SIGNED_OBJECT_IMPORT_AND_FINAL_PREMERGE_TOOLS_PREPARED_NO_IDENTITY_PROJECTION')
