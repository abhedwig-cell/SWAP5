"""Persist original successful O0 artifacts while O2 remains genuinely pending."""
from pathlib import Path
import json,subprocess,shutil
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
paths=[]
for host in ('WINDOWS','UBUNTU'):
 stem=f'FROST_IMPLICIT_HYS2_YEAR06_{host}_O0_ORIGINAL_V1'
 q=json.loads((P/(stem+'.json')).read_text());assert q['actual_scientific_source']=='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6'
 paths.extend([P/(stem+'.json'),*(P/x['file'] for x in q['parts'])])
 name=f'FROST_IMPLICIT_HYS2_YEAR06_{host}_ORIGINAL_ARTIFACTS_API_V1.json';shutil.copyfile(E/name,P/name);paths.append(P/name)
name='FROST_IMPLICIT_HYS2_YEAR06_SCIENTIFIC_JOBS_API_V1.json';shutil.copyfile(E/name,P/name);paths.append(P/name)
path=P/'GAP_MATRIX.json';g=json.loads(path.read_text());g['frost_implicit_plate05'].update(status='ACTUAL_CANONICAL600_ADMITTED_ALL32_AND_CURRENT16_WHOLE_OBJECT_POSTIMAGES',canonical_admission=True,actual_canonical='47124f4de18a752fc466d50e2752e843548e5fea',admission_receipt='FROST_IMPLICIT_PLATE05_MERGE_RECEIPT_V1.json',next_code_action='Continue coherent implicit HYS2 bottom5/8 calendars/year batch06; original day5 diagnosis and local scientific evidence preserved.')
g['frost_implicit_hys2_year06']=dict(classification=['MISSING_COMPOSITION','NUMERICAL_FAILURE','OVERRESTRICTIVE_GUARD'],status='IMPLEMENTED_LOCAL_FOUR_PASS_WINDOWS_UBUNTU_O0_ORIGINAL_CI_SUCCESS_O2_IN_PROGRESS_FULL64_NOT_YET_INDEPENDENTLY_QUALIFIED',contract='FROST_IMPLICIT_HYS2_YEAR06_CONTRACT_V1.json',actual_scientific_source='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6',local_actual_scientific_source='23850bf112e4312745b056e5517b95e13e2af53b',new_contexts=48,requalified_contexts=16,planned_total=64,unchanged_build_only_postimages=32,original_failure_preserved=True,scientific_qualification='NOT_QUALIFIED',canonical_admission=False)
g['next_coherent_batches'][0]['status']='Current06 implementation and local4 independent audit pass; actual Windows/Ubuntu O0 original scientific cohorts successful and preserved; O2 remains running. Audit entire64 matrix and32 unchanged postimages before public/canonical admission.'
g['next_coherent_batches'][1]['status']='Original120-trial evidence already localizes internal versus prescribed bottom flux mismatch; endpoint storage jump is zero in those runtime trials. Explicit scientific decision about simultaneous head/flux semantics remains required. Keep route refused; no repeat merely to rediscover the same cause.'
path.write_text(json.dumps(g,indent=2)+'\n');paths.append(path)
path=P/'STATUS.json';s=json.loads(path.read_text());s['frost_implicit_hys2_year06'].update(actual_scientific_O0_jobs='WINDOWS_AND_UBUNTU_SUCCESS_ORIGINAL_ARTIFACTS_PRESERVED',actual_scientific_O2_jobs='IN_PROGRESS',full64_independent_qualification=False)
s['recovery_point']='Actual canonical600 admission complete.06 physical source23850 unchanged on scientific producera4f24f74f3. Windows/Ubuntu O0 original artifacts207262304B/203980101B preserved with official SHA and36923members each; O2 existing runs45718884480/45718884532 still in progress. Independent complete64 audit, final source freeze/public/negative/canonical gates remain pending.'
path.write_text(json.dumps(s,indent=2)+'\n');paths.append(path)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--sparse','--',*[p.relative_to(R).as_posix() for p in paths]],cwd=R,check=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Preserve original Windows and Ubuntu HYS2 O0 artifacts with pending O2 recovery'],cwd=R,check=True)
