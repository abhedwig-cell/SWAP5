"""Commit all original portable evidence before the independent full-matrix audit."""
from pathlib import Path
import json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
paths=[]
for host in ('WINDOWS','UBUNTU'):
 stem=f'FROST_IMPLICIT_HYS2_YEAR06_{host}_O2_ORIGINAL_V1';q=json.loads((P/(stem+'.json')).read_text())
 assert len(q['members'])==36923 and q['actual_scientific_source']=='a4f24f74f3b5b82b2673f2695d15fe7ba3990fd6'
 paths.extend([P/(stem+'.json'),*(P/x['file'] for x in q['parts'])])
 name=f'FROST_IMPLICIT_HYS2_YEAR06_{host}_ORIGINAL_ARTIFACTS_API_V2.json';shutil.copyfile(E/name,P/name);paths.append(P/name)
name='FROST_IMPLICIT_HYS2_YEAR06_SCIENTIFIC_OFFICIAL_API_V2.json';q=json.loads((E/name).read_text())
assert len(q['runs'])==2 and all(x['run']['status']=='completed' and x['run']['conclusion']=='success' and len(x['jobs']['jobs'])==2 and all(j['conclusion']=='success' for j in x['jobs']['jobs']) for x in q['runs'])
shutil.copyfile(E/name,P/name);paths.append(P/name)
path=P/'STATUS.json';s=json.loads(path.read_text());s['canonical']='47124f4de18a752fc466d50e2752e843548e5fea';s['branch']=s['working_branch']=s['active_branch']='codex/nomacro-frost-implicit-hys2-calendar06';s['last_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();s['last_commit_role']='PRECEDING_PERSISTED_CHECKPOINT_NOT_SCIENTIFIC_PRODUCER'
for x in s['running_ci']:x['status']='COMPLETED_SUCCESS'
s['frost_implicit_hys2_year06'].update(actual_scientific_O2_jobs='WINDOWS_AND_UBUNTU_SUCCESS_ORIGINAL_ARTIFACTS_PRESERVED',scientific_qualification='FOUR_PORTABLE_CI_COHORTS_PASS_FULL64_INDEPENDENT_ORIGINAL_BYTE_AUDIT_PENDING',full64_independent_qualification=False)
s['next_action']=s['next_code_change']='Run independent original-byte complete64 science and32 whole-object postimage audit at fixed actual HEAD. Preserve any reader failure; no model replay for read-only corrections. Then freeze actual source, wire joint authority, genuine clean PUBLIC/PUB, four committed negative controls and selected canonical admission CI.'
s['recovery_point']='All four actual scientific jobs on a4f24f74f3 SUCCESS; four official original ZIPs and their36923members each have verified official sizes/SHA and original producer identities. O2 plus O0 originals persisted before independent64/32 audit. Actual canonical600 remains47124; wholePARTIAL/NOT_QUALIFIED.'
path.write_text(json.dumps(s,indent=2)+'\n');paths.append(path)
path=P/'GAP_MATRIX.json';g=json.loads(path.read_text());g['frost_implicit_hys2_year06']['status']='ALL_FOUR_ACTUAL_PORTABLE_CI_COHORTS_SUCCESS_ORIGINAL_ARCHIVES_PRESERVED_INDEPENDENT64_AND32_POSTIMAGE_AUDIT_PENDING';g['next_coherent_batches'][0]['status']='All four original Windows/Ubuntu O0/O2 cohorts succeed and are preserved; independent64 science/32 postimage audit and actual public/canonical admission remain pending.';path.write_text(json.dumps(g,indent=2)+'\n');paths.append(path)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--sparse','--',*[p.relative_to(R).as_posix() for p in paths]],cwd=R,check=True)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Preserve all original HYS2 O0 O2 portable cohorts before independent qualification'],cwd=R,check=True)
