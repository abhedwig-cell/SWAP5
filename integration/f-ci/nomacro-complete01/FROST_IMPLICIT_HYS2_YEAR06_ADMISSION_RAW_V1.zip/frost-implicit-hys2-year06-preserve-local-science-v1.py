"""Preserve the true pre-canonical producer of four actual local public probes."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive,SHA
source='23850bf112e4312745b056e5517b95e13e2af53b';base='087fc67db3e1e58d45215522eb284e89cb6c12f1';name='FROST_IMPLICIT_HYS2_YEAR06_LOCAL_WINDOWS_O0_O2_RAW_V1';files={};projection={};contexts=[];provider={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==source
def add(root,prefix):
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():files[prefix+'/'+p.relative_to(root).as_posix()]=p
data=W/'frost-implicit-hys2-year06-local-science-v1';add(data,'current')
with ExitStack() as stack:
 old=Archive(GitArchiveSource(R,base),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
 for opt in ['O0','O2']:
  build_root=W/f'frost-implicit-hys2-year06-local-{opt}-v1';add(build_root,'compiled/'+opt)
  for phase in ['year','water']:
   q=json.loads((data/(opt+'-'+phase)/'RESULT.json').read_text());assert q['source']==source and q['status']=='ACTUAL_SELECTED_IMPLICIT_HYS2_BOUNDARY_PERIODS_NATIVE_COLD_AND_CONTROLS_PASS_NOT_ADMITTED' and len(q['contexts'])==1
   item=q['contexts'][0];assert item['convergence']['unconverged_continuations']==0 and (item['case']['days']!=35 or item['controls'] is not None)
   b=build_root/item['case']['name']/'bundle';meta=json.loads((b/'BUILD.json').read_text());i=meta['identity'];projection[str(b)]=dict(archive_prefix='compiled/'+opt+'/'+item['case']['name']+'/bundle',actual_BUILD_sha256=SHA((b/'BUILD.json').read_bytes()))
   for key,folder in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
    for n,digest in i[key].items():
     member='original-provider-build/'+folder+'/'+n;raw=old.get(member);assert SHA(raw)==digest and raw==(J/'build'/folder/n).read_bytes();provider[member]=dict(bytes=len(raw),sha256=digest)
   member='original-provider-build/ttutil-obj/libttutil.a';raw=old.get(member);assert SHA(raw)==i['ttutil_library'] and raw==(J/'build/ttutil-obj/libttutil.a').read_bytes();provider[member]=dict(bytes=len(raw),sha256=SHA(raw))
   contexts.append(dict(optimization=opt,phase=phase,case=item['case'],source=source,compiler=i['compiler'],BUILD_sha256=SHA((b/'BUILD.json').read_bytes()),convergence=item['convergence']))
 dependency=dict(archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',sha256=old.record['sha256'],actual_data_revision=base,actual_required_files=provider)
add(E/'FROST_IMPLICIT_HYS2_YEAR06_LOCAL_SOURCE_CAPSULE_V1','source');assert json.loads((E/'FROST_IMPLICIT_HYS2_YEAR06_LOCAL_SOURCE_CAPSULE_V1/RESULT.json').read_text())['producer_head']==source
target=E/('FROST_IMPLICIT_HYS2_YEAR06_ACTUAL_LOCAL_GIT_SOURCE_'+source+'.tar');assert not target.exists();subprocess.run(['git','archive','--format=tar','--output='+str(target),source,'--','app','src','tools','tests','.github'],cwd=R,check=True);files['git-source/'+target.name]=target
target=E/('FROST_IMPLICIT_HYS2_YEAR06_ACTUAL_LOCAL_COMMIT_'+source+'.bin');target.write_bytes(subprocess.check_output(['git','cat-file','commit',source],cwd=R));assert hashlib.sha1(b'commit '+str(target.stat().st_size).encode()+b'\0'+target.read_bytes()).hexdigest()==source;files['git-source/'+target.name]=target
for n,value in [('COMPILED_PROJECTION_V1.json',projection),('FROST_IMPLICIT_HYS2_YEAR06_LOCAL_PROVIDER_DEPENDENCY_V1.json',dependency)]:
 target=E/('FROST_IMPLICIT_HYS2_YEAR06_LOCAL_'+n if n.startswith('COMPILED') else n);target.write_text(json.dumps(value,indent=2)+'\n');files[n]=target
files['controllers/'+Path(__file__).name]=Path(__file__);members={};archive=E/(name+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(files.items()):
  raw=p.read_bytes();z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
 for n,v in members.items():raw=z.read(n);assert len(raw)==v['bytes'] and SHA(raw)==v['sha256']
raw=archive.read_bytes();chunk=25*1024*1024;parts=[]
for index,offset in enumerate(range(0,len(raw),chunk),1):
 piece=raw[offset:offset+chunk];n=name+'.zip'+('.part'+str(index).zfill(3) if len(raw)>chunk else '');(P/n).write_bytes(piece);parts.append(dict(file=n,bytes=len(piece),sha256=SHA(piece)))
q=dict(status='FOUR_ACTUAL_PUBLIC_HYS2_YEAR12_AND_CHANGED_IMPLICIT5_WATER35_NATIVE_COLD_CONTROLS_RAW_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,contexts=contexts,actual_scientific_source=source,original_provider_dependency=dependency,pre_dependency_canonical_admission_producer=True,source_identity_rebound=False,canonical_admission=False,whole_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED')
for root in [P,E]:(root/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],len(raw),q['sha256'],len(members),flush=True)
