"""Reconcile canonical admission and next scientific batch without rebinding raw producers."""
from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *x:subprocess.check_output(['git',*x],cwd=R).decode().strip()
M='47124f4de18a752fc466d50e2752e843548e5fea'
assert git('branch','--show-current')=='codex/nomacro-frost-implicit-hys2-calendar06'
assert subprocess.run(['git','merge-base','--is-ancestor',M,'HEAD'],cwd=R).returncode==0
receipt=json.loads((P/'FROST_IMPLICIT_PLATE05_MERGE_RECEIPT_V1.json').read_text())
assert receipt['actual_merge']==M and receipt['canonical_admission'] and receipt['coadmission']['contexts']==600
for p in (E/'FROST_IMPLICIT_HYS2_YEAR06_CI_DRAFT_V1').rglob('*'):
 if p.is_file():
  target=R/p.relative_to(E/'FROST_IMPLICIT_HYS2_YEAR06_CI_DRAFT_V1');assert not target.exists();shutil.copyfile(p,target)
path=P/'FROST_IMPLICIT_HYS2_YEAR06_CONTRACT_V1.json';c=json.loads(path.read_text())
assert c['actual_local_scientific_source']=='23850bf112e4312745b056e5517b95e13e2af53b'
c.update(actual_canonical_dependency=M,dependency_canonical_admission_pending=False,dependency_admission_receipt='FROST_IMPLICIT_PLATE05_MERGE_RECEIPT_V1.json',dependency_admission_archive_sha256=receipt['admission_archive_sha256'],unchanged_implicit8_postimage_contexts=32,
 next_code_action='Run complete real public input domain/source inverse, then coherent Windows/Ubuntu O0/O2 sixteen-case scientific cohorts and eight unchanged implicit8 build-only postimages per job. Preserve all original failures and actual producers. No model replay for ancestry/metadata reconciliation.')
path.write_text(json.dumps(c,indent=2)+'\n')
path=P/'STATUS.json';s=json.loads(path.read_text())
for key in ('canonical_head','current_canonical_sha','canonical_baseline'):s[key]=M
s['active_branch']=git('branch','--show-current')
s['frost_implicit_plate05'].update(status='ACTUAL_CANONICAL600_ADMISSION_VERIFIED',qualification='BOUNDED_SOURCE_SCIENCE_AND_CANONICAL_ADMISSION_VERIFIED',canonical_admission=True,actual_canonical=M,current_admitted_contexts=600,actual_public_seconds=733.8576745996252,actual_ordinary_publication_seconds=505.683720999863,admission_archive='FROST_IMPLICIT_PLATE05_ADMISSION_RAW_V1.json',admission_archive_sha256=receipt['admission_archive_sha256'],next_code_action='Continue coherent implicit hysteresis2 boundary5/8 calendar/year batch06.')
s['frost_implicit_hys2_year06'].update(dependency_canonical_admission_pending=False,actual_canonical_dependency=M,local_independent_original_byte_audit='FROST_IMPLICIT_HYS2_YEAR06_LOCAL_INDEPENDENT4_V1.json',next_code_action=c['next_code_action'])
s['coverage_batch_report'].update(actual_canonical=M,bounded_coadmission_contexts=600,new_current_batch_contexts=32,repaired_previous_plate_contexts=16,important_added_capabilities='Original implicit plate Frost water/CDE state, calendars and year seams with actual trial flux and exact original pending-date restart semantics.',next_implementation_batch='Implicit hysteresis2 bottom5/8 calendars/year seams:64 science contexts (48new+16changed old),32 unchanged implicit8 build-only postimages. Full matrix NOT_QUALIFIED.')
s['next_code_change']=s['next_action']=c['next_code_action']
s['recovery_point']='Actual canonical47124 admitted600: exact signed M/S, candidate and actual clean14/56 PUBLIC/PUB,14CI/45checks/four real negatives sealed in413af4b3 archive. Normal merge into06 preserves original local scientific producer23850 and all original failed/diagnostic bytes. Next complete input inverse and coherent64 matrix; no metadata-only model replay.'
s['completed'].append('PR1804 actualcanonical47124f4de18a752fc466d50e2752e843548e5fea admits bounded600; actual clean14/56 PUBLIC733.857675s and ordinaryPUB505.683721s PASS,14workflowsSUCCESS/28checksPASS17skip, four real committed pushed negatives refused; original134member admission archive8873418B SHA413af4b36a23ba07972ec04d7ed385ea82d1d4fc46b64e42edeaab7c83a5d6e4. WholePARTIAL/NOT_QUALIFIED/familygapUNKNOWN/fixedRC3unchanged.')
path.write_text(json.dumps(s,indent=2)+'\n')
for p in (R/'tests/nomacro_drainage').glob('frost_implicit_hys2*.py'):compile(p.read_text(),str(p),'exec')
print('CANONICAL600_RECONCILED_ORIGINAL23850_LOCAL_SOURCE_PRESERVED_COHERENT64_AND32_POSTIMAGE_GATES_READY')
