"""Real original component, actual-trial receipt; diagnostic, not admission."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
A=W/'frost-implicit-hys2-year06-original-failure-v1';B=A/'original-bundle';J=A/'original-provider-build'
D=A/'trial-flux-counterfactual-v1';D.mkdir()
S=lambda b:hashlib.sha256(b).hexdigest();meta=json.loads((B/'BUILD.json').read_text())
sys.path.insert(0,str(R/'app/hybrid_water'))
from frost_boundary_terminal_trial import receipt_source,IMPORT,TRIAL_IMPORT,GUARD
def head_source(text):
 assert text.count(IMPORT)==text.count(GUARD)==1
 return text.replace(IMPORT,TRIAL_IMPORT,1).replace(GUARD,'            if(abs(terminal_water_trial_residual(-kmean(NN+1)*hgrad(NN+1)))>1d-10)flnonconv=.true.',1)
for name,render in [('terminal_water_receipt',receipt_source),('headcalc',head_source)]:
 original=(B/(name+'.f90')).read_bytes();assert S(original)==meta['identity']['donor_generated'][name+'.f90']
 (D/(name+'.f90')).write_text(render(original.decode('cp1252').replace('\r\n','\n')),encoding='cp1252')
env=dict(os.environ,OMP_NUM_THREADS='1',PATH='C:/msys64/ucrt64/bin;'+os.environ.get('PATH',''));compiler=shutil.which('gfortran',path=env['PATH'])
commands=[]
def run(cmd):
 commands.append(cmd);p=subprocess.run(cmd,cwd=D,env=env,capture_output=True)
 (D/f'compiler-{len(commands)}.stdout').write_bytes(p.stdout);(D/f'compiler-{len(commands)}.stderr').write_bytes(p.stderr);p.check_returncode()
started=time.perf_counter()
for name in ['terminal_water_receipt','headcalc']:
 run([compiler,*meta['identity']['donor_flags'],'-I',str(D),'-I',str(B),'-I',str(J/'swap-obj'),'-I',str(J/'ttutil-obj'),'-c',name+'.f90'])
objects={p.name:p for p in (J/'swap-obj').glob('*.o')};objects.update({p.name:p for p in B.glob('*.o')});objects.update({p.name:p for p in D.glob('*.o')})
exe=D/'day_donor_trial_flux.exe';run([compiler,'-o',str(exe),*[str(objects[n]) for n in sorted(objects)],str(J/'ttutil-obj/libttutil.a')]);compile_seconds=time.perf_counter()-started
O=D/'actual-worker';O.mkdir()
for name in meta['inputs']:
 target=O/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((A/'original-donor-replay-v1'/name).read_bytes())
request=b''.join((str(day)+' -1\n').encode() for day in range(1,13))+b'0 -1\n';(O/'donor.request').write_bytes(request);error=None;code=None;started=time.perf_counter()
try:
 with (O/'donor.stdout').open('xb') as out,(O/'donor.stderr').open('xb') as err:
  p=subprocess.run([str(exe),'./swap.swp'],cwd=O,env=env,input=request,stdout=out,stderr=err,timeout=180);code=p.returncode
except subprocess.TimeoutExpired:error='EXPLICIT_180_SECOND_DIAGNOSTIC_CENSOR'
stdout=(O/'donor.stdout').read_bytes();warnings=[]
for p in O.rglob('*'):
 if p.is_file() and p.suffix.lower() in {'.wrn','.war','.log','.err','.stderr'}:
  warnings.extend(dict(file=str(p.relative_to(O)),line=l) for l in p.read_text(errors='replace').splitlines() if 'No convergence was reached' in l)
report=dict(status='TRIAL_FLUX_COUNTERFACTUAL_COMPONENT_DIAGNOSTIC_NOT_QUALIFIED',actual_collection_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),original_source='dcae412aae8f65acb48b1e37431334c2c522c071',original_compiler=meta['identity']['compiler'],actual_compiler=subprocess.check_output([compiler,'--version'],env=env).decode().splitlines()[0],actual_compiler_sha256=S(Path(compiler).read_bytes()),mixed_compiler=True,commands=commands,compiled_source_sha256={n:S((D/n).read_bytes()) for n in ['headcalc.f90','terminal_water_receipt.f90']},linked_objects={n:dict(path=str(p),sha256=S(p.read_bytes())) for n,p in objects.items()},executable_sha256=S(exe.read_bytes()),original_timecontrol_sha256=S((B/'timecontrol.f90').read_bytes()),original_timecontrol_unchanged=True,donor_returned_days=sum(l.startswith(b'HYBRID_DAY_RETURN') for l in stdout.splitlines()),returncode=code,error=error,convergence_warnings=warnings,compile_link_seconds=compile_seconds,model_seconds=time.perf_counter()-started,kernel_accepted_days=0,public_admission=False,checkpoint_publication=False,physical_equations_state_retry_limits_tolerances_changed=False)
for root in [D,E]:(root/'FROST_IMPLICIT_HYS2_YEAR06_TRIAL_FLUX_COUNTERFACTUAL_V1.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'commands','linked_objects'}},indent=2),flush=True)
