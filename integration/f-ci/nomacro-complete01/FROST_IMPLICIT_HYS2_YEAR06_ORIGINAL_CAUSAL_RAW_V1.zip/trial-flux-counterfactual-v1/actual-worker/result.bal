* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-25 23:18:18

Period             :  2002-12-26  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        79.62 cm       0.4800E+02 mg/cm2
Initial :        97.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -17.57 cm       0.4800E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :     5.26    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :   -25.21    Soil evaporation  :     0.02
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :   -17.55    Sum               :     0.02


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.8058E-10
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.0000E+00

