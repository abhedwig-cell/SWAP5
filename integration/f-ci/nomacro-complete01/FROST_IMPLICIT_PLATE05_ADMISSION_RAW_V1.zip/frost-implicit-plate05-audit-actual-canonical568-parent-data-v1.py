"""Explicit real canonical data revision, never projected current source."""
from pathlib import Path
import json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_boundary_git_archive import GitArchiveSource
from frost_boundary_state_calendar_central import audit
from frost_boundary_state_calendar_postimage_custody import audit as postimages
from frost_boundary_state_calendar_verify import frozen
base='087fc67db3e1e58d45215522eb284e89cb6c12f1';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();data=GitArchiveSource(R,base)
science=audit(data);assert science==frozen('FROST_BOUNDARY_STATE_CALENDAR04_COMPLETE52_CENTRAL_V1');print('INDEPENDENT_GENUINE_CANONICAL568_PARENT52_SCIENCE_PASS',flush=True)
objects=postimages(data,comparison_revision=base);assert objects==frozen('FROST_BOUNDARY_STATE_CALENDAR04_CURRENT16_POSTIMAGE_CENTRAL_V1')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==head
q=dict(status='ACTUAL_CANONICAL568_PARENT52_SCIENCE_AND_ORIGINAL16_WHOLE_OBJECT_POSTIMAGES_PASS',actual_auditor_source=head,actual_historical_data_revision=base,source_or_namespace_or_filesystem_projection=False,science=science,postimages=objects,compiler_executions=0,model_executions=0)
(E/'FROST_IMPLICIT_PLATE05_ACTUAL_CANONICAL568_PARENT_AUDIT_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],flush=True)
