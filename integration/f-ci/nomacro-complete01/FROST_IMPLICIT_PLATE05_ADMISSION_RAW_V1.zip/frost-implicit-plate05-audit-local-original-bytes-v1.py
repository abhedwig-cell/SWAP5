"""Independent current auditor reads the sealed original public local bytes."""
from pathlib import Path
from contextlib import ExitStack
import json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
from frost_implicit_plate_archive_science import case_audit
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
auditor='tests/nomacro_drainage/frost_implicit_plate_archive_science.py'
actual=(R/auditor).read_bytes().replace(b'\r\n',b'\n')
assert subprocess.check_output(['git','show',head+':'+auditor],cwd=R)==actual
results=[]
with ExitStack() as stack:
 store=Archive(P,'FROST_IMPLICIT_PLATE05_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
 provider=Archive(GitArchiveSource(R,'087fc67db3e1e58d45215522eb284e89cb6c12f1'),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
 for opt in ['O0','O2']:
  batch=json.loads(store.get('current/'+opt+'/RESULT.json'))
  for item in batch['contexts']:
   case=item['case'];q=case_audit(store,opt+'/'+case['name'],case,provider,batch['source'],opt);results.append(q)
   print('INDEPENDENT_ACTUAL_LOCAL_IMPLICIT_PLATE_PASS',opt,case['name'],flush=True)
q=dict(status='INDEPENDENT_FOUR_ACTUAL_PUBLIC_LOCAL_IMPLICIT_PLATE_ORIGINAL_BUDGETS_NATIVE_COLD_REFUSAL_TRANSACTIONS_AND_COMPLETE_SOURCE_AUDIT_PASS_NOT_ADMITTED',actual_auditor_source=head,actual_auditor_lf_sha256=SHA(actual),actual_external_controller_sha256=SHA(Path(__file__).read_bytes()),contexts=results,compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'FROST_IMPLICIT_PLATE05_LOCAL_INDEPENDENT4_V1.json').write_text(json.dumps(q,indent=2)+'\n');(P/'FROST_IMPLICIT_PLATE05_LOCAL_INDEPENDENT4_V1.json').write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],flush=True)
