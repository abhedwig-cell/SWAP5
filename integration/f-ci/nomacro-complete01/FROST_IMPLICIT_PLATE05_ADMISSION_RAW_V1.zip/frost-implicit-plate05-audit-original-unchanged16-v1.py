"""Audit the exact original full35 records selected for later current custody."""
from pathlib import Path
from contextlib import ExitStack
import json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
from frost_implicit_plate_archive_science import case_audit
from frost_implicit_plate_inherited_postimages import NAMES
from frost_calendar_state_portable_custody import source as custody
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();cases=json.loads((P/'FROST_IMPLICIT_PLATE05_CONTRACT_V1.json').read_text())['representative_cases'];results=[];sources=[]
with ExitStack() as stack:
 for host in ['WINDOWS','UBUNTU']:
  for opt in ['O0','O2']:
   store=Archive(GitArchiveSource(R,head),f'FROST_IMPLICIT_PLATE05_{host}_{opt}_ORIGINAL_V1',stack)
   producer=store.record['actual_scientific_source'];_,proof=custody(store,stack,producer,producer,f'.github/workflows/nomacro-frost-implicit-plate05-{host.lower()}.yml');sources.append(proof)
   for case in cases:
    if case['name'] not in NAMES:continue
    result=case_audit(store,case['name'],case,store,producer,opt);results.append(dict(platform=host,**result));print('INDEPENDENT_ORIGINAL_IMPLICIT_PLATE_FULL35_PASS',host,opt,case['name'],flush=True)
assert len(results)==16
q=dict(status='INDEPENDENT_ORIGINAL16_FULL35_SCIENCE_PASS_CURRENT_POSTIMAGE_CUSTODY_STILL_REQUIRED_NOT_ADMITTED',actual_auditor_source=head,actual_auditor_lf_sha256=SHA((R/'tests/nomacro_drainage/frost_implicit_plate_archive_science.py').read_bytes().replace(b'\r\n',b'\n')),actual_external_controller_sha256=SHA(Path(__file__).read_bytes()),contexts=results,source_and_original_provider_custody=sources,compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'FROST_IMPLICIT_PLATE05_ORIGINAL_UNCHANGED16_INDEPENDENT_V1.json').write_text(json.dumps(q,indent=2)+'\n');(P/'FROST_IMPLICIT_PLATE05_ORIGINAL_UNCHANGED16_INDEPENDENT_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],flush=True)
