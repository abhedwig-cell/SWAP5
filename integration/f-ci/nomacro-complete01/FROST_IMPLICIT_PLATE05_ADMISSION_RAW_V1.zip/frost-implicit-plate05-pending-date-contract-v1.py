"""Record original failed native frames and exact proposed guard closure."""
from pathlib import Path
import difflib,hashlib,io,json,struct,subprocess,sys,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';S=lambda b:hashlib.sha256(b).hexdigest();base='087fc67db3e1e58d45215522eb284e89cb6c12f1'
sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage')]
from frost_implicit_plate_calendar import GUARD,source,original_source
from original_output_thermal import render_integral
from cde_interval_output import render_integral as chemical
archive=E/'FROST_IMPLICIT_PLATE05_UBUNTU_O0_ORIGINAL_V1.zip';assert S(archive.read_bytes())=='9f401703b1ba49a91ab41dcc37bd90d98947fbd97478dbc2c0eb04b67f28f73c'
prefix='current/water-b8-i1-h1-p1-dates-r0-year-seam/'
with zipfile.ZipFile(archive) as z:
 profile=json.loads(z.read(prefix+'science/RESULT.json'));assert profile['trajectory']['days']==12 and len(profile['own'])==0
 stderr=z.read(prefix+'science/own-2/original/donor.stderr');assert b'Inconsistent original interval date pointer' in stderr
 projection=json.loads(z.read('COMPILED_PROJECTION_V1.json'));b=projection[profile['build_root']]['archive_prefix'];meta=json.loads(z.read(b+'/BUILD.json'));frames=[]
 for day in [2,12]:
  with zipfile.ZipFile(io.BytesIO(z.read(prefix+f'science/trajectory/accepted-column-1-day-{day}.zip'))) as checkpoint:raw=checkpoint.read('macro.bin')
  found=[]
  for at in range(0,len(raw)-160,4):
   if struct.unpack_from('<2i',raw,at)!=(1,34):continue
   h=struct.unpack_from('<20i',raw,at)
   if h[3]>100 and h[4:6]==(0,1) and raw[at:at+80]==raw[at+80:at+160]:found.append(h)
  assert len(found)==1 and found[0][6]==day and found[0][10]==1
  frames.append(dict(day=day,actual_native_calendar_header=found[0],actual_original_interval_date_pointer=found[0][10],stale_dates_before_immutable_start=3,former_guard_expected_pointer=4 if day==2 else 6))
 original=z.read('original-provider-build/swap-selected/integral.f90').decode('cp1252').replace('\r\n','\n');water=render_integral(original,None,meta['identity']['original_output'])
 assert water==z.read(b+'/integral.f90').decode('cp1252').replace('\r\n','\n')
 proposed=source(water);assert original_source(proposed)==water
 cde=chemical(original,dict(meta['identity']['original_output'],kind='cde',cde_interval_output=True));assert GUARD in cde
 clock=z.read('original-provider-build/swap-selected/timecontrol.f90').decode('cp1252')
 assert 'ioutdatint = 1' in clock and 'outdatint(ioutdatint) - t1900 + 1.d0' in clock
 evidence=dict(status='ORIGINAL_COMPLETE12_WARM_BUDGET_PASS_COLD_REFUSED_BY_OVERRESTRICTIVE_PENDING_DATE_GUARD_NOT_QUALIFIED',classification='OVERRESTRICTIVE_GUARD',actual_source='f6fb0167343024723872eb64cf1ed60622b05981',official_archive=archive.name,official_archive_sha256=S(archive.read_bytes()),artifact_id=15064822425,run_id=45705146877,frames=frames,original_warm_budgets=profile['independent_original_budgets'],cold_error=stderr.decode(),original_integral_sha256=S(water.encode('cp1252')),proposed_integral_sha256=S(proposed.encode('cp1252')),complete_integral_inverse_exact=True,guard_literal_already_used_by_CDE=True,dates_or_state_or_counter_normalized=False,compiler_executions=0,model_executions=0,canonical_admission=False)
for root in [E,P]:(root/'FROST_IMPLICIT_PLATE05_ORIGINAL_YEAR_PENDING_DATE_FAILURE_V1.json').write_text(json.dumps(evidence,indent=2)+'\n')
contract_path=P/'FROST_IMPLICIT_PLATE05_CONTRACT_V1.json';contract=json.loads(contract_path.read_text());contract['files']={}
paths=subprocess.check_output(['git','diff','--name-only',base,'--','app'],cwd=R).decode().splitlines();paths+=['app/hybrid_water/frost_implicit_plate_calendar.py'];assert len(paths)==len(set(paths))
for name in paths:
 new=(R/name).read_bytes().replace(b'\r\n',b'\n');r=subprocess.run(['git','show',base+':'+name],cwd=R,capture_output=True);added=r.returncode!=0
 item=dict(added=added,proposed_lf_sha256=S(new),before_lf_sha256=None,ordered_literal_edits=[])
 if not added:
  old=r.stdout;item['before_lf_sha256']=S(old);a=old.decode();b=new.decode()
  for tag,a0,a1,b0,b1 in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
   if tag!='equal':item['ordered_literal_edits'].append(dict(base_start=a0,base_end=a1,before=a[a0:a1],after=b[b0:b1]))
 contract['files'][name]=item
contract.update(status='FULL35_PUBLIC_LOCAL_PASS_PENDING_DATE_NATIVE_GUARD_CORRECTION_IMPLEMENTED_PENDING_REQUALIFICATION',classification='MISSING_COMPOSITION_WITH_TRIAL_RECEIPT_AND_NATIVE_PENDING_DATE_GUARD_DEFECTS',pending_date_evidence='FROST_IMPLICIT_PLATE05_ORIGINAL_YEAR_PENDING_DATE_FAILURE_V1.json',next_code_action='Run actual local O0/O2 full35 regular water and exact12year cold seam after bounded original pending-date guard correction. Then requalify all changed water calendar cases and previously unreached CDE year; inherit only exact unchanged dense water and CDE full35 bodies after actual postimage custody.',preserve_original_failed_year=True)
contract_path.write_text(json.dumps(contract,indent=2)+'\n')
status_path=P/'STATUS.json';status=json.loads(status_path.read_text());status['frost_implicit_plate05']=dict(status=contract['status'],baseline_canonical=base,actual_local_scientific_source='71568c90592aebb87bc88c069a1fff339bd6746b',actual_CI_scientific_source='f6fb0167343024723872eb64cf1ed60622b05981',actual_CI_runs=[45705146738,45705146877],local_original_primary_days=140,local_native_samples=28,local_exact_cold_windows=12,local_compiled_refusals=344,local_transaction_contexts=8,local_independent_audit='FROST_IMPLICIT_PLATE05_LOCAL_INDEPENDENT4_V1.json',contract=contract_path.name,pending_date_failure='FROST_IMPLICIT_PLATE05_ORIGINAL_YEAR_PENDING_DATE_FAILURE_V1.json',next_code_action=contract['next_code_action'],current_admitted_contexts=568,whole_closure='PARTIAL',whole_science='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',fixed_RC3_changed=False);status_path.write_text(json.dumps(status,indent=2)+'\n')
print(evidence['status'],'EXACT_SOURCE_DELTA_FILES',len(paths),flush=True)
