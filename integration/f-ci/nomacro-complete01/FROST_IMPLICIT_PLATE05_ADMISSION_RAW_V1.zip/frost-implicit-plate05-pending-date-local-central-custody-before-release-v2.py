"""Fresh committed central-byte custody before releasing completed local copies."""
from pathlib import Path
from contextlib import ExitStack
import json,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();rows=[]
with ExitStack() as stack:
 store=Archive(GitArchiveSource(R,head),'FROST_IMPLICIT_PLATE05_PENDING_DATE_LOCAL_WINDOWS_O0_O2_RAW_V2',stack)
 for root,prefix in [(W/'frost-implicit-plate05-pending-date-local-science-v2','current'),(W/'frost-implicit-plate05-pending-date-local-O0-v2','compiled/O0'),(W/'frost-implicit-plate05-pending-date-local-O2-v2','compiled/O2')]:
  count=size=0
  for p in root.rglob('*'):
   assert not p.is_symlink()
   if not p.is_file():continue
   name=prefix+'/'+p.relative_to(root).as_posix();raw=p.read_bytes();assert store.get(name)==raw;count+=1;size+=len(raw)
  assert count>0;rows.append(dict(path=str(root),archive_prefix=prefix,files=count,bytes=size,actual_central_revision=head,archive_sha256=store.record['sha256']))
q=dict(status='EXACT_COMMITTED_CENTRAL_ORIGINAL_BYTES_VERIFIED_FOR_THREE_COMPLETED_OWNED_RESOURCES',resources=rows,models_running_in_resources=False,compiler_executions=0,model_executions=0)
(E/'FROST_IMPLICIT_PLATE05_PENDING_DATE_LOCAL_CENTRAL_CUSTODY_BEFORE_RELEASE_V2.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q,indent=2),flush=True)
