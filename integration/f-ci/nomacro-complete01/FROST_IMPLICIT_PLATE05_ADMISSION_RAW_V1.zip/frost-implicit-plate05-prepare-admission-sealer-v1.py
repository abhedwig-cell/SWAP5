"""Prepare a distinct current admission sealer; never mutate executed parent controllers."""
from pathlib import Path
E=Path(__file__).resolve().parent
s=(E/'frost-boundary-state-calendar04-admission-seal-v1.py').read_text()
replacements={
 'FROST_BOUNDARY_STATE_CALENDAR04':'FROST_IMPLICIT_PLATE05',
 'frost-boundary-state-calendar04-':'frost-implicit-plate05-',
 'frost_boundary_state_calendar_metadata.py':'frost_implicit_plate_metadata.py',
 'e66867c5de454f45fd8d4adde31f68454c61cf9c':'cb5946a6d8205462d96495a39611f72f570db58a',
 '9936bcda75eb920d67aa74e47018baf39ab18f78':'087fc67db3e1e58d45215522eb284e89cb6c12f1',
 '18e31348e7e72fadc564c3046ce3645578bd46b1':'06b31c0ea8d0bb087441be1dab0d1f1ad9236fcc',
 'f28db55d7653d6029e870af45cc97ff310c5ffd4':'81f4f9ad7d7debf7bddc17e991e689341a28192c',
 'e8bd491bbf37828528958c9ea4e982c0afac3bf8':'c8ca41ee58a52cb57074485ba7a812bfbed56181',
 'PR1803':'PR1804','PR=1803':'PR=1804',
 'CANDIDATE_PUBLIC_V2':'CANDIDATE_PUBLIC_V1',
 "('CANDIDATE','V2',candidate)":"('CANDIDATE','V1',candidate)",
 '(568,546,3886,1672)':'(600,570,4070,1752)',
 'len(runs)==15':'len(runs)==14',
 "len({x['workflow_id'] for x in runs})==15":"len({x['workflow_id'] for x in runs})==14",
 ",'POND'":"",
 'len(checks)==46':'len(checks)==45',
 "sum(x['conclusion']=='success' for x in checks)==29":"sum(x['conclusion']=='success' for x in checks)==28",
 'CANONICAL568':'CANONICAL600',
 'FROST_BOUNDARY_STATE_CALENDAR_ADMISSION_VERIFIED':'FROST_IMPLICIT_PLATE_ADMISSION_VERIFIED',
}
for before,after in replacements.items():
 assert before in s,before
 s=s.replace(before,after)
# POND was not selected for this private Frost change. Preserve its parent proof,
# without asserting a current run or changing selection policy.
s=s.replace("whole_tree=tree,coadmission=expected,actual_public_observations=observations,", "whole_tree=tree,coadmission=expected,actual_public_observations=observations,\n POND_current_model_replay='NOT_SELECTED_EXISTING_PRIVATE_FROST_PATH_SELECTION_PARENT_SUCCESS_RETAINED',")
s=s.replace("paths += [E/'frost_implicit_plate_metadata.py']", "paths += [p for p in [E/'frost_implicit_plate_metadata.py'] if p.exists()]")
# Byte manifest covers all original selected logs, reports, failures, controllers,
# actual signed objects and observations. Bulk scientific archives stay central.
out=E/'frost-implicit-plate05-admission-seal-v1.py'
with out.open('x',encoding='utf8',newline='\n') as f:f.write(s)
compile(s,str(out),'exec')
print(out)
