"""Select the coherent changed implicit plate dependency surface only."""
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
for platform in ['windows','ubuntu']:
 old=R/f'.github/workflows/nomacro-frost-boundary-state-calendar04-{platform}.yml'
 source=old.read_text().replace('nomacro-frost-boundary-state-calendar04','nomacro-frost-implicit-plate05').replace('frost-boundary-state-calendar04','frost-implicit-plate05')
 source=source.replace('codex/nomacro-frost-implicit-plate05-science01','codex/nomacro-frost-implicit-plate05')
 source=source.replace('Original Frost boundary state/calendar','Original implicit Frost plate state/calendar')
 source=source.replace('1c3b8725548c836c9a73570c2579dd6cdc683217','087fc67db3e1e58d45215522eb284e89cb6c12f1')
 lines=source.splitlines()
 for i,line in enumerate(lines):
  if 'tests/nomacro_drainage/frost_boundary_state_calendar_portable.py' in line:
   python='python3' if platform=='ubuntu' else 'python'
   lines[i]='          '+python+' -B tests/nomacro_drainage/frost_implicit_plate_portable.py --platform '+platform.title()+' --reference-work "$RUNNER_TEMP/provider" --build-root "$RUNNER_TEMP/builds" --output "$RUNNER_TEMP/proof/current" --optimization \'${{ matrix.optimization }}\''
  if "import os,user_prepare;" in line:
   python='python3' if platform=='ubuntu' else 'python'
   lines[i:i]=['          cp integration/f-ci/nomacro-complete01/FROST_IMPLICIT_PLATE05_CONTRACT_V1.json "$proof/actual-input-contract.json"','          '+python+' -B tests/nomacro_drainage/frost_implicit_plate_input_contract.py --output "$proof/public-input-contract"']
   break
 # Replace runner after insertion, preserving no unselected parent replay.
 for i,line in enumerate(lines):
  if 'tests/nomacro_drainage/frost_boundary_state_calendar_portable.py' in line:
   python='python3' if platform=='ubuntu' else 'python'
   lines[i]='          '+python+' -B tests/nomacro_drainage/frost_implicit_plate_portable.py --platform '+platform.title()+' --reference-work "$RUNNER_TEMP/provider" --build-root "$RUNNER_TEMP/builds" --output "$RUNNER_TEMP/proof/current" --optimization \'${{ matrix.optimization }}\''
 target=R/f'.github/workflows/nomacro-frost-implicit-plate05-{platform}.yml';assert not target.exists();target.write_text('\n'.join(lines)+'\n')
 print(target.name)
