"""Keep each official original ZIP and verified members without rewriting it."""
from pathlib import Path
import argparse,hashlib,json,zipfile
p=argparse.ArgumentParser()
for n in ['stem','sha256','platform','optimization','source']:p.add_argument('--'+n,required=True)
for n in ['bytes','artifact','run']:p.add_argument('--'+n,type=int,required=True)
a=p.parse_args();E=Path(__file__).parent;P=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01/integration/f-ci/nomacro-complete01');S=lambda b:hashlib.sha256(b).hexdigest()
assert Path(a.stem).name==a.stem and a.stem.startswith('FROST_IMPLICIT_PLATE05_')
archive=E/(a.stem+'.zip');raw=archive.read_bytes();assert len(raw)==a.bytes and S(raw)==a.sha256
members={}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 for name in z.namelist():
  if name.endswith('/'):continue
  value=z.read(name);members[name]=dict(bytes=len(value),sha256=S(value))
parts=[];chunk=25*1024*1024
for index,offset in enumerate(range(0,len(raw),chunk),1):
 value=raw[offset:offset+chunk];name=a.stem+'.zip'+('.part'+str(index).zfill(3) if len(raw)>chunk else '');target=P/name;assert not target.exists();target.write_bytes(value);parts.append(dict(file=name,bytes=len(value),sha256=S(value)))
q=dict(status='OFFICIAL_ORIGINAL_CI_ARTIFACT_BYTES_PRESERVED_STATUS_REMAINS_AS_ORIGINALLY_OBSERVED',archive=a.stem+'.zip',bytes=len(raw),sha256=S(raw),parts=parts,members=members,platform=a.platform,optimization=a.optimization,actual_scientific_source=a.source,original_artifact_id=a.artifact,original_run_id=a.run,canonical_admission=False,scientific_failure_not_waived=True)
for root in [E,P]:(root/(a.stem+'.json')).write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],a.stem,len(raw),len(members),flush=True)
