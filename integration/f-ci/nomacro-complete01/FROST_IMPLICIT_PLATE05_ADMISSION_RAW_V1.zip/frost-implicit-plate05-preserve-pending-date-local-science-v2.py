"""Seal original public local results and exact unchanged central SDK custody."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive,SHA
source='87081fd3e70063ae7f60d8606b6d36675257a160';base='087fc67db3e1e58d45215522eb284e89cb6c12f1'
name='FROST_IMPLICIT_PLATE05_PENDING_DATE_LOCAL_WINDOWS_O0_O2_RAW_V2';files={};projection={};contexts=[]
def add(root,prefix):
 assert root.is_dir()
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():files[prefix+'/'+p.relative_to(root).as_posix()]=p
add(W/'frost-implicit-plate05-pending-date-local-science-v2','current')
provider={}
with ExitStack() as stack:
 old=Archive(GitArchiveSource(R,base),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
 for opt in ['O0','O2']:
  root=W/f'frost-implicit-plate05-pending-date-local-{opt}-v2';add(root,'compiled/'+opt)
  batch=json.loads((W/'frost-implicit-plate05-pending-date-local-science-v2'/opt/'RESULT.json').read_text());assert batch['source']==source and batch['status']=='ACTUAL_SELECTED_IMPLICIT_PLATE_PERIODS_NATIVE_COLD_AND_CONTROLS_PASS_NOT_ADMITTED'
  assert len(batch['contexts'])==2
  for item in batch['contexts']:
   assert item['convergence']['unconverged_continuations']==0 and (item['case']['days']!=35 or item['controls'] is not None)
   b=root/item['case']['name']/'bundle';meta=json.loads((b/'BUILD.json').read_text());i=meta['identity']
   projection[str(b)]=dict(archive_prefix='compiled/'+opt+'/'+item['case']['name']+'/bundle',actual_BUILD_sha256=SHA((b/'BUILD.json').read_bytes()))
   for key,folder in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
    for n,digest in i[key].items():
     member='original-provider-build/'+folder+'/'+n;raw=old.get(member);assert SHA(raw)==digest and raw==(J/'build'/folder/n).read_bytes();provider[member]=dict(bytes=len(raw),sha256=digest)
   member='original-provider-build/ttutil-obj/libttutil.a';raw=old.get(member);assert SHA(raw)==i['ttutil_library'] and raw==(J/'build/ttutil-obj/libttutil.a').read_bytes();provider[member]=dict(bytes=len(raw),sha256=SHA(raw))
   contexts.append(dict(optimization=opt,case=item['case'],convergence=item['convergence'],source=source,compiler=i['compiler'],BUILD_sha256=SHA((b/'BUILD.json').read_bytes())))
 dependency=dict(archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',sha256=old.record['sha256'],central_revision=base,checked_actual_required_files=provider)
 source_bytes=old.get('original-provider-build/swap-selected/timecontrol.f90');assert source_bytes==(J/'build/swap-selected/timecontrol.f90').read_bytes();dependency['original_TimeControl_sha256']=SHA(source_bytes)
add(E/'FROST_IMPLICIT_PLATE05_PENDING_DATE_LOCAL_SOURCE_CAPSULE_V2','source')
cap=json.loads((E/'FROST_IMPLICIT_PLATE05_PENDING_DATE_LOCAL_SOURCE_CAPSULE_V2/RESULT.json').read_text());assert cap['producer_head']==source
target=E/('FROST_IMPLICIT_PLATE05_ACTUAL_LOCAL_GIT_SOURCE_'+source+'.tar');assert not target.exists()
subprocess.run(['git','archive','--format=tar','--output='+str(target),source,'--','app','src','tools','tests','.github'],cwd=R,check=True);files['git-source/'+target.name]=target
target=E/('FROST_IMPLICIT_PLATE05_ACTUAL_LOCAL_COMMIT_'+source+'.bin');target.write_bytes(subprocess.check_output(['git','cat-file','commit',source],cwd=R));assert hashlib.sha1(b'commit '+str(target.stat().st_size).encode()+b'\0'+target.read_bytes()).hexdigest()==source;files['git-source/'+target.name]=target
target=E/'FROST_IMPLICIT_PLATE05_PENDING_DATE_LOCAL_COMPILED_PROJECTION_V2.json';target.write_text(json.dumps(projection,indent=2)+'\n');files['COMPILED_PROJECTION_V1.json']=target
files['controllers/'+Path(__file__).name]=Path(__file__)
target=E/'FROST_IMPLICIT_PLATE05_PENDING_DATE_LOCAL_ORIGINAL_PROVIDER_DEPENDENCY_V2.json';target.write_text(json.dumps(dependency,indent=2)+'\n');files[target.name]=target
members={};archive=E/(name+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(files.items()):
  raw=p.read_bytes();z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(members)
 for n,v in members.items():raw=z.read(n);assert len(raw)==v['bytes'] and SHA(raw)==v['sha256']
raw=archive.read_bytes();chunk=25*1024*1024;parts=[]
for index,offset in enumerate(range(0,len(raw),chunk),1):
 piece=raw[offset:offset+chunk];n=name+'.zip'+('.part'+str(index).zfill(3) if len(raw)>chunk else '');(P/n).write_bytes(piece);parts.append(dict(file=n,bytes=len(piece),sha256=SHA(piece)))
record=dict(status='FOUR_ACTUAL_PUBLIC_IMPLICIT_PLATE_WATER_CALENDAR_FULL35_AND_YEAR12_NATIVE_COLD_CONTROLS_RAW_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,contexts=contexts,actual_scientific_source=source,original_provider_dependency=dependency,canonical_admission=False,whole_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED')
for root in [E,P]:(root/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(record['status'],len(raw),record['sha256'],len(members),len(provider),flush=True)
