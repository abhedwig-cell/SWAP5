"""Observation-only mixed-compiler diagnostic. This is not qualification."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
A=W/'frost-implicit-plate05-original-failure-v1';B=A/'original-bundle';J=A/'original-provider-build'
D=W/'frost-implicit-plate05-headcalc-observation-v1';assert D.is_dir()
S=lambda b:hashlib.sha256(b).hexdigest()
meta=json.loads((B/'BUILD.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
assert head=='256585f28e865fe042c74a5a24533ab99d9d1f80'
checks={}
for name,digest in meta['identity']['donor_objects'].items():
 p=J/'swap-obj'/name;assert S(p.read_bytes())==digest;checks[str(p)]=digest
assert S((J/'ttutil-obj/libttutil.a').read_bytes())==meta['identity']['ttutil_library']
for name,digest in meta['identity']['donor_generated'].items():assert S((B/name).read_bytes())==digest
source=(B/'headcalc.f90').read_text(encoding='cp1252')
changes=[('\nsubroutine headcalc\n','\nsubroutine headcalc\n   use iso_fortran_env, only: error_unit\n'),
('      if (budget_enabled .and. .not.flnonconv) then', '''      if(budget_enabled.and.(numbit>=MaxIt.or.tcum+dt>=1d0-1d-8))then
         write(error_unit,*) 'PLATE05_PHYSICAL',flnonconv,flboth,numbit,MaxIt,tcum,dt,t1900,qbot,-kmean(NN+1)*hgrad(NN+1),sum1,CritDevBalTot
      end if
      if (budget_enabled .and. .not.flnonconv) then'''),
('         if (abs(budget_total+budget_step)>1d-10*(t1900-budget_start+dt)) flnonconv=.true.', '''         if(tcum+dt>=1d0-1d-8.or.numbit>=MaxIt)then
           write(error_unit,*) 'PLATE05_EXTRA',budget_total+budget_step,1d-10*(t1900-budget_start+dt),terminal_water_residual(),tcum,dt,qbot,-kmean(NN+1)*hgrad(NN+1),flboth
         end if
         if (abs(budget_total+budget_step)>1d-10*(t1900-budget_start+dt)) flnonconv=.true.''')]
for old,new in changes:assert source.count(old)==1;source=source.replace(old,new)
inverse=source
for old,new in reversed(changes):assert inverse.count(new)==1;inverse=inverse.replace(new,old)
assert inverse==(B/'headcalc.f90').read_text(encoding='cp1252')
(D/'headcalc.f90').write_text(source,encoding='cp1252')
env=dict(os.environ,OMP_NUM_THREADS='1',PATH='C:/msys64/ucrt64/bin;'+os.environ.get('PATH',''))
compiler=shutil.which('gfortran',path=env['PATH']);version=subprocess.check_output([compiler,'--version'],env=env).decode().splitlines()[0]
commands=[]
def run(cmd):
 commands.append(cmd);p=subprocess.run(cmd,cwd=D,env=env,capture_output=True)
 (D/f'compiler-{len(commands)}.stdout').write_bytes(p.stdout);(D/f'compiler-{len(commands)}.stderr').write_bytes(p.stderr)
 p.check_returncode()
started=time.perf_counter()
run([compiler,*meta['identity']['donor_flags'],'-I',str(B),'-I',str(J/'swap-obj'),'-I',str(J/'ttutil-obj'),'-c','headcalc.f90'])
objects={p.name:p for p in (J/'swap-obj').glob('*.o')};objects.update({p.name:p for p in B.glob('*.o')});objects['headcalc.o']=D/'headcalc.o'
exe=D/'day_donor_observation.exe'
run([compiler,'-o',str(exe),*[str(objects[n]) for n in sorted(objects)],str(J/'ttutil-obj/libttutil.a')])
compile_seconds=time.perf_counter()-started
O=D/'actual-worker';O.mkdir();inputs={}
for name in meta['inputs']:
 p=A/'original-donor-replay-v1'/name;raw=p.read_bytes();target=O/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);inputs[name]=S(raw)
started=time.perf_counter();request=b'1 -1\n';(O/'donor.request').write_bytes(request);error=None;code=None
try:
 with (O/'donor.stdout').open('xb') as out,(O/'donor.stderr').open('xb') as err:
  p=subprocess.run([str(exe),'./swap.swp'],cwd=O,env=env,input=request,stdout=out,stderr=err,timeout=180);code=p.returncode
except subprocess.TimeoutExpired:error='EXPLICIT_180_SECOND_DIAGNOSTIC_CENSOR'
report=dict(status='OBSERVATION_ONLY_MIXED_COMPILER_DIAGNOSTIC_NOT_QUALIFIED',actual_collection_head=head,original_source='6049f82bcf265ef17de2ff86a69b4ef4c33f768f',original_compiler=meta['identity']['compiler'],actual_observation_compiler=version,actual_observation_compiler_sha256=S(Path(compiler).read_bytes()),original_objects_compiler=meta['identity']['compiler'],compiler_equality=version==meta['identity']['compiler'],commands=commands,linked_objects={n:dict(path=str(p),sha256=S(p.read_bytes())) for n,p in objects.items()},original_headcalc_sha256=S((B/'headcalc.f90').read_bytes()),observation_source_sha256=S((D/'headcalc.f90').read_bytes()),observation_inverse_exact=True,executable_sha256=S(exe.read_bytes()),compile_link_seconds=compile_seconds,model_seconds=time.perf_counter()-started,inputs=inputs,returncode=code,error=error,public_admission=False,physical_equations_state_flags_tolerances_changed=False)
(D/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');(E/'FROST_IMPLICIT_PLATE05_HEADCALC_OBSERVATION_V1.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'commands','linked_objects','inputs'}},indent=2),flush=True)
