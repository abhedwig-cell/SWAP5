"""Preserve actual diagnostic bytes and the bounded next-batch contract."""
from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';T=R/'tests/nomacro_drainage'
S=lambda b:hashlib.sha256(b).hexdigest();base='087fc67db3e1e58d45215522eb284e89cb6c12f1'
reader=(T/'frost_boundary_state_calendar_metadata.py').read_text().replace('FROST_BOUNDARY_STATE_CALENDAR04_','FROST_IMPLICIT_PLATE05_').replace('current04','current05').replace('Current04','Current05')
(T/'frost_implicit_plate_metadata.py').write_text(reader)
runtime=T/'frost_implicit_plate_portable.py';raw=runtime.read_text();assert raw.count('from frost_boundary_state_calendar_metadata import read')==1;runtime.write_text(raw.replace('from frost_boundary_state_calendar_metadata import read','from frost_implicit_plate_metadata import read'))
cases=[]
for kind in ('water','cde'):
 cases.append(dict(name=kind+'-b8-i1-h2-p2-parent-dense',bottom=8,implicit=1,kind=kind,hysteresis=2,initial=2,calendar='parent-dense',reset=1,start=None,days=35))
for kind,hys,initial,calendar,reset in [('water',0,1,'regular',0),('water',1,2,'monthly',1),('cde',0,2,'dates',1),('cde',1,1,'dense',1)]:
 cases.append(dict(name=f'{kind}-b8-i1-h{hys}-p{initial}-{calendar}-r{reset}',bottom=8,implicit=1,kind=kind,hysteresis=hys,initial=initial,calendar=calendar,reset=reset,start=None,days=35))
for kind,hys,initial,calendar,reset in [('water',1,1,'dates',0),('cde',0,2,'monthly',1)]:
 cases.append(dict(name=f'{kind}-b8-i1-h{hys}-p{initial}-{calendar}-r{reset}-year-seam',bottom=8,implicit=1,kind=kind,hysteresis=hys,initial=initial,calendar=calendar,reset=reset,start='2002-12-28',days=12))
original='frost-implicit-plate05-original-failure-v1/original-donor-replay-v1'
observed='frost-implicit-plate05-headcalc-observation-v1'
files={}
for prefix in (original,observed):
 for p in sorted((W/prefix).rglob('*')):
  if p.is_file():files[p.relative_to(W).as_posix()]=p.read_bytes()
for p in E.glob('frost-implicit-plate05-*.py'):files['controllers/'+p.name]=p.read_bytes()
for p in E.glob('FROST_IMPLICIT_PLATE05_*.json'):files['results/'+p.name]=p.read_bytes()
manifest={n:dict(bytes=len(b),sha256=S(b)) for n,b in files.items()}
name='FROST_IMPLICIT_PLATE05_ORIGINAL_CAUSAL_DIAGNOSTIC_RAW_V1.zip';archive=E/name
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
 z.writestr('MEMBER_MANIFEST_V1.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 for n,v in manifest.items():assert S(z.read(n))==v['sha256']
(P/name).write_bytes(archive.read_bytes())
summary=dict(status='ORIGINAL_ZERO_DAY_FAILURE_AND_MIXED_COMPILER_CAUSAL_DIAGNOSTIC_PRESERVED_NOT_QUALIFIED',archive=name,bytes=archive.stat().st_size,sha256=S(archive.read_bytes()),members=len(manifest)+1,baseline_executable_unchanged=True,observation_inverse_exact=True,counterfactual_original_TimeControl_unchanged=True,counterfactual_returned_days=1,counterfactual_normal_completion_exit_code=100,compiler_equality=False,scientific_qualification=False)
(P/'FROST_IMPLICIT_PLATE05_ORIGINAL_CAUSAL_DIAGNOSTIC_RAW_V1.json').write_text(json.dumps(summary,indent=2)+'\n')
contract=json.loads((P/'FROST_IMPLICIT_PLATE05_CONTRACT_V1.json').read_text())
contract.update(status='IMPLEMENTED_BOUNDARY_RECEIPT_CORRECTION_AND_PUBLIC_COMPOSITION_PENDING_QUALIFICATION',classification='MISSING_COMPOSITION_WITH_DIAGNOSED_TRIAL_RECEIPT_DEFECT',hypothesis='Observed original physical convergence plus passing projected step receipt; old terminal receipt reads stale global qbot. Actual-trial receipt returns first day using unchanged original implicit retry/TimeControl. Mixed compiler observations are diagnostic only; complete actual public builds must qualify.',qualification='NOT_QUALIFIED',public_admission=False,representative_cases=cases,native_codecs=['S5FBW002','S5FBC002','S5BCW002','S5BCC002'],expected_scientific_matrix=dict(platforms=['Windows','Ubuntu'],optimizations=['O0','O2'],contexts=32,primary_days=936,short35_contexts=24,year12_contexts=8),preserved_diagnostic=summary,known_closed='Implicit hysteresis2 new calendars remain refused; original bottom5 day5 year failure remains preserved.',next_code_action='Persist actual implementation. Run local O0/O2 whole35 water/CDE selected implicit8 public builds, exact native cold and real compiled refusal/transaction controls. Then qualify the coherent Windows/Ubuntu matrix with actual compilers and independently audit raw archives.',affected_invariants=[3,4,7,13,21,23,26],equations_state_tolerances_retry_limits_changed=False,new_source_identity_projection=False,selection_cost=dict(local_feedback='Two full35 public contexts per optimization, expected under five minutes each; selected because original zero-day convergence failure affects actual accepted days and native cold rollback.',scientific_matrix='Eight representative cases per platform/optimization; same physical correction and existing codecs/calendar/root owners, no unrelated model replay.'))
paths=subprocess.check_output(['git','diff','--name-only',base,'--','app'],cwd=R).decode().splitlines();contract['files']={}
for n in paths:
 old=subprocess.check_output(['git','show',base+':'+n],cwd=R);new=(R/n).read_bytes().replace(b'\r\n',b'\n')
 edits=[];a=old.decode();b=new.decode()
 for tag,a0,a1,b0,b1 in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
  if tag!='equal':edits.append(dict(base_start=a0,base_end=a1,before=a[a0:a1],after=b[b0:b1]))
 contract['files'][n]=dict(before_lf_sha256=S(old),proposed_lf_sha256=S(new),ordered_literal_edits=edits)
(P/'FROST_IMPLICIT_PLATE05_CONTRACT_V1.json').write_text(json.dumps(contract,indent=2)+'\n')
for name in ['FROST_IMPLICIT_PLATE05_HEADCALC_OBSERVATION_V1.json','FROST_IMPLICIT_PLATE05_TRIAL_FLUX_COUNTERFACTUAL_V1.json']:(P/name).write_bytes((E/name).read_bytes())
status_path=P/'STATUS.json';status=json.loads(status_path.read_text());status['frost_implicit_plate05']=dict(status=contract['status'],baseline_canonical=base,contract='FROST_IMPLICIT_PLATE05_CONTRACT_V1.json',preserved_diagnostic=summary,next_code_action=contract['next_code_action'],whole_closure='PARTIAL',whole_science='NOT_QUALIFIED');status_path.write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps(summary,indent=2));print('REPRESENTATIVE_CASES',len(cases),'APP_FILES',len(paths))
