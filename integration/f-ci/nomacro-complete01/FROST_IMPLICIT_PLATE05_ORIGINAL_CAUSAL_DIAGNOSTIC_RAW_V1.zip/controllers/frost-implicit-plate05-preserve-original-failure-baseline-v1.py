"""Read the real archived zero-day implicit plate failure for the next work block."""
from pathlib import Path,PurePosixPath
from contextlib import ExitStack
import hashlib,json,subprocess,sys
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=W/'frost-implicit-plate05-original-failure-v1'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface'),str(R/'app/hybrid_water')]
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive
SHA=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert head=='087fc67db3e1e58d45215522eb284e89cb6c12f1'
name='water-bottom8-implicit1-hys2-initial2';prefix='current/'+name
inventory=[]
with ExitStack() as stack:
 store=Archive(GitArchiveSource(R,head),'FROST_BOUNDARY03_WINDOWS_O0_ORIGINAL_V3',stack)
 record=json.loads(store.get(prefix+'/science/RESULT.json'));assert record['source']=='6049f82bcf265ef17de2ff86a69b4ef4c33f768f'
 assert store.get(prefix+'/science/trajectory/daily.jsonl')==b''
 assert b'Implicit original retry reached clock resolution' in store.get(prefix+'/science/trajectory/original/donor.stderr')
 projection=json.loads(store.get('COMPILED_PROJECTION_V1.json'));build_prefix=projection[record['build_root']]['archive_prefix'];meta=json.loads(store.get(build_prefix+'/BUILD.json'))
 assert SHA(store.get(build_prefix+'/BUILD.json'))==projection[record['build_root']]['actual_BUILD_sha256']
 roots=[(prefix+'/',D/'original-failed-profile'),(build_prefix+'/',D/'original-bundle'),('original-provider-build/',D/'original-provider-build')]
 for original,destination in roots:
  for member in sorted(store.names):
   if not member.startswith(original):continue
   relative=PurePosixPath(member[len(original):]);assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
   path=destination/relative.as_posix();assert path.resolve().is_relative_to(D.resolve());raw=store.get(member);path.parent.mkdir(parents=True,exist_ok=True)
   if path.exists():assert path.read_bytes()==raw
   else:path.write_bytes(raw)
   assert path.read_bytes()==raw;inventory.append(dict(archive_member=member,actual_copy=str(path),bytes=len(raw),sha256=SHA(raw)))
 assert inventory
 for file,digest in meta['identity']['donor_generated'].items():assert SHA((D/'original-bundle'/file).read_bytes())==digest
 for file,digest in meta['identity']['donor_objects'].items():assert SHA((D/'original-provider-build/swap-obj'/file).read_bytes())==digest
 assert SHA((D/'original-provider-build/ttutil-obj/libttutil.a').read_bytes())==meta['identity']['ttutil_library']
 for role,digest in meta['executable_sha256'].items():assert SHA((D/'original-bundle'/('day_'+role+'.exe')).read_bytes())==digest
 for file,digest in meta['inputs'].items():assert SHA((D/'original-failed-profile/inputs'/file).read_bytes())==digest
 q=dict(status='GENUINE_ORIGINAL_IMPLICIT_PLATE_ZERO_ACCEPTED_DAY_FAILURE_AND_COMPLETE_BUILD_PROVIDER_INPUT_BYTES_EXACT_FOR_DIAGNOSIS_NOT_QUALIFIED',actual_collection_head=head,actual_original_producer=record['source'],actual_original_archive_sha256=store.record['sha256'],actual_original_compiler=meta['identity']['compiler'],actual_original_BUILD_sha256=SHA(store.get(build_prefix+'/BUILD.json')),original_BUILD_metadata_unchanged=True,accepted_original_days=0,original_error='Implicit original retry reached clock resolution',physical_inventory=inventory,compiler_executions=0,model_executions=0,public_admission=False,next='Inspect original HeadCalc/TimeControl and runtime project contract. Observe original physical criteria, step/terminal guards and global versus actual trial bottom flux with the original compiler before attributing the failure. Do not loosen retry, conservation or native limits.')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==head
(E/'FROST_IMPLICIT_PLATE05_ORIGINAL_ZERO_DAY_BASELINE_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],len(inventory),flush=True)
