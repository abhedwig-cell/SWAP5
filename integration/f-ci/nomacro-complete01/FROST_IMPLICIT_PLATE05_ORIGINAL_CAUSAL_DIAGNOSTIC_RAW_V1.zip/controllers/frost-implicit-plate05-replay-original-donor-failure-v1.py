"""Replay the real original donor day protocol, without public admission or namespace changes."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
E=Path(__file__).parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=W/'frost-implicit-plate05-original-failure-v1';B=D/'original-bundle';O=D/'original-donor-replay-v1';O.mkdir()
SHA=lambda b:hashlib.sha256(b).hexdigest();meta=json.loads((B/'BUILD.json').read_text());producer='6049f82bcf265ef17de2ff86a69b4ef4c33f768f'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert head=='087fc67db3e1e58d45215522eb284e89cb6c12f1'
exe=B/'day_donor.exe';assert SHA(exe.read_bytes())==meta['executable_sha256']['donor']
original=D/'original-failed-profile/science/trajectory/original';inputs={}
for name in meta['inputs']:
 p=original/name;assert p.is_file();target=O/name;target.parent.mkdir(parents=True,exist_ok=True);raw=p.read_bytes();target.write_bytes(raw);inputs[name]=dict(bytes=len(raw),sha256=SHA(raw),original_archived_worker_path=str(p))
# DailyHost.step sends this exact production donor protocol request for day1
# without checkpoint publication. The original donor fails before the reply.
request=b'1 -1\n';(O/'donor.request').write_bytes(request)
env=dict(os.environ,OMP_NUM_THREADS='1',PATH='C:/msys64/ucrt64/bin;'+os.environ.get('PATH',''));started=time.perf_counter();error=None;code=None
try:
 with (O/'donor.stdout').open('xb') as stdout,(O/'donor.stderr').open('xb') as stderr:
  p=subprocess.run([str(exe),'./swap.swp'],cwd=O,input=request,env=env,stdout=stdout,stderr=stderr,timeout=180);code=p.returncode
except subprocess.TimeoutExpired:error='EXPLICIT_180_SECOND_DIAGNOSTIC_CENSOR'
out=(O/'donor.stdout').read_bytes();err=(O/'donor.stderr').read_bytes();clock_failure=b'Implicit original retry reached clock resolution' in err
assert b'HYBRID_READY' in out
returned=sum(line.startswith(b'HYBRID_DAY_RETURN') for line in out.splitlines())
runtime={}
for name in ['libgfortran-5.dll','libquadmath-0.dll','libgcc_s_seh-1.dll','libwinpthread-1.dll']:
 p=Path('C:/msys64/ucrt64/bin')/name
 if p.is_file():runtime[name]=dict(path=str(p),sha256=SHA(p.read_bytes()))
assert SHA(exe.read_bytes())==meta['executable_sha256']['donor'] and subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==head
q=dict(status='ORIGINAL_DONOR_ZERO_DAY_CLOCK_FAILURE_REPRODUCED_DIAGNOSTIC_NOT_QUALIFIED' if clock_failure and returned==0 else 'ORIGINAL_DONOR_REPLAY_DIAGNOSTIC_REQUIRES_ANALYSIS_NOT_QUALIFIED',actual_collection_head=head,actual_original_compiler_source=producer,actual_original_compiler=meta['identity']['compiler'],actual_original_compiler_sha256=meta['identity']['compiler_sha256'],original_executable_sha256=meta['executable_sha256']['donor'],command=[str(exe),'./swap.swp'],input_protocol=request.decode(),inputs=inputs,returncode=code,error=error,clock_resolution_failure=clock_failure,original_donor_returned_days=returned,kernel_accepted_days=0,model_seconds=time.perf_counter()-started,actual_runtime_DLLs=runtime,original_runtime_DLL_equality='UNKNOWN_ORIGINAL_DLL_HASHES_NOT_CAPTURED',compiler_executions=0,public_admission=False,namespace_or_source_identity_projection=False,checkpoint_publication=False,physical_equations_or_tolerances_changed=False)
for root in [O,E]:(root/'FROST_IMPLICIT_PLATE05_ORIGINAL_DONOR_REPLAY_V1.json').write_text(json.dumps(q,indent=2)+'\n')
print(q['status'],code,returned,q['model_seconds'],flush=True)
