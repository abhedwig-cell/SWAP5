* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 22:20:54

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.49 cm       0.8218E+01 mg/cm2
Initial :        76.02 cm       0.1238E+02 mg/cm2
            =============       =================
Change           -0.54 cm      -0.4158E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    79.08    Interception      :    11.35
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    29.65
Bottom flux    :     0.00    Soil evaporation  :    13.02
                             Crack flux        :     0.00
                             Drainage level 1  :    27.04
=========================    ============================
Sum            :    79.08    Sum               :    81.06


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.6772E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4835E+01
=========================    ============================
Sum         :  0.6772E+00    Sum            :  0.4835E+01

