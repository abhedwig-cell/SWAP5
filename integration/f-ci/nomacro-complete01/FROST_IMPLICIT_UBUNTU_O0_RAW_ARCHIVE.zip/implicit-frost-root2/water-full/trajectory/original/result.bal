* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 22:18:57

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        77.84 cm
Initial :        97.19 cm
            =============
Change          -19.35 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     5.90
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    49.11
=========================    ============================
Sum            :    86.58    Sum               :   105.93

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.02 cm
Initial :        77.84 cm
            =============
Change           -1.82 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     4.65
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     6.00    Transpiration     :    14.78
Bottom flux    :     0.00    Soil evaporation  :    16.91
                             Crack flux        :     0.00
                             Drainage level 1  :    43.46
=========================    ============================
Sum            :    77.98    Sum               :    79.80

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        75.49 cm
Initial :        76.02 cm
            =============
Change           -0.54 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :    11.35
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    29.65
Bottom flux    :     0.00    Soil evaporation  :    13.05
                             Crack flux        :     0.00
                             Drainage level 1  :    27.04
=========================    ============================
Sum            :    80.55    Sum               :    81.09
