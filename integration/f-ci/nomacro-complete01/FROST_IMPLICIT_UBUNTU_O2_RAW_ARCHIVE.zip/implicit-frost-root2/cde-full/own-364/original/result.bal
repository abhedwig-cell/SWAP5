* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 22:20:24

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.84 cm       0.2568E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.65 cm       0.2568E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.80    Interception      :     4.25
Runon          :     0.00    Runoff            :     5.90
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.78
                             Crack flux        :     0.00
                             Drainage level 1  :    49.11
=========================    ============================
Sum            :    83.20    Sum               :   105.76


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.7655E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2309E+02
=========================    ============================
Sum         :  0.4877E+02    Sum            :  0.2309E+02

