* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 22:19:54

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.84 cm       0.2568E+02 mg/cm2
Initial :        97.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -19.35 cm       0.2568E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     5.90
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    49.11
=========================    ============================
Sum            :    86.58    Sum               :   105.93


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.7655E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2309E+02
=========================    ============================
Sum         :  0.4877E+02    Sum            :  0.2309E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.02 cm       0.1238E+02 mg/cm2
Initial :        77.84 cm       0.2568E+02 mg/cm2
            =============       =================
Change           -1.82 cm      -0.1330E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     4.65
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     6.00    Transpiration     :    14.78
Bottom flux    :     0.00    Soil evaporation  :    16.91
                             Crack flux        :     0.00
                             Drainage level 1  :    43.46
=========================    ============================
Sum            :    77.98    Sum               :    79.80


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.6440E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1394E+02
=========================    ============================
Sum         :  0.6440E+00    Sum            :  0.1394E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.49 cm       0.8218E+01 mg/cm2
Initial :        76.02 cm       0.1238E+02 mg/cm2
            =============       =================
Change           -0.54 cm      -0.4158E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :    11.35
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    29.65
Bottom flux    :     0.00    Soil evaporation  :    13.05
                             Crack flux        :     0.00
                             Drainage level 1  :    27.04
=========================    ============================
Sum            :    80.55    Sum               :    81.09


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.6772E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4835E+01
=========================    ============================
Sum         :  0.6772E+00    Sum            :  0.4835E+01

