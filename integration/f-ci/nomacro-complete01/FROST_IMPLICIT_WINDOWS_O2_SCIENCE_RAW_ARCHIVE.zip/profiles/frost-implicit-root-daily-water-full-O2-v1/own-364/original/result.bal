* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 23:15:01

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        77.84 cm
Initial :        75.19 cm
            =============
Change            2.65 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.80    Interception      :     4.25
Runon          :     0.00    Runoff            :     5.90
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.78
                             Crack flux        :     0.00
                             Drainage level 1  :    49.11
=========================    ============================
Sum            :    83.20    Sum               :   105.76
