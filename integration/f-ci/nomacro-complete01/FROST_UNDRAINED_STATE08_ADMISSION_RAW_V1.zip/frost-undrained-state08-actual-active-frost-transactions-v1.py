"""Fresh active-Frost rollback checks on genuine unchanged producer656cd3 data."""
from pathlib import Path
import hashlib,json,subprocess,sys
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider');D=W/'frost-undrained-state08-active-frost-transaction-v1'
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
import frost_undrained_state_controls as controls
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
actor=git('rev-parse','HEAD');producer='656cd3ed25c91dc6ab8de12f2525fd30be8e358f';assert actor=='127af752c5519e7f9d9a6894c61137f0ee7f3920'
assert not git('diff',producer,'HEAD','--','app','src','tools','reference') and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=dict(status='RUNNING_FRESH_ACTIVE_FROST_TRANSACTION_CHECKS_NOT_ADMITTED',actual_observer=actor,actual_compiled_producer=producer,new_compiler_executions=0,full_model_periods_replayed=0,contexts=[])
for opt in ('O0','O2'):
    profile=W/'frost-undrained-state08-local-smoke-v3'/(opt+'-cde-d0-b5-i1-h2-p2-dense')/'science';report=json.loads((profile/'RESULT.json').read_text());assert report['source']==producer
    build=Path(report['build_root']);project=controls.m.e.load(report['input_root'],original_output=True,time_step_policy='original-adaptive-event-closure-v1');full=profile/'trajectory';checkpoint=full/'accepted-column-1-day-19.zip';before=controls.m.sha(checkpoint)
    temperatures=controls.active_frost_start(checkpoint,project)
    data=controls.m.rows(full);result=controls.transaction(build,J,project,full,data,D/(opt+'-active19'),19,False)
    assert result['discard_no_day_advance'] and result['replay_exact'] and result['accept_exact'] and result['recovered_next_day_exact'] and result['origin_unchanged']
    assert controls.m.sha(checkpoint)==before
    q['contexts'].append(dict(optimization=opt,actual_original_checkpoint_sha256=before,actual_original_temperature=temperatures,actual_transaction=result));print(opt,temperatures,result,flush=True)
assert git('rev-parse','HEAD')==actor
q['status']='TWO_REAL_FROST_ACTIVE_DAY19_ROLLBACK_REPLAY_ACCEPT_AND_COLD_RECOVERY_PASS_NO_FULL_PERIOD_REPLAY'
for path in [D/'RESULT.json',E/'FROST_UNDRAINED_STATE08_ACTIVE_FROST_TRANSACTIONS_V1.json']:
    with path.open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
