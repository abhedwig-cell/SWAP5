"""Actual new functional public build, original budgets and exact state/cold."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
p=argparse.ArgumentParser();p.add_argument('--case',required=True);p.add_argument('--optimization',choices=['O0','O2'],required=True);a=p.parse_args()
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water'),str(R/'tests/nomacro_scheduled_subsurface')]
from frost_undrained_state_inputs import prepare
from frost_boundary_convergence import require_convergence
git=lambda *x:subprocess.check_output(['git',*x],cwd=R).decode().strip();SHA=lambda b:hashlib.sha256(b).hexdigest()
head=git('rev-parse','HEAD');assert head=='76b0c773e172979cd183f836e83017ab8f6fd14f' and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
contract=json.loads((R/'integration/f-ci/nomacro-complete01/FROST_UNDRAINED_STATE08_INPUT_CONTRACT_V1.json').read_text());case=next(c for c in contract['representative_cases'] if c['name']==a.case)
D=W/'frost-undrained-state08-local-smoke-v2'/(a.optimization+'-'+case['name']);D.mkdir();inputs=D/'inputs';prepare(case,inputs)
B=W/('frost-undrained-state08-local-'+a.optimization+'-v2')/case['name']/'bundle'
compiler=Path('C:/msys64/ucrt64/bin/gfortran.exe');provider=json.loads((J/'PREPARED.json').read_text());assert SHA(compiler.read_bytes())==provider['toolchain']['gfortran']['sha256']
q=dict(status='RUNNING_REAL_UNDRAINED_FROST_SMOKE_NOT_QUALIFIED',actual_source=head,case=case,optimization=a.optimization,actual_compiler_sha256=SHA(compiler.read_bytes()),input_root=str(inputs),build_root=str(B),canonical_admission=False,scientific_qualification=False)
save=lambda:(D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
def run(label,command,cap):
    start=time.perf_counter()
    with (D/(label+'.stdout.txt')).open('xb') as out,(D/(label+'.stderr.txt')).open('xb') as err:
        process=subprocess.run(command,cwd=R,stdout=out,stderr=err,timeout=cap)
    q[label]=dict(command=command,returncode=process.returncode,seconds=time.perf_counter()-start);save();process.check_returncode()
try:
    command=[sys.executable,'-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy','original-adaptive-event-closure-v1','--reference-work',str(J),'--build-only','--donor-opt',a.optimization,'--kernel-opt',a.optimization,'--output',str(B)]
    run('build',command,300)
    record=dict(status='ACTUAL_PUBLIC_BUILD_COMPLETE_NOT_SCIENTIFICALLY_QUALIFIED',actual_source=head,input_root=str(inputs),build_root=str(B),returncode=0,command=command,seconds=q['build']['seconds']);(D/'BUILD_RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
    command=[sys.executable,'-B','tests/nomacro_drainage/frost_undrained_state_runtime.py','--build-record',str(D/'BUILD_RESULT.json'),'--reference-work',str(J),'--output',str(D/'science'),'--days',str(case['days'])]
    if case['start'] and case['start'][5:7]=='12':command.append('--year-seam')
    run('science',command,900);q['original_convergence']=require_convergence(D/'science');q['science_result']=json.loads((D/'science/RESULT.json').read_text());save()
    if case['days']==35:
        run('controls',[sys.executable,'-B','tests/nomacro_drainage/frost_undrained_state_controls.py','--reference-work',str(J),'--profile',str(D/'science'),'--output',str(D/'controls')],600);q['controls_result']=json.loads((D/'controls/RESULT.json').read_text())
    assert git('rev-parse','HEAD')==head and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
    q['status']='REAL_UNDRAINED_FROST_PUBLIC_SMOKE_ORIGINAL_BUDGETS_EXACT_NATIVE_COLD_AND_CONTROLS_PASS_NOT_ADMITTED'
except Exception as exc:q.update(status='FAILED_REAL_UNDRAINED_FROST_PUBLIC_SMOKE_NOT_QUALIFIED',error=repr(exc));raise
finally:save()
print(q['status'],head,a.optimization,a.case,flush=True)
