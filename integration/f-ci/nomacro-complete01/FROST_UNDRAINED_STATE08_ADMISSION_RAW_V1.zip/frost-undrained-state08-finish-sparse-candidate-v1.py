"""Resume the explicit sparse Git add refusal without rewriting installed files."""
from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
C='082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66';BRANCH='codex/nomacro-frost-undrained-state08';assert git('rev-parse','HEAD')==C and git('branch','--show-current')==BRANCH
paths=[p.relative_to(E/'frost-undrained-state08-source-proposal-v1').as_posix() for p in (E/'frost-undrained-state08-source-proposal-v1').rglob('*.py')]
paths+=['tests/nomacro_drainage/frost_undrained_state_inputs.py','docs/science/NOMACRO_FROST_UNDRAINED_STATE08.md']
paths+=['integration/f-ci/nomacro-complete01/'+n for n in ['FROST_UNDRAINED_STATE08_SOURCE_PROPOSAL_V1.json','FROST_UNDRAINED_STATE08_RUNTIME_PROPOSAL_V1.json','FROST_UNDRAINED_STATE08_NATIVE_CONTROLS_PROPOSAL_V1.json','FROST_UNDRAINED_STATE08_INPUT_CONTRACT_V1.json','FROST_UNDRAINED_STATE08_DEPENDENCY_STUDY_V1.json','FROST_UNDRAINED_STATE08_COMPILER_IDENTITY_CLARIFICATION_V1.json','FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.json','FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.zip','STATUS.json','GAP_MATRIX.json']]
changed=set(git('diff','--name-only','HEAD').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines());assert changed==set(paths),(changed-set(paths),set(paths)-changed)
archive=P/'FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='4dbbc19e93b8166ff90c8dc4a765fdc596381e5eef061cc70f4acc101f399854'
q=dict(status='NORMAL_GIT_ADD_REFUSED_OUTSIDE_SPARSE_ARCHIVE_PATH_RESUMED_WITH_EXPLICIT_DOCUMENTED_ADD_SPARSE',actual_parent=C,original_installer='frost-undrained-state08-install-candidate-v1.py',scientific_model_runs=0,source_input_or_evidence_bytes_changed_by_resume=False)
name='FROST_UNDRAINED_STATE08_OPERATIONAL_REFUSALS_V1.json';s=json.dumps(q,indent=2)+'\n'
with (E/name).open('x',encoding='utf8') as f:f.write(s)
(P/name).write_text(s);paths.append((P/name).relative_to(R).as_posix())
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--sparse','--',*paths],cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Compose existing undrained Frost boundary state and calendar owners for qualification'],cwd=R,check=True)
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=dict(status='REAL_UNDRAINED_FROST_COMPOSITION_CANDIDATE_COMMITTED_NOT_SCIENTIFICALLY_QUALIFIED',actual_source=git('rev-parse','HEAD'),actual_tree=git('rev-parse','HEAD^{tree}'),parent_candidate=C,branch=BRANCH,parent_canonical_admission_pending=True,new_qualified_contexts=0,canonical_admission=False)
with (E/'FROST_UNDRAINED_STATE08_IMPLEMENTED_CANDIDATE_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps(q),flush=True)
