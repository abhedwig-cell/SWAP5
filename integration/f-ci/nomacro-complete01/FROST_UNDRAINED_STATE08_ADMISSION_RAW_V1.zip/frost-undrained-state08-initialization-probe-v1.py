"""Locate original initialization refusal with real module calls, zero days."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
E=Path(__file__).resolve().parent;W=E.parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
B=W/'frost-undrained-state08-initialization-probe-O0-v1'
D=W/'frost-undrained-state08-original35-v1'/'initialization-probe-v1'
SHA=lambda b:hashlib.sha256(b).hexdigest()
assert B.is_dir() and not any(B.iterdir());D.mkdir()
source='''program original_initialization_probe
use iso_fortran_env, only: output_unit
use MOD_swap_base, only: swap_configuration, sw_animo, sw_multi_swap, swhea, swdra, swsnow, swsolu
use MOD_meteo, only: meteo, tav, peva, empreva, epond
use MOD_MvG, only: fill_cofgen
use MOD_SoilWater, only: soilwater
use MOD_gwl, only: calcgwl
use MOD_SoilTemperature, only: SoilTemperature, tsoil
use MOD_snow, only: snow
use MOD_solute, only: solute
implicit none
sw_animo=1
call mark('BEFORE_INITIALIZE')
call Initialize
call IterTime(1)
call mark('BEFORE_CONFIGURATION')
call swap_configuration()
call mark('BEFORE_READSWAP')
call ReadSwap
call mark('AFTER_READSWAP')
call Meteo(1)
call mark('AFTER_METEO')
call TimeControl(1)
call mark('AFTER_TIMECONTROL')
if(sw_multi_swap/=0)error stop 'Unexpected multi SWAP'
call fill_cofgen
call mark('AFTER_FILL_COFGEN')
call SoilWater(1)
call mark('AFTER_SOILWATER')
call calcgwl()
call mark('AFTER_CALCGWL')
if(swhea>0)call SoilTemperature(1)
call mark('AFTER_SOILTEMPERATURE')
if(swdra/=0)error stop 'Unexpected drainage'
if(swsnow==1)call Snow(1,tsoil(1),tav,epond,peva,empreva)
call mark('AFTER_SNOW')
if(swsolu>0)call Solute(1)
call mark('AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS')
contains
subroutine mark(text)
character(len=*),intent(in)::text
write(output_unit,'(a)')'ORIGINAL_INIT_PHASE '//text
flush(output_unit)
end subroutine
end program
'''
(B/'probe.f90').write_text(source,encoding='ascii')
env=dict(os.environ,OMP_NUM_THREADS='1',PATH='C:/msys64/ucrt64/bin;'+os.environ.get('PATH',''))
compiler=shutil.which('gfortran',path=env['PATH']);objects=sorted(p for p in (J/'build/swap-obj').glob('*.o') if p.name!='swap_main.o')
assert objects and all(p.is_file() for p in objects)
q=dict(status='BUILDING_DIAGNOSTIC_NOT_QUALIFIED',actual_controller_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),driver_sha256=SHA(source.encode()),
       compiler=subprocess.check_output([compiler,'--version'],env=env,text=True).splitlines()[0],compiler_sha256=SHA(Path(compiler).read_bytes()),mixed_compiler_diagnostic=True,
       original_objects={p.name:SHA(p.read_bytes()) for p in objects},original_library_sha256=SHA((J/'build/ttutil-obj/libttutil.a').read_bytes()),model_days_executed=0,scientific_qualification=False,cases=[])
exe=B/'original_initialization_probe.exe'
command=[compiler,'-O0','-g','-fbacktrace','-ffree-line-length-none','-I',str(J/'build/swap-obj'),'-I',str(J/'build/ttutil-obj'),'probe.f90',*map(str,objects),str(J/'build/ttutil-obj/libttutil.a'),'-o',str(exe)]
q['command']=command
p=subprocess.run(command,cwd=B,env=env,capture_output=True,timeout=60)
(B/'compile.stdout').write_bytes(p.stdout);(B/'compile.stderr').write_bytes(p.stderr);q['compiler_returncode']=p.returncode
(B/'BUILD_DIAGNOSTIC.json').write_text(json.dumps(q,indent=2)+'\n');p.check_returncode();q['executable_sha256']=SHA(exe.read_bytes())
inputs=json.loads((E/'FROST_UNDRAINED_STATE08_CURRENT_READER_OBSERVATION_V1.json').read_text())
for item in inputs['cases']:
    original=Path(item['folder']);folder=D/original.name;shutil.copytree(original,folder)
    result=subprocess.run([str(exe),'./swap.swp'],cwd=folder,env=env,capture_output=True,timeout=30)
    (folder/'probe.stdout').write_bytes(result.stdout);(folder/'probe.stderr').write_bytes(result.stderr)
    phases=[s.decode() for s in result.stdout.splitlines() if s.startswith(b'ORIGINAL_INIT_PHASE ')]
    q['cases'].append(dict(case=item['case'],folder=str(folder),returncode=result.returncode,phases=phases,stdout_sha256=SHA(result.stdout),stderr_sha256=SHA(result.stderr),model_days=0))
    print(folder.name,result.returncode,phases[-1] if phases else 'NO_PHASE',flush=True)
q['status']='ORIGINAL_INITIALIZATION_PHASE_OBSERVATIONS_ONLY_NOT_QUALIFIED'
for path in [B/'RESULT.json',D/'RESULT.json',E/'FROST_UNDRAINED_STATE08_ORIGINAL_INITIALIZATION_PHASES_V1.json']:
    with path.open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
