"""Install next coherent functional batch on the sole real checkout."""
from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
C='082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66';BRANCH='codex/nomacro-frost-undrained-state08'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip();SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD')==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
for mode in ('PUBLIC','PUBLICATION'):
    q=json.loads((E/('CI_CHECKOUT_SCOPE07_CANDIDATE_'+mode+'_V5.json')).read_text());assert q['returncode']==0 and q['before']==q['after'] and q['before']['head']==C
negative=json.loads((E/'CI_CHECKOUT_SCOPE07_FINAL2_NEGATIVES_V1.json').read_text());assert negative['candidate']==C and negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+BRANCH],cwd=R).returncode==1
source=json.loads((E/'FROST_UNDRAINED_STATE08_SOURCE_PROPOSAL_V1.json').read_text())
for relative,item in source['files'].items():
    if not item.get('added'):
        assert SHA(subprocess.check_output(['git','show',C+':'+relative],cwd=R))==item['before_sha256']
    proposed=(E/'frost-undrained-state08-source-proposal-v1'/relative).read_bytes();assert SHA(proposed)==item['proposed_sha256'];compile(proposed,relative,'exec')
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','switch','-c',BRANCH],cwd=R,check=True)
paths=[]
for path in sorted((E/'frost-undrained-state08-source-proposal-v1').rglob('*.py')):
    relative=path.relative_to(E/'frost-undrained-state08-source-proposal-v1');target=R/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target);paths.append(relative.as_posix())
path=R/'tests/nomacro_drainage/frost_undrained_state_inputs.py';shutil.copyfile(E/'frost-undrained-state08-input-provider-proposal-v1.py',path);paths.append(path.relative_to(R).as_posix())
metadata=['FROST_UNDRAINED_STATE08_SOURCE_PROPOSAL_V1.json','FROST_UNDRAINED_STATE08_RUNTIME_PROPOSAL_V1.json','FROST_UNDRAINED_STATE08_NATIVE_CONTROLS_PROPOSAL_V1.json','FROST_UNDRAINED_STATE08_INPUT_CONTRACT_V1.json','FROST_UNDRAINED_STATE08_DEPENDENCY_STUDY_V1.json','FROST_UNDRAINED_STATE08_COMPILER_IDENTITY_CLARIFICATION_V1.json','FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.json','FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.zip']
for name in metadata:shutil.copyfile(E/name,P/name);paths.append((P/name).relative_to(R).as_posix())
status=json.loads((P/'STATUS.json').read_text());status['ci_checkout_scope07'].update(actual_candidate=C,actual_source_anchor='debb72039c28e136012c1cfa6cda157d25eecaee',actual_signed_CI_checkout='e2ad1538dae3fc1eefdfd9a5f4507043bdc0a9f3',latest_positive_version='V5',current_four_real_controls='CI_CHECKOUT_SCOPE07_FINAL2_NEGATIVES_V1.json',canonical_admission=False,current_CI='RUNNING_NO_MERGE_CLAIM')
status['frost_undrained_state08']=dict(status='BOUNDED_EXPERIMENTAL_COMPOSITION_IMPLEMENTED_REAL_PUBLIC_SMOKE_AND_SCIENTIFIC_QUALIFICATION_PENDING',branch=BRANCH,actual_parent_candidate=C,parent_PR=1806,parent_canonical_admission_pending=True,scientific_change_class='B_EXISTING_PROCESS_COMPOSITION',input_contract='FROST_UNDRAINED_STATE08_INPUT_CONTRACT_V1.json',diagnostic_raw_sha256='4dbbc19e93b8166ff90c8dc4a765fdc596381e5eef061cc70f4acc101f399854',original_reader_and_initialization_cases=4,original_csv0_normal35_cases=4,new_qualified_contexts=0,canonical_admission=False)
status['next_action']='Build and run real undrained Frost08 sensitive CDE implicit5 and water implicit8 contexts on actual source with unchanged1e-10 budgets and exact cold state. Finish actual07 CI/admission on its frozen candidate when ready; do not switch HEAD during either active model/observer. Reconcile genuine07 merge normally into08, preserving original scientific producer identities.'
status['recovery_point']='Sole checkout now starts bounded undrained Frost08 from genuine07 candidate082f3d4b8e with V5 PUBLIC/publication and four fresh true committed controls PASS.07 currentCI and canonical pending. Four original undrained process trajectories35days observed; original binary output buffer failure retained and existing qualified correction identified. No08 scientific admission yet.'
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n');paths.append((P/'STATUS.json').relative_to(R).as_posix())
gap=json.loads((P/'GAP_MATRIX.json').read_text());gap['frost_undrained_state08']=dict(classification='MISSING_COMPOSITION_AND_OVERRESTRICTIVE_GUARD',status=status['frost_undrained_state08']['status'],historical_support='GENUINE_ORIGINAL_READER_PROCESS_INITIALIZATION_AND_FOUR_CSV0_35DAY_NORMAL_RUNS_OBSERVED',scope='SWDRA0; original analytical1; water/CDE; explicit/implicit; lower5/8; hysteresis0/1/2; initial1/2; dense/periodic/monthly/date state',qualification='PENDING_TARGETED_CURRENT_BUDGET_NATIVE_COLD_AND_COMPILED_REFUSALS',new_qualified_contexts=0,whole_family_closed=False)
(P/'GAP_MATRIX.json').write_text(json.dumps(gap,indent=2)+'\n');paths.append((P/'GAP_MATRIX.json').relative_to(R).as_posix())
doc=R/'docs/science/NOMACRO_FROST_UNDRAINED_STATE08.md';doc.write_text('''# Bounded original undrained Frost state/calendar composition

Experimental candidate; current scientific qualification and canonical admission pending.

Original readers and process initialization accept four drainage-off Frost decks across water/CDE, explicit/implicit and lower5/8. The original binary output fails during its known buffer-lifetime defect; changing only SWCSV to0 gives four normal35-day original completions. Raw failures, phase probes, compiler identities and output-only counterfactuals are retained in the original diagnostic archive. Existing qualified binary/vector output corrections are reused; no new output or mass repair is introduced.

The proposed composition selects existing Frost, lower-boundary, event, thermal/calendar, CDE and exact native owners with SWDRA0. It must never select or claim the Divdra overlap correction. New distinct drainage-off codecs and implicit root header5 reject foreign drainage/state while retaining the same actual carried values. Water/CDE absolute1e-10 limits, physical fluxes, Newton criteria, rollback and exact cold restart remain unchanged.

The16-case input contract forms one representative batch across water/CDE, explicit/implicit, lower5/8, hysteresis and initial-state modes, dense/calendar output and real year seams. It is not a claim of complete historical family closure. New scientifically qualified contexts:0. Whole migration PARTIAL; whole science NOT_QUALIFIED; global family/gap counts UNKNOWN; RC3 unchanged.

Parent07 canonical admission is pending. Source and compiler/observer identities must remain real; complete historical evidence reuse requires explicit unchanged dependency and compiled-postimage custody. No old scientific model periods are replayed solely for metadata.
''',encoding='utf8',newline='\n');paths.append(doc.relative_to(R).as_posix())
for relative in paths:
    if relative.endswith('.py'):compile((R/relative).read_bytes(),relative,'exec')
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*paths],cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Compose existing undrained Frost boundary state and calendar owners for qualification'],cwd=R,check=True)
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=dict(status='REAL_UNDRAINED_FROST_COMPOSITION_CANDIDATE_COMMITTED_NOT_SCIENTIFICALLY_QUALIFIED',actual_source=git('rev-parse','HEAD'),actual_tree=git('rev-parse','HEAD^{tree}'),parent_candidate=C,branch=BRANCH,parent_canonical_admission_pending=True,new_qualified_contexts=0,canonical_admission=False)
with (E/'FROST_UNDRAINED_STATE08_IMPLEMENTED_CANDIDATE_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps(q),flush=True)
