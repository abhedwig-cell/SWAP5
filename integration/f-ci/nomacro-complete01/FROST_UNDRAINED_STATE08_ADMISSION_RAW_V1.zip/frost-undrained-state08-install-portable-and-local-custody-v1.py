"""Commit real local evidence once and launch one coherent portable scope."""
from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
SOURCE='656cd3ed25c91dc6ab8de12f2525fd30be8e358f';git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip();SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD')==SOURCE and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
local=json.loads((E/'FROST_UNDRAINED_STATE08_LOCAL_WINDOWS_O0_O2_RAW_V1.json').read_text());assert local['actual_scientific_source']==SOURCE and (local['primary_days'],local['native_samples'],local['exact_cold_windows'],local['actual_compiled_refusals'],local['transactions'])==(94,22,10,224,4)
paths=[]
for original,target in [('frost-undrained-state08-input-contract-proposal-v1.py','tests/nomacro_drainage/frost_undrained_input_contract.py'),('frost-undrained-state08-portable-proposal-v1.py','tests/nomacro_drainage/frost_undrained_portable.py'),('frost-undrained-state08-inherited-postimages-proposal-v1.py','tests/nomacro_drainage/frost_undrained_inherited_postimages.py')]:
    raw=(E/original).read_bytes();compile(raw,target,'exec');(R/target).write_bytes(raw);paths.append(target)
control=json.loads((E/'FROST_UNDRAINED_STATE08_ACTIVE_FROST_CONTROL_PROPOSAL_V1.json').read_text());assert SHA((R/control['path']).read_bytes().replace(b'\r\n',b'\n'))==control['before_lf_sha256']
for path in (E/'frost-undrained-state08-source-proposal-v2').rglob('*'):
    if not path.is_file():continue
    relative=path.relative_to(E/'frost-undrained-state08-source-proposal-v2').as_posix();raw=path.read_bytes()
    if relative.endswith('.py'):compile(raw,relative,'exec')
    (R/relative).parent.mkdir(parents=True,exist_ok=True);(R/relative).write_bytes(raw);paths.append(relative)
for manifest_name in ['FROST_UNDRAINED_STATE08_LOCAL_WINDOWS_O0_O2_RAW_V1','FROST_UNDRAINED_STATE08_PUBLIC_DOMAIN_REFUSALS_RAW_V1']:
    q=json.loads((E/(manifest_name+'.json')).read_text());raw=(E/q['archive']).read_bytes();assert len(raw)==q['bytes'] and SHA(raw)==q['sha256'];parts=[];chunk=25*1024*1024
    for index,offset in enumerate(range(0,len(raw),chunk),1):
        piece=raw[offset:offset+chunk];name=q['archive']+('.part'+str(index).zfill(3) if len(raw)>chunk else '');(P/name).write_bytes(piece);assert (P/name).read_bytes()==piece;parts.append(dict(file=name,bytes=len(piece),sha256=SHA(piece)));paths.append((P/name).relative_to(R).as_posix())
    q['parts']=parts;(P/(manifest_name+'.json')).write_text(json.dumps(q,indent=2)+'\n');paths.append((P/(manifest_name+'.json')).relative_to(R).as_posix())
for name in ['FROST_UNDRAINED_STATE08_ACTIVE_FROST_CONTROL_PROPOSAL_V1.json','FROST_UNDRAINED_STATE08_PORTABLE_WORKFLOW_PROPOSAL_V1.json']:
    shutil.copyfile(E/name,P/name);paths.append((P/name).relative_to(R).as_posix())
status=json.loads((P/'STATUS.json').read_text());status['ci_checkout_scope07'].update(current_CI='ALL16_CURRENT_WORKFLOWS_SUCCESS_48_TERMINAL_CHECKS_30_SUCCESS_18_POLICY_SKIP',actual_candidate='082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66',canonical_admission=False)
status['frost_undrained_state08'].update(status='FOUR_REAL_LOCAL_O0_O2_CONTEXTS_PASS_RAW_SOURCE_NATIVE_REFUSALS_PRESERVED_PORTABLE64_PENDING',actual_local_scientific_source=SOURCE,local_primary_days=94,local_native_samples=22,local_exact_cold_windows=10,local_actual_compiled_refusals=224,local_transactions=4,local_raw_sha256=local['sha256'],new_admitted_contexts=0,portable_representative_cases=16,portable_profiles=['WindowsO0','WindowsO2','UbuntuO0','UbuntuO2'],unchanged_drained_compile_only_cases_per_profile=8,parent_canonical_admission_pending=True)
status['next_action']='Finish true07 premerge closure and actual signed canonical observers on frozen082candidate; meanwhile execute coherent08 Windows/Ubuntu O0/O2 new16case campaign and8 unchanged drained compile-only postimages. Preserve original actual local producer656cd3, original refusals and pending parent admission; no old model-period replay for metadata.'
(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n');paths.append((P/'STATUS.json').relative_to(R).as_posix())
gap=json.loads((P/'GAP_MATRIX.json').read_text());gap['frost_undrained_state08'].update(status=status['frost_undrained_state08']['status'],actual_local_scientific_source=SOURCE,local_primary_days=94,local_exact_cold_windows=10,portable_scientific_admission='PENDING',new_qualified_contexts=0);(P/'GAP_MATRIX.json').write_text(json.dumps(gap,indent=2)+'\n');paths.append((P/'GAP_MATRIX.json').relative_to(R).as_posix())
doc=R/'docs/science/NOMACRO_FROST_UNDRAINED_STATE08.md';s=doc.read_text();s+='\nActual local scientific producer `'+SOURCE+'` passes four Windows contexts (O0/O2 CDE implicit5 dense35 and water implicit8 initial1 date/year12):94 primary days,22 native samples,10 exact cold windows,224 actual compiled refusals and4 calendar/Snow transactions. Original28-term limits are unchanged; maximum original day/prefix residuals are retained in the raw manifest. These local observations do not constitute portable or canonical admission. Their original day4 calendar transaction start is retained honestly; the portable candidate adds a real Frost-active day19 start with original-temperature validation and the same discard/replay algorithm. Parent07 actual canonical admission remains pending.\n';doc.write_text(s,encoding='utf8',newline='\n');paths.append(doc.relative_to(R).as_posix())
assert not git('diff',SOURCE,'--','app','src','tools','reference')
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--sparse','--',*paths],cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Preserve four real undrained Frost probes and qualify coherent portable state scope'],cwd=R,check=True)
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=dict(status='PORTABLE_UNDRAINED_FROST_CANDIDATE_AND_ORIGINAL_LOCAL_EVIDENCE_COMMITTED_NOT_ADMITTED',actual_candidate=git('rev-parse','HEAD'),actual_tree=git('rev-parse','HEAD^{tree}'),original_local_scientific_source=SOURCE,local_raw_sha256=local['sha256'],parent_candidate='082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66',parent_canonical_admission_pending=True,new_admitted_contexts=0)
with (E/'FROST_UNDRAINED_STATE08_PORTABLE_CANDIDATE_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps(q),flush=True)
