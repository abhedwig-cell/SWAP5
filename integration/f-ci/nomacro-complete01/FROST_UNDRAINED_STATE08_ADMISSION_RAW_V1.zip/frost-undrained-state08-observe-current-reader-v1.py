"""Observe genuine current reader refusals; no source changes or model execution."""
from pathlib import Path
import hashlib,json,subprocess,sys
E=Path(__file__).resolve().parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'app/hybrid_water')]
from frost_implicit_hys2_inputs import prepare as implicit_inputs
from frost_boundary_state_calendar_inputs import prepare as explicit_inputs
from original_output_baseline import assignment
from experimental_project import inspect
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
head=git('rev-parse','HEAD');assert head=='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d'
before=git('status','--porcelain=v1','--untracked-files=all','--ignored');assert not before
out=E/'frost-undrained-state08-current-reader-inputs-v1';out.mkdir()
cases=[]
for kind,implicit,bottom in [('water',0,8),('cde',0,5),('water',1,5),('cde',1,8)]:
    case=dict(kind=kind,implicit=implicit,bottom=bottom,hysteresis=2,initial=2,
              calendar='parent-dense' if implicit else 'dense',days=35,reset=1,start=None)
    folder=out/(kind+'-i'+str(implicit)+'-b'+str(bottom))
    (implicit_inputs if implicit else explicit_inputs)(case,folder)
    path=folder/'swap.swp';text=path.read_text(encoding='cp1252')
    path.write_text(assignment(text,'SWDRA',0),encoding='cp1252')
    try:
        result=inspect(folder,original_output=True)
        observation=dict(accepted=True,selectors=result['selectors'])
    except ValueError as error:
        observation=dict(accepted=False,exception_type=type(error).__name__,message=str(error))
    files={p.relative_to(folder).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in folder.rglob('*') if p.is_file()}
    cases.append(dict(case=case,actual_swdra=0,folder=str(folder),files=files,observation=observation))
assert git('rev-parse','HEAD')==head and git('status','--porcelain=v1','--untracked-files=all','--ignored')==before
q=dict(status='ACTUAL_PUBLIC_READER_OBSERVATIONS_ONLY_NOT_HISTORICAL_RUNTIME_QUALIFICATION',actual_source=head,cases=cases,
       compiler_executions=0,model_executions=0,scientific_qualification=False,
       next_action='Observe original reader and process dispatch with genuine original provider, then compose bounded undrained build, event, native and source guards with targeted balances and exact cold seams. Do not remove a single guard in isolation.',
       unique_inputs_preserved=True,source_or_filesystem_identity_projected=False)
with (E/'FROST_UNDRAINED_STATE08_CURRENT_READER_OBSERVATION_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
for item in cases:print(item['folder'],json.dumps(item['observation']),flush=True)
