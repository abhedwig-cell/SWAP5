"""Output-only original diagnostic; preserve initial CSV3 crashes, no admission."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
E=Path(__file__).resolve().parent;W=E.parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
original=W/'frost-undrained-state08-original35-v1';D=original/'csv0-counterfactual-v1';D.mkdir()
sys.path.insert(0,str(R/'tests/nomacro_scheduled_subsurface'))
from original_output_baseline import assignment
SHA=lambda b:hashlib.sha256(b).hexdigest()
prior=json.loads((original/'RESULT.json').read_text());exe=J/'build/swap_b0_gfortran.exe';assert SHA(exe.read_bytes())==prior['original_executable_sha256']
q=dict(status='RUNNING_OUTPUT_ONLY_ORIGINAL_COUNTERFACTUAL_NOT_QUALIFIED',original_observation_sha256=SHA((original/'RESULT.json').read_bytes()),original_executable_sha256=SHA(exe.read_bytes()),compiler_executions=0,SWAP5_model_executions=0,scientific_qualification=False,cases=[])
env=dict(os.environ,OMP_NUM_THREADS='1',PATH='C:/msys64/ucrt64/bin;'+os.environ.get('PATH',''))
for row in prior['cases']:
    case=row['case'];name=case['kind']+'-i'+str(case['implicit'])+'-b'+str(case['bottom']);source=original/name;folder=D/name;folder.mkdir()
    for name,digest in row['input_inventory'].items():
        raw=(source/name).read_bytes();assert SHA(raw)==digest
        path=folder/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    path=folder/'swap.swp';before=path.read_bytes();after=assignment(before.decode('cp1252'),'SWCSV',0).encode('cp1252');assert after!=before;path.write_bytes(after)
    started=time.perf_counter();error=None;code=None
    with (folder/'original.stdout').open('xb') as out,(folder/'original.stderr').open('xb') as err:
        try:run=subprocess.run([str(exe),'./swap.swp'],cwd=folder,env=env,stdout=out,stderr=err,timeout=180);code=run.returncode
        except subprocess.TimeoutExpired as exc:error=repr(exc)
    observed=dict(case=case,actual_swdra=0,actual_SWCSV=0,actual_TEND=row['actual_TEND'],maximum_model_days=35,
                  only_changed_requested_output_selector='SWCSV',original_input_sha256=SHA(before),actual_input_sha256=SHA(after),
                  returncode=code,error=error,seconds=time.perf_counter()-started,
                  normal_completion=b'Swap normal completion!' in (folder/'original.stdout').read_bytes(),
                  actual_outputs={p.name:dict(bytes=p.stat().st_size,sha256=SHA(p.read_bytes())) for p in folder.iterdir() if p.is_file()})
    q['cases'].append(observed);(D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n');print(folder.name,code,observed['normal_completion'],observed['seconds'],flush=True)
q['status']='OUTPUT_ONLY_ORIGINAL_CSV0_COUNTERFACTUAL_OBSERVED_NOT_QUALIFIED';(D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
with (E/'FROST_UNDRAINED_STATE08_ORIGINAL_CSV0_COUNTERFACTUAL_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
