"""Run genuine original SWAP on four new undrained Frost decks, at most35 days."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
E=Path(__file__).resolve().parent;W=E.parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
D=W/'frost-undrained-state08-original35-v1'
sys.path.insert(0,str(R/'tests/nomacro_scheduled_subsurface'))
from original_output_baseline import assignment
SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
head=git('rev-parse','HEAD');assert head=='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d'
before=git('status','--porcelain=v1','--untracked-files=all','--ignored');assert not before
assert D.is_dir() and not any(D.iterdir())
prepared=json.loads((J/'PREPARED.json').read_text())
for name,digest in prepared['provider_files'].items():assert SHA((J/name).read_bytes())==digest,name
exe=J/'build/swap_b0_gfortran.exe'
observation=json.loads((E/'FROST_UNDRAINED_STATE08_CURRENT_READER_OBSERVATION_V1.json').read_text())
q=dict(status='RUNNING_NEW_UNDRAINED_FROST_ORIGINAL_OBSERVATION_NOT_ADMITTED',actual_controller_source=head,
       original_provider=str(J),original_PREPARED_sha256=SHA((J/'PREPARED.json').read_bytes()),
       original_executable_sha256=SHA(exe.read_bytes()),original_compiler=prepared['toolchain']['gfortran'],
       compiler_executions=0,qualification=False,SWAP5_model_executions=0,cases=[])
save=lambda:(D/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
save()
for item in observation['cases']:
    source=Path(item['folder']);folder=D/source.name;shutil.copytree(source,folder)
    for name,meta in item['files'].items():assert SHA((folder/name).read_bytes())==meta['sha256']
    path=folder/'swap.swp';path.write_text(assignment(path.read_text(encoding='cp1252'),'TEND','2002-02-04'),encoding='cp1252')
    inventory={p.relative_to(folder).as_posix():SHA(p.read_bytes()) for p in folder.rglob('*') if p.is_file()}
    start=time.perf_counter();error=None;code=None
    with (folder/'original.stdout').open('xb') as out,(folder/'original.stderr').open('xb') as err:
        try:run=subprocess.run([str(exe),'./swap.swp'],cwd=folder,stdout=out,stderr=err,timeout=180);code=run.returncode
        except subprocess.TimeoutExpired as exc:error=repr(exc)
    row=dict(case=item['case'],actual_swdra=0,actual_TEND='2002-02-04',maximum_model_days=35,
             input_inventory=inventory,returncode=code,error=error,seconds=time.perf_counter()-start,
             stdout_sha256=SHA((folder/'original.stdout').read_bytes()),stderr_sha256=SHA((folder/'original.stderr').read_bytes()),
             public_reader_refusal_preserved=item['observation'],original_outputs={p.name:dict(bytes=p.stat().st_size,sha256=SHA(p.read_bytes())) for p in folder.iterdir() if p.is_file() and p.name not in inventory})
    q['cases'].append(row);save();print(folder.name,code,error,row['seconds'],flush=True)
assert git('rev-parse','HEAD')==head and git('status','--porcelain=v1','--untracked-files=all','--ignored')==before
q['status']='FOUR_NEW_UNDRAINED_FROST_GENUINE_ORIGINAL_RUNS_OBSERVED_NOT_SCIENTIFICALLY_ADMITTED';save()
with (E/'FROST_UNDRAINED_STATE08_ORIGINAL35_OBSERVATION_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
