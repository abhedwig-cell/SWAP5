"""Close actual source, original science, observations, negatives and selected CI."""
from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='cc0f81f6f54d5b64e186da5582712ee15a77bc20';B='0b482de01847dd8ba5f93c63881b9aeff468d3e3';S='877d9ee67e9400436cb4d96ea7358c31d544052d'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
read=lambda n:json.loads((E/n).read_text())
assert git('rev-parse','HEAD')==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
assert not git('diff','127af752c5519e7f9d9a6894c61137f0ee7f3920',C,'--','app','src','tools','reference')
tree=git('rev-parse',C+'^{tree}');api=read('FROST_UNDRAINED_STATE08_PR1807_GENUINE_SYNTHETIC_GIT_API_V1.json')
assert api['sha']==S and api['tree']['sha']==tree and [x['sha'] for x in api['parents']]==[B,C] and api['verification']['verified'] and api['verification']['reason']=='valid'
raw=(E/('FROST_UNDRAINED_STATE08_PR1807_GENUINE_GIT_OBJECT_'+S+'.bin')).read_bytes();assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==S and raw==subprocess.check_output(['git','cat-file','commit',S],cwd=R)
observations={};fixtures=None
for scope in ['PUBLIC','PUBLICATION']:
    stem='FROST_UNDRAINED_STATE08_CANDIDATE_'+scope+'_V2';q=read(stem+'.json');out=(E/(stem+'.stdout.txt')).read_bytes()
    assert q['returncode']==0 and q['error'] is None and q['before']==q['after'] and not q['before']['status'] and not (E/(stem+'.stderr.txt')).read_bytes()
    before=q['before'];assert before['head']==C and before['tree']==tree and len(before['sparse'])==14 and len(before['original_project_files'])==56
    if fixtures is None:fixtures=before['original_project_files']
    assert before['original_project_files']==fixtures
    if scope=='PUBLIC':
        science=json.loads(out);assert science['coadmission']['contexts']==712 and len(science['new_original_portable_science'])==4 and len(science['additional_actual_local_science']['contexts'])==4
        assert science['compiler_executions']==science['model_executions']==0 and science['whole_scientific_equivalence']=='NOT_QUALIFIED' and science['functional_completion']=='PARTIAL' and not science['RC3_changed']
    else:assert b'PUBLICATION_REPLAY_SELECTED=false' in out and q['ordinary_python_default_dont_write_bytecode'] is False and q['child_bytecode_environment_variables_absent']
    observations[scope]=q['seconds']
neg=read('FROST_UNDRAINED_STATE08_FINAL2_NEGATIVES_V1.json');assert neg['candidate']==C and neg['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
assert len(neg['controls'])==4 and {x['role'] for x in neg['controls']}=={'SOURCE','RAW','INHERITED','PUBLICATION'}
for item in neg['controls']:
    assert item['actual_refusal'] and item['actual_one_file_delta'] and git('show','-s','--format=%P',item['head'])==C and git('diff','--name-only',C,item['head'])==item['path']
    assert git('ls-remote','--heads','origin','refs/heads/'+item['branch']).split()[0]==item['head']
    if item['role']=='PUBLICATION':assert item['actual_publication_replay_selected']
ci=read('FROST_UNDRAINED_STATE08_PR1807_FINAL_ALL_CI_API_V1.json');runs=ci['runs']['workflow_runs'];checks=ci['checks']['check_runs']
assert ci['runs']['total_count']==len(runs)==len({x['workflow_id'] for x in runs})==14 and all(x['head_sha']==C and x['status']=='completed' and x['conclusion']=='success' for x in runs)
assert ci['checks']['total_count']==len(checks)==45 and all(x['head_sha']==C and x['status']=='completed' and x['conclusion'] in ['success','skipped'] for x in checks)
assert sum(x['conclusion']=='success' for x in checks)==28 and sum(x['conclusion']=='skipped' for x in checks)==17
for role in ['CO2','DVS','LRV','TIMEINT_STARTUP','TIMEINT_INVERSE','FCI_MODULAR']:
    name='FROST_UNDRAINED_STATE08_PR1807_'+role+'_ORIGINAL_CI_V1.log';raw=(E/name).read_bytes();q=read(name+'.json')
    assert len(raw)==q['bytes'] and hashlib.sha256(raw).hexdigest()==q['sha256'] and q['actual_source']==C and q['actual_checkout']==S and C.encode() in raw and S.encode() in raw
selection=read('FROST_UNDRAINED_STATE08_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json');assert selection['actual_parent']==B and selection['actual_candidate']==C and selection['unchanged_tracked_files']==1063 and not git('diff',B,C,'--',*selection['unchanged_dependency_paths'])
assert git('rev-parse','HEAD')==C
q=dict(status='ACTUAL_UNDRAINED_FROST_CANDIDATE_SOURCE_ORIGINAL64_LOCAL4_NATIVE_COLD_ACTIVE_TRANSACTIONS_PUBLIC_PUB_FOUR_REAL_NEGATIVES_AND14CI45CHECKS_CLOSED',actual_candidate=C,actual_parent=B,actual_synthetic=S,actual_tree=tree,actual_positive_observation_seconds=observations,prospective_contexts=712,new_contexts=64,scientific_portable_producer='127af752c5519e7f9d9a6894c61137f0ee7f3920',scientific_local_producer='656cd3ed25c91dc6ab8de12f2525fd30be8e358f',original_scientific_producers_rebound=False,current_MCSOL_model_replay='NOT_SELECTED_IMPACT_1063_EXACT_DEPENDENCY_FILES',current_HUPSEL_model_replay='NOT_SELECTED_WORKFLOW_PATHS_OR_ORIGINAL_HUPSEL_MODEL_JOB_NOT_CHANGED',current_POND_model_replay='NOT_SELECTED_EXISTING_PRIVATE_FROST_PATH_SELECTION_PARENT_SUCCESS_RETAINED',model_periods_replayed_for_metadata=0,canonical_admission=False,whole_functional_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
with (E/'FROST_UNDRAINED_STATE08_PREMERGE_CLOSURE_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],flush=True)
