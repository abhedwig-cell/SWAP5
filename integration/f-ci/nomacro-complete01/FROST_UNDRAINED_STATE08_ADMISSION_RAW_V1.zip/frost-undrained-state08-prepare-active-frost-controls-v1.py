"""Use a real partially frozen start for the new drainage-off transaction test."""
from pathlib import Path
import hashlib,json
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
path='tests/nomacro_drainage/frost_undrained_state_controls.py';before=(R/path).read_bytes().replace(b'\r\n',b'\n');s=before.decode()
helper='''
def active_frost_start(checkpoint,project):
    import math,re,struct,zipfile
    with zipfile.ZipFile(checkpoint) as archive:raw=archive.read('result.end')
    records=[];offset=0
    while offset<len(raw):
        count=struct.unpack_from('<i',raw,offset)[0]
        assert 0<=count<=len(raw)-offset-8 and struct.unpack_from('<i',raw,offset+4+count)[0]==count
        records.append(raw[offset+4:offset+4+count]);offset+=count+8
    values=iter(records)
    def take(fmt):return struct.unpack('<'+fmt,next(values))
    integer=lambda:take('i')[0]
    assert integer()==1 and integer()==0;nodes=integer();assert nodes==project.nodes
    take(str(nodes)+'d');take('d');assert integer()==1;take('d');take('d')
    evaporation=integer();assert evaporation in (0,1,2)
    for _ in range(evaporation):take('d')
    mode=integer();assert mode in (0,1,2)
    if mode:
        take(str(nodes)+'i')
        for _ in range(3):take(str(nodes)+'d')
    assert integer()==1;temperature=take(str(nodes)+'d');assert all(map(math.isfinite,temperature))
    text=(Path(project.input_directory)/'swap.swp').read_text(encoding='cp1252')
    limits=re.findall(r'(?mi)^[ \\t]*TFROSTSTA[ \\t]*=[ \\t]*([^!\\r\\n]+)',text);assert len(limits)==1
    limit=float(limits[0].strip().replace('D','e').replace('d','e'));assert math.isfinite(limit)
    assert min(temperature)<limit,'Transaction start has no actual original Frost-active soil temperature'
    return dict(original_temperature_min_C=min(temperature),original_temperature_max_C=max(temperature),actual_TFROSTSTA_C=limit,actual_original_Frost_active=True)


'''
anchor='def main():\n';assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor,1)
a="        start=30 if project.start_date[5:7]=='12' else 4";b="        start=30 if project.start_date[5:7]=='12' else 19\n        q['actual_active_frost_start']=active_frost_start(full/f'accepted-column-1-day-{start}.zip',project);save()";assert s.count(a)==1;s=s.replace(a,b,1)
compile(s,path,'exec');D=E/'frost-undrained-state08-source-proposal-v2';target=D/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(s,encoding='utf8',newline='\n')
q=dict(status='NEW_DRAINAGE0_TRANSACTION_ACTUAL_FROST_ACTIVE_START_PROPOSAL_NO_MODEL_PERIOD_REPLAY',path=path,before_lf_sha256=hashlib.sha256(before).hexdigest(),proposed_lf_sha256=hashlib.sha256(s.encode()).hexdigest(),old_transaction_algorithm_unchanged=True,new_start_day=19,actual_original_temperature_checked=True,new_qualified_contexts=0)
with (E/'FROST_UNDRAINED_STATE08_ACTIVE_FROST_CONTROL_PROPOSAL_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'])
