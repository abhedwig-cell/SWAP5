"""Preserve existing refusal/transaction algorithms with actual new typed domain."""
from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=E/'frost-undrained-state08-source-proposal-v1'
C='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d';records=[]
for old,new,edits in [
 ('frost_calendar_state_root_controls.py','frost_undrained_state_root_controls.py',[("[4,project.nodes,int(project.solute),1,mode,bottom,1,0]","[5,project.nodes,int(project.solute),1,mode,bottom,1,0]")]),
 ('frost_calendar_state_extra_native.py','frost_undrained_state_extra_native.py',[
  ("b'S5BCW002',b'S5BCC002')","b'S5BCW002',b'S5BCC002',b'S5UDW001',b'S5UDC001',b'S5UDW002',b'S5UDC002')"),
  ('len(set(codecs))==16','len(set(codecs))==20'),('(39 if project.solute else 35)','(43 if project.solute else 39)')]),
 ('frost_calendar_state_controls.py','frost_undrained_state_controls.py',[
  ('from frost_calendar_state_extra_native import extra','from frost_undrained_state_extra_native import extra'),
  ('frost_calendar_state_root_controls.py','frost_undrained_state_root_controls.py'),
  ("selected=m.e.switches((Path(project.input_directory)/'swap.swp').read_text(encoding='cp1252'))","selected=m.e.switches((Path(project.input_directory)/'swap.swp').read_text(encoding='cp1252'));assert selected['SWDRA']==0"),
  ('ACTUAL_FROST_CALENDAR_COMPILED_NATIVE_SNOW_CDE_ROOT_AND_TRANSACTIONS_PASS_NOT_ADMITTED','ACTUAL_UNDRAINED_FROST_COMPILED_NATIVE_SNOW_CDE_ROOT_AND_TRANSACTIONS_PASS_NOT_ADMITTED')])]:
    source='tests/nomacro_drainage/'+old;target='tests/nomacro_drainage/'+new;raw=subprocess.check_output(['git','show',C+':'+source],cwd=R);s=raw.decode()
    for before,after in edits:
        assert s.count(before)==1,(old,before);s=s.replace(before,after)
    compile(s,target,'exec');p=D/target;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
    records.append(dict(parent=source,path=target,actual_parent_revision=C,parent_sha256=hashlib.sha256(raw).hexdigest(),proposed_sha256=hashlib.sha256(s.encode()).hexdigest(),ordered_literal_edits=[dict(before=a,after=b) for a,b in edits]))
q=dict(status='TYPED_NATIVE_CONTROLS_PROPOSALS_ONLY_NOT_INSTALLED_OR_QUALIFIED',files=records,old_refusal_and_transaction_algorithms_unchanged=True,new_codec_variants_added=4,root_header=5,actual_compiled_refusals_executed=0)
with (E/'FROST_UNDRAINED_STATE08_NATIVE_CONTROLS_PROPOSAL_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'])
