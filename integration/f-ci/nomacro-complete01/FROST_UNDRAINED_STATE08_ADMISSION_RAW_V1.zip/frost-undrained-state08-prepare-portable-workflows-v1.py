"""Reuse the actual portable source/byte-custody workflow for one functional batch."""
from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');D=E/'frost-undrained-state08-source-proposal-v2';records=[]
for host in ('windows','ubuntu'):
    parent=f'.github/workflows/nomacro-frost-implicit-hys2-year06-{host}.yml';target=f'.github/workflows/nomacro-frost-undrained-state08-{host}.yml'
    raw=subprocess.check_output(['git','show','df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c:'+parent],cwd=R);s=raw.decode()
    edits=[('codex/nomacro-frost-implicit-hys2-calendar06','codex/nomacro-frost-undrained-state08'),
           ('nomacro-frost-implicit-hys2-year06','nomacro-frost-undrained-state08'),
           ('Original implicit Frost hysteresis2 boundary state/calendar','Original undrained Frost boundary state/calendar'),
           ('47124f4de18a752fc466d50e2752e843548e5fea','df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c'),
           ('FROST_IMPLICIT_HYS2_YEAR06_CONTRACT_V1','FROST_UNDRAINED_STATE08_INPUT_CONTRACT_V1'),
           ('frost_implicit_hys2_input_contract.py','frost_undrained_input_contract.py'),
           ('frost_implicit_hys2_inherited_postimages.py','frost_undrained_inherited_postimages.py'),
           ('frost_implicit_hys2_portable.py','frost_undrained_portable.py')]
    for before,after in edits:
        assert before in s,(host,before);s=s.replace(before,after)
    path=D/target;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(s,encoding='utf8',newline='\n')
    records.append(dict(path=target,parent=parent,actual_parent_revision='df00f9393ac552b0a6cab8ee84f8b8d8c06ac26c',parent_sha256=hashlib.sha256(raw).hexdigest(),proposed_sha256=hashlib.sha256(s.encode()).hexdigest(),ordered_literal_replacements=[dict(before=a,after=b) for a,b in edits],actual_scientific_producer='ACTUAL_GITHUB_SHA_AT_EXECUTION_NEVER_REBOUND',old_model_periods_replayed_by_inherited_builds=0))
q=dict(status='TWO_PORTABLE_WORKFLOWS_PREPARED_FOR_NEW_UNDRAINED_COMPOSITION_NOT_YET_EXECUTED',workflows=records,new_representative_cases=16,profiles=['WindowsO0','WindowsO2','UbuntuO0','UbuntuO2'],existing_drained_compile_only_postimage_cases_per_profile=8,scientific_admission=False)
with (E/'FROST_UNDRAINED_STATE08_PORTABLE_WORKFLOW_PROPOSAL_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'])
