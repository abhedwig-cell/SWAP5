"""Keep original budgets/cold runtime, with actual drainage0 and root5 witnesses."""
from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d'
old='tests/nomacro_drainage/frost_calendar_state_runtime.py';new='tests/nomacro_drainage/frost_undrained_state_runtime.py'
raw=subprocess.check_output(['git','show',C+':'+old],cwd=R);s=raw.decode()
edits=[('thermal=struct.pack(\'<10i\',1,nodes,0,solute,hys,1,1,1,1,2)','thermal=struct.pack(\'<10i\',1,nodes,0,solute,hys,1,1,0,1,2)'),
       ('header=(4,nodes,solute,1,hys,selected.get(\'bottom\',6),1,0)','header=(5,nodes,solute,1,hys,selected[\'bottom\'],1,0)'),
       ("selected=input_selection(project.input_directory,True);assert selected","selected=input_selection(project.input_directory,True);assert selected and selected.get('undrained_frost') and selected['drainage']==0"),
       ("if a.year_seam and a.days==35:windows.append((15,19))","if a.year_seam:\n        if a.days==35:windows.append((15,19))\n        else:windows.append((5,9))"),
       ('RUNNING_ACTUAL_FROST_CALENDAR_NOT_QUALIFIED','RUNNING_ACTUAL_UNDRAINED_FROST_CALENDAR_NOT_QUALIFIED'),
       ('FAILED_ACTUAL_FROST_CALENDAR_NOT_QUALIFIED','FAILED_ACTUAL_UNDRAINED_FROST_CALENDAR_NOT_QUALIFIED'),
       ('ACTUAL_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED','ACTUAL_UNDRAINED_FROST_CALENDAR_ORIGINAL_BUDGETS_NATIVE_HISTORY_COLD_AND_USER_OUTPUT_PASS_NOT_ADMITTED')]
for before,after in edits:
    assert s.count(before)==1,before;s=s.replace(before,after)
compile(s,new,'exec');D=E/'frost-undrained-state08-source-proposal-v1';p=D/new;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
q=dict(status='RUNTIME_PROPOSAL_SYNTAX_ONLY_NOT_INSTALLED_OR_QUALIFIED',actual_base=C,parent_path=old,parent_source_sha256=hashlib.sha256(raw).hexdigest(),path=new,proposed_sha256=hashlib.sha256(s.encode()).hexdigest(),ordered_literal_edits=[dict(before=a,after=b) for a,b in edits],scientific_budget_algorithm_unchanged=True,exact_native_restart_unchanged=True,actual_new_domain_witness='SWDRA0_ROOT_HEADER5',model_runs=0)
with (E/'FROST_UNDRAINED_STATE08_RUNTIME_PROPOSAL_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'])
