"""Prepare reviewable exact literal composition edits outside the frozen checkout."""
from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='39d00d6b1d15dbe1132a0b6a2eb361d2459e697d';D=E/'frost-undrained-state08-source-proposal-v1';D.mkdir()
SHA=lambda b:hashlib.sha256(b).hexdigest()
files={}
def change(name,edits):
    path='app/hybrid_water/'+name;original=subprocess.check_output(['git','show',C+':'+path],cwd=R);s=original.decode();recipe=[]
    for before,after,count in edits:
        assert s.count(before)==count,(name,before,s.count(before),count)
        s=s.replace(before,after);recipe.append(dict(before=before,after=after,count=count))
    compile(s,path,'exec');raw=s.encode();inverse=s
    for item in reversed(recipe):
        assert inverse.count(item['after'])==item['count'],(name,item['after'])
        inverse=inverse.replace(item['after'],item['before'])
    assert inverse.encode()==original
    target=D/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    files[path]=dict(before_sha256=SHA(original),proposed_sha256=SHA(raw),ordered_literal_replacements=recipe)

change('frost_boundary_state_calendar.py',[
 ("def input_domain(selectors,boundary,original_output):\n","def input_domain(selectors,boundary,original_output):\n    from frost_undrained_state import input_domain as undrained_domain\n    if undrained_domain(selectors,boundary,original_output):return True\n",1),
 ("def selection(directory,original_output=True):\n","def selection(directory,original_output=True):\n    from frost_undrained_state import selection as undrained_selection\n    undrained=undrained_selection(directory,original_output)\n    if undrained is not None:return undrained\n",1),
 ("def codec(selected):\n","def codec(selected):\n    if selected.get('undrained_frost'):\n        from frost_undrained_state import codec as undrained_codec\n        return undrained_codec(selected)\n",1)])
change('frost_drainage_composition.py',[
 ("def enabled(project):\n","def enabled(project):\n    from frost_undrained_state import selected as undrained_selection\n    if undrained_selection(project) is not None:return True\n",1),
 ("def metadata(project):\n","def metadata(project):\n    from frost_undrained_state import metadata as undrained_metadata\n    undrained=undrained_metadata(project)\n    if undrained is not None:return undrained\n",1),
 ("def apply_build(output, donor_build, project, patched):\n","def apply_build(output, donor_build, project, patched):\n    from frost_undrained_state import selected as undrained_selection,apply_build as undrained_build\n    if undrained_selection(project) is not None:return undrained_build(output,project,patched)\n",1),
 ("def validate(bundle, reference, project, identity):\n","def validate(bundle, reference, project, identity):\n    from frost_undrained_state import selected as undrained_selection,validate as undrained_validate\n    if undrained_selection(project) is not None:return undrained_validate(bundle,project,identity)\n",1)])
change('implicit_frost_composition.py',[("def metadata(project):\n","def metadata(project):\n    from frost_undrained_state import selected as undrained_selection,metadata as undrained_metadata\n    undrained=undrained_selection(project)\n    if undrained is not None:return undrained_metadata(project) if undrained['implicit'] else None\n",1)])
change('implicit_frost_root_state.py',[
 ("def source(solute,mode=2,bottom=6):\n","def drainage(project):\n    from frost_undrained_state import selected\n    return 0 if selected(project) is not None else 1\n\n\ndef source(solute,mode=2,bottom=6,drain=1):\n    if type(drain) is not int or drain not in (0,1):\n        raise ValueError('Invalid implicit Frost native drainage domain')\n",1),
 ("'.or.swfrost/=1.or.swdra/=1.or.swhyst/='+str(mode)","'.or.swfrost/=1.or.swdra/='+str(drain)+'.or.swhyst/='+str(mode)",1),
 ("('expected=[1,numnod', 'expected=[4,numnod'),","('expected=[1,numnod', 'expected=['+str(5 if drain==0 else 4)+',numnod'),",1),
 ("source(project.solute,hysteresis(project),boundary(project))","source(project.solute,hysteresis(project),boundary(project),drainage(project))",5),
 ("bytes=96, header_version=4,\n        native_revision=2","bytes=96, header_version=5 if drainage(project)==0 else 4,\n        native_revision=3 if drainage(project)==0 else 2",1),
 ("expected=[4,project.nodes,int(project.solute),1,hysteresis(project),boundary(project),1,0]","expected=[5 if drainage(project)==0 else 4,project.nodes,int(project.solute),1,hysteresis(project),boundary(project),1,0]",1)])
change('frost_calendar_output.py',[
 ("swfrost=1,swdra=1,swhyst=selected['hysteresis']","swfrost=1,swdra=selected.get('drainage',1),swhyst=selected['hysteresis']",1),
 ("    if boundary.get('boundary_state_calendar'):providers+=['frost_boundary_state_calendar.py','frost_boundary_composition.py']","    if boundary.get('boundary_state_calendar'):providers+=['frost_boundary_state_calendar.py','frost_boundary_composition.py']\n    if boundary.get('undrained_frost'):providers.append('frost_undrained_state.py')",1)])
change('experimental_project.py',[("    if policy == EVENT_POLICY and not drained_frost:\n","    from frost_undrained_state import selection as undrained_frost_selection\n    undrained_frost=undrained_frost_selection(directory,original_output)\n    if undrained_frost is not None and policy!=EVENT_POLICY:\n        raise ValueError('Bounded undrained Frost state/calendar requires qualified original event closure')\n    if policy == EVENT_POLICY and not drained_frost and undrained_frost is None:\n",1)])
change('snow_undrained.py',[("def selection(project):\n","def selection(project):\n    from frost_undrained_state import selected as undrained_frost_selection\n    if undrained_frost_selection(project) is not None:return None\n",1)])
path='app/hybrid_water/frost_undrained_state.py';raw=(E/'frost-undrained-state08-composition-provider-proposal-v1.py').read_bytes();compile(raw,path,'exec');target=D/path;target.write_bytes(raw);files[path]=dict(added=True,proposed_sha256=SHA(raw))
q=dict(status='SOURCE_PROPOSAL_SYNTAX_AND_LITERAL_OLD_SOURCE_INVERSES_ONLY_NOT_INSTALLED_OR_QUALIFIED',actual_base=C,change_class='B_EXISTING_PROCESS_COMPOSITION',files=files,
       existing_engine_or_Fortran_criterion_source_changed=False,compiler_executions=0,model_executions=0,public_admission=False,
       next_action='Install only after actual07 canonical observation and receipt; use real source commit for public builds and targeted original-budget/native/cold qualification. Preserve all old648 source dependencies explicitly, never project source identities.')
with (E/'FROST_UNDRAINED_STATE08_SOURCE_PROPOSAL_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],len(files),flush=True)
