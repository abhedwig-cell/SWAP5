"""One coherent prospective drainage-off Frost batch; no admission/count inflation."""
from pathlib import Path
import json
E=Path(__file__).resolve().parent
cases=[]
for kind in ('water','cde'):
    for bottom in (5,8):
        for implicit in (0,1):
            case=dict(kind=kind,bottom=bottom,implicit=implicit,hysteresis=2,initial=2,
                      calendar='dense',reset=1,start=None,days=35,drainage=0)
            case['name']=f'{kind}-d0-b{bottom}-i{implicit}-h2-p2-dense'
            cases.append(case)
for kind in ('water','cde'):
    for bottom in (5,8):
        for implicit in (0,1):
            hys=0 if bottom==5 else 1;initial=1 if implicit==0 else 2
            calendar='monthly' if implicit==0 else 'dates';reset=0 if implicit else 1
            start=None;days=35
            if (kind,bottom,implicit)==('water',8,1):hys=2;initial=1;calendar='dates';start='2002-12-26';days=12
            elif (kind,bottom,implicit)==('cde',5,0):hys=2;initial=1;calendar='dates';start='2002-12-26';days=12
            elif (kind,bottom,implicit) in [('water',5,1),('cde',8,1)]:calendar='regular';start='2002-12-26';days=12
            case=dict(kind=kind,bottom=bottom,implicit=implicit,hysteresis=hys,initial=initial,
                      calendar=calendar,reset=reset,start=start,days=days,drainage=0)
            case['name']=f'{kind}-d0-b{bottom}-i{implicit}-h{hys}-p{initial}-{calendar}-r{reset}'+('-year-seam' if start else '')
            cases.append(case)
assert len(cases)==len({x['name'] for x in cases})==16
q=dict(status='PROSPECTIVE_COHERENT16_CONTEXT_INPUT_CONTRACT_NOT_IMPLEMENTED_OR_QUALIFIED',
       scientific_change_class='B_NEW_UNDRAINED_COMPOSITION_EXISTING_UNCHANGED_PROCESS_IMPLEMENTATIONS',
       source_proposal='FROST_UNDRAINED_STATE08_SOURCE_PROPOSAL_V1.json',
       original_diagnostics='FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1.json',
       representative_cases=cases,required_platforms=['Windows','Ubuntu'],required_optimizations=['O0','O2'],
       original_budget_limits=dict(water_cm=1e-10,CDE_mg_cm2=1e-10),
       required_checks=['Actual public build source identity and complete generated-source inverses',
                        'Original actual day and prefix water/CDE budgets without corrections',
                        'Exact native cold seams including real year/date/month output carry',
                        'Malformed, foreign drainage/root/codec/checkpoint compiled refusals',
                        'Actual rejected-trial transaction and rollback preservation',
                        'Unchanged old648 scientific dependency source and targeted whole-object build postimages without old model replay'],
       rejected_trial_and_convergence_criteria_changed=False,model_runs_executed_by_this_contract=0,
       new_scientifically_qualified_contexts=0,canonical_admission=False,
       whole_historical_functional_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_counts='UNKNOWN')
with (E/'FROST_UNDRAINED_STATE08_INPUT_CONTRACT_V1.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],len(cases),sum(c['days']==35 for c in cases),sum(c['days']==12 for c in cases))
