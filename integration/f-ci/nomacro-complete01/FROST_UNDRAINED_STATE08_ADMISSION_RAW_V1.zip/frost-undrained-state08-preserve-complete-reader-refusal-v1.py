"""Preserve strict complete-reader refusal before any model process was started."""
from pathlib import Path
import difflib,hashlib,json,subprocess
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
SHA=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
A='76b0c773e172979cd183f836e83017ab8f6fd14f';BASE='082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66';assert git('rev-parse','HEAD')==A
D=W/'frost-undrained-state08-local-smoke-v2/O0-cde-d0-b5-i1-h2-p2-dense';r=json.loads((D/'RESULT.json').read_text());err=D/'science.stderr.txt'
assert r['actual_source']==A and r['build']['returncode']==0 and b'Foreign actual terminal water receipt source' in err.read_bytes() and not (D/'science/trajectory').exists()
q=dict(status='ACTUAL_COMPLETE_BUNDLE_READER_REFUSED_NEW_TYPED_RECEIPT_BEFORE_MODEL_LAUNCH_ORIGINAL_RETAINED',actual_source=A,actual_build=r['build'],actual_BUILD_sha256=SHA((Path(r['build_root'])/'BUILD.json').read_bytes()),original_reader_stderr_sha256=SHA(err.read_bytes()),original_reader_stderr_path=str(err),accepted_model_days=0,model_day_requests=0,correction='Select exact same new SWDRA0 receipt renderer in the complete public bundle reader as already selected in public generation and private source closure',all_source_comparisons_and_1e_10_bounds_retained=True,original_B2_source_bytes='FROST_UNDRAINED_STATE08_SOURCE_BYTES_V2/RESULT.json',original_B2_controller_bytes='FROST_UNDRAINED_STATE08_CONTROLLER_SOURCE_V2.json')
name='FROST_UNDRAINED_STATE08_PUBLIC_SMOKE_REFUSAL_V2.json';text=json.dumps(q,indent=2)+'\n'
with (E/name).open('x',encoding='utf8') as f:f.write(text)
(P/name).write_text(text)
files={};paths=set(git('diff','--name-only',BASE,'--','app').splitlines())|set(git('ls-files','--others','--exclude-standard','--','app').splitlines())
for path in sorted(paths):
    actual=(R/path).read_bytes().replace(b'\r\n',b'\n');compile(actual,path,'exec');old=subprocess.run(['git','show',BASE+':'+path],cwd=R,capture_output=True)
    if old.returncode:files[path]=dict(added=True,proposed_lf_sha256=SHA(actual));continue
    a=old.stdout.decode();b=actual.decode();edits=[]
    for tag,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
        if tag!='equal':edits.append(dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]))
    files[path]=dict(before_lf_sha256=SHA(old.stdout),proposed_lf_sha256=SHA(actual),ordered_literal_edits=edits)
source_name='FROST_UNDRAINED_STATE08_SOURCE_PROPOSAL_V3.json';source=dict(status='COMPLETE_UNDRAINED_FROST_RENDERER_AND_STRICT_PUBLIC_BUNDLE_READER_SOURCE',actual_parent_candidate=BASE,files=files,all28_terminal_terms_unchanged=True,source_comparisons_or_scientific_criteria_relaxed=False,scientific_qualification=False);text=json.dumps(source,indent=2)+'\n'
with (E/source_name).open('x',encoding='utf8') as f:f.write(text)
(P/source_name).write_text(text)
status=json.loads((P/'STATUS.json').read_text());status['frost_undrained_state08'].update(status='REAL_TYPED_RECEIPT_BUILD_PASS_COMPLETE_BUNDLE_READER_BOUND_FRESH_SCIENCE_PENDING',source_contract=source_name,latest_original_refusal=name,original_failure_sources=['1239cce09a233e43b334a6873a1c5d89f1ed3aef',A]);(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
changed=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines();assert set(changed)=={'app/hybrid_water/daily_coupling.py','integration/f-ci/nomacro-complete01/'+name,'integration/f-ci/nomacro-complete01/'+source_name,'integration/f-ci/nomacro-complete01/STATUS.json'}
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*changed],cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Bind complete public bundle reader to exact undrained Frost receipt'],cwd=R,check=True)
q=dict(actual_source=git('rev-parse','HEAD'),actual_tree=git('rev-parse','HEAD^{tree}'),source_contract=source_name,previous_original_source=A,parent_candidate=BASE,parent_canonical_admission_pending=True,new_qualified_contexts=0,canonical_admission=False)
with (E/'FROST_UNDRAINED_STATE08_IMPLEMENTED_CANDIDATE_V3.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps(q),flush=True)
