"""Preserve first genuine public refusal; bind a distinct same-terms receipt."""
from pathlib import Path
import difflib,hashlib,json,subprocess,sys
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip();SHA=lambda b:hashlib.sha256(b).hexdigest()
A='1239cce09a233e43b334a6873a1c5d89f1ed3aef';BASE='082f3d4b8e027d7aa8fcfbb9e3dde603aea85a66';assert git('rev-parse','HEAD')==A
D=W/'frost-undrained-state08-local-smoke-v1/O0-cde-d0-b5-i1-h2-p2-dense';failed=json.loads((D/'RESULT.json').read_text());assert failed['status']=='FAILED_REAL_UNDRAINED_FROST_PUBLIC_SMOKE_NOT_QUALIFIED' and failed['actual_source']==A and failed['build']['returncode']==0
stderr=D/'science/trajectory/original/donor.stderr';stdout=D/'science/trajectory/original/donor.stdout';daily=D/'science/trajectory/daily.jsonl'
assert b'ERROR STOP Unsupported terminal water receipt domain' in stderr.read_bytes() and b'HYBRID_READY' in stdout.read_bytes() and b'HYBRID_DAY_RETURN' not in stdout.read_bytes();assert not daily.read_bytes()
q=dict(status='ORIGINAL_ACTUAL_PUBLIC_UNDRAINED_BUILD_PASS_FIRST_DAY_TYPED_RECEIPT_REFUSAL_RETAINED',actual_source=A,actual_build_result=failed['build'],kind='cde',bottom=5,implicit=1,drainage=0,accepted_primary_days=0,accepted_kernel_days=0,original_stdout_sha256=SHA(stdout.read_bytes()),original_stderr_sha256=SHA(stderr.read_bytes()),raw_build_root=failed['build_root'],raw_input_root=failed['input_root'],actual_BUILD_sha256=SHA((Path(failed['build_root'])/'BUILD.json').read_bytes()),correction='Distinct SWDRA0/SWFROST1 terminal day receipt; unchanged28 ledger terms, actual drainage rate, absolute1e-10 criterion and numerical process',physical_or_mass_terms_changed=False)
name='FROST_UNDRAINED_STATE08_PUBLIC_SMOKE_REFUSAL_V1.json'
with (E/name).open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
(P/name).write_text(json.dumps(q,indent=2)+'\n')
sys.path.insert(0,str(R/'app/hybrid_water'))
from frost_calendar_terminal_water import source as parent_source
from frost_undrained_terminal_water import source as new_source
before=parent_source();after=new_source();restored=after.replace('    use MOD_swap_base, only: swmacro, swsnow, swdra, swfrost','    use MOD_swap_base, only: swmacro, swsnow, swdra',1).replace("    if(swmacro/=0.or.swsnow/=1.or.swfrost/=1.or.swdra/=0)error stop 'Unsupported undrained Frost terminal water receipt domain'","    if(swmacro/=0.or.swsnow/=1.or.swdra/=1)error stop 'Unsupported terminal water receipt domain'",1)
assert restored==before and 'qdrtot*dt' in after and 'real(sum(real(terms,real128)),8)' in after
paths=set(git('diff','--name-only',BASE,'--','app').splitlines())|set(git('ls-files','--others','--exclude-standard','--','app').splitlines());files={}
for path in sorted(paths):
    actual=(R/path).read_bytes().replace(b'\r\n',b'\n');compile(actual,path,'exec')
    original=subprocess.run(['git','show',BASE+':'+path],cwd=R,capture_output=True)
    if original.returncode:files[path]=dict(added=True,proposed_lf_sha256=SHA(actual));continue
    a=original.stdout.decode();b=actual.decode();edits=[]
    for tag,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
        if tag!='equal':edits.append(dict(base_start=i,base_end=j,before=a[i:j],after=b[k:l]))
    reconstructed=[];cursor=0
    for edit in edits:assert a[edit['base_start']:edit['base_end']]==edit['before'];reconstructed.extend((a[cursor:edit['base_start']],edit['after']));cursor=edit['base_end']
    reconstructed.append(a[cursor:]);assert ''.join(reconstructed)==b
    files[path]=dict(before_lf_sha256=SHA(original.stdout),proposed_lf_sha256=SHA(actual),ordered_literal_edits=edits)
record=dict(status='BOUNDED_UNDRAINED_COMPOSITION_AND_DISTINCT_TERMINAL_DOMAIN_SOURCE_PROPOSAL',actual_parent_candidate=BASE,files=files,terminal_parent_complete_source_sha256=SHA(before.encode()),undrained_terminal_complete_source_sha256=SHA(after.encode()),terminal28_terms_complete_inverse_pass=True,absolute_receipt_criterion_changed=False,new_scientific_qualification=False)
source_name='FROST_UNDRAINED_STATE08_SOURCE_PROPOSAL_V2.json'
with (E/source_name).open('x',encoding='utf8') as f:json.dump(record,f,indent=2);f.write('\n')
(P/source_name).write_text(json.dumps(record,indent=2)+'\n')
status=json.loads((P/'STATUS.json').read_text());status['frost_undrained_state08'].update(status='FIRST_REAL_PUBLIC_BUILD_AND_INITIALIZATION_PASS_DISTINCT_DRAINAGE0_TERMINAL_DOMAIN_IMPLEMENTED_FRESH_SMOKE_PENDING',original_smoke_refusal=name,source_contract=source_name,new_qualified_contexts=0);(P/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
changed=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
assert set(changed)<=set(files)|{'integration/f-ci/nomacro-complete01/'+name,'integration/f-ci/nomacro-complete01/'+source_name,'integration/f-ci/nomacro-complete01/STATUS.json'}
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','add','--',*changed],cwd=R,check=True);subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Bind distinct undrained Frost terminal receipt domain with unchanged28 terms'],cwd=R,check=True)
q=dict(status='DISTINCT_UNDRAINED_TERMINAL_DOMAIN_COMMITTED_FRESH_SCIENCE_PENDING',actual_source=git('rev-parse','HEAD'),actual_tree=git('rev-parse','HEAD^{tree}'),original_failed_source=A,parent_candidate=BASE,source_contract=source_name,new_qualified_contexts=0,canonical_admission=False)
with (E/'FROST_UNDRAINED_STATE08_IMPLEMENTED_CANDIDATE_V2.json').open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps(q),flush=True)
