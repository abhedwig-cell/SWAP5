"""Preserve four true pre-parent-admission local trajectories, without replay."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from frost_boundary_git_archive import GitArchiveSource
from analytical_hydraulic_archives import Archive,SHA
source='656cd3ed25c91dc6ab8de12f2525fd30be8e358f';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==source
name='FROST_UNDRAINED_STATE08_LOCAL_WINDOWS_O0_O2_RAW_V1';files={};projection={};contexts=[];provider={}
def add(root,prefix):
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path
D=W/'frost-undrained-state08-local-smoke-v3';add(D,'current')
with ExitStack() as stack:
    original=Archive(GitArchiveSource(R,'087fc67db3e1e58d45215522eb284e89cb6c12f1'),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
    for opt in ('O0','O2'):
        root=W/('frost-undrained-state08-local-'+opt+'-v3');add(root,'compiled/'+opt)
        for case in ('cde-d0-b5-i1-h2-p2-dense','water-d0-b8-i1-h2-p1-dates-r0-year-seam'):
            folder=D/(opt+'-'+case);q=json.loads((folder/'RESULT.json').read_text());assert q['actual_source']==source and q['status']=='REAL_UNDRAINED_FROST_PUBLIC_SMOKE_ORIGINAL_BUDGETS_EXACT_NATIVE_COLD_AND_CONTROLS_PASS_NOT_ADMITTED'
            science=json.loads((folder/'science/RESULT.json').read_text());assert science['source']==science['actual_controller_source']==source and science['selection']['drainage']==0
            assert q['original_convergence']['unconverged_continuations']==0
            build=Path(q['build_root']);meta=json.loads((build/'BUILD.json').read_text());identity=meta['identity'];assert identity['compiler_sha256']=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
            projection[str(build)]=dict(archive_prefix='compiled/'+opt+'/'+case+'/bundle',actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()))
            for key,subdir in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
                for file,digest in identity[key].items():
                    member='original-provider-build/'+subdir+'/'+file;raw=original.get(member);assert SHA(raw)==digest and raw==(J/'build'/subdir/file).read_bytes();provider[member]=dict(bytes=len(raw),sha256=digest)
            member='original-provider-build/ttutil-obj/libttutil.a';raw=original.get(member);assert SHA(raw)==identity['ttutil_library'] and raw==(J/'build/ttutil-obj/libttutil.a').read_bytes();provider[member]=dict(bytes=len(raw),sha256=SHA(raw))
            controls=q.get('controls_result');refusals=0;transactions=0
            if q['case']['days']==35:
                assert controls['status']=='ACTUAL_UNDRAINED_FROST_COMPILED_NATIVE_SNOW_CDE_ROOT_AND_TRANSACTIONS_PASS_NOT_ADMITTED'
                refusals=len(controls['existing_calendar_thermal_refusals'])+len(controls['new_snow_private_and_codec_refusals'])+len(controls.get('root',{}).get('refusals',[]));assert refusals==112;transactions=2
            contexts.append(dict(case=q['case'],optimization=opt,actual_source=source,actual_build_root=str(build),actual_BUILD_sha256=SHA((build/'BUILD.json').read_bytes()),compiler=identity['compiler'],compiler_sha256=identity['compiler_sha256'],original_budgets=science['independent_original_budgets'],native_samples=len(science['native_samples']),exact_cold_windows=len(science['own']),actual_compiled_refusals=refusals,transactions=transactions))
    dependency=dict(archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',actual_data_revision='087fc67db3e1e58d45215522eb284e89cb6c12f1',sha256=original.record['sha256'],actual_required_files=provider)
add(E/'FROST_UNDRAINED_STATE08_SOURCE_BYTES_V3','source')
assert json.loads((E/'FROST_UNDRAINED_STATE08_SOURCE_BYTES_V3/RESULT.json').read_text())['producer_head']==source
for file in ['FROST_UNDRAINED_STATE08_CONTROLLER_SOURCE_V3.tar','FROST_UNDRAINED_STATE08_CONTROLLER_SOURCE_V3.json','frost-undrained-state08-actual-local-smoke-v3.py',Path(__file__).name]:files['controllers/'+file]=E/file
for key,value in [('COMPILED_PROJECTION_V1.json',projection),('LOCAL_PROVIDER_DEPENDENCY_V1.json',dependency)]:
    path=E/('FROST_UNDRAINED_STATE08_'+key)
    with path.open('x',encoding='utf8') as f:json.dump(value,f,indent=2);f.write('\n')
    files[key]=path
archive=E/(name+'.zip');members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for key,path in sorted(files.items()):
        raw=path.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    raw=subprocess.check_output(['git','cat-file','commit',source],cwd=R);z.writestr('genuine-producer-commit.bin',raw);members['genuine-producer-commit.bin']=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for key,item in members.items():
        raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=archive.read_bytes();q=dict(status='FOUR_REAL_UNDRAINED_PUBLIC_LOCAL_TRAJECTORIES_RAW_PRESERVED_PENDING_INDEPENDENT_AND_PORTABLE_ADMISSION',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),members=members,contexts=contexts,actual_scientific_source=source,original_provider_dependency=dependency,primary_days=sum(c['case']['days'] for c in contexts),native_samples=sum(c['native_samples'] for c in contexts),exact_cold_windows=sum(c['exact_cold_windows'] for c in contexts),actual_compiled_refusals=sum(c['actual_compiled_refusals'] for c in contexts),transactions=sum(c['transactions'] for c in contexts),source_identity_rebound=False,parent_canonical_admission_pending=True,canonical_admission=False,new_admitted_contexts=0)
assert (q['primary_days'],q['native_samples'],q['exact_cold_windows'],q['actual_compiled_refusals'],q['transactions'])==(94,22,10,224,4)
with (E/(name+'.json')).open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],len(raw),q['sha256'],len(members),flush=True)
