"""Preserve each initial failure, original probe and output-only counterfactual."""
from pathlib import Path
import hashlib,json,zipfile
E=Path(__file__).resolve().parent;W=E.parent
J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
SHA=lambda b:hashlib.sha256(b).hexdigest()
name='FROST_UNDRAINED_STATE08_ORIGINAL_DIAGNOSTIC_RAW_V1'
files={}
for label,root in [('original-runs',W/'frost-undrained-state08-original35-v1'),('phase-driver',W/'frost-undrained-state08-initialization-probe-O0-v1'),('initial-inputs',E/'frost-undrained-state08-current-reader-inputs-v1')]:
    for path in sorted(root.rglob('*')):
        if path.is_file():files[label+'/'+path.relative_to(root).as_posix()]=path
for path in E.iterdir():
    if path.is_file() and (path.name.startswith('frost-undrained-state08-') and path.suffix=='.py' or path.name.startswith('FROST_UNDRAINED_STATE08_') and path.suffix=='.json'):
        files['observations/'+path.name]=path
for relative in ['PREPARED.json','build/swap_b0_gfortran.exe','build/swap-selected/swap.f90','build/swap-selected/readswap.f90','build/swap-selected/swapoutput.f90','build/swap-selected/swap_csv_output.f90']:
    files['original-provider/'+relative]=J/relative
runtime={p.name:dict(bytes=p.stat().st_size,sha256=SHA(p.read_bytes())) for p in Path('C:/msys64/ucrt64/bin').glob('*.dll') if p.name in ['libgfortran-5.dll','libquadmath-0.dll','libgcc_s_seh-1.dll','libwinpthread-1.dll']}
members={}
with zipfile.ZipFile(E/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for key,path in sorted(files.items()):
        assert not path.is_symlink();raw=path.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(E/(name+'.zip')) as z:
    assert set(z.namelist())==set(members)
    for key,meta in members.items():
        raw=z.read(key);assert len(raw)==meta['bytes'] and SHA(raw)==meta['sha256']
raw=(E/(name+'.zip')).read_bytes()
q=dict(status='ORIGINAL_FAILURES_ZERO_DAY_PHASE_PROBES_AND_OUTPUT_ONLY_COUNTERFACTUALS_PRESERVED_NOT_ADMITTED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),members=members,
       genuine_original_csv3_crashes=4,genuine_original_csv0_normal_completion_cases=4,
       independent_scientific_qualification=False,new_public_admission=False,
       original_inputs_and_failures_unchanged=True,mixed_compiler_phase_drivers_are_diagnostic_only=True,
       current_runtime_DLL_hashes=runtime,original_provider_compilation_runtime_DLL_equality='UNKNOWN_NOT_CAPTURED_AT_ORIGINAL_COMPILATION')
with (E/(name+'.json')).open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],len(raw),q['sha256'],len(members),flush=True)
