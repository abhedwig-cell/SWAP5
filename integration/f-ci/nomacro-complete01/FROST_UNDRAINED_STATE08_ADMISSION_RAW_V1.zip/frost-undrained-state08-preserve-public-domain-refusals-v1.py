"""Preserve every actual raw byte of the two early typed-domain refusals."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
SHA=lambda b:hashlib.sha256(b).hexdigest();files={}
for version in (1,2):
    for kind,root in [('raw-probe',W/f'frost-undrained-state08-local-smoke-v{version}'),('actual-public-build',W/f'frost-undrained-state08-local-O0-v{version}')]:
        for path in sorted(root.rglob('*')):
            if path.is_file():files[f'attempt{version}/{kind}/'+path.relative_to(root).as_posix()]=path
for path in (E/'FROST_UNDRAINED_STATE08_SOURCE_BYTES_V2').rglob('*'):
    if path.is_file():files['attempt2/actual-source-bytes/'+path.relative_to(E/'FROST_UNDRAINED_STATE08_SOURCE_BYTES_V2').as_posix()]=path
for name in ['FROST_UNDRAINED_STATE08_CONTROLLER_SOURCE_V2.tar','FROST_UNDRAINED_STATE08_CONTROLLER_SOURCE_V2.json','frost-undrained-state08-actual-local-smoke-v1.py','frost-undrained-state08-actual-local-smoke-v2.py','frost-undrained-state08-preserve-domain-refusal-and-commit-v1.py','frost-undrained-state08-preserve-complete-reader-refusal-v1.py','FROST_UNDRAINED_STATE08_IMPLEMENTED_CANDIDATE_V1.json','FROST_UNDRAINED_STATE08_IMPLEMENTED_CANDIDATE_V2.json']:
    files['observations/'+name]=E/name
name='FROST_UNDRAINED_STATE08_PUBLIC_DOMAIN_REFUSALS_RAW_V1';members={}
with zipfile.ZipFile(E/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for key,path in sorted(files.items()):
        assert not path.is_symlink();raw=path.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
    for role,head in [('attempt1','1239cce09a233e43b334a6873a1c5d89f1ed3aef'),('attempt2','76b0c773e172979cd183f836e83017ab8f6fd14f')]:
        for suffix,args in [('commit.bin',['cat-file','commit',head]),('source-git-objects.tar',['archive','--format=tar',head,'app','src','tools/solute','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface'])]:
            raw=subprocess.check_output(['git',*args],cwd=R);key=role+'/'+suffix;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(E/(name+'.zip')) as z:
    assert set(z.namelist())==set(members)
    for key,item in members.items():
        raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=(E/(name+'.zip')).read_bytes()
q=dict(status='ORIGINAL_TWO_PUBLIC_TYPED_DOMAIN_REFUSALS_COMPLETE_RAW_COMPILED_INPUT_SOURCE_AND_FAILURE_BYTES_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),members=members,
       attempt1_actual_source='1239cce09a233e43b334a6873a1c5d89f1ed3aef',attempt2_actual_source='76b0c773e172979cd183f836e83017ab8f6fd14f',accepted_primary_model_days=0,
       attempt1_source_authority='GENUINE_GIT_OBJECT_ARCHIVE_NOT_CLAIMED_RETROACTIVE_RAW_WORKING_SNAPSHOT; ACTUAL_GENERATED_AND_COMPILED_BYTES_RETAINED',
       attempt2_raw_working_source_bytes_captured_at_actual_producer=True,original_refusals_not_reclassified_as_science_PASS=True,scientific_qualification=False)
with (E/(name+'.json')).open('x',encoding='utf8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],len(raw),q['sha256'],len(members),flush=True)
