"""Release only own copies whose every actual file has accepted archived bytes."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys
E=Path(__file__).resolve().parent;W=E.parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
C='cc0f81f6f54d5b64e186da5582712ee15a77bc20'
cleanup=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py')
task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713'
positive=json.loads((E/'FROST_UNDRAINED_STATE08_CANDIDATE_PUBLIC_V2.json').read_text());assert positive['returncode']==0 and positive['before']==positive['after'] and positive['before']['head']==C
accepted={x['archive']:x for x in json.loads((E/'FROST_UNDRAINED_STATE08_CANDIDATE_PUBLIC_V2.stdout.txt').read_text())['actual_raw_custody']}
labels=['FROST_UNDRAINED_STATE08_PUBLIC_DOMAIN_REFUSALS_RAW_V1','FROST_UNDRAINED_STATE08_LOCAL_WINDOWS_O0_O2_RAW_V1','FROST_UNDRAINED_STATE08_ACTIVE_FROST_TRANSACTIONS_RAW_V1']
resources=['frost-undrained-state08-local-smoke-v1','frost-undrained-state08-local-O0-v1','frost-undrained-state08-local-smoke-v2','frost-undrained-state08-local-O0-v2','frost-undrained-state08-local-smoke-v3','frost-undrained-state08-local-O0-v3','frost-undrained-state08-local-O2-v3','frost-undrained-state08-active-frost-transaction-v1']
hashes={};report=dict(status='VERIFYING_EXACT_ACCEPTED_CUSTODY_BEFORE_OWN_RELEASE',actual_qualified_candidate=C,task=task,archives=[],resources=[])
with ExitStack() as stack:
    data=GitArchiveSource(R,C)
    for label in labels:
        q=json.loads((data/(label+'.json')).read_text());assert q['sha256']==accepted[q['archive']]['sha256'] and q['bytes']==accepted[q['archive']]['bytes']
        if 'parts' not in q:
            import io,zipfile
            raw=(data/q['archive']).read_bytes();assert SHA(raw)==q['sha256'];z=stack.enter_context(zipfile.ZipFile(io.BytesIO(raw)))
            for n,item in q['members'].items():
                raw=z.read(n);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'];hashes.setdefault((len(raw),SHA(raw)),[]).append(label+':'+n)
        else:
            archive=Archive(data,label,stack)
            for n in archive.names:
                raw=archive.get(n);hashes.setdefault((len(raw),SHA(raw)),[]).append(label+':'+n)
        report['archives'].append(dict(archive=label,bytes=q['bytes'],sha256=q['sha256']))
    for label in resources:
        root=W/label;assert root.resolve().parent==W.resolve() and root.is_dir() and not root.is_symlink()
        rows=[];unmatched=[]
        for path in root.rglob('*'):
            assert not path.is_symlink()
            if path.is_file():
                raw=path.read_bytes();digest=SHA(raw);origins=hashes.get((len(raw),digest))
                item=dict(path=path.relative_to(root).as_posix(),bytes=len(raw),sha256=digest)
                if origins:item['accepted_archive_member']=origins[0];rows.append(item)
                else:unmatched.append(item)
        report['resources'].append(dict(path=str(root),files=rows,unmatched=unmatched,eligible_for_explicit_release=not unmatched))
report['status']='FRESH_COMPLETE_ACTUAL_FILE_CUSTODY_MAPPED_RELEASE_ELIGIBLE_ONLY'
with (E/'FROST_UNDRAINED_STATE08_RESOURCE_CENTRAL_CUSTODY_BEFORE_RELEASE_V1.json').open('x',encoding='utf8') as f:json.dump(report,f,indent=2);f.write('\n')
for item in report['resources']:
    if not item['eligible_for_explicit_release']:
        print('RETAIN_UNMATCHED_ACTUAL_BYTES',item['path'],len(item['unmatched']),flush=True);continue
    result=subprocess.run([sys.executable,'-B',str(cleanup),'release','--task',task,'--path',item['path']],capture_output=True)
    with (E/('FROST_UNDRAINED_STATE08_RELEASE_'+Path(item['path']).name+'_V1.json')).open('xb') as f:f.write(result.stdout)
    assert not result.stderr;result.check_returncode()
    print('RELEASED_EXACT_CENTRAL_COPIES',item['path'],len(item['files']),sum(x['bytes'] for x in item['files']),flush=True)
