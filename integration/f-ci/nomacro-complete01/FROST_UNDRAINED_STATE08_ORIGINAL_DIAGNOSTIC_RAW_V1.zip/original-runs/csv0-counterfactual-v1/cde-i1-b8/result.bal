* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-26 02:12:24

Period             :  1900-01-01  until  2002-02-04 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        60.28 cm       0.4782E+02 mg/cm2
Initial :        97.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -36.91 cm       0.4782E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :     4.59    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :   -43.45    Soil evaporation  :     0.45
                             Crack flux        :     0.00
=========================    ============================
Sum            :   -36.46    Sum               :     0.45


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.1280E-01    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.1969E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.4782E+02    Sum            :  0.0000E+00

