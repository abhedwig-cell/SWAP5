program original_initialization_probe
use iso_fortran_env, only: output_unit
use MOD_swap_base, only: swap_configuration, sw_animo, sw_multi_swap, swhea, swdra, swsnow, swsolu
use MOD_meteo, only: meteo, tav, peva, empreva, epond
use MOD_MvG, only: fill_cofgen
use MOD_SoilWater, only: soilwater
use MOD_gwl, only: calcgwl
use MOD_SoilTemperature, only: SoilTemperature, tsoil
use MOD_snow, only: snow
use MOD_solute, only: solute
implicit none
sw_animo=1
call mark('BEFORE_INITIALIZE')
call Initialize
call IterTime(1)
call mark('BEFORE_CONFIGURATION')
call swap_configuration()
call mark('BEFORE_READSWAP')
call ReadSwap
call mark('AFTER_READSWAP')
call Meteo(1)
call mark('AFTER_METEO')
call TimeControl(1)
call mark('AFTER_TIMECONTROL')
if(sw_multi_swap/=0)error stop 'Unexpected multi SWAP'
call fill_cofgen
call mark('AFTER_FILL_COFGEN')
call SoilWater(1)
call mark('AFTER_SOILWATER')
call calcgwl()
call mark('AFTER_CALCGWL')
if(swhea>0)call SoilTemperature(1)
call mark('AFTER_SOILTEMPERATURE')
if(swdra/=0)error stop 'Unexpected drainage'
if(swsnow==1)call Snow(1,tsoil(1),tav,epond,peva,empreva)
call mark('AFTER_SNOW')
if(swsolu>0)call Solute(1)
call mark('AFTER_SOLUTE_INITIALIZATION_ZERO_MODEL_DAYS')
contains
subroutine mark(text)
character(len=*),intent(in)::text
write(output_unit,'(a)')'ORIGINAL_INIT_PHASE '//text
flush(output_unit)
end subroutine
end program
