"""Genuine current HEAD/index/working custody and exact undrained source inverses."""
import hashlib,json,re,subprocess
from pathlib import Path
from explicit_bottom9_analytical_inherited_custody import tracked_working_files,materialized
from ci_checkout_scope07_inherited_custody import original_git_payload
from frost_undrained_input_contract import source as complete_inverse
ROOT=Path(__file__).resolve().parents[2]
BASE='0b482de01847dd8ba5f93c63881b9aeff468d3e3'
COMPILER='127af752c5519e7f9d9a6894c61137f0ee7f3920'
SELF='tests/nomacro_drainage/frost_undrained_verify.py'
JOINT='tests/nomacro_drainage/initial_profile_age_groundwater_verify.py'
PREFIX='integration/f-ci/nomacro-complete01/'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
SHA=lambda b:hashlib.sha256(b).hexdigest()

def tree(ref):
    result={}
    for row in git('ls-tree','-r','-z',ref).split(b'\0'):
        if row:
            meta,path=row.split(b'\t',1);result[path.decode()]=tuple(meta.decode().split())
    return result

def source(anchor):
    head=git('rev-parse','HEAD');complete_inverse()
    assert re.fullmatch('[0-9a-f]{40}',anchor) and not git('for-each-ref','--format=%(refname)','refs/replace')
    assert not git('status','--porcelain=v1','--untracked-files=all')
    assert not git('diff',COMPILER,'HEAD','--','app','src','tools','reference')
    old,current,frozen=tree(BASE),tree('HEAD'),tree(anchor)
    assert old.keys()<=current.keys() and current.keys()==frozen.keys()
    contract=json.loads(git('show','HEAD:'+PREFIX+'FROST_UNDRAINED_STATE08_SOURCE_PROPOSAL_V3.json'))
    adapters=json.loads(git('show','HEAD:'+PREFIX+'FROST_UNDRAINED_STATE08_PARENT_METADATA_WITNESSES_V1.json'))
    assert adapters['actual_parent']==BASE
    metadata={PREFIX+'STATUS.json',PREFIX+'GAP_MATRIX.json'}
    expected={p for p,item in contract['files'].items() if not item.get('added')}|{JOINT}|set(adapters['files'])|metadata
    assert {p for p in old if old[p]!=current[p]}==expected
    for p,item in adapters['files'].items():
        before=git('show',BASE+':'+p);actual=(ROOT/p).read_bytes().replace(b'\r\n',b'\n')
        assert SHA(before)==item['before_lf_sha256'] and SHA(actual)==item['proposed_lf_sha256']
        text=before.decode();parts=[];cursor=0
        for edit in item['ordered_literal_edits']:
            assert cursor<=edit['base_start']<=edit['base_end'] and text[edit['base_start']:edit['base_end']]==edit['before']
            parts.extend((text[cursor:edit['base_start']],edit['after']));cursor=edit['base_end']
        parts.append(text[cursor:]);assert ''.join(parts).encode()==actual==git('show','HEAD:'+p)
    actual=(ROOT/JOINT).read_bytes().replace(b'\r\n',b'\n')
    for name in ['guard_previous_source','verify','strip_current_evidence','publication_dependencies_unchanged']:
        args='text' if name=='strip_current_evidence' else ''
        before=' import ci_checkout_scope07_verify as checkout_owner\n return checkout_owner.'+name+'('+args+')\n'
        after=' import frost_undrained_verify as undrained_owner\n return undrained_owner.'+name+'('+args+')\n'
        assert actual.count(after.encode())==1;actual=actual.replace(after.encode(),before.encode(),1)
    assert actual==git('show',BASE+':'+JOINT)
    tracked=tracked_working_files();eols={}
    for row in git('ls-files','--eol','-z').split(b'\0'):
        if row:
            meta,path=row.split(b'\t',1);eols[path.decode()]=meta.decode().split()
    observed=[]
    for p,(mode,kind,digest) in current.items():
        assert mode!='120000' and kind=='blob' and tracked[p][1:]==(mode,digest),'Changed actual source index: '+p
        if p not in metadata|{SELF}:assert current[p]==frozen[p],'Changed frozen actual repository source: '+p
        if not materialized(p,tracked):continue
        raw=(ROOT/p).read_bytes()
        if p==SELF:
            normal=raw.replace(b'\r\n',b'\n');pattern=br"(?m)^SEALED='[0-9a-f]{40}'$"
            left,a=re.subn(pattern,b"SEALED='SOURCE_ANCHOR'",normal);right,b=re.subn(pattern,b"SEALED='SOURCE_ANCHOR'",git('show',anchor+':'+p));assert a==b==1 and left==right
        else:original_git_payload(raw,p,digest,eols)
        if p.startswith(('app/','src/','tools/','tests/','.github/')):observed.append(dict(path=p,actual_raw_sha256=SHA(raw)))
    assert git('rev-parse','HEAD')==head and tracked_working_files()==tracked
    return dict(status='REAL_UNDRAINED_FROST_HEAD_INDEX_WORKING_COMPLETE_SOURCE_AND_LITERAL_INVERSES_PASS',actual_head=head.decode().strip(),source_anchor=anchor,original_compiled_source=COMPILER,parent=BASE,files=observed,modified_inherited_files=sorted(expected),source_or_filesystem_identity_projected=False,compiler_executions=0,model_executions=0)
