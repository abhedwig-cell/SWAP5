* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 07:55:44

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.14 cm       0.1047E+00 mg/cm2
Initial :        73.20 cm       0.0000E+00 mg/cm2
            =============       =================
Change            1.94 cm       0.1047E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.28
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    35.01
Bottom flux    :   -45.32    Soil evaporation  :     0.03
                             Crack flux        :     0.00
=========================    ============================
Sum            :    41.26    Sum               :    39.33


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.1047E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.1047E+00    Sum            :  0.0000E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.48 cm       0.2470E+00 mg/cm2
Initial :        75.14 cm       0.1047E+00 mg/cm2
            =============       =================
Change           -0.66 cm       0.1423E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.61
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    25.28
Bottom flux    :   -40.71    Soil evaporation  :     0.03
                             Crack flux        :     0.00
=========================    ============================
Sum            :    31.27    Sum               :    31.92


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.1423E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.1423E+00    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.56 cm       0.9858E-01 mg/cm2
Initial :        74.48 cm       0.2470E+00 mg/cm2
            =============       =================
Change            0.08 cm      -0.1484E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -36.77    Soil evaporation  :     0.03
                             Crack flux        :     0.00
=========================    ============================
Sum            :    43.78    Sum               :    43.70


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.1484E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.1484E+00    Sum            :  0.0000E+00

