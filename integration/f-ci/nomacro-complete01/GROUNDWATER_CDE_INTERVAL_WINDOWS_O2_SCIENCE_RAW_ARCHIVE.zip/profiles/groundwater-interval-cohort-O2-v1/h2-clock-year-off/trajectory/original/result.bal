* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 07:58:00

Period             :  2002-12-15  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.89 cm       0.0000E+00 mg/cm2
Initial :        74.24 cm       0.0000E+00 mg/cm2
            =============       =================
Change            0.65 cm       0.0000E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     8.19    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -9.94    Soil evaporation  :     0.00
                             Crack flux        :     0.00
=========================    ============================
Sum            :     0.65    Sum               :     0.00


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.7767E-17
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.7767E-17    Sum            :  0.0000E+00

