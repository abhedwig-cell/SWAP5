* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 10:41:46

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.12 cm       0.9531E+02 mg/cm2
Initial :        73.20 cm       0.7320E+01 mg/cm2
            =============       =================
Change            1.92 cm       0.8799E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.32
Runon          :     0.00    Runoff            :     0.00
SSDI           :     4.80
Irrigation     :     0.00    Transpiration     :    35.35
Bottom flux    :   -35.19    Soil evaporation  :    11.94
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :    53.79    Sum               :    51.87


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.9600E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.7988E+01
                             Drainage       :  0.2641E-01
=========================    ============================
Sum         :  0.8801E+02    Sum            :  0.2641E-01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.47 cm       0.1108E+03 mg/cm2
Initial :        75.12 cm       0.9531E+02 mg/cm2
            =============       =================
Change           -0.65 cm       0.1547E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.68
Runon          :     0.00    Runoff            :     0.00
SSDI           :     1.40
Irrigation     :     0.00    Transpiration     :    25.56
Bottom flux    :   -27.99    Soil evaporation  :    13.79
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    45.39    Sum               :    46.04


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.6800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.5253E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.1547E+02    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.89 cm       0.1476E+03 mg/cm2
Initial :        74.47 cm       0.1108E+03 mg/cm2
            =============       =================
Change            0.43 cm       0.3683E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     1.20
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -23.16    Soil evaporation  :    14.48
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    58.59    Sum               :    58.16


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.7200E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.3517E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.3683E+02    Sum            :  0.0000E+00

