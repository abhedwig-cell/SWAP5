* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 10:40:27

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.58 cm       0.5136E+02 mg/cm2
Initial :        73.20 cm       0.7320E+01 mg/cm2
            =============       =================
Change            1.38 cm       0.4404E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.32
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.38
Bottom flux    :   -33.58    Soil evaporation  :    11.93
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    53.00    Sum               :    51.62


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.3961E+01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.4404E+02    Sum            :  0.0000E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        73.65 cm       0.2855E+02 mg/cm2
Initial :        74.58 cm       0.5136E+02 mg/cm2
            =============       =================
Change           -0.93 cm      -0.2281E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.74
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    25.75
Bottom flux    :   -26.77    Soil evaporation  :    13.64
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    45.21    Sum               :    46.14


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.2281E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.2281E+02    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        73.69 cm       0.1028E+02 mg/cm2
Initial :        73.65 cm       0.2855E+02 mg/cm2
            =============       =================
Change            0.03 cm      -0.1827E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -22.36    Soil evaporation  :    14.48
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    58.19    Sum               :    58.16


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.1827E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.1827E+02    Sum            :  0.0000E+00

