* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 10:40:52

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        52.31 cm       0.1857E-01 mg/cm2
Initial :        54.19 cm       0.3404E+01 mg/cm2
            =============       =================
Change           -1.88 cm      -0.3386E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.74
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    27.79
Bottom flux    :   -30.38    Soil evaporation  :    12.53
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    50.17    Sum               :    52.05


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.3386E+01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.3386E+01    Sum            :  0.0000E+00

