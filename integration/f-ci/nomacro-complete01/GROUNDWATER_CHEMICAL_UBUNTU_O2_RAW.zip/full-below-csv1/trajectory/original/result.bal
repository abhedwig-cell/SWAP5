* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 10:40:47

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        52.78 cm       0.4934E+02 mg/cm2
Initial :        23.68 cm       0.2368E+01 mg/cm2
            =============       =================
Change           29.10 cm       0.4697E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.35
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.72
Bottom flux    :    -5.71    Soil evaporation  :    11.69
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    80.87    Sum               :    51.76


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.1026E+01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.4697E+02    Sum            :  0.0000E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        54.19 cm       0.3404E+01 mg/cm2
Initial :        52.78 cm       0.4934E+02 mg/cm2
            =============       =================
Change            1.40 cm      -0.4594E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.27
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    15.09
Bottom flux    :   -35.85    Soil evaporation  :    13.37
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    36.13    Sum               :    34.73


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.4594E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.4594E+02    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        52.31 cm       0.1857E-01 mg/cm2
Initial :        54.19 cm       0.3404E+01 mg/cm2
            =============       =================
Change           -1.88 cm      -0.3386E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.74
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    27.79
Bottom flux    :   -30.38    Soil evaporation  :    12.53
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    50.17    Sum               :    52.05


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.3386E+01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.3386E+01    Sum            :  0.0000E+00

