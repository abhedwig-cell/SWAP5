* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 10:42:16

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.12 cm       0.5133E+02 mg/cm2
Initial :        76.72 cm       0.5166E+02 mg/cm2
            =============       =================
Change           -1.60 cm      -0.3307E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     0.00    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -1.59    Soil evaporation  :     0.01
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    -1.59    Sum               :     0.01


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.3307E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.3307E+00    Sum            :  0.0000E+00

