* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 11:37:20

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.89 cm       0.1476E+03 mg/cm2
Initial :        74.47 cm       0.1108E+03 mg/cm2
            =============       =================
Change            0.43 cm       0.3683E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     1.20
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -23.16    Soil evaporation  :    14.49
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    58.59    Sum               :    58.16


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.7200E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.3517E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.3683E+02    Sum            :  0.0000E+00

