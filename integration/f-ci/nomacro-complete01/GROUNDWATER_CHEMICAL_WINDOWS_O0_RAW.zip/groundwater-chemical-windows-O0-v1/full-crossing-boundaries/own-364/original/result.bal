* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 11:37:18

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.12 cm       0.9531E+02 mg/cm2
Initial :        73.20 cm       0.7320E+01 mg/cm2
            =============       =================
Change            1.92 cm       0.8799E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.32
Runon          :     0.00    Runoff            :     0.00
SSDI           :     4.80
Irrigation     :     0.00    Transpiration     :    35.35
Bottom flux    :   -35.19    Soil evaporation  :    11.94
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :    53.79    Sum               :    51.87


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.9600E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.7986E+01
                             Drainage       :  0.2642E-01
=========================    ============================
Sum         :  0.8801E+02    Sum            :  0.2642E-01

