* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 11:35:44

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.12 cm       0.4337E+02 mg/cm2
Initial :        73.20 cm       0.1189E+02 mg/cm2
            =============       =================
Change            1.92 cm       0.3148E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.32
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.35
Bottom flux    :   -32.79    Soil evaporation  :    11.94
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :    53.79    Sum               :    51.87


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.1362E+02
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.2876E+01
                             Drainage       :  0.2638E-01
=========================    ============================
Sum         :  0.4512E+02    Sum            :  0.1365E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.47 cm       0.3054E+02 mg/cm2
Initial :        75.12 cm       0.4337E+02 mg/cm2
            =============       =================
Change           -0.65 cm      -0.1283E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.68
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    25.56
Bottom flux    :   -26.60    Soil evaporation  :    13.79
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    45.38    Sum               :    46.03


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.8808E+01
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.4022E+01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.4022E+01    Sum            :  0.8808E+01


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.55 cm       0.1713E+02 mg/cm2
Initial :        74.47 cm       0.3054E+02 mg/cm2
            =============       =================
Change            0.08 cm      -0.1340E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -22.31    Soil evaporation  :    14.48
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    58.24    Sum               :    58.16


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.5426E+01
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.7978E+01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.7978E+01    Sum            :  0.5426E+01

