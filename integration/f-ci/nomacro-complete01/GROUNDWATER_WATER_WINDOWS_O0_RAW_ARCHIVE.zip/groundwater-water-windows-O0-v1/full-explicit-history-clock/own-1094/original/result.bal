* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 11:42:38

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        73.88 cm
Initial :        73.92 cm
            =============
Change           -0.04 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -22.45    Soil evaporation  :    14.46
                             Crack flux        :     0.00
=========================    ============================
Sum            :    58.10    Sum               :    58.14
