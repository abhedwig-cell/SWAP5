* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 11:42:13

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        74.78 cm
Initial :        73.20 cm
            =============
Change            1.58 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.28
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    35.00
Bottom flux    :   -33.84    Soil evaporation  :    11.88
                             Crack flux        :     0.00
=========================    ============================
Sum            :    52.74    Sum               :    51.17

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        73.92 cm
Initial :        74.78 cm
            =============
Change           -0.86 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.68
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    25.56
Bottom flux    :   -27.17    Soil evaporation  :    13.44
                             Crack flux        :     0.00
=========================    ============================
Sum            :    44.81    Sum               :    45.67

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        73.88 cm
Initial :        73.92 cm
            =============
Change           -0.04 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -22.45    Soil evaporation  :    14.46
                             Crack flux        :     0.00
=========================    ============================
Sum            :    58.10    Sum               :    58.14
