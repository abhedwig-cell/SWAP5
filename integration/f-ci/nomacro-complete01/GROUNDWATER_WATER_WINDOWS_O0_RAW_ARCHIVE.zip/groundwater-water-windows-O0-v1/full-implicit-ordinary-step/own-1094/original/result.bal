* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 11:43:16

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        74.55 cm
Initial :        74.47 cm
            =============
Change            0.08 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -22.32    Soil evaporation  :    14.48
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    58.23    Sum               :    58.15
