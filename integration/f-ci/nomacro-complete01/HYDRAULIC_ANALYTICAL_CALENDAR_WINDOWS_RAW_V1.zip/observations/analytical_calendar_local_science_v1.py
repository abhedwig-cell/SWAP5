"""Reread all actual clock postimages and retain the original monthly producer."""
import json,subprocess,sys,time
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');EV=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tests/nomacro_drainage'))
from analytical_calendar_science import audit
profiles=sorted(p.parent for p in EV.glob('analytical-calendar-*/RESULT.json') if p.parent.name!='analytical-calendar-vapor8-monthly-O2-postimage-v1')
assert len(profiles)==15
q=dict(status='RUNNING',observer_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),profiles={},model_executions=0,compiler_executions=0)
out=EV/'ANALYTICAL_CALENDAR_LOCAL_INDEPENDENT_V1.json';assert not out.exists()
def save():out.write_text(json.dumps(q,indent=2)+'\n')
start=time.perf_counter();save()
try:
 for profile in profiles:
  q['profiles'][profile.name]=audit(profile,Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'));save();print(profile.name,'INDEPENDENT_PASS',flush=True)
 q['profiles']['original-monthly-vapor8-O2-source208']=audit(EV/'vapor-monthly-current-postimage-v1',Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'),original_monthly=True)
 proof=json.loads((EV/'ANALYTICAL_MONTHLY_EXACT_POSTIMAGE_INHERITANCE_V1.json').read_text());assert proof['model_executions']==0 and proof['original_producer_or_receipt_rewritten'] is False
 assert len(q['profiles'])==16
 assert sum(v['days']==367 for v in q['profiles'].values())==5
 assert sum(v['days']==35 for v in q['profiles'].values())==9
 assert sum(v['days']==2 for v in q['profiles'].values())==2
 assert sum(v['cold_windows'] for v in q['profiles'].values())==53
 q['status']='INDEPENDENT_FIVE_YEAR_NINE_SHORT_TWO_DENSITY_CONTEXTS_53_EXACT_COLD_DAY_AND_REAL_INTERVAL_NATIVE_OUTPUT_PASS'
except Exception as error:q.update(status='FAILED',error=repr(error));raise
finally:q['seconds']=time.perf_counter()-start;save()
print(q['status'],q['seconds'],flush=True)
