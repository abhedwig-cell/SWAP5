"""Observe real saved interval fields beside actual printed terminal terms."""
import collections,hashlib,json,math,re,struct,zipfile
from pathlib import Path
EV=Path(__file__).parent
SCHEMA='7406171723a1e8af82035a609a201d33f5cc8750be0a4dbce6c3980da81f3068'
def split(value):
 depth=0;start=0;result=[]
 for index,char in enumerate(value):
  if char in '([':depth+=1
  if char in ')]':depth-=1
  if char==',' and depth==0:result.append(value[start:index]);start=index+1
 result.append(value[start:]);assert depth==0;return result
def saved(raw,source,nodes):
 writer=re.findall(r'allocate\(values\(nreal\)\);values=\[(.*)\]\n',source);assert len(writer)==1 and hashlib.sha256(writer[0].encode()).hexdigest()==SCHEMA
 tokens=split(writer[0]);found=[]
 for at in range(len(raw)-160):
  if raw[at:at+8]!=struct.pack('<2i',1,nodes):continue
  h=struct.unpack_from('<20i',raw,at);n=h[3]
  if 0<h[2]<100 and 100<n<100000 and at+160+16*n<=len(raw) and raw[at:at+80]==raw[at+80:at+160] and raw[at+160:at+160+8*n]==raw[at+160+8*n:at+160+16*n]:found.append((at,h))
 assert len(found)==1
 at,h=found[0];variables=dict(numnod=nodes,nrlevs=h[2]);parts=[]
 for token in tokens:
  if token.startswith('reshape('):name=re.match(r'reshape\((\w+)\(',token)[1];size=nodes*h[2]
  elif '(' in token:
   match=re.fullmatch(r'(\w+)\(1:([^()]+)\)',token);assert match;name,expr=match.groups()
   size=None if expr=='maout' else eval(expr,{'__builtins__':{}},variables)
  else:name=token;size=1
  parts.append((name,size))
 unknown=sum(size is None for name,size in parts);assert unknown==2
 count=(h[3]-sum(size or 0 for name,size in parts));assert count>0 and count%unknown==0
 maout=count//unknown;values=struct.unpack_from('<'+str(h[3])+'d',raw,at+160);assert all(math.isfinite(v) for v in values)
 position=0;result={}
 for name,size in parts:
  n=size or maout;result[name]=values[position] if n==1 else values[position:position+n];position+=n
 assert position==h[3];return result,h
q=dict(status='RUNNING',profiles={})
for name in ('analytical-calendar-vapor8-nprint2-O0-v1','analytical-calendar-vapor8-perstep-O2-v1'):
 profile=EV/name;meta=json.loads((profile/'RESULT.json').read_text());build=Path(meta['build_root']);source=(build/'integral.f90').read_text(encoding='cp1252')
 rows=[json.loads(line) for line in (profile/'trajectory/daily.jsonl').read_text().splitlines()];observed={};latest=None
 for line in (profile/'trajectory/original/donor.stdout').read_text().splitlines():
  if line.startswith('MODEL7_TERMINAL_WATER_TERMS '):latest=list(map(float,line.split()[1:]))
  elif line.startswith('ORIGINAL_DAILY_RECEIPT ') and latest is not None:observed[int(line.split()[1])]=latest;latest=None
 counts=collections.Counter();details=[]
 for path in (profile/'trajectory').glob('accepted-column-1-day-*.zip'):
  day=int(path.name.split('-')[-1].split('.')[0])
  with zipfile.ZipFile(path) as z:state,header=saved(z.read('macro.bin'),source,34)
  row=rows[day-1]
  fields=['igrai',None,None,'igird','irunon','iqssdi','iqbup','iintc','iruno','iqrot','iepd','ievap',None,'iqdra',None,'iqbdo','ivolbeg','ipondbeg',None,'isicbeg',None,None]
  expected=[(state[key] if key else 0.)*(-1 if 7<=i<16 else 1) for i,key in enumerate(fields)]+[-v for v in row['stock_end_cm']]
  differences=[i for i,(a,b) in enumerate(zip(observed[day],expected)) if a!=b];counts[str(differences)]+=1
  details.append(dict(day=day,differences=differences,interval_expected=expected,actual_terminal=observed[day]))
 q['profiles'][name]=dict(native_checkpoint_differences=dict(counts),observations=details)
q['status']='SAVED_INTERVAL_NATIVE_AND_REAL_TERMINAL_PHASE_CORRESPONDENCE_OBSERVED_NOT_ADMITTED'
with (EV/'ANALYTICAL_CALENDAR_NATIVE_INTERVAL_ASSESSMENT_V1.json').open('x') as out:json.dump(q,out,indent=2);out.write('\n')
print({key:value['native_checkpoint_differences'] for key,value in q['profiles'].items()})
