"""Check the two exact descriptor changes without rewriting original receipts."""
import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');EV=Path(__file__).parent
sys.path[:0]=[str(ROOT/'tests/nomacro_drainage'),str(ROOT/'tests/nomacro_scheduled_subsurface')]
from calendar_publisher import publisher_equivalence
q=json.loads((EV/'analytical-calendar-vapor8-monthly-O2-postimage-v1/RESULT.json').read_text())
assert q['status']=='ACTUAL_MONTHLY_COMPILED_FORTRAN_PROVIDER_FLAGS_POSTIMAGE_EXACT_PENDING_DESCRIPTOR_AND_ORIGINAL_EVIDENCE_AUDIT'
assert set(q['identity_changes'])=={'model7_terminal_water.source_sha256','restart_publisher.library_sha256'}
old=Path(q['original_build_root']);new=Path(q['build_root'])
a=json.loads((old/'BUILD.json').read_text());b=json.loads((new/'BUILD.json').read_text())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
path='app/hybrid_water/model7_terminal_water.py'
for metadata,source in ((a,'208c25624268589b5f26cbc10f2113aca4276ae6'),(b,'102e95eb6d33107b81ab06576707fe0be9b215e2')):
 assert metadata['identity']['model7_terminal_water']['source_sha256']==sha(subprocess.check_output(['git','show',source+':'+path],cwd=ROOT))
pe=publisher_equivalence(old/'restart_publish.dll',new/'restart_publish.dll')
original=Path(q['original_profile']);raw=(original/'RESULT.json').read_bytes();assert sha(raw)==q['original_RESULT_sha256']
r=dict(status='ACTUAL_MONTHLY_NEW_COMPILED_POSTIMAGE_EXACT_OLD35DAY_TWO_COLD_EVIDENCE_REUSED_AFTER_SOURCE_AND_PE_INVERSE',original_source=q['original_source'],actual_new_compiled_source=q['source'],original_RESULT_sha256=sha(raw),actual_new_BUILD_sha256=q['actual_BUILD_sha256'],whole_Fortran_provider_flags_exact=True,only_descriptor_changes=q['identity_changes'],publisher_equivalence=pe,model_executions=0,original_producer_or_receipt_rewritten=False,canonical_admission=False)
with (EV/'ANALYTICAL_MONTHLY_EXACT_POSTIMAGE_INHERITANCE_V1.json').open('x') as stream:json.dump(r,stream,indent=2);stream.write('\n')
print(r['status'])
