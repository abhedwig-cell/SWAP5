"""Actual unchanged public builder for two accepted calendar configurations."""
import json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');EV=Path(__file__).parent;W=EV.parent
out=EV/'vapor-calendar-build-assessment-v1';out.mkdir()
q=dict(status='RUNNING',source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),cases=[],model_executions=0,public_admission=False)
def save():(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
save()
for label,opt in (('nprint2','O0'),('monthly','O2')):
 inputs=EV/f'vapor-calendar-dispatch-assessment-v1/snow0-{label}'
 build=W/f'vapor-{label}-admission-probe-{opt}-v1/bundle'
 command=[sys.executable,'-B',str(ROOT/'tools/solute/run_water.py'),'--model','original-input-water','--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy','original-adaptive-day-seed-v1','--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--build-only','--donor-opt',opt,'--kernel-opt',opt,'--output',str(build)]
 # Derive the real model identifier from the actual accepted frontend.
 sys.path.insert(0,str(ROOT/'app/hybrid_water'));import experimental_project as e
 project=e.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1');command[4]=project.model
 start=time.perf_counter();run=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=180)
 (out/(label+'.stdout.txt')).write_text(run.stdout);(out/(label+'.stderr.txt')).write_text(run.stderr)
 item=dict(label=label,optimization=opt,command=command,build_root=str(build),actual_frontend_accepted=True,actual_model=project.model,returncode=run.returncode,seconds=time.perf_counter()-start,input_inventory=e.inventory(inputs),model_executions=0)
 q['cases'].append(item);save();print(label,run.returncode,run.stderr.splitlines()[-1:] if run.stderr else [],flush=True)
q['status']='TWO_ACTUAL_VAPOR_CALENDAR_BUILDER_POSTIMAGES_OBSERVED_NOT_QUALIFIED';save()
