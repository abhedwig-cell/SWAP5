"""Observe actual existing calendar dispatch, without modifying application code."""
import json,re,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');EV=Path(__file__).parent
sys.path[:0]=[str(ROOT/'app/hybrid_water'),str(ROOT/'tests/nomacro_scheduled_subsurface')]
import experimental_project as e
from hydraulic_vapor import describe
from original_output_baseline import assignment
from groundwater_water_output import metadata
out=EV/'vapor-calendar-dispatch-assessment-v1';out.mkdir()
base=EV/'snow-vapor-water-O0-v3/input'
q=dict(status='RUNNING',source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),cases=[],model_executions=0,compiler_executions=0,public_admission=False)
def save():(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
save()
for snow in (0,1):
 for label,edits in (('daily',{}),('nprint2',{'NPRINTDAY':2}),('nprint3',{'NPRINTDAY':3}),('monthly',{'SWMONTH':1}),('perstep',{'FLPRINTDT':'.TRUE.','SWRES':0}),('annual-perstep',{'FLPRINTDT':'.TRUE.','SWRES':1})):
  folder=out/f'snow{snow}-{label}';shutil.copytree(base,folder);path=folder/'swap.swp';text=path.read_text(encoding='cp1252')
  for key,value in dict(SWSNOW=snow,**edits).items():text=assignment(text,key,value) if re.search(r'(?mi)^[ \t]*'+key+r'[ \t]*=',text) else text+'\n'+key+' = '+str(value)+'\n'
  path.write_text(text,encoding='cp1252');item=dict(SWSNOW=snow,cadence=label,input_inventory=e.inventory(folder))
  try:project=e.load(folder,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
  except ValueError as error:item.update(frontend='REFUSED',diagnostic=str(error))
  else:
   item['frontend']='ACCEPTED';item['actual_active_vapor']=describe(project)
   try:item.update(auxiliary_magic=e.auxiliary_magic(project).decode(),actual_output_metadata=metadata(project))
   except ValueError as error:item['native_or_output_owner_refusal']=str(error)
  q['cases'].append(item);save();print(snow,label,item['frontend'],item.get('auxiliary_magic'),item.get('diagnostic',item.get('native_or_output_owner_refusal')),flush=True)
q['status']='TWELVE_ACTUAL_VAPOR_CALENDAR_DISPATCH_CONTEXTS_OBSERVED_NOT_QUALIFIED';save()
