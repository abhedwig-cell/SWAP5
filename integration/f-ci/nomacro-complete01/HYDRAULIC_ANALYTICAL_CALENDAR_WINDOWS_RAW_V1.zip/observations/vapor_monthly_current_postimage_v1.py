"""Observe the already built monthly route; no application changes or admission."""
import json,subprocess,sys
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');EV=Path(__file__).parent;W=EV.parent
sys.path[:0]=[str(ROOT/'tests/nomacro_scheduled_subsurface'),str(ROOT/'tests/nomacro_drainage')]
import original_output_matrix as thermal
from water_snow_groundwater_period import cold
m=thermal.m
out=EV/'vapor-monthly-current-postimage-v1';out.mkdir()
inputs=EV/'vapor-calendar-dispatch-assessment-v1/snow0-monthly';build=W/'vapor-monthly-admission-probe-O2-v1/bundle'
q=dict(status='RUNNING',source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),input_root=str(inputs),build_root=str(build),kind='water',optimization='O2',days=35,compiled_in_previous_actual_build_assessment=True,compiler_executions=0,canonical_admission=False)
def save():(out/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
save()
try:
 project=m.e.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1');q['input_inventory']=m.e.inventory(inputs)
 full=out/'trajectory';q['trajectory'],data=m.trajectory(build,Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'),project,full,35,{2,4,30,34,35},180);save()
 q['cold']=[]
 for start,end in ((2,4),(30,34)):q['cold'].append(cold(build,Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'),project,full,data,start,end,out/('own-'+str(start))));save()
 q['status']='ACTUAL_EXISTING_NOSNOW_VAPOR_MONTHLY_35DAY_TWO_EXACT_COLD_POSTIMAGE_PASS_NOT_ADMITTED'
except Exception as error:q.update(status='FAILED',error=repr(error));raise
finally:save()
print(q['status'],flush=True)
