"""Commit, push and observe four genuine never-merge clean public refusals."""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('C:/Users/Veldh012/swap5-groundwater-composition-negative01')
EV=Path(__file__).resolve().parent
BASE='8e27dd9eb0f633050d2d82d00d28992435c313cb'
OBSERVER=EV/'DEFAULT_MODEL_GRAMMAR_PUBLIC_OBSERVE_V1.py'
cases=(
 ('SOURCE','app/hybrid_water/implicit_conductivity.py',b'\n# Actual signed hydraulic source negative; never merge.\n','Unreviewed default model grammar source delta'),
 ('RAW','integration/f-ci/nomacro-complete01/HYDRAULIC_DEFAULT_MODEL_GRAMMAR_WINDOWS_RAW_V1.zip',b'!','AssertionError'),
 ('INHERITED','integration/f-ci/nomacro-complete01/HYDRAULIC_SIGNED_SELECTORS_ADMISSION_RAW_V1.zip',b'!','AssertionError'),
 ('PUBLICATION','tests/publication/run_pub_p2e09_reference_threshold_freeze.sh',b'\n# Actual publication dependency negative; never merge.\n','Earlier observer modified outside exact delegation'))

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
git('checkout','--detach',BASE)
p=Path(git('rev-parse','--git-path','info/sparse-checkout'));p=p if p.is_absolute() else ROOT/p
patterns=p.read_text().splitlines();assert len(patterns)==36
subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],cwd=ROOT,input='\n'.join(patterns+['/integration/f-ci/nomacro-complete01/*DEFAULT_MODEL_GRAMMAR*'])+'\n',text=True,check=True)
assert len(p.read_text().splitlines())==37 and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
result=dict(candidate=BASE,status='RUNNING',controls=[],models=0,compilers=0,never_merge=True)
def save():(EV/'DEFAULT_MODEL_GRAMMAR_FINAL_NEGATIVES_OBSERVE_V1.json').write_text(json.dumps(result,indent=2)+'\n')
save()
for role,path,extra,error in cases:
 branch='codex/nomacro-default-model-grammar-'+role.lower()+'-negative01'
 git('switch','-c',branch,BASE)
 with (ROOT/path).open('ab') as out:out.write(extra)
 git('add','--',path);git('commit','-m','Actual '+role.lower()+' public refusal control; NEVER MERGE');git('push','-u','origin',branch)
 head=git('rev-parse','HEAD');assert git('diff','--name-only',BASE,head)==path
 label='DEFAULT_MODEL_GRAMMAR_FINAL_'+role+'_NEGATIVE_PUBLIC_V1'
 subprocess.run([sys.executable,'-B',str(OBSERVER),'--cwd',str(ROOT),'--output',str(EV/(label+'.json'))],check=True)
 q=json.loads((EV/(label+'.json')).read_text());stderr=(EV/(label+'.stderr.txt')).read_text()
 assert q['returncode']!=0 and error in stderr and q['before']==q['after'] and q['before']['head']==head
 assert not q['before']['status'] and len(q['before']['sparse'])==37
 result['controls'].append(dict(role=role,branch=branch,head=head,path=path,public_returncode=q['returncode'],seconds=q['seconds'],actual_refusal=True));save()
 print(role,head,q['returncode'],q['seconds'],flush=True)
 if role=='PUBLICATION':
  env=dict(os.environ,GITHUB_EVENT_NAME='pull_request')
  scope=subprocess.run([sys.executable,'-B','tests/nomacro_drainage/frost_publication_scope.py'],cwd=ROOT,env=env,capture_output=True,text=True)
  (EV/'DEFAULT_MODEL_GRAMMAR_FINAL_PUBLICATION_SCOPE_NEGATIVE_V1.txt').write_text(scope.stdout+scope.stderr)
  assert scope.returncode==0 and 'PUBLICATION_REPLAY_SELECTED=true' in scope.stdout
  assert not git('status','--porcelain=v1','--untracked-files=all','--ignored') and git('rev-parse','HEAD')==head
result['status']='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN36_PUBLIC_NEGATIVES_REFUSED';save()
