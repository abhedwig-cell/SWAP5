"""Probe original default-model integer spellings; accept zero model days."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
EV=Path(__file__).resolve().parent;WORK=EV.parent
sys.path[:0]=[str(ROOT/'app/hybrid_water'),str(ROOT/'tests/nomacro_scheduled_subsurface')]
import daily_host as host
import experimental_project as frontend
from original_output_baseline import assignment

output=EV/'original-signed-default-reader-v1';output.mkdir()
bundle=WORK/'original-signed-hydraulic-reader-v1/bundle'
base=EV/'original-signed-hydraulic-reader-v1/unsigned-control-input'
exe=host.executable(bundle,'day_donor')
result=dict(status='RUNNING',source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    original_reader_only_executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
    actual_original_BUILD_sha256=hashlib.sha256((bundle/'BUILD.json').read_bytes()).hexdigest(),
    compiled_reader_startups=[],accepted_model_days=0,compiler_executions=0,new_full_model_periods=0,public_admission=False)
def save():(output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
save()
for label,literal in (('unsigned','1'),('positive','+1'),('leading-zero','01'),('positive-leading-zero','+0001'),('per-layer','+01 001')):
    inputs=output/(label+'-input');shutil.copytree(base,inputs)
    path=inputs/'swap.swp';path.write_text(assignment(path.read_text(encoding='cp1252'),'iHWCKmodel',literal),encoding='cp1252')
    project=frontend.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
    directory=output/(label+'-original');host.prepare_column(inputs,directory,host.ColumnStart('original',0),True,True,project)
    run=subprocess.run([str(exe),'./swap.swp'],cwd=directory,input=b'0 0\n',capture_output=True,timeout=20)
    (directory/'donor.stdout').write_bytes(run.stdout);(directory/'donor.stderr').write_bytes(run.stderr)
    assert run.returncode in (0,100) and not run.stderr and b'HYBRID_READY' in run.stdout and b'HYBRID_DAY_RETURN' not in run.stdout
    result['compiled_reader_startups'].append(dict(role=label,literal=literal,actual_original_reader_accepted=True,returncode=run.returncode,input_inventory=frontend.inventory(inputs)));save()
result['status']='ORIGINAL_DEFAULT_MODEL1_SIGN_AND_LEADING_ZERO_READER_SPELLINGS_ACCEPTED_ZERO_MODEL_DAYS'
save();print(result['status'],len(result['compiled_reader_startups']))
