"""Observe four real default-model guards; review a parser-only in-memory inverse."""
from contextlib import ExitStack
import ast
import hashlib
import importlib
import json
from pathlib import Path
import re
import subprocess
import sys
import types

ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');EV=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'app/hybrid_water'),str(ROOT/'tests/nomacro_drainage'),str(ROOT/'tests/nomacro_scheduled_subsurface')]
import experimental_project as frontend
from analytical_hydraulic_archives import Archive
from model7_search_science import Store
from original_output_baseline import assignment

CASES=(
 ('implicit','implicit_conductivity','IMPLICIT_CONDUCTIVITY_WINDOWS_O0_RAW_ARCHIVE','implicit-conductivity-water-cde-windows-O0-v5/short-water-head/input'),
 ('groundwater','implicit_groundwater_state','GROUNDWATER_WATER_WINDOWS_O0_RAW_ARCHIVE','groundwater-water-explicit-ordinary-O0-v1/input'),
 ('snow-undrained','snow_undrained','SNOW_UNDRAINED_WINDOWS_SUPPORT_RAW_ARCHIVE','profiles/snow-undrained-portable-input-projection-v1/water-explicit-flux-daily'),
 ('snow-groundwater','snow_water_groundwater','WATER_SNOW_GROUNDWATER_WINDOWS_O0_SCIENCE_RAW_ARCHIVE','profiles/water-snow-groundwater-day-closure-source-O0-v1/explicit-h0-daily/input'))
OUT=EV/'signed-default-dispatch-assessment-v2';OUT.mkdir()
record=dict(status='RUNNING',source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),observations=[],candidate_checks=[],compiler_executions=0,model_executions=0,public_admission=False)
def save():(OUT/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
def observe(directory,name):
 project=frontend.load(directory,original_output=True,time_step_policy='original-adaptive-day-seed-v1');module=importlib.import_module(name)
 if name=='implicit_conductivity':
  text=(directory/'swap.swp').read_text(encoding='cp1252');report=frontend.inspect(directory,original_output=True)
  return module.selection(text,frontend.switches(text),report['boundary'],original_output=True)
 return module.enabled(project) if name=='implicit_groundwater_state' else module.selection(project)
save();inputs={}
with ExitStack() as stack:
 for label,name,raw,prefix in CASES:
  proof=ROOT/'integration/f-ci/nomacro-complete01';meta=json.loads((proof/(raw+'.json')).read_text())
  archive=(Archive if meta.get('parts') else Store)(proof,raw,stack)
  for spelling,literal in (('unsigned','1'),('signed','+1'),('zero','+0001'),('layers','+01 001')):
   directory=OUT/(label+'-'+spelling);directory.mkdir()
   for member in archive.names:
    if member.startswith(prefix+'/'):
     p=directory/member[len(prefix)+1:];p.parent.mkdir(parents=True,exist_ok=True)
     item=meta['members'][member]
     if isinstance(item,str):
      data=archive.z.read(member);assert hashlib.sha256(data).hexdigest()==item and len(data)==archive.z.getinfo(member).file_size
     else:data=archive.get(member)
     p.write_bytes(data)
   path=directory/'swap.swp';text=path.read_text(encoding='cp1252')
   text=assignment(text,'iHWCKmodel',literal) if re.search(r'(?mi)^\s*iHWCKmodel\s*=',text) else text+'\niHWCKmodel = '+literal+'\n'
   path.write_text(text,encoding='cp1252');inputs[label,spelling]=directory
   try:result=observe(directory,name);error=None
   except ValueError as exc:result=None;error=str(exc)
   if spelling=='unsigned':assert result,(label,error)
   else:assert not result,(label,result)
   record['observations'].append(dict(family=label,module=name,literal=literal,selected=result,error=error,archive=raw,archive_sha256=meta['sha256'],input_prefix=prefix));save()
 old="r'1(?:[ \\t]+1)*[ \\t]*'";new="r'\\+?0*1(?:[ \\t]+\\+?0*1)*[ \\t]*'";originals={};candidates={}
 for label,name,raw,prefix in CASES:
  original=importlib.import_module(name);text=Path(original.__file__).read_text();assert text.count(old)==1
  updated=text.replace(old,new,1)
  functions=lambda source:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
  a,b=functions(text),functions(updated);expected='enabled' if name=='implicit_groundwater_state' else 'selection'
  assert set(a)==set(b) and [key for key in a if a[key]!=b[key]]==[expected]
  candidate=types.ModuleType(name);candidate.__file__=original.__file__;exec(compile(updated,original.__file__,'exec'),candidate.__dict__)
  originals[name]=original;candidates[name]=candidate
  record.setdefault('reviewable_source_edits',{})[name]=dict(before=old,after=new,before_lf_sha256=hashlib.sha256(text.encode()).hexdigest(),after_lf_sha256=hashlib.sha256(updated.encode()).hexdigest(),only_function=expected)
 try:
  sys.modules.update(candidates)
  for label,name,raw,prefix in CASES:
   baseline=observe(inputs[label,'unsigned'],name)
   for spelling in ('signed','zero','layers'):
    actual=observe(inputs[label,spelling],name);assert actual==baseline,(label,spelling,actual,baseline)
    record['candidate_checks'].append(dict(family=label,spelling=spelling,selection_exact_unsigned=True))
 finally:sys.modules.update(originals)
record['status']='FOUR_ACTUAL_DEFAULT_MODEL_GUARD_GAPS_AND_TWELVE_REVIEWABLE_PARSER_ONLY_CANDIDATES_CONFIRMED_NOT_APPLIED';save();print(record['status'])
