"""Only two new prescribed-head/undrained pressure-profile contexts."""
from pathlib import Path
import subprocess,sys,json
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;T='C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py';task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';source='110f2d111a567f8a75e3f8fe211c362824fe41ce';inputs=E/'initial-pressure-profile-bottom5-continuation-inputs-v1/head5-undrained-cde';q=dict(status='RUNNING',source=source,observations=[])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==source
for opt in ('O0','O2'):
 name='initial-pressure-head5-undrained-cde-'+opt+'-v1';out=E/name
 a=subprocess.run([sys.executable,T,'allocate','--task',task,'--kind','build','--name',name,'--variant',opt,'--source-ref',source,'--recipe','python -B tests/nomacro_drainage/initial_pressure_profile_runtime.py SWINCO1 nonhydrostatic original HTB active CDE drainage0 bottom5 --optimization '+opt+' --days35; realoriginal gfortran donor/kernel plus3exactcold'],capture_output=True,text=True);assert a.returncode==0,a.stderr;build=json.loads(a.stdout)['path']
 cmd=[sys.executable,'-B','tests/nomacro_drainage/initial_pressure_profile_runtime.py','--input',str(inputs),'--optimization',opt,'--days','35','--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--build-root',build,'--output',str(out)]
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=900);(E/(name+'.stdout.txt')).write_text(p.stdout);(E/(name+'.stderr.txt')).write_text(p.stderr);q['observations'].append(dict(opt=opt,profile=name,returncode=p.returncode));(E/'INITIAL_PRESSURE_PROFILE_BOTTOM5_CONTINUATION_BATCH_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(opt,p.returncode,flush=True);p.check_returncode()
q['status']='TWO_NEW_ORIGINAL_PRESSURE_PROFILE_UNDRAINED_PRESCRIBED_HEAD_CDE_35DAY_SIX_COLD_PASS';(E/'INITIAL_PRESSURE_PROFILE_BOTTOM5_CONTINUATION_BATCH_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],flush=True)
