"""Prepare four first-time initial-pressure contexts; never execute a model."""
import sys,re,shutil,json,hashlib
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path[:0]=[str(R/'tests/nomacro_drainage'),str(R/'tests/nomacro_scheduled_subsurface')]
from vapor_boundary_inputs import prepare
from original_output_baseline import assignment
out=E/'initial-pressure-profile-inputs-v1';assert not out.exists();out.mkdir();records=[]
for name in ('closed-vapor-cde','nonhydrostatic-water','saturated-vapor-cde','legacy-zih-water'):
 p=out/name
 if name=='closed-vapor-cde':shutil.copytree(E/'vapor-boundary-closed-inputs-v1/vapor-boundary-closed-unit8-active-cde7-8-O0-v1',p)
 else:
  prepare('head5-active-cde8-11',p);f=p/'swap.swp';s=f.read_text(encoding='cp1252')
  for key,value in dict(SWINCO=1,SWBOTB=6,SWDRA=1,SWSOLU=1 if name=='saturated-vapor-cde' else 0).items():s=assignment(s,key,value)
  if name!='saturated-vapor-cde':
   for key,value in dict(iHWCKmodel='3 3' if name=='legacy-zih-water' else '1 1',SWVAPOR='0 0').items():s=assignment(s,key,value)
  rows=[(-.5,-70),(-70,-20),(-195,100)] if name=='saturated-vapor-cde' else [(-.5,-20),(-50,-130),(-195,-210)]
  new='HTB =\n'+''.join(' '+str(z)+' '+str(h)+'\n' for z,h in rows)+'* End of table'
  if name=='legacy-zih-water':new='ZI = '+ ' '.join(str(z) for z,h in rows)+'\nH = '+' '.join(str(h) for z,h in rows)+'\n* End of table'
  s,n=re.subn(r'(?mi)^[ \t]*HTB[ \t]*=[ \t]*\n.*?^\* End of table',lambda m:new,s,count=1,flags=re.S);assert n==1
  f.write_text(s,encoding='cp1252')
 records.append(dict(case=name,inputs=str(p),files={f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}))
(E/'INITIAL_PRESSURE_PROFILE_PREPARED_INPUTS_V1.json').write_text(json.dumps(dict(status='INPUTS_PREPARED_NOT_EXECUTED_OR_QUALIFIED',source='56df667d37c6e4070d6e552e493ddc0e28880a28',contexts=records,compiler_executions=0,model_executions=0),indent=2)+'\n');print('Prepared',len(records),'unique scientific input contexts; no build/model execution')
