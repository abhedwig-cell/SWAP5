"""Run the literal prior source owner under a fully inverted source-only view."""
import sys,json,time,subprocess
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from initial_pressure_profile_source_inverse import complete_inverse,prior_source_projection,boundary_complete_inverse
import vapor_boundary_verify as previous
q=dict(status='RUNNING',source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),model_executions=0,compiler_executions=0);started=time.perf_counter()
try:
 complete_inverse()
 with prior_source_projection():
  saved=previous.complete_inverse;previous.complete_inverse=boundary_complete_inverse
  try:assert previous.guard_previous_source()
  finally:previous.complete_inverse=saved
 q['status']='LITERAL_PRIOR_NATIVE5_AND_ALL_EARLIER_SOURCE_GUARDS_PASS_WITH_EXACT_INITIALIZATION_INVERSE'
except Exception as error:q.update(status='FAILED',error=repr(error));raise
finally:q['seconds']=time.perf_counter()-started;(E/'INITIAL_PRESSURE_PROFILE_PRIOR_SOURCE_PREFLIGHT_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(q,flush=True)
