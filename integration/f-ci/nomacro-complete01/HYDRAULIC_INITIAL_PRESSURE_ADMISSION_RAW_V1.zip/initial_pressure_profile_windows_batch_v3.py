"""Run the seven not-yet-observed Windows contexts from registered real builds."""
import json,os,subprocess,sys
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
T='C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py';task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';source='2e2e95df42ac9f28d2c7b8ab0c98eb3bec802818'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==source
inputs=json.loads((E/'INITIAL_PRESSURE_PROFILE_INITIAL_FRONTEND_V4.json').read_text())['selected_inputs'];q=dict(status='RUNNING',source=source,observations=[])
def save():(E/'INITIAL_PRESSURE_PROFILE_WINDOWS_BATCH_V3.json').write_text(json.dumps(q,indent=2)+'\n')
save()
for case,path in inputs.items():
 for opt in ('O0','O2'):
  name='initial-pressure-'+case+'-'+opt+'-v1';out=E/name
  if case!='closed-vapor-cde':name='initial-pressure-'+case+'-'+opt+'-v2';out=E/name
  if case in ('closed-vapor-cde','legacy-zih-water'):
   item=json.loads((out/'RESULT.json').read_text());assert item['status']=='ACTUAL_ORIGINAL_INITIAL_PRESSURE_WATER_CDE_EXACT_COLD_PASS_NOT_ADMITTED'.replace('INITIAL_PRESSURE_','INITIAL_PRESSURE_PROFILE_');q['observations'].append(dict(case=case,opt=opt,existing_completed_context=str(out),repeated=False));save();continue
  assert not out.exists()
  allocated=subprocess.run([sys.executable,T,'allocate','--task',task,'--kind','build','--name',name,'--variant',opt,'--source-ref',source,'--recipe','python -B tests/nomacro_drainage/initial_pressure_profile_runtime.py actual original SWINCO1 input '+path+' --optimization '+opt+' --days 35 real gfortran donor/kernel; exact three cold windows'],capture_output=True,text=True);assert allocated.returncode==0,allocated.stderr;build=json.loads(allocated.stdout)['path']
  command=[sys.executable,'-B','tests/nomacro_drainage/initial_pressure_profile_runtime.py','--input',path,'--optimization',opt,'--days','35','--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--build-root',build,'--output',str(out)]
  result=subprocess.run(command,cwd=R,capture_output=True,text=True,timeout=900);(E/(name+'.stdout.txt')).write_text(result.stdout);(E/(name+'.stderr.txt')).write_text(result.stderr)
  q['observations'].append(dict(case=case,opt=opt,profile=str(out),returncode=result.returncode));save();print(case,opt,result.returncode,flush=True)
  if result.returncode:q['status']='FAILED';save();raise SystemExit(result.returncode)
q['status']='EIGHT_FIRST_TIME_WINDOWS_SWINCO1_SHORT35_THREE_EXACT_COLD_EACH_PASS';save();print(q['status'],flush=True)
