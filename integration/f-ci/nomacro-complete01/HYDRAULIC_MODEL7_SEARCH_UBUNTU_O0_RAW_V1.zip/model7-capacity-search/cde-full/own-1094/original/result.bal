* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-21 00:03:02

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.36 cm       0.1630E+02 mg/cm2
Initial :        76.64 cm       0.2359E+02 mg/cm2
            =============       =================
Change           -0.28 cm      -0.7291E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.47
                             Crack flux        :     0.00
                             Drainage level 1  :    22.69
=========================    ============================
Sum            :    80.55    Sum               :    80.83


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.6903E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.7981E+01
=========================    ============================
Sum         :  0.6903E+00    Sum            :  0.7981E+01

