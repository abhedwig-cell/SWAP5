* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-21 00:02:45

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.08 cm       0.3961E+02 mg/cm2
Initial :        75.71 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.38 cm       0.3961E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.09
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    33.13
=========================    ============================
Sum            :    86.58    Sum               :    84.20


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.7993E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.9193E+01
=========================    ============================
Sum         :  0.4880E+02    Sum            :  0.9193E+01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.64 cm       0.2359E+02 mg/cm2
Initial :        78.08 cm       0.3961E+02 mg/cm2
            =============       =================
Change           -1.45 cm      -0.1602E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.75
Runon          :     0.00    Runoff            :     0.01
SSDI           :     0.00
Irrigation     :     4.00    Transpiration     :    24.71
Bottom flux    :     0.00    Soil evaporation  :    14.11
                             Crack flux        :     0.00
                             Drainage level 1  :    31.85
=========================    ============================
Sum            :    75.98    Sum               :    77.43


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.6543E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1667E+02
=========================    ============================
Sum         :  0.6543E+00    Sum            :  0.1667E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.36 cm       0.1630E+02 mg/cm2
Initial :        76.64 cm       0.2359E+02 mg/cm2
            =============       =================
Change           -0.28 cm      -0.7291E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.47
                             Crack flux        :     0.00
                             Drainage level 1  :    22.69
=========================    ============================
Sum            :    80.55    Sum               :    80.83


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.6903E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.7981E+01
=========================    ============================
Sum         :  0.6903E+00    Sum            :  0.7981E+01

