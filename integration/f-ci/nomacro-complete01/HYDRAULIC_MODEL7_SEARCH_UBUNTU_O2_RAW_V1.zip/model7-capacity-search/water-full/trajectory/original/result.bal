* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-21 00:02:29

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        78.08 cm
Initial :        75.71 cm
            =============
Change            2.38 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.09
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    33.13
=========================    ============================
Sum            :    86.58    Sum               :    84.20

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.64 cm
Initial :        78.08 cm
            =============
Change           -1.45 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.75
Runon          :     0.00    Runoff            :     0.01
SSDI           :     0.00
Irrigation     :     4.00    Transpiration     :    24.71
Bottom flux    :     0.00    Soil evaporation  :    14.11
                             Crack flux        :     0.00
                             Drainage level 1  :    31.85
=========================    ============================
Sum            :    75.98    Sum               :    77.43

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.36 cm
Initial :        76.64 cm
            =============
Change           -0.28 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.47
                             Crack flux        :     0.00
                             Drainage level 1  :    22.69
=========================    ============================
Sum            :    80.55    Sum               :    80.83
