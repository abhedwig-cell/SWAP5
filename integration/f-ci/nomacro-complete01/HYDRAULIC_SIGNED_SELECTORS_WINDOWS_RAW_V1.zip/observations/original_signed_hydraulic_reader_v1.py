"""Probe original integer syntax and current dispatch, accepting zero model days."""
from contextlib import ExitStack
import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
WORK=Path(__file__).resolve().parent.parent
EV=WORK/'evidence'
sys.path[:0]=[str(ROOT/'tests/nomacro_drainage'),str(ROOT/'tests/nomacro_scheduled_subsurface'),str(ROOT/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive
from original_output_baseline import assignment
import daily_host as host
import experimental_project as frontend
import hydraulic_vapor
import model7_capacity
import model7_terminal_water

output=EV/'original-signed-hydraulic-reader-v1';output.mkdir()
bundle=WORK/'original-signed-hydraulic-reader-v1/bundle';bundle.mkdir()
result=dict(status='RUNNING',source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),compiled_reader_startups=[],accepted_model_days=0,compiler_executions=0,new_full_model_periods=0,public_admission=False)
def save():(output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
save()
with ExitStack() as stack:
 archive=Archive(ROOT/'integration/f-ci/nomacro-complete01','HYDRAULIC_VAPOR_WINDOWS_CDE_RAW_V1',stack)
 role=next(item for item in archive.record['roles'] if item['case']=='mixed-7-8' and item['optimization']=='O0')
 profile=archive.view(role['profile']);q=json.loads((profile/'RESULT.json').read_text())
 projection=json.loads(archive.get('COMPILED_PROJECTION_V1.json'));prefix=projection[q['build_root']]['archive_prefix']
 for name in archive.names:
  if name.startswith(prefix+'/'):
   relative=name[len(prefix)+1:];assert '/' not in relative
   (bundle/relative).write_bytes(archive.get(name))
 result['actual_original_BUILD_sha256']=hashlib.sha256((bundle/'BUILD.json').read_bytes()).hexdigest()
 assert result['actual_original_BUILD_sha256']==projection[q['build_root']]['actual_BUILD_sha256']
 original=profile/'input';inventory=q['inventory']
 for label,models in (('unsigned-control','8'),('signed-scalar','+8'),('signed-mixed','+7 +8')):
  inputs=output/(label+'-input');inputs.mkdir()
  for name,digest in inventory.items():
   raw=(original/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest
   path=inputs/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
  path=inputs/'swap.swp';path.write_text(assignment(path.read_text(encoding='cp1252'),'iHWCKmodel',models),encoding='cp1252')
  project=frontend.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1')
  selected=hydraulic_vapor.describe(project)
  directory=output/(label+'-original')
  host.prepare_column(inputs,directory,host.ColumnStart('original',0),True,True,project)
  run=subprocess.run([str(host.executable(bundle,'day_donor')),'./swap.swp'],cwd=directory,input=b'0 0\n',capture_output=True,timeout=20)
  (directory/'donor.stdout').write_bytes(run.stdout);(directory/'donor.stderr').write_bytes(run.stderr)
  assert run.returncode in (0,100) and not run.stderr and b'HYBRID_READY' in run.stdout and b'HYBRID_DAY_RETURN' not in run.stdout
  result['compiled_reader_startups'].append(dict(role=label,literal_models=models,returncode=run.returncode,actual_original_reader_accepted=True,actual_vapor_models=selected['models'],shared_analytical_dispatch=model7_capacity.analytical_models(project),capacity_correction_selected=model7_capacity.enabled(project),terminal_guard_and_search_selected=model7_terminal_water.enabled(project),input_inventory=frontend.inventory(inputs)))
  save()
result['status']='ORIGINAL_SIGNED_HYDRAULIC_READER_ACCEPTED_BUT_SHARED_CURRENT_DISPATCH_MISSING_FOR_PLUS_LITERALS'
save();print(result['status'],result['compiled_reader_startups'],flush=True)
