"""Reviewable parser-only candidate; actual application source stays unchanged."""
import ast,hashlib,json,sys,types
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
EV=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'app/hybrid_water')]
import model7_capacity as original
import model7_terminal_water as terminal
import experimental_project as frontend

path=ROOT/'app/hybrid_water/model7_capacity.py';before=path.read_text()
old="r'[0-9]+(?:[ \\t]+[0-9]+)*[ \\t]*'"
new="r'[+-]?[0-9]+(?:[ \\t]+[+-]?[0-9]+)*[ \\t]*'"
assert before.count(old)==1
after=before.replace(old,new,1)
functions=lambda text:{node.name:ast.dump(node,include_attributes=False) for node in ast.parse(text).body if isinstance(node,ast.FunctionDef)}
a,b=functions(before),functions(after)
assert set(a)==set(b) and [name for name in a if a[name]!=b[name]]==['analytical_models']
candidate=types.ModuleType('model7_capacity');candidate.__file__=str(path)
exec(compile(after,str(path),'exec'),candidate.__dict__)
checks=[]
for label,models,expected in (('unsigned-control','8',(8,)),('signed-scalar','+8',(8,)),('signed-mixed','+7 +8',(7,8))):
 project=frontend.load(EV/'original-signed-hydraulic-reader-v1'/(label+'-input'),original_output=True,time_step_policy='original-adaptive-day-seed-v1')
 previous=sys.modules['model7_capacity'];sys.modules['model7_capacity']=candidate
 try:
  parsed=candidate.analytical_models(project);assert parsed==expected
  assert candidate.enabled(project)==(7 in expected) and terminal.enabled(project)
 finally:sys.modules['model7_capacity']=previous
 checks.append(dict(role=label,literal=models,parsed=parsed,capacity_selected=7 in expected,terminal_guard_and_search_selected=True))
assert path.read_text()==before
record=dict(status='REVIEWABLE_SIGNED_LITERAL_DISPATCH_CANDIDATE_PASS_NOT_APPLIED',path='app/hybrid_water/model7_capacity.py',
 before=old,after=new,parent_lf_sha256=hashlib.sha256(before.encode()).hexdigest(),candidate_lf_sha256=hashlib.sha256(after.encode()).hexdigest(),
 equations_renderers_and_native_codecs_unchanged=True,checks=checks,compiler_executions=0,new_full_periods=0,public_admission=False)
(EV/'SIGNED_HYDRAULIC_DISPATCH_CANDIDATE_V1.json').open('x').write(json.dumps(record,indent=2)+'\n')
print(record['status'],checks)
