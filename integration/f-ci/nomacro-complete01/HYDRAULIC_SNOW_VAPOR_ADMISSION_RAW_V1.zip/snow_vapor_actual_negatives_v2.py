"""Four actual committed/pushed clean38 never-merge public refusal controls."""
import json,os,subprocess,sys
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-groundwater-composition-negative01');EV=Path(__file__).parent
BASE='bd9426711347a1bd7694d39e5c65345db0e25406';OBSERVER=EV/'SNOW_VAPOR_PUBLIC_OBSERVE_V1.py'
cases=(
 ('SOURCE','app/hybrid_water/snow_vapor_composition.py',b'\n# Actual Snow vapor source negative; NEVER MERGE.\n','Unreviewed Snow vapor source delta'),
 ('RAW','integration/f-ci/nomacro-complete01/HYDRAULIC_SNOW_VAPOR_WINDOWS_RAW_V1.zip',b'!','AssertionError'),
 ('INHERITED','integration/f-ci/nomacro-complete01/HYDRAULIC_DEFAULT_MODEL_GRAMMAR_ADMISSION_RAW_V1.zip',b'!','AssertionError'),
 ('PUBLICATION','tests/publication/run_pub_p2e09_reference_threshold_freeze.sh',b'\n# Actual publication dependency negative; NEVER MERGE.\n','AssertionError'))
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored') and git('rev-parse','HEAD')==BASE
pattern=Path(git('rev-parse','--git-path','info/sparse-checkout'));pattern=pattern if pattern.is_absolute() else ROOT/pattern
assert len(pattern.read_text().splitlines())==38
result=dict(candidate=BASE,status='RUNNING',controls=[],model_executions=0,compiler_executions=0,never_merge=True)
def save():(EV/'SNOW_VAPOR_FINAL_NEGATIVES_OBSERVE_V2.json').write_text(json.dumps(result,indent=2)+'\n')
save()
for role,path,extra,error in cases:
 branch='codex/nomacro-snow-vapor-'+role.lower()+'-negative02';git('switch','-c',branch,BASE)
 with (ROOT/path).open('ab') as out:out.write(extra)
 git('add','--',path);git('commit','-m','Actual '+role.lower()+' Snow vapor public refusal control; NEVER MERGE')
 # No common Git config writes while the genuine positive observer runs.
 git('push','origin',branch)
 head=git('rev-parse','HEAD');assert git('diff','--name-only',BASE,head)==path
 label='SNOW_VAPOR_FINAL_'+role+'_NEGATIVE_PUBLIC_V2'
 subprocess.run([sys.executable,'-B',str(OBSERVER),'--cwd',str(ROOT),'--output',str(EV/label)],check=True)
 q=json.loads((EV/(label+'.json')).read_text());stderr=(EV/(label+'.stderr.txt')).read_text()
 assert q['returncode']!=0 and error in stderr and q['before']==q['after'] and q['before']['head']==head and not q['before']['status'] and len(q['before']['sparse'])==38
 result['controls'].append(dict(role=role,branch=branch,head=head,path=path,public_returncode=q['returncode'],seconds=q['seconds'],actual_refusal=True));save();print(role,head,q['seconds'],flush=True)
 if role=='PUBLICATION':
  scope=subprocess.run([sys.executable,'-B','tests/nomacro_drainage/frost_publication_scope.py'],cwd=ROOT,env=dict(os.environ,GITHUB_EVENT_NAME='pull_request'),capture_output=True,text=True)
  (EV/'SNOW_VAPOR_FINAL_PUBLICATION_SCOPE_NEGATIVE_V2.txt').write_text(scope.stdout+scope.stderr)
  assert scope.returncode==0 and 'PUBLICATION_REPLAY_SELECTED=true' in scope.stdout and not git('status','--porcelain=v1','--untracked-files=all','--ignored') and git('rev-parse','HEAD')==head
result['status']='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN38_PUBLIC_NEGATIVES_REFUSED';save()
