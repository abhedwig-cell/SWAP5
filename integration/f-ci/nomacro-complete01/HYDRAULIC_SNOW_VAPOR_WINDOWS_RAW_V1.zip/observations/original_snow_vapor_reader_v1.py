"""Actual original reader startup only; no model integration or admission."""
import hashlib,json,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
EV=Path(__file__).parent
sys.path[:0]=[str(ROOT/'tests/nomacro_scheduled_subsurface')]
from original_output_baseline import assignment
output=EV/'original-snow-vapor-reader-v1';output.mkdir()
base=EV/'original-signed-default-reader-v1/unsigned-original'
exe=EV.parent/'original-signed-hydraulic-reader-v1/bundle/day_donor.exe'
assert exe.is_file()
q=dict(status='RUNNING',source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),accepted_model_days=0,compiler_executions=0,public_admission=False,cases=[])
def save():(output/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
save()
for label,models,flags in [('model8','8','1 1'),('model11','11','1 1'),('mixed7-8','7 8','1 1'),('mixed8-11-selective','8 11','1 0')]:
 directory=output/label;directory.mkdir()
 for path in base.iterdir():
  if path.is_file() and path.suffix.lower() in ('.swp','.crp','.met','.dra','.bbc','.irg','.sol','.tem','.wbc'):shutil.copy2(path,directory/path.name)
 path=directory/'swap.swp';text=path.read_text(encoding='cp1252')
 for key,value in dict(SWSNOW=1,iHWCKmodel=models,SWVAPOR=flags).items():text=assignment(text,key,value)
 path.write_text(text,encoding='cp1252')
 p=subprocess.run([str(exe),'./swap.swp'],cwd=directory,input=b'0 0\n',capture_output=True,timeout=30)
 (directory/'donor.stdout').write_bytes(p.stdout);(directory/'donor.stderr').write_bytes(p.stderr)
 item=dict(label=label,models=models,flags=flags,returncode=p.returncode,input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),original_reader_ready=b'HYBRID_READY' in p.stdout,no_model_day=b'HYBRID_DAY_RETURN' not in p.stdout,stderr_empty=not p.stderr);q['cases'].append(item);save()
 assert p.returncode in (0,100) and item['original_reader_ready'] and item['no_model_day'] and item['stderr_empty'],item
q['status']='FOUR_ORIGINAL_SNOW_ACTIVE_VAPOR_CONFIGURATIONS_READER_ACCEPTED_ZERO_MODEL_DAYS';save();print(q['status'])
