"""Observe all actual targeted postimages without model/compiler execution."""
import json,subprocess,sys,time
from pathlib import Path
ROOT=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');EV=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tests/nomacro_drainage'))
from snow_vapor_science import audit
profiles=[EV/f'snow-vapor-{kind}-{opt}-v3' for kind in ('water','cde') for opt in ('O0','O2')]
profiles+=sorted(p.parent for p in EV.glob('snow-vapor-*-short-v1/RESULT.json'))
assert len(profiles)==16
q=dict(status='RUNNING',observer_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),profiles={},model_executions=0,compiler_executions=0)
out=EV/'SNOW_VAPOR_LOCAL_INDEPENDENT_V1.json';assert not out.exists()
def save():out.write_text(json.dumps(q,indent=2)+'\n')
save();start=time.perf_counter()
try:
 for profile in profiles:
  q['profiles'][profile.name]=audit(profile,Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'));save();print(profile.name,'INDEPENDENT_PASS',flush=True)
 assert sum(p['days']==1096 for p in q['profiles'].values())==4
 assert sum(p['days']==35 for p in q['profiles'].values())==12
 assert sum(p['cold_windows'] for p in q['profiles'].values())==64
 assert sum(p['native_checkpoints'] for p in q['profiles'].values())==140
 assert sum(p['exact_private_CDE_stocks'] for p in q['profiles'].values())==70
 q['status']='INDEPENDENT_FOUR_FULL_TWELVE_SHORT_SNOW_VAPOR_64_COLD_140_NATIVE_70_CDE_STOCK_POSTIMAGES_PASS'
except Exception as error:q.update(status='FAILED',error=repr(error));raise
finally:q['seconds']=time.perf_counter()-start;save()
print(q['status'],q['seconds'],flush=True)
