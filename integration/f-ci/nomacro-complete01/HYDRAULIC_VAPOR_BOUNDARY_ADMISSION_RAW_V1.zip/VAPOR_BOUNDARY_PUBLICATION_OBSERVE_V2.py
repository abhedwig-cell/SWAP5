"""Record actual publication selection on the unchanged clean candidate."""
import json,os,subprocess,time
from pathlib import Path
root=Path('C:/Users/Veldh012/swap5-implicit-conductivity-canonical01')
out=Path(__file__).parent/'VAPOR_BOUNDARY_FINAL_PUBLICATION_SCOPE_POSITIVE_V1.json'
git=lambda *a:subprocess.check_output(['git',*a],cwd=root,text=True).strip()
before=(git('rev-parse','HEAD'),git('status','--porcelain=v1','--untracked-files=all','--ignored'))
assert before==('56df667d37c6e4070d6e552e493ddc0e28880a28','')
started=time.perf_counter()
p=subprocess.run(['python','-B','tests/nomacro_drainage/frost_publication_scope.py'],cwd=root,env=dict(os.environ,GITHUB_EVENT_NAME='pull_request'),capture_output=True,text=True,timeout=600)
assert before==(git('rev-parse','HEAD'),git('status','--porcelain=v1','--untracked-files=all','--ignored'))
q=dict(head=before[0],clean_including_ignored=True,seconds=time.perf_counter()-started,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,model_executions=0,compiler_executions=0)
with out.open('x') as f:json.dump(q,f,indent=2);f.write('\n')
assert p.returncode==0 and not p.stderr and 'PUBLICATION_REPLAY_SELECTED=false' in p.stdout
print(q)
