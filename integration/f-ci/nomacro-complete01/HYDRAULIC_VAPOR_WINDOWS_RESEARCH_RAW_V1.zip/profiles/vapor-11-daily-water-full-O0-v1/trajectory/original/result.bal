* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-21 03:53:40

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        78.06 cm
Initial :        75.55 cm
            =============
Change            2.51 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.06
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    33.03
=========================    ============================
Sum            :    86.58    Sum               :    84.07

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        75.96 cm
Initial :        78.06 cm
            =============
Change           -2.10 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.56
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    25.04
Bottom flux    :     0.00    Soil evaporation  :    14.37
                             Crack flux        :     0.00
                             Drainage level 1  :    28.11
=========================    ============================
Sum            :    71.98    Sum               :    74.08

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.24 cm
Initial :        75.96 cm
            =============
Change            0.28 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.48
                             Crack flux        :     0.00
                             Drainage level 1  :    22.12
=========================    ============================
Sum            :    80.55    Sum               :    80.27
