* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-21 03:53:40

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        77.99 cm
Initial :        75.04 cm
            =============
Change            2.95 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.01
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    32.64
=========================    ============================
Sum            :    86.58    Sum               :    83.63

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        75.52 cm
Initial :        77.99 cm
            =============
Change           -2.47 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.56
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    25.02
Bottom flux    :     0.00    Soil evaporation  :    14.33
                             Crack flux        :     0.00
                             Drainage level 1  :    28.54
=========================    ============================
Sum            :    71.98    Sum               :    74.45

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        75.90 cm
Initial :        75.52 cm
            =============
Change            0.37 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.49
                             Crack flux        :     0.00
                             Drainage level 1  :    22.02
=========================    ============================
Sum            :    80.55    Sum               :    80.18
