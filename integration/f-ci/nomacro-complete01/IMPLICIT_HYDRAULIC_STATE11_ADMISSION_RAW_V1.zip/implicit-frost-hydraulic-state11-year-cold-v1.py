import argparse,json,subprocess,sys,time
from pathlib import Path
from datetime import date
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');sys.path[:0]=[str(r/'app/hybrid_water'),str(r/'tests/nomacro_drainage'),str(r/'tests/nomacro_scheduled_subsurface')]
from explicit_bottom9_runtime import m,own
p=argparse.ArgumentParser();p.add_argument('--profile',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--reference-work',type=Path,required=True);a=p.parse_args();q=json.loads((a.profile/'RESULT.json').read_text());assert q['status']=='ACTUAL_ORIGINAL_IMPLICIT_FROST_ANALYTICAL_STATE_PHYSICAL_NATIVE_COLD_AND_TRANSACTIONS_PASS_NOT_ADMITTED';build=Path(q['build_root']);meta=json.loads((build/'BUILD.json').read_text());project=m.e.load(q['input_root'],original_output=True,time_step_policy=meta['identity']['time_step_policy']);m.validate_bundle(build,a.reference_work,project);first=date.fromisoformat(meta['project']['start_date']);seam=(date(first.year+1,1,1)-first).days;cuts=sorted(item['day'] for item in q['native_samples']);low=max(d for d in cuts if d<seam);high=min(d for d in cuts if d>seam);assert 0<low<seam<high<=35;a.output.mkdir();result=dict(status='RUNNING_ACTUAL_CALENDAR_DERIVED_YEAR_COLD_WINDOW',actual_scientific_producer=q['actual_source'],actual_controller_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),actual_start_date=str(first),actual_new_year_offset=seam,actual_checkpoint_window=[low,high],full_model_periods_replayed=0,primary_model_days_replayed=0,cold_model_days=high-low)
try:
 data=m.rows(a.profile/'trajectory');result['actual_cold']=own(build,a.reference_work,project,a.profile/'trajectory',data,low,high,a.output/'actual');result['status']='ACTUAL_COLD_WINDOW_SPANS_REAL_NEW_YEAR_EXACT_PHYSICAL_COMPLETE_NATIVE_AND_USER_OUTPUT_PASS'
except Exception as error:result.update(status='FAILED_ACTUAL_YEAR_COLD_CONTROL',error=repr(error));raise
finally:(a.output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status'],str(first),low,high,flush=True)
