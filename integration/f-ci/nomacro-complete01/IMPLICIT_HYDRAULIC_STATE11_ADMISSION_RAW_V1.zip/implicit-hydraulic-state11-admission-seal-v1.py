"""Seal genuine observed canonical admission; no model or compiler execution."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
E=Path(__file__).resolve().parent
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='fdea74b3914fe37c05a6a5301af6661773e1e5e3'
B='22520105f5a3ccac2bd2ae1b726f27b7b0d67b1e'
S='d2d86b6ff605a2a12dd6f504b275a92c7cd8efee'
A='547d107e94ff96c537b77397591ab245da5885d2'
SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
read=lambda p:json.loads((E/p).read_text(encoding='utf8'))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--merge',required=True);a=parser.parse_args();M=a.merge
    assert git('rev-parse','HEAD').decode().strip()==M
    assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
    tree=git('rev-parse',M+'^{tree}').decode().strip()
    assert tree=='9a9d2bbf84dcf7dc98fc5916d146b88c6b031a52'
    for sha in (C,S):assert git('rev-parse',sha+'^{tree}').decode().strip()==tree
    for sha in (S,M):
        assert git('show','-s','--format=%P',sha).decode().split()==[B,C]
        raw=(E/('IMPLICIT_HYDRAULIC_STATE11_PR1810_GENUINE_GIT_OBJECT_'+sha+'.bin')).read_bytes()
        assert raw==git('cat-file','commit',sha)
        assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha
    api=read('IMPLICIT_HYDRAULIC_STATE11_PR1810_ACTUAL_GIT_API_V1.json')
    assert api['sha']==M and api['verification']['verified'] and api['verification']['reason']=='valid'
    positive=read('IMPLICIT_HYDRAULIC_STATE11_CANDIDATE_PUBLIC_V1.stdout.txt');coadmission=positive['coadmission']
    assert (coadmission['contexts'],coadmission['short35_contexts'],coadmission['native_calendar_samples'],coadmission['exact_cold_windows'])==(880,786,5806,2520)
    assert coadmission['new_implicit_analytical_hydraulic_state_contexts']==56
    assert coadmission['new_implicit_analytical_hydraulic_state_primary_days']==1960
    assert coadmission['new_implicit_analytical_hydraulic_state_compiled_refusals']==320
    assert coadmission['new_implicit_analytical_hydraulic_state_external_transactions']==56
    observations={};fixtures=None
    for role,head in [('CANDIDATE',C),('ACTUAL_MERGE',M)]:
        for scope in ('PUBLIC','PUBLICATION'):
            stem='IMPLICIT_HYDRAULIC_STATE11_'+role+'_'+scope+'_V1';q=read(stem+'.json');out=(E/(stem+'.stdout.txt')).read_bytes()
            assert q['returncode']==0 and q['error'] is None and q['before']==q['after'] and not q['before']['status']
            assert not (E/(stem+'.stderr.txt')).read_bytes()
            before=q['before'];assert before['head']==head and before['tree']==tree
            assert len(before['sparse'])==14 and len(before['original_project_files'])==56
            if fixtures is None:fixtures=before['original_project_files']
            assert fixtures==before['original_project_files']
            if scope=='PUBLIC':
                current=json.loads(out);assert current['coadmission']==coadmission
                assert current['compiler_executions']==current['model_executions']==0
                assert len(current['new_original_portable_science'])==4
                assert not current['additional_local_contexts_counted_again']
                assert not current['unchanged_periods_replayed'] and not current['original_scientific_producers_rebound']
            else:
                assert b'PUBLICATION_REPLAY_SELECTED=false' in out
                assert q['ordinary_python_default_dont_write_bytecode'] is False and q['child_bytecode_environment_variables_absent']
            observations[stem]=dict(seconds=q['seconds'],actual_head=head,stdout_sha256=SHA(out))
    negatives=read('IMPLICIT_HYDRAULIC_STATE11_FINAL1_NEGATIVES_V1.json')
    assert negatives['candidate']==C and negatives['never_merge'] is True
    assert negatives['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED'
    assert len(negatives['controls'])==4 and {x['role'] for x in negatives['controls']}=={'SOURCE','RAW','INHERITED','PUBLICATION'}
    for item in negatives['controls']:
        assert item['actual_refusal'] and item['actual_one_file_delta']
        assert git('show','-s','--format=%P',item['head']).decode().split()==[C]
        assert git('diff','--name-only',C,item['head']).decode().splitlines()==[item['path']]
        if item['role']=='PUBLICATION':assert item['actual_publication_replay_selected']
    ci=read('IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL_ALL_CI_API_V1.json')
    runs=ci['runs']['workflow_runs'];checks=ci['checks']['check_runs']
    assert ci['runs']['total_count']==len(runs)==len({r['workflow_id'] for r in runs})==15
    assert all(r['head_sha']==C and r['status']=='completed' and r['conclusion']=='success' for r in runs)
    assert ci['checks']['total_count']==len(checks)
    assert all(c['head_sha']==C and c['status']=='completed' and c['conclusion'] in ('success','skipped') for c in checks)
    roles=['CO2','DVS','LRV','TIMEINT_STARTUP','TIMEINT_INVERSE','FCI_MODULAR']
    roles+=['FCI110_'+v for v in ('B1_POISON','AHL_PROVIDER','AHL_APPLICATION','PLANVALID','AHL_MATRIX','AHL_SCALE','FKT22','PPA','AHL_DEFAULT_OFF','AHL_FAILCLOSED','AHL_OWNERSHIP')]
    roles.append('POND_SUCCESS')
    logs={}
    for role in roles:
        name='IMPLICIT_HYDRAULIC_STATE11_PR1810_'+role+'_ORIGINAL_CI_V1.log';raw=(E/name).read_bytes();q=read(name+'.json')
        raw.decode('utf8',errors='strict')
        assert len(raw)==q['bytes'] and SHA(raw)==q['sha256']
        assert q['actual_source']==C and q['actual_checkout']==S and C.encode() in raw and S.encode() in raw
        logs[role]=q
    selection=read('IMPLICIT_HYDRAULIC_STATE11_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json')
    assert selection['actual_parent']==B and selection['actual_candidate']==C and selection['unchanged_tracked_files']==1063
    assert not git('diff',B,C,'--',*selection['unchanged_dependency_paths'])
    canonical=read('IMPLICIT_HYDRAULIC_STATE11_ACTUAL_MERGE_ALL_CI_API_V1.json')
    assert canonical['total_count']==len(canonical['workflow_runs']) and canonical['workflow_runs']
    for run in canonical['workflow_runs']:
        assert run['head_sha']==M and run['status']=='completed' and run['conclusion']=='success'
        jobs=read('IMPLICIT_HYDRAULIC_STATE11_ACTUAL_MERGE_CI_JOBS_'+str(run['id'])+'_V1.json')['jobs']
        assert jobs and all(j['status']=='completed' and j['conclusion'] in ('success','skipped') for j in jobs)
    # Original Ubuntu producer failure and corrected observer remain distinct.
    correction=read('IMPLICIT_HYDRAULIC_STATE11_DECODED_LOG_UTF8_AUDIT_V1.json')
    for opt in ('O0','O2'):
        name='IMPLICIT_HYDRAULIC_STATE11_FIRST_UBUNTU_'+opt+'_EXACT_DECODED_UTF8_JOB_V2.log'
        (E/name).read_bytes().decode('utf8',errors='strict')
    name='IMPLICIT_HYDRAULIC_STATE11_ADMISSION_RAW_V1';archive=E/(name+'.zip');files={}
    for path in E.iterdir():
        if not path.is_file() or path.suffix in ('.zip','.tar','.gz','.xz') or '.zip.part' in path.name or path.name.startswith(name):continue
        if path.name.startswith(('IMPLICIT_HYDRAULIC_STATE11_','implicit-hydraulic-state11-','implicit-frost-hydraulic-state11-')):files[path.name]=path
    assert Path(__file__).name in files
    members={}
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for member,path in sorted(files.items()):
            raw=path.read_bytes();z.writestr(member,raw);members[member]=dict(bytes=len(raw),sha256=SHA(raw))
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(members) and set(z.namelist())==set(members)
        assert z.testzip() is None
        for member,item in members.items():
            raw=z.read(member);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256'] and raw==files[member].read_bytes()
    raw=archive.read_bytes()
    common=dict(canonical_admission=True,actual_merge=M,qualified_candidate=C,source_anchor=A,whole_tree=tree,
        coadmission=coadmission,new_scientific_contexts=56,actual_primary_portable_producer='c40ca084d8e5eb638e0b4ac5c471463d9aad01c3',
        original_ubuntu_producer_workflow_conclusion='failure',original_ubuntu_model_trajectories_and_native_controls='PASS_BEFORE_OBSERVER_FILENAME_FAILURE',
        actual_ubuntu_observer_only_source='ede801b4a67be2777742d3918090c3b67740fb25',producer_roles_rebound=False,
        selected_model5_exact_chain_rule_Jacobian_is_new_numerical_policy=True,physical_equations_changed=False,new_physical_state=False,
        additional_28_local_contexts_counted_again=False,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
    manifest=dict(status='ACTUAL_CANONICAL880_SIGNED_OBJECTS_PUBLIC_PUBLICATION_15CI_REAL_NEGATIVES_AND_ORIGINAL_LOGS_PRESERVED',
        archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,
        actual_public_observations=observations,successful_workflows=len(runs),successful_checks=sum(c['conclusion']=='success' for c in checks),
        skipped_checks=sum(c['conclusion']=='skipped' for c in checks),canonical_push_workflows_success=len(canonical['workflow_runs']),
        original_PR_success_log_roles=logs,original_failed_and_cancelled_log_roles_preserved=True,decoded_log_UTF8_correction_audit=correction,**common)
    receipt=dict(status='ACTUAL_CANONICAL880_IMPLICIT_HYDRAULIC_STATE_ADMISSION_VERIFIED',PR=1810,previous_canonical=B,
        ordered_parents=[B,C],synthetic_merge=S,admission_archive_sha256=SHA(raw),**common)
    for file,record in [(name+'.json',manifest),('IMPLICIT_HYDRAULIC_STATE11_MERGE_RECEIPT_V1.json',receipt)]:
        with (E/file).open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
    assert git('rev-parse','HEAD').decode().strip()==M
    print(manifest['status'],len(raw),manifest['sha256'],len(members),flush=True)

if __name__=='__main__':main()
