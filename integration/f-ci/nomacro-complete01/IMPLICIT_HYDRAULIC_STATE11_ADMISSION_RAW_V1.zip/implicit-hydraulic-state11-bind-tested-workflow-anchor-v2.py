"""Resume binding after the real eleven-test PASS, handling working CRLF."""
from pathlib import Path
import ast,hashlib,json,re,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
OLD='e28233d32c404c86fa58d7cbd71f7632dde1654c'
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
anchor=git('rev-parse','HEAD').decode().strip();assert anchor.startswith('36c8e0c19a')
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
log=E/'IMPLICIT_HYDRAULIC_STATE11_WORKFLOW_TEST_REPAIR_UNIT_V1.stderr.txt';raw=log.read_bytes()
assert b'Ran 11 tests' in raw and raw.rstrip().endswith(b'OK') and b'FAILED' not in raw
self=R/'tests/nomacro_drainage/implicit_hydraulic_state_verify.py';body=self.read_bytes().replace(b'\r\n',b'\n')
assert body==git('show',anchor+':'+self.relative_to(R).as_posix())
changed,n=re.subn(rb"(?m)^SEALED='[0-9a-f]{40}'$",b"SEALED='"+anchor.encode()+b"'",body);assert n==1
ast.parse(changed);self.write_bytes(changed);git('add','--',self.relative_to(R).as_posix())
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Bind tested exact workflow custody source anchor for final hydraulic-state admission'],cwd=R,check=True)
candidate=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored') and not git('diff',OLD,candidate,'--','app','src','tools','reference')
record=dict(status='ACTUAL_ELEVEN_LEGACY_BOUNDARY_TESTS_PASS_WITH_CURRENT_TEXT_REWRITE_NEGATIVE_SOURCE_BOUND_NOT_YET_PUSHED',
    previous_candidate=OLD,source_anchor=anchor,candidate=candidate,tree=git('rev-parse',candidate+'^{tree}').decode().strip(),
    unit_actual_source=anchor,unit_tests=11,unit_errors=0,unit_stderr_sha256=hashlib.sha256(raw).hexdigest(),
    compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'IMPLICIT_HYDRAULIC_STATE11_FINAL3_CHECKPOINT_V1.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
print(json.dumps(record,indent=2))
