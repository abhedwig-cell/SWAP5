"""Cancel only this task's superseded source-anchor jobs; never current CI."""
from pathlib import Path
import json,os,subprocess,urllib.request,urllib.error
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
OLD='0129113550efaef7f540e8bf3cd917e8fc9ee9d4';CURRENT='e28233d32c404c86fa58d7cbd71f7632dde1654c'
branch='codex/nomacro-implicit-hydraulic-state11'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==CURRENT
pending=json.loads((E/'IMPLICIT_HYDRAULIC_STATE11_OBSOLETE_ANCHOR_PENDING_RUNS_V1.json').read_text(encoding='utf8'))
assert pending and all(p['head_sha']==OLD and p['head_branch']==branch and isinstance(p['id'],int) for p in pending)
# The connector has no workflow-cancel action. Use existing Git credentials
# solely in memory for the same already authorized repository. Never log them.
credential=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,
    env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30)
assert credential.returncode==0,'Existing Git credential unavailable; no CI operation attempted'
fields=dict(line.split('=',1) for line in credential.stdout.decode().splitlines() if '=' in line)
token=fields.get('password');assert token,'No reusable existing credential; no CI operation attempted'
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-owned-obsolete-CI-cleanup'}
out=dict(status='CANCEL_ONLY_OWN_SUPERSEDED_ANCHOR_CI',obsolete_head=OLD,current_head_untouched=CURRENT,results=[])
for item in pending:
    endpoint='https://api.github.com/repos/abhedwig-cell/SWAP5/actions/runs/'+str(item['id'])
    try:
        with urllib.request.urlopen(urllib.request.Request(endpoint,headers=headers),timeout=30) as response:actual=json.load(response)
        assert actual['head_sha']==OLD and actual['head_branch']==branch
        if actual['status']=='completed':out['results'].append(dict(id=item['id'],result='ALREADY_TERMINAL',conclusion=actual['conclusion']));continue
        with urllib.request.urlopen(urllib.request.Request(endpoint+'/cancel',data=b'',method='POST',headers=headers),timeout=30) as response:
            out['results'].append(dict(id=item['id'],result='CANCEL_REQUESTED',http_status=response.status))
    except urllib.error.HTTPError as error:
        out['results'].append(dict(id=item['id'],result='API_REFUSED',http_status=error.code))
        if error.code in (401,403):break
with (E/'IMPLICIT_HYDRAULIC_STATE11_OBSOLETE_ANCHOR_CI_CANCELLATION_V1.json').open('x',encoding='utf8') as stream:json.dump(out,stream,indent=2);stream.write('\n')
print(json.dumps(out,indent=2))
