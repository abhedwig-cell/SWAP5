"""Preserve the complete actual canonical-push run/job responses once terminal."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess,sys,urllib.request
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');M='105b9a8e6ca9e846f214d69a71afe73ed18be11d'
credential=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30)
assert credential.returncode==0;fields=dict(line.split('=',1) for line in credential.stdout.decode().splitlines() if '=' in line)
headers={'Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-canonical-admission-custody'}
def fetch(path):
    with urllib.request.urlopen(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=60) as response:return json.load(response)
runs=fetch('actions/runs?head_sha='+M+'&per_page=100')
assert runs['total_count']==len(runs['workflow_runs'])==4
assert {r['id'] for r in runs['workflow_runs']}=={45971858227,45971858243,45971858233,45971858223}
assert all(r['head_sha']==M and r['event']=='push' for r in runs['workflow_runs'])
if any(r['status']!='completed' for r in runs['workflow_runs']):
    print(json.dumps([dict(id=r['id'],status=r['status'],conclusion=r['conclusion']) for r in runs['workflow_runs']]));sys.exit(2)
assert all(r['conclusion']=='success' for r in runs['workflow_runs'])
with ThreadPoolExecutor(max_workers=4) as pool:
    jobs=list(pool.map(fetch,['actions/runs/'+str(r['id'])+'/jobs?filter=latest&per_page=100' for r in runs['workflow_runs']]))
for run,jobset in zip(runs['workflow_runs'],jobs):
    assert jobset['total_count']==len(jobset['jobs']) and jobset['jobs']
    assert all(j['head_sha']==M and j['status']=='completed' and j['conclusion'] in ('success','skipped') for j in jobset['jobs'])
    with (E/('IMPLICIT_HYDRAULIC_STATE11_ACTUAL_MERGE_CI_JOBS_'+str(run['id'])+'_V1.json')).open('x',encoding='utf8') as out:json.dump(jobset,out,indent=2);out.write('\n')
with (E/'IMPLICIT_HYDRAULIC_STATE11_ACTUAL_MERGE_ALL_CI_API_V1.json').open('x',encoding='utf8') as out:json.dump(runs,out,indent=2);out.write('\n')
print('ACTUAL_CANONICAL_MERGE_FOUR_PUSH_WORKFLOWS_AND_ALL_JOBS_SUCCESS_PRESERVED')
