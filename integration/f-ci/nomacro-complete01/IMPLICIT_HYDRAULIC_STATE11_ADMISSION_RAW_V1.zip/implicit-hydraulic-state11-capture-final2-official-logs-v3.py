"""Stream official original job-log bytes to disk without Windows text conversion."""
from pathlib import Path
import hashlib,json,os,subprocess,urllib.request,urllib.error,urllib.parse
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='e28233d32c404c86fa58d7cbd71f7632dde1654c';S='8745bf31942245fe7028c0b449380306da9fe49b'
SHA=lambda b:hashlib.sha256(b).hexdigest()
jobs=json.loads((E/'IMPLICIT_HYDRAULIC_STATE11_FINAL2_REQUIRED_JOB_LOGS_V3.json').read_text(encoding='utf8'))
assert jobs and len({j['role'] for j in jobs})==len(jobs)
credential=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,
    env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30)
assert credential.returncode==0,'Existing repository credential unavailable'
fields=dict(line.split('=',1) for line in credential.stdout.decode().splitlines() if '=' in line)
token=fields.get('password');assert token,'No existing repository credential'
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Accept-Encoding':'identity',
         'X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-original-evidence-custody'}
api='https://api.github.com/repos/abhedwig-cell/SWAP5/'
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,response_headers,newurl):return None
opener=urllib.request.build_opener(NoRedirect)
def fetch(path):
    try:
        with opener.open(urllib.request.Request(api+path,headers=headers),timeout=90) as response:return response.read()
    except urllib.error.HTTPError as error:
        if error.code not in (301,302,303,307,308):raise
        location=error.headers['Location'];parts=urllib.parse.urlsplit(location)
        assert parts.scheme=='https' and (parts.hostname.endswith('.blob.core.windows.net') or parts.hostname.endswith('.actions.githubusercontent.com'))
        # Signed official storage redirect carries its own authorization.
        # Never forward GitHub credentials across origins or persist its URL.
        with urllib.request.urlopen(urllib.request.Request(location,headers={'User-Agent':'SWAP5-original-evidence-custody','Accept-Encoding':'identity'}),timeout=90) as response:return response.read()
def write_once(path,raw):
    if path.exists():assert path.read_bytes()==raw,'Existing immutable evidence differs: '+path.name
    else:
        with path.open('xb') as stream:stream.write(raw)
for specification in jobs:
    role=specification['role'];job_id=specification['job_id'];run_id=specification['run_id']
    run_raw=fetch('actions/runs/'+str(run_id));run=json.loads(run_raw)
    job_raw=fetch('actions/jobs/'+str(job_id));job=json.loads(job_raw)
    assert run['head_sha']==C and run['event']=='pull_request'
    assert job['run_id']==run_id and job['status']=='completed' and job['conclusion']=='success'
    assert job['head_sha']==C
    name='IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL2_'+role+'_ORIGINAL_CI_V1.log'
    path=E/name
    if path.exists():raw=path.read_bytes()
    else:raw=fetch('actions/jobs/'+str(job_id)+'/logs')
    text=raw.decode('utf8',errors='strict');assert C in text and S in text and not raw.startswith(b'PK')
    write_once(path,raw)
    metadata=dict(status='OFFICIAL_ORIGINAL_UTF8_HTTP_JOB_LOG_BYTES_PRESERVED_WITHOUT_TEXT_NORMALIZATION',
        job_id=job_id,run_id=run_id,role=role,actual_source=C,actual_checkout=S,bytes=len(raw),sha256=SHA(raw),
        original_run_event=run['event'],original_job_conclusion=job['conclusion'],
        original_job_api_sha256=SHA(job_raw),scientific_source_rebound=False,
        original_bytes_converted_or_normalized=False,model_executions=0,compiler_executions=0)
    write_once(path.with_suffix(path.suffix+'.json'),(json.dumps(metadata,indent=2)+'\n').encode())
    write_once(E/('IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL2_JOB_'+str(job_id)+'_ORIGINAL_API_V1.json'),job_raw)
    # A running run's metadata changes legitimately after another job completes;
    # bind each retrieval to this actual job rather than overwrite earlier API.
    write_once(E/('IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL2_RUN_'+str(run_id)+'_AT_JOB_'+str(job_id)+'_API_V1.json'),run_raw)
    print(role,job_id,len(raw),SHA(raw),flush=True)

