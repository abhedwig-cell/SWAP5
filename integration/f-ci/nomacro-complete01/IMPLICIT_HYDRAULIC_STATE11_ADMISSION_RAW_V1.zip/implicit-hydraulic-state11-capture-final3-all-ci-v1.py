"""Capture and validate complete genuine PR final CI and jobs before merge."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess,urllib.request
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='e4d9a56143d85550ee272fbac55f1d4a08173195';B='22520105f5a3ccac2bd2ae1b726f27b7b0d67b1e';S='51a85657597eb5937667c4f084a6ad98351fee28'
credential=subprocess.run(['git','credential','fill'],cwd=R,input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'),timeout=30)
assert credential.returncode==0
fields=dict(line.split('=',1) for line in credential.stdout.decode().splitlines() if '=' in line)
headers={'Authorization':'Bearer '+fields['password'],'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-admission-custody'}
def fetch(path):
    with urllib.request.urlopen(urllib.request.Request('https://api.github.com/repos/abhedwig-cell/SWAP5/'+path,headers=headers),timeout=60) as response:return json.load(response)
with ThreadPoolExecutor(max_workers=3) as pool:
    runs,checks,pr=list(pool.map(fetch,['actions/runs?head_sha='+C+'&per_page=100','commits/'+C+'/check-runs?per_page=100','pulls/1810']))
assert runs['total_count']==len(runs['workflow_runs'])==len({r['workflow_id'] for r in runs['workflow_runs']})==15
assert all(r['head_sha']==C and r['status']=='completed' and r['conclusion']=='success' for r in runs['workflow_runs'])
assert checks['total_count']==len(checks['check_runs']) and all(c['head_sha']==C and c['status']=='completed' and c['conclusion'] in ('success','skipped') for c in checks['check_runs'])
assert pr['head']['sha']==C and pr['base']['sha']==B and pr['merge_commit_sha']==S and pr['state']=='open' and pr['mergeable']
with ThreadPoolExecutor(max_workers=4) as pool:
    jobs=list(pool.map(fetch,['actions/runs/'+str(r['id'])+'/jobs?filter=latest&per_page=100' for r in runs['workflow_runs']]))
for run,jobset in zip(runs['workflow_runs'],jobs):
    assert jobset['total_count']==len(jobset['jobs']) and jobset['jobs']
    assert all(j['head_sha']==C and j['status']=='completed' and j['conclusion'] in ('success','skipped') for j in jobset['jobs'])
    with (E/('IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL3_CI_JOBS_'+str(run['id'])+'_V1.json')).open('x',encoding='utf8') as out:json.dump(jobset,out,indent=2);out.write('\n')
result=dict(runs=runs,checks=checks,PR=pr)
with (E/'IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL3_ALL_CI_API_V1.json').open('x',encoding='utf8') as out:json.dump(result,out,indent=2);out.write('\n')
print('ACTUAL_FINAL3_PR_ALL_CI_PASSED',len(runs['workflow_runs']),len(checks['check_runs']),sum(c['conclusion']=='success' for c in checks['check_runs']),sum(c['conclusion']=='skipped' for c in checks['check_runs']))
