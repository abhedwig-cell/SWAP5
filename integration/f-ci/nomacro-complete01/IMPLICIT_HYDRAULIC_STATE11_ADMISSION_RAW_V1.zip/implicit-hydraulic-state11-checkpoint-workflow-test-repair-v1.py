"""Freeze and bind the exact legacy-workflow comparison repair after real tests."""
from pathlib import Path
import ast,hashlib,importlib.util,json,re,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
C='e28233d32c404c86fa58d7cbd71f7632dde1654c';BASE='22520105f5a3ccac2bd2ae1b726f27b7b0d67b1e'
SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C
helper=R/'tests/nomacro_drainage/implicit_hydraulic_state_ci_checkout_custody.py'
spec=importlib.util.spec_from_file_location('actual_working_checkout_definition',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
path=module.TEST_PATH;before=git('show',C+':'+path);assert before==git('show',BASE+':'+path)
text=before.decode();assert text.count(module.TEST_OLD)==1;at=text.index(module.TEST_OLD)
actual=(R/path).read_bytes().replace(b'\r\n',b'\n');assert actual==text.replace(module.TEST_OLD,module.TEST_NEW,1).encode()
ast.parse(actual);ast.parse(helper.read_bytes())
witness=dict(status='EXACT_CURRENT_WORKFLOW_GUARD_AND_REWRITE_NEGATIVE_ADDED_LEGACY_ASSERTION_AND_ALL_OTHER_NEGATIVES_UNCHANGED',
    actual_before_source=C,actual_canonical_dependency=BASE,files={path:dict(before_lf_sha256=SHA(before),proposed_lf_sha256=SHA(actual),
    ordered_literal_edits=[dict(base_start=at,base_end=at+len(module.TEST_OLD),before=module.TEST_OLD,after=module.TEST_NEW)])},
    old_workflow_validator_changed=False,current_workflow_commands_caps_and_timeout_changed=False,
    compiler_executions=0,model_executions=0)
with (P/'IMPLICIT_HYDRAULIC_STATE11_WORKFLOW_TEST_CUSTODY_V1.json').open('x',encoding='utf8') as out:json.dump(witness,out,indent=2);out.write('\n')
failure=E/'IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL2_FCI_MODULAR_FAILED_ORIGINAL_CI_V1.log';raw=failure.read_bytes()
assert b'test_original_workflow_body_cannot_be_rewritten' in raw and b'Foreign complete current checkout workflow' in raw
record=dict(status='REAL_FINAL2_LEGACY_WORKFLOW_COMPARISON_FAILURE_RETAINED_PENDING_CURRENT_REPAIR_ADMISSION',
    original_candidate=C,original_checkout='8745bf31942245fe7028c0b449380306da9fe49b',original_job_id=140389716966,
    original_run_id=45962659064,original_conclusion='failure',original_tests=11,original_errors=1,
    original_log=failure.name,original_log_bytes=len(raw),original_log_sha256=SHA(raw),canonical_admission=False,
    actual_PUBLIC880='PASS',actual_ordinary_publication='PASS_NO_REPLAY',four_actual_committed_negatives='PASS',
    physical_APP_src_tools_reference_changed_for_this_repair=False,new_model_periods_for_this_repair=0,
    repair='Prove actual complete current workflow and a current text rewrite refusal; read genuine M10 workflow explicitly for the separate unchanged legacy comparison. No source, HEAD, filesystem or namespace identity is rebound.')
with (P/'IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL2_LEGACY_WORKFLOW_FAILURE_V1.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
paths=['tests/hupsel51/test_successor.py','tests/nomacro_drainage/implicit_hydraulic_state_ci_checkout_custody.py',
       'integration/f-ci/nomacro-complete01/IMPLICIT_HYDRAULIC_STATE11_WORKFLOW_TEST_CUSTODY_V1.json',
       'integration/f-ci/nomacro-complete01/IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL2_LEGACY_WORKFLOW_FAILURE_V1.json']
git('add','--',*paths)
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Preserve strict original workflow assertion through exact current checkout custody'],cwd=R,check=True)
anchor=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
label='IMPLICIT_HYDRAULIC_STATE11_WORKFLOW_TEST_REPAIR_UNIT_V1'
with (E/(label+'.stdout.txt')).open('xb') as out,(E/(label+'.stderr.txt')).open('xb') as err:
    result=subprocess.run([sys.executable,'-B','tests/hupsel51/test_successor.py'],cwd=R,stdout=out,stderr=err,timeout=120)
assert result.returncode==0,(E/(label+'.stderr.txt')).read_text(encoding='utf8')
assert b'Ran 11 tests' in (E/(label+'.stderr.txt')).read_bytes() and b'OK' in (E/(label+'.stderr.txt')).read_bytes()
self=R/'tests/nomacro_drainage/implicit_hydraulic_state_verify.py';body=self.read_bytes()
changed,n=re.subn(rb"(?m)^SEALED='[0-9a-f]{40}'$",b"SEALED='"+anchor.encode()+b"'",body);assert n==1
self.write_bytes(changed);git('add','--',self.relative_to(R).as_posix())
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','-m','Bind tested exact workflow custody source anchor for final hydraulic-state admission'],cwd=R,check=True)
candidate=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored') and not git('diff',C,candidate,'--','app','src','tools','reference')
output=dict(status='ACTUAL_ELEVEN_LEGACY_BOUNDARY_TESTS_PASS_WITH_CURRENT_TEXT_REWRITE_NEGATIVE_SOURCE_BOUND_NOT_YET_PUSHED',
    previous_candidate=C,source_anchor=anchor,candidate=candidate,tree=git('rev-parse',candidate+'^{tree}').decode().strip(),
    unit_command=[sys.executable,'-B','tests/hupsel51/test_successor.py'],unit_actual_source=anchor,unit_returncode=result.returncode,
    compiler_executions=0,model_executions=0,canonical_admission=False)
with (E/'IMPLICIT_HYDRAULIC_STATE11_FINAL3_CHECKPOINT_V1.json').open('x',encoding='utf8') as out:json.dump(output,out,indent=2);out.write('\n')
print(json.dumps(output,indent=2))
