"""Hash exact tool-decoded UTF-8 CI logs, retaining all original source roles."""
from pathlib import Path
import hashlib,json
E=Path(__file__).parent
C='fdea74b3914fe37c05a6a5301af6661773e1e5e3';S='d2d86b6ff605a2a12dd6f504b275a92c7cd8efee'
jobs={'TIMEINT_STARTUP':139978440171,'TIMEINT_INVERSE':139978440340,'FCI_MODULAR':139985883538}
for role,job in jobs.items():
    name='IMPLICIT_HYDRAULIC_STATE11_PR1810_'+role+'_ORIGINAL_CI_V1.log'
    path=E/name;raw=path.read_bytes();text=raw.decode('utf8',errors='strict')
    assert C in text and S in text
    api=E/('IMPLICIT_HYDRAULIC_STATE11_PR1810_'+role+'_ORIGINAL_CI_LOG_API_V1.json')
    if api.exists():
        original=json.loads(api.read_text(encoding='utf8'))
        decoded=original.get('decoded_log',original.get('structuredContent',{}).get('content'))
        assert decoded is not None and decoded.encode('utf8')==raw
    record=dict(status='EXACT_TOOL_DECODED_UTF8_ORIGINAL_CI_JOB_LOG_PRESERVED',job_id=job,role=role,
                actual_source=C,actual_checkout=S,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                decoding='Tool-decoded original log string encoded as UTF-8, including original BOM if present; not compressed HTTP response bytes',
                scientific_source_rebound=False,compiler_executions=0,model_executions=0)
    with path.with_suffix(path.suffix+'.json').open('x',encoding='utf8') as stream:json.dump(record,stream,indent=2);stream.write('\n')
    print(role,len(raw),record['sha256'])
