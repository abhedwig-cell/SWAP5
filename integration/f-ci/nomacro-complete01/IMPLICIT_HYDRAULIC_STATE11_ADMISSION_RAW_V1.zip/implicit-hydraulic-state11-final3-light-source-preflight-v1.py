"""Check exact changed-file surface and real current source before publishing."""
from pathlib import Path
import json,subprocess,sys
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
import implicit_hydraulic_state_source_custody as source
import implicit_hydraulic_state_ci_checkout_custody as operations
from implicit_hydraulic_state_source_contract import source as inverse
C='e4d9a56143d85550ee272fbac55f1d4a08173195';A='36c8e0c19afd6e2b4543b332e86f9f8ea0f97288'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
old,current,frozen=source.tree(source.BASE),source.tree('HEAD'),source.tree(A)
assert old.keys()<=current.keys() and current.keys()==frozen.keys()
metadata={source.PREFIX+'STATUS.json',source.PREFIX+'GAP_MATRIX.json'}
assert all(current[p]==frozen[p] for p in current if p not in metadata|{source.SELF})
contract=json.loads(git('show','HEAD:'+source.PREFIX+'IMPLICIT_HYDRAULIC_STATE11_SOURCE_PROPOSAL_V9.json'))
documentation=json.loads(git('show','HEAD:'+source.PREFIX+'IMPLICIT_HYDRAULIC_STATE11_PARENT_DOCUMENTATION_WITNESSES_V1.json'))
operation=operations.source();physical=inverse()
expected={p for p,item in contract['files'].items() if not item['new_file']}|{source.JOINT}|metadata|set(documentation['files'])|set(operation['files'])
assert {p for p in old if old[p]!=current[p]}==expected
assert not git('diff',source.COMPILER,'HEAD','--','app','src','tools','reference')
assert git('diff','--name-only',A,C).decode().splitlines()==[source.SELF]
record=dict(status='ACTUAL_FINAL3_EXACT_INHERITED_CHANGED_FILE_SURFACE_FROZEN_SOURCE_AND_COMPLETE_APP_INVERSES_PASS',
    candidate=C,source_anchor=A,whole_tree=git('rev-parse','HEAD^{tree}').decode().strip(),
    actual_current_operational_custody=operation,actual_physical_source_custody=physical,
    changed_inherited_files=sorted(expected),compiler_executions=0,model_executions=0,
    broad_public_and_publication_still_required=True,canonical_admission=False)
with (E/'IMPLICIT_HYDRAULIC_STATE11_FINAL3_LIGHT_SOURCE_PREFLIGHT_V1.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
print(record['status'])
