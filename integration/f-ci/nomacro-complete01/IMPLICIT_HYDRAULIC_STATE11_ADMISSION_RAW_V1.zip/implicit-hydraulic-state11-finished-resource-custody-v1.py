"""Read genuine Git archive bytes before considering release of owned old builds."""
from pathlib import Path
import hashlib,io,json,subprocess,zipfile
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
W=Path('C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600');E=W/'evidence'
C='fdea74b3914fe37c05a6a5301af6661773e1e5e3';P='integration/f-ci/nomacro-complete01/'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==C
record=dict(status='RUNNING_EXACT_GIT_ARCHIVE_CUSTODY_NO_RELEASE_OR_DELETE',actual_observer=C,resources=[],model_executions=0,compiler_executions=0)
for stem,roots in [
    ('IMPLICIT_HYDRAULIC_STATE11_MODEL5_PUBLIC_RAW_V1',['ih11-model5-public-v1','ih11-model5-public-O0-v1','ih11-model5-public-O2-v1']),
    ('IMPLICIT_HYDRAULIC_STATE11_NONSELECTED_POSTIMAGE_RAW_V1',['ih11-current-postimages-v1','ih11-current-postimages-O0-v1','ih11-current-postimages-O2-v1']),
    ('IMPLICIT_HYDRAULIC_STATE11_PARENT824_POSTIMAGE_RAW_V1',['ih11-parent-postimages-v1','ih11-parent-postimages-O0-v1','ih11-parent-postimages-O2-v1']),
]:
    descriptor=json.loads(git('show',C+':'+P+stem+'.json'))
    parts=[]
    for part in descriptor['parts']:
        raw=git('show',C+':'+P+part['file']);assert len(raw)==part['bytes'] and SHA(raw)==part['sha256'];parts.append(raw)
    archive=b''.join(parts);assert len(archive)==descriptor['bytes'] and SHA(archive)==descriptor['sha256']
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(descriptor['members'])
        assert set(z.namelist())==set(descriptor['members'])
        for label in roots:
            root=W/label;assert root.is_dir() and not root.is_symlink()
            files={};refusals=[]
            for path in root.rglob('*'):
                assert not path.is_symlink()
                if not path.is_file():continue
                member='actual/'+path.relative_to(W).as_posix();raw=path.read_bytes();item=descriptor['members'].get(member)
                if item is None:refusals.append(dict(file=member,reason='NOT_IN_ACCEPTED_ARCHIVE'));continue
                if len(raw)!=item['bytes'] or SHA(raw)!=item['sha256'] or z.read(member)!=raw:
                    refusals.append(dict(file=member,reason='CURRENT_BYTES_DIFFER_FROM_PRESERVED_GIT_ARCHIVE'));continue
                files[member]=dict(bytes=len(raw),sha256=SHA(raw))
            assert files,label
            record['resources'].append(dict(path=str(root),archive=stem,archive_git_source=C,
                archive_sha256=descriptor['sha256'],verified_files=len(files),verified_bytes=sum(v['bytes'] for v in files.values()),
                complete_current_files_exactly_preserved=not refusals,refusals=refusals,
                release_permitted_only_after_actual_canonical_admission_and_no_current_dependency=True))
record['status']='OWN_FINISHED_RESOURCES_FRESHLY_MATCHED_AGAINST_GENUINE_GIT_ARCHIVES_NO_RELEASE_OR_DELETE'
assert git('rev-parse','HEAD').decode().strip()==C
with (E/'IMPLICIT_HYDRAULIC_STATE11_FINISHED_RESOURCE_CUSTODY_V1.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
for item in record['resources']:print(item['path'],item['verified_files'],len(item['refusals']),flush=True)
