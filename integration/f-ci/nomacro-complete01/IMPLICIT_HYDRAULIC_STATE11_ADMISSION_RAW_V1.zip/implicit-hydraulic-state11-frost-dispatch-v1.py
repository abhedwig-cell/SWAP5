import argparse,json,subprocess,sys,time
from pathlib import Path
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');w=Path('C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600');p=argparse.ArgumentParser();p.add_argument('--optimization',choices=['O0','O2'],required=True);a=p.parse_args();opt=a.optimization;head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();q=dict(status='RUNNING_REMAINING_FOUR_FINITE_IMPLICIT_FROST_STATE_CONTEXTS_NOT_ADMITTED',actual_source=head,optimization=opt,steps=[],canonical_admission=False);out=w/('ih11f-v1/dispatch-'+opt+'.json')
def save():out.write_text(json.dumps(q,indent=2)+'\n')
save()
selection=json.loads((r/'integration/f-ci/nomacro-complete01/IMPLICIT_HYDRAULIC_STATE11_FROST_FEEDBACK_SELECTION_V1.json').read_text())
for name in selection['cases']:
 if name=='mixed2-3-water-d0-b5':continue
 command=[sys.executable,'-B','tests/nomacro_drainage/implicit_frost_hydraulic_state_feedback.py','--case',name,'--optimization',opt,'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--output',str(w/('ih11f-v1/'+name+'-'+opt)),'--build-output',str(w/('ih11f-'+opt+'-v1/'+name))];start=time.perf_counter()
 try:
  with (w/('ih11f-v1/'+name+'-'+opt+'.controller.stdout')).open('xb') as stdout,(w/('ih11f-v1/'+name+'-'+opt+'.controller.stderr')).open('xb') as stderr:child=subprocess.run(command,cwd=r,stdout=stdout,stderr=stderr,timeout=900)
  step=dict(case=name,actual_source=head,command=command,returncode=child.returncode,seconds=time.perf_counter()-start)
 except Exception as error:step=dict(case=name,actual_source=head,command=command,error=repr(error),seconds=time.perf_counter()-start)
 q['steps'].append(step);save();print(opt,name,step.get('returncode',step.get('error')),flush=True);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head
q['status']='FINITE_FROST_FEEDBACK_COMPLETE_ALL_ACTUAL_RAW_RETAINED_NOT_ADMITTED';save()
