"""Install the exact operations repair in the existing coherent batch/PR."""
from pathlib import Path
import ast,hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='fdea74b3914fe37c05a6a5301af6661773e1e5e3';P=R/'integration/f-ci/nomacro-complete01'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
contract=json.loads((E/'IMPLICIT_HYDRAULIC_STATE11_HUPSEL_CHECKOUT_PROPOSAL_V1.json').read_text(encoding='utf8'))
path='.github/workflows/hupsel51-water-balance.yml';old=git('show',C+':'+path);new=(E/'IMPLICIT_HYDRAULIC_STATE11_HUPSEL_CHECKOUT_PROPOSED_V1.yml').read_bytes()
assert hashlib.sha256(old).hexdigest()==contract['files'][path]['before_lf_sha256']
assert hashlib.sha256(new).hexdigest()==contract['files'][path]['proposed_lf_sha256']
contract['status']='EXACT_CHECKOUT_ONLY_HUPSEL_WORKER_CONTRACT_ORIGINAL_MODEL_COMMANDS_CAPS_TIMEOUTS_UNCHANGED'
targets={R/path:new,P/'IMPLICIT_HYDRAULIC_STATE11_HUPSEL_CHECKOUT_CONTRACT_V1.json':(json.dumps(contract,indent=2)+'\n').encode(),
    R/'tests/nomacro_drainage/implicit_hydraulic_state_ci_checkout_custody.py':(E/'implicit_hydraulic_state_ci_checkout_custody.PROPOSED_V1.py').read_bytes()}
path=R/'tests/nomacro_drainage/implicit_hydraulic_state_source_custody.py';body=git('show',C+':'+path.relative_to(R).as_posix()).decode()
old='    complete_inverse()';new=('    from implicit_hydraulic_state_ci_checkout_custody import source as checkout_custody\n'
                                '    operations=checkout_custody()\n    complete_inverse()')
assert body.count(old)==1;body=body.replace(old,new,1)
old="|{JOINT}|metadata|set(documentation['files'])";assert body.count(old)==1
body=body.replace(old,old+"|set(operations['files'])",1)
targets[path]=body.encode()
for path,raw in targets.items():
    if path.suffix=='.py':ast.parse(raw)
for path,raw in targets.items():path.write_bytes(raw)
record=dict(status='CHECKOUT_ONLY_OPERATIONS_REPAIR_INSTALLED_PENDING_FRESH_ACTUAL_CANDIDATE_GATES',
    previous_candidate=C,canonical_admission=False,
    original_candidate_PUBLIC880_and_ordinary_publication='PASS_PRESERVED_WITH_ORIGINAL_SOURCE_IDENTITY',
    original_four_committed_negative_controls='PASS_PRESERVED_WITH_ORIGINAL_PARENTS_NEVER_REBOUND',
    original_PR_workflows='14_SUCCESS_HUPSEL_CANCELLED_THREE_ATTEMPTS_ORIGINAL_LOGS_PRESERVED',
    retained_partial_Hupsel_artifact=dict(id=15130451004,bytes=4206987,sha256='851cdbc5d70e1bbc302c8236c4efd40168817aef0a6f8bcccbe0f0e28443869f'),
    all_scientific_APP_source_unchanged=True,portable_model_producer='c40ca084d8e5eb638e0b4ac5c471463d9aad01c3',
    new_model_periods_for_this_operations_repair=0,
    remaining_required=['Fresh genuine current HEAD public/publication','Fresh four actual committed negative controls',
                        'All actual PR checks and signed synthetic merge','Actual canonical merge and postmerge checks'])
with (P/'IMPLICIT_HYDRAULIC_STATE11_PR1810_PRE_CHECKOUT_REPAIR_V1.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
assert not git('diff',C,'--','app','src','tools','reference')
print(record['status'])
