"""Explicitly reject a changed model command with the genuine installed guard."""
from pathlib import Path
import hashlib,json,subprocess,sys
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='e4d9a56143d85550ee272fbac55f1d4a08173195'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
sys.path.insert(0,str(R/'tests/nomacro_drainage'))
import implicit_hydraulic_state_ci_checkout_custody as custody
text=(R/custody.PATH).read_text(encoding='utf8');proof=custody.validate_workflow_text(text)
anchor='run: python3 -B tools/solute/check_hupsel51_repair.py --reference-work'
assert text.count(anchor)==1
changed=text.replace(anchor,'run: echo NEVER_EXECUTE_OR_ACCEPT --reference-work',1)
try:custody.validate_workflow_text(changed)
except ValueError as error:refusal=str(error)
else:raise AssertionError('Changed actual model invocation was accepted')
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
q=dict(status='ACTUAL_INSTALLED_CURRENT_WORKFLOW_GUARD_REFUSES_CHANGED_HUPSEL_MODEL_COMMAND_TEXT_BEFORE_ANY_EXECUTION',
    actual_observer=C,actual_workflow=proof,changed_original_expression=anchor,
    replacement='run: echo NEVER_EXECUTE_OR_ACCEPT --reference-work',
    actual_text_sha256=hashlib.sha256(text.encode()).hexdigest(),mutated_text_sha256=hashlib.sha256(changed.encode()).hexdigest(),
    refusal=refusal,actual_current_workflow_modified=False,source_identity_rebound=False,
    separate_from_four_actual_committed_source_RAW_inherited_publication_controls=True,
    compiler_executions=0,model_executions=0)
with (E/'IMPLICIT_HYDRAULIC_STATE11_ACTUAL_MODEL_COMMAND_TEXT_NEGATIVE_V1.json').open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'])
