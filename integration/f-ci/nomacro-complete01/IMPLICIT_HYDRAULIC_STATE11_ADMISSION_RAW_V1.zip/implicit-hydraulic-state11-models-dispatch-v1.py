import argparse,json,subprocess,sys,time
from pathlib import Path
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');w=Path('C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600')
p=argparse.ArgumentParser();p.add_argument('--optimization',required=True,choices=['O0','O2']);a=p.parse_args();opt=a.optimization
selection=json.loads((r/'integration/f-ci/nomacro-complete01/IMPLICIT_HYDRAULIC_STATE11_MODEL_STATE_FEEDBACK_SELECTION_V1.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();result=dict(status='RUNNING_FINITE_ORIGINAL_MODEL_STATE_FEEDBACK_NOT_ADMITTED',actual_controller_source=head,optimization=opt,steps=[],canonical_admission=False);record=w/('ih11-analysis-v1/finite-models-'+opt+'-dispatch.json')
def save():record.write_text(json.dumps(result,indent=2)+'\n')
save()
for name in selection['cases']:
 command=[sys.executable,'-B','tests/nomacro_drainage/implicit_hydraulic_state_feedback.py','--case',name,'--optimization',opt,'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--output',str(w/('ih11-analysis-v1/'+name+'-'+opt)),'--build-output',str(w/('ih11-models-'+opt+'-v1/'+name))]
 started=time.perf_counter()
 try:
  with (w/('ih11-analysis-v1/'+name+'-'+opt+'.controller.stdout')).open('xb') as out,(w/('ih11-analysis-v1/'+name+'-'+opt+'.controller.stderr')).open('xb') as err:child=subprocess.run(command,cwd=r,stdout=out,stderr=err,timeout=600)
  step=dict(case=name,actual_source=head,command=command,returncode=child.returncode,seconds=time.perf_counter()-started)
 except Exception as error:step=dict(case=name,actual_source=head,command=command,error=repr(error),seconds=time.perf_counter()-started)
 result['steps'].append(step);save();print(opt,name,step.get('returncode',step.get('error')),flush=True)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head
result['status']='FINITE_MODEL_STATE_FEEDBACK_COMPLETE_ALL_RAW_RETAINED_NOT_ADMITTED';save()
