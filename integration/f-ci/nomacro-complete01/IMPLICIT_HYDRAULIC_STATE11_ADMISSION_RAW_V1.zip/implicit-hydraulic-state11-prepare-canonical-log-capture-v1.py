from pathlib import Path
import ast
E=Path(__file__).parent
text=(E/'implicit-hydraulic-state11-capture-final3-official-logs-v1.py').read_text(encoding='utf8')
for before,after in [('e4d9a56143d85550ee272fbac55f1d4a08173195','105b9a8e6ca9e846f214d69a71afe73ed18be11d'),('51a85657597eb5937667c4f084a6ad98351fee28','105b9a8e6ca9e846f214d69a71afe73ed18be11d'),("run['event']=='pull_request'","run['event']=='push'"),('PR1810_FINAL3_','ACTUAL_MERGE_'),('FINAL3_REQUIRED_JOB_LOGS_V1.json','CANONICAL_REQUIRED_JOB_LOGS_V1.json')]:
    assert before in text;text=text.replace(before,after)
ast.parse(text)
with (E/'implicit-hydraulic-state11-capture-canonical-official-logs-v1.py').open('x',encoding='utf8') as out:out.write(text)
