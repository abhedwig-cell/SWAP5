"""Prepare final admission checks for the actual operations-repaired candidate."""
from pathlib import Path
import ast,hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='e28233d32c404c86fa58d7cbd71f7632dde1654c';OLD='fdea74b3914fe37c05a6a5301af6661773e1e5e3'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==C
text=(E/'implicit-hydraulic-state11-admission-seal-v1.py').read_text(encoding='utf8')
for before,after in [(OLD,C),('d2d86b6ff605a2a12dd6f504b275a92c7cd8efee','8745bf31942245fe7028c0b449380306da9fe49b'),
 ('547d107e94ff96c537b77397591ab245da5885d2','0129113550efaef7f540e8bf3cd917e8fc9ee9d4'),
 ('9a9d2bbf84dcf7dc98fc5916d146b88c6b031a52','cb9ef1a10bbc1e79be121db8c167531bd30da8b8'),
 ('CANDIDATE_PUBLIC_V1.stdout.txt','CANDIDATE_PUBLIC_V2.stdout.txt'),
 ("scope+'_V1'","scope+'_V2'"),('FINAL1_NEGATIVES_V1','FINAL2_NEGATIVES_V2'),
 ('PR1810_FINAL_ALL_CI_API_V1','PR1810_FINAL2_ALL_CI_API_V1'),
 ("'IMPLICIT_HYDRAULIC_STATE11_PR1810_'+role+'_ORIGINAL_CI_V1.log'","'IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL2_'+role+'_ORIGINAL_CI_V1.log'"),
 ('MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json','MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V2.json')]:
    assert before in text,before;text=text.replace(before,after)
ast.parse(text)
with (E/'implicit-hydraulic-state11-admission-seal-v2.py').open('x',encoding='utf8') as out:out.write(text)
oldpath=E/'IMPLICIT_HYDRAULIC_STATE11_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V1.json'
old=json.loads(oldpath.read_text(encoding='utf8'));assert old['actual_candidate']==OLD
paths=old['unchanged_dependency_paths'];base=old['actual_parent']
before=git('ls-tree','-rl',base,'--',*paths);after=git('ls-tree','-rl',C,'--',*paths)
assert before==after and len(before.splitlines())==1063
assert hashlib.sha256(before).hexdigest()=='b4aff8d1a27934512a1a311bbcf3f067f1e050fdde5a2cac0a78bdeef7348461'
record=dict(status='MCSOL_NOT_SELECTED_FRESH_LITERAL_UNCHANGED_DEPENDENCY_TREE_AFTER_CHECKOUT_ONLY_REPAIR',
    actual_candidate=C,actual_parent=base,unchanged_dependency_paths=paths,unchanged_tracked_files=1063,
    actual_ls_tree_rl_sha256=hashlib.sha256(before).hexdigest(),original_selection=old,
    original_selection_file=oldpath.name,original_selection_sha256=hashlib.sha256(oldpath.read_bytes()).hexdigest(),
    original_scientific_source_rebound=False,current_model_replay='NOT_SELECTED_IMPACT',compiler_executions=0,model_executions=0)
with (E/'IMPLICIT_HYDRAULIC_STATE11_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V2.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
print('ACTUAL_FINAL2_ADMISSION_SEAL_PREPARED_AND_UNCHANGED_1063_MCSOL_SOURCE_PROVED_NO_MODEL_REPLAY')
