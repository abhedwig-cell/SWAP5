from pathlib import Path
import ast
E=Path(__file__).parent
text=(E/'implicit-hydraulic-state11-real-negative-controls-v1.py').read_text(encoding='utf8')
assert text.count("+'01'")==2
text=text.replace('FINAL1','FINAL2').replace('NEGATIVES_V1','NEGATIVES_V2').replace("+'01'","+'02'")
text=text.replace('_PUBLIC_V1','_PUBLIC_V2').replace('_SCOPE_V1','_SCOPE_V2')
ast.parse(text)
with (E/'implicit-hydraulic-state11-real-negative-controls-v2.py').open('x',encoding='utf8') as out:out.write(text)
print('FRESH_FINAL2_NEGATIVE_CONTROLLER_PREPARED_NO_EXECUTION')
