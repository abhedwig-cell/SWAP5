"""Prepare source-specific final3 observers without rebinding any previous run."""
from pathlib import Path
import ast,hashlib,json,subprocess
E=Path(__file__).parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
C='e4d9a56143d85550ee272fbac55f1d4a08173195';OLD='e28233d32c404c86fa58d7cbd71f7632dde1654c'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R);SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==C
text=(E/'implicit-hydraulic-state11-real-negative-controls-v2.py').read_text(encoding='utf8')
assert text.count("+'02'")==2
text=text.replace('FINAL2','FINAL3').replace('NEGATIVES_V2','NEGATIVES_V3').replace("+'02'","+'03'")
text=text.replace('_PUBLIC_V2','_PUBLIC_V3').replace('_SCOPE_V2','_SCOPE_V3');ast.parse(text)
with (E/'implicit-hydraulic-state11-real-negative-controls-v3.py').open('x',encoding='utf8') as out:out.write(text)
text=(E/'implicit-hydraulic-state11-admission-seal-v2.py').read_text(encoding='utf8')
for before,after in [(OLD,C),('8745bf31942245fe7028c0b449380306da9fe49b','51a85657597eb5937667c4f084a6ad98351fee28'),
 ('0129113550efaef7f540e8bf3cd917e8fc9ee9d4','36c8e0c19afd6e2b4543b332e86f9f8ea0f97288'),
 ('cb9ef1a10bbc1e79be121db8c167531bd30da8b8','a5e95a0420e7ae330926c41e256392fc8c52cadc'),
 ('CANDIDATE_PUBLIC_V2.stdout.txt','CANDIDATE_PUBLIC_V3.stdout.txt'),("scope+'_V2'","scope+'_V3'"),
 ('FINAL2_NEGATIVES_V2','FINAL3_NEGATIVES_V3'),('PR1810_FINAL2_ALL_CI_API_V1','PR1810_FINAL3_ALL_CI_API_V1'),
 ("'IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL2_'+role+'_ORIGINAL_CI_V1.log'","'IMPLICIT_HYDRAULIC_STATE11_PR1810_FINAL3_'+role+'_ORIGINAL_CI_V1.log'"),
 ('MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V2.json','MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V3.json')]:
    assert before in text,before;text=text.replace(before,after)
ast.parse(text)
with (E/'implicit-hydraulic-state11-admission-seal-v3.py').open('x',encoding='utf8') as out:out.write(text)
oldpath=E/'IMPLICIT_HYDRAULIC_STATE11_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V2.json';old=json.loads(oldpath.read_text(encoding='utf8'))
assert old['actual_candidate']==OLD
paths=old['unchanged_dependency_paths'];base=old['actual_parent']
before=git('ls-tree','-rl',base,'--',*paths);after=git('ls-tree','-rl',C,'--',*paths)
assert before==after and len(before.splitlines())==1063 and SHA(before)=='b4aff8d1a27934512a1a311bbcf3f067f1e050fdde5a2cac0a78bdeef7348461'
record=dict(status='MCSOL_NOT_SELECTED_FRESH_LITERAL_UNCHANGED_1063_DEPENDENCY_FILES_FINAL3',
    actual_candidate=C,actual_parent=base,unchanged_dependency_paths=paths,unchanged_tracked_files=1063,
    actual_ls_tree_rl_sha256=SHA(before),original_selection=old,original_selection_file=oldpath.name,
    original_selection_sha256=SHA(oldpath.read_bytes()),original_scientific_source_rebound=False,
    current_model_replay='NOT_SELECTED_IMPACT',compiler_executions=0,model_executions=0)
with (E/'IMPLICIT_HYDRAULIC_STATE11_MCSOL_UNCHANGED_DEPENDENCY_SELECTION_V3.json').open('x',encoding='utf8') as out:json.dump(record,out,indent=2);out.write('\n')
print('FINAL3_SOURCE_SPECIFIC_CONTROLS_AND_ADMISSION_CONTROLLER_PREPARED_NO_RUN_REBINDING_NO_MODEL_REPLAY')
