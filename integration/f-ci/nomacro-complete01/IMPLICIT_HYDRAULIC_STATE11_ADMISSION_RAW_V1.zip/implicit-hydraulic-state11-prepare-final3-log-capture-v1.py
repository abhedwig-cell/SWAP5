from pathlib import Path
import ast
E=Path(__file__).parent
text=(E/'implicit-hydraulic-state11-capture-final2-official-logs-v1.py').read_text(encoding='utf8')
for before,after in [('e28233d32c404c86fa58d7cbd71f7632dde1654c','e4d9a56143d85550ee272fbac55f1d4a08173195'),
 ('8745bf31942245fe7028c0b449380306da9fe49b','51a85657597eb5937667c4f084a6ad98351fee28'),('FINAL2','FINAL3')]:
    assert before in text;text=text.replace(before,after)
ast.parse(text)
with (E/'implicit-hydraulic-state11-capture-final3-official-logs-v1.py').open('x',encoding='utf8') as out:out.write(text)
