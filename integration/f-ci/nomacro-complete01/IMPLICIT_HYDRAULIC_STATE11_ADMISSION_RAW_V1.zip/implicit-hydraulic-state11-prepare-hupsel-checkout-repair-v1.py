"""Prepare an exact checkout-only repair after genuine CI infrastructure timeouts."""
from pathlib import Path
import hashlib,json,subprocess
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent
C='fdea74b3914fe37c05a6a5301af6661773e1e5e3';B='22520105f5a3ccac2bd2ae1b726f27b7b0d67b1e'
P='integration/f-ci/nomacro-complete01/'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
SHA=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=all','--ignored')
path='.github/workflows/hupsel51-water-balance.yml';before=git('show',C+':'+path)
assert before==git('show',B+':'+path)
text=before.decode();anchor='    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-python@v5'
assert text.count(anchor)==1
addition=('        with:\n'
          '          filter: blob:none\n'
          '          sparse-checkout-cone-mode: false\n'
          '          sparse-checkout: |\n'
          '            /*\n'
          '            !/integration/**/*.zip\n'
          '            !/integration/**/*.zip.part*\n'
          '            !/integration/**/*.tar.xz\n'
          '            !/integration/**/*.tar.xz.part*\n'
          '            !/integration/**/*.tar.gz\n'
          '            !/integration/**/*.tar.gz.part*\n')
at=text.index(anchor)+len('    steps:\n      - uses: actions/checkout@v4\n')
after=text[:at]+addition+text[at:]
assert after.replace(addition,'',1)==text
contract=dict(status='CHECKOUT_ONLY_PROPOSAL_ORIGINAL_HUPSEL_MODEL_COMMANDS_AND_TIMEOUTS_UNCHANGED_NOT_INSTALLED',
    actual_before_source=C,actual_canonical_dependency=B,files={path:dict(before_lf_sha256=SHA(before),proposed_lf_sha256=SHA(after.encode()),
    ordered_literal_edits=[dict(base_start=at,base_end=at,before='',after=addition)])},
    omitted_working_bytes='Only integration ZIP/tar proof archives and byte-parts; retained in genuine Git objects, not required by fresh Hupsel model worker',
    retained_sources_inputs_and_commands='Whole app/src/tools/tests/reference/examples and every compact integration record',
    scientific_equations_changed=False,model_commands_changed=False,model_caps_changed=False,job_timeout_changed=False,
    compiler_executions=0,model_executions=0)
for name,raw in [('IMPLICIT_HYDRAULIC_STATE11_HUPSEL_CHECKOUT_PROPOSED_V1.yml',after.encode()),
    ('IMPLICIT_HYDRAULIC_STATE11_HUPSEL_CHECKOUT_PROPOSAL_V1.json',(json.dumps(contract,indent=2)+'\n').encode())]:
    with (E/name).open('xb') as out:out.write(raw)
print(contract['status'])
