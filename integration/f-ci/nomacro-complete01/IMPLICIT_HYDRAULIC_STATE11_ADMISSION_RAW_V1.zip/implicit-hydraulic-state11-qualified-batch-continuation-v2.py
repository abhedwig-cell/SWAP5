import json,os,subprocess,sys,time
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01')
W=Path('C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600')
opt=sys.argv[1];assert opt in ('O0','O2')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='3fb05b2827a5d298b558aa93581ec86f46a0390d'
root=W/'ih11-branch-qualified-v1';build=W/('ih11-branch-qualified-'+opt+'-v1')
cases=[('ordinary',v) for v in ['model6-snow-cde-profile','mixed8-9-water','mixed10-11-snow-water','mixed1-7-cde']]+[('frost',v) for v in ['mixed2-3-water-d0-b5','mixed4-5-cde-d1-b5','mixed6-7-cde-d0-b8','mixed8-9-water-d1-b8']]
q=dict(status='RUNNING',actual_source=head,optimization=opt,contexts=[],unaffected_pure_Gardner_not_replayed=True)
record=root/('BATCH-CONTINUATION-'+opt+'.json')
def save():record.write_text(json.dumps(q,indent=2)+'\n')
save()
for kind,case in cases:
 name=kind+'-'+case;folder=root/(name+'-'+opt)
 script='implicit_'+('frost_' if kind=='frost' else '')+'hydraulic_state_feedback.py'
 cmd=[sys.executable,'-B',str(R/'tests/nomacro_drainage'/script),'--case',case,'--optimization',opt,'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--output',str(folder),'--build-output',str(build/name)]
 start=time.perf_counter()
 with (root/(name+'-'+opt+'.stdout')).open('xb') as out,(root/(name+'-'+opt+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err)
 result=json.loads((folder/'RESULT.json').read_text()) if (folder/'RESULT.json').exists() else {}
 q['contexts'].append(dict(kind=kind,case=case,command=cmd,returncode=p.returncode,seconds=time.perf_counter()-start,status=result.get('status'),error=result.get('error')));save()
 print(opt,name,p.returncode,result.get('status'),flush=True)
 if p.returncode:q['status']='FAILED';save();sys.exit(p.returncode)
q['status']='EIGHT_REMAINING_AFFECTED_CONTEXTS_ACTUAL_PUBLIC_35_DAY_COLD_NATIVE_TRANSACTION_PASS_NOT_ADMITTED';save()
