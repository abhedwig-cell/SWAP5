import hashlib,json,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');W=Path('C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600');E=W/'evidence';NAME='IMPLICIT_HYDRAULIC_STATE11_CURRENT_COUPLINGS_RAW_V3';sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='3fb05b2827a5d298b558aa93581ec86f46a0390d'
science=json.loads((E/'IMPLICIT_HYDRAULIC_STATE11_CURRENT_COMPLETED_INDEPENDENT_SCIENCE_V2.json').read_text());assert len(science['contexts'])==24 and science['primary_days']==840
roots=['ih11-branch-qualified-v1','ih11-branch-qualified-O0-v1','ih11-branch-qualified-O2-v1'];files={}
for root in roots:
 for f in sorted((W/root).rglob('*')):
  assert not f.is_symlink()
  if f.is_file() and not any(part.startswith('ordinary-model5-cde-profile') for part in f.relative_to(W/root).parts):files['actual/'+f.relative_to(W).as_posix()]=f
for n in ['implicit-hydraulic-state11-qualified-batch-v1.py','implicit-hydraulic-state11-qualified-batch-continuation-v2.py','implicit-hydraulic-state11-current-science-v1.py','IMPLICIT_HYDRAULIC_STATE11_CURRENT_COMPLETED_INDEPENDENT_SCIENCE_V1.json','IMPLICIT_HYDRAULIC_STATE11_CURRENT_COMPLETED_INDEPENDENT_SCIENCE_V2.json',Path(__file__).name]:files['observer-and-controller/'+n]=E/n
members={};target=E/(NAME+'.zip')
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,f in sorted(files.items()):
  raw=f.read_bytes();z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=sha(raw));assert sha(f.read_bytes())==members[n]['sha256']
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 for n,item in members.items():
  raw=z.read(n);assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
raw=target.read_bytes();parts=[]
for i,at in enumerate(range(0,len(raw),20_000_000),1):
 value=raw[at:at+20_000_000];n=NAME+'.zip.part'+str(i).zfill(3);assert not (E/n).exists();(E/n).write_bytes(value);parts.append(dict(file=n,bytes=len(value),sha256=sha(value)))
dependencies={}
for stem in ['IMPLICIT_HYDRAULIC_STATE11_FROST_CAUSAL_RAW_V1','IMPLICIT_HYDRAULIC_STATE11_MODEL5_CAUSAL_RAW_V1']:
 p=json.loads((E/(stem+'.json')).read_text());dependencies[stem]=dict(bytes=p['bytes'],sha256=p['sha256'])
q=dict(status='ACTUAL_AFFECTED_COUPLINGS_AND_ORIGINAL_FAILURES_RETAINED_FULL_CRC_MEMBER_SHA_VERIFIED_NOT_ADMITTED',archive=NAME+'.zip',bytes=len(raw),sha256=sha(raw),parts=parts,members=members,actual_preservation_source=head,actual_scientific_source=head,raw_dependencies=dependencies,scientific_totals=dict(successful_contexts=24,primary_days=840,ordinary_model5_failed_contexts=2),deduplicated_roles='Two fixed PDI contexts and original model5 failure payloads are retained once in the named actual causal archives; this archive retains other22 successful contexts and exact actual batch ledgers.',canonical_admission=False,portable_qualification=False)
(E/(NAME+'.json')).write_text(json.dumps(q,indent=2)+'\n');print('SEALED',len(raw),sha(raw),len(members),flush=True)
