"""Retain actual zero-day guard evidence before releasing reproducible work."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,subprocess,sys,zipfile
E=Path(__file__).resolve().parent;W=E.parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert HEAD=='7fcb9add0d3aeea936c8867d83408a6549b479d3';sys.path.insert(0,str(R/'tests/nomacro_drainage'))
from analytical_hydraulic_archives import Archive,SHA
from frost_boundary_git_archive import GitArchiveSource
q=json.loads((W/'ih11g-v1/RESULT.json').read_text());assert q['actual_controller_source']==HEAD and q['status'].startswith('ORIGINAL_OPTIONAL_ALFAW_PUBLIC_GUARD_REPAIRED') and q['model_days']==q['model_executions']==0 and len(q['postimages'])==2
assert sum(len(i['whole_objects']) for i in q['postimages'])==42
files={};members={};projection={}
for label,prefix in [('ih11g-v1','actual-feedback'),('ih11g-O0-v1','actual-builds/O0'),('ih11g-O2-v1','actual-builds/O2')]:
 root=W/label
 for path in root.rglob('*'):
  assert not path.is_symlink()
  if path.is_file():files[prefix+'/'+path.relative_to(root).as_posix()]=path
  if path.name=='BUILD.json':projection[str(path.parent)]=dict(archive_prefix=prefix+'/'+path.parent.relative_to(root).as_posix(),actual_BUILD_sha256=SHA(path.read_bytes()))
required={};J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
with ExitStack() as stack:
 sdk=Archive(GitArchiveSource(R,'087fc67db3e1e58d45215522eb284e89cb6c12f1'),'FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',stack)
 for observation in q['original_readswap_contracts'].values():
  for name,digest in observation['original_objects'].items():
   member='original-provider-build/swap-obj/'+name;raw=sdk.get(member);assert SHA(raw)==digest and raw==(J/'build/swap-obj'/name).read_bytes();required[member]=dict(bytes=len(raw),sha256=digest)
 for item in q['contexts']:
  for build in item.get('builds',{}).values():
   identity=build['meta']['identity']
   for key,folder in [('donor_objects','swap-obj'),('donor_modules','swap-obj'),('ttutil_modules','ttutil-obj')]:
    for name,digest in identity[key].items():
     member='original-provider-build/'+folder+'/'+name;raw=sdk.get(member);assert SHA(raw)==digest and raw==(J/'build'/folder/name).read_bytes();required[member]=dict(bytes=len(raw),sha256=digest)
 member='original-provider-build/ttutil-obj/libttutil.a';raw=sdk.get(member);assert raw==(J/'build/ttutil-obj/libttutil.a').read_bytes();required[member]=dict(bytes=len(raw),sha256=SHA(raw))
 dependency=dict(actual_data_revision='087fc67db3e1e58d45215522eb284e89cb6c12f1',archive='FROST_BOUNDARY_STATE_CALENDAR04_LOCAL_WINDOWS_O0_O2_RAW_V1',sha256=sdk.record['sha256'],actual_required_files=required)
name='IMPLICIT_HYDRAULIC_STATE11_GUARD_RAW_V1';archive=E/(name+'.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def add(label,raw):z.writestr(label,raw);members[label]=dict(bytes=len(raw),sha256=SHA(raw))
 for label,path in sorted(files.items()):add(label,path.read_bytes())
 for sha in [q['actual_parent'],HEAD]:
  add('genuine-commit/'+sha+'.bin',subprocess.check_output(['git','cat-file','commit',sha],cwd=R))
  for path in ['app/hybrid_water/implicit_conductivity.py','tests/nomacro_drainage/implicit_hydraulic_state_guard_feedback.py']:
   result=subprocess.run(['git','show',sha+':'+path],cwd=R,capture_output=True)
   if result.returncode==0:add('immutable-git-source/'+sha+'/'+path,result.stdout)
 add('LOCAL_PROVIDER_DEPENDENCY_V1.json',(json.dumps(dependency,indent=2)+'\n').encode());add('COMPILED_PROJECTION_V1.json',(json.dumps(projection,indent=2)+'\n').encode());add('controllers/'+Path(__file__).name,Path(__file__).read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(members)
 for label,item in members.items():raw=z.read(label);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=archive.read_bytes();parts=[]
for i,offset in enumerate(range(0,len(raw),25*1024**2),1):
 value=raw[offset:offset+25*1024**2];file=name+'.zip' if len(raw)<=25*1024**2 else name+f'.zip.part{i:03d}'
 with (P/file).open('xb') as f:f.write(value)
 parts.append(dict(file=file,bytes=len(value),sha256=SHA(value)))
record=dict(status='ORIGINAL_OPTIONAL_ALFAW_REAL_READER_PUBLIC_GUARD_AND42_WHOLE_OBJECT_POSTIMAGES_PRESERVED_NO_MODEL_REPLAY',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=parts,members=members,actual_current_source=HEAD,actual_original_public_source=q['actual_parent'],original_input_authority=q['original_input_authority'],original_provider_dependency=dependency,original_reader_executions=8,original_reader_acceptances=6,original_active_hysteresis_missing_column_refusals=2,public_build_commands=4,whole_objects=42,source_and_object_normalization=False,new_scientific_contexts=0,model_executions=0,model_days=0,canonical_admission=False)
for root in [E,P]:
 with (root/(name+'.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(record['status'],len(raw),record['sha256'],len(members),flush=True)
