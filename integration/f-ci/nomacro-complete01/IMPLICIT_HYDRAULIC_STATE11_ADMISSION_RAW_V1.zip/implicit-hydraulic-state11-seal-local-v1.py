import hashlib,io,json,subprocess,zipfile
from pathlib import Path
r=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');w=Path('C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600');e=w/'evidence';p=r/'integration/f-ci/nomacro-complete01';name='IMPLICIT_HYDRAULIC_STATE11_LOCAL_RAW_V1';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=r)
assert not git('status','--porcelain=v1','--untracked-files=all')
head=git('rev-parse','HEAD').decode().strip();science=json.loads((e/'IMPLICIT_HYDRAULIC_STATE11_LOCAL_SCIENCE_V2.json').read_text());assert science['primary_days']==630 and len(science['contexts'])==18 and science['status'].startswith('INDEPENDENT_EIGHTEEN')
provider=json.loads((p/'IMPLICIT_HYDRAULIC_STATE11_GUARD_RAW_V1.json').read_text())['original_provider_dependency'];j=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
for member,item in provider['actual_required_files'].items():
 assert member.startswith('original-provider-build/');target=j/'build'/member[len('original-provider-build/'):];value=target.read_bytes();assert len(value)==item['bytes'] and sha(value)==item['sha256'],member
compiler=Path('C:/msys64/ucrt64/bin/gfortran.exe');assert sha(compiler.read_bytes())=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
roots=['ih11-analysis-v1','ih11-analysis-O0-v1','ih11-analysis-O2-v1','ih11-models-O0-v1','ih11-models-O2-v1','ih11-models-O0-v2','ih11-models-O2-v2'];files={}
for root in roots:
 for f in sorted((w/root).rglob('*')):
  assert not f.is_symlink()
  if f.is_file():files['actual/'+f.relative_to(w).as_posix()]=f
extras=['IMPLICIT_HYDRAULIC_STATE11_LOCAL_SCIENCE_V1.json','IMPLICIT_HYDRAULIC_STATE11_LOCAL_SCIENCE_V2.json','IMPLICIT_HYDRAULIC_STATE11_PARENT_NATIVE_CONTROLLER_V1.json','IMPLICIT_HYDRAULIC_STATE11_PARENT_NATIVE_CONTROLLER_V2.json','implicit-hydraulic-state11-real-parent-native-controls-v1.py','implicit-hydraulic-state11-real-parent-native-controls-v2.py','implicit-hydraulic-state11-models-dispatch-v1.py','implicit-hydraulic-state11-models-dispatch-v2.py',Path(__file__).name,'IH11_GUARD_FINISHED_RESOURCE_RELEASE_V1.json','IH11_GUARD_FINISHED_CLEANUP_V1.json']
for n in extras:files['controller-and-observer/'+n]=e/n
members={};sources={};target=e/(name+'.zip');assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def add(n,b):
  assert n not in members;z.writestr(n,b);members[n]=dict(bytes=len(b),sha256=sha(b))
 for n,f in files.items():add(n,f.read_bytes())
 print('Preserved actual raw and compiler members',len(members),flush=True)
 for revision in sorted({head,*[q['actual_producer_source'] for q in science['contexts']]}):
  commit=git('cat-file','commit',revision);assert hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==revision
  add('actual-source/'+revision+'/commit.bin',commit)
  archive=git('archive','--format=zip',revision,'app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','reference/swap-4.3.1/hydraulic-corrections')
  add('actual-source/'+revision+'/source.zip',archive);tree={line.split(b'\t',1)[1].decode():line.split()[2].decode() for line in git('ls-tree','-r',revision).splitlines()};inventory={}
  with zipfile.ZipFile(io.BytesIO(archive)) as source:
   for info in source.infolist():
    if info.is_dir():continue
    value=source.read(info.filename);blob=hashlib.sha1(b'blob '+str(len(value)).encode()+b'\0'+value).hexdigest();assert blob==tree[info.filename];inventory[info.filename]=dict(bytes=len(value),sha256=sha(value),git_blob=blob)
  sources[revision]=dict(actual_commit_bytes_sha256=sha(commit),actual_source_zip_sha256=sha(archive),members=inventory)
  print('Preserved genuine complete source and Git bytes',revision,len(inventory),flush=True)
 add('actual-source/INVENTORY.json',(json.dumps(sources,indent=2)+'\n').encode())
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 for n,item in members.items():
  value=z.read(n);assert len(value)==item['bytes'] and sha(value)==item['sha256']
raw=target.read_bytes();parts=[];archive=name+'.zip'
for i,at in enumerate(range(0,len(raw),20_000_000),1):
 value=raw[at:at+20_000_000];n=archive if len(raw)<=20_000_000 else archive+f'.part{i:03d}';out=p/n;assert not out.exists();out.write_bytes(value);parts.append(dict(file=n,bytes=len(value),sha256=sha(value)))
q=dict(status='ACTUAL_EIGHTEEN_LOCAL_IMPLICIT_HYDRAULIC_STATE_CONTEXTS_AND_ALL_ORIGINAL_REFUSALS_COMPILER_RAW_PRESERVED_NOT_CANONICALLY_ADMITTED',archive=archive,bytes=len(raw),sha256=sha(raw),parts=parts,members=members,actual_preservation_source=head,actual_observer_source=science['actual_observer_source'],actual_scientific_sources=sorted({v['actual_producer_source'] for v in science['contexts']}),original_provider_dependency=provider,actual_compiler_sha256=sha(compiler.read_bytes()),scientific_totals={k:science[k] for k in ['primary_days','native_samples','exact_cold_windows','external_transaction_contexts']},failed_original_inputs_and_reader_guard_attempts_preserved=True,old_model_periods_replayed_for_metadata=False,canonical_admission=False,portable_qualification=False)
(p/(name+'.json')).write_text(json.dumps(q,indent=2)+'\n');(p/'IMPLICIT_HYDRAULIC_STATE11_LOCAL_SCIENCE_V2.json').write_bytes((e/'IMPLICIT_HYDRAULIC_STATE11_LOCAL_SCIENCE_V2.json').read_bytes());(e/'IMPLICIT_HYDRAULIC_STATE11_LOCAL_PRESERVATION_V1.json').write_text(json.dumps(dict(status='RAW_FULL_CRC_INVENTORY_MEMBER_SHA_AND_GENUINE_SOURCE_GIT_BYTES_VERIFIED',archive=archive,bytes=len(raw),sha256=q['sha256'],members=len(members),parts=parts,actual_source=head),indent=2)+'\n');print('RAW_LOCAL_PRESERVED',len(raw),sha(raw),len(members),flush=True)
