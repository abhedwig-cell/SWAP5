import hashlib,io,json,subprocess,zipfile
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');W=Path('C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600');E=W/'evidence';P=R/'integration/f-ci/nomacro-complete01'
NAME='IMPLICIT_HYDRAULIC_STATE11_PARENT824_POSTIMAGE_RAW_V1'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='72d43eaaa4ff832227f4943bffd30061376fa00d'
roots=['ih11-parent-postimages-v1','ih11-parent-postimages-O0-v1','ih11-parent-postimages-O2-v1']
files={}
for root in roots:
 assert (W/root).is_dir(),root
 for f in sorted((W/root).rglob('*')):
  assert not f.is_symlink()
  if f.is_file():files['actual/'+f.relative_to(W).as_posix()]=f
prefixes=[]
exact=['IMPLICIT_HYDRAULIC_STATE11_UBUNTU_OBSERVER_O0_ORIGINAL.zip','IMPLICIT_HYDRAULIC_STATE11_UBUNTU_OBSERVER_O2_ORIGINAL.zip','IMPLICIT_HYDRAULIC_STATE11_UBUNTU_OBSERVER_TERMINAL_RUNS_API_V1.json','IMPLICIT_HYDRAULIC_STATE11_UBUNTU_OBSERVER_TERMINAL_JOBS_API_V1.json','IMPLICIT_HYDRAULIC_STATE11_UBUNTU_OBSERVER_OFFICIAL_ARTIFACTS_API_V1.json','IMPLICIT_HYDRAULIC_STATE11_UBUNTU_OBSERVER_INDEPENDENT_IDENTITY_EQUALITY_V1.json','IMPLICIT_HYDRAULIC_STATE11_CURRENT_SOURCE_CONTRACT_V9.json',Path(__file__).name]
for entry in E.iterdir():
 if entry.name in exact or any(entry.name.startswith(v) for v in prefixes):
  if entry.is_file():files['observer-and-diagnostics/'+entry.name]=entry
  elif entry.is_dir():
   for f in sorted(entry.rglob('*')):
    assert not f.is_symlink()
    if f.is_file():files['observer-and-diagnostics/'+f.relative_to(E).as_posix()]=f
provider=json.loads((P/'IMPLICIT_HYDRAULIC_STATE11_GUARD_RAW_V1.json').read_text())['original_provider_dependency'];J=Path('C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider')
for member,item in provider['actual_required_files'].items():
 f=J/'build'/member.removeprefix('original-provider-build/');raw=f.read_bytes();assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
compiler=Path('C:/msys64/ucrt64/bin/gfortran.exe');assert sha(compiler.read_bytes())=='d818d364c3f0a422fc195f80539554d4ea38fdcd719046771233dbac294bc371'
members={};target=E/(NAME+'.zip');sources={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def add(n,raw):
  assert n not in members;z.writestr(n,raw);members[n]=dict(bytes=len(raw),sha256=sha(raw))
 for n,f in files.items():
  raw=f.read_bytes();add(n,raw);assert sha(f.read_bytes())==members[n]['sha256'],str(f)
 print('Actual raw members',len(members),flush=True)
 for revision in [head]:
  commit=git('cat-file','commit',revision);assert hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==revision;add('actual-source/'+revision+'/commit.bin',commit)
  archive=git('archive','--format=zip',revision,'app','src','tools/solute','tools/vq','tests/nomacro_drainage','tests/nomacro_scheduled_subsurface','reference/swap-4.3.1/hydraulic-corrections');add('actual-source/'+revision+'/source.zip',archive)
  tree={line.split(b'\t',1)[1].decode():line.split()[2].decode() for line in git('ls-tree','-r',revision).splitlines()};inventory={}
  with zipfile.ZipFile(io.BytesIO(archive)) as source:
   infos=[info for info in source.infolist() if not info.is_dir()];oids=[tree[info.filename] for info in infos];batch=subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=('\n'.join(oids)+'\n').encode());cursor=0
   for info,oid in zip(infos,oids):
    stop=batch.index(b'\n',cursor);identity,kind,extent=batch[cursor:stop].split();extent=int(extent);raw=batch[stop+1:stop+1+extent];cursor=stop+2+extent
    assert identity.decode()==oid and kind==b'blob' and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
    exported=source.read(info.filename);assert exported==raw or exported.replace(b'\r\n',b'\n')==raw.replace(b'\r\n',b'\n')
    n='actual-source/git-blobs/'+oid+'.bin'
    if n not in members:add(n,raw)
    inventory[info.filename]=dict(git_blob=oid,actual_git_blob_member=n,actual_git_blob_sha256=sha(raw),exported_sha256=sha(exported),exported_bytes=len(exported),actual_git_blob_bytes=len(raw),export_endings_differ=exported!=raw)
   assert cursor==len(batch)
  sources[revision]=dict(actual_commit_sha256=sha(commit),source_zip_sha256=sha(archive),members=inventory)
  print('Genuine source',revision,len(inventory),flush=True)
 add('actual-source/INVENTORY.json',(json.dumps(sources,indent=2)+'\n').encode())
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 for n,item in members.items():
  raw=z.read(n);assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
raw=target.read_bytes();parts=[]
for i,at in enumerate(range(0,len(raw),20_000_000),1):
 value=raw[at:at+20_000_000];name=NAME+'.zip' if len(raw)<=20_000_000 else NAME+'.zip.part'+str(i).zfill(3);part=E/name;assert not part.exists();part.write_bytes(value);parts.append(dict(file=name,bytes=len(value),sha256=sha(value)))
q=dict(status='ACTUAL16_ORIGINAL_PARENT_COMPILER_CONTEXTS_398_WHOLE_OBJECTS_AND_TWO_READ_ONLY_LINUX_OBSERVERS_RAW_FULL_CRC_MEMBER_SHA_SOURCE_VERIFIED_NOT_ADMITTED',archive=NAME+'.zip',bytes=len(raw),sha256=sha(raw),parts=parts,members=members,actual_preservation_source=head,actual_scientific_sources=list(sources),original_provider_dependency=provider,actual_compiler_sha256=sha(compiler.read_bytes()),roots=roots,old_model_periods_replayed=False,original_source_and_exported_bytes_both_retained=True,canonical_admission=False,portable_qualification=False,model_executions_for_sealing=0)
(E/(NAME+'.json')).write_text(json.dumps(q,indent=2)+'\n');print('SEALED',len(raw),sha(raw),len(members),flush=True)
