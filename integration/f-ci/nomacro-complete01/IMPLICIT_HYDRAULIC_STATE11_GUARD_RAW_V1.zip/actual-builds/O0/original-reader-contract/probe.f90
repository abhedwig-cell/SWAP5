program original_initialization_probe
use iso_fortran_env, only: output_unit
use MOD_swap_base, only: swap_configuration, sw_animo, sw_multi_swap, swhea, swdra, swsnow, swsolu
use atmosphere_interface, only: tav
use MOD_meteo, only: meteo, peva, empreva, epond
use MOD_MvG, only: fill_cofgen
use MOD_SoilWater, only: soilwater
use MOD_gwl, only: calcgwl
use MOD_SoilTemperature, only: SoilTemperature, tsoil
use MOD_snow, only: snow
use MOD_solute, only: solute
implicit none
sw_animo=1
call mark('BEFORE_INITIALIZE')
call Initialize
call IterTime(1)
call mark('BEFORE_CONFIGURATION')
call swap_configuration()
call mark('BEFORE_READSWAP')
call ReadSwap
call mark('AFTER_READSWAP_ZERO_MODEL_DAYS')
contains
subroutine mark(text)
character(len=*),intent(in)::text
write(output_unit,'(a)')'ORIGINAL_INIT_PHASE '//text
flush(output_unit)
end subroutine
end program
