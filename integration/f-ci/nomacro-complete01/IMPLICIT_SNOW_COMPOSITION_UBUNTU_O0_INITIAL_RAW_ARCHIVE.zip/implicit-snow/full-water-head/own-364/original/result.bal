* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 12:06:09

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        42.67 cm
Initial :        75.19 cm
            =============
Change          -32.52 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.80    Interception      :     4.32
Runon          :     0.00    Runoff            :    40.97
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    21.30
Bottom flux    :   -68.22    Soil evaporation  :     6.14
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    14.98    Sum               :    72.72
