subroutine hybrid_original_output_initial_emit()
use variables,only:volact,pond
use MOD_snow,only:ssnow
use plant_interface,only:sicact
implicit none
write(*,'(a,12(1x,es25.17e3))')'HYBRID_STOCK_FLUX', &
 volact,pond,ssnow,sicact,0d0,0d0,volact,pond,ssnow,sicact,0d0,0d0
end subroutine
subroutine hybrid_age_output_day_emit()
use iso_fortran_env,only:int64
use hybrid_cde_interval_receipt,only:cde_day_close,cde_day_diagnostics,CDE_DAY_OK
use MOD_solute,only:sampro,sdstor,imsqprec,imsqirrig,imsqbot,imsqdra,imdectot,imrottot,sbaldev
use MOD_integral,only:iptra,iqrot,iqreddry,iqredwet,iqredsol,iqredfrs
use hybrid_age_output_state
use variables,only:volact,pond,daycum,t1900
use MOD_snow,only:ssnow
use plant_interface,only:sicact
implicit none
real(8)::stocks(12),flow(16)
real(8)::cde_daily(9),cde_initial,cde_flow(6)
integer(int64)::cde_counts(6)
logical::cde_live
integer::status
call finish_output_receipt(hybrid_output_frame,[volact,pond,ssnow,sicact,0d0,0d0],stocks,flow,status)
if(status/=OUTPUT_RECEIPT_OK)error stop 'Original output daily frame finish rejected'
write(*,'(a,12(1x,es25.17e3))')'HYBRID_STOCK_FLUX',stocks
write(*,'(a,16(1x,es25.17e3))')'HYBRID_EXTERNAL_FLUX',flow
call cde_day_close(sampro,cde_daily,status)
if(status/=CDE_DAY_OK)error stop 'Actual CDE independent daily mass receipt rejected'
call cde_day_diagnostics(cde_initial,cde_flow,cde_counts,cde_live)
if(cde_live)error stop 'Unclosed actual CDE daily receipt'
write(*,'(a,9(1x,es25.17e3))')'HYBRID_SOLUTE_LEDGER',cde_daily
write(*,'(a,17(1x,es25.17e3))')'CDE_INTERVAL_DAILY_AUDIT', &
 cde_initial,sampro,cde_flow,cde_daily(9),sdstor,imsqprec,imsqirrig,imsqbot,imsqdra,imdectot,imrottot,sbaldev
write(*,'(a,6(1x,i0))')'CDE_INTERVAL_INCREMENT_COUNTS',cde_counts
write(*,'(a,6(1x,es25.17e3))')'HYBRID_UPTAKE',iptra,iqrot,iqreddry,iqredwet,iqredsol,iqredfrs
write(*,'(a,1x,i0,1x,es25.17e3)')'ORIGINAL_DAILY_RECEIPT',daycum,t1900
end subroutine
