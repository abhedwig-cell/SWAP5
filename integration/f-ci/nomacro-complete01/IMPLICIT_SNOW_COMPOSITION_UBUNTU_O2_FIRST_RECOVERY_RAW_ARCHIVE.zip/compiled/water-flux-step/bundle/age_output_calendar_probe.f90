subroutine hybrid_original_output_initial_emit()
use variables,only:volact,pond
use MOD_snow,only:ssnow
use plant_interface,only:sicact
implicit none
write(*,'(a,12(1x,es25.17e3))')'HYBRID_STOCK_FLUX', &
 volact,pond,ssnow,sicact,0d0,0d0,volact,pond,ssnow,sicact,0d0,0d0
end subroutine
subroutine hybrid_age_output_day_emit()
use iso_fortran_env,only:real128
use ieee_arithmetic,only:ieee_is_finite
use hybrid_age_output_state
use variables,only:volact,pond,daycum,t1900
use MOD_snow,only:ssnow
use plant_interface,only:sicact
implicit none
real(8)::stocks(12),flow(16)
real(8)::soil_stocks(12),soil_flow(16),soil_terms(28),soil_residual
integer::status
call finish_output_receipt(hybrid_output_frame,[volact,pond,ssnow,sicact,0d0,0d0],stocks,flow,status)
if(status/=OUTPUT_RECEIPT_OK)error stop 'Original output daily frame finish rejected'
write(*,'(a,12(1x,es25.17e3))')'HYBRID_STOCK_FLUX',stocks
write(*,'(a,16(1x,es25.17e3))')'HYBRID_EXTERNAL_FLUX',flow
call finish_output_receipt(hybrid_soil_output_frame,[volact,pond,0d0,0d0,0d0,0d0],soil_stocks,soil_flow,status)
if(status/=OUTPUT_RECEIPT_OK)error stop 'Original Snow soil frame finish rejected'
soil_terms=[soil_flow(1:7),-soil_flow(8:16),soil_stocks(7:12),-soil_stocks(1:6)]
soil_residual=real(sum(real(soil_terms,real128)),8)
if(.not.ieee_is_finite(soil_residual).or.abs(soil_residual)>1d-10)error stop 'Original Snow soil day guard exceeded'
write(*,'(a,29(1x,es25.17e3))')'HYBRID_SNOW_SOIL_RECEIPT',soil_stocks,soil_flow,soil_residual
write(*,'(a,1x,i0,1x,es25.17e3)')'ORIGINAL_DAILY_RECEIPT',daycum,t1900
end subroutine
