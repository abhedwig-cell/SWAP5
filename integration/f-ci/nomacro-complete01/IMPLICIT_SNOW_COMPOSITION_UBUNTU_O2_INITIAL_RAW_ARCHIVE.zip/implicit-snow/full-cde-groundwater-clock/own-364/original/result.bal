* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 12:08:47

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.82 cm       0.7774E-01 mg/cm2
Initial :        73.20 cm       0.0000E+00 mg/cm2
            =============       =================
Change            1.61 cm       0.7774E-01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    34.30
Bottom flux    :   -67.99    Soil evaporation  :     0.19
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :    18.59    Sum               :    38.97


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.7871E-01
                             Drainage       :  0.9719E-03
=========================    ============================
Sum         :  0.7871E-01    Sum            :  0.9719E-03

