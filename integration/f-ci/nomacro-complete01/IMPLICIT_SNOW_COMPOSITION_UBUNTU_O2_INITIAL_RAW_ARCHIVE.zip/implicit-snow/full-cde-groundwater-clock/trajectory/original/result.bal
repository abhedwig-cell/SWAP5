* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 12:08:16

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.82 cm       0.7774E-01 mg/cm2
Initial :        95.20 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -20.39 cm       0.7774E-01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    34.30
Bottom flux    :   -67.99    Soil evaporation  :     0.19
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :    18.59    Sum               :    38.97


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.7871E-01
                             Drainage       :  0.9719E-03
=========================    ============================
Sum         :  0.7871E-01    Sum            :  0.9719E-03


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        73.95 cm       0.1006E+00 mg/cm2
Initial :        74.82 cm       0.7774E-01 mg/cm2
            =============       =================
Change           -0.86 cm       0.2289E-01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     6.41
Runon          :     0.00    Runoff            :     1.21
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    19.19
Bottom flux    :   -44.19    Soil evaporation  :     1.84
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    27.79    Sum               :    28.66


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.2289E-01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.2289E-01    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        73.91 cm       0.7370E-01 mg/cm2
Initial :        73.95 cm       0.1006E+00 mg/cm2
            =============       =================
Change           -0.04 cm      -0.2693E-01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :    11.51
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -36.85    Soil evaporation  :     0.06
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    43.70    Sum               :    43.73


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.2693E-01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.2693E-01    Sum            :  0.0000E+00

