* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 12:13:32

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        42.33 cm       0.2935E-06 mg/cm2
Initial :        72.37 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -30.04 cm       0.2935E-06 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :    41.50
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    18.85
Bottom flux    :   -67.26    Soil evaporation  :     6.80
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    19.32    Sum               :    71.36


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.2935E-06
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.2935E-06    Sum            :  0.0000E+00

