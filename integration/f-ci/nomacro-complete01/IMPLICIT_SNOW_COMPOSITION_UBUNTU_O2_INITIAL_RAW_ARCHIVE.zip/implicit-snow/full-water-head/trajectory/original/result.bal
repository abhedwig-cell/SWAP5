* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 12:07:51

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        42.67 cm
Initial :        97.19 cm
            =============
Change          -54.52 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.32
Runon          :     0.00    Runoff            :    40.97
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    21.30
Bottom flux    :   -68.22    Soil evaporation  :     6.30
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    18.36    Sum               :    72.88

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        42.50 cm
Initial :        42.67 cm
            =============
Change           -0.17 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     0.12
Runon          :     0.00    Runoff            :    46.77
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -0.00    Soil evaporation  :    25.25
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    71.98    Sum               :    72.15

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        42.55 cm
Initial :        42.50 cm
            =============
Change            0.05 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :     0.93
Runon          :     0.00    Runoff            :    49.69
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -0.00    Soil evaporation  :    29.88
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    80.55    Sum               :    80.50
