"""Record actual final candidate/canonical publication selection and clean HEAD."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--cwd',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
def git(*args):return subprocess.check_output(['git',*args],cwd=a.cwd,text=True).strip()
def snapshot():
 sparse=Path(git('rev-parse','--git-path','info/sparse-checkout'))
 if not sparse.is_absolute():sparse=a.cwd/sparse
 return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all','--ignored'),sparse=sparse.read_text().splitlines())
before=snapshot();assert before['status']=='' and len(before['sparse'])==44
command=[sys.executable,'-B','tests/nomacro_drainage/frost_publication_scope.py'];q=dict(status='RUNNING',command=command,before=before,compiler_executions=0,model_executions=0,read_only_observer_timeout_seconds=14400);started=time.perf_counter()
try:
 result=subprocess.run(command,cwd=a.cwd,env=dict(os.environ,GITHUB_EVENT_NAME='pull_request'),capture_output=True,text=True,timeout=14400);q.update(status='ACTUAL_PUBLICATION_COMMAND_RETURNED',returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
except subprocess.TimeoutExpired as error:q.update(status='READ_ONLY_OBSERVER_TIMEOUT_NOT_A_SCIENTIFIC_REFUSAL',returncode=None,error=repr(error))
finally:
 q.update(seconds=time.perf_counter()-started,after=snapshot());q['actual_checkout_unchanged']=q['before']==q['after']
 with a.output.open('x',encoding='utf8') as out:json.dump(q,out,indent=2);out.write('\n')
assert q['actual_checkout_unchanged'] and q['returncode']==0 and not q['stderr'] and 'PUBLICATION_REPLAY_SELECTED=false' in q['stdout']
print('ACTUAL_CLEAN44_PUBLICATION_FALSE_PASS',q['seconds'],q['before']['head'],flush=True)
