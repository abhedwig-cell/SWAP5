"""Prepare the actual merge in the existing idle negative baseline, preserving inputs."""
import hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;N=Path('C:/Users/Veldh012/swap5-groundwater-composition-negative01')
HEAD='8ae1661391ed35125421290de3fb5d95ec8cd5b5';BASE='84e815a0ba9f59a2d56fe838a3b13361ad8670a2';TREE='b3c78d4bd0c5b583bd8046e339bbe3bb3eb45371'
git=lambda *args:subprocess.check_output(['git',*args],cwd=N,text=True).strip()
merge=json.loads((E/'INITIAL_PROFILE_AGE_GROUNDWATER_PR1788_ACTUAL_MERGE_API_V1.json').read_text());assert merge['merged'];canonical=merge['sha']
for label in ('INITIAL_PROFILE_AGE_GROUNDWATER_FINAL_CANDIDATE_PUBLIC_OWNER_V2','INITIAL_PROFILE_AGE_GROUNDWATER_FINAL_PUBLICATION_SCOPE_POSITIVE_V1'):
 q=json.loads((E/(label+'.json')).read_text());assert q['returncode']==0 and q['before']==q['after'] and q['before']['head']==HEAD and not q['before']['status']
negative=json.loads((E/'INITIAL_PROFILE_AGE_GROUNDWATER_FINAL_NEGATIVES_OBSERVE_V1.json').read_text());assert negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN44_PUBLIC_NEGATIVES_REFUSED'
assert not git('status','--porcelain=v1','--ignored','--untracked-files=all');before=git('rev-parse','HEAD')
assert before==next(x['head'] for x in negative['controls'] if x['role']=='PUBLICATION')
prepared=json.loads((E/'INITIAL_PROFILE_AGE_GROUNDWATER_CLEAN44_CANDIDATE_PREPARATION_V1.json').read_text());record=next(x for x in prepared['records'] if Path(x['checkout'])==N);expected=record['preserved_input_bytes'];assert len(expected)==33
raw={name:(N/name).read_bytes() for name in expected}
for name,value in raw.items():assert hashlib.sha256(value).hexdigest()==expected[name]
subprocess.run(['git','fetch','--no-tags','origin',canonical],cwd=N,check=True)
assert git('show','-s','--format=%P',canonical).split()==[BASE,HEAD] and git('rev-parse',canonical+'^{tree}')==TREE
assert not git('diff','--name-only',before,canonical,'--',*expected),'Actual merge changes preserved scientific input trees'
sparse=Path(git('rev-parse','--git-path','info/sparse-checkout'))
if not sparse.is_absolute():sparse=N/sparse
patterns=sparse.read_bytes();assert len(patterns.splitlines())==44
subprocess.run(['git','switch','--detach',canonical],cwd=N,check=True)
assert git('rev-parse','HEAD')==canonical and git('rev-parse','HEAD^{tree}')==TREE and not git('status','--porcelain=v1','--ignored','--untracked-files=all') and sparse.read_bytes()==patterns
for name,value in raw.items():assert (N/name).read_bytes()==value
q=dict(status='ACTUAL_CANONICAL_ORDERED_PARENTS_FULL_TREE_CLEAN44_ALL33_INPUT_BYTES_PRESERVED',before=before,canonical=canonical,tree=TREE,patterns=44,preserved_input_bytes=expected,actual_scientific_input_files_rewritten=False)
with (E/'INITIAL_PROFILE_AGE_GROUNDWATER_ACTUAL_CANONICAL_CLEAN44_PREPARATION_V1.json').open('x') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['status'],canonical)
