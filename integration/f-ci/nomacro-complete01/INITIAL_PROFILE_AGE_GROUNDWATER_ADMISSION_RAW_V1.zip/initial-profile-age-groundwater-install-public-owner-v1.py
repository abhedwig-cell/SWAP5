"""Install the prepared AGE owner only after actual Frost canonical admission."""
import ast,hashlib,json,subprocess,sys
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;P=R/'integration/f-ci/nomacro-complete01'
git=lambda *args:subprocess.check_output(['git',*args],cwd=R).decode().strip()
BASE='06e980f4bb17e43e4cc61cf4fc2d6ea17204526d';CANONICAL='84e815a0ba9f59a2d56fe838a3b13361ad8670a2'
receipt=json.loads((P/'INITIAL_PROFILE_FROST_MERGE_RECEIPT_V1.json').read_text());archive=json.loads((P/'INITIAL_PROFILE_FROST_ADMISSION_RAW_V1.json').read_text())
assert receipt['status']=='ACTUAL_CANONICAL_86CONTEXT_PRESSURE_CALENDAR_FROST_ADMISSION_VERIFIED' and receipt['actual_merge']==CANONICAL and receipt['qualified_head']==BASE and receipt['canonical_admission'] is True
assert archive['canonical']==CANONICAL and archive['candidate']==BASE and archive['canonical_admission'] is True and archive['sha256']==receipt['admission_archive_sha256']
assert hashlib.sha256((P/archive['archive']).read_bytes()).hexdigest()==archive['sha256']
assert git('branch','--show-current')=='codex/nomacro-initial-profile-age-groundwater01' and not git('status','--porcelain=v1','--untracked-files=all','--ignored'),'Freeze a clean actual source/admission commit first'
sealed=git('rev-parse','HEAD');assert len(sealed)==40
template=(E/'initial-profile-age-groundwater-verify-template-v1.py').read_text();assert template.count('PENDING_ACTUAL_FROZEN_AGE_SCIENCE_SOURCE')==1 and 'PENDING_ACTUAL_FROST_ADMISSION_ARCHIVE_SHA256' not in template
template=template.replace('PENDING_ACTUAL_FROZEN_AGE_SCIENCE_SOURCE',sealed).replace('PENDING_ACTUAL_FROST_ADMISSION_ARCHIVE_SHA256',archive['sha256']);ast.parse(template)
# Do not execute the module while constructing it. Its constant declarations
# provide the exact four delegation strings reviewed in the prepared source.
tree=ast.parse(template);constants={}
for node in tree.body:
 if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and isinstance(node.value,ast.Constant):constants[node.targets[0].id]=node.value.value
old='tests/nomacro_drainage/initial_profile_frost_verify.py';raw=(R/old).read_bytes().replace(b'\r\n',b'\n');assert raw==subprocess.check_output(['git','show',BASE+':'+old],cwd=R)
text=raw.decode()
for name,key in [('guard_previous_source','GUARD_HOOK'),('verify','VERIFY_HOOK'),('strip_current_evidence','STRIP_HOOK'),('publication_dependencies_unchanged','PUBLICATION_HOOK')]:
 node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name);lines=text.splitlines(keepends=True);lines.insert(node.body[0].lineno-1,constants[key]);text=''.join(lines)
restored=text
for key in ('GUARD_HOOK','VERIFY_HOOK','STRIP_HOOK','PUBLICATION_HOOK'):assert restored.count(constants[key])==1;restored=restored.replace(constants[key],'',1)
assert restored.encode()==raw
pattern='            /integration/f-ci/nomacro-complete01/INITIAL_PROFILE_*\n';prior='            /integration/f-ci/nomacro-complete01/INITIAL_PROFILE_FROST*\n';ci={}
for path in ('.github/workflows/mc-sol01-column-input.yml','.github/workflows/mc-sol01-swp-reader.yml'):
 current=(R/path).read_bytes().replace(b'\r\n',b'\n').decode();assert current.count(prior)==1 and pattern not in current;ci[path]=current.replace(prior,prior+pattern,1)
# All preconditions complete before these repository writes.
(R/'tests/nomacro_drainage/initial_profile_age_groundwater_verify.py').write_text(template)
(R/old).write_text(text)
for path,current in ci.items():(R/path).write_text(current)
q=dict(status='AGE_GROUNDWATER_OWNER_INSTALLED_AFTER_ACTUAL_FROST_CANONICAL_ADMISSION_PENDING_FRESH_FINAL_HEAD_GATES',actual_frozen_science_source=sealed,actual_parent_canonical=CANONICAL,actual_parent_admission_sha256=archive['sha256'],old_scientific_body_restored_byte_exact=True,new_source_prefix_count=1,compiler_executions=0,model_executions=0,canonical_admission=False)
(E/'INITIAL_PROFILE_AGE_GROUNDWATER_PUBLIC_OWNER_INSTALLATION_V1.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],sealed)
