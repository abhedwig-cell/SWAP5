"""Commit and push four real one-path negative heads from the final candidate."""
import argparse,json,os,pathlib,subprocess,sys,traceback
E=pathlib.Path(__file__).parent
N=pathlib.Path('C:/Users/Veldh012/swap5-groundwater-composition-negative01')
p=argparse.ArgumentParser();p.add_argument('--head',required=True);a=p.parse_args();HEAD=a.head;assert len(HEAD)==40 and all(c in '0123456789abcdef' for c in HEAD)
git=lambda *args:subprocess.check_output(['git',*args],cwd=N,text=True).strip()
assert git('status','--porcelain=v1','--untracked-files=all','--ignored')=='' and len(git('sparse-checkout','list').splitlines())==44
assert git('merge-base','--is-ancestor','84e815a0ba9f59a2d56fe838a3b13361ad8670a2',HEAD)==''
cases=[('SOURCE','app/hybrid_water/initial_profile_age.py'),('RAW','integration/f-ci/nomacro-complete01/INITIAL_PROFILE_AGE_WINDOWS_RAW_V1.zip'),('INHERITED','integration/f-ci/nomacro-complete01/INITIAL_PROFILE_FROST_ADMISSION_RAW_V1.zip'),('PUBLICATION','tests/publication/run_pub_p2e09_reference_threshold_freeze.sh')]
q=dict(status='RUNNING',candidate=HEAD,controls=[],compiler_executions=0,model_executions=0,never_merge=True)
def save():(E/'INITIAL_PROFILE_AGE_FINAL_NEGATIVES_OBSERVE_V1.json').write_text(json.dumps(q,indent=2)+'\n')
save()
try:
 for role,path in cases:
  branch='codex/nomacro-initial-profile-age-'+role.lower()+'-negative01';git('switch','-c',branch,HEAD);assert git('rev-parse','HEAD')==HEAD and git('status','--porcelain=v1','--untracked-files=all','--ignored')==''
  target=N/path
  with target.open('ab') as f:f.write(b'\x00' if role in ('RAW','INHERITED') else b'\n# Actual committed pressure AGE negative control; never merge.\n')
  git('add','--',path);git('commit','-m','Actual '+role+' negative control for original pressure AGE; never merge');head=git('rev-parse','HEAD');assert git('show','-s','--format=%P',head)==HEAD and git('diff','--name-only',HEAD,head)==path
  subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],cwd=N,capture_output=True,text=True,check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==head
  if role=='PUBLICATION':
   result=subprocess.run([sys.executable,'-B','tests/nomacro_drainage/frost_publication_scope.py'],cwd=N,env=dict(os.environ,GITHUB_EVENT_NAME='pull_request'),capture_output=True,text=True,timeout=7200);(E/'INITIAL_PROFILE_AGE_FINAL_PUBLICATION_SCOPE_NEGATIVE_V1.txt').write_text(result.stdout+result.stderr);assert result.returncode==0 and 'PUBLICATION_REPLAY_SELECTED=true' in result.stdout
  output=E/('INITIAL_PROFILE_AGE_FINAL_'+role+'_NEGATIVE_PUBLIC_V1');r=subprocess.run([sys.executable,'-B',str(E/'INITIAL_PROFILE_AGE_PUBLIC_OBSERVE_V1.py'),'--cwd',str(N),'--output',str(output)],capture_output=True,text=True,check=True)
  actual=json.loads(output.with_suffix('.json').read_text());assert actual['status']=='ACTUAL_PUBLIC_COMMAND_RETURNED' and isinstance(actual['returncode'],int) and actual['returncode']!=0 and actual['before']==actual['after'] and actual['before']['head']==head and actual['compiler_executions']==actual['model_executions']==0
  assert 'AssertionError' in output.with_suffix('.stderr.txt').read_text()
  q['controls'].append(dict(role=role,branch=branch,head=head,path=path,public_returncode=actual['returncode'],seconds=actual['seconds'],actual_refusal=True));save();print(role,head,actual['seconds'],'REFUSED',flush=True)
 q['status']='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN44_PUBLIC_NEGATIVES_REFUSED'
except Exception as error:q.update(status='FAILED',error=repr(error),traceback=traceback.format_exc());raise
finally:save()
