"""Own pressure/AGE composition and retain every literal admitted Frost proof."""
import ast,json,sys
from contextlib import ExitStack
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'tests/nomacro_drainage'),str(ROOT/'tests/nomacro_scheduled_subsurface'),str(ROOT/'app/hybrid_water')]
from analytical_hydraulic_archives import Archive
from initial_profile_age_source_inverse import BASE,CORE,complete_inverse,git,blob,norm
from initial_profile_age_parent_projection import CI,PATTERN,frost_parent_complete_inverse,prior_source_projection
from initial_profile_age_central_science import read
import initial_profile_frost_verify as previous
PROOF=ROOT/'integration/f-ci/nomacro-complete01'
OLD='tests/nomacro_drainage/initial_profile_frost_verify.py'
SEALED='PENDING_ACTUAL_FROZEN_AGE_SCIENCE_SOURCE'
PREVIOUS_CANONICAL='84e815a0ba9f59a2d56fe838a3b13361ad8670a2'
PARENT_ADMISSION_SHA='PENDING_ACTUAL_FROST_ADMISSION_ARCHIVE_SHA256'
GUARD_HOOK=' import initial_profile_age_verify as age_owner\n return age_owner.guard_previous_source()\n'
VERIFY_HOOK=' import initial_profile_age_verify as age_owner\n return age_owner.verify()\n'
STRIP_HOOK=' import initial_profile_age_verify as age_owner\n return age_owner.strip_current_evidence(text)\n'
PUBLICATION_HOOK=' import initial_profile_age_verify as age_owner\n return age_owner.publication_dependencies_unchanged()\n'
PARSERS=tuple('initial_profile_age_'+name+'.py' for name in ('source_inverse','parent_projection','science','central_science','ledger','runtime','discovery','postimage','frontend','inputs','preserve'))+('initial_profile_frost_admission_seal.py',)
RAW_NAMES=tuple('INITIAL_PROFILE_AGE_'+suffix+'_RAW_V1' for suffix in ('WINDOWS','UBUNTU_O0','UBUNTU_O2'))


def literal(name,namespace):
 nodes=[n for n in ast.parse(blob(BASE,OLD)).body if isinstance(n,ast.FunctionDef) and n.name==name];assert len(nodes)==1
 exec(compile(ast.Module(body=nodes,type_ignores=[]),OLD,'exec'),namespace);return namespace[name]


def prior_namespace():
 namespace=dict(vars(previous),complete_inverse=frost_parent_complete_inverse);literal('guard_previous_source',namespace);return namespace


def guard_previous_source():
 complete_inverse();frost_parent_complete_inverse()
 for name in PARSERS:
  path='tests/nomacro_drainage/'+name;assert norm((ROOT/path).read_bytes())==blob(SEALED,path),'Frozen pressure/AGE observer changed'
 raw=norm((ROOT/OLD).read_bytes()).decode()
 for hook in (GUARD_HOOK,VERIFY_HOOK,STRIP_HOOK,PUBLICATION_HOOK):assert raw.count(hook)==1;raw=raw.replace(hook,'',1)
 assert raw.encode()==blob(BASE,OLD),'Previous Frost scientific body changed beyond exact delegation'
 existing=set(git('ls-tree','-r','--name-only',BASE,'--','tests').decode().splitlines());changed=set(git('diff','--name-only',BASE,'--','tests').decode().splitlines())&existing
 assert changed=={OLD,'tests/nomacro_drainage/initial_profile_age_discovery.py','tests/nomacro_drainage/initial_profile_age_runtime.py','tests/nomacro_drainage/initial_profile_frost_admission_seal.py'},changed
 for path in CI:assert norm((ROOT/path).read_bytes()).count(PATTERN.encode())==1
 with prior_source_projection():assert literal('guard_previous_source',prior_namespace())()
 return True


def strip_current_evidence(text):
 assert text.count(PATTERN)<=1
 return literal('strip_current_evidence',dict(vars(previous)))(text.replace(PATTERN,''))


def publication_dependencies_unchanged():
 guard_previous_source()
 with prior_source_projection():return literal('publication_dependencies_unchanged',prior_namespace())()


def verify():
 guard_previous_source()
 names=['INITIAL_PROFILE_AGE_QUALIFICATION.json','INITIAL_PROFILE_AGE_CONTRACT_V2.json','INITIAL_PROFILE_AGE_CENTRAL_INDEPENDENT_V2.json',*[name+'.json' for name in RAW_NAMES],'INITIAL_PROFILE_FROST_ADMISSION_RAW_V1.json','INITIAL_PROFILE_FROST_MERGE_RECEIPT_V1.json']
 for name in names:
  path='integration/f-ci/nomacro-complete01/'+name;assert norm((ROOT/path).read_bytes())==blob(SEALED,path)
 qual=json.loads((PROOF/'INITIAL_PROFILE_AGE_QUALIFICATION.json').read_text());assert qual['runtime']==CORE and qual['contexts']==qual['compiler_postimages']==24 and qual['required_actual_parent_canonical']==PREVIOUS_CANONICAL
 for key in ('physical_process_equations_changed','original_initialization_equations_changed','new_physical_state','new_native_codec','native_interface_changed','mass_or_convergence_limits_changed','rollback_or_rejected_trial_semantics_changed','production_authority_changed','original_receipts_rewritten','explicit_positive_incoming_AGE_policy_cross_qualified','dry_surface_AGE_gap_closed','canonical_admission','whole_historical_family_closed','RC3_changed'):assert qual[key] is False
 actual=read(PROOF,RAW_NAMES);assert actual['contexts']==actual['compiler_postimages']==24 and actual['exact_cold_windows']==72 and actual['native_checkpoints']==168 and sum(actual['frontend']['counts'].values())==92
 assert actual==json.loads((PROOF/'INITIAL_PROFILE_AGE_CENTRAL_INDEPENDENT_V2.json').read_text())
 with ExitStack() as stack:
  for name in RAW_NAMES:
   store=Archive(PROOF,name,stack);assert store.record['sha256']==qual['raw_records'][name]['sha256']
  admission=Archive(PROOF,'INITIAL_PROFILE_FROST_ADMISSION_RAW_V1',stack)
  assert admission.record['candidate']==BASE and admission.record['canonical']==PREVIOUS_CANONICAL and admission.record['sha256']==PARENT_ADMISSION_SHA and admission.record['canonical_admission'] is True
  assert admission.record['phase1_and2_standalone_admission_claimed'] is False
  for name in admission.names:admission.get(name)
 receipt=json.loads((PROOF/'INITIAL_PROFILE_FROST_MERGE_RECEIPT_V1.json').read_text());assert receipt['status']=='ACTUAL_CANONICAL_86CONTEXT_PRESSURE_CALENDAR_FROST_ADMISSION_VERIFIED' and receipt['qualified_head']==BASE and receipt['actual_merge']==PREVIOUS_CANONICAL and receipt['admission_archive_sha256']==PARENT_ADMISSION_SHA and receipt['contexts']==86 and receipt['canonical_admission'] is True
 with prior_source_projection():prior=literal('verify',prior_namespace())()
 assert prior['status']=='BOUNDED_ORIGINAL_INITIAL_PRESSURE_FROST_SOURCE_RAW_NATIVE_PASS' and prior['coadmission']['contexts']==86
 return dict(status='BOUNDED_ORIGINAL_INITIAL_PRESSURE_AGE_SOURCE_RAW_NATIVE_PASS',runtime=CORE,targeted=actual,inherited_frost_and_all_prior_science=prior,coadmission=dict(contexts=110,short35_contexts=108,year367_contexts=2,exact_cold_windows=334,native_calendar_samples=776,compiled_postimages=57,previous_canonical=PREVIOUS_CANONICAL),compiler_executions=0,model_executions=0,canonical_admission='OWNED_BY_ACTUAL_MERGE_RECEIPT',functional_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)


if __name__=='__main__':print(json.dumps(verify(),indent=2))
