from pathlib import Path
import os,sys,subprocess,json,argparse
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=('O0','O2'),required=True);a=p.parse_args()
R=Path(r"C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01");E=Path(r"C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600/evidence");W=E.parent
os.environ.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TEMP=str(W/'active-python-scratch'),TMP=str(W/'active-python-scratch'),PATH='C:/msys64/ucrt64/bin;'+os.environ['PATH'])
for item in json.loads((E/'INITIAL_PROFILE_FROST_POSTIMAGE_BUILD_ALLOCATIONS_V1.json').read_text()):
 if item['optimization']!=a.optimization:continue
 case,opt,label=item['case'],item['optimization'],item['label'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==item['source']
 cmd=[sys.executable,'-B','tests/nomacro_drainage/initial_profile_frost_postimage.py','--profile',str(E/('initial-profile-frost-'+case+'-'+opt+'-v1')),'--input',str(E/'initial-profile-frost-original-dispatch-v1'/(case+'-initial2')),'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--build-root',item['allocation']['path'],'--output',str(E/label)]
 with (E/(label+'.controller.stdout.txt')).open('x') as out,(E/(label+'.controller.stderr.txt')).open('x') as err:r=subprocess.run(cmd,cwd=R,stdout=out,stderr=err)
 print(case,opt,'COMPILED_POSTIMAGE',r.returncode,flush=True);r.check_returncode()
