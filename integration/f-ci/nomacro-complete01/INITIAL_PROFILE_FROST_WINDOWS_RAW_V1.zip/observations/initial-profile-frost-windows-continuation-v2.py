import os,sys,json,subprocess,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=('O0','O2'),required=True);a=p.parse_args()
R=Path(r"C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01");E=Path(r"C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600/evidence");W=E.parent
os.environ.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TEMP=str(W/'active-python-scratch'),TMP=str(W/'active-python-scratch'),PATH='C:/msys64/ucrt64/bin;'+os.environ['PATH'])
cleanup=Path(r"C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py");task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';reference='C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider';source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert source=='cc0f4126f9bafd7bbea104ebd5a3e07ef7c09c16'
space=json.loads(subprocess.check_output([sys.executable,str(cleanup),'check-space'],text=True));assert space['ok']
for case in ('explicit-cde','implicit-water','implicit-cde'):
 kind=case.split('-')[1];label='initial-profile-frost-'+case+'-'+a.optimization+'-v1';inputs=E/'initial-profile-frost-original-dispatch-v1'/(case+'-initial1');output=E/label
 build=json.loads(subprocess.check_output([sys.executable,str(cleanup),'allocate','--task',task,'--kind','build','--name',label,'--variant',a.optimization,'--source-ref',source,'--recipe','unchanged frost runtime SWINCO1 35days cold2-4,19-23,30-34 '+case+' '+a.optimization],text=True))['path']
 script='frost_implicit_runtime.py' if case.startswith('implicit-') else 'frost_cde_drainage_runtime.py'
 cmd=[sys.executable,'-B','tests/nomacro_drainage/'+script,'--reference-work',reference,'--build-root',build,'--output',str(output),'--existing-input',str(inputs),'--kind',kind,'--optimization',a.optimization]
 with (E/(label+'.controller.stdout.txt')).open('x') as out,(E/(label+'.controller.stderr.txt')).open('x') as err:r=subprocess.run(cmd,cwd=R,stdout=out,stderr=err)
 print(case,a.optimization,'RUNTIME',r.returncode,flush=True);r.check_returncode()
 independent=E/(label+'-INDEPENDENT_V1.json');cmd=[sys.executable,'-B','tests/nomacro_drainage/initial_profile_frost_science.py','--profile',str(output),'--reference-work',reference,'--output',str(independent)]
 with (E/(label+'.science.stdout.txt')).open('x') as out,(E/(label+'.science.stderr.txt')).open('x') as err:r=subprocess.run(cmd,cwd=R,stdout=out,stderr=err)
 print(case,a.optimization,'SCIENCE',r.returncode,flush=True);r.check_returncode()
