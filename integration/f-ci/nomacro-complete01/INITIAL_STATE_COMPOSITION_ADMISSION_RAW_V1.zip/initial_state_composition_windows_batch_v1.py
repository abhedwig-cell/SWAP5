"""Real new baseline codec and twenty first-time original profile state contexts."""
import json,subprocess,sys
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).parent;T='C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py';task='01a1e8b4-228b-75f1-8ac4-b07ca1e15713';source='5c909ffd8b32e047910014d363243bba545839f9';reference='C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider';q=dict(status='RUNNING',source=source,contexts=[])
def save():(E/'INITIAL_STATE_COMPOSITION_WINDOWS_BATCH_V1.json').write_text(json.dumps(q,indent=2)+'\n')
def run(case,inputs,initial,opt):
 label='initial-state-'+case+'-initial'+str(initial)+'-'+opt+'-v1';output=E/label;assert not output.exists()
 a=subprocess.run([sys.executable,T,'allocate','--task',task,'--kind','build','--name',label,'--variant',opt,'--source-ref',source,'--recipe','python -B tests/nomacro_drainage/initial_state_composition_runtime.py actual '+case+' originalinitial'+str(initial)+' O'+opt[1:]+' 35days andthreeexactcold; realdonor/kernel retained'],capture_output=True,text=True);assert a.returncode==0,a.stderr;build=json.loads(a.stdout)['path']
 command=[sys.executable,'-B','tests/nomacro_drainage/initial_state_composition_runtime.py','--input',str(inputs),'--initial',str(initial),'--optimization',opt,'--days','35','--reference-work',reference,'--build-root',build,'--output',str(output)]
 p=subprocess.run(command,cwd=R,capture_output=True,text=True,timeout=900);(E/(label+'.stdout.txt')).write_text(p.stdout);(E/(label+'.stderr.txt')).write_text(p.stderr);q['contexts'].append(dict(case=case,initial=initial,opt=opt,profile=label,returncode=p.returncode));save();print(case,initial,opt,p.returncode,flush=True)
 if p.returncode:q['status']='FAILED';save();raise SystemExit(p.returncode)
 return output
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==source;save()
profile=run('daily-snow-cde',E/'initial-state-composition-original-dispatch-v1/implicit-snow-cde',2,'O2')
label='initial-state-daily-snow-cde-initial2-O2-controls-v1';p=subprocess.run([sys.executable,'-B','tests/nomacro_drainage/initial_state_composition_root_controls.py','--reference-work',reference,'--profile',str(profile),'--output',str(E/label)],cwd=R,capture_output=True,text=True,timeout=180);(E/(label+'.stdout.txt')).write_text(p.stdout);(E/(label+'.stderr.txt')).write_text(p.stderr);assert p.returncode==0,(p.stdout,p.stderr);q['baseline_native_controls_O2']='28actualcompiledrefusalsPASS';save();print(q['baseline_native_controls_O2'],flush=True)
for item in json.loads((E/'INITIAL_STATE_COMPOSITION_INITIAL_FRONTEND_V1.json').read_text())['cases']:
 for opt in ('O0','O2'):run(item['case'],Path(item['inputs']),1,opt)
q['status']='TWENTY_FIRST_TIME_PROFILE_STATE_COMPOSITIONS_AND_NEW_DAILY_SNOW_CDE_INITIAL2_O2_PASS';save();print(q['status'],flush=True)
