* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 05:17:53

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        74.82 cm       0.7750E-01 mg/cm2
Initial :        73.20 cm       0.0000E+00 mg/cm2
            =============       =================
Change            1.61 cm       0.7750E-01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    34.30
Bottom flux    :   -46.16    Soil evaporation  :     0.02
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :    40.42    Sum               :    38.81


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.7847E-01
                             Drainage       :  0.9745E-03
=========================    ============================
Sum         :  0.7847E-01    Sum            :  0.9745E-03


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        73.95 cm       0.9411E-01 mg/cm2
Initial :        74.82 cm       0.7750E-01 mg/cm2
            =============       =================
Change           -0.87 cm       0.1661E-01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.41
Runon          :     0.00    Runoff            :     1.13
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    18.99
Bottom flux    :   -44.55    Soil evaporation  :     1.78
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    27.43    Sum               :    28.30


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.1661E-01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.1661E-01    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        73.91 cm       0.7355E-01 mg/cm2
Initial :        73.95 cm       0.9411E-01 mg/cm2
            =============       =================
Change           -0.04 cm      -0.2055E-01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -36.89    Soil evaporation  :     0.02
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    43.66    Sum               :    43.70


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.2055E-01
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.2055E-01    Sum            :  0.0000E+00

