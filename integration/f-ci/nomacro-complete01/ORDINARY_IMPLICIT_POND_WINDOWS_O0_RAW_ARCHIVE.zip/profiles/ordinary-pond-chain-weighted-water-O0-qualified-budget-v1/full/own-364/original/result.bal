* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 04:53:13

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        35.03 cm
Initial :        75.19 cm
            =============
Change          -40.15 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :    41.50
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    18.29
Bottom flux    :   -56.10    Soil evaporation  :     6.63
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    30.48    Sum               :    70.64
