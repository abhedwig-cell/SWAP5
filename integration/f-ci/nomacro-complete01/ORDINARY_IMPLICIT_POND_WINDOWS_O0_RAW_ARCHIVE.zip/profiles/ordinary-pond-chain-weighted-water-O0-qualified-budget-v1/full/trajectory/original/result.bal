* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 04:43:23

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        35.03 cm
Initial :        75.19 cm
            =============
Change          -40.15 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :    41.50
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    18.29
Bottom flux    :   -56.10    Soil evaporation  :     6.63
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    30.48    Sum               :    70.64

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        35.45 cm
Initial :        35.03 cm
            =============
Change            0.42 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     0.13
Runon          :     0.00    Runoff            :    46.71
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.59    Soil evaporation  :    25.31
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    72.57    Sum               :    72.15

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        35.56 cm
Initial :        35.45 cm
            =============
Change            0.11 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     0.94
Runon          :     0.00    Runoff            :    49.59
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.06    Soil evaporation  :    29.97
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    80.61    Sum               :    80.50
