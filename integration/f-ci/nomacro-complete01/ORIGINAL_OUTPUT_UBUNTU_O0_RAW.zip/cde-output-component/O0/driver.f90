program component
use iso_fortran_env,only:int64
use MOD_grid,only:numnod
use MOD_solute,only:samini,sqprec,sqirrig,sqbot,dectot,rottot,sqdra,imsqbot,imsqdra,imsqirrig,imsqprec,imdectot,imrottot,sbaldev,sdstor,isqtop,isqbot,imqsol
use variables,only:flzerointr
use hybrid_original_cde_output_state
implicit none
character(500)::path,mode
real(8)::before(21),after(21)
integer::u,i
call get_command_argument(1,mode);call get_command_argument(2,path)
numnod=3;flzerointr=.true.
call assign(2d0)
if(trim(mode)=='write')then
 open(newunit=u,file=trim(path),access='stream',form='unformatted',status='new')
 call hybrid_cde_output_checkpoint(u,.false.);close(u)
else
 call assign(5d0);call snapshot(before)
 open(newunit=u,file=trim(path),access='stream',form='unformatted',status='old')
 call hybrid_cde_output_checkpoint(u,.true.);close(u)
 call snapshot(after)
 if(any(transfer(before,0_int64,21)/=transfer(after,0_int64,21)))error stop 'Read mutated live CDE state'
 select case(trim(mode))
 case('pending-read')
  open(newunit=u,file=trim(path),access='stream',form='unformatted',status='old')
  call hybrid_cde_output_checkpoint(u,.true.)
 case('pending-write')
  open(newunit=u,status='scratch',access='stream',form='unformatted')
  call hybrid_cde_output_checkpoint(u,.false.)
 case('reset')
  flzerointr=.false.
 case('shape')
  numnod=4
 end select
 call hybrid_cde_output_apply();call snapshot(after)
 call assign(2d0);call snapshot(before)
 if(any(transfer(before,0_int64,21)/=transfer(after,0_int64,21)))error stop 'CDE output restore not exact'
 call hybrid_cde_output_apply()
end if
write(*,'(a)')'CDE_OUTPUT_COMPONENT_PASS'
contains
subroutine assign(factor)
real(8),intent(in)::factor
samini=factor*1
sqprec=factor*2
sqirrig=factor*3
sqbot=factor*4
dectot=factor*5
rottot=factor*6
sqdra=factor*7
imsqbot=factor*8
imsqdra=factor*9
imsqirrig=factor*10
imsqprec=factor*11
imdectot=factor*12
imrottot=factor*13
sbaldev=factor*14
sdstor=factor*15
isqtop=factor*16
isqbot=factor*17
do i=1,4
 imqsol(i)=factor*(17+i)
end do
end subroutine
subroutine snapshot(values)
real(8),intent(out)::values(21)
values=[samini,sqprec,sqirrig,sqbot,dectot,rottot,sqdra,imsqbot,imsqdra,imsqirrig,imsqprec,imdectot,imrottot,sbaldev,sdstor,isqtop,isqbot,imqsol(1:4)]
end subroutine
end program
