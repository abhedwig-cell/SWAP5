program catalog
use SWAP_csv_output,only:vars_v,M_v
implicit none
integer::i
do i=1,M_v
 write(*,'(i0,1x,a,1x,a)')i,vars_v%name(i),vars_v%unit(i)
end do
end program
