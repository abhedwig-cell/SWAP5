program test_original_tillage_state
use MOD_tillage
use MOD_swap_base, only: swtill
use MOD_grid, only: NumLay, NumNod
use, intrinsic :: ieee_arithmetic, only: ieee_value, ieee_quiet_nan
implicit none
type(hybrid_tillage_post_event_state) :: a,b,c,bad
logical :: ok
integer :: i,model,unit
character(len=20) :: mode
character(len=1024) :: filename
! Technical state vectors only: no project, weather, physical timestep or density input.
NumLay=2; NumNod=2; swtill=1
a%Ntill=2; a%iTill=2; a%Ntypes=2; a%i_n_model=3; a%iRedist=2
a%MaxNumSoilHo=2; a%MaxNumSoilCP=2; a%Max_Z_tillage=2d0
a%Type_Tillage = [1,2]
a%iType_Tillage = [1,2]
a%iTT1 = [1,2]
a%iTT2 = [1,2]
a%Date_tillage = [(dble(i),i=1,a%Ntill+1)]
a%Z_tillage = [(dble(i),i=1,a%Ntill)]
a%I_tillage = [(dble(i),i=1,a%Ntill)]
a%TAB_Rho_tillage = [(dble(i),i=1,a%Ntypes)]
a%TAB_Rho_cons = [(dble(i),i=1,a%Ntypes)]
a%TAB_K_R_cons = [(dble(i),i=1,a%Ntypes)]
a%Rho_tillage = [(dble(i),i=1,a%MaxNumSoilHo)]
a%Rho_cons = [(dble(i),i=1,a%MaxNumSoilHo)]
a%K_R_cons = [(dble(i),i=1,a%MaxNumSoilHo)]
a%TAB_Rho_match = [(dble(i),i=1,a%Ntypes)]
a%TAB_N_match = [(dble(i),i=1,a%Ntypes)]
a%Rho_match = [(dble(i),i=1,a%MaxNumSoilHo)]
a%N_match = [(dble(i),i=1,a%MaxNumSoilHo)]
a%Slope_match = [(dble(i),i=1,a%MaxNumSoilHo)]
call get_command_argument(1,mode)
call get_command_argument(2,filename)
if(trim(mode)=='cold')then
open(newunit=unit,file=trim(filename),access='stream',form='unformatted',status='old')
call hybrid_tillage_read_post_event(unit,repeat('a',64),bad,ok)
close(unit)
if(.not.ok)error stop "Cold native read refused"
call hybrid_tillage_restore_post_event(bad,ok)
if(.not.ok)error stop "Cold restore refused"
call hybrid_tillage_capture_post_event(c,ok)
if(.not.ok)error stop "Cold capture refused"
call identical(a,c)
write(*,'(a)')'ORIGINAL_PRIVATE_TILLAGE_COLD_STATE_EXACT'
stop
end if
call hybrid_tillage_restore_post_event(a,ok)
if(.not.ok)error stop "Valid technical post-event state refused"
if(trim(mode)=='cold_reject')then
open(newunit=unit,file=trim(filename),access='stream',form='unformatted',status='old')
call hybrid_tillage_read_post_event(unit,repeat('a',64),bad,ok)
close(unit)
if(ok)error stop "Corrupt native read accepted"
call hybrid_tillage_capture_post_event(c,ok)
if(.not.ok)error stop "Rejected read damaged private state"
call identical(a,c)
write(*,'(a)')'ORIGINAL_PRIVATE_TILLAGE_COLD_CORRUPTION_REFUSED_NO_MUTATION'
stop
end if
a%Date_tillage(1)=99d0
call hybrid_tillage_capture_post_event(b,ok)
if(.not.ok.or.b%Date_tillage(1)/=1d0)error stop "Caller aliases private saved state"
a=b
a%Rho_cons(1)=123d0
call hybrid_tillage_capture_post_event(c,ok)
if(.not.ok)error stop "Capture refused"
call identical(b,c)
bad=b; bad%schema=2
call refuse_without_mutation(bad,b)
bad=b; bad%iTill=1
call refuse_without_mutation(bad,b)
bad=b; bad%Date_tillage=[1d0]
call refuse_without_mutation(bad,b)
bad=b; bad%Rho_cons(1)=ieee_value(0d0,ieee_quiet_nan)
call refuse_without_mutation(bad,b)
swtill=0
call hybrid_tillage_capture_post_event(c,ok)
if(ok)error stop "Inactive capture accepted"
call hybrid_tillage_restore_post_event(b,ok)
if(ok)error stop "Inactive restore accepted"
swtill=1
call hybrid_tillage_capture_post_event(c,ok)
if(.not.ok)error stop "Active state lost"
call identical(b,c)
do model=1,2
a=b; a%i_n_model=model
deallocate(a%TAB_Rho_match)
deallocate(a%TAB_N_match)
deallocate(a%Rho_match)
deallocate(a%N_match)
deallocate(a%Slope_match)
call hybrid_tillage_restore_post_event(a,ok)
if(.not.ok)error stop "Inactive matching arrays required"
call hybrid_tillage_capture_post_event(c,ok)
if(.not.ok)error stop "Matching-free state capture refused"
if(allocated(c%TAB_Rho_match))error stop "Undefined inactive matching state serialized"
if(allocated(c%TAB_N_match))error stop "Undefined inactive matching state serialized"
if(allocated(c%Rho_match))error stop "Undefined inactive matching state serialized"
if(allocated(c%N_match))error stop "Undefined inactive matching state serialized"
if(allocated(c%Slope_match))error stop "Undefined inactive matching state serialized"
end do
call hybrid_tillage_restore_post_event(b,ok)
if(.not.ok)error stop "Rollback refused"
call hybrid_tillage_capture_post_event(c,ok)
if(.not.ok)error stop "Rollback capture refused"
call identical(b,c)
open(newunit=unit,file='state.bin',access='stream',form='unformatted',status='new')
call hybrid_tillage_write_post_event(unit,repeat('a',64),b,ok)
close(unit)
if(.not.ok)error stop "Native write refused"
write(*,'(a)')"ORIGINAL_PRIVATE_TILLAGE_POST_EVENT_TECHNICAL_STATE_PASS"
contains
subroutine refuse_without_mutation(incoming,previous)
type(hybrid_tillage_post_event_state),intent(in)::incoming,previous
type(hybrid_tillage_post_event_state)::actual
logical::accepted
call hybrid_tillage_restore_post_event(incoming,accepted)
if(accepted)error stop "Invalid technical native accepted"
call hybrid_tillage_capture_post_event(actual,accepted)
if(.not.accepted)error stop "Rejected restore damaged state"
call identical(previous,actual)
end subroutine
subroutine identical(x,y)
type(hybrid_tillage_post_event_state),intent(in)::x,y
if(x%Ntill/=y%Ntill)error stop "Changed private scalar Ntill"
if(x%iTill/=y%iTill)error stop "Changed private scalar iTill"
if(x%Ntypes/=y%Ntypes)error stop "Changed private scalar Ntypes"
if(x%i_n_model/=y%i_n_model)error stop "Changed private scalar i_n_model"
if(x%iRedist/=y%iRedist)error stop "Changed private scalar iRedist"
if(x%MaxNumSoilHo/=y%MaxNumSoilHo)error stop "Changed private scalar MaxNumSoilHo"
if(x%MaxNumSoilCP/=y%MaxNumSoilCP)error stop "Changed private scalar MaxNumSoilCP"
if(x%Max_Z_tillage/=y%Max_Z_tillage)error stop "Changed private scalar Max_Z_tillage"
if(any(x%Type_Tillage/=y%Type_Tillage))error stop "Changed private array Type_Tillage"
if(any(x%iType_Tillage/=y%iType_Tillage))error stop "Changed private array iType_Tillage"
if(any(x%iTT1/=y%iTT1))error stop "Changed private array iTT1"
if(any(x%iTT2/=y%iTT2))error stop "Changed private array iTT2"
if(any(x%Date_tillage/=y%Date_tillage))error stop "Changed private array Date_tillage"
if(any(x%Z_tillage/=y%Z_tillage))error stop "Changed private array Z_tillage"
if(any(x%I_tillage/=y%I_tillage))error stop "Changed private array I_tillage"
if(any(x%TAB_Rho_tillage/=y%TAB_Rho_tillage))error stop "Changed private array TAB_Rho_tillage"
if(any(x%TAB_Rho_cons/=y%TAB_Rho_cons))error stop "Changed private array TAB_Rho_cons"
if(any(x%TAB_K_R_cons/=y%TAB_K_R_cons))error stop "Changed private array TAB_K_R_cons"
if(any(x%Rho_tillage/=y%Rho_tillage))error stop "Changed private array Rho_tillage"
if(any(x%Rho_cons/=y%Rho_cons))error stop "Changed private array Rho_cons"
if(any(x%K_R_cons/=y%K_R_cons))error stop "Changed private array K_R_cons"
if(any(x%TAB_Rho_match/=y%TAB_Rho_match))error stop "Changed private array TAB_Rho_match"
if(any(x%TAB_N_match/=y%TAB_N_match))error stop "Changed private array TAB_N_match"
if(any(x%Rho_match/=y%Rho_match))error stop "Changed private array Rho_match"
if(any(x%N_match/=y%N_match))error stop "Changed private array N_match"
if(any(x%Slope_match/=y%Slope_match))error stop "Changed private array Slope_match"
end subroutine
end program
