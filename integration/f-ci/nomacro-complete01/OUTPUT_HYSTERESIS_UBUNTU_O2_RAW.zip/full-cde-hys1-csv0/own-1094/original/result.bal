* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 03:00:04

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.30 cm       0.1561E+02 mg/cm2
Initial :        75.93 cm       0.2404E+02 mg/cm2
            =============       =================
Change           -0.63 cm      -0.8438E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :     0.00    Soil evaporation  :    14.20
                             Crack flux        :     0.00
                             Drainage level 1  :    23.31
=========================    ============================
Sum            :    80.55    Sum               :    81.18


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.8438E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.8438E+01

