* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 03:53:20

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.85 cm       0.4332E+02 mg/cm2
Initial :        72.37 cm       0.7237E+01 mg/cm2
            =============       =================
Change            5.49 cm       0.3609E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    30.18
=========================    ============================
Sum            :    86.58    Sum               :    81.09


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1191E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.1191E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.93 cm       0.2404E+02 mg/cm2
Initial :        77.85 cm       0.4332E+02 mg/cm2
            =============       =================
Change           -1.93 cm      -0.1928E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.43
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    20.58
Bottom flux    :     0.00    Soil evaporation  :    13.44
                             Crack flux        :     0.00
                             Drainage level 1  :    33.45
=========================    ============================
Sum            :    71.98    Sum               :    73.91


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1928E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1928E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.30 cm       0.1560E+02 mg/cm2
Initial :        75.93 cm       0.2404E+02 mg/cm2
            =============       =================
Change           -0.63 cm      -0.8440E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :     0.00    Soil evaporation  :    14.19
                             Crack flux        :     0.00
                             Drainage level 1  :    23.31
=========================    ============================
Sum            :    80.55    Sum               :    81.18


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.8440E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.8440E+01

