* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 03:53:53

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.86 cm       0.4307E+02 mg/cm2
Initial :        75.19 cm       0.7519E+01 mg/cm2
            =============       =================
Change            2.67 cm       0.3555E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    32.99
=========================    ============================
Sum            :    86.58    Sum               :    83.91


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1245E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.1245E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.93 cm       0.2388E+02 mg/cm2
Initial :        77.86 cm       0.4307E+02 mg/cm2
            =============       =================
Change           -1.93 cm      -0.1919E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.43
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    20.52
Bottom flux    :     0.00    Soil evaporation  :    13.45
                             Crack flux        :     0.00
                             Drainage level 1  :    33.51
=========================    ============================
Sum            :    71.98    Sum               :    73.91


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1919E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1919E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.30 cm       0.1549E+02 mg/cm2
Initial :        75.93 cm       0.2388E+02 mg/cm2
            =============       =================
Change           -0.63 cm      -0.8385E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :     0.00    Soil evaporation  :    14.19
                             Crack flux        :     0.00
                             Drainage level 1  :    23.32
=========================    ============================
Sum            :    80.55    Sum               :    81.18


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.8385E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.8385E+01

