* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 03:52:50

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        77.85 cm
Initial :        72.37 cm
            =============
Change            5.49 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    30.18
=========================    ============================
Sum            :    86.58    Sum               :    81.09

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        75.93 cm
Initial :        77.85 cm
            =============
Change           -1.93 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.43
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    20.58
Bottom flux    :     0.00    Soil evaporation  :    13.44
                             Crack flux        :     0.00
                             Drainage level 1  :    33.45
=========================    ============================
Sum            :    71.98    Sum               :    73.91

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        75.30 cm
Initial :        75.93 cm
            =============
Change           -0.63 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.15
Bottom flux    :     0.00    Soil evaporation  :    14.19
                             Crack flux        :     0.00
                             Drainage level 1  :    23.31
=========================    ============================
Sum            :    80.55    Sum               :    81.18
