* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 03:53:48

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        77.85 cm
Initial :        72.37 cm
            =============
Change            5.49 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    30.18
=========================    ============================
Sum            :    86.58    Sum               :    81.09
