from pathlib import Path
import importlib.util,json,sys,subprocess
root,build,reference,inputs,out=map(Path,sys.argv[1:6]);original=sys.argv[6]=='1';policy=sys.argv[7]
spec=importlib.util.spec_from_file_location('actual_thermal_source',root/'tests/nomacro_mixtures/run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);p=m.e.load(inputs,original_output=original,time_step_policy=policy)
if out.exists():
 data=m.rows(out);assert len(data)==35;m.validate_bundle(build,reference,p);report=dict(status='ACTUAL_COMPLETED_THERMAL_TRAJECTORY_REVALIDATED',days=35,budgets=m.check(data),build_sha256=m.sha(build/'BUILD.json'))
else:report,data=m.trajectory(build,reference,p,out,35,{2,4,8,19,23,30,34,35},90)
(out.parent/'RUN.json').write_text(json.dumps(dict(status='ACTUAL_THERMAL_SOURCE_TRAJECTORY_PASS',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),original_output=original,trajectory=report),indent=2)+'\n')
