* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 10:04:25

Period             :  1900-01-01  until  2002-01-10 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        82.64 cm       0.1200E+03 mg/cm2
Initial :        97.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -14.55 cm       0.1200E+03 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :     0.02    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     3.60
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -18.14    Soil evaporation  :     0.02
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :   -14.52    Sum               :     0.02


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.1200E+03    Root uptake    :  0.0000E+00
Bottom flux : -0.1729E-06
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.1200E+03    Sum            :  0.0000E+00

