* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 21:11:31

Period             :  2003-12-15  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        69.84 cm
Initial :        97.19 cm
            =============
Change          -27.34 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :     4.17    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :   -33.81    Soil evaporation  :     0.10
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :   -27.24    Sum               :     0.10
