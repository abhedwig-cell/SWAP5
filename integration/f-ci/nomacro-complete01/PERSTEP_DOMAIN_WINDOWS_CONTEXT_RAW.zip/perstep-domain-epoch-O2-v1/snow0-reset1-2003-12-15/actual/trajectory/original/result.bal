* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-18 21:11:27

Period             :  2003-12-15  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        61.23 cm
Initial :        75.19 cm
            =============
Change          -13.95 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     4.17    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :   -20.42    Soil evaporation  :     0.10
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :   -13.85    Sum               :     0.10
