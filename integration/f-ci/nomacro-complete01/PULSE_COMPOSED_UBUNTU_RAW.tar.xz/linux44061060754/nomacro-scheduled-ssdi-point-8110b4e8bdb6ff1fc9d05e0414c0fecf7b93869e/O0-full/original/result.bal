* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-17 10:02:56

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        78.02 cm
Initial :        75.19 cm
            =============
Change            2.83 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.03
SSDI           :     0.40
Irrigation     :     0.00    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    30.75
=========================    ============================
Sum            :    84.58    Sum               :    81.75

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.37 cm
Initial :        78.02 cm
            =============
Change           -1.65 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.45
Runon          :     0.00    Runoff            :     0.00
SSDI           :     1.30
Irrigation     :     0.00    Transpiration     :    21.40
Bottom flux    :     0.00    Soil evaporation  :    13.73
                             Crack flux        :     0.00
                             Drainage level 1  :    33.34
=========================    ============================
Sum            :    73.28    Sum               :    74.93

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        76.02 cm
Initial :        76.37 cm
            =============
Change           -0.35 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     1.50
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.41
                             Crack flux        :     0.00
                             Drainage level 1  :    24.31
=========================    ============================
Sum            :    82.05    Sum               :    82.40
