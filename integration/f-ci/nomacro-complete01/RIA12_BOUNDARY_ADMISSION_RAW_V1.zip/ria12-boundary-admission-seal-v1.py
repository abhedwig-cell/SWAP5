"""Seal actual canonical400, genuine source, all CI and committed refusals."""
from pathlib import Path
import json,hashlib,subprocess,zipfile
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest();read=lambda name:json.loads((E/name).read_text());git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
candidate='8e8f2a4c7ff28e4e4845c4b5554894a4bc3c5af1';actual='2c361f08f7170943d716483252512817ef35a3a1';parent='a18cc38017f69523de48ec04d47cd12686b1ecff';synthetic='9906329474c2ed62aacb1d79a4c2f88771ea6ef6';tree='21ce9131fe83619938f24b38cef23189649275ce';anchor='2c596a91d66601b3c9fcc1d7188b9dc8e49d0e91'
api=read('RIA12_BOUNDARY_PR1796_ACTUAL_GIT_API_V1.json');assert api['sha']==actual and api['tree']['sha']==tree and [p['sha'] for p in api['parents']]==[parent,candidate]
assert all(git('rev-parse',head+'^{tree}')==tree for head in (candidate,synthetic,actual))
expected=dict(contexts=400,short35_contexts=398,year367_contexts=2,new_ria_boundary_contexts=8,native_calendar_samples=2806,exact_cold_windows=1204,compiled_initialization_postimages=343,previous_canonical=parent)
observations={}
for role,head in [('CANDIDATE',candidate),('ACTUAL_CANONICAL',actual)]:
 for scope in ('PUBLIC','PUBLICATION'):
  label=f'RIA12_BOUNDARY_{role}_{scope}_V1';q=read(label+'.json');raw=(E/(label+'.stdout.txt')).read_bytes();assert q['returncode']==0 and q['before']==q['after'] and q['before']['head']==head and q['before']['tree']==tree and not q['before']['status'];assert len(q['before']['sparse'])==14 and len(q['before']['original_project_files'])==56 and not (E/(label+'.stderr.txt')).read_bytes()
  if scope=='PUBLIC':assert json.loads(raw)['coadmission']==expected
  else:assert b'PUBLICATION_REPLAY_SELECTED=false' in raw
  observations[label]=q['seconds']
negative=read('RIA12_BOUNDARY_FINAL_NEGATIVES_V1.json');assert negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED' and len(negative['controls'])==4 and all(x['actual_refusal'] for x in negative['controls']) and negative['candidate']==candidate
for q in negative['controls']:assert git('show','-s','--format=%P',q['head'])==candidate and git('diff','--name-only',candidate,q['head'])==q['path']
runs=read('RIA12_BOUNDARY_PR1796_FINAL_WORKFLOW_RUNS_V1.json')['workflow_runs'];checks=read('RIA12_BOUNDARY_PR1796_FINAL_CHECK_RUNS_V1.json')['check_runs'];assert len(runs)==13 and all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion']=='success' for x in runs);assert len(checks)==42 and all(x['status']=='completed' and x['conclusion'] in ('success','skipped') for x in checks) and sum(x['conclusion']=='success' for x in checks)==27
for role,job in [('CO2',138322516788),('DVS',138322516146),('LRV',138322516457),('FCI_MODULAR',138332236057),('TIMEINT_RETRIED',138344462891)]:
 label=f'RIA12_BOUNDARY_PR1796_{role}_ORIGINAL_JOB_{job}.txt';q=read(label+'.json');raw=(E/label).read_bytes();assert len(raw)==q['bytes'] and SHA(raw)==q['sha256'] and q['actual_candidate']==candidate and q['actual_synthetic']==synthetic and q['actual_candidate_in_original_log'] and q['actual_synthetic_in_original_log']
cancelled=next(x for x in read('RIA12_BOUNDARY_PR1796_ORIGINAL_TIMEINT_ATTEMPT1_JOBS_V1.json')['jobs'] if x['id']==138322517081);assert cancelled['conclusion']=='cancelled' and all(x['conclusion']=='skipped' for x in cancelled['steps'] if x['name'] in ('Compiler identity','Run TG event-startup attribution'))
name='RIA12_BOUNDARY_ADMISSION_RAW_V1';members={}
paths=[p for p in E.iterdir() if p.is_file() and p.name.startswith('RIA12_BOUNDARY_') and p.suffix in ('.json','.txt','.bin')]
helpers=['ria12-boundary-negative-controls-v1.py','ria12-boundary-genuine-signed-object-import-v1.py','ria12-boundary-original-ci-job-log-v1.py',Path(__file__).name]
with zipfile.ZipFile(P/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths+[E/x for x in helpers]):
  raw=p.read_bytes();assert p.name not in members;z.writestr(p.name,raw);members[p.name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(P/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,item in members.items():assert len(z.read(key))==item['bytes'] and SHA(z.read(key))==item['sha256']
raw=(P/(name+'.zip')).read_bytes();manifest=dict(status='ACTUAL_CANONICAL400_RIA_BOUNDARY_PUBLIC_PUB_FOUR_COMMITTED_REFUSALS_ALL13_CI_AND_GENUINE_SOURCE_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,canonical_admission=True,actual_merge=actual,qualified_head=candidate,source_anchor=anchor,whole_qualified_tree=tree,coadmission=expected,actual_public_observations=observations,successful_workflows=13,successful_checks=27,skipped_checks=15,original_cancelled_checkout_and_single_job_retry_preserved=True,successful_other_TIMEINT_jobs_replayed=False,full_original_periods_replayed_for_observer_repairs=0,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
with (P/(name+'.json')).open('x') as f:json.dump(manifest,f,indent=2)
receipt=dict(status='ACTUAL_CANONICAL400_RIA_BOUNDARY_ADMISSION_VERIFIED',PR=1796,actual_merge=actual,qualified_head=candidate,source_anchor=anchor,whole_qualified_tree=tree,previous_canonical=parent,ordered_parents=[parent,candidate],synthetic_merge=synthetic,admission_archive_sha256=manifest['sha256'],coadmission=expected,canonical_admission=True,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
with (P/'RIA12_BOUNDARY_MERGE_RECEIPT_V1.json').open('x') as f:json.dump(receipt,f,indent=2)
print(manifest['status'],manifest['bytes'],manifest['sha256'],len(members))
