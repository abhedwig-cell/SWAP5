from pathlib import Path
import json,zipfile,hashlib
P=Path.cwd()/'integration/f-ci/nomacro-complete01';SHA=lambda b:hashlib.sha256(b).hexdigest()
for opt,aid in [('O0',14901209078),('O2',14901508013)]:
 p=P/f'RIA12_BOUNDARY_UBUNTU_{opt}_ORIGINAL_V1.zip';raw=p.read_bytes()
 with zipfile.ZipFile(p) as z:
  batch=json.loads(z.read('current/BATCH.json'));assert batch['full35_periods']==2 and batch['actual_source']=='b271938b36d2ce8074510cd847ba1166c4728c05' and batch['status'].endswith('PASS_NOT_ADMITTED')
  cases=[]
  for kind in ('water','cde'):
   q=json.loads(z.read('current/'+kind+'/RESULT.json'));s=json.loads(z.read('current/'+kind+'-INDEPENDENT.json'));c=json.loads(z.read('current/'+kind+'-native-controls/RESULT.json'));t=json.loads(z.read('current/'+kind+'-transactions/RESULT.json'))
   assert q['days']==35 and q['status'].endswith('PASS_NOT_ADMITTED') and s['status'].endswith('PASS_NOT_ADMITTED') and len(c['compiled_refusals'])==41 and len(c['private_input_refusals'])==3 and c['own_positive_ready'] and c['accepted_model_days']==0
   assert t['status'].endswith('PASS_NOT_ADMITTED') and t['targeted_current_prefix_days']==0
   cases.append(dict(kind=kind,profile_prefix='current/'+kind,actual_source=q['source'],actual_compiler=q['actual_compiler_source'],input_root=q['input_root'],build_root=q['build_root'],original_samples='current/'+kind+'-original-samples',independent='current/'+kind+'-INDEPENDENT.json',opposite_initial='current/'+kind+'-opposite-initial',native_controls='current/'+kind+'-native-controls',transactions='current/'+kind+'-transactions'))
  members={n:dict(bytes=len(z.read(n)),sha256=SHA(z.read(n))) for n in z.namelist()}
 q=dict(status='ORIGINAL_SUCCESSFUL_GITHUB_TWO_RIA_BOUNDARY_FULL35_ORIGINAL_NATIVE_COLD_POSTIMAGE_AND_EXTERNAL_ARTIFACT_PRESERVED',actual_source=batch['actual_source'],workflow_run=45354381845,artifact_id=aid,archive=p.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=p.name,bytes=len(raw),sha256=SHA(raw))],members=members,cases=cases,full35_scientific_contexts=2,canonical_admission=False)
 p.with_suffix('.json').write_text(json.dumps(q,indent=2)+'\n');print('UBUNTU_ORIGINAL_ARTIFACT_FULL_MEMBER_AND_CONTEXT_VERIFIED',opt,len(members),len(raw))
