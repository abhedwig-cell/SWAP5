from pathlib import Path
import subprocess,sys,json,zipfile
R=Path.cwd();W=Path('C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600');E=W/'evidence';P=R/'integration/f-ci/nomacro-complete01';cleanup=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();assert head=='b271938b36d2ce8074510cd847ba1166c4728c05';reference='C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'
origin=E/'ria12-boundary-current-native-origins-v1';origin.mkdir()
for archive,folder in [('RIA12_NATIVE_CONTROL_ORIGINS_V1','legacy'),('RIA12_BOUNDARY_NATIVE_ORIGINS_V1','boundary')]:
 declaration=json.loads((P/(archive+'.json')).read_text())
 with zipfile.ZipFile(P/declaration['archive']) as z:
  for name in z.namelist():
   path=origin/folder/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(z.read(name))
for opt in ('O0','O2'):
 for case,kind,othercase in [('water-d0-b5','water','cde-wet8-d1'),('cde-wet8-d1','cde','water-d0-b5')]:
  profile=E/f'ria12-boundary-{case}-Windows-{opt}-full35-v2';label=f'ria12-boundary-{case}-Windows-{opt}-opposite-initial-v1'
  subprocess.run([sys.executable,'-B',str(cleanup),'allocate','--task','01a1e8b4-228b-75f1-8ac4-b07ca1e15713','--kind','build','--name',label,'--variant',opt,'--source-ref',head,'--recipe','ria12_boundary_postimage.py: same generated/whole compiled images SWINCO2 to1; CDE2day/cold only; no full35 replay'],check=True,capture_output=True)
  command=[sys.executable,'-B','tests/nomacro_drainage/ria12_boundary_postimage.py','--profile',str(profile),'--reference-work',reference,'--build-root',str(W/label),'--output',str(E/label)]+(['--short-native'] if kind=='cde' else [])
  subprocess.run(command,check=True)
  controls=E/f'ria12-boundary-{case}-Windows-{opt}-native-controls-v1'
  subprocess.run([sys.executable,'-B','tests/nomacro_drainage/ria12_boundary_controls.py','--profile',str(profile),'--reference-work',reference,'--model1-origin',str(origin/'legacy/model1/accepted-column-1-day-1.zip'),'--legacy-ria-origin',str(origin/'legacy/legacy-ria/accepted-column-1-day-1.zip'),'--primary-origin',str(origin/f'boundary/primary-{kind}/accepted-column-1-day-2.zip'),'--foreign-context-origin',str(origin/f'boundary/foreign-boundary-{kind}/accepted-column-1-day-2.zip'),'--other-kind-origin',str(E/f'ria12-boundary-{othercase}-Windows-{opt}-full35-v2/trajectory/accepted-column-1-day-2.zip'),'--output',str(controls)],check=True)
  if opt=='O0':subprocess.run([sys.executable,'-B','tests/nomacro_drainage/ria12_boundary_transactions.py','--profile',str(profile),'--reference-work',reference,'--output',str(E/f'ria12-boundary-{case}-Windows-{opt}-transactions-v1')],check=True)
  print('WINDOWS_CURRENT_BOUNDARY_NATIVE_POSTIMAGE_EXTERNAL_PASS',case,opt,flush=True)
