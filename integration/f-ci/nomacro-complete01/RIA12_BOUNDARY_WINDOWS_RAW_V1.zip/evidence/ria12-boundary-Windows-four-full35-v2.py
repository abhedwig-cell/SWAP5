from pathlib import Path
import subprocess,sys,json
R=Path.cwd();W=Path('C:/Users/Veldh012/SWAP5-work/01a1e8b4-228b-75f1-8ac4-b07ca1e15713-a9ded600');E=W/'evidence';cleanup=Path('C:/Users/Veldh012/OneDrive - Wageningen University & Research/Documents/ChatGPT/SWAP5-finaliseren/tools/storage/cleanup.py');head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();reference='C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider'
cases=[('water-d0-b5',E/'ria12-boundary-inputs-v1/water-drain0-bottom5',E/'ria12-boundary-water-d0-b5-O0-short-v1'),('cde-wet8-d1',E/'ria12-boundary-wet8-inputs-v2/cde-drain1-bottom8',E/'ria12-boundary-cde-wet8-d1-O0-short-v2')]
for opt in ('O0','O2'):
 for case,inputs,reuse in cases:
  label=f'ria12-boundary-{case}-Windows-{opt}-full35-v2';command=[sys.executable,'-B','tests/nomacro_drainage/ria12_boundary_period.py','--input',str(inputs),'--reference-work',reference,'--output',str(E/label),'--optimization',opt]
  if opt=='O0':command+=['--reuse-profile',str(reuse)]
  else:
   subprocess.run([sys.executable,'-B',str(cleanup),'allocate','--task','01a1e8b4-228b-75f1-8ac4-b07ca1e15713','--kind','build','--name',label,'--variant',opt,'--source-ref',head,'--recipe','ria12_boundary_period.py real new35 with 7warm native/3cold; complete original RIA/TTUTIL at actualheads; no parent35 replay'],check=True,capture_output=True);command+=['--build-root',str(W/label)]
  with (E/(label+'-controller.stdout')).open('xb') as out,(E/(label+'-controller.stderr')).open('xb') as err:subprocess.run(command,check=True,stdout=out,stderr=err)
  sample=E/(label+'-original-samples');subprocess.run([sys.executable,'-B','tests/nomacro_drainage/ria12_boundary_reference_samples.py','--profile',str(E/label),'--reference-work',reference,'--reuse-component',str(W/('ria12-original-component-'+opt+'-v4')),'--output',str(sample)],check=True)
  subprocess.run([sys.executable,'-B','tests/nomacro_drainage/ria12_boundary_science.py','--profile',str(E/label),'--reference-samples',str(sample),'--output',str(E/(label+'-INDEPENDENT.json'))],check=True)
  print('ACTUAL_NEW_BOUNDARY35_ORIGINAL_NATIVE_COLD_INDEPENDENT_PASS',case,opt,flush=True)
