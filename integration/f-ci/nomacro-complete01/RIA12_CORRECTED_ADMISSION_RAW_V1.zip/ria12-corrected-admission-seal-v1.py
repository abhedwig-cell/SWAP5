"""Seal genuine canonical admission after all exact-head CI and actual observers."""
from pathlib import Path
import json,hashlib,subprocess,zipfile
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
SHA=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((E/n).read_text());git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
candidate='1874c63ee359df7bbcfaead42af69bd9312a9065';parent='1e48f182a1415a3ef5224de39559a0ecff0c4c7c';synthetic='6d98117fc064cde638359738a2fd0baf0c72bcc6';tree='a77a888dee46a04c764f6d19ceeb31bf7f0554df';anchor='8264c29e9e8f5b21d9c81ff62751295d690d21b3'
api=read('RIA12_CORRECTED_PR1798_ACTUAL_GIT_API_V1.json');actual=api['sha'];assert api['tree']['sha']==tree and [p['sha'] for p in api['parents']]==[parent,candidate]
assert all(git('rev-parse',h+'^{tree}')==tree for h in (candidate,synthetic,actual))
expected=dict(contexts=416,short35_contexts=414,year367_contexts=2,corrected_ria_NoHeat_replacement_contexts=16,unchanged_ria_thermal_contexts=16,native_calendar_samples=2918,exact_cold_windows=1252,compiled_initialization_postimages=359,previous_canonical=parent)
observations={}
for role,head in [('CANDIDATE',candidate),('ACTUAL_CANONICAL',actual)]:
 for scope in ('PUBLIC','PUBLICATION'):
  label=f'RIA12_CORRECTED_{role}_{scope}_V1';q=read(label+'.json');raw=(E/(label+'.stdout.txt')).read_bytes()
  assert q['returncode']==0 and q['before']==q['after'] and q['before']['head']==head and q['before']['tree']==tree and not q['before']['status']
  assert len(q['before']['sparse'])==14 and len(q['before']['original_project_files'])==56 and not (E/(label+'.stderr.txt')).read_bytes()
  if scope=='PUBLIC':assert json.loads(raw)['coadmission']==expected
  else:
   assert b'PUBLICATION_REPLAY_SELECTED=false' in raw
   assert q['ordinary_python_default_dont_write_bytecode'] is False and q['child_bytecode_environment_variables_absent']
  observations[label]=q['seconds']
negative=read('RIA12_CORRECTED_FINAL_NEGATIVES_V1.json');assert negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED' and len(negative['controls'])==4 and all(x['actual_refusal'] for x in negative['controls']) and negative['candidate']==candidate
for q in negative['controls']:assert git('show','-s','--format=%P',q['head'])==candidate and git('diff','--name-only',candidate,q['head'])==q['path']
runs=read('RIA12_CORRECTED_PR1798_FINAL_WORKFLOW_RUNS_V1.json')['workflow_runs'];checks=read('RIA12_CORRECTED_PR1798_FINAL_CHECK_RUNS_V1.json')['check_runs']
initial=read('RIA12_CORRECTED_PR1798_INITIAL_APPLICABLE_WORKFLOW_RUNS_V1.json')['workflow_runs']
assert len(initial)==14 and {x['name'] for x in initial}<={x['name'] for x in runs}
assert all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion']=='success' for x in runs)
assert len(checks)==read('RIA12_CORRECTED_PR1798_FINAL_CHECK_RUNS_V1.json')['total_count'] and len(checks)>=len(runs)
assert all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion'] in ('success','skipped') for x in checks)
# Exact original selected integration logs bind the real candidate and synthetic.
logs=read('RIA12_CORRECTED_PR1798_REQUIRED_ORIGINAL_JOB_LOGS_V1.json')
assert {'CO2','DVS','LRV','FCI_MODULAR','TIMEINT_STARTUP'}<={x['role'] for x in logs}
for item in logs:
 label=item['file'];q=read(label+'.json');raw=(E/label).read_bytes()
 assert len(raw)==q['bytes'] and SHA(raw)==q['sha256'] and q['actual_candidate']==candidate and q['actual_synthetic']==synthetic and q['actual_candidate_in_original_log'] and q['actual_synthetic_in_original_log']
name='RIA12_CORRECTED_ADMISSION_RAW_V1';members={}
paths=[p for p in E.iterdir() if p.is_file() and p.name.startswith('RIA12_CORRECTED_') and p.suffix in ('.json','.txt','.bin')]
paths += [p for p in E.glob('RIA12_CORRECTED_PR1798_*CANCELLED*ARTIFACT*.zip')]
helpers=['ria12-corrected-negative-controls-v1.py','ria12-thermal-genuine-signed-object-import-v1.py','ria12-corrected-admission-ci-job-log-v1.py','ria12-corrected-normal-python-publication-observe-v1.py',Path(__file__).name]
with zipfile.ZipFile(P/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths+[E/n for n in helpers]):
  raw=p.read_bytes();assert p.name not in members;z.writestr(p.name,raw);members[p.name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(P/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,item in members.items():assert len(z.read(key))==item['bytes'] and SHA(z.read(key))==item['sha256']
raw=(P/(name+'.zip')).read_bytes()
manifest=dict(status='ACTUAL_CANONICAL416_CORRECTED_NOHEAT_REPLACEMENT16_REAL_SOURCE_PUBLIC_ORDINARY_PUB_FOUR_COMMITTED_REFUSALS_ALL_APPLICABLE_CI_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,canonical_admission=True,actual_merge=actual,qualified_head=candidate,source_anchor=anchor,whole_qualified_tree=tree,coadmission=expected,actual_public_observations=observations,successful_workflows=len(runs),successful_checks=sum(x['conclusion']=='success' for x in checks),skipped_checks=sum(x['conclusion']=='skipped' for x in checks),original_wet_primary_O0_O2_global_refusals_retained=True,original_observer_failures_retained=True,configuration_availability_increase=0,original_legacy_negative_binding_native_transition_explicit=True,full_original_periods_replayed_for_observer_repairs=0,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
with (P/(name+'.json')).open('x') as f:json.dump(manifest,f,indent=2)
receipt=dict(status='ACTUAL_CANONICAL416_CORRECTED_NOHEAT_REPLACEMENT16_ADMISSION_VERIFIED',PR=1798,actual_merge=actual,qualified_head=candidate,source_anchor=anchor,whole_qualified_tree=tree,previous_canonical=parent,ordered_parents=[parent,candidate],synthetic_merge=synthetic,admission_archive_sha256=manifest['sha256'],coadmission=expected,canonical_admission=True,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
with (P/'RIA12_CORRECTED_MERGE_RECEIPT_V1.json').open('x') as f:json.dump(receipt,f,indent=2)
print(manifest['status'],manifest['bytes'],manifest['sha256'],len(members))
