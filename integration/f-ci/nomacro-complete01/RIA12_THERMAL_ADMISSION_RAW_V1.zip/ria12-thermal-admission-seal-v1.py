"""Seal genuine canonical admission after all exact-head CI and actual observers."""
from pathlib import Path
import json,hashlib,subprocess,zipfile
E=Path(__file__).resolve().parent;R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01'
SHA=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((E/n).read_text());git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
candidate='6bbb9a5d8b97c1277af8af3b3f15e78d1ad1d70a';parent='2c361f08f7170943d716483252512817ef35a3a1';synthetic='58312db691aca7004c9f8ed8352ac8a25d1be3e6';tree='a039d668ea69dfcb8d93105b5bf1d683786f9d6f';anchor='21b0e33fd527c40f39a0ae3952c0534c06a535ed'
api=read('RIA12_THERMAL_PR1797_ACTUAL_GIT_API_V1.json');actual=api['sha'];assert api['tree']['sha']==tree and [p['sha'] for p in api['parents']]==[parent,candidate]
assert all(git('rev-parse',h+'^{tree}')==tree for h in (candidate,synthetic,actual))
expected=dict(contexts=416,short35_contexts=414,year367_contexts=2,new_ria_thermal_contexts=16,native_calendar_samples=2918,exact_cold_windows=1252,compiled_initialization_postimages=359,previous_canonical=parent)
observations={}
for role,head in [('ENVFIX_CANDIDATE',candidate),('ACTUAL_CANONICAL',actual)]:
 for scope in ('PUBLIC','PUBLICATION'):
  label=f'RIA12_THERMAL_{role}_{scope}_V1';q=read(label+'.json');raw=(E/(label+'.stdout.txt')).read_bytes()
  assert q['returncode']==0 and q['before']==q['after'] and q['before']['head']==head and q['before']['tree']==tree and not q['before']['status']
  assert len(q['before']['sparse'])==14 and len(q['before']['original_project_files'])==56 and not (E/(label+'.stderr.txt')).read_bytes()
  if scope=='PUBLIC':assert json.loads(raw)['coadmission']==expected
  else:
   assert b'PUBLICATION_REPLAY_SELECTED=false' in raw
   assert q['ordinary_python_default_dont_write_bytecode'] is False and q['child_bytecode_environment_variables_absent']
  observations[label]=q['seconds']
negative=read('RIA12_THERMAL_ENVFIX_FINAL_NEGATIVES_V1.json');assert negative['status']=='FOUR_ACTUAL_COMMITTED_PUSHED_CLEAN14_PUBLIC_NEGATIVES_REFUSED' and len(negative['controls'])==4 and all(x['actual_refusal'] for x in negative['controls']) and negative['candidate']==candidate
for q in negative['controls']:assert git('show','-s','--format=%P',q['head'])==candidate and git('diff','--name-only',candidate,q['head'])==q['path']
runs=read('RIA12_THERMAL_PR1797_FINAL_WORKFLOW_RUNS_V1.json')['workflow_runs'];checks=read('RIA12_THERMAL_PR1797_FINAL_CHECK_RUNS_V1.json')['check_runs']
assert len(runs)==22 and all(x['head_sha']==candidate and x['status']=='completed' and x['conclusion']=='success' for x in runs)
assert len(checks)==51 and all(x['status']=='completed' and x['conclusion'] in ('success','skipped') for x in checks) and sum(x['conclusion']=='success' for x in checks)==36
for role,job in [('CO2',138376626025),('DVS',138376624149),('LRV',138376625146),('FCI_MODULAR',138387705593),('TIMEINT_STARTUP',138376667748),('POND_CANCELLED',138377259132)]:
 label=f'RIA12_THERMAL_PR1797_ENVFIX_{role}_ORIGINAL_JOB_{job}.txt';q=read(label+'.json');raw=(E/label).read_bytes()
 assert len(raw)==q['bytes'] and SHA(raw)==q['sha256'] and q['actual_candidate']==candidate and q['actual_synthetic']==synthetic and q['actual_candidate_in_original_log'] and q['actual_synthetic_in_original_log']
assert read('RIA12_THERMAL_PR1797_POND_RETRY_EVIDENCE_V1.json')['conclusion']=='success'
name='RIA12_THERMAL_ADMISSION_RAW_V1';members={}
paths=[p for p in E.iterdir() if p.is_file() and p.name.startswith('RIA12_THERMAL_') and p.suffix in ('.json','.txt','.bin')]
paths += [E/'RIA12_THERMAL_PR1797_ENVFIX_POND_CANCELLED_ARTIFACT_V1.zip']
helpers=['ria12-thermal-envfix-negative-controls-v1.py','ria12-thermal-genuine-signed-object-import-v1.py','ria12-thermal-envfix-original-ci-job-log-v1.py','ria12-thermal-original27d-ci-job-log-v1.py','ria12-thermal-normal-python-publication-observe-v2.py',Path(__file__).name]
with zipfile.ZipFile(P/(name+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths+[E/n for n in helpers]):
  raw=p.read_bytes();assert p.name not in members;z.writestr(p.name,raw);members[p.name]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(P/(name+'.zip')) as z:
 assert set(z.namelist())==set(members)
 for key,item in members.items():assert len(z.read(key))==item['bytes'] and SHA(z.read(key))==item['sha256']
raw=(P/(name+'.zip')).read_bytes()
manifest=dict(status='ACTUAL_CANONICAL416_RIA_THERMAL_PUBLIC_ORDINARY_PUB_FOUR_COMMITTED_REFUSALS_ALL22_CI_AND_GENUINE_SOURCE_PRESERVED',archive=name+'.zip',bytes=len(raw),sha256=SHA(raw),parts=[dict(file=name+'.zip',bytes=len(raw),sha256=SHA(raw))],members=members,canonical_admission=True,actual_merge=actual,qualified_head=candidate,source_anchor=anchor,whole_qualified_tree=tree,coadmission=expected,actual_public_observations=observations,successful_workflows=22,successful_checks=36,skipped_checks=15,original27d_failures_retained=True,ordinary_publication_entry_correction_explicit=True,original_cancelled_pond_and_job_retry_retained=True,full_original_periods_replayed_for_observer_repairs=0,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
with (P/(name+'.json')).open('x') as f:json.dump(manifest,f,indent=2)
receipt=dict(status='ACTUAL_CANONICAL416_RIA_THERMAL_ADMISSION_VERIFIED',PR=1797,actual_merge=actual,qualified_head=candidate,source_anchor=anchor,whole_qualified_tree=tree,previous_canonical=parent,ordered_parents=[parent,candidate],synthetic_merge=synthetic,admission_archive_sha256=manifest['sha256'],coadmission=expected,canonical_admission=True,whole_historical_completion='PARTIAL',whole_scientific_equivalence='NOT_QUALIFIED',global_family_and_gap_counts='UNKNOWN',RC3_changed=False)
with (P/'RIA12_THERMAL_MERGE_RECEIPT_V1.json').open('x') as f:json.dump(receipt,f,indent=2)
print(manifest['status'],manifest['bytes'],manifest['sha256'],len(members))
