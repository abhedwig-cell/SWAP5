"""Fetch full original GitHub job log after connector transport-size failure."""
import argparse,subprocess,os,http.client,json,urllib.request,urllib.parse,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--job',type=int,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root='C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01'
r=subprocess.run(['git','credential','fill'],cwd=root,input=b'protocol=https\nhost=github.com\npath=abhedwig-cell/SWAP5.git\n\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'),timeout=30)
if r.returncode:raise RuntimeError('Existing repository authentication unavailable; no credentials printed')
values=dict(line.split(b'=',1) for line in r.stdout.splitlines() if b'=' in line)
token=values.get(b'password')
if not token:raise RuntimeError('Repository credential has no API secret; no credentials printed')
connection=http.client.HTTPSConnection('api.github.com',timeout=60)
connection.request('GET','/repos/abhedwig-cell/SWAP5/actions/jobs/'+str(a.job)+'/logs',headers={'Authorization':'Bearer '+token.decode(),'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWAP5-qualified-evidence-log-preservation'})
response=connection.getresponse();status=response.status;location=response.getheader('Location');raw=response.read();connection.close()
del token,values,r
if status in (301,302,303,307,308):
 parsed=urllib.parse.urlparse(location or '')
 if parsed.scheme!='https' or not parsed.hostname:raise RuntimeError('Invalid GitHub-issued signed log redirect')
 # The second request has no repository credentials or Authorization header.
 with urllib.request.urlopen(urllib.request.Request(location,headers={'Accept-Encoding':'identity'}),timeout=120) as stream:
  if stream.status!=200:raise RuntimeError('Signed original log download failed')
  raw=stream.read();kind=stream.headers.get('Content-Type','')
else:
 if status!=200:raise RuntimeError('GitHub original log HTTP '+str(status))
 kind='API-direct'
text=raw.decode('utf8')
with a.output.open('xb') as out:out.write(raw)
candidate='27d155ebd1ae7a8604c2b16baf585c3b986ef96d';synthetic='149b877c27b3e3016c6719d6d20e104e6693cb46'
record=dict(job_id=a.job,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),transport='Original authenticated GitHub job-log endpoint; credential-free signed second request',content_type=kind,actual_candidate=candidate,actual_synthetic=synthetic,actual_candidate_in_original_log=candidate in text,actual_synthetic_in_original_log=synthetic in text,full_original_response_preserved_before_context_verification=True)
record['status']='ORIGINAL_EXACT_HEAD_AND_SYNTHETIC_CI_JOB_LOG_PRESERVED' if candidate in text and synthetic in text else 'ORIGINAL_CI_JOB_LOG_CONTEXT_NOT_YET_VERIFIED'
with a.output.with_suffix(a.output.suffix+'.json').open('x') as out:json.dump(record,out,indent=2)
print(json.dumps(record))
assert candidate in text and synthetic in text,'Original log context did not prove both expected candidate and actual synthetic SHA; bytes retained for investigation'

