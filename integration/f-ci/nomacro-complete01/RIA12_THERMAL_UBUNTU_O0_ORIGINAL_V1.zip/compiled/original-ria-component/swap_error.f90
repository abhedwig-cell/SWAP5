    subroutine swap_error (routine, message)
      
      use MOD_swap_base, only: toscr, unit_err
      
      implicit none
      
      character(len=*), intent(in) :: routine, message
      
      ! overrule log-file with err-file
      call messini (toscr, .TRUE., unit_err)

      ! error message
      call fatalerr (routine, message)

    end
