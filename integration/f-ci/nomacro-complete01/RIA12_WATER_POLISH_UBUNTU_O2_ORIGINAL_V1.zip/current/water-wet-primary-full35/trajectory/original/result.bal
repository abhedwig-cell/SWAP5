* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-24 13:16:17

Period             :  1900-01-01  until  2002-02-04 
Depth soil profile :  200.00 cm

            Water storage
Final   :        73.63 cm
Initial :        80.90 cm
            =============
Change           -7.27 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     1.40    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.00
                             Crack flux        :     0.00
                             Drainage level 1  :     8.67
=========================    ============================
Sum            :     1.40    Sum               :     8.67
