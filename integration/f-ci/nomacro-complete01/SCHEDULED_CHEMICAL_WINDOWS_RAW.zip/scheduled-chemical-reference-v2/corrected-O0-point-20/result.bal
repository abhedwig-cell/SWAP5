* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-17 12:43:34

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.01 cm       0.7584E+01 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.82 cm       0.7584E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.03
SSDI           :     0.40
Irrigation     :     0.00    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    30.76
=========================    ============================
Sum            :    84.58    Sum               :    81.76


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.8000E+01    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4156E+00
=========================    ============================
Sum         :  0.8000E+01    Sum            :  0.4156E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.37 cm       0.2986E+02 mg/cm2
Initial :        78.01 cm       0.7584E+01 mg/cm2
            =============       =================
Change           -1.64 cm       0.2227E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.45
Runon          :     0.00    Runoff            :     0.00
SSDI           :     1.30
Irrigation     :     0.00    Transpiration     :    21.40
Bottom flux    :     0.00    Soil evaporation  :    13.73
                             Crack flux        :     0.00
                             Drainage level 1  :    33.33
=========================    ============================
Sum            :    73.28    Sum               :    74.92


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.2600E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.3725E+01
=========================    ============================
Sum         :  0.2600E+02    Sum            :  0.3725E+01


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.02 cm       0.5029E+02 mg/cm2
Initial :        76.37 cm       0.2986E+02 mg/cm2
            =============       =================
Change           -0.35 cm       0.2043E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     1.50
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.41
                             Crack flux        :     0.00
                             Drainage level 1  :    24.32
=========================    ============================
Sum            :    82.05    Sum               :    82.40


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.3000E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.9568E+01
=========================    ============================
Sum         :  0.3000E+02    Sum            :  0.9568E+01

