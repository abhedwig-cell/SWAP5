* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-17 12:43:57

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.01 cm       0.0000E+00 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.82 cm       0.0000E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     0.03
SSDI           :     0.90
Irrigation     :     0.00    Transpiration     :    34.73
Bottom flux    :     0.00    Soil evaporation  :    11.99
                             Crack flux        :     0.00
                             Drainage level 1  :    31.26
=========================    ============================
Sum            :    85.08    Sum               :    82.26


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.0000E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.38 cm       0.0000E+00 mg/cm2
Initial :        78.01 cm       0.0000E+00 mg/cm2
            =============       =================
Change           -1.63 cm       0.0000E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     6.49
Runon          :     0.00    Runoff            :     0.00
SSDI           :     3.90
Irrigation     :     0.00    Transpiration     :    22.64
Bottom flux    :     0.00    Soil evaporation  :    13.80
                             Crack flux        :     0.00
                             Drainage level 1  :    34.57
=========================    ============================
Sum            :    75.88    Sum               :    77.51


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.02 cm       0.0000E+00 mg/cm2
Initial :        76.38 cm       0.0000E+00 mg/cm2
            =============       =================
Change           -0.36 cm       0.0000E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :    11.52
Runon          :     0.00    Runoff            :     0.00
SSDI           :     3.90
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.48
                             Crack flux        :     0.00
                             Drainage level 1  :    26.66
=========================    ============================
Sum            :    84.45    Sum               :    84.81


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.0000E+00

