"""Current actual paired9/M1 generated and whole compiled source preservation."""
import argparse,json,sys,subprocess,time
from pathlib import Path
from contextlib import ExitStack
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');E=Path(__file__).resolve().parent;P=R/'integration/f-ci/nomacro-complete01';sys.path[:0]=[str(R/'app/hybrid_water'),str(R/'tests/nomacro_drainage')]
from snow58_analytical_source import complete_inverse,git
from analytical_hydraulic_archives import Archive,SHA
from snow58_compiled_postimage import compare
import experimental_project
p=argparse.ArgumentParser();p.add_argument('--optimization',choices=('O0','O2'),required=True);p.add_argument('--build-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();complete_inverse();head=git('rev-parse','HEAD').decode().strip();a.output.mkdir();cases=[];started=time.perf_counter()
with ExitStack() as stack:
 guard=Archive(P,'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_CURRENT_GUARD_WINDOWS_RAW_V1',stack)
 for model,kind in ((7,'water'),(11,'cde')):
  name='model'+str(model)+'-'+kind+'-'+a.optimization;member='profiles/sna-guard-Windows-'+a.optimization+'-v1/'+name+'/RESULT.json';raw=guard.get(member);q=json.loads(raw);cases.append(dict(label='existing9-'+name,baseline_build=q['build_root'],baseline_BUILD_sha256=q['actual_BUILD_sha256'],input_root=q['input_root'],baseline_source=q['source'],original_archive_sha256=guard.record['sha256'],original_member=member,original_metadata_sha256=SHA(raw)))
 legacy=Archive(P,'EXPLICIT_BOTTOM9_SNOW_ANALYTICAL_WINDOWS_POSITIVE505_RAW_V1',stack);member='preservation/explicit-bottom9-snow-analytical-legacy-model1-postimages-'+a.optimization+'-v1/RESULT.json';group=json.loads(legacy.get(member))
 for entry in group['contexts']:
  member='preservation/explicit-bottom9-snow-analytical-legacy-model1-postimages-'+a.optimization+'-v1/'+entry['label']+'/RESULT.json';raw=legacy.get(member);q=json.loads(raw);cases.append(dict(label='existingM1-'+entry['label'],baseline_build=q['build_root'],baseline_BUILD_sha256=q['actual_BUILD_sha256'],input_root=q['input_root'],baseline_source=q['current_source'],original_archive_sha256=legacy.record['sha256'],original_member=member,original_metadata_sha256=SHA(raw)))
assert len(cases)==6;q=dict(status='RUNNING',actual_current_source=head,optimization=a.optimization,contexts=[],model_executions=0,canonical_admission=False)
def save():(a.output/'RESULT.json').write_text(json.dumps(q,indent=2)+'\n')
save()
try:
 for case in cases:
  old=Path(case['baseline_build']);assert SHA((old/'BUILD.json').read_bytes())==case['baseline_BUILD_sha256'];inputs=Path(case['input_root']);project=experimental_project.load(inputs,original_output=True,time_step_policy='original-adaptive-day-seed-v1');label=case['label'];out=a.output/label;out.mkdir();bundle=a.build_root/label/'bundle'
  command=[sys.executable,'-B','tools/solute/run_water.py','--model',project.model,'--experimental-project',str(inputs),'--original-output','--experimental-time-step-policy',project.time_step_policy,'--reference-work','C:/Users/Veldh012/swap5-coverage-evidence/J_windows_provider','--build-only','--donor-opt',a.optimization,'--kernel-opt',a.optimization,'--output',str(bundle)]
  with (out/'build.stdout').open('xb') as stdout,(out/'build.stderr').open('xb') as stderr:r=subprocess.run(command,cwd=R,stdout=stdout,stderr=stderr,timeout=300)
  r.check_returncode();assert git('rev-parse','HEAD').decode().strip()==head
  files=lambda root:{p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in ('.f90','.f','.for','.inc')}
  before,after=files(old),files(bundle);assert before.keys()==after.keys();sources=[]
  for name,path in sorted(before.items()):
   left,right=path.read_bytes(),after[name].read_bytes();assert left.replace(b'\r\n',b'\n')==right.replace(b'\r\n',b'\n'),'Changed nonselected complete generated source '+label+'/'+name;sources.append(dict(file=name,old_sha256=SHA(left),current_sha256=SHA(right)))
  compiled=compare(old,bundle);record=dict(status='ACTUAL_UNSELECTED_EXISTING9_OR_MODEL1_WHOLE_GENERATED_COMPILED_PRESERVED_NO_MODEL_PERIOD',source=head,case=case,actual_current_build_root=str(bundle),actual_current_BUILD_sha256=SHA((bundle/'BUILD.json').read_bytes()),generated_sources=sources,compiled=compiled,model_executions=0)
  (out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');q['contexts'].append(dict(label=label,result=str(out/'RESULT.json'),build_root=str(bundle)));save();print('ACTUAL_UNSELECTED_SOURCE_COMPILED_PRESERVED',label,flush=True)
 q.update(status='ALL6_EXISTING9_MODEL1_CURRENT_WHOLE_GENERATED_AND_COMPILED_PRESERVATION_PASS_NO_MODEL_PERIOD',seconds=time.perf_counter()-started)
finally:save()
print(q['status'],a.optimization,flush=True)
