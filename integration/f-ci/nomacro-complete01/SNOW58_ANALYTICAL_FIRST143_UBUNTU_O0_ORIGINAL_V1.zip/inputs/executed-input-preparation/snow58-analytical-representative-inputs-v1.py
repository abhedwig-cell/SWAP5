"""Preserve source inputs and select six discriminating original-state contexts."""
import json,re,subprocess,zipfile,io,hashlib
from pathlib import Path
R=Path('C:/Users/Veldh012/swap5-nomacro-scheduled-chemical01');P=R/'integration/f-ci/nomacro-complete01';E=Path(__file__).resolve().parent;SHA=lambda b:hashlib.sha256(b).hexdigest()
original=json.loads((P/'SNOW_UNDRAINED_WINDOWS_SUPPORT_RAW_ARCHIVE.json').read_text());blob=subprocess.check_output(['git','show','HEAD:integration/f-ci/nomacro-complete01/'+original['archive']],cwd=R);assert len(blob)==original['bytes'] and SHA(blob)==original['sha256'];member='profiles/snow-undrained-baseline-v1/water-explicit-head-interval/swap.swp'
with zipfile.ZipFile(io.BytesIO(blob)) as z:old=z.read(member)
assert SHA(old)==original['members'][member]['sha256'];wet_gwli=re.findall(rb'(?mi)^[ \t]*GWLI[ \t]*=[ \t]*([^!\r\n]+)',old);assert len(wet_gwli)==1 and wet_gwli[0].strip()==b'-75.0'
table_pattern=rb'(?ms)^[ \t]*HTB[ \t]*=[^\n]*\n.*?^\* End of table[^\n]*';tables=re.findall(table_pattern,old);assert len(tables)==1;wet_table=tables[0]
prepared=E/'snow58-analytical-input-discovery-v1';derived=[]
for label,base,field in [('model11-cde-wet-initial2',prepared/'bottom8-model11-cde-initial2','GWLI'),('model3-water-wet-initial1',prepared/'bottom8-model3-water-initial1','HTB')]:
 folder=E/('snow58-analytical-bottom8-'+label+'-v1');folder.mkdir();files={}
 for path in base.iterdir():
  if not path.is_file():continue
  raw=path.read_bytes()
  if path.name=='swap.swp':
   if field=='GWLI':raw,count=re.subn(rb'(?mi)^([ \t]*GWLI[ \t]*=[ \t]*)[^!\r\n]*',lambda m:m[1]+wet_gwli[0].strip()+b' ',raw)
   else:raw,count=re.subn(table_pattern,lambda m:wet_table,raw)
   assert count==1
  (folder/path.name).write_bytes(raw);files[path.name]=dict(bytes=len(raw),sha256=SHA(raw))
 assert len(files)==10;derived.append(dict(role=label,input_root=str(folder),parent_input_root=str(base),only_changed_active_field=field,original_archive_sha256=original['sha256'],original_member=member,original_member_sha256=SHA(old),original_table_present_under_SWINCO=2,new_SWINCO=2 if field=='GWLI' else 1,all_numeric_spellings_copied=True,files=files))
cases=[dict(case='bottom5-model7-water-dry-initial1',bottom=5,model=7,kind='water',initial=1,input_root=str(prepared/'bottom5-model7-water-initial1'),reuse_short_profiles={o:str(E/('snow58-analytical7-water-bottom5-'+o+'-preflight-v1')) for o in ('O0','O2')}),dict(case='bottom8-model7-water-wet-initial2',bottom=8,model=7,kind='water',initial=2,input_root=str(E/'snow58-analytical7-water-bottom8-original-wet-initial2-v1'),requires_actual_lysimeter_outflow=True,reuse_short_profiles={o:str(E/('snow58-analytical7-water-bottom8-wet-'+o+'-preflight-v1')) for o in ('O0','O2')}),dict(case='bottom5-model3-cde-dry-initial1',bottom=5,model=3,kind='cde',initial=1,input_root=str(prepared/'bottom5-model3-cde-initial1'),requires_actual_incoming_tracer=True),dict(case='bottom8-model11-cde-wet-initial2',bottom=8,model=11,kind='cde',initial=2,input_root=derived[0]['input_root'],requires_actual_lysimeter_outflow=True,requires_actual_incoming_tracer=True),dict(case='bottom8-model3-water-wet-initial1',bottom=8,model=3,kind='water',initial=1,input_root=derived[1]['input_root'],requires_actual_lysimeter_outflow=True),dict(case='bottom5-model11-water-dry-initial1',bottom=5,model=11,kind='water',initial=1,input_root=str(prepared/'bottom5-model11-water-initial1'))]
members={};role_roots={'prepared/'+p.name:p for p in prepared.iterdir() if p.is_dir()};role_roots.update({'derived/'+x['role']:Path(x['input_root']) for x in derived});role_roots['derived/model7-water-wet-initial2']=E/'snow58-analytical7-water-bottom8-original-wet-initial2-v1'
name='SNOW58_ANALYTICAL_INPUTS_V1';archive=P/(name+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for role,folder in sorted(role_roots.items()):
  files=[p for p in sorted(folder.iterdir()) if p.is_file()];assert len(files)==10
  for path in files:
   key=role+'/'+path.name;raw=path.read_bytes();z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
 raw=Path(__file__).read_bytes();key='executed-input-preparation/'+Path(__file__).name;z.writestr(key,raw);members[key]=dict(bytes=len(raw),sha256=SHA(raw))
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(members)
 for key,item in members.items():raw=z.read(key);assert len(raw)==item['bytes'] and SHA(raw)==item['sha256']
raw=archive.read_bytes();record=dict(status='ACTUAL_SOURCE_INPUTS_PRESERVED_SIX_REPRESENTATIVES_SELECTED_NOT_NEW_QUALIFICATION',source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),archive=archive.name,bytes=len(raw),sha256=SHA(raw),parts=[dict(file=archive.name,bytes=len(raw),sha256=SHA(raw))],members=members,roles={name:str(path) for name,path in role_roots.items()},derived_original_wet_inputs=derived,cases=cases,selected_platforms=['Windows','Ubuntu'],selected_optimizations=['O0','O2'],selected_full35_contexts=24,compiler_executions=0,model_executions=0,canonical_admission=False)
(P/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(record['status'],len(members),len(raw),record['sha256'])
