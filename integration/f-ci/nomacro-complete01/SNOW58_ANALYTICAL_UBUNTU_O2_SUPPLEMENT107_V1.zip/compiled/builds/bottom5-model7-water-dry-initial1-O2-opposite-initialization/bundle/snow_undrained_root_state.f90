module hybrid_snow_analytical_native
  use MOD_grid,only:numnod,numlay
  use MOD_swap_base,only:swmacro,swsolu,swsnow,swfrost,swhyst,swdra,swhea,swcalt
  use MOD_MvG,only:iHWCKmodel,swsophy
  use WC_K_models_04_11,only:NoVap
  use variables,only:swkimpl,swbotb
  implicit none
  private
  public::snow_analytical_domain_checkpoint
contains
  subroutine snow_analytical_domain_checkpoint(unit,restoring)
    integer,intent(in)::unit
    logical,intent(in)::restoring
    integer,allocatable::expected(:),header(:),witness(:)
    integer::n,ios
    if(numnod<1.or.numlay<1.or.numlay>size(iHWCKmodel).or.swmacro/=0.or.swsolu<0.or.swsolu>1.or. &
       swsnow/=1.or.swfrost/=0.or.swhyst/=0.or.swdra/=0.or.swhea/=1.or.swcalt/=2.or. &
       swsophy/=0.or.swkimpl/=0.or.swbotb/=5)error stop 'Foreign analytical Snow native domain'
    if(any(iHWCKmodel(1:numlay)<1).or.any(iHWCKmodel(1:numlay)>11).or. &
       any(iHWCKmodel(1:numlay)==2).or.all(iHWCKmodel(1:numlay)==1)) &
       error stop 'Foreign analytical Snow native constitutive models'
    if(any((iHWCKmodel(1:numlay)>=8).and.(.not.NoVap(1:numlay)))) &
       error stop 'Active vapor cannot use analytical Snow native'
    n=4+numlay;allocate(expected(n),header(n),witness(n))
    expected(1:4)=[1,numnod,numlay,swsolu]
    expected(5:n)=iHWCKmodel(1:numlay)
    if(restoring)then
      read(unit,iostat=ios)header,witness
      if(ios/=0)error stop 'Incomplete analytical Snow native model domain'
      if(any(header/=expected).or.any(witness/=expected)) &
        error stop 'Foreign analytical Snow native model witness'
    else
      write(unit)expected,expected
    end if
  end subroutine
end module

module hybrid_snow_undrained_root_state
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  use MOD_grid, only: numnod
  use MOD_swap_base, only: swsolu,swsnow,swhyst
  use variables, only: swbotb,swkimpl
  use MOD_re_global, only: alpwetnoddrz,alpdrynodrtz
  use hybrid_snow_analytical_native,only:snow_analytical_domain_checkpoint
  implicit none
  private
  public :: snow_undrained_root_checkpoint
contains
  subroutine snow_undrained_root_checkpoint(unit,restoring,clock)
    integer,intent(in)::unit
    logical,intent(in)::restoring
    real(8),intent(in)::clock
    integer::expected(8),header(8),witness(8),ios
    real(8)::values(2),copy(2)
    if(swsolu/=0.or.swsnow/=1.or.swkimpl/=0.or.(swbotb/=5.and.swbotb/=8)) &
      error stop 'Foreign implicit Snow root diagnostic domain'
    call snow_analytical_domain_checkpoint(unit,restoring)
    expected=[3,numnod,swsolu,swsnow,swhyst,swbotb,swkimpl,0]
    if(restoring)then
      read(unit,iostat=ios)header,witness
      if(ios/=0)error stop 'Incomplete implicit Snow root diagnostic domain'
      if(any(header/=expected).or.any(witness/=expected))error stop 'Foreign implicit Snow root diagnostic witness'
      read(unit,iostat=ios)values,copy
      if(ios/=0)error stop 'Incomplete implicit Snow root diagnostic values'
      if(any(values/=copy).or..not.all(ieee_is_finite(values))) &
        error stop 'Invalid implicit Snow root diagnostic values'
      alpwetnoddrz=values(1)
      alpdrynodrtz=values(2)
    else
      values=[alpwetnoddrz,alpdrynodrtz]
      if(.not.all(ieee_is_finite(values)))error stop 'Nonfinite implicit Snow root diagnostic values'
      write(unit)expected,expected
      write(unit)values,values
      write(*,'(a,3(1x,es25.17e3))')'HYBRID_UNDRAINED_SNOW_ROOT_NATIVE',clock,values
    end if
  end subroutine
end module
