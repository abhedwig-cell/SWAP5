"""Observe the actual public command without checkout or producer rebinding."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--cwd',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
def git(*args):return subprocess.check_output(['git',*args],cwd=a.cwd,text=True).strip()
def snapshot():
 sparse=Path(git('rev-parse','--git-path','info/sparse-checkout'))
 if not sparse.is_absolute():sparse=a.cwd/sparse
 return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain'),sparse=sparse.read_text(encoding='utf-8').splitlines())
command=[sys.executable,'-B','tests/hupsel51/verify_successor.py'];before=snapshot();assert before['status']=='' and len(before['sparse'])==29
q=dict(command=command,cwd='.',before=before,model_executions=0,compiler_executions=0)
started=time.perf_counter()
with a.output.with_suffix('.stdout.txt').open('x',encoding='utf-8') as out,a.output.with_suffix('.stderr.txt').open('x',encoding='utf-8') as err:
 result=subprocess.run(command,cwd=a.cwd,stdout=out,stderr=err,timeout=1200)
q.update(returncode=result.returncode,seconds=time.perf_counter()-started,after=snapshot());assert q['before']==q['after']
with a.output.with_suffix('.json').open('x',encoding='utf-8') as out:json.dump(q,out,indent=2);out.write('\n')
print(q['returncode'],q['seconds'],q['before']['head'],flush=True)
