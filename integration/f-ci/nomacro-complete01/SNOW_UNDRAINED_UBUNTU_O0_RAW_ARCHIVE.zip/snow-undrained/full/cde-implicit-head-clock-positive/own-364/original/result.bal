* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 17:10:15

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        42.77 cm       0.7657E+00 mg/cm2
Initial :        72.37 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -29.59 cm       0.7657E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :    41.04
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    19.26
Bottom flux    :   -67.27    Soil evaporation  :     6.38
                             Crack flux        :     0.00
=========================    ============================
Sum            :    19.31    Sum               :    70.91


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.7658E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.5988E-04
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.7657E+00    Sum            :  0.0000E+00

