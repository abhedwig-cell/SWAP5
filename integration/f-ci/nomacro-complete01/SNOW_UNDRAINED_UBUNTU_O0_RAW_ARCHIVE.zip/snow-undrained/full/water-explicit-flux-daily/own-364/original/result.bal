* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 17:06:37

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        38.74 cm
Initial :        75.19 cm
            =============
Change          -36.45 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.32
Runon          :     0.00    Runoff            :    40.97
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    19.03
Bottom flux    :   -74.41    Soil evaporation  :     6.30
                             Crack flux        :     0.00
=========================    ============================
Sum            :    12.17    Sum               :    70.62
