* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 17:04:44

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        38.74 cm
Initial :        97.19 cm
            =============
Change          -58.45 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.32
Runon          :     0.00    Runoff            :    40.97
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    19.03
Bottom flux    :   -74.41    Soil evaporation  :     6.30
                             Crack flux        :     0.00
=========================    ============================
Sum            :    12.17    Sum               :    70.62

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        43.57 cm
Initial :        38.74 cm
            =============
Change            4.83 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     0.12
Runon          :     0.00    Runoff            :    46.78
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     4.99    Soil evaporation  :    25.24
                             Crack flux        :     0.00
=========================    ============================
Sum            :    76.97    Sum               :    72.14

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        46.26 cm
Initial :        43.57 cm
            =============
Change            2.68 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :     0.93
Runon          :     0.00    Runoff            :    49.67
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     2.63    Soil evaporation  :    29.90
                             Crack flux        :     0.00
=========================    ============================
Sum            :    83.18    Sum               :    80.50
