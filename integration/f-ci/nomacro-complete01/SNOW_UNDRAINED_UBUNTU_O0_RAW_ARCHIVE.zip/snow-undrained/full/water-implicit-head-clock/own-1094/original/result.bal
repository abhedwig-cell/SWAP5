* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 17:07:20

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        42.66 cm
Initial :        42.61 cm
            =============
Change            0.05 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :     0.93
Runon          :     0.00    Runoff            :    49.65
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -0.00    Soil evaporation  :    29.92
                             Crack flux        :     0.00
=========================    ============================
Sum            :    80.55    Sum               :    80.50
