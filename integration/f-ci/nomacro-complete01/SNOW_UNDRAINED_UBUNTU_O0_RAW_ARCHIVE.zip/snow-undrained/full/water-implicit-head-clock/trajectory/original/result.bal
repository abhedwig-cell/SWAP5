* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 17:06:40

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        42.77 cm
Initial :        97.19 cm
            =============
Change          -54.41 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :    41.04
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    19.27
Bottom flux    :   -70.08    Soil evaporation  :     6.38
                             Crack flux        :     0.00
=========================    ============================
Sum            :    16.50    Sum               :    70.91

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        42.61 cm
Initial :        42.77 cm
            =============
Change           -0.17 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     0.12
Runon          :     0.00    Runoff            :    46.77
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -0.00    Soil evaporation  :    25.25
                             Crack flux        :     0.00
=========================    ============================
Sum            :    71.98    Sum               :    72.15

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        42.66 cm
Initial :        42.61 cm
            =============
Change            0.05 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :     0.93
Runon          :     0.00    Runoff            :    49.65
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -0.00    Soil evaporation  :    29.92
                             Crack flux        :     0.00
=========================    ============================
Sum            :    80.55    Sum               :    80.50
