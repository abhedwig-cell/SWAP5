* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 17:12:21

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        38.74 cm       0.3618E+00 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -36.45 cm       0.3618E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.32
Runon          :     0.00    Runoff            :    40.97
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    19.03
Bottom flux    :   -74.41    Soil evaporation  :     6.30
                             Crack flux        :     0.00
=========================    ============================
Sum            :    12.17    Sum               :    70.62


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.3618E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.3618E+00    Sum            :  0.0000E+00

