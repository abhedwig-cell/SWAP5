* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 17:09:58

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        38.74 cm       0.3618E+00 mg/cm2
Initial :        97.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -58.45 cm       0.3618E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.32
Runon          :     0.00    Runoff            :    40.97
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    19.03
Bottom flux    :   -74.41    Soil evaporation  :     6.30
                             Crack flux        :     0.00
=========================    ============================
Sum            :    12.17    Sum               :    70.62


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.3618E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.3618E+00    Sum            :  0.0000E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        43.57 cm       0.8609E+00 mg/cm2
Initial :        38.74 cm       0.3618E+00 mg/cm2
            =============       =================
Change            4.83 cm       0.4991E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     0.12
Runon          :     0.00    Runoff            :    46.78
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     4.99    Soil evaporation  :    25.24
                             Crack flux        :     0.00
=========================    ============================
Sum            :    76.97    Sum               :    72.14


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.4991E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.4991E+00    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        46.26 cm       0.1124E+01 mg/cm2
Initial :        43.57 cm       0.8609E+00 mg/cm2
            =============       =================
Change            2.68 cm       0.2629E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :     0.93
Runon          :     0.00    Runoff            :    49.67
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     2.63    Soil evaporation  :    29.90
                             Crack flux        :     0.00
=========================    ============================
Sum            :    83.18    Sum               :    80.50


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.2629E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.2629E+00    Sum            :  0.0000E+00

