* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 17:09:55

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        42.77 cm
Initial :        75.19 cm
            =============
Change          -32.41 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :    41.04
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    19.27
Bottom flux    :   -70.08    Soil evaporation  :     6.38
                             Crack flux        :     0.00
=========================    ============================
Sum            :    16.50    Sum               :    70.91
