import argparse,json,os,subprocess,sys,time
from pathlib import Path

p=argparse.ArgumentParser()
for key in ('checkout','output','head'):p.add_argument('--'+key,required=True)
p.add_argument('--refusal');a=p.parse_args();root=Path(a.checkout);out=Path(a.output)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def snapshot():return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain'),sparse=git('sparse-checkout','list').splitlines())
before=snapshot();assert before['head']==a.head and before['status']=='' and len(before['sparse'])==28
command=[sys.executable,'-B','tests/hupsel51/verify_successor.py'];start=time.monotonic()
with Path(str(out)+'.stdout.txt').open('xb') as stdout,Path(str(out)+'.stderr.txt').open('xb') as stderr:
    result=subprocess.run(command,cwd=root,stdout=stdout,stderr=stderr,timeout=2400)
after=snapshot();q=dict(command=command,cwd=str(root),before=before,after=after,returncode=result.returncode,
    elapsed_seconds=time.monotonic()-start,model_executions=0)
assert before==after
stdout=Path(str(out)+'.stdout.txt').read_text(encoding='utf-8');stderr=Path(str(out)+'.stderr.txt').read_text(encoding='utf-8')
q.update(stdout_bytes=Path(str(out)+'.stdout.txt').stat().st_size,stderr_bytes=Path(str(out)+'.stderr.txt').stat().st_size)
if a.refusal:
    q['expected_refusal']=a.refusal;q['status']='ACTUAL_CLEAN28_COMMITTED_PUBLIC_NEGATIVE_REFUSED' if result.returncode!=0 and a.refusal in stdout+stderr else 'FAILED_NEGATIVE'
else:
    q['status']='ACTUAL_CLEAN28_REGISTERED_PUBLIC_WATER_SNOW_GROUNDWATER_PASS' if result.returncode==0 and json.loads(stdout)['status']=='BOUNDED_WATER_SNOW_GROUNDWATER_SOURCE_RAW_ADMISSION_PASS' else 'FAILED_PUBLIC'
with Path(str(out)+'.json').open('x',encoding='utf-8') as f:json.dump(q,f,indent=2);f.write('\n')
print(q['status'],q['elapsed_seconds'],flush=True)
assert q['status'].startswith('ACTUAL_'),q
