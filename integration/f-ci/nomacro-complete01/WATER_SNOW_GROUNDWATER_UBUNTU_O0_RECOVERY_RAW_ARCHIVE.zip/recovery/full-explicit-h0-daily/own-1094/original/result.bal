* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 14:35:08

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        74.56 cm
Initial :        74.48 cm
            =============
Change            0.08 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :    11.51
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -36.73    Soil evaporation  :     0.07
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    43.82    Sum               :    43.74
