* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 14:34:34

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        74.83 cm
Initial :        69.19 cm
            =============
Change            5.64 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :     0.08
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    34.32
Bottom flux    :   -63.87    Soil evaporation  :     0.18
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :    22.71    Sum               :    39.07
