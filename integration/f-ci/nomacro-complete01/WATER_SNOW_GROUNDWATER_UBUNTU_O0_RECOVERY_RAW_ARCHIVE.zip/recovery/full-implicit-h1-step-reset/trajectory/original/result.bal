* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 14:33:58

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        74.83 cm
Initial :        91.19 cm
            =============
Change          -16.36 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :     0.08
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    34.32
Bottom flux    :   -63.87    Soil evaporation  :     0.18
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :    22.71    Sum               :    39.07

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        68.07 cm
Initial :        74.83 cm
            =============
Change           -6.76 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     5.64
Runon          :     0.00    Runoff            :    24.38
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     9.52
Bottom flux    :   -32.45    Soil evaporation  :     6.76
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    39.53    Sum               :    46.30

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        67.94 cm
Initial :        68.07 cm
            =============
Change           -0.13 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :     0.99
Runon          :     0.00    Runoff            :    49.68
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.27
Bottom flux    :     0.03    Soil evaporation  :    29.79
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    80.58    Sum               :    80.72
