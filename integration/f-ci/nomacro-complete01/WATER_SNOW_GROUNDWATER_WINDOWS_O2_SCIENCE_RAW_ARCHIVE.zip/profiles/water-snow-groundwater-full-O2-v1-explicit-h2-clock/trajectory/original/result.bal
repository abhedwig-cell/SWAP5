* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-20 14:37:17

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        74.80 cm
Initial :        95.20 cm
            =============
Change          -20.40 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.22
Runon          :     0.00    Runoff            :     0.00
SSDI           :     2.40
Irrigation     :     0.00    Transpiration     :    34.30
Bottom flux    :   -68.01    Soil evaporation  :     0.19
                             Crack flux        :     0.00
                             Drainage level 1  :     0.26
=========================    ============================
Sum            :    18.57    Sum               :    38.97

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        73.95 cm
Initial :        74.80 cm
            =============
Change           -0.85 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     6.41
Runon          :     0.00    Runoff            :     1.86
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    19.16
Bottom flux    :   -43.51    Soil evaporation  :     1.90
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    28.47    Sum               :    29.33

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        73.91 cm
Initial :        73.95 cm
            =============
Change           -0.04 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :    11.51
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :   -36.85    Soil evaporation  :     0.06
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    43.70    Sum               :    43.73
