* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 14:22:25

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.00 cm       0.3679E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.81 cm       0.3679E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.01
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    37.24
Bottom flux    :     0.00    Soil evaporation  :    10.11
                             Crack flux        :     0.00
                             Drainage level 1  :    36.40
=========================    ============================
Sum            :    86.58    Sum               :    83.77


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1121E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.1121E+02

