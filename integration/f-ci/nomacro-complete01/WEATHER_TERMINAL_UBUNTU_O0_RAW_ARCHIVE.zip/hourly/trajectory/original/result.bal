* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 13:46:40

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.00 cm       0.3679E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.81 cm       0.3679E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.01
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    37.24
Bottom flux    :     0.00    Soil evaporation  :    10.11
                             Crack flux        :     0.00
                             Drainage level 1  :    36.40
=========================    ============================
Sum            :    86.58    Sum               :    83.77


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1121E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.1121E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.32 cm       0.1986E+02 mg/cm2
Initial :        78.00 cm       0.3679E+02 mg/cm2
            =============       =================
Change           -1.68 cm      -0.1692E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.00    Transpiration     :    30.52
Bottom flux    :     0.00    Soil evaporation  :    10.05
                             Crack flux        :     0.00
                             Drainage level 1  :    35.09
=========================    ============================
Sum            :    73.98    Sum               :    75.66


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1692E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1692E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.98 cm       0.1157E+02 mg/cm2
Initial :        76.32 cm       0.1986E+02 mg/cm2
            =============       =================
Change           -0.34 cm      -0.8295E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    39.64
Bottom flux    :     0.00    Soil evaporation  :    12.00
                             Crack flux        :     0.00
                             Drainage level 1  :    29.25
=========================    ============================
Sum            :    80.55    Sum               :    80.89


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.8295E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.8295E+01

