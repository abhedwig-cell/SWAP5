* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 13:46:06

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.92 cm       0.3889E+02 mg/cm2
Initial :        75.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change            2.73 cm       0.3889E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    84.18    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.07
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    37.75
Bottom flux    :     0.00    Soil evaporation  :    13.35
                             Crack flux        :     0.00
                             Drainage level 1  :    32.67
=========================    ============================
Sum            :    86.58    Sum               :    83.85


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.9108E+01
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.9108E+01


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.35 cm       0.2191E+02 mg/cm2
Initial :        77.92 cm       0.3889E+02 mg/cm2
            =============       =================
Change           -1.57 cm      -0.1699E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    71.98    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.08
SSDI           :     0.00
Irrigation     :     4.00    Transpiration     :    28.29
Bottom flux    :     0.00    Soil evaporation  :    16.03
                             Crack flux        :     0.00
                             Drainage level 1  :    33.15
=========================    ============================
Sum            :    75.98    Sum               :    77.55


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1699E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1699E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.02 cm       0.1417E+02 mg/cm2
Initial :        76.35 cm       0.2191E+02 mg/cm2
            =============       =================
Change           -0.33 cm      -0.7733E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    80.55    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    41.09
Bottom flux    :     0.00    Soil evaporation  :    16.18
                             Crack flux        :     0.00
                             Drainage level 1  :    23.61
=========================    ============================
Sum            :    80.55    Sum               :    80.88


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.7733E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.7733E+01

