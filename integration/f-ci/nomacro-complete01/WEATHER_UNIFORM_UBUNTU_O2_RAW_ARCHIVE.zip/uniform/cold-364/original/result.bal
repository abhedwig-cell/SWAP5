* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-19 13:59:18

Period             :  2002-12-31  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.01 cm       0.3809E+02 mg/cm2
Initial :        79.13 cm       0.3861E+02 mg/cm2
            =============       =================
Change           -1.12 cm      -0.5206E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     0.00    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.01
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.01
                             Crack flux        :     0.00
                             Drainage level 1  :     1.10
=========================    ============================
Sum            :     0.00    Sum               :     1.12


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.5206E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.5206E+00

