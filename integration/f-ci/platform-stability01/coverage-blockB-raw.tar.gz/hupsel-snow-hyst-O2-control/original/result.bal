* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 10:29:58

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.86 cm       0.2527E+02 mg/cm2
Initial :        94.37 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -16.51 cm       0.2527E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     5.48
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    46.69
=========================    ============================
Sum            :    86.58    Sum               :   103.09


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2273E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2273E+02


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.01 cm       0.1306E+02 mg/cm2
Initial :        77.86 cm       0.2527E+02 mg/cm2
            =============       =================
Change           -1.85 cm      -0.1221E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     6.83
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     8.00    Transpiration     :    24.33
Bottom flux    :     0.00    Soil evaporation  :    13.77
                             Crack flux        :     0.00
                             Drainage level 1  :    36.90
=========================    ============================
Sum            :    79.98    Sum               :    81.83


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1221E+02
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1221E+02


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        75.30 cm       0.8460E+01 mg/cm2
Initial :        76.01 cm       0.1306E+02 mg/cm2
            =============       =================
Change           -0.71 cm      -0.4597E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :    11.51
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    32.16
Bottom flux    :     0.00    Soil evaporation  :    14.18
                             Crack flux        :     0.00
                             Drainage level 1  :    23.41
=========================    ============================
Sum            :    80.55    Sum               :    81.26


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.4597E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.4597E+01

