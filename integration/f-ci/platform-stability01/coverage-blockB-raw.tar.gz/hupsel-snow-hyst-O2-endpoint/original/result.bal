* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-13 10:30:03

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        77.86 cm       0.2527E+02 mg/cm2
Initial :        94.37 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -16.51 cm       0.2527E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.25
Runon          :     0.00    Runoff            :     5.48
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    34.72
Bottom flux    :     0.00    Soil evaporation  :    11.95
                             Crack flux        :     0.00
                             Drainage level 1  :    46.69
=========================    ============================
Sum            :    86.58    Sum               :   103.09


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.2273E+02
=========================    ============================
Sum         :  0.4800E+02    Sum            :  0.2273E+02

