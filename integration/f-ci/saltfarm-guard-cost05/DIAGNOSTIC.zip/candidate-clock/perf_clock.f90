module perf_clock
implicit none
integer(8)::pc(17)=0,pt(17)=0,prate=0,pbegin,phead,piter,pnow,pguard,pnative,pserial
integer::pidx
end module
