module perf_clock
implicit none
integer(8)::pc(8)=0,pt(8)=0,prate=0,pbegin,phead,piter,pnow
integer::pidx
end module
