from pathlib import Path
import hashlib,json,re,shutil,subprocess,time
root=Path(r'C:\SWAP5-testing\saltfarm-rc3-cost02');case=root/'original-current';case.mkdir();full=Path(r'C:\SWAP5-testing\rc3-local01\saltfarm-O2-candidate-full');meta=json.loads(Path(r'C:\SWAP5-testing\rc3-local01\saltfarm-O2-candidate-build\BUILD.json').read_text());inventory={}
for n in meta['inputs']:
 p=case/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(full/'original'/n,p);inventory[n]=hashlib.sha256(p.read_bytes()).hexdigest()
exe=Path(r'C:\SWAP5-RC2\comparison431\swap431-common.exe');assert hashlib.sha256(exe.read_bytes()).hexdigest()=='d033b50a580fc847049cda141a0af9d1d65d54ced7228983dbbf3ac798bc53de'
start=time.perf_counter()
with (root/'original-current.stdout').open('wb') as out,(root/'original-current.stderr').open('wb') as err:r=subprocess.run([str(exe),'./swap.swp'],cwd=case,stdout=out,stderr=err,timeout=15)
wall=time.perf_counter()-start;assert r.returncode==100
old=Path(r'C:\SWAP5-RC2\comparison431\salt-original431-reused.csv');records=lambda p:[s for s in p.read_text().splitlines() if s.strip() and not s.startswith('*')];assert records(case/'result_output.csv')==records(old)
for n,h in inventory.items():assert hashlib.sha256((case/n).read_bytes()).hexdigest()==h
counts={}
for name,path in [('original',case/'swap.log'),('RC3',full/'original/swap.log')]:
 text=path.read_text();entries=[tuple(map(int,line.split())) for line in text.splitlines() if re.fullmatch(r'\s*\d+\s+\d+\s+\d+\s*',line)];counts[name]=dict(histogram=entries,solves=sum(v[1] for v in entries),newton_iterations=sum(v[0]*v[1] for v in entries),backtracks=sum(v[2] for v in entries))
result=dict(status='CURRENT_ORIGINAL_CONTROL_EXACT_TO_PRESERVED_INPUT_AND_CSV',wall_seconds=wall,input_sha256=inventory,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),command=[str(exe),'./swap.swp'],cwd=str(case),returncode=r.returncode,cap_seconds=15,counts=counts,interpretation='Same-session ordered cost control, not randomized paired accuracy-matched speed qualification')
(root/'ORIGINAL_CURRENT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
