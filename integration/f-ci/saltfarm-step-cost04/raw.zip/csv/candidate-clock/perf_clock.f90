module perf_clock
implicit none
integer(8)::pc(13)=0,pt(13)=0,prate=0,pbegin,phead,piter,pnow
integer::pidx
end module
