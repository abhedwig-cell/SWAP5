module perf07
implicit none
integer(8)::pc(26)=0,pt(26)=0,bt(26)=0,rate=0,now
contains
subroutine tick(i)
integer::i
call system_clock(bt(i),rate)
end subroutine
subroutine tock(i)
integer::i
call system_clock(now)
pc(i)=pc(i)+1;pt(i)=pt(i)+now-bt(i)
end subroutine
end module
