subroutine macro_replay_dump(tag,flux)
use MOD_macropore,only:NumDm,ICpBtDm,VlMpDmCp,WaUnMpDmCp,FlEndSrpEvt,ThtSrpRefDmCp,SorpDmCp,TimAbsCumDmCp, &
 VlMpDyCp,SubsidCp,FrMpWalWet,ICpBtDmPot,ICpTpWaSrDm,ZWaLevDm,ZBtDm,VlMpDm,VlMp,ArMpTp,ArMpTpDm, &
 ArMpSs,KsMpSs,FrArMtrx,WaSrMp,WaSrMpDm,WaUnMpDm,WaUnsat,QOutMtxSatDmCp,QOutMtxUnsDmCp, &
 QInMtxSatDmCp,QInIntSatDmCp,QInTopLatDm,QInTopVrtDm,QExcMpMtx
use MOD_grid,only:numnod
use variables,only:h,theta,gwl,pond,qrot,volact
implicit none
character(*),intent(in)::tag
logical,intent(in)::flux
integer::u
open(newunit=u,file='replay_'//tag//'_physical.bin',access='stream',form='unformatted',status='replace')
write(u)numnod,NumDm
write(u)ICpBtDm(1:NumDm)
write(u)VlMpDmCp(1:NumDm,1:NumNod)
write(u)WaUnMpDmCp(1:NumDm,1:NumNod)
write(u)FlEndSrpEvt(1:NumDm,1:NumNod)
write(u)ThtSrpRefDmCp(1:NumDm,1:NumNod)
write(u)SorpDmCp(1:NumDm,1:NumNod)
write(u)TimAbsCumDmCp(1:NumDm,1:NumNod)
write(u)VlMpDyCp(1:NumNod)
write(u)SubsidCp(1:NumNod)
write(u)FrMpWalWet(1:NumDm,1:NumNod)
write(u)ICpBtDmPot(1:NumDm)
write(u)ICpTpWaSrDm(1:NumDm)
write(u)ZWaLevDm(1:NumDm)
write(u)ZBtDm(1:NumDm)
write(u)VlMpDm(1:NumDm)
write(u)VlMp
write(u)ArMpTp
write(u)ArMpTpDm(1:NumDm)
write(u)ArMpSs
write(u)KsMpSs
write(u)FrArMtrx(1:NumNod)
write(u)WaSrMp
write(u)WaSrMpDm(1:NumDm)
write(u)WaUnMpDm(1:NumDm)
write(u)WaUnsat(1:NumDm)
close(u)
open(newunit=u,file='replay_'//tag//'_matrix.bin',access='stream',form='unformatted',status='replace')
write(u)h(1:numnod),theta(1:numnod),gwl,pond
close(u)
if(flux)then
 open(newunit=u,file='replay_'//tag//'_flux.bin',access='stream',form='unformatted',status='replace')
 write(u)QOutMtxSatDmCp(1:NumDm,1:numnod),QOutMtxUnsDmCp(1:NumDm,1:numnod), &
 QInMtxSatDmCp(1:NumDm,1:numnod),QInIntSatDmCp(1:NumDm,1:numnod),QInTopLatDm(1:NumDm),QInTopVrtDm(1:NumDm), &
 QExcMpMtx(1:numnod),qrot(1:numnod),volact
 close(u)
end if
end subroutine

