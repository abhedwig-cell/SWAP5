module MOD_irrigation
   
   use MOD_arrays, only: mairg, macp, maho 
   
   ! local, saved
   integer, dimension(2),      save :: nod_ssdi           ! upper and lower nodes where ssdi takes place

   real(8),                    save :: irr_depth          ! Amount of scheduled irirgation (input as mm, converted to cm)
   real(8),                    save :: irr_rate           ! Application rate (inputs as mm/h, converted to cm/d)

   ! --- irrigation variables
   integer,                    save :: dayfix             ! days since last irrigation event
   integer,                    save :: irrigevent         ! Switch: 0 = no irrigation; 1 = fixed irrigation event; 2 = scheduled irrigation event
   integer, dimension(mairg),  save :: irtype             ! Type of fixed irrigation: 0 = sprinkling irrigation; 1 = surface irrigation
   integer,                    save :: isua               ! Switch for type of irrigation: 0 = sprinkling irrigation, 1 = surface irrigation
   integer,                    save :: isuas              ! Switch for type of scheduled irrigation: 0 = sprinkling irrigation, 1 = surface irrigation
   integer,                    save :: nirri              ! Number of irrigation event
   integer,                    save :: schedule           ! Switch for simulation of irrigation scheduling: 0 = no, 1 = yes
   integer,                    save :: swcirrthres        ! Switch to allow over irrigation when a conc-threshold is exceeded: 0 = no; 1 = yes/allowed
   real(8),                    save :: cirr               ! Solute concentration of irrigation water (M/L3)
   real(8),                    save :: cirrs              ! Solute concentration of irrigation water (M/L3)
   real(8),                    save :: cirrthres          ! Threshold value (M/L3) indicating the concentration that initiates over irrigation
   real(8),                    save :: dcrit              ! Depth (L) of sensor for soil water pressure head or water content
   real(8), dimension(14),     save :: ditab              ! Array with amount of under- or over-irrigation (L) as function of crop development stage
   real(8), dimension(14),     save :: dwatab             ! Array with maximum amounts of water depleted as function of crop development stage
   real(8),                    save :: dt_irr_event       ! Length of SSDI irrigation event (T)
   real(8), dimension(14),     save :: fidtab             ! Array with prescribed fixed irrigation depth (L) as function of crop development stage
   real(8),                    save :: gird               ! Gross irrigation rate (L/T)
   real(8), dimension(14),     save :: hcritab            ! Array with minimum soil water pressure heads (L) as function of crop development stage
   real(8), dimension(mairg),  save :: irconc             ! Array with irrigation concentrations (M/L3) in case of fixed irrigation
   real(8), dimension(mairg),  save :: irdate             ! Array with fixed irrigation dates
   real(8), dimension(mairg),  save :: irrate             ! Array with fixed irrigation rates (mm/h)
   real(8), dimension(mairg),  save :: irdepth            ! Array with fixed irrigation depths (mm)
   real(8), dimension(2),      save :: ir_z               ! Depth (interval) in case of fixed irrigation with subsurface irrigation (cm)
   real(8),                    save :: nird               ! Net irrigation depth (L)
   real(8),                    save :: perirrsurp         ! percentage (-) of the scheduled irrigation depths that may be over irrigated
   real(8), dimension(macp),   save :: qssdi              ! Array with water input via subsurface drip irrigation for each compartment (L/T)
   real(8),                    save :: qssdisum           ! Total subsurface irrigation flux (L/T)
   real(8),                    save :: raithreshold       ! Threshold value (L) indicating the amount of rainfall which is substracted from scheduled irrigation depths
   real(8), dimension(14),     save :: rawtab             ! Array with minimum of readily available water as function of crop development stage
   real(8), dimension(14),     save :: tawtab             ! Array with minimum of totally available water as function of crop development stage
   real(8), dimension(14),     save :: tcritab            ! Array with minimum volumetric soil water contents as function of crop development stage
   real(8),                    save :: tstairrig          ! Date after which scheduled irrigation is allowed
   real(8),                    save :: tendirrig          ! Date after which scheduled irrigation is NOT allowed
   real(8), dimension(14),     save :: treltab            ! Array with minimum of ratio actual/potential transpiration as function of crop development stage
   logical,                    save :: flheadirg          ! Flag indicating that header should be printed in irrigation output file
   logical,                    save :: flirrigate         ! Flag indicating irrigation in simulation run (either fixed or scheduled)

   integer,                    save :: sw_irrig = 1
   real(8),                    save :: f_irr_avail = 1.0d0
   integer,                    save :: tcs
   integer,                    save :: tcsfix
   integer,                    save :: dcslim
   integer,                    save :: dcs
   integer,                    save :: irgdayfix
   integer,                    save :: yearendcrp, yearstacrp
   real(8),                    save :: tstairryrx,tendirryrx
   public
   
      integer                    :: hybrid_irrigation_local_node, hybrid_irrigation_local_nodsen
      integer                    :: hybrid_irrigation_local_ifnd, hybrid_irrigation_local_i, hybrid_irrigation_local_j, hybrid_irrigation_local_datea(6)
      integer                    :: hybrid_irrigation_local_endirr(2), hybrid_irrigation_local_startirr(2)
      real(8)                    :: hybrid_irrigation_local_frlow, hybrid_irrigation_local_phlo, hybrid_irrigation_local_phhi, hybrid_irrigation_local_phme, hybrid_irrigation_local_awlh, hybrid_irrigation_local_awmh, hybrid_irrigation_local_awah, hybrid_irrigation_local_cdef
      real(8)                    :: hybrid_irrigation_local_wclo, hybrid_irrigation_local_wcme, hybrid_irrigation_local_wchi, hybrid_irrigation_local_wcac, hybrid_irrigation_local_tps1, hybrid_irrigation_local_tps2, hybrid_irrigation_local_tps3, hybrid_irrigation_local_tps4, hybrid_irrigation_local_tps5, hybrid_irrigation_local_depl, hybrid_irrigation_local_phcrit
      real(8)                    :: hybrid_irrigation_local_dps1, hybrid_irrigation_local_dps2, hybrid_irrigation_local_tred
      real(8)                    :: hybrid_irrigation_local_dvstage(7), hybrid_irrigation_local_trel(7), hybrid_irrigation_local_raw(7), hybrid_irrigation_local_taw(7), hybrid_irrigation_local_dwa(7), hybrid_irrigation_local_hcri(7), hybrid_irrigation_local_tcri(7)
      real(8)                    :: hybrid_irrigation_local_di(7), hybrid_irrigation_local_fid(7), hybrid_irrigation_local_irgdepmax, hybrid_irrigation_local_irgdepmin, hybrid_irrigation_local_irgthreshold
      real(4)                    :: hybrid_irrigation_local_fsec
      real(8)                    :: hybrid_irrigation_local_grai_red, hybrid_irrigation_local_dummy
      real(8), dimension(maho)   :: hybrid_irrigation_local_wclos, hybrid_irrigation_local_wcmes, hybrid_irrigation_local_wchis
      real(8), dimension(2)      :: hybrid_irrigation_local_ir_z
      logical                    :: hybrid_irrigation_local_flirritime
      character(len=200)         :: hybrid_irrigation_local_message
   type hybrid_irrigation_snapshot_t
   integer, dimension(2) :: nod_ssdi
   real(8) :: irr_depth
   real(8) :: irr_rate
   integer :: dayfix
   integer :: irrigevent
   integer, dimension(mairg) :: irtype
   integer :: isua
   integer :: isuas
   integer :: nirri
   integer :: schedule
   integer :: swcirrthres
   real(8) :: cirr
   real(8) :: cirrs
   real(8) :: cirrthres
   real(8) :: dcrit
   real(8), dimension(14) :: ditab
   real(8), dimension(14) :: dwatab
   real(8) :: dt_irr_event
   real(8), dimension(14) :: fidtab
   real(8) :: gird
   real(8), dimension(14) :: hcritab
   real(8), dimension(mairg) :: irconc
   real(8), dimension(mairg) :: irdate
   real(8), dimension(mairg) :: irrate
   real(8), dimension(mairg) :: irdepth
   real(8), dimension(2) :: ir_z
   real(8) :: nird
   real(8) :: perirrsurp
   real(8), dimension(macp) :: qssdi
   real(8) :: qssdisum
   real(8) :: raithreshold
   real(8), dimension(14) :: rawtab
   real(8), dimension(14) :: tawtab
   real(8), dimension(14) :: tcritab
   real(8) :: tstairrig
   real(8) :: tendirrig
   real(8), dimension(14) :: treltab
   logical :: flheadirg
   logical :: flirrigate
   integer :: sw_irrig
   real(8) :: f_irr_avail
   integer :: tcs
   integer :: tcsfix
   integer :: dcslim
   integer :: dcs
   integer :: irgdayfix
   integer :: yearendcrp, yearstacrp
   real(8) :: tstairryrx,tendirryrx
      integer                    :: hybrid_irrigation_local_node, hybrid_irrigation_local_nodsen
      integer                    :: hybrid_irrigation_local_ifnd, hybrid_irrigation_local_i, hybrid_irrigation_local_j, hybrid_irrigation_local_datea(6)
      integer                    :: hybrid_irrigation_local_endirr(2), hybrid_irrigation_local_startirr(2)
      real(8)                    :: hybrid_irrigation_local_frlow, hybrid_irrigation_local_phlo, hybrid_irrigation_local_phhi, hybrid_irrigation_local_phme, hybrid_irrigation_local_awlh, hybrid_irrigation_local_awmh, hybrid_irrigation_local_awah, hybrid_irrigation_local_cdef
      real(8)                    :: hybrid_irrigation_local_wclo, hybrid_irrigation_local_wcme, hybrid_irrigation_local_wchi, hybrid_irrigation_local_wcac, hybrid_irrigation_local_tps1, hybrid_irrigation_local_tps2, hybrid_irrigation_local_tps3, hybrid_irrigation_local_tps4, hybrid_irrigation_local_tps5, hybrid_irrigation_local_depl, hybrid_irrigation_local_phcrit
      real(8)                    :: hybrid_irrigation_local_dps1, hybrid_irrigation_local_dps2, hybrid_irrigation_local_tred
      real(8)                    :: hybrid_irrigation_local_dvstage(7), hybrid_irrigation_local_trel(7), hybrid_irrigation_local_raw(7), hybrid_irrigation_local_taw(7), hybrid_irrigation_local_dwa(7), hybrid_irrigation_local_hcri(7), hybrid_irrigation_local_tcri(7)
      real(8)                    :: hybrid_irrigation_local_di(7), hybrid_irrigation_local_fid(7), hybrid_irrigation_local_irgdepmax, hybrid_irrigation_local_irgdepmin, hybrid_irrigation_local_irgthreshold
      real(4)                    :: hybrid_irrigation_local_fsec
      real(8)                    :: hybrid_irrigation_local_grai_red, hybrid_irrigation_local_dummy
      real(8), dimension(maho)   :: hybrid_irrigation_local_wclos, hybrid_irrigation_local_wcmes, hybrid_irrigation_local_wchis
      real(8), dimension(2)      :: hybrid_irrigation_local_ir_z
      logical                    :: hybrid_irrigation_local_flirritime
      character(len=200)         :: hybrid_irrigation_local_message
      real(8)::accepted_iptra_day,accepted_iqreddry_day,accepted_iqredsol_day
      logical::was_emerged
   end type
   type(hybrid_irrigation_snapshot_t),save::hybrid_irrigation_snapshot
   logical,save::hybrid_irrigation_pending=.false.
   contains

! File VersionID:
!   $Id: irrigation.f90 372 2018-03-13 10:01:20Z heine003 $
! ----------------------------------------------------------------------
      subroutine irrigation (task)
! ----------------------------------------------------------------------
!     Date               : November 2004
!     Purpose            : evaluate and schedule irrigations
!                        : Modified July 2019; 
!                             - tcs=5 obsolete and replaced by tcs=7 (theta) and tcs=8 (presh)
!                             - some calculations only once during initialization
! ----------------------------------------------------------------------
! --  global variables
      use MOD_arrays,           only: maho      
      use MOD_swap_base,        only: swsolu, unit_err, fl_initialize, swirfix
      use plant_interface,      only: unit_crp, crpfilnam, icrop, cropstart, cropend, fl_start_croprotation, fl_cropemergence, dvs, noddrz, hlim3l, hlim3h, hlim4, rd
      use atmosphere_interface, only: grai
      use MOD_grid,             only: zbotcp, numlay, botcom, ztopcp, dz, layer, numnod
      use MOD_MvG,              only: watcon
      use MOD_integral_global,  only: iptra_day, iqreddry_day, iqredsol_day
      use MOD_solute_global,    only: cml
      use variables,            only: t1900, t, h, theta
      
      implicit none
      
      ! locals
      integer, intent(in)        :: task
      logical::hybrid_external_handled
      real(8)::afgen
      ! functions
      logical                    :: rdinqr, rdinar
      
!     save local variables


!     dcs(1)  = Amount of under- or over-irrigation (L) in case of a scheduled irrigation event
!     dcs(2)  = Prescribed fixed irrigation depth (L) for each scheduled irrigation event

! ----------------------------------------------------------------------
      select case (task)
      
      case (1)

! === initialization calculated irrigation ============================

         ! open connection
         call rdinit(unit_crp, unit_err, crpfilnam)

         ! determine whether irrigation scheduling is applied
         call rdsinr ('schedule',0,1,schedule)

         if (schedule == 1) then

            ! no scheduled irrigation before this date
            call rdfinr('startirr',1,31,hybrid_irrigation_local_startirr,2,2)
            call rdfinr('endirr',1,31,hybrid_irrigation_local_endirr,2,2)
            hybrid_irrigation_local_datea(1) = 1900
            hybrid_irrigation_local_datea(2) = hybrid_irrigation_local_startirr(2)
            hybrid_irrigation_local_datea(3) = hybrid_irrigation_local_startirr(1)        
            hybrid_irrigation_local_fsec = 0.0
            call dtardp (hybrid_irrigation_local_datea, hybrid_irrigation_local_fsec, tstairrig)
            hybrid_irrigation_local_datea(2) = hybrid_irrigation_local_endirr(2)
            hybrid_irrigation_local_datea(3) = hybrid_irrigation_local_endirr(1)        
            call dtardp (hybrid_irrigation_local_datea, hybrid_irrigation_local_fsec, tendirrig)

            call dtdpar (cropstart(icrop),hybrid_irrigation_local_datea,hybrid_irrigation_local_fsec)
            yearstacrp = hybrid_irrigation_local_datea(1)
            call dtdpar (cropend(icrop),hybrid_irrigation_local_datea,hybrid_irrigation_local_fsec)
            yearendcrp = hybrid_irrigation_local_datea(1)
            if (yearendcrp > yearstacrp) then
               hybrid_irrigation_local_datea(1) = yearstacrp
               hybrid_irrigation_local_datea(2) = hybrid_irrigation_local_startirr(2)
               hybrid_irrigation_local_datea(3) = hybrid_irrigation_local_startirr(1)        
               hybrid_irrigation_local_fsec     = 0.0
               call dtardp (hybrid_irrigation_local_datea, hybrid_irrigation_local_fsec, tstairryrx)
               hybrid_irrigation_local_datea(1) = yearendcrp
               hybrid_irrigation_local_datea(2) = hybrid_irrigation_local_endirr(2)
               hybrid_irrigation_local_datea(3) = hybrid_irrigation_local_endirr(1)        
               call dtardp (hybrid_irrigation_local_datea, hybrid_irrigation_local_fsec, tendirryrx)
            end if
            
            ! application method
            call rdsinr ('isuas',0,2,isuas)
            
            ! extra info in case of subsurface irrigation
            if (rdinqr('irr_rate')) then
               call rdsdor('irr_rate',   0.1d0,  100.0d0, irr_rate)        ! mm/h
               irr_rate   = 0.1d0*24.0d0*irr_rate                          ! from mm/h to cm/d
            else
               irr_rate = 0.0d0
            end if
            if (isuas == 2) then
               if (.NOT. rdinar('ss_irr_z')) then
                  ! application at single depth (single compartment)
                  call rdsdor('ss_irr_z', -100.0d0, 0.0d0, hybrid_irrigation_local_dummy)             ! cm
                  hybrid_irrigation_local_ir_z(1) = hybrid_irrigation_local_dummy
                  hybrid_irrigation_local_ir_z(2) = hybrid_irrigation_local_dummy
               else
                  ! application over depth interval between two depth levels (multiple consecutive compartments)
                  call rdfdor('ss_irr_z',-100.0d0, 0.0d0, hybrid_irrigation_local_ir_z, 2, 2)         ! cm
               end if
               ! determine layer number where SSDI takes place
               do hybrid_irrigation_local_j = 1, 2
                  hybrid_irrigation_local_i = 1
                  do while (zbotcp(hybrid_irrigation_local_i) > (hybrid_irrigation_local_ir_z(hybrid_irrigation_local_j) + 1.0d-5))
                     hybrid_irrigation_local_i = hybrid_irrigation_local_i + 1
                  end do
                  nod_ssdi(hybrid_irrigation_local_j) = hybrid_irrigation_local_i
               end do
            end if
         
            ! solute concentration irrigation water
            cirrs = 0.0d0 
            if (swsolu == 1) call rdsdor ('cirrs',0.0d0,100.0d0,cirrs)

            ! timing criteria
            call rdsinr ('tcs',1,8,tcs)
            if (tcs == 5) then
               hybrid_irrigation_local_message = 'Option TCS=5 (together with PHORMC) is obsolete and cannot be used anymore.'
               call swap_warning ('irrigation', hybrid_irrigation_local_message)
               hybrid_irrigation_local_message = 'Use option TCS=7 for pressure head (previously: TCS=5 + PHORMC=0) or TCS=8 for water content (previously: TCS=5 + PHORMC=1).'
               call swap_warning ('irrigation', hybrid_irrigation_local_message)
               call swap_error ('irrigation', 'Option TCS=5 (together with PHORMC) is obsolete and cannot be used anymore.')
            end if

            ! timing - allowable daily stress (ratio actual/potential transpiration)
            if (tcs == 1) then
               call rdador('dvs_tc1',0.0d0,2.0d0,hybrid_irrigation_local_dvstage,7,hybrid_irrigation_local_ifnd)
               call rdfdor('trel',0.0d0,1.0d0,hybrid_irrigation_local_trel,7,hybrid_irrigation_local_ifnd)
               do hybrid_irrigation_local_i = 1, hybrid_irrigation_local_ifnd
                  treltab(hybrid_irrigation_local_i*2) = hybrid_irrigation_local_trel(hybrid_irrigation_local_i)
                  treltab(hybrid_irrigation_local_i*2-1) = hybrid_irrigation_local_dvstage(hybrid_irrigation_local_i)
               end do
            end if

            ! timing - depletion of readily available water
            if (tcs == 2) then
               call rdador('dvs_tc2',0.0d0,2.0d0,hybrid_irrigation_local_dvstage,7,hybrid_irrigation_local_ifnd)
               call rdfdor('raw',0.0d0,1.0d0,hybrid_irrigation_local_raw,7,hybrid_irrigation_local_ifnd)
               do hybrid_irrigation_local_i = 1, hybrid_irrigation_local_ifnd
                  rawtab(hybrid_irrigation_local_i*2) = hybrid_irrigation_local_raw(hybrid_irrigation_local_i)
                  rawtab(hybrid_irrigation_local_i*2-1) = hybrid_irrigation_local_dvstage(hybrid_irrigation_local_i)
               end do
            end if

            ! timing - depletion of totally available water
            if (tcs == 3) then
               call rdador('dvs_tc3',0.0d0,2.0d0,hybrid_irrigation_local_dvstage,7,hybrid_irrigation_local_ifnd)
               call rdfdor('taw',0.0d0,1.0d0,hybrid_irrigation_local_taw,7,hybrid_irrigation_local_ifnd)
               do hybrid_irrigation_local_i = 1, hybrid_irrigation_local_ifnd
                  tawtab(hybrid_irrigation_local_i*2) = hybrid_irrigation_local_taw(hybrid_irrigation_local_i)
                  tawtab(hybrid_irrigation_local_i*2-1) = hybrid_irrigation_local_dvstage(hybrid_irrigation_local_i)
               end do
            end if

            ! timing - allowable depletion amount
            if (tcs == 4) then
                call rdador('dvs_tc4',0.0d0,2.0d0,hybrid_irrigation_local_dvstage,7,hybrid_irrigation_local_ifnd)
                call rdfdor('dwa',0.0d0,500.0d0,hybrid_irrigation_local_dwa,7,hybrid_irrigation_local_ifnd)
                do hybrid_irrigation_local_i = 1, hybrid_irrigation_local_ifnd
                  dwatab(hybrid_irrigation_local_i*2) = hybrid_irrigation_local_dwa(hybrid_irrigation_local_i)
                  dwatab(hybrid_irrigation_local_i*2-1) = hybrid_irrigation_local_dvstage(hybrid_irrigation_local_i)
               end do
            end if

            ! timing - critical press. head or moist. content at sensor depth
            ! OBSOLETE replaced by tcs=7 or tcs=8; see below  (july, 2019)

            ! timing - fixed intervals, weekly with threshold (below it: no irrigation)
            if (tcs == 6) then
               call rdsdor ('irgthreshold',0.0d0,20.0d0,hybrid_irrigation_local_irgthreshold)
            end if

            ! timing - fixed intervals
            call rdsinr ('tcsfix',0,1,tcsfix)
            if (tcsfix == 1) then
               if (tcs == 6) then   
                  hybrid_irrigation_local_message = 'Timing criteria: conflict with fixed intervals tcsfix=1 AND tcs=6 not allowed, adapt input !'
                  call swap_error ('irrigation', hybrid_irrigation_local_message)
               end if
               call rdsinr('irgdayfix',1,366,irgdayfix)
            end if

            ! timing - critical pressure head at sensor depth (dcrit; read later)
            swcirrthres = 0
            if (tcs == 7) then
               call rdador ('dvs_tc7',0.0d0,2.0d0,hybrid_irrigation_local_dvstage,7,hybrid_irrigation_local_ifnd)
               call rdfdor ('value_tc7',-1.0d6,100.0d0,hybrid_irrigation_local_hcri,7,hybrid_irrigation_local_ifnd)
               do hybrid_irrigation_local_i = 1, hybrid_irrigation_local_ifnd
                  hcritab(hybrid_irrigation_local_i*2)   = hybrid_irrigation_local_hcri(hybrid_irrigation_local_i)
                  hcritab(hybrid_irrigation_local_i*2-1) = hybrid_irrigation_local_dvstage(hybrid_irrigation_local_i)
               end do
            end if
            
            ! timing - critical water content at sensor depth (dcrit; read later)
            if (tcs == 8) then
               call rdador ('dvs_tc8',0.0d0,2.0d0,hybrid_irrigation_local_dvstage,7,hybrid_irrigation_local_ifnd)
               call rdfdor ('value_tc8',0.0d0,1.0d0,hybrid_irrigation_local_tcri,7,hybrid_irrigation_local_ifnd)
               do hybrid_irrigation_local_i = 1, hybrid_irrigation_local_ifnd
                  tcritab(hybrid_irrigation_local_i*2)   = hybrid_irrigation_local_tcri(hybrid_irrigation_local_i)
                  tcritab(hybrid_irrigation_local_i*2-1) = hybrid_irrigation_local_dvstage(hybrid_irrigation_local_i)
               end do
            end if
            
            if (tcs == 7 .OR. tcs == 8) then
            
               ! sensor depth
               call rdsdor ('dcrit',-100.0d0,0.0d0,dcrit)
            
               ! determine compartment number of sensor depth
               hybrid_irrigation_local_i = 1
               do while (zbotcp(hybrid_irrigation_local_i) > (dcrit + 1.0d-5))
                  hybrid_irrigation_local_i = hybrid_irrigation_local_i+1
               end do
               hybrid_irrigation_local_nodsen = hybrid_irrigation_local_i

               ! in case of solutes: allow overirrigation when conc exceeds concthreshold
               cirrthres = 0.0d0
               perirrsurp = 0.0d0
               if (rdinqr('swcirrthres')) then
                  call rdsinr ('swcirrthres',0,1,swcirrthres)
                  if (swcirrthres == 1) then
                     call rdsdor ('cirrthres', 0.0d0,100.0d0,cirrthres)
                     call rdsdor ('perirrsurp',0.0d0,100.0d0,perirrsurp)
                  end if
               end if

            end if

            ! depth criteria
            call rdsinr ('dcs',1,2,dcs)

            ! field capacity as input for timing and depth options
            if (tcs == 2 .OR. tcs == 3 .OR. tcs == 4 .OR. dcs == 1) then
               call rdsdor('phfieldcapacity',-500.0d0,0.0d0,hybrid_irrigation_local_phlo)
            else
               hybrid_irrigation_local_phlo = -100.0d0
            end if

            ! depth - back to field capacity
            if (dcs == 1) then
               call rdador('dvs_dc1',0.0d0,2.0d0,hybrid_irrigation_local_dvstage,7,hybrid_irrigation_local_ifnd)
               call rdfdor('di',-100.0d0,+100.0d0,hybrid_irrigation_local_di,7,hybrid_irrigation_local_ifnd)
               raithreshold = 0.0d0
               if (rdinqr('raithreshold')) then
                  call rdsdor('raithreshold',0.0d0,1000.0d0,raithreshold)
               end if
               do hybrid_irrigation_local_i = 1, hybrid_irrigation_local_ifnd
                  ditab(hybrid_irrigation_local_i*2)   = hybrid_irrigation_local_di(hybrid_irrigation_local_i)
                  ditab(hybrid_irrigation_local_i*2-1) = hybrid_irrigation_local_dvstage(hybrid_irrigation_local_i)
               end do
            end if

            ! depth - fixed depth
            if (dcs == 2) then
               call rdador('dvs_dc2',0.0d0,2.0d0,hybrid_irrigation_local_dvstage,7,hybrid_irrigation_local_ifnd)
               call rdfdor('fid',0.0d0,400.0d0,hybrid_irrigation_local_fid,7,hybrid_irrigation_local_ifnd)
               do hybrid_irrigation_local_i = 1, hybrid_irrigation_local_ifnd
                  fidtab(hybrid_irrigation_local_i*2)   = hybrid_irrigation_local_fid(hybrid_irrigation_local_i)
                  fidtab(hybrid_irrigation_local_i*2-1) = hybrid_irrigation_local_dvstage(hybrid_irrigation_local_i)
               end do
            end if

            ! depth - limited by min and max
            call rdsinr ('dcslim',0,1,dcslim)
            if (dcslim == 1) then
               call rdsdor('irgdepmin',0.0d0,100.0d0,hybrid_irrigation_local_irgdepmin)
               call rdsdor('irgdepmax',hybrid_irrigation_local_irgdepmin,1.0d7,hybrid_irrigation_local_irgdepmax)
            else
               hybrid_irrigation_local_irgdepmin = 0.0d0
               hybrid_irrigation_local_irgdepmax = 1.0d7
            end if

            ! for some options some constants can be computed once (per crop) and stored
            if (tcs > 1) then
               call rdsdor ('hlim3h',-10000.0d0,100.0d0,hlim3h)
               call rdsdor ('hlim3l',-10000.0d0,100.0d0,hlim3l)
               call rdsdor ('hlim4' ,-20000.0d0,100.0d0,hlim4)
               hybrid_irrigation_local_phme = (hlim3l + hlim3h) * 0.5d0
               hybrid_irrigation_local_phhi = hlim4
               do hybrid_irrigation_local_i = 1, numlay
                  hybrid_irrigation_local_node     = botcom(hybrid_irrigation_local_i)    ! bottom most compartment per soil layer
                  hybrid_irrigation_local_wclos(hybrid_irrigation_local_i) = watcon(hybrid_irrigation_local_node,hybrid_irrigation_local_phlo)
                  hybrid_irrigation_local_wcmes(hybrid_irrigation_local_i) = watcon(hybrid_irrigation_local_node,hybrid_irrigation_local_phme)
                  hybrid_irrigation_local_wchis(hybrid_irrigation_local_i) = watcon(hybrid_irrigation_local_node,hybrid_irrigation_local_phhi)
               end do
            end if

         end if

         cirr = 0.0d0

         ! close input file
         close(unit_crp)
         
         return
      
      case (2)
         
         if (schedule == 1) then
            
            ! read crop data of former day from *.END file
            !if (fl_initialize .AND. .NOT. fl_start_croprotation) then

!               ! open inifile
!               call rdinit(unit_ini,unit_err,inifilnam)
!
!               ! irrigation
!               call rdsinr ('flirrigate',0,1,sw_value)
!               flirrigate = sw_value == 1
!
!               if (flirrigate) then
!                  call rdsinr ('dayfix',0,366,dayfix)
!               end if
!        
!               ! close inifile
!               close(unit_ini)
        
            !else
            if (.NOT. fl_initialize .OR. fl_start_croprotation) then
               
               ! irrigation
               flirrigate = .TRUE.
               dayfix = 366
      
            end if         
         
         end if

         return
         
      case (3)

         ! determine irrigation rates and states
      
         gird            = 0.0d0
         irrigevent      = 0
         cirr            = 0.0d0
         irr_depth       = 0.0d0
         qssdi(1:numnod) = 0.0d0
         dt_irr_event   = 1.0d0
         qssdisum        = 0.0d0

         call hybrid_external_fixed(hybrid_external_handled)
         if (.not.hybrid_external_handled) then
         ! fixed irrigations events
         if (swirfix == 1) then
            if (abs(irdate(nirri) - t1900) < 1.d-3) then
               isua = irtype(nirri)
               if (isua < 2) then
                  !gird = irdepth(nirri)
                  gird = irrate(nirri)
                  cirr = irconc(nirri)
               else
                  qssdi(nod_ssdi(1):nod_ssdi(2)) = irrate(nirri) 
                  qssdisum                       = qssdisum + sum(qssdi(nod_ssdi(1):nod_ssdi(2)))
               end if
               dt_irr_event = irdepth(nirri) / irrate(nirri)     ! end time (fraction of day) of irrigation event
               nirri = nirri + 1
               irrigevent = 1
            end if
         end if

         end if ! explicit external fixed event
         ! scheduled timing within desired period?
         if (schedule == 1) then
            hybrid_irrigation_local_flirritime = .FALSE.
            if (yearendcrp > yearstacrp) then
               if ( (t1900 - tstairryrx) > 1.0d-3 .AND. (t1900 - tendirryrx) <= 1.0d-3 ) then
                  hybrid_irrigation_local_flirritime = .TRUE.
               end if
            else
               if ((t - tstairrig) >= -1.0d-3 .AND. (t - tendirrig) <= 1.0d-3) then
                  hybrid_irrigation_local_flirritime = .TRUE.
               end if
            end if
         end if

         if (sw_irrig == 1 .AND. schedule == 1 .AND. irrigevent == 0 .AND. fl_cropemergence .AND. hybrid_irrigation_local_flirritime) then
            
            cirr = cirrs
            isua = isuas

            ! determine water holding capacity, readily available water, actual available water and water deficit
            if (tcs > 1) then
               hybrid_irrigation_local_frlow = (ztopcp(noddrz) + rd) / dz(noddrz)
               hybrid_irrigation_local_awlh = 0.0d0; hybrid_irrigation_local_awmh = 0.0d0; hybrid_irrigation_local_awah = 0.0d0; hybrid_irrigation_local_cdef = 0.0d0
               do hybrid_irrigation_local_node = 1,noddrz
                  hybrid_irrigation_local_wclo = hybrid_irrigation_local_wclos(layer(hybrid_irrigation_local_node)) * dz(hybrid_irrigation_local_node); if (hybrid_irrigation_local_node == noddrz) hybrid_irrigation_local_wclo = hybrid_irrigation_local_wclo * hybrid_irrigation_local_frlow
                  hybrid_irrigation_local_wcme = hybrid_irrigation_local_wcmes(layer(hybrid_irrigation_local_node)) * dz(hybrid_irrigation_local_node); if (hybrid_irrigation_local_node == noddrz) hybrid_irrigation_local_wcme = hybrid_irrigation_local_wcme * hybrid_irrigation_local_frlow
                  hybrid_irrigation_local_wchi = hybrid_irrigation_local_wchis(layer(hybrid_irrigation_local_node)) * dz(hybrid_irrigation_local_node); if (hybrid_irrigation_local_node == noddrz) hybrid_irrigation_local_wchi = hybrid_irrigation_local_wchi * hybrid_irrigation_local_frlow
                  hybrid_irrigation_local_wcac = watcon(hybrid_irrigation_local_node,h(hybrid_irrigation_local_node)) * dz(hybrid_irrigation_local_node); if (hybrid_irrigation_local_node == noddrz) hybrid_irrigation_local_wcac = hybrid_irrigation_local_wcac * hybrid_irrigation_local_frlow
                  hybrid_irrigation_local_awlh = hybrid_irrigation_local_awlh + (hybrid_irrigation_local_wclo - hybrid_irrigation_local_wchi)
                  hybrid_irrigation_local_awmh = hybrid_irrigation_local_awmh + (hybrid_irrigation_local_wcme - hybrid_irrigation_local_wchi)
                  hybrid_irrigation_local_awah = hybrid_irrigation_local_awah + (hybrid_irrigation_local_wcac - hybrid_irrigation_local_wchi)
                  hybrid_irrigation_local_cdef = hybrid_irrigation_local_cdef + (hybrid_irrigation_local_wclo - hybrid_irrigation_local_wcac) 
               end do
            end if

            ! timing - allowable daily stress - only under dry or saline stress circumstances
            if (tcs == 1) then
               
               hybrid_irrigation_local_tps1 = afgen(treltab,14,dvs)
               
               ! transpiration fraction due to drought and salinity stress
               if (iptra_day > 1.d-10) then
                  hybrid_irrigation_local_tred = 1.0d0 - (iqreddry_day + iqredsol_day) / iptra_day
               else
                  hybrid_irrigation_local_tred = 1.0d0
               end if
               if (hybrid_irrigation_local_tred < hybrid_irrigation_local_tps1) irrigevent = 2
            end if

            ! timing - depletion of readily available water (fraction)
            if (tcs == 2) then
               
               ! compare readily available water and actual available water
               hybrid_irrigation_local_tps2 = afgen(rawtab,14,dvs)
               hybrid_irrigation_local_depl = hybrid_irrigation_local_tps2 * (hybrid_irrigation_local_awlh - hybrid_irrigation_local_awmh)
               if (hybrid_irrigation_local_depl > hybrid_irrigation_local_awlh) hybrid_irrigation_local_depl = hybrid_irrigation_local_awlh 
               if (hybrid_irrigation_local_awah < (hybrid_irrigation_local_awlh - hybrid_irrigation_local_depl)) irrigevent = 2
            
            end if

            ! timing - depletion of totally available water (fraction)
            if (tcs == 3) then
               
               ! compare totally available water and actual available water
               hybrid_irrigation_local_tps3 = afgen(tawtab,14,dvs)
               hybrid_irrigation_local_depl = hybrid_irrigation_local_tps3 * hybrid_irrigation_local_awlh
               if (hybrid_irrigation_local_awah < (hybrid_irrigation_local_awlh - hybrid_irrigation_local_depl)) irrigevent = 2
            
            end if

            ! timing - allowable amount of depletion
            if (tcs == 4) then
               
               ! check if depletion amount has been exceeded                
               hybrid_irrigation_local_tps4 = afgen(dwatab,14,dvs)
               if ((hybrid_irrigation_local_awlh-hybrid_irrigation_local_awah) > (hybrid_irrigation_local_tps4 * 0.1d0)) irrigevent = 2
            
            end if

            ! timing - critical pressure head or moisture content exceeded
            ! OBSOLETE: replaced by tcs=7 or tcs=8

            ! timing - fixed irrigation time (weekly during crop growth)
            if (tcs == 6) then

               ! (weekly) irrigation only when deficit is higher then threshold cdef (cm) en IrgThreshold (mm)
               dayfix = dayfix + 1
               if (dayfix >= 7)  then
                  dayfix = 0
                  if (10.0d0 * hybrid_irrigation_local_cdef > hybrid_irrigation_local_irgthreshold) then
                     irrigevent = 2
                  end if
               end if

            end if

            ! timing - critical pressure head at dcrit (node=nodsen) exceeded
            if (tcs == 7) then

               ! calculation of critical pressure head
               hybrid_irrigation_local_tps5 = afgen(hcritab,14,dvs)
               hybrid_irrigation_local_phcrit = hybrid_irrigation_local_tps5
               if (h(hybrid_irrigation_local_nodsen) <= hybrid_irrigation_local_phcrit) irrigevent = 2
            end if

            ! timing - critical watercontent at dcrit (node=nodsen) exceeded
            if (tcs == 8) then
               
               hybrid_irrigation_local_tps5 = afgen(tcritab,14,dvs)
               ! compare critical water content and actual water content
               if (theta(hybrid_irrigation_local_nodsen) <= hybrid_irrigation_local_tps5) irrigevent = 2
            
            end if

            ! timing - fixed intervals
            if (tcsfix == 1) then

               if (irrigevent == 2 .AND. (dayfix >= irgdayfix)) then
                  irrigevent = 2
                  dayfix = 1
               else
                  irrigevent = 0
                  if (dayfix < irgdayfix) dayfix = dayfix + 1
               end if
            
            end if

            ! Amount and rate
            if (irrigevent == 2) then
               
               ! depth - back to field capacity [cm]
               if (dcs == 1) then
                  ! correct for over- or under irrigation
                  hybrid_irrigation_local_dps1 = afgen(ditab,14,dvs)
                  ! option to reduce irrigation on rainy (> raithreshold) day
                  hybrid_irrigation_local_grai_red = 0.0d0
                  if (grai > raithreshold) hybrid_irrigation_local_grai_red = grai
                  irr_depth = max (0.0d0, hybrid_irrigation_local_cdef + hybrid_irrigation_local_dps1 * 0.1d0 - hybrid_irrigation_local_grai_red)
               end if

               ! depth - fixed depth [cm]
               if (dcs == 2) then
                  hybrid_irrigation_local_dps2 = afgen(fidtab,14,dvs)
                  irr_depth = hybrid_irrigation_local_dps2 * 0.1d0
               end if

               ! depth - limited depth [cm]
               if (dcslim == 1) then
                  irr_depth = max(irr_depth, hybrid_irrigation_local_irgdepmin * 0.1d0)
                  irr_depth = min(irr_depth, hybrid_irrigation_local_irgdepmax * 0.1d0)
               end if

               ! in case of solutes: allow overirrigation when conc exceeds concthreshold
               if (swsolu == 1  .AND. swcirrthres == 1) then
                  if (cml(hybrid_irrigation_local_nodsen) > cirrthres) then
                     irr_depth = irr_depth + 0.01d0 * perirrsurp * irr_depth
                  end if
               end if
               
               ! Rates
               if (irr_rate > 0.0d0) then
                  if (irr_depth/irr_rate > 1.0d0) then
                     call swap_warning('irrigation', 'irr_depth/irr_rate > 1.0d0; irr_rate temporarily adapted')
                     if (isuas < 2) then
                        gird = irr_depth
                     else
                        qssdi(nod_ssdi(1):nod_ssdi(2)) = irr_depth
                        qssdisum                       = qssdisum + sum(qssdi(nod_ssdi(1):nod_ssdi(2)))
                     end if
                     dt_irr_event = 1.0d0
                  else
                     if (isuas < 2) then
                        gird = irr_rate
                     else
                        qssdi(nod_ssdi(1):nod_ssdi(2)) = irr_rate
                        qssdisum                       = qssdisum + sum(qssdi(nod_ssdi(1):nod_ssdi(2)))
                     end if
                     dt_irr_event = irr_depth/irr_rate
                  end if
               else
                  ! irrigation supplied spread evenly over the whole day
                  if (isuas < 2) then
                     gird = irr_depth
                  else
                     qssdi(nod_ssdi(1):nod_ssdi(2)) = irr_depth
                     qssdisum                       = qssdisum + sum(qssdi(nod_ssdi(1):nod_ssdi(2)))
                  end if
                  dt_irr_event = 1.0d0
               end if

            end if ! irrigevent == 2

         end if
         
         return

      case(4)
         ! possible: limited by external model
         gird = gird * f_irr_avail
         if (irr_rate > 0.0d0) dt_irr_event = dt_irr_event * f_irr_avail

      case(9)
         ! special: reset scheduled irrigation at end of irrigation event
         irrigevent      = 0
         gird            = 0.0d0
         qssdi(1:numnod) = 0.0d0
         dt_irr_event    = 1.0d0
         qssdisum        = 0.0d0
         
      case default
         
         call swap_error ('irrigation', 'Illegal value for TASK')
      
      end select

      return
   
      end subroutine irrigation
      
      subroutine read_irrigation_fixed()
         use MOD_swap_base,only:swinco
         use MOD_swap_base, only: unit_err, unit_swp, swpfilnam, pathwork, iun_min2, iun_max2, swsolu
         use MOD_arrays,    only: fillen
         use MOD_grid,      only: zbotcp
         use variables,     only: tstart, tend
         implicit none
         ! local
         integer                 :: i, j, ifnd, swirgfil, unit_irg
         real(8)                 :: dummy
         character(len=fillen)   :: irgfil, filnam
         logical                 :: file_exists
         ! functions
         integer                 :: getun2
         logical                 :: rdinqr, rdinar

         swirgfil = 0
         irgfil = ' ' 
         irconc = 0.d0
         call rdsinr ('swirgfil',0,1,swirgfil)
         if (swirgfil == 1) then
            ! input from separate file 
            call rdscha ('irgfil',irgfil)
            close (unit_swp)   ! we must close main input file, so that soils database can be accessed by rdinit
            filnam = trim(pathwork)//trim(irgfil)//'.irg'
            inquire(file = filnam, exist = file_exists)
            if (.NOT. file_exists) call swap_error ('readswap', 'File '//trim(filnam)//' does not exists!')
            unit_irg = getun2 (iun_min2, iun_max2, 2)
            call rdinit(unit_irg,unit_err,filnam)
         end if
         call rdatim ('irdate',irdate,mairg,ifnd)
         call rdfinr ('irtype',0,2,irtype,mairg,ifnd)
         if (rdinqr('irrate')) then
            call rdfdor('irdepth',0.01d0,100.0d0,irdepth,mairg,ifnd)       ! mm
            call rdfdor('irrate',0.0d0,100.0d0,irrate,mairg,ifnd)          ! mm/h
         else
            ! backward compatibility
            call rdfdor ('irdepth',0.01d0,100.d0,irdepth,mairg,ifnd)       ! mm
            irrate(1:ifnd) = irdepth(1:ifnd)/24.0d0                        ! mm/h
         end if

         ! check if irdate is ascending, and determine initial entry point nirri
         nirri = 1
         do i = 1, ifnd-1
            if (irdate(i) >= irdate(i+1)) call swap_error ('readswap', 'irdate not in ascending order')
            if (tstart >= irdate(i)) nirri = i
         end do
         if (tstart >= irdate(ifnd)) nirri = ifnd
         if(swinco==3.and.all(irdate(1:ifnd)<tstart))nirri=ifnd+1
         
         ! additional information in case of subsurface irrigation
         if (maxval(irtype) == 2) then
            call rdfdor('irrate',0.0d0,100.0d0,irrate,mairg,ifnd)       ! mm/h
            if (.NOT. rdinar('ir_z')) then
               ! application at single depth (single compartment)
               call rdsdor('ir_z', -100.0d0, 0.0d0, dummy)              ! cm
               ir_z(1) = dummy
               ir_z(2) = dummy
            else
               ! application over depth interval between two depth levels (multiple consecutive compartments)
               call rdfdor('ir_z',-100.0d0, 0.0d0, ir_z, 2, 2)          ! cm
            end if
                  ! determine layer number where SSDI takes place
            do j = 1, 2
               i = 1
               do while (zbotcp(i) > (ir_z(j) + 1.0d-5))
                  i = i + 1
               end do
               nod_ssdi(j) = i
            end do

            ! redefine application rate: uniformly spread over all nodes
            do i = 1, ifnd
               if (irtype(i) == 2) irdepth(i) = irdepth(i)/dble((nod_ssdi(2) - nod_ssdi(1) + 1))
            end do
         end if
         
         if (swsolu > 0) call rdfdor ('irconc',0.d0,1000.d0,irconc,mairg,ifnd)
! -      at least one date must be within simulation period
         if(swinco/=3 .or. .not.all(irdate(1:ifnd)<tstart)) &
            call checkdate(ifnd,irdate,tend,tstart,'irdate', 'readswap/swirfix=1      ')

! ---    convert mm irrigation to cm; 
         irdepth = 0.1d0*irdepth
         irrate  = 0.1d0*24.0d0*irrate    ! from mm/h to cm/d

         do i = 1, ifnd
            if (irdepth(i) / irrate(i) > 1.0d0) call swap_error('readswap', 'You cannot consider irrigation duration times > 1 d')
         end do
         
         if (swirgfil == 1) then
            close(unit_irg)
            call rdinit(unit_swp,unit_err,swpfilnam)     ! open main input file again
         end if
      
      end subroutine read_irrigation_fixed
      

   subroutine hybrid_irrigation_checkpoint(unit,restoring)
      use plant_interface,only:fl_cropemergence
      use MOD_integral_global,only:iptra_day,iqreddry_day,iqredsol_day
      use ieee_arithmetic,only:ieee_is_finite
      integer,intent(in)::unit
      logical,intent(in)::restoring
      integer::ios
      if(restoring)then
         read(unit,iostat=ios) hybrid_irrigation_snapshot%nod_ssdi, &
         hybrid_irrigation_snapshot%irr_depth, &
         hybrid_irrigation_snapshot%irr_rate, &
         hybrid_irrigation_snapshot%dayfix, &
         hybrid_irrigation_snapshot%irrigevent, &
         hybrid_irrigation_snapshot%irtype, &
         hybrid_irrigation_snapshot%isua, &
         hybrid_irrigation_snapshot%isuas, &
         hybrid_irrigation_snapshot%nirri, &
         hybrid_irrigation_snapshot%schedule, &
         hybrid_irrigation_snapshot%swcirrthres, &
         hybrid_irrigation_snapshot%cirr, &
         hybrid_irrigation_snapshot%cirrs, &
         hybrid_irrigation_snapshot%cirrthres, &
         hybrid_irrigation_snapshot%dcrit, &
         hybrid_irrigation_snapshot%ditab, &
         hybrid_irrigation_snapshot%dwatab, &
         hybrid_irrigation_snapshot%dt_irr_event, &
         hybrid_irrigation_snapshot%fidtab, &
         hybrid_irrigation_snapshot%gird, &
         hybrid_irrigation_snapshot%hcritab, &
         hybrid_irrigation_snapshot%irconc, &
         hybrid_irrigation_snapshot%irdate, &
         hybrid_irrigation_snapshot%irrate, &
         hybrid_irrigation_snapshot%irdepth, &
         hybrid_irrigation_snapshot%ir_z, &
         hybrid_irrigation_snapshot%nird, &
         hybrid_irrigation_snapshot%perirrsurp, &
         hybrid_irrigation_snapshot%qssdi, &
         hybrid_irrigation_snapshot%qssdisum, &
         hybrid_irrigation_snapshot%raithreshold, &
         hybrid_irrigation_snapshot%rawtab, &
         hybrid_irrigation_snapshot%tawtab, &
         hybrid_irrigation_snapshot%tcritab, &
         hybrid_irrigation_snapshot%tstairrig, &
         hybrid_irrigation_snapshot%tendirrig, &
         hybrid_irrigation_snapshot%treltab, &
         hybrid_irrigation_snapshot%flheadirg, &
         hybrid_irrigation_snapshot%flirrigate, &
         hybrid_irrigation_snapshot%sw_irrig, &
         hybrid_irrigation_snapshot%f_irr_avail, &
         hybrid_irrigation_snapshot%tcs, &
         hybrid_irrigation_snapshot%tcsfix, &
         hybrid_irrigation_snapshot%dcslim, &
         hybrid_irrigation_snapshot%dcs, &
         hybrid_irrigation_snapshot%irgdayfix, &
         hybrid_irrigation_snapshot%yearendcrp, &
         hybrid_irrigation_snapshot%yearstacrp, &
         hybrid_irrigation_snapshot%tstairryrx, &
         hybrid_irrigation_snapshot%tendirryrx, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_node, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_nodsen, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_ifnd, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_i, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_j, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_datea, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_endirr, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_startirr, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_frlow, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phlo, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phhi, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phme, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_awlh, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_awmh, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_awah, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_cdef, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wclo, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wcme, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wchi, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wcac, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps1, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps2, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps3, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps4, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps5, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_depl, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phcrit, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dps1, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dps2, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tred, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dvstage, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_trel, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_raw, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_taw, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dwa, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_hcri, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tcri, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_di, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_fid, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmax, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmin, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_irgthreshold, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_fsec, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_grai_red, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dummy, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wclos, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wcmes, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wchis, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_ir_z, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_flirritime, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_message, &
         hybrid_irrigation_snapshot%accepted_iptra_day, &
         hybrid_irrigation_snapshot%accepted_iqreddry_day, &
         hybrid_irrigation_snapshot%accepted_iqredsol_day, &
         hybrid_irrigation_snapshot%was_emerged
         if(ios/=0)error stop 'Incomplete Hupsel irrigation context'
         if(.not.all(ieee_is_finite([hybrid_irrigation_snapshot%accepted_iptra_day, &
            hybrid_irrigation_snapshot%accepted_iqreddry_day,hybrid_irrigation_snapshot%accepted_iqredsol_day]))) &
            error stop 'Nonfinite accepted irrigation feedback'
         if(hybrid_irrigation_snapshot%dayfix<0.or.hybrid_irrigation_snapshot%dayfix>366) &
            error stop 'Invalid Hupsel irrigation context'
         hybrid_irrigation_pending=.true.
      else
         hybrid_irrigation_snapshot%nod_ssdi=nod_ssdi
         hybrid_irrigation_snapshot%irr_depth=irr_depth
         hybrid_irrigation_snapshot%irr_rate=irr_rate
         hybrid_irrigation_snapshot%dayfix=dayfix
         hybrid_irrigation_snapshot%irrigevent=irrigevent
         hybrid_irrigation_snapshot%irtype=irtype
         hybrid_irrigation_snapshot%isua=isua
         hybrid_irrigation_snapshot%isuas=isuas
         hybrid_irrigation_snapshot%nirri=nirri
         hybrid_irrigation_snapshot%schedule=schedule
         hybrid_irrigation_snapshot%swcirrthres=swcirrthres
         hybrid_irrigation_snapshot%cirr=cirr
         hybrid_irrigation_snapshot%cirrs=cirrs
         hybrid_irrigation_snapshot%cirrthres=cirrthres
         hybrid_irrigation_snapshot%dcrit=dcrit
         hybrid_irrigation_snapshot%ditab=ditab
         hybrid_irrigation_snapshot%dwatab=dwatab
         hybrid_irrigation_snapshot%dt_irr_event=dt_irr_event
         hybrid_irrigation_snapshot%fidtab=fidtab
         hybrid_irrigation_snapshot%gird=gird
         hybrid_irrigation_snapshot%hcritab=hcritab
         hybrid_irrigation_snapshot%irconc=irconc
         hybrid_irrigation_snapshot%irdate=irdate
         hybrid_irrigation_snapshot%irrate=irrate
         hybrid_irrigation_snapshot%irdepth=irdepth
         hybrid_irrigation_snapshot%ir_z=ir_z
         hybrid_irrigation_snapshot%nird=nird
         hybrid_irrigation_snapshot%perirrsurp=perirrsurp
         hybrid_irrigation_snapshot%qssdi=qssdi
         hybrid_irrigation_snapshot%qssdisum=qssdisum
         hybrid_irrigation_snapshot%raithreshold=raithreshold
         hybrid_irrigation_snapshot%rawtab=rawtab
         hybrid_irrigation_snapshot%tawtab=tawtab
         hybrid_irrigation_snapshot%tcritab=tcritab
         hybrid_irrigation_snapshot%tstairrig=tstairrig
         hybrid_irrigation_snapshot%tendirrig=tendirrig
         hybrid_irrigation_snapshot%treltab=treltab
         hybrid_irrigation_snapshot%flheadirg=flheadirg
         hybrid_irrigation_snapshot%flirrigate=flirrigate
         hybrid_irrigation_snapshot%sw_irrig=sw_irrig
         hybrid_irrigation_snapshot%f_irr_avail=f_irr_avail
         hybrid_irrigation_snapshot%tcs=tcs
         hybrid_irrigation_snapshot%tcsfix=tcsfix
         hybrid_irrigation_snapshot%dcslim=dcslim
         hybrid_irrigation_snapshot%dcs=dcs
         hybrid_irrigation_snapshot%irgdayfix=irgdayfix
         hybrid_irrigation_snapshot%yearendcrp=yearendcrp
         hybrid_irrigation_snapshot%yearstacrp=yearstacrp
         hybrid_irrigation_snapshot%tstairryrx=tstairryrx
         hybrid_irrigation_snapshot%tendirryrx=tendirryrx
         hybrid_irrigation_snapshot%hybrid_irrigation_local_node=hybrid_irrigation_local_node
         hybrid_irrigation_snapshot%hybrid_irrigation_local_nodsen=hybrid_irrigation_local_nodsen
         hybrid_irrigation_snapshot%hybrid_irrigation_local_ifnd=hybrid_irrigation_local_ifnd
         hybrid_irrigation_snapshot%hybrid_irrigation_local_i=hybrid_irrigation_local_i
         hybrid_irrigation_snapshot%hybrid_irrigation_local_j=hybrid_irrigation_local_j
         hybrid_irrigation_snapshot%hybrid_irrigation_local_datea=hybrid_irrigation_local_datea
         hybrid_irrigation_snapshot%hybrid_irrigation_local_endirr=hybrid_irrigation_local_endirr
         hybrid_irrigation_snapshot%hybrid_irrigation_local_startirr=hybrid_irrigation_local_startirr
         hybrid_irrigation_snapshot%hybrid_irrigation_local_frlow=hybrid_irrigation_local_frlow
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phlo=hybrid_irrigation_local_phlo
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phhi=hybrid_irrigation_local_phhi
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phme=hybrid_irrigation_local_phme
         hybrid_irrigation_snapshot%hybrid_irrigation_local_awlh=hybrid_irrigation_local_awlh
         hybrid_irrigation_snapshot%hybrid_irrigation_local_awmh=hybrid_irrigation_local_awmh
         hybrid_irrigation_snapshot%hybrid_irrigation_local_awah=hybrid_irrigation_local_awah
         hybrid_irrigation_snapshot%hybrid_irrigation_local_cdef=hybrid_irrigation_local_cdef
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wclo=hybrid_irrigation_local_wclo
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wcme=hybrid_irrigation_local_wcme
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wchi=hybrid_irrigation_local_wchi
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wcac=hybrid_irrigation_local_wcac
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps1=hybrid_irrigation_local_tps1
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps2=hybrid_irrigation_local_tps2
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps3=hybrid_irrigation_local_tps3
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps4=hybrid_irrigation_local_tps4
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps5=hybrid_irrigation_local_tps5
         hybrid_irrigation_snapshot%hybrid_irrigation_local_depl=hybrid_irrigation_local_depl
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phcrit=hybrid_irrigation_local_phcrit
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dps1=hybrid_irrigation_local_dps1
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dps2=hybrid_irrigation_local_dps2
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tred=hybrid_irrigation_local_tred
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dvstage=hybrid_irrigation_local_dvstage
         hybrid_irrigation_snapshot%hybrid_irrigation_local_trel=hybrid_irrigation_local_trel
         hybrid_irrigation_snapshot%hybrid_irrigation_local_raw=hybrid_irrigation_local_raw
         hybrid_irrigation_snapshot%hybrid_irrigation_local_taw=hybrid_irrigation_local_taw
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dwa=hybrid_irrigation_local_dwa
         hybrid_irrigation_snapshot%hybrid_irrigation_local_hcri=hybrid_irrigation_local_hcri
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tcri=hybrid_irrigation_local_tcri
         hybrid_irrigation_snapshot%hybrid_irrigation_local_di=hybrid_irrigation_local_di
         hybrid_irrigation_snapshot%hybrid_irrigation_local_fid=hybrid_irrigation_local_fid
         hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmax=hybrid_irrigation_local_irgdepmax
         hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmin=hybrid_irrigation_local_irgdepmin
         hybrid_irrigation_snapshot%hybrid_irrigation_local_irgthreshold=hybrid_irrigation_local_irgthreshold
         hybrid_irrigation_snapshot%hybrid_irrigation_local_fsec=hybrid_irrigation_local_fsec
         hybrid_irrigation_snapshot%hybrid_irrigation_local_grai_red=hybrid_irrigation_local_grai_red
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dummy=hybrid_irrigation_local_dummy
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wclos=hybrid_irrigation_local_wclos
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wcmes=hybrid_irrigation_local_wcmes
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wchis=hybrid_irrigation_local_wchis
         hybrid_irrigation_snapshot%hybrid_irrigation_local_ir_z=hybrid_irrigation_local_ir_z
         hybrid_irrigation_snapshot%hybrid_irrigation_local_flirritime=hybrid_irrigation_local_flirritime
         hybrid_irrigation_snapshot%hybrid_irrigation_local_message=hybrid_irrigation_local_message
         hybrid_irrigation_snapshot%accepted_iptra_day=iptra_day
         hybrid_irrigation_snapshot%accepted_iqreddry_day=iqreddry_day
         hybrid_irrigation_snapshot%accepted_iqredsol_day=iqredsol_day
         hybrid_irrigation_snapshot%was_emerged=fl_cropemergence
         write(unit) hybrid_irrigation_snapshot%nod_ssdi, &
         hybrid_irrigation_snapshot%irr_depth, &
         hybrid_irrigation_snapshot%irr_rate, &
         hybrid_irrigation_snapshot%dayfix, &
         hybrid_irrigation_snapshot%irrigevent, &
         hybrid_irrigation_snapshot%irtype, &
         hybrid_irrigation_snapshot%isua, &
         hybrid_irrigation_snapshot%isuas, &
         hybrid_irrigation_snapshot%nirri, &
         hybrid_irrigation_snapshot%schedule, &
         hybrid_irrigation_snapshot%swcirrthres, &
         hybrid_irrigation_snapshot%cirr, &
         hybrid_irrigation_snapshot%cirrs, &
         hybrid_irrigation_snapshot%cirrthres, &
         hybrid_irrigation_snapshot%dcrit, &
         hybrid_irrigation_snapshot%ditab, &
         hybrid_irrigation_snapshot%dwatab, &
         hybrid_irrigation_snapshot%dt_irr_event, &
         hybrid_irrigation_snapshot%fidtab, &
         hybrid_irrigation_snapshot%gird, &
         hybrid_irrigation_snapshot%hcritab, &
         hybrid_irrigation_snapshot%irconc, &
         hybrid_irrigation_snapshot%irdate, &
         hybrid_irrigation_snapshot%irrate, &
         hybrid_irrigation_snapshot%irdepth, &
         hybrid_irrigation_snapshot%ir_z, &
         hybrid_irrigation_snapshot%nird, &
         hybrid_irrigation_snapshot%perirrsurp, &
         hybrid_irrigation_snapshot%qssdi, &
         hybrid_irrigation_snapshot%qssdisum, &
         hybrid_irrigation_snapshot%raithreshold, &
         hybrid_irrigation_snapshot%rawtab, &
         hybrid_irrigation_snapshot%tawtab, &
         hybrid_irrigation_snapshot%tcritab, &
         hybrid_irrigation_snapshot%tstairrig, &
         hybrid_irrigation_snapshot%tendirrig, &
         hybrid_irrigation_snapshot%treltab, &
         hybrid_irrigation_snapshot%flheadirg, &
         hybrid_irrigation_snapshot%flirrigate, &
         hybrid_irrigation_snapshot%sw_irrig, &
         hybrid_irrigation_snapshot%f_irr_avail, &
         hybrid_irrigation_snapshot%tcs, &
         hybrid_irrigation_snapshot%tcsfix, &
         hybrid_irrigation_snapshot%dcslim, &
         hybrid_irrigation_snapshot%dcs, &
         hybrid_irrigation_snapshot%irgdayfix, &
         hybrid_irrigation_snapshot%yearendcrp, &
         hybrid_irrigation_snapshot%yearstacrp, &
         hybrid_irrigation_snapshot%tstairryrx, &
         hybrid_irrigation_snapshot%tendirryrx, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_node, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_nodsen, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_ifnd, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_i, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_j, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_datea, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_endirr, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_startirr, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_frlow, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phlo, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phhi, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phme, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_awlh, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_awmh, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_awah, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_cdef, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wclo, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wcme, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wchi, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wcac, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps1, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps2, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps3, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps4, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tps5, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_depl, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_phcrit, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dps1, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dps2, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tred, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dvstage, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_trel, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_raw, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_taw, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dwa, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_hcri, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_tcri, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_di, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_fid, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmax, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmin, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_irgthreshold, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_fsec, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_grai_red, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_dummy, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wclos, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wcmes, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_wchis, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_ir_z, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_flirritime, &
         hybrid_irrigation_snapshot%hybrid_irrigation_local_message, &
         hybrid_irrigation_snapshot%accepted_iptra_day, &
         hybrid_irrigation_snapshot%accepted_iqreddry_day, &
         hybrid_irrigation_snapshot%accepted_iqredsol_day, &
         hybrid_irrigation_snapshot%was_emerged
      end if
   end subroutine
   subroutine hybrid_apply_irrigation(emerged)
      use MOD_integral_global,only:iptra_day,iqreddry_day,iqredsol_day
      logical,intent(in)::emerged
      if(.not.hybrid_irrigation_pending)return
      iptra_day=hybrid_irrigation_snapshot%accepted_iptra_day
      iqreddry_day=hybrid_irrigation_snapshot%accepted_iqreddry_day
      iqredsol_day=hybrid_irrigation_snapshot%accepted_iqredsol_day
      nirri=hybrid_irrigation_snapshot%nirri
      if(.not.hybrid_irrigation_snapshot%was_emerged.and.emerged)then
         if(schedule==1)then
            dayfix=366
            flirrigate=.true.
         else
         nod_ssdi=hybrid_irrigation_snapshot%nod_ssdi
         irr_depth=hybrid_irrigation_snapshot%irr_depth
         irr_rate=hybrid_irrigation_snapshot%irr_rate
         dayfix=hybrid_irrigation_snapshot%dayfix
         irrigevent=hybrid_irrigation_snapshot%irrigevent
         irtype=hybrid_irrigation_snapshot%irtype
         isua=hybrid_irrigation_snapshot%isua
         isuas=hybrid_irrigation_snapshot%isuas
         nirri=hybrid_irrigation_snapshot%nirri
         schedule=hybrid_irrigation_snapshot%schedule
         swcirrthres=hybrid_irrigation_snapshot%swcirrthres
         cirr=hybrid_irrigation_snapshot%cirr
         cirrs=hybrid_irrigation_snapshot%cirrs
         cirrthres=hybrid_irrigation_snapshot%cirrthres
         dcrit=hybrid_irrigation_snapshot%dcrit
         ditab=hybrid_irrigation_snapshot%ditab
         dwatab=hybrid_irrigation_snapshot%dwatab
         dt_irr_event=hybrid_irrigation_snapshot%dt_irr_event
         fidtab=hybrid_irrigation_snapshot%fidtab
         gird=hybrid_irrigation_snapshot%gird
         hcritab=hybrid_irrigation_snapshot%hcritab
         irconc=hybrid_irrigation_snapshot%irconc
         irdate=hybrid_irrigation_snapshot%irdate
         irrate=hybrid_irrigation_snapshot%irrate
         irdepth=hybrid_irrigation_snapshot%irdepth
         ir_z=hybrid_irrigation_snapshot%ir_z
         nird=hybrid_irrigation_snapshot%nird
         perirrsurp=hybrid_irrigation_snapshot%perirrsurp
         qssdi=hybrid_irrigation_snapshot%qssdi
         qssdisum=hybrid_irrigation_snapshot%qssdisum
         raithreshold=hybrid_irrigation_snapshot%raithreshold
         rawtab=hybrid_irrigation_snapshot%rawtab
         tawtab=hybrid_irrigation_snapshot%tawtab
         tcritab=hybrid_irrigation_snapshot%tcritab
         tstairrig=hybrid_irrigation_snapshot%tstairrig
         tendirrig=hybrid_irrigation_snapshot%tendirrig
         treltab=hybrid_irrigation_snapshot%treltab
         flheadirg=hybrid_irrigation_snapshot%flheadirg
         flirrigate=hybrid_irrigation_snapshot%flirrigate
         sw_irrig=hybrid_irrigation_snapshot%sw_irrig
         f_irr_avail=hybrid_irrigation_snapshot%f_irr_avail
         tcs=hybrid_irrigation_snapshot%tcs
         tcsfix=hybrid_irrigation_snapshot%tcsfix
         dcslim=hybrid_irrigation_snapshot%dcslim
         dcs=hybrid_irrigation_snapshot%dcs
         irgdayfix=hybrid_irrigation_snapshot%irgdayfix
         yearendcrp=hybrid_irrigation_snapshot%yearendcrp
         yearstacrp=hybrid_irrigation_snapshot%yearstacrp
         tstairryrx=hybrid_irrigation_snapshot%tstairryrx
         tendirryrx=hybrid_irrigation_snapshot%tendirryrx
         hybrid_irrigation_local_node=hybrid_irrigation_snapshot%hybrid_irrigation_local_node
         hybrid_irrigation_local_nodsen=hybrid_irrigation_snapshot%hybrid_irrigation_local_nodsen
         hybrid_irrigation_local_ifnd=hybrid_irrigation_snapshot%hybrid_irrigation_local_ifnd
         hybrid_irrigation_local_i=hybrid_irrigation_snapshot%hybrid_irrigation_local_i
         hybrid_irrigation_local_j=hybrid_irrigation_snapshot%hybrid_irrigation_local_j
         hybrid_irrigation_local_datea=hybrid_irrigation_snapshot%hybrid_irrigation_local_datea
         hybrid_irrigation_local_endirr=hybrid_irrigation_snapshot%hybrid_irrigation_local_endirr
         hybrid_irrigation_local_startirr=hybrid_irrigation_snapshot%hybrid_irrigation_local_startirr
         hybrid_irrigation_local_frlow=hybrid_irrigation_snapshot%hybrid_irrigation_local_frlow
         hybrid_irrigation_local_phlo=hybrid_irrigation_snapshot%hybrid_irrigation_local_phlo
         hybrid_irrigation_local_phhi=hybrid_irrigation_snapshot%hybrid_irrigation_local_phhi
         hybrid_irrigation_local_phme=hybrid_irrigation_snapshot%hybrid_irrigation_local_phme
         hybrid_irrigation_local_awlh=hybrid_irrigation_snapshot%hybrid_irrigation_local_awlh
         hybrid_irrigation_local_awmh=hybrid_irrigation_snapshot%hybrid_irrigation_local_awmh
         hybrid_irrigation_local_awah=hybrid_irrigation_snapshot%hybrid_irrigation_local_awah
         hybrid_irrigation_local_cdef=hybrid_irrigation_snapshot%hybrid_irrigation_local_cdef
         hybrid_irrigation_local_wclo=hybrid_irrigation_snapshot%hybrid_irrigation_local_wclo
         hybrid_irrigation_local_wcme=hybrid_irrigation_snapshot%hybrid_irrigation_local_wcme
         hybrid_irrigation_local_wchi=hybrid_irrigation_snapshot%hybrid_irrigation_local_wchi
         hybrid_irrigation_local_wcac=hybrid_irrigation_snapshot%hybrid_irrigation_local_wcac
         hybrid_irrigation_local_tps1=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps1
         hybrid_irrigation_local_tps2=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps2
         hybrid_irrigation_local_tps3=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps3
         hybrid_irrigation_local_tps4=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps4
         hybrid_irrigation_local_tps5=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps5
         hybrid_irrigation_local_depl=hybrid_irrigation_snapshot%hybrid_irrigation_local_depl
         hybrid_irrigation_local_phcrit=hybrid_irrigation_snapshot%hybrid_irrigation_local_phcrit
         hybrid_irrigation_local_dps1=hybrid_irrigation_snapshot%hybrid_irrigation_local_dps1
         hybrid_irrigation_local_dps2=hybrid_irrigation_snapshot%hybrid_irrigation_local_dps2
         hybrid_irrigation_local_tred=hybrid_irrigation_snapshot%hybrid_irrigation_local_tred
         hybrid_irrigation_local_dvstage=hybrid_irrigation_snapshot%hybrid_irrigation_local_dvstage
         hybrid_irrigation_local_trel=hybrid_irrigation_snapshot%hybrid_irrigation_local_trel
         hybrid_irrigation_local_raw=hybrid_irrigation_snapshot%hybrid_irrigation_local_raw
         hybrid_irrigation_local_taw=hybrid_irrigation_snapshot%hybrid_irrigation_local_taw
         hybrid_irrigation_local_dwa=hybrid_irrigation_snapshot%hybrid_irrigation_local_dwa
         hybrid_irrigation_local_hcri=hybrid_irrigation_snapshot%hybrid_irrigation_local_hcri
         hybrid_irrigation_local_tcri=hybrid_irrigation_snapshot%hybrid_irrigation_local_tcri
         hybrid_irrigation_local_di=hybrid_irrigation_snapshot%hybrid_irrigation_local_di
         hybrid_irrigation_local_fid=hybrid_irrigation_snapshot%hybrid_irrigation_local_fid
         hybrid_irrigation_local_irgdepmax=hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmax
         hybrid_irrigation_local_irgdepmin=hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmin
         hybrid_irrigation_local_irgthreshold=hybrid_irrigation_snapshot%hybrid_irrigation_local_irgthreshold
         hybrid_irrigation_local_fsec=hybrid_irrigation_snapshot%hybrid_irrigation_local_fsec
         hybrid_irrigation_local_grai_red=hybrid_irrigation_snapshot%hybrid_irrigation_local_grai_red
         hybrid_irrigation_local_dummy=hybrid_irrigation_snapshot%hybrid_irrigation_local_dummy
         hybrid_irrigation_local_wclos=hybrid_irrigation_snapshot%hybrid_irrigation_local_wclos
         hybrid_irrigation_local_wcmes=hybrid_irrigation_snapshot%hybrid_irrigation_local_wcmes
         hybrid_irrigation_local_wchis=hybrid_irrigation_snapshot%hybrid_irrigation_local_wchis
         hybrid_irrigation_local_ir_z=hybrid_irrigation_snapshot%hybrid_irrigation_local_ir_z
         hybrid_irrigation_local_flirritime=hybrid_irrigation_snapshot%hybrid_irrigation_local_flirritime
         hybrid_irrigation_local_message=hybrid_irrigation_snapshot%hybrid_irrigation_local_message
            schedule=0
         end if
      else
         nod_ssdi=hybrid_irrigation_snapshot%nod_ssdi
         irr_depth=hybrid_irrigation_snapshot%irr_depth
         irr_rate=hybrid_irrigation_snapshot%irr_rate
         dayfix=hybrid_irrigation_snapshot%dayfix
         irrigevent=hybrid_irrigation_snapshot%irrigevent
         irtype=hybrid_irrigation_snapshot%irtype
         isua=hybrid_irrigation_snapshot%isua
         isuas=hybrid_irrigation_snapshot%isuas
         nirri=hybrid_irrigation_snapshot%nirri
         schedule=hybrid_irrigation_snapshot%schedule
         swcirrthres=hybrid_irrigation_snapshot%swcirrthres
         cirr=hybrid_irrigation_snapshot%cirr
         cirrs=hybrid_irrigation_snapshot%cirrs
         cirrthres=hybrid_irrigation_snapshot%cirrthres
         dcrit=hybrid_irrigation_snapshot%dcrit
         ditab=hybrid_irrigation_snapshot%ditab
         dwatab=hybrid_irrigation_snapshot%dwatab
         dt_irr_event=hybrid_irrigation_snapshot%dt_irr_event
         fidtab=hybrid_irrigation_snapshot%fidtab
         gird=hybrid_irrigation_snapshot%gird
         hcritab=hybrid_irrigation_snapshot%hcritab
         irconc=hybrid_irrigation_snapshot%irconc
         irdate=hybrid_irrigation_snapshot%irdate
         irrate=hybrid_irrigation_snapshot%irrate
         irdepth=hybrid_irrigation_snapshot%irdepth
         ir_z=hybrid_irrigation_snapshot%ir_z
         nird=hybrid_irrigation_snapshot%nird
         perirrsurp=hybrid_irrigation_snapshot%perirrsurp
         qssdi=hybrid_irrigation_snapshot%qssdi
         qssdisum=hybrid_irrigation_snapshot%qssdisum
         raithreshold=hybrid_irrigation_snapshot%raithreshold
         rawtab=hybrid_irrigation_snapshot%rawtab
         tawtab=hybrid_irrigation_snapshot%tawtab
         tcritab=hybrid_irrigation_snapshot%tcritab
         tstairrig=hybrid_irrigation_snapshot%tstairrig
         tendirrig=hybrid_irrigation_snapshot%tendirrig
         treltab=hybrid_irrigation_snapshot%treltab
         flheadirg=hybrid_irrigation_snapshot%flheadirg
         flirrigate=hybrid_irrigation_snapshot%flirrigate
         sw_irrig=hybrid_irrigation_snapshot%sw_irrig
         f_irr_avail=hybrid_irrigation_snapshot%f_irr_avail
         tcs=hybrid_irrigation_snapshot%tcs
         tcsfix=hybrid_irrigation_snapshot%tcsfix
         dcslim=hybrid_irrigation_snapshot%dcslim
         dcs=hybrid_irrigation_snapshot%dcs
         irgdayfix=hybrid_irrigation_snapshot%irgdayfix
         yearendcrp=hybrid_irrigation_snapshot%yearendcrp
         yearstacrp=hybrid_irrigation_snapshot%yearstacrp
         tstairryrx=hybrid_irrigation_snapshot%tstairryrx
         tendirryrx=hybrid_irrigation_snapshot%tendirryrx
         hybrid_irrigation_local_node=hybrid_irrigation_snapshot%hybrid_irrigation_local_node
         hybrid_irrigation_local_nodsen=hybrid_irrigation_snapshot%hybrid_irrigation_local_nodsen
         hybrid_irrigation_local_ifnd=hybrid_irrigation_snapshot%hybrid_irrigation_local_ifnd
         hybrid_irrigation_local_i=hybrid_irrigation_snapshot%hybrid_irrigation_local_i
         hybrid_irrigation_local_j=hybrid_irrigation_snapshot%hybrid_irrigation_local_j
         hybrid_irrigation_local_datea=hybrid_irrigation_snapshot%hybrid_irrigation_local_datea
         hybrid_irrigation_local_endirr=hybrid_irrigation_snapshot%hybrid_irrigation_local_endirr
         hybrid_irrigation_local_startirr=hybrid_irrigation_snapshot%hybrid_irrigation_local_startirr
         hybrid_irrigation_local_frlow=hybrid_irrigation_snapshot%hybrid_irrigation_local_frlow
         hybrid_irrigation_local_phlo=hybrid_irrigation_snapshot%hybrid_irrigation_local_phlo
         hybrid_irrigation_local_phhi=hybrid_irrigation_snapshot%hybrid_irrigation_local_phhi
         hybrid_irrigation_local_phme=hybrid_irrigation_snapshot%hybrid_irrigation_local_phme
         hybrid_irrigation_local_awlh=hybrid_irrigation_snapshot%hybrid_irrigation_local_awlh
         hybrid_irrigation_local_awmh=hybrid_irrigation_snapshot%hybrid_irrigation_local_awmh
         hybrid_irrigation_local_awah=hybrid_irrigation_snapshot%hybrid_irrigation_local_awah
         hybrid_irrigation_local_cdef=hybrid_irrigation_snapshot%hybrid_irrigation_local_cdef
         hybrid_irrigation_local_wclo=hybrid_irrigation_snapshot%hybrid_irrigation_local_wclo
         hybrid_irrigation_local_wcme=hybrid_irrigation_snapshot%hybrid_irrigation_local_wcme
         hybrid_irrigation_local_wchi=hybrid_irrigation_snapshot%hybrid_irrigation_local_wchi
         hybrid_irrigation_local_wcac=hybrid_irrigation_snapshot%hybrid_irrigation_local_wcac
         hybrid_irrigation_local_tps1=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps1
         hybrid_irrigation_local_tps2=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps2
         hybrid_irrigation_local_tps3=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps3
         hybrid_irrigation_local_tps4=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps4
         hybrid_irrigation_local_tps5=hybrid_irrigation_snapshot%hybrid_irrigation_local_tps5
         hybrid_irrigation_local_depl=hybrid_irrigation_snapshot%hybrid_irrigation_local_depl
         hybrid_irrigation_local_phcrit=hybrid_irrigation_snapshot%hybrid_irrigation_local_phcrit
         hybrid_irrigation_local_dps1=hybrid_irrigation_snapshot%hybrid_irrigation_local_dps1
         hybrid_irrigation_local_dps2=hybrid_irrigation_snapshot%hybrid_irrigation_local_dps2
         hybrid_irrigation_local_tred=hybrid_irrigation_snapshot%hybrid_irrigation_local_tred
         hybrid_irrigation_local_dvstage=hybrid_irrigation_snapshot%hybrid_irrigation_local_dvstage
         hybrid_irrigation_local_trel=hybrid_irrigation_snapshot%hybrid_irrigation_local_trel
         hybrid_irrigation_local_raw=hybrid_irrigation_snapshot%hybrid_irrigation_local_raw
         hybrid_irrigation_local_taw=hybrid_irrigation_snapshot%hybrid_irrigation_local_taw
         hybrid_irrigation_local_dwa=hybrid_irrigation_snapshot%hybrid_irrigation_local_dwa
         hybrid_irrigation_local_hcri=hybrid_irrigation_snapshot%hybrid_irrigation_local_hcri
         hybrid_irrigation_local_tcri=hybrid_irrigation_snapshot%hybrid_irrigation_local_tcri
         hybrid_irrigation_local_di=hybrid_irrigation_snapshot%hybrid_irrigation_local_di
         hybrid_irrigation_local_fid=hybrid_irrigation_snapshot%hybrid_irrigation_local_fid
         hybrid_irrigation_local_irgdepmax=hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmax
         hybrid_irrigation_local_irgdepmin=hybrid_irrigation_snapshot%hybrid_irrigation_local_irgdepmin
         hybrid_irrigation_local_irgthreshold=hybrid_irrigation_snapshot%hybrid_irrigation_local_irgthreshold
         hybrid_irrigation_local_fsec=hybrid_irrigation_snapshot%hybrid_irrigation_local_fsec
         hybrid_irrigation_local_grai_red=hybrid_irrigation_snapshot%hybrid_irrigation_local_grai_red
         hybrid_irrigation_local_dummy=hybrid_irrigation_snapshot%hybrid_irrigation_local_dummy
         hybrid_irrigation_local_wclos=hybrid_irrigation_snapshot%hybrid_irrigation_local_wclos
         hybrid_irrigation_local_wcmes=hybrid_irrigation_snapshot%hybrid_irrigation_local_wcmes
         hybrid_irrigation_local_wchis=hybrid_irrigation_snapshot%hybrid_irrigation_local_wchis
         hybrid_irrigation_local_ir_z=hybrid_irrigation_snapshot%hybrid_irrigation_local_ir_z
         hybrid_irrigation_local_flirritime=hybrid_irrigation_snapshot%hybrid_irrigation_local_flirritime
         hybrid_irrigation_local_message=hybrid_irrigation_snapshot%hybrid_irrigation_local_message
      end if
      hybrid_irrigation_pending=.false.
   end subroutine

   subroutine hybrid_external_fixed(handled)
      use variables,only:t1900
      use MOD_swap_base,only:swirfix,swsolu
      use ieee_arithmetic,only:ieee_is_finite
      implicit none
      logical,intent(out)::handled
      integer::unit,ios,enabled
      real(8)::clock,depth,concentration,rate
      character(len=16)::version
      character(len=1)::extra
      inquire(file='hybrid-irrigation-day.in',exist=handled)
      if(.not.handled)return
      open(newunit=unit,file='hybrid-irrigation-day.in',status='old',action='read',iostat=ios)
      if(ios/=0)error stop 'Unreadable external irrigation'
      read(unit,*,iostat=ios)version,clock,enabled,depth,concentration,rate
      if(ios/=0)error stop 'Incomplete external irrigation'
      read(unit,*,iostat=ios)extra
      close(unit)
      if(ios>=0)error stop 'Trailing external irrigation input'
      if(version/='S5IRR002')error stop 'Foreign external irrigation protocol'
      if(.not.all(ieee_is_finite([clock,depth,concentration,rate]))) &
         error stop 'Nonfinite external irrigation'
      if(clock/=t1900.or.schedule/=0.or.swirfix/=1.or.swsolu/=0) &
         error stop 'Foreign external irrigation clock or mode'
      if(concentration/=0d0)error stop 'Water-only irrigation cannot carry solute'
      if(enabled/=0.and.enabled/=1)error stop 'Invalid external irrigation switch'
      if(enabled==0)then
         if(any([depth,concentration,rate]/=0d0))error stop 'Nonzero disabled irrigation'
      else
         if(depth<0.01d0.or.depth>100d0.or.concentration<0d0.or.concentration>1000d0.or. &
            rate<=0d0.or.rate>100d0)error stop 'External irrigation outside original range'
         if((0.1d0*depth)/(0.1d0*24d0*rate)>1d0)error stop 'External irrigation exceeds one day'
      end if
      ! Retain the original future table; suppress an original same-date event once.
      if(nirri<1.or.nirri>mairg)error stop 'Invalid original irrigation cursor'
      if(abs(irdate(nirri)-t1900)<1d-3)nirri=nirri+1
      if(enabled==1)then
         ! Original read_irrigation_fixed conversions, followed by task3 assignments.
         depth=0.1d0*depth
         rate=0.1d0*24d0*rate
         isua=1
         gird=rate
         cirr=concentration
         dt_irr_event=depth/rate
         irrigevent=1
      end if
      write(*,'(a,1x,f16.8,1x,i0,3(1x,es25.17e3))') &
         'HYBRID_IRRIGATION_INPUT',clock,enabled,depth,concentration,rate
   end subroutine

end module MOD_irrigation
