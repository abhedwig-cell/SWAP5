module hybrid_state_diagnostic
use MOD_grid,only:numnod
use variables,only:t1900
use plant_interface,only:component_0=>unit_crp
use plant_interface,only:component_1=>icrop
use plant_interface,only:component_2=>cropstart
use plant_interface,only:component_3=>cropend
use plant_interface,only:component_4=>croptype
use plant_interface,only:component_5=>co2
use plant_interface,only:component_6=>fco2amax
use plant_interface,only:component_7=>fco2eff
use plant_interface,only:component_8=>fco2tra
use plant_interface,only:component_9=>fl_start_croprotation
use plant_interface,only:component_10=>fl_start_cropemergence
use plant_interface,only:component_11=>fl_cropemergence
use plant_interface,only:component_12=>fl_cropharvest
use plant_interface,only:component_13=>fl_cropharvestday
use plant_interface,only:component_14=>fl_cropisreset
use plant_interface,only:component_15=>swcf
use plant_interface,only:component_16=>cf
use plant_interface,only:component_17=>ch
use plant_interface,only:component_18=>albedo
use plant_interface,only:component_19=>rsc
use plant_interface,only:component_20=>rsw
use plant_interface,only:component_21=>kdif
use plant_interface,only:component_22=>kdir
use plant_interface,only:component_23=>vcover
use plant_interface,only:component_24=>sw_drought
use plant_interface,only:component_25=>sw_oxygen
use plant_interface,only:component_26=>mrftb
use plant_interface,only:component_27=>max_resp_factor
use plant_interface,only:component_28=>q10_root
use plant_interface,only:component_29=>c_mroot
use plant_interface,only:component_30=>f_senes
use plant_interface,only:component_31=>sw_inter
use plant_interface,only:component_32=>dt_interc_event
use plant_interface,only:component_33=>cofab
use plant_interface,only:component_34=>pfreetb
use plant_interface,only:component_35=>pstemtb
use plant_interface,only:component_36=>scanopytb
use plant_interface,only:component_37=>avevaptb
use plant_interface,only:component_38=>avprectb
use plant_interface,only:component_39=>siccaplai
use plant_interface,only:component_40=>siccap
use plant_interface,only:component_41=>sicact
use plant_interface,only:component_42=>crsflx_in
use plant_interface,only:component_43=>crsflx_out
use plant_interface,only:component_44=>siccaploss
use plant_interface,only:component_45=>swrd
use plant_interface,only:component_46=>swrdc
use plant_interface,only:component_47=>swwrtnonox
use plant_interface,only:component_48=>aeratecrit
use plant_interface,only:component_49=>wrtmax
use plant_interface,only:component_50=>wroottb
use plant_interface,only:component_51=>noddrz
use plant_interface,only:component_52=>rd
use plant_interface,only:component_53=>dvs
use plant_interface,only:component_54=>lai
use plant_interface,only:component_55=>tsum
use plant_interface,only:component_56=>wrt
use plant_interface,only:component_57=>wst
use plant_interface,only:component_58=>wlv
use plant_interface,only:component_59=>wso
use plant_interface,only:component_60=>dwrt
use plant_interface,only:component_61=>dwst
use plant_interface,only:component_62=>dwlv
use plant_interface,only:component_63=>grrt
use plant_interface,only:component_64=>drrt
use plant_interface,only:component_65=>drst
use plant_interface,only:component_66=>drlv
use plant_interface,only:component_67=>ipgass
use plant_interface,only:component_68=>igass
use plant_interface,only:component_69=>imres
use plant_interface,only:component_70=>laipot
use plant_interface,only:component_71=>wrtpot
use plant_interface,only:component_72=>wstpot
use plant_interface,only:component_73=>wlvpot
use plant_interface,only:component_74=>wsopot
use plant_interface,only:component_75=>dwrtpot
use plant_interface,only:component_76=>dwstpot
use plant_interface,only:component_77=>dwlvpot
use plant_interface,only:component_78=>grrtpot
use plant_interface,only:component_79=>ipgasspot
use plant_interface,only:component_80=>igasspot
use plant_interface,only:component_81=>imrespot
use plant_interface,only:component_82=>dmhrv
use plant_interface,only:component_83=>dmloss
use plant_interface,only:component_84=>icut
use plant_interface,only:component_85=>tcut
use plant_interface,only:component_86=>dmhrvpot
use plant_interface,only:component_87=>dmlosspot
use plant_interface,only:component_88=>icutpot
use plant_interface,only:component_89=>tcutpot
use plant_interface,only:component_90=>hlim3h
use plant_interface,only:component_91=>hlim3l
use plant_interface,only:component_92=>hlim4
use atmosphere_interface,only:component_93=>tav
use atmosphere_interface,only:component_94=>rad
use atmosphere_interface,only:component_95=>grai
use variables,only:component_96=>h
use variables,only:component_97=>theta
use variables,only:component_98=>k
use variables,only:component_99=>kmean
use variables,only:component_100=>dimoca
use variables,only:component_101=>fhyst
use variables,only:component_102=>indeks
use variables,only:component_103=>dt
use variables,only:component_104=>dtold
use variables,only:component_105=>pond
use variables,only:component_106=>pondm1
use variables,only:component_107=>gwl
use variables,only:component_108=>volact
use MOD_MvG,only:component_109=>cofgen
use MOD_SoilTemperature,only:component_110=>tsoil
use MOD_SoilTemperature,only:component_111=>heacon
use MOD_SoilTemperature,only:component_112=>heacap
use MOD_SoilTemperature,only:component_113=>tetop
use MOD_SoilTemperature,only:component_114=>tebot
use MOD_top,only:component_115=>theatm
use MOD_top,only:component_116=>katm
use MOD_top,only:component_117=>q0
use MOD_top,only:component_118=>hsurf
use MOD_top,only:component_119=>FlRunoff
use MOD_top,only:component_120=>ftoph
implicit none
contains
subroutine hybrid_snapshot(phase)
character(*),intent(in)::phase
if(t1900<37780d0.or.t1900>37781d0)return
call dump_drainage(phase)


write(*,'(a,1x,a,1x,f18.8)')'DIAG_COMPONENT_BEGIN',phase,t1900
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.unit_crp',component_0
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.icrop',component_1
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.cropstart',component_2
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.cropend',component_3
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.croptype',component_4
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.co2',component_5
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.fco2amax',component_6
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.fco2eff',component_7
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.fco2tra',component_8
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_start_croprotation',component_9
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_start_cropemergence',component_10
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_cropemergence',component_11
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_cropharvest',component_12
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_cropharvestday',component_13
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_cropisreset',component_14
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.swcf',component_15
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.cf',component_16
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.ch',component_17
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.albedo',component_18
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.rsc',component_19
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.rsw',component_20
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.kdif',component_21
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.kdir',component_22
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.vcover',component_23
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.sw_drought',component_24
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.sw_oxygen',component_25
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.mrftb',component_26
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.max_resp_factor',component_27
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.q10_root',component_28
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.c_mroot',component_29
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.f_senes',component_30
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.sw_inter',component_31
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dt_interc_event',component_32
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.cofab',component_33
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.pfreetb',component_34
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.pstemtb',component_35
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.scanopytb',component_36
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.avevaptb',component_37
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.avprectb',component_38
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.siccaplai',component_39
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.siccap',component_40
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.sicact',component_41
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.crsflx_in',component_42
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.crsflx_out',component_43
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.siccaploss',component_44
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.swrd',component_45
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.swrdc',component_46
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.swwrtnonox',component_47
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.aeratecrit',component_48
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wrtmax',component_49
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wroottb',component_50
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.noddrz',component_51
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.rd',component_52
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dvs',component_53
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.lai',component_54
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.tsum',component_55
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wrt',component_56
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wst',component_57
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wlv',component_58
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wso',component_59
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwrt',component_60
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwst',component_61
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwlv',component_62
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.grrt',component_63
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.drrt',component_64
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.drst',component_65
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.drlv',component_66
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.ipgass',component_67
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.igass',component_68
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.imres',component_69
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.laipot',component_70
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wrtpot',component_71
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wstpot',component_72
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wlvpot',component_73
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wsopot',component_74
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwrtpot',component_75
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwstpot',component_76
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwlvpot',component_77
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.grrtpot',component_78
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.ipgasspot',component_79
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.igasspot',component_80
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.imrespot',component_81
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dmhrv',component_82
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dmloss',component_83
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.icut',component_84
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.tcut',component_85
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dmhrvpot',component_86
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dmlosspot',component_87
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.icutpot',component_88
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.tcutpot',component_89
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.hlim3h',component_90
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.hlim3l',component_91
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.hlim4',component_92
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD atmosphere_interface.tav',component_93
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD atmosphere_interface.rad',component_94
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD atmosphere_interface.grai',component_95
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.h',component_96(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.theta',component_97(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.k',component_98(1:numnod+1)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.kmean',component_99(1:numnod+1)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.dimoca',component_100(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.fhyst',component_101(1:numnod)
write(*,'(a,*(1x,i0))') 'DIAG_FIELD variables.indeks',component_102(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.dt',component_103
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.dtold',component_104
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.pond',component_105
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.pondm1',component_106
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.gwl',component_107
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.volact',component_108
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_MvG.cofgen',component_109(:,1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.tsoil',component_110(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.heacon',component_111(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.heacap',component_112(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.tetop',component_113
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.tebot',component_114
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_top.theatm',component_115
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_top.katm',component_116
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_top.q0',component_117
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_top.hsurf',component_118
write(*,'(a,*(1x,l1))') 'DIAG_FIELD MOD_top.FlRunoff',component_119
write(*,'(a,*(1x,l1))') 'DIAG_FIELD MOD_top.ftoph',component_120
write(*,'(a)')'DIAG_COMPONENT_END'
end subroutine
subroutine dump_drainage(phase)
use variables,only:drain_field_0=>nprintday
use variables,only:drain_field_1=>flprintdt
use variables,only:drain_field_2=>flprintshort
use variables,only:drain_field_3=>floutputshort
use variables,only:drain_field_4=>nprintcount
use variables,only:drain_field_5=>cntper
use variables,only:drain_field_6=>daycum
use variables,only:drain_field_7=>daynr
use variables,only:drain_field_8=>imonth
use variables,only:drain_field_9=>ioutdat
use variables,only:drain_field_10=>ioutdatint
use variables,only:drain_field_11=>isteps
use variables,only:drain_field_12=>iyear
use variables,only:drain_field_13=>numbit_crit
use variables,only:drain_field_14=>period
use variables,only:drain_field_15=>swheader
use variables,only:drain_field_16=>swodat
use variables,only:drain_field_17=>swres
use variables,only:drain_field_18=>dt
use variables,only:drain_field_19=>dtmax
use variables,only:drain_field_20=>dtmin
use variables,only:drain_field_21=>dtold
use variables,only:drain_field_22=>fact_dt_increase
use variables,only:drain_field_23=>fact_dt_decrease
use variables,only:drain_field_24=>fact_dt_fldect
use variables,only:drain_field_25=>outdat
use variables,only:drain_field_26=>outdatint
use variables,only:drain_field_27=>outper
use variables,only:drain_field_28=>t
use variables,only:drain_field_29=>t1900
use variables,only:drain_field_30=>tcum
use variables,only:drain_field_31=>timjan1
use variables,only:drain_field_32=>tend
use variables,only:drain_field_33=>tstart
use variables,only:drain_field_34=>flbaloutput
use variables,only:drain_field_35=>fldayend
use variables,only:drain_field_36=>fldaystart
use variables,only:drain_field_37=>fldecdt
use variables,only:drain_field_38=>fldtmin
use variables,only:drain_field_39=>fldtreduce
use variables,only:drain_field_40=>flheader
use variables,only:drain_field_41=>floutput
use variables,only:drain_field_42=>flrunend
use variables,only:drain_field_43=>flzerocumu
use variables,only:drain_field_44=>flzerointr
use variables,only:drain_field_45=>bal
use variables,only:drain_field_46=>blc
use variables,only:drain_field_47=>bpegwl
use variables,only:drain_field_48=>indeks
use variables,only:drain_field_49=>Itnumb
use variables,only:drain_field_50=>MaxBackTr
use variables,only:drain_field_51=>MaxIt
use variables,only:drain_field_52=>MaxIterTime
use variables,only:drain_field_53=>msteps
use variables,only:drain_field_54=>nhead
use variables,only:drain_field_55=>nodgwl
use variables,only:drain_field_56=>npegwl
use variables,only:drain_field_57=>numbit
use variables,only:drain_field_58=>sw2
use variables,only:drain_field_59=>sw3
use variables,only:drain_field_60=>sw4
use variables,only:drain_field_61=>swafo
use variables,only:drain_field_62=>swaun
use variables,only:drain_field_63=>swbal
use variables,only:drain_field_64=>swblc
use variables,only:drain_field_65=>swbotb
use variables,only:drain_field_66=>swbotb3Impl
use variables,only:drain_field_67=>SwBotb3ResVert
use variables,only:drain_field_68=>swcfbs
use variables,only:drain_field_69=>swcofqhc
use variables,only:drain_field_70=>swcsv
use variables,only:drain_field_71=>swkimpl
use variables,only:drain_field_72=>swkmean
use variables,only:drain_field_73=>swqhbot
use variables,only:drain_field_74=>swredu
use variables,only:drain_field_75=>swsba
use variables,only:drain_field_76=>aqamp
use variables,only:drain_field_77=>aqave
use variables,only:drain_field_78=>aqper
use variables,only:drain_field_79=>aqtmax
use variables,only:drain_field_80=>cfbs
use variables,only:drain_field_81=>cofqha
use variables,only:drain_field_82=>cofqhb
use variables,only:drain_field_83=>cofqhc
use variables,only:drain_field_84=>cofred
use variables,only:drain_field_85=>CritDevBalCp
use variables,only:drain_field_86=>CritDevBalTot
use variables,only:drain_field_87=>CritDevh1Cp
use variables,only:drain_field_88=>CritDevh2Cp
use variables,only:drain_field_89=>CritDevMasBal
use variables,only:drain_field_90=>CritDevPondDt
use variables,only:drain_field_91=>CriterHr
use variables,only:drain_field_92=>deepgw
use variables,only:drain_field_93=>delp
use variables,only:drain_field_94=>dimoca
use variables,only:drain_field_95=>dznew
use variables,only:drain_field_96=>fhyst
use variables,only:drain_field_97=>gwl
use variables,only:drain_field_98=>gwlconv
use variables,only:drain_field_99=>gwli
use variables,only:drain_field_100=>gwlinp
use variables,only:drain_field_101=>gwlm1
use variables,only:drain_field_102=>gwltab
use variables,only:drain_field_103=>htb
use variables,only:drain_field_104=>h
use variables,only:drain_field_105=>haqtab
use variables,only:drain_field_106=>hbot
use variables,only:drain_field_107=>hbotab
use variables,only:drain_field_108=>hdrain
use variables,only:drain_field_109=>hm1
use variables,only:drain_field_110=>hplate
use variables,only:drain_field_111=>ivolbeg
use variables,only:drain_field_112=>ipondbeg
use variables,only:drain_field_113=>isicbeg
use variables,only:drain_field_114=>issnowbeg
use variables,only:drain_field_115=>ithetabeg
use variables,only:drain_field_116=>k
use variables,only:drain_field_117=>kbot
use variables,only:drain_field_118=>kmean
use variables,only:drain_field_119=>ksatfit
use variables,only:drain_field_120=>ksatexm
use variables,only:drain_field_121=>ldwet
use variables,only:drain_field_122=>pegwl
use variables,only:drain_field_123=>pegwl_bot
use variables,only:drain_field_124=>pond
use variables,only:drain_field_125=>pondini
use variables,only:drain_field_126=>pondm1
use variables,only:drain_field_127=>pondmx
use variables,only:drain_field_128=>pondmxtab
use variables,only:drain_field_129=>q
use variables,only:drain_field_130=>qbot
use variables,only:drain_field_131=>qbotab
use variables,only:drain_field_132=>qbot_nonfrozen
use variables,only:drain_field_133=>qimmob
use variables,only:drain_field_134=>qrot
use variables,only:drain_field_135=>qtop
use variables,only:drain_field_136=>epd
use variables,only:drain_field_137=>reva
use variables,only:drain_field_138=>rimlay
use variables,only:drain_field_139=>rsigni
use variables,only:drain_field_140=>rsoil
use variables,only:drain_field_141=>rsro
use variables,only:drain_field_142=>rsroexp
use variables,only:drain_field_143=>runon
use variables,only:drain_field_144=>runots
use variables,only:drain_field_145=>saev
use variables,only:drain_field_146=>shape_3
use variables,only:drain_field_147=>sinamp
use variables,only:drain_field_148=>sinave
use variables,only:drain_field_149=>sinmax
use variables,only:drain_field_150=>spev
use variables,only:drain_field_151=>tau
use variables,only:drain_field_152=>theta
use variables,only:drain_field_153=>thetar
use variables,only:drain_field_154=>thetas
use variables,only:drain_field_155=>thetm1
use variables,only:drain_field_156=>thetsl
use variables,only:drain_field_157=>volact
use variables,only:drain_field_158=>volini
use variables,only:drain_field_159=>volm1
use variables,only:drain_field_160=>zi
use variables,only:drain_field_161=>flksatexm
use variables,only:drain_field_162=>fllowgwl
use variables,only:drain_field_163=>fluseksatexm
use variables,only:drain_field_164=>flMaxIterTime
implicit none
character(*),intent(in)::phase
integer::unit
if(abs(t1900-37780d0)>1d-8)return
if(phase/='BEFORE_METEO3'.and.phase/='BEFORE_DRAIN2'.and.phase/='AFTER_DRAIN2')return
open(newunit=unit,file='diagnostic-drain-'//trim(phase)//'.bin',access='stream',form='unformatted',status='replace')
write(unit)drain_field_0
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nprintday',2,1,storage_size(drain_field_0)
write(unit)drain_field_1
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'flprintdt',3,1,storage_size(drain_field_1)
write(unit)drain_field_2
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'flprintshort',3,1,storage_size(drain_field_2)
write(unit)drain_field_3
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'floutputshort',3,1,storage_size(drain_field_3)
write(unit)drain_field_4
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nprintcount',2,1,storage_size(drain_field_4)
write(unit)drain_field_5
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'cntper',2,1,storage_size(drain_field_5)
write(unit)drain_field_6
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'daycum',2,1,storage_size(drain_field_6)
write(unit)drain_field_7
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'daynr',2,1,storage_size(drain_field_7)
write(unit)drain_field_8
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'imonth',2,1,storage_size(drain_field_8)
write(unit)drain_field_9
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ioutdat',2,1,storage_size(drain_field_9)
write(unit)drain_field_10
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ioutdatint',2,1,storage_size(drain_field_10)
write(unit)drain_field_11
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'isteps',2,1,storage_size(drain_field_11)
write(unit)drain_field_12
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'iyear',2,1,storage_size(drain_field_12)
write(unit)drain_field_13
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'numbit_crit',2,1,storage_size(drain_field_13)
write(unit)drain_field_14
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'period',2,1,storage_size(drain_field_14)
write(unit)drain_field_15
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swheader',2,1,storage_size(drain_field_15)
write(unit)drain_field_16
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swodat',2,1,storage_size(drain_field_16)
write(unit)drain_field_17
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swres',2,1,storage_size(drain_field_17)
write(unit)drain_field_18
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'dt',1,1,storage_size(drain_field_18)
write(unit)drain_field_19
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'dtmax',1,1,storage_size(drain_field_19)
write(unit)drain_field_20
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'dtmin',1,1,storage_size(drain_field_20)
write(unit)drain_field_21
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'dtold',1,1,storage_size(drain_field_21)
write(unit)drain_field_22
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fact_dt_increase',1,1,storage_size(drain_field_22)
write(unit)drain_field_23
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fact_dt_decrease',1,1,storage_size(drain_field_23)
write(unit)drain_field_24
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fact_dt_fldect',1,1,storage_size(drain_field_24)
write(unit)drain_field_25
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'outdat',1,size(drain_field_25),storage_size(drain_field_25)
write(unit)drain_field_26
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'outdatint',1,size(drain_field_26),storage_size(drain_field_26)
write(unit)drain_field_27
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'outper',1,1,storage_size(drain_field_27)
write(unit)drain_field_28
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'t',1,1,storage_size(drain_field_28)
write(unit)drain_field_29
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'t1900',1,1,storage_size(drain_field_29)
write(unit)drain_field_30
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'tcum',1,1,storage_size(drain_field_30)
write(unit)drain_field_31
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'timjan1',1,1,storage_size(drain_field_31)
write(unit)drain_field_32
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'tend',1,1,storage_size(drain_field_32)
write(unit)drain_field_33
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'tstart',1,1,storage_size(drain_field_33)
write(unit)drain_field_34
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'flbaloutput',3,1,storage_size(drain_field_34)
write(unit)drain_field_35
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fldayend',3,1,storage_size(drain_field_35)
write(unit)drain_field_36
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fldaystart',3,1,storage_size(drain_field_36)
write(unit)drain_field_37
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fldecdt',3,1,storage_size(drain_field_37)
write(unit)drain_field_38
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fldtmin',3,1,storage_size(drain_field_38)
write(unit)drain_field_39
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fldtreduce',3,1,storage_size(drain_field_39)
write(unit)drain_field_40
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'flheader',3,1,storage_size(drain_field_40)
write(unit)drain_field_41
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'floutput',3,1,storage_size(drain_field_41)
write(unit)drain_field_42
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'flrunend',3,1,storage_size(drain_field_42)
write(unit)drain_field_43
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'flzerocumu',3,1,storage_size(drain_field_43)
write(unit)drain_field_44
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'flzerointr',3,1,storage_size(drain_field_44)
write(unit)drain_field_45
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'bal',2,1,storage_size(drain_field_45)
write(unit)drain_field_46
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'blc',2,1,storage_size(drain_field_46)
write(unit)drain_field_47
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'bpegwl',2,1,storage_size(drain_field_47)
write(unit)drain_field_48
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'indeks',2,size(drain_field_48),storage_size(drain_field_48)
write(unit)drain_field_49
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'Itnumb',2,size(drain_field_49),storage_size(drain_field_49)
write(unit)drain_field_50
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'MaxBackTr',2,1,storage_size(drain_field_50)
write(unit)drain_field_51
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'MaxIt',2,1,storage_size(drain_field_51)
write(unit)drain_field_52
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'MaxIterTime',2,1,storage_size(drain_field_52)
write(unit)drain_field_53
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'msteps',2,1,storage_size(drain_field_53)
write(unit)drain_field_54
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nhead',2,1,storage_size(drain_field_54)
write(unit)drain_field_55
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nodgwl',2,1,storage_size(drain_field_55)
write(unit)drain_field_56
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'npegwl',2,1,storage_size(drain_field_56)
write(unit)drain_field_57
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'numbit',2,1,storage_size(drain_field_57)
write(unit)drain_field_58
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'sw2',2,1,storage_size(drain_field_58)
write(unit)drain_field_59
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'sw3',2,1,storage_size(drain_field_59)
write(unit)drain_field_60
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'sw4',2,1,storage_size(drain_field_60)
write(unit)drain_field_61
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swafo',2,1,storage_size(drain_field_61)
write(unit)drain_field_62
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swaun',2,1,storage_size(drain_field_62)
write(unit)drain_field_63
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swbal',2,1,storage_size(drain_field_63)
write(unit)drain_field_64
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swblc',2,1,storage_size(drain_field_64)
write(unit)drain_field_65
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swbotb',2,1,storage_size(drain_field_65)
write(unit)drain_field_66
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swbotb3Impl',2,1,storage_size(drain_field_66)
write(unit)drain_field_67
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'SwBotb3ResVert',2,1,storage_size(drain_field_67)
write(unit)drain_field_68
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swcfbs',2,1,storage_size(drain_field_68)
write(unit)drain_field_69
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swcofqhc',2,1,storage_size(drain_field_69)
write(unit)drain_field_70
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swcsv',2,1,storage_size(drain_field_70)
write(unit)drain_field_71
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swkimpl',2,1,storage_size(drain_field_71)
write(unit)drain_field_72
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swkmean',2,1,storage_size(drain_field_72)
write(unit)drain_field_73
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swqhbot',2,1,storage_size(drain_field_73)
write(unit)drain_field_74
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swredu',2,1,storage_size(drain_field_74)
write(unit)drain_field_75
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swsba',2,1,storage_size(drain_field_75)
write(unit)drain_field_76
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'aqamp',1,1,storage_size(drain_field_76)
write(unit)drain_field_77
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'aqave',1,1,storage_size(drain_field_77)
write(unit)drain_field_78
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'aqper',1,1,storage_size(drain_field_78)
write(unit)drain_field_79
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'aqtmax',1,1,storage_size(drain_field_79)
write(unit)drain_field_80
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'cfbs',1,1,storage_size(drain_field_80)
write(unit)drain_field_81
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'cofqha',1,1,storage_size(drain_field_81)
write(unit)drain_field_82
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'cofqhb',1,1,storage_size(drain_field_82)
write(unit)drain_field_83
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'cofqhc',1,1,storage_size(drain_field_83)
write(unit)drain_field_84
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'cofred',1,1,storage_size(drain_field_84)
write(unit)drain_field_85
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'CritDevBalCp',1,1,storage_size(drain_field_85)
write(unit)drain_field_86
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'CritDevBalTot',1,1,storage_size(drain_field_86)
write(unit)drain_field_87
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'CritDevh1Cp',1,1,storage_size(drain_field_87)
write(unit)drain_field_88
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'CritDevh2Cp',1,1,storage_size(drain_field_88)
write(unit)drain_field_89
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'CritDevMasBal',1,1,storage_size(drain_field_89)
write(unit)drain_field_90
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'CritDevPondDt',1,1,storage_size(drain_field_90)
write(unit)drain_field_91
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'CriterHr',1,1,storage_size(drain_field_91)
write(unit)drain_field_92
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'deepgw',1,1,storage_size(drain_field_92)
write(unit)drain_field_93
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'delp',1,size(drain_field_93),storage_size(drain_field_93)
write(unit)drain_field_94
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'dimoca',1,size(drain_field_94),storage_size(drain_field_94)
write(unit)drain_field_95
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'dznew',1,size(drain_field_95),storage_size(drain_field_95)
write(unit)drain_field_96
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fhyst',1,size(drain_field_96),storage_size(drain_field_96)
write(unit)drain_field_97
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'gwl',1,1,storage_size(drain_field_97)
write(unit)drain_field_98
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'gwlconv',1,1,storage_size(drain_field_98)
write(unit)drain_field_99
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'gwli',1,1,storage_size(drain_field_99)
write(unit)drain_field_100
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'gwlinp',1,1,storage_size(drain_field_100)
write(unit)drain_field_101
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'gwlm1',1,1,storage_size(drain_field_101)
write(unit)drain_field_102
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'gwltab',1,size(drain_field_102),storage_size(drain_field_102)
if(allocated(drain_field_103))then
write(unit)drain_field_103
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'htb',1,size(drain_field_103),storage_size(drain_field_103)
else
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'htb',1,-1,64
end if
write(unit)drain_field_104
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'h',1,size(drain_field_104),storage_size(drain_field_104)
write(unit)drain_field_105
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'haqtab',1,size(drain_field_105),storage_size(drain_field_105)
write(unit)drain_field_106
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'hbot',1,1,storage_size(drain_field_106)
write(unit)drain_field_107
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'hbotab',1,size(drain_field_107),storage_size(drain_field_107)
write(unit)drain_field_108
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'hdrain',1,1,storage_size(drain_field_108)
write(unit)drain_field_109
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'hm1',1,size(drain_field_109),storage_size(drain_field_109)
write(unit)drain_field_110
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'hplate',1,1,storage_size(drain_field_110)
write(unit)drain_field_111
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ivolbeg',1,1,storage_size(drain_field_111)
write(unit)drain_field_112
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ipondbeg',1,1,storage_size(drain_field_112)
write(unit)drain_field_113
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'isicbeg',1,1,storage_size(drain_field_113)
write(unit)drain_field_114
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'issnowbeg',1,1,storage_size(drain_field_114)
write(unit)drain_field_115
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ithetabeg',1,size(drain_field_115),storage_size(drain_field_115)
write(unit)drain_field_116
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'k',1,size(drain_field_116),storage_size(drain_field_116)
write(unit)drain_field_117
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'kbot',1,1,storage_size(drain_field_117)
write(unit)drain_field_118
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'kmean',1,size(drain_field_118),storage_size(drain_field_118)
write(unit)drain_field_119
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ksatfit',1,size(drain_field_119),storage_size(drain_field_119)
write(unit)drain_field_120
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ksatexm',1,size(drain_field_120),storage_size(drain_field_120)
write(unit)drain_field_121
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ldwet',1,1,storage_size(drain_field_121)
write(unit)drain_field_122
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'pegwl',1,1,storage_size(drain_field_122)
write(unit)drain_field_123
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'pegwl_bot',1,1,storage_size(drain_field_123)
write(unit)drain_field_124
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'pond',1,1,storage_size(drain_field_124)
write(unit)drain_field_125
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'pondini',1,1,storage_size(drain_field_125)
write(unit)drain_field_126
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'pondm1',1,1,storage_size(drain_field_126)
write(unit)drain_field_127
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'pondmx',1,1,storage_size(drain_field_127)
write(unit)drain_field_128
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'pondmxtab',1,size(drain_field_128),storage_size(drain_field_128)
write(unit)drain_field_129
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'q',1,size(drain_field_129),storage_size(drain_field_129)
write(unit)drain_field_130
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qbot',1,1,storage_size(drain_field_130)
write(unit)drain_field_131
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qbotab',1,size(drain_field_131),storage_size(drain_field_131)
write(unit)drain_field_132
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qbot_nonfrozen',1,1,storage_size(drain_field_132)
write(unit)drain_field_133
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qimmob',1,size(drain_field_133),storage_size(drain_field_133)
write(unit)drain_field_134
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qrot',1,size(drain_field_134),storage_size(drain_field_134)
write(unit)drain_field_135
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qtop',1,1,storage_size(drain_field_135)
write(unit)drain_field_136
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'epd',1,1,storage_size(drain_field_136)
write(unit)drain_field_137
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'reva',1,1,storage_size(drain_field_137)
write(unit)drain_field_138
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rimlay',1,1,storage_size(drain_field_138)
write(unit)drain_field_139
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rsigni',1,1,storage_size(drain_field_139)
write(unit)drain_field_140
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rsoil',1,1,storage_size(drain_field_140)
write(unit)drain_field_141
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rsro',1,1,storage_size(drain_field_141)
write(unit)drain_field_142
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rsroexp',1,1,storage_size(drain_field_142)
write(unit)drain_field_143
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'runon',1,1,storage_size(drain_field_143)
write(unit)drain_field_144
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'runots',1,1,storage_size(drain_field_144)
write(unit)drain_field_145
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'saev',1,1,storage_size(drain_field_145)
write(unit)drain_field_146
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'shape_3',1,1,storage_size(drain_field_146)
write(unit)drain_field_147
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'sinamp',1,1,storage_size(drain_field_147)
write(unit)drain_field_148
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'sinave',1,1,storage_size(drain_field_148)
write(unit)drain_field_149
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'sinmax',1,1,storage_size(drain_field_149)
write(unit)drain_field_150
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'spev',1,1,storage_size(drain_field_150)
write(unit)drain_field_151
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'tau',1,1,storage_size(drain_field_151)
write(unit)drain_field_152
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'theta',1,size(drain_field_152),storage_size(drain_field_152)
write(unit)drain_field_153
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'thetar',1,size(drain_field_153),storage_size(drain_field_153)
write(unit)drain_field_154
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'thetas',1,size(drain_field_154),storage_size(drain_field_154)
write(unit)drain_field_155
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'thetm1',1,size(drain_field_155),storage_size(drain_field_155)
write(unit)drain_field_156
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'thetsl',1,size(drain_field_156),storage_size(drain_field_156)
write(unit)drain_field_157
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'volact',1,1,storage_size(drain_field_157)
write(unit)drain_field_158
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'volini',1,1,storage_size(drain_field_158)
write(unit)drain_field_159
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'volm1',1,1,storage_size(drain_field_159)
write(unit)drain_field_160
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'zi',1,size(drain_field_160),storage_size(drain_field_160)
write(unit)drain_field_161
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'flksatexm',3,1,storage_size(drain_field_161)
write(unit)drain_field_162
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fllowgwl',3,1,storage_size(drain_field_162)
write(unit)drain_field_163
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'fluseksatexm',3,size(drain_field_163),storage_size(drain_field_163)
write(unit)drain_field_164
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'flMaxIterTime',3,1,storage_size(drain_field_164)
close(unit)
end subroutine
end module
