module hybrid_state_diagnostic
use MOD_grid,only:numnod
use variables,only:t1900
use plant_interface,only:component_0=>unit_crp
use plant_interface,only:component_1=>icrop
use plant_interface,only:component_2=>cropstart
use plant_interface,only:component_3=>cropend
use plant_interface,only:component_4=>croptype
use plant_interface,only:component_5=>co2
use plant_interface,only:component_6=>fco2amax
use plant_interface,only:component_7=>fco2eff
use plant_interface,only:component_8=>fco2tra
use plant_interface,only:component_9=>fl_start_croprotation
use plant_interface,only:component_10=>fl_start_cropemergence
use plant_interface,only:component_11=>fl_cropemergence
use plant_interface,only:component_12=>fl_cropharvest
use plant_interface,only:component_13=>fl_cropharvestday
use plant_interface,only:component_14=>fl_cropisreset
use plant_interface,only:component_15=>swcf
use plant_interface,only:component_16=>cf
use plant_interface,only:component_17=>ch
use plant_interface,only:component_18=>albedo
use plant_interface,only:component_19=>rsc
use plant_interface,only:component_20=>rsw
use plant_interface,only:component_21=>kdif
use plant_interface,only:component_22=>kdir
use plant_interface,only:component_23=>vcover
use plant_interface,only:component_24=>sw_drought
use plant_interface,only:component_25=>sw_oxygen
use plant_interface,only:component_26=>mrftb
use plant_interface,only:component_27=>max_resp_factor
use plant_interface,only:component_28=>q10_root
use plant_interface,only:component_29=>c_mroot
use plant_interface,only:component_30=>f_senes
use plant_interface,only:component_31=>sw_inter
use plant_interface,only:component_32=>dt_interc_event
use plant_interface,only:component_33=>cofab
use plant_interface,only:component_34=>pfreetb
use plant_interface,only:component_35=>pstemtb
use plant_interface,only:component_36=>scanopytb
use plant_interface,only:component_37=>avevaptb
use plant_interface,only:component_38=>avprectb
use plant_interface,only:component_39=>siccaplai
use plant_interface,only:component_40=>siccap
use plant_interface,only:component_41=>sicact
use plant_interface,only:component_42=>crsflx_in
use plant_interface,only:component_43=>crsflx_out
use plant_interface,only:component_44=>siccaploss
use plant_interface,only:component_45=>swrd
use plant_interface,only:component_46=>swrdc
use plant_interface,only:component_47=>swwrtnonox
use plant_interface,only:component_48=>aeratecrit
use plant_interface,only:component_49=>wrtmax
use plant_interface,only:component_50=>wroottb
use plant_interface,only:component_51=>noddrz
use plant_interface,only:component_52=>rd
use plant_interface,only:component_53=>dvs
use plant_interface,only:component_54=>lai
use plant_interface,only:component_55=>tsum
use plant_interface,only:component_56=>wrt
use plant_interface,only:component_57=>wst
use plant_interface,only:component_58=>wlv
use plant_interface,only:component_59=>wso
use plant_interface,only:component_60=>dwrt
use plant_interface,only:component_61=>dwst
use plant_interface,only:component_62=>dwlv
use plant_interface,only:component_63=>grrt
use plant_interface,only:component_64=>drrt
use plant_interface,only:component_65=>drst
use plant_interface,only:component_66=>drlv
use plant_interface,only:component_67=>ipgass
use plant_interface,only:component_68=>igass
use plant_interface,only:component_69=>imres
use plant_interface,only:component_70=>laipot
use plant_interface,only:component_71=>wrtpot
use plant_interface,only:component_72=>wstpot
use plant_interface,only:component_73=>wlvpot
use plant_interface,only:component_74=>wsopot
use plant_interface,only:component_75=>dwrtpot
use plant_interface,only:component_76=>dwstpot
use plant_interface,only:component_77=>dwlvpot
use plant_interface,only:component_78=>grrtpot
use plant_interface,only:component_79=>ipgasspot
use plant_interface,only:component_80=>igasspot
use plant_interface,only:component_81=>imrespot
use plant_interface,only:component_82=>dmhrv
use plant_interface,only:component_83=>dmloss
use plant_interface,only:component_84=>icut
use plant_interface,only:component_85=>tcut
use plant_interface,only:component_86=>dmhrvpot
use plant_interface,only:component_87=>dmlosspot
use plant_interface,only:component_88=>icutpot
use plant_interface,only:component_89=>tcutpot
use plant_interface,only:component_90=>hlim3h
use plant_interface,only:component_91=>hlim3l
use plant_interface,only:component_92=>hlim4
use atmosphere_interface,only:component_93=>tav
use atmosphere_interface,only:component_94=>rad
use atmosphere_interface,only:component_95=>grai
use variables,only:component_96=>h
use variables,only:component_97=>theta
use variables,only:component_98=>k
use variables,only:component_99=>kmean
use variables,only:component_100=>dimoca
use variables,only:component_101=>fhyst
use variables,only:component_102=>indeks
use variables,only:component_103=>dt
use variables,only:component_104=>dtold
use variables,only:component_105=>pond
use variables,only:component_106=>pondm1
use variables,only:component_107=>gwl
use variables,only:component_108=>volact
use MOD_MvG,only:component_109=>cofgen
use MOD_SoilTemperature,only:component_110=>tsoil
use MOD_SoilTemperature,only:component_111=>heacon
use MOD_SoilTemperature,only:component_112=>heacap
use MOD_SoilTemperature,only:component_113=>tetop
use MOD_SoilTemperature,only:component_114=>tebot
use MOD_top,only:component_115=>theatm
use MOD_top,only:component_116=>katm
use MOD_top,only:component_117=>q0
use MOD_top,only:component_118=>hsurf
use MOD_top,only:component_119=>FlRunoff
use MOD_top,only:component_120=>ftoph
implicit none
contains
subroutine hybrid_snapshot(phase)
character(*),intent(in)::phase
if(t1900<37786d0.or.t1900>37787d0)return
call dump_drainage(phase)

write(*,'(a,1x,a,1x,f18.8)')'DIAG_COMPONENT_BEGIN',phase,t1900
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.unit_crp',component_0
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.icrop',component_1
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.cropstart',component_2
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.cropend',component_3
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.croptype',component_4
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.co2',component_5
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.fco2amax',component_6
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.fco2eff',component_7
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.fco2tra',component_8
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_start_croprotation',component_9
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_start_cropemergence',component_10
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_cropemergence',component_11
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_cropharvest',component_12
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_cropharvestday',component_13
write(*,'(a,*(1x,l1))') 'DIAG_FIELD plant_interface.fl_cropisreset',component_14
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.swcf',component_15
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.cf',component_16
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.ch',component_17
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.albedo',component_18
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.rsc',component_19
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.rsw',component_20
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.kdif',component_21
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.kdir',component_22
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.vcover',component_23
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.sw_drought',component_24
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.sw_oxygen',component_25
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.mrftb',component_26
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.max_resp_factor',component_27
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.q10_root',component_28
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.c_mroot',component_29
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.f_senes',component_30
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.sw_inter',component_31
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dt_interc_event',component_32
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.cofab',component_33
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.pfreetb',component_34
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.pstemtb',component_35
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.scanopytb',component_36
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.avevaptb',component_37
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.avprectb',component_38
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.siccaplai',component_39
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.siccap',component_40
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.sicact',component_41
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.crsflx_in',component_42
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.crsflx_out',component_43
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.siccaploss',component_44
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.swrd',component_45
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.swrdc',component_46
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.swwrtnonox',component_47
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.aeratecrit',component_48
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wrtmax',component_49
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wroottb',component_50
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.noddrz',component_51
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.rd',component_52
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dvs',component_53
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.lai',component_54
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.tsum',component_55
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wrt',component_56
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wst',component_57
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wlv',component_58
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wso',component_59
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwrt',component_60
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwst',component_61
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwlv',component_62
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.grrt',component_63
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.drrt',component_64
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.drst',component_65
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.drlv',component_66
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.ipgass',component_67
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.igass',component_68
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.imres',component_69
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.laipot',component_70
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wrtpot',component_71
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wstpot',component_72
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wlvpot',component_73
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.wsopot',component_74
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwrtpot',component_75
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwstpot',component_76
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dwlvpot',component_77
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.grrtpot',component_78
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.ipgasspot',component_79
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.igasspot',component_80
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.imrespot',component_81
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dmhrv',component_82
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dmloss',component_83
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.icut',component_84
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.tcut',component_85
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dmhrvpot',component_86
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.dmlosspot',component_87
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.icutpot',component_88
write(*,'(a,*(1x,i0))') 'DIAG_FIELD plant_interface.tcutpot',component_89
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.hlim3h',component_90
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.hlim3l',component_91
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD plant_interface.hlim4',component_92
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD atmosphere_interface.tav',component_93
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD atmosphere_interface.rad',component_94
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD atmosphere_interface.grai',component_95
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.h',component_96(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.theta',component_97(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.k',component_98(1:numnod+1)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.kmean',component_99(1:numnod+1)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.dimoca',component_100(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.fhyst',component_101(1:numnod)
write(*,'(a,*(1x,i0))') 'DIAG_FIELD variables.indeks',component_102(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.dt',component_103
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.dtold',component_104
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.pond',component_105
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.pondm1',component_106
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.gwl',component_107
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD variables.volact',component_108
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_MvG.cofgen',component_109(:,1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.tsoil',component_110(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.heacon',component_111(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.heacap',component_112(1:numnod)
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.tetop',component_113
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_SoilTemperature.tebot',component_114
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_top.theatm',component_115
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_top.katm',component_116
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_top.q0',component_117
write(*,'(a,*(1x,es25.17e3))') 'DIAG_FIELD MOD_top.hsurf',component_118
write(*,'(a,*(1x,l1))') 'DIAG_FIELD MOD_top.FlRunoff',component_119
write(*,'(a,*(1x,l1))') 'DIAG_FIELD MOD_top.ftoph',component_120
write(*,'(a)')'DIAG_COMPONENT_END'
end subroutine
subroutine dump_drainage(phase)
use MOD_drain,only:drain_field_0=>swdivd
use MOD_drain,only:drain_field_1=>swdivdinf
use MOD_drain,only:drain_field_2=>swdislay
use MOD_drain,only:drain_field_3=>swdtyp
use MOD_drain,only:drain_field_4=>swliminf
use MOD_drain,only:drain_field_5=>swnrsrf
use MOD_drain,only:drain_field_6=>swtopdislay
use MOD_drain,only:drain_field_7=>swtopnrsrf
use MOD_drain,only:drain_field_8=>cofani
use MOD_drain,only:drain_field_9=>cofintfl
use MOD_drain,only:drain_field_10=>diffl
use MOD_drain,only:drain_field_11=>drainl
use MOD_drain,only:drain_field_12=>expintfl
use MOD_drain,only:drain_field_13=>facdpthinf
use MOD_drain,only:drain_field_14=>ftopdislay
use MOD_drain,only:drain_field_15=>ksatcp
use MOD_drain,only:drain_field_16=>Lspacing
use MOD_drain,only:drain_field_17=>qdra
use MOD_drain,only:drain_field_18=>qdrain
use MOD_drain,only:drain_field_19=>qdrtot
use MOD_drain,only:drain_field_20=>zbotdr
use MOD_drain,only:drain_field_21=>ztopdislay
use MOD_drain,only:drain_field_22=>dramet
use MOD_drain,only:drain_field_23=>nrlevs
use MOD_drain,only:drain_field_24=>qdrtab
use MOD_drain,only:drain_field_25=>ipos
use MOD_drain,only:drain_field_26=>basegw
use MOD_drain,only:drain_field_27=>entres
use MOD_drain,only:drain_field_28=>geofac
use MOD_drain,only:drain_field_29=>khbot
use MOD_drain,only:drain_field_30=>khtop
use MOD_drain,only:drain_field_31=>kvbot
use MOD_drain,only:drain_field_32=>kvtop
use MOD_drain,only:drain_field_33=>shape
use MOD_drain,only:drain_field_34=>wetper
use MOD_drain,only:drain_field_35=>zintf
use MOD_drain,only:drain_field_36=>nowltab
use MOD_drain,only:drain_field_37=>swallo
use MOD_drain,only:drain_field_38=>drares
use MOD_drain,only:drain_field_39=>infres
use MOD_drain,only:drain_field_40=>owltab
use MOD_drain,only:drain_field_41=>swsrf
use MOD_drain,only:drain_field_42=>swqhr
use MOD_drain,only:drain_field_43=>swsec
use MOD_drain,only:drain_field_44=>nrpri
use MOD_drain,only:drain_field_45=>nrsec
use MOD_drain,only:drain_field_46=>nmper
use MOD_drain,only:drain_field_47=>swman
use MOD_drain,only:drain_field_48=>nphase
use MOD_drain,only:drain_field_49=>nodhd
use MOD_drain,only:drain_field_50=>numadj
use MOD_drain,only:drain_field_51=>intwl
use MOD_drain,only:drain_field_52=>widthr
use MOD_drain,only:drain_field_53=>taludr
use MOD_drain,only:drain_field_54=>rdrain
use MOD_drain,only:drain_field_55=>rsurfdeep
use MOD_drain,only:drain_field_56=>rsurfshallow
use MOD_drain,only:drain_field_57=>rinfi
use MOD_drain,only:drain_field_58=>rentry
use MOD_drain,only:drain_field_59=>rexit
use MOD_drain,only:drain_field_60=>gwlinf
use MOD_drain,only:drain_field_61=>wlptab
use MOD_drain,only:drain_field_62=>impend
use MOD_drain,only:drain_field_63=>wldip
use MOD_drain,only:drain_field_64=>wscap
use MOD_drain,only:drain_field_65=>hbweir
use MOD_drain,only:drain_field_66=>osswlm
use MOD_drain,only:drain_field_67=>wlstar
use MOD_drain,only:drain_field_68=>wlp
use MOD_drain,only:drain_field_69=>alphaw
use MOD_drain,only:drain_field_70=>betaw
use MOD_drain,only:drain_field_71=>dropr
use MOD_drain,only:drain_field_72=>gwlcrit
use MOD_drain,only:drain_field_73=>hcrit
use MOD_drain,only:drain_field_74=>vcrit
use MOD_drain,only:drain_field_75=>hqhtab
use MOD_drain,only:drain_field_76=>qqhtab
use MOD_drain,only:drain_field_77=>wlsman
use MOD_drain,only:drain_field_78=>wlstab
use MOD_drain,only:drain_field_79=>sttab
use MOD_drain,only:drain_field_80=>swst
use MOD_drain,only:drain_field_81=>wlsbak
use MOD_drain,only:drain_field_82=>wls
use MOD_drain,only:drain_field_83=>qdrd
implicit none
character(*),intent(in)::phase
integer::unit
if(abs(t1900-37786d0)>1d-8)return
if(phase/='BEFORE_METEO3'.and.phase/='BEFORE_DRAIN2'.and.phase/='AFTER_DRAIN2')return
open(newunit=unit,file='diagnostic-drain-'//trim(phase)//'.bin',access='stream',form='unformatted',status='replace')
write(unit)drain_field_0
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swdivd',2,1,storage_size(drain_field_0)
write(unit)drain_field_1
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swdivdinf',2,1,storage_size(drain_field_1)
write(unit)drain_field_2
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swdislay',2,1,storage_size(drain_field_2)
write(unit)drain_field_3
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swdtyp',2,size(drain_field_3),storage_size(drain_field_3)
write(unit)drain_field_4
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swliminf',2,1,storage_size(drain_field_4)
write(unit)drain_field_5
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swnrsrf',2,1,storage_size(drain_field_5)
write(unit)drain_field_6
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swtopdislay',2,size(drain_field_6),storage_size(drain_field_6)
write(unit)drain_field_7
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swtopnrsrf',2,1,storage_size(drain_field_7)
write(unit)drain_field_8
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'cofani',1,size(drain_field_8),storage_size(drain_field_8)
write(unit)drain_field_9
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'cofintfl',1,1,storage_size(drain_field_9)
write(unit)drain_field_10
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'diffl',1,size(drain_field_10),storage_size(drain_field_10)
write(unit)drain_field_11
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'drainl',1,size(drain_field_11),storage_size(drain_field_11)
write(unit)drain_field_12
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'expintfl',1,1,storage_size(drain_field_12)
write(unit)drain_field_13
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'facdpthinf',1,1,storage_size(drain_field_13)
write(unit)drain_field_14
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ftopdislay',1,size(drain_field_14),storage_size(drain_field_14)
write(unit)drain_field_15
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ksatcp',1,size(drain_field_15),storage_size(drain_field_15)
write(unit)drain_field_16
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'Lspacing',1,size(drain_field_16),storage_size(drain_field_16)
write(unit)drain_field_17
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qdra',1,size(drain_field_17),storage_size(drain_field_17)
write(unit)drain_field_18
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qdrain',1,size(drain_field_18),storage_size(drain_field_18)
write(unit)drain_field_19
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qdrtot',1,1,storage_size(drain_field_19)
write(unit)drain_field_20
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'zbotdr',1,size(drain_field_20),storage_size(drain_field_20)
write(unit)drain_field_21
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ztopdislay',1,size(drain_field_21),storage_size(drain_field_21)
write(unit)drain_field_22
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'dramet',2,1,storage_size(drain_field_22)
write(unit)drain_field_23
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nrlevs',2,1,storage_size(drain_field_23)
write(unit)drain_field_24
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qdrtab',1,size(drain_field_24),storage_size(drain_field_24)
write(unit)drain_field_25
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'ipos',2,1,storage_size(drain_field_25)
write(unit)drain_field_26
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'basegw',1,1,storage_size(drain_field_26)
write(unit)drain_field_27
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'entres',1,1,storage_size(drain_field_27)
write(unit)drain_field_28
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'geofac',1,1,storage_size(drain_field_28)
write(unit)drain_field_29
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'khbot',1,1,storage_size(drain_field_29)
write(unit)drain_field_30
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'khtop',1,1,storage_size(drain_field_30)
write(unit)drain_field_31
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'kvbot',1,1,storage_size(drain_field_31)
write(unit)drain_field_32
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'kvtop',1,1,storage_size(drain_field_32)
write(unit)drain_field_33
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'shape',1,1,storage_size(drain_field_33)
write(unit)drain_field_34
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wetper',1,1,storage_size(drain_field_34)
write(unit)drain_field_35
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'zintf',1,1,storage_size(drain_field_35)
write(unit)drain_field_36
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nowltab',2,size(drain_field_36),storage_size(drain_field_36)
write(unit)drain_field_37
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swallo',2,size(drain_field_37),storage_size(drain_field_37)
write(unit)drain_field_38
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'drares',1,size(drain_field_38),storage_size(drain_field_38)
write(unit)drain_field_39
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'infres',1,size(drain_field_39),storage_size(drain_field_39)
write(unit)drain_field_40
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'owltab',1,size(drain_field_40),storage_size(drain_field_40)
write(unit)drain_field_41
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swsrf',2,1,storage_size(drain_field_41)
write(unit)drain_field_42
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swqhr',2,1,storage_size(drain_field_42)
write(unit)drain_field_43
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swsec',2,1,storage_size(drain_field_43)
write(unit)drain_field_44
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nrpri',2,1,storage_size(drain_field_44)
write(unit)drain_field_45
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nrsec',2,1,storage_size(drain_field_45)
write(unit)drain_field_46
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nmper',2,1,storage_size(drain_field_46)
write(unit)drain_field_47
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swman',2,size(drain_field_47),storage_size(drain_field_47)
write(unit)drain_field_48
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nphase',2,size(drain_field_48),storage_size(drain_field_48)
write(unit)drain_field_49
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'nodhd',2,size(drain_field_49),storage_size(drain_field_49)
write(unit)drain_field_50
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'numadj',2,1,storage_size(drain_field_50)
write(unit)drain_field_51
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'intwl',2,size(drain_field_51),storage_size(drain_field_51)
write(unit)drain_field_52
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'widthr',1,size(drain_field_52),storage_size(drain_field_52)
write(unit)drain_field_53
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'taludr',1,size(drain_field_53),storage_size(drain_field_53)
write(unit)drain_field_54
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rdrain',1,size(drain_field_54),storage_size(drain_field_54)
write(unit)drain_field_55
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rsurfdeep',1,1,storage_size(drain_field_55)
write(unit)drain_field_56
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rsurfshallow',1,1,storage_size(drain_field_56)
write(unit)drain_field_57
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rinfi',1,size(drain_field_57),storage_size(drain_field_57)
write(unit)drain_field_58
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rentry',1,size(drain_field_58),storage_size(drain_field_58)
write(unit)drain_field_59
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'rexit',1,size(drain_field_59),storage_size(drain_field_59)
write(unit)drain_field_60
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'gwlinf',1,size(drain_field_60),storage_size(drain_field_60)
write(unit)drain_field_61
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wlptab',1,size(drain_field_61),storage_size(drain_field_61)
write(unit)drain_field_62
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'impend',1,size(drain_field_62),storage_size(drain_field_62)
write(unit)drain_field_63
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wldip',1,size(drain_field_63),storage_size(drain_field_63)
write(unit)drain_field_64
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wscap',1,size(drain_field_64),storage_size(drain_field_64)
write(unit)drain_field_65
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'hbweir',1,size(drain_field_65),storage_size(drain_field_65)
write(unit)drain_field_66
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'osswlm',1,1,storage_size(drain_field_66)
write(unit)drain_field_67
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wlstar',1,1,storage_size(drain_field_67)
write(unit)drain_field_68
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wlp',1,1,storage_size(drain_field_68)
write(unit)drain_field_69
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'alphaw',1,size(drain_field_69),storage_size(drain_field_69)
write(unit)drain_field_70
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'betaw',1,size(drain_field_70),storage_size(drain_field_70)
write(unit)drain_field_71
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'dropr',1,size(drain_field_71),storage_size(drain_field_71)
write(unit)drain_field_72
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'gwlcrit',1,size(drain_field_72),storage_size(drain_field_72)
write(unit)drain_field_73
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'hcrit',1,size(drain_field_73),storage_size(drain_field_73)
write(unit)drain_field_74
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'vcrit',1,size(drain_field_74),storage_size(drain_field_74)
write(unit)drain_field_75
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'hqhtab',1,size(drain_field_75),storage_size(drain_field_75)
write(unit)drain_field_76
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qqhtab',1,size(drain_field_76),storage_size(drain_field_76)
write(unit)drain_field_77
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wlsman',1,size(drain_field_77),storage_size(drain_field_77)
write(unit)drain_field_78
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wlstab',1,size(drain_field_78),storage_size(drain_field_78)
write(unit)drain_field_79
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'sttab',1,size(drain_field_79),storage_size(drain_field_79)
write(unit)drain_field_80
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'swst',1,1,storage_size(drain_field_80)
write(unit)drain_field_81
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wlsbak',1,size(drain_field_81),storage_size(drain_field_81)
write(unit)drain_field_82
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'wls',1,1,storage_size(drain_field_82)
write(unit)drain_field_83
write(*,'(a,1x,a,1x,a,3(1x,i0))')'DIAG_DRAIN_LAYOUT',phase,'qdrd',1,1,storage_size(drain_field_83)
close(unit)
end subroutine
end module
