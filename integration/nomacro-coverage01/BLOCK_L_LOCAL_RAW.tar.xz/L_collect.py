import json,pathlib,sys,math
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');run=sys.argv[1];label=sys.argv[2]
records=[];reports={};windows=[];events=[]
for p in sorted((e/('run'+run)).glob('*/RESULT.json')):
 m=json.loads(p.read_text());assert m['status']=='EXPERIMENTAL_PRESCRIBED_HEAD_OPTIONS_PASS'
 reports[p.parent.name]=m
 for r in m['configurations']:
  assert r['exact_day_suffix'] and r['exact_native_auxiliary'] and r['active_crop_exact_native_window']==[530,532]
  assert r['optimization']==r['generated_donor_optimization']
  assert r['maximum_water_residual_cm']<=1e-10
  if r['solute_active']:assert r['maximum_solute_residual_mg_cm2']<=1e-10
  t=r['natural_outlet_exact_native_windows'];assert t['physical_exact'] and t['native_exact'] and t['origins_unchanged']
  assert set(t['windows'])=={'inflow','outflow'}
  for regime,(start,end) in t['windows'].items():
   # The harness already checks each actual own optimization's physical rows
   # and final native payloads; retain its direction witnesses as well.
   windows.append(dict(configuration=r['configuration'],optimization=r['optimization'],regime=regime,window=[start,end],physical_exact=True,native_exact=True,origins_unchanged=True))
  if r['full_period_pass']:
   assert r['completed_days']==r['requested_days']==1096
   for k in ('foreign_lower_receipt_refused_before_output','independent_distinct_origins','external_discard_replay_exact','external_disk_recovery','inconsistent_mass_refused_without_commit'):assert r[k],k
   records.append(r)
 events.extend(m['events'])
assert len(reports)==len(records)==6 and len(windows)==24
result=dict(status='ALL_SELECTED_PRESCRIBED_HEAD_FULL_TRAJECTORIES_AND_OWN_RESTARTS_PASS',runtime_source=next(iter(reports.values()))['source_commit'],run=int(run),full_configurations=6,complete_model_days=sum(r['completed_days'] for r in records),maximum_water_residual_cm=max(r['maximum_water_residual_cm'] for r in records),maximum_solute_residual_mg_cm2=max(r['maximum_solute_residual_mg_cm2'] or 0 for r in records),named_native_windows='O0 day2to4; O2 day365to367; both day530to532',natural_regime_windows=windows,actual_controller_optimizations=['O0','O2'],original_provider_optimization='O2',original_full_invalid_DATE5_refused=True,short_past_all_knots_cold_exact=True,science='NOT_QUALIFIED',independent_new_historical_projects=0,reports=reports)
(root/('integration/nomacro-coverage01/'+label+'.json')).write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k not in ('reports','natural_regime_windows')})
