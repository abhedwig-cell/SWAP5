program tangent_probe
 use hybrid_step_budget, only: linear_pond_top_jacobian
 implicit none
 real(8) :: c,step,pond,threshold,resistance
 integer :: status
 do
  read(*,*,iostat=status) c,step,pond,threshold,resistance
  if(status/=0) exit
  write(*,'(es25.17e3)') linear_pond_top_jacobian(c,step,pond,threshold,resistance)
 end do
end program
