import pathlib,json,sys,subprocess,zipfile,hashlib
root=pathlib.Path.cwd();out=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');sys.path.insert(0,str(root/'app/hybrid_water'))
import daily_host as h
sha=lambda b:hashlib.sha256(b).hexdigest()
proof={};commands=[]
with zipfile.ZipFile(root/'integration/f-ci/hupsel51-water-balance/COMPOSED_WINDOWS_RAW.zip') as z:
 for name,p in [('grass',h.GRASSGROWTH),('hupsel',h.HUPSEL),('salt',h.SALTFARM)]:
  target=out/('L_composed_named_'+name)
  cmd=[sys.executable,'-B','tools/solute/run_water.py','--model',p.model,'--reference-work',str(out/'J_windows_provider'),'--build-only','--kernel-opt','O2','--no-macro-release','--output',str(target)]
  if not (target/'BUILD.json').exists():
   r=subprocess.run(cmd,capture_output=True,text=True);(out/('L_build_'+name+'.stdout')).write_text(r.stdout);(out/('L_build_'+name+'.stderr')).write_text(r.stderr);assert r.returncode==0,r.stderr
  a=json.loads((target/'BUILD.json').read_text());b=json.loads(z.read('named/'+name+'/build/BUILD.json'))
  keys=['compiler_sha256','donor_flags','kernel_flags','donor_generated','kernel_sources','adapter','driver','floating_point_profile','soil_table_policy','solute_step_policy','time_step_policy']
  for k in keys:assert a['identity'].get(k)==b['identity'].get(k),(name,k)
  assert a['inputs']==b['inputs']
  assert a['identity']['restart_publisher']['source_sha256']==b['identity']['restart_publisher']['source_sha256']
  if 'budget_source' in a['identity']:
   old=subprocess.check_output(['git','show','f1d1c13a295c5b54ec11e03d864de7030ca09008:app/hybrid_water/hybrid_step_budget.f90'])
   actual=(root/'app/hybrid_water/hybrid_step_budget.f90').read_bytes()
   assert actual.replace(b'\r\n',b'\n')==old.replace(b'\r\n',b'\n')
   assert a['identity']['budget_source']==sha(actual) and b['identity']['budget_source']==sha(old)
  proof[name]=dict(status='ACTUAL_NAMED_GENERATED_SOURCES_AND_INPUTS_EXACT',compared_identity_keys=keys,identity={k:a['identity'].get(k) for k in keys},inputs=a['inputs'],current_BUILD_sha256=sha((target/'BUILD.json').read_bytes()),prior_BUILD_member='named/'+name+'/build/BUILD.json',prior_BUILD_sha256=sha(z.read('named/'+name+'/build/BUILD.json')),binary_identity='NOT_BYTE_EXACT: separately compiled original provider objects/libraries; not used as a binary preservation claim',publisher_source_exact=True,budget_source_git_blob_exact=True,budget_checkout='Only LF/CRLF checkout conversion differs; each actual source digest is checked against its own BUILD identity')
 for opt,prior in [('O0','full1096-O0'),('O2','full1096')]:
  d=out/('L_composed_closed_'+opt)/'undrained';a=json.loads((d/'build/BUILD.json').read_text());b=json.loads(z.read(prior+'/undrained/build/BUILD.json'))
  for k in keys:assert a['identity'].get(k)==b['identity'].get(k),(opt,k)
  old=subprocess.check_output(['git','show','f1d1c13a295c5b54ec11e03d864de7030ca09008:app/hybrid_water/hybrid_step_budget.f90']);actual=(root/'app/hybrid_water/hybrid_step_budget.f90').read_bytes()
  assert a['identity']['budget_source']==sha(actual) and b['identity']['budget_source']==sha(old)
  assert a['inputs']==b['inputs']
  current=[json.loads(s) for s in (d/'full/daily.jsonl').read_text().splitlines()];old=[json.loads(s) for s in z.read(prior+'/undrained/full/daily.jsonl').decode().splitlines()]
  physical=lambda rows:[{k:v for k,v in r.items() if k not in ('column','revision')} for r in rows]
  assert physical(current)==physical(old)
  proof[opt]=dict(status='CLOSED6_CURRENT_FULL_NATIVE_AND_PRIOR_PHYSICAL_EXACT',full=json.loads((d.parent/'RESULT.json').read_text())['undrained'],compared_identity_keys=keys,all_generated_execution_sources_exact=True,all_1096_physical_daily_rows_exact=True)
report=dict(status='L_CURRENT_CLOSED6_AND_NAMED_PRESERVATION_PASS',runtime_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),baseline='f1d1c13a295c5b54ec11e03d864de7030ca09008',profiles=proof,scope='Fresh closed6 full O0/O2 and own50/530; unchanged named generated sources/inputs inherited from immutable actual-composition proof. Host build-only branches change only selected5/8; stepping functions and kernel sources unchanged. No old capsule rebind.',science='NOT_QUALIFIED')
(root/'integration/nomacro-coverage01/BLOCK_L_CURRENT_PRESERVATION.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'])
