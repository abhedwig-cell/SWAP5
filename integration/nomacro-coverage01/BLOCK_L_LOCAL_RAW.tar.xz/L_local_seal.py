import pathlib,json,tarfile,hashlib
e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');out=pathlib.Path.cwd()/'integration/nomacro-coverage01';files={};raw=out/'BLOCK_L_LOCAL_RAW.tar.xz'
names=['L_receipt_codec','L_composed_receipt','L_composed_soil_air','L_composed_pond','L_composed_closed_O0','L_composed_closed_O2','L_composed_named_grass','L_composed_named_hupsel','L_composed_named_salt','L_inputs','L_water_head_O0_build','L_water_head_O0_fixed_build','L_water_head_O0_warm','L_water_head_O0_cold','L_short_table_input','L_short_table_build','L_short_table_warm','L_short_table_cold','L_invalid_table_input','L_invalid_table_build','L_invalid_table_run','L_preserve_K_build','L_reader_preserve_K_build','L_composed_default_windows']
extra=['L_SHORT_EVENTS.json','L_TABLE_EVENTS.json','L_INVALID_TABLE_RESULT.json','L_composition.py','L_collect.py','L_local_seal.py']
with tarfile.open(raw,'w:xz',preset=1) as t:
 for name in names+extra:
  base=e/name
  assert base.exists(),str(base)
  for p in ([base] if base.is_file() else base.rglob('*')):
   if not p.is_file() or p.suffix.lower() not in ('.json','.jsonl','.csv','.zip','.bin','.end','.err','.log','.stdout','.stderr','.f90','.swp','.crp','.dra','.bbc','.ini','.met','.py'):continue
   if 'provider' in p.relative_to(e).parts:continue
   rel=p.relative_to(e).as_posix();t.add(p,arcname=rel,recursive=False);files[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
result=dict(archive=raw.name,bytes=raw.stat().st_size,sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),files=files,scope='Actual local L source/component/short/native/invalid-domain and fresh composed closed6 full O0/O2; generated sources and checkpoint/log evidence, compiled binaries excluded.',retained_development_comparison_failures=['Initial donor_objects equality assertion failed for independently compiled providers; not a physical or source preservation PASS','budget_source equality assertion exposed LF versus CRLF Windows checkout digests; exact Git source and both actual digest identities verified instead'])
(out/'BLOCK_L_LOCAL_ARCHIVE.json').write_text(json.dumps(result,indent=2)+'\n');print(raw.name,result['bytes'],result['sha256'])
