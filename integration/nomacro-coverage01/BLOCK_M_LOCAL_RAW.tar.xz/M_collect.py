import pathlib,json,math,subprocess
e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');root=pathlib.Path.cwd();out=root/'integration/nomacro-coverage01';reports={};full=[];windows=[];sources={};nominal=[]
for run in (43863064413,43867490337):
 for p in sorted((e/('run'+str(run))).glob('*/RESULT.json')):
  m=json.loads(p.read_text());assert m['status']=='EXPERIMENTAL_SURFACE_INPUT_OPTIONS_PASS'
  records=m['configurations'];key=records[0]['configuration']
  if run==43863064413 and not key.endswith('pond-table'):continue
  assert key not in reports;reports[key]=m;sources[key]=m.get('executed_runtime_source',m['source_commit'])
  assert len(records)==2 and {r['optimization'] for r in records}=={'O0','O2'}
  for r in records:
   assert r['exact_day_suffix'] and r['exact_native_auxiliary'] and r['active_crop_exact_native_window']==[530,532]
   assert r['maximum_water_residual_cm']<=1e-10 and (r['maximum_solute_residual_mg_cm2'] or 0)<=1e-10
   t=r['surface_event_exact_native_windows'];assert t['windows']==[[199,201],[529,531]] and t['physical_exact'] and t['native_exact'] and t['origins_unchanged']
   for w in t['windows']:windows.append(dict(configuration=key,optimization=r['optimization'],window=w,physical_exact=True,native_exact=True,origins_unchanged=True))
   assert all(math.isfinite(v) and -50<=v<=80 for v in r['active_native_soil_temperature_C'])
   if r['optimization']=='O2':
    assert r['full_period_pass'] and r['completed_days']==r['requested_days']==1096
    assert all(r[k] for k in ('foreign_surface_schedule_refused_before_output','independent_distinct_origins','external_discard_replay_exact','external_disk_recovery','inconsistent_mass_refused_without_commit'))
    full.append(r)
    if 'original_runon_event_witness' in r:
     witness=r['original_runon_event_witness'];assert witness['original_clock_contract_pass'] and witness['original_dtCrit_days']==1e-8
     nominal.extend(dict(configuration=key,**v) for v in witness['records'])
assert len(reports)==len(full)==6 and len(windows)==24
q=dict(status='ALL_SIX_ORIGINAL_SURFACE_INPUT_CONFIGURATIONS_QUALIFIED',qualification_source='f6ce291e4c28e88ee3c1b47a206da12433a92c38',runtime_source='166d4b7b5fe9ba0f6ea3aa8af6f5d55d66a904ad',per_configuration_executed_sources=sources,
  full_configurations=6,complete_model_days=sum(r['completed_days'] for r in full),full_period_optimization='O2',original_provider_optimization='O2',actual_touched_native_optimizations=['O0','O2'],O0_scope='Five-day ordinary and full532 active prefix plus531 event prefix with exact own continuation; not six full O0 periods',
  first_matrix_run=43863064413,affected_physical_full_run=43864567262,missing_verification_completion_run=43867490337,failed_completion_runs=[43866440207,43866903871],unchanged_pond_inheritance='Actual fresh O0/O2 generated source/input/policy preservation from65 to166; no old capsule rebind',
  maximum_water_residual_cm=max(r['maximum_water_residual_cm'] for r in full),maximum_solute_residual_mg_cm2=max(r['maximum_solute_residual_mg_cm2'] or 0 for r in full),mass_guard_cm=1e-10,mass_guard_changed=False,
  native_windows='Ordinary O0 2to4 / O2 365to367; both530to532; both199to201 and529to531',surface_event_windows=windows,nominal_runon_diagnostics=nominal,
  nominal_runon_1e10_accuracy='FAILED_NOT_QUALIFIED; retained day200 error6.2864e-10cm, original dtCrit1e-8day unchanged',whole_scientific_equivalence='NOT_QUALIFIED',independent_new_historical_projects=0,reports=reports)
(out/'BLOCK_M_QUALIFICATION.json').write_text(json.dumps(q,indent=2)+'\n')
default=next((e/'run43864571266').glob('*/RESULT.json'));d=json.loads(default.read_text());assert d['status']=='EXPERIMENTAL_GENERIC_SURFACE_SMOKE_PASS' and len(d['profiles'])==8
(out/'BLOCK_M_DEFAULT_PRESERVATION_RESULT.json').write_text(json.dumps(d,indent=2)+'\n')
print({k:v for k,v in q.items() if k not in ('reports','surface_event_windows','nominal_runon_diagnostics')})
