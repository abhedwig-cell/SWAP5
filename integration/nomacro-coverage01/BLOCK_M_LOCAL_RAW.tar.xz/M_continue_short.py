import pathlib,subprocess,json,sys,time,zipfile
root=pathlib.Path.cwd();out=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');reports=[];events=[]
for key in ('water-runon-file','water-surface-combined','chemical-surface-combined'):
 source=out/'M_inputs_fixed'/key;bundle=out/('M_fixed_'+key+'_O0_build');warm=out/('M_fixed_'+key+'_warm');cold=out/('M_fixed_'+key+'_cold');end=out/('M_fixed_'+key+'_endpoint')
 common=['--model','HYBRID_NOMACRO_WATER','--experimental-project',str(source),'--reference-work',str(out/'J_windows_provider')]
 commands=[common+['--build-only','--kernel-opt','O0','--donor-opt','O0','--output',str(bundle)],common+['--build-bundle',str(bundle),'--days','5','--checkpoint-at','2','--output',str(warm)],common+['--build-bundle',str(bundle),'--restart',str(warm/'accepted-column-1-day-2.zip'),'--restart-day','2','--days','4','--checkpoint-at','4','--output',str(cold)],common+['--build-bundle',str(bundle),'--days','4','--checkpoint-at','4','--output',str(end)]]
 for index,args in enumerate(commands):
  target=pathlib.Path(args[args.index('--output')+1]);
  if (target/'BUILD.json').exists() or (target/'daily.jsonl').exists():continue
  cmd=[sys.executable,'-B','tools/solute/run_water.py',*args];start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);events.append(dict(configuration=key,command=cmd,seconds=time.perf_counter()-start,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(out/'M_FIXED_SHORT_EVENTS.json').write_text(json.dumps(events,indent=2)+'\n');assert r.returncode==0,(key,index,r.stdout,r.stderr)
 rows=lambda p:[json.loads(s) for s in (p/'daily.jsonl').read_text().splitlines()]
 physical=lambda rr:[{k:v for k,v in r.items() if k not in ('column','revision')} for r in rr]
 assert physical(rows(cold))==physical(rows(warm)[2:4])
 with zipfile.ZipFile(cold/'accepted-column-1-day-4.zip') as a,zipfile.ZipFile(end/'accepted-column-1-day-4.zip') as b:
  assert all(a.read(n)==b.read(n) for n in ('result.end','macro.bin'))
 r=rows(warm)
 if 'runon' in key or 'combined' in key:assert abs(r[2]['external_flux_cm'][4]-.8)<1e-10,r[2]
 reports.append(dict(configuration=key,status='ACTUAL_O0_FIVE_DAY_OWN_NATIVE_2_TO_4_PASS',max_water_cm=max(abs(x['independent_residual_cm']) for x in r),max_solute_mg_cm2=max(abs(x.get('solute_independent_residual_mg_cm2',0)) for x in r),runon_day3_cm=r[2]['external_flux_cm'][4]))
 (out/'M_FIXED_SHORT_RESULT.json').write_text(json.dumps(dict(status='SELECTED_ACTUAL_O0_SHORT_AND_NATIVE_PASS',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),profiles=reports),indent=2)+'\n');print(key,'PASS',flush=True)
