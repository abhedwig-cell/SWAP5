import pathlib,subprocess,json,tarfile,hashlib,ast
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');out=root/'integration/nomacro-coverage01';profiles={}
sha=lambda b:hashlib.sha256(b).hexdigest()
configs=[('closed6',e/'L_composed_closed_O0/inputs','BLOCK_L_LOCAL_RAW.tar.xz','L_composed_closed_O0/undrained/build/'),('head5',e/'L_inputs/water-head-fixed','BLOCK_L_FULL_TRAJECTORIES_RAW.tar.xz','water-head-fixed-O0-build/')]
for name,inputs,archive,ending in configs:
 if name=='head5':
  inputs=e/'M_preserved_L_head5_inputs'
  if not inputs.exists():
   inputs.mkdir()
   with tarfile.open(out/archive,'r:xz') as t:
    members=[m for m in t.getmembers() if '/input-water-head-fixed/' in m.name];assert members
    for m in members:
     assert m.isfile();relative=m.name.split('/input-water-head-fixed/',1)[1];target=(inputs/relative).resolve();assert target.is_relative_to(inputs.resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(m).read())
  with tarfile.open(out/archive,'r:xz') as t:
   member=next(m for m in t.getmembers() if m.name.endswith(ending+'BUILD.json'));inventory=json.loads(t.extractfile(member).read())['inputs']
  for file,digest in inventory.items():
   if not (inputs/file).exists():
    raw=subprocess.check_output(['git','show','dadbda8128c16d8ba8dd858e5ac3a0b64a9a2b75:reference/swap-4.3.1/projects/1.hupselbrook/'+file]);assert sha(raw)==digest,file;(inputs/file).write_bytes(raw)
 bundle=e/('M_preserve_'+name+'_'+sha((root/'app/hybrid_water/daily_host.py').read_bytes())[:8]+('_fullinputs' if name=='head5' else '')+'_build')
 cmd=['python','-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(inputs),'--reference-work',str(e/'J_windows_provider'),'--build-only','--kernel-opt','O0','--donor-opt','O0','--output',str(bundle)]
 if not (bundle/'BUILD.json').exists():
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);(e/('M_preserve_'+name+'.stdout')).write_text(r.stdout);(e/('M_preserve_'+name+'.stderr')).write_text(r.stderr);assert r.returncode==0,r.stderr
 current=json.loads((bundle/'BUILD.json').read_text())
 with tarfile.open(out/archive,'r:xz') as t:
  members=t.getmembers();candidates=[m.name for m in members if m.name.endswith(ending+'BUILD.json')];assert len(candidates)==1,candidates
  prior=json.loads(t.extractfile(candidates[0]).read());prefix=candidates[0][:-len('BUILD.json')];assert set(prior['identity']['donor_generated'])==set(current['identity']['donor_generated'])
  hashes={}
  for file,old_digest in prior['identity']['donor_generated'].items():
   raw=t.extractfile(prefix+file).read();now=(bundle/file).read_bytes();assert sha(raw)==old_digest;assert sha(now)==current['identity']['donor_generated'][file]
   assert raw.replace(b'\r\n',b'\n')==now.replace(b'\r\n',b'\n'),(name,file)
   hashes[file]=dict(prior_actual_sha256=old_digest,current_actual_sha256=sha(now),normalized_LF_sha256=sha(raw.replace(b'\r\n',b'\n')))
  assert current['inputs']==prior['inputs']
  kernel_hashes={}
  for file,old_digest in prior['identity']['kernel_sources']:
   now=(root/file).read_bytes();original=subprocess.check_output(['git','show','dadbda8128c16d8ba8dd858e5ac3a0b64a9a2b75:'+file])
   assert now.replace(b'\r\n',b'\n')==original.replace(b'\r\n',b'\n'),file
   assert old_digest in (sha(original),sha(now)) and dict(current['identity']['kernel_sources'])[file]==sha(now),file
   kernel_hashes[file]=dict(prior_actual_sha256=old_digest,current_actual_sha256=sha(now),normalized_Git_blob_sha256=sha(original))
  for key in ('soil_table_policy','solute_step_policy','time_step_policy'):assert current['identity'].get(key)==prior['identity'].get(key),(name,key)
  assert 'surface_schedule' not in current['identity']
  profiles[name]=dict(status='ACTUAL_PRIOR_EXECUTION_SOURCES_AND_INPUTS_PRESERVED',generated=hashes,inputs=current['inputs'],kernel_sources=kernel_hashes,baseline_archive=archive,baseline_BUILD_member=candidates[0],current_BUILD_sha256=sha((bundle/'BUILD.json').read_bytes()),comparison='Actual source bytes differ only in recorded LF/CRLF checkout encoding; no binary identity or old capsule rebind')
old=ast.parse(subprocess.check_output(['git','show','30f7a21ff0b3437ea937476c72ca11421d2d03de:app/hybrid_water/daily_host.py'],text=True));new=ast.parse((root/'app/hybrid_water/daily_host.py').read_text())
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a=functions(old);b=functions(new);changed={k for k in set(a)|set(b) if a.get(k)!=b.get(k)};assert changed=={'build'},changed
result=dict(status='M_INACTIVE_L5_CLOSED6_SOURCE_PRESERVATION_PASS',runtime_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),baseline='30f7a21ff0b3437ea937476c72ca11421d2d03de',profiles=profiles,all_host_execution_functions_classes_AST_exact=True,only_changed_host_function='build',science='NOT_QUALIFIED')
(out/'BLOCK_M_PRIOR_SOURCE_PRESERVATION.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'])
