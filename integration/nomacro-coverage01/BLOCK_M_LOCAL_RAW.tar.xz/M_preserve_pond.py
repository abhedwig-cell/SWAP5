import pathlib,subprocess,json,hashlib
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');out=root/'integration/nomacro-coverage01';result={}
sha=lambda b:hashlib.sha256(b).hexdigest()
for key in ('water-pond-table','chemical-pond-table'):
 artifact=next((e/'run43863064413').glob('*-'+key+'-*'));source=artifact/('input-'+key)
 for opt in ('O0','O2'):
  prior=json.loads((artifact/(key+'-'+opt+'-build/BUILD.json')).read_text());bundle=e/('M_inherit_'+key+'_'+opt+'_build')
  if not (bundle/'BUILD.json').exists():
   cmd=['python','-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(source),'--reference-work',str(e/'J_windows_provider'),'--build-only','--kernel-opt',opt,'--donor-opt',opt,'--output',str(bundle)]
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);(e/('M_inherit_'+key+'_'+opt+'.stdout')).write_text(r.stdout);(e/('M_inherit_'+key+'_'+opt+'.stderr')).write_text(r.stderr);assert r.returncode==0,r.stderr
  current=json.loads((bundle/'BUILD.json').read_text());assert current['inputs']==prior['inputs'];assert current['identity']['surface_schedule']==prior['identity']['surface_schedule']
  fields={}
  assert current['identity']['donor_generated'].keys()==prior['identity']['donor_generated'].keys()
  for file,digest in prior['identity']['donor_generated'].items():
   old=(artifact/(key+'-'+opt+'-build')/file).read_bytes();now=(bundle/file).read_bytes();assert sha(old)==digest;assert sha(now)==current['identity']['donor_generated'][file];assert old.replace(b'\r\n',b'\n')==now.replace(b'\r\n',b'\n'),(key,opt,file)
   fields[file]=dict(prior_actual_sha256=digest,current_actual_sha256=sha(now),normalized_LF_sha256=sha(old.replace(b'\r\n',b'\n')))
  for field in ('floating_point_profile','soil_table_policy','solute_step_policy','time_step_policy'):assert current['identity'].get(field)==prior['identity'].get(field),(key,opt,field)
  assert {k:v for k,v in current['binding'].items() if k!='build'}=={k:v for k,v in prior['binding'].items() if k!='build'}
  assert current['binding']['build']!=prior['binding']['build'] # Deliberately new source/compiler-bound capsules.
  result[key+'-'+opt]=dict(status='POND65_FULL_AND_NATIVE_DEPENDENCY_PRESERVED',generated=fields,inputs=current['inputs'],current_BUILD_sha256=sha((bundle/'BUILD.json').read_bytes()),old_artifact=json.loads((artifact/'ARTIFACT.json').read_text()),source_policy=current['identity']['surface_schedule'],scope='New runon1 eligibility is false for this runon0 case; actual emitted code/inputs/policy preserved. EOL normalization recorded, no binary/capsule rebinding.')
assert not subprocess.check_output(['git','diff','166d4b7b5fe9ba0f6ea3aa8af6f5d55d66a904ad','HEAD','--','app','src','reference','tools'])
report=dict(status='BOTH_POND_TABLE_FULL_AND_NATIVE_COHORTS_INHERITED_ON_ACTUAL_SOURCE_PRESERVATION',runtime_source='166d4b7b5fe9ba0f6ea3aa8af6f5d55d66a904ad',prior_runtime_source='65bfe12195af15c1ed39167edbd996e643941c55',prior_full_run=43863064413,profiles=result,science='NOT_QUALIFIED')
(out/'BLOCK_M_POND_SOURCE_PRESERVATION.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'])
