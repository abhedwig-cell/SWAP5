from pathlib import Path
root=Path('C:/Users/Veldh012/swap5-coverage-evidence/run43582993979')
p=next(root.rglob('solute-salt-O0-manual-control'))
for f in p.rglob('swap.err'):print(f.read_text(errors='replace')[-1600:])
