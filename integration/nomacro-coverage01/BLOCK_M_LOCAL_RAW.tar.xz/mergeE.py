from pathlib import Path
import json
out=Path('integration/nomacro-coverage01')
a=dict(pr=1674,merge='02ecf51877ec420e8e591e3a99584b78c3f7d59e',qualified_source='b7a9d8405c3ec3f79d199b9c5a8273cebd4d9bdc',qualified_head='7f8b72fc5b31098b348a9b0d6d237f9ccee6ec06',actual_tree='4d5aeb4ca357153fd37e2df9903f77d0ca895794',qualified_tree='4d5aeb4ca357153fd37e2df9903f77d0ca895794',postimage_delta=[],relevant_source_delta_from_executed_code=[],frozen_rc1='11529865e76fb2259542f1e770726cd87af27603',workflow_run=43423367602,status='CANONICALLY_ADMITTED_BOUNDED_EXPERIMENTAL_FUNCTIONAL_SCOPE',science='NOT_QUALIFIED; original scientific FAILs retained')
(out/'BLOCK_E_MERGE.json').write_text(json.dumps(a,indent=2)+'\n')
p=out/'BLOCK_E_STATUS.json';d=json.loads(p.read_text());d.update(status=a['status'],actual_merge=a['merge'],actual_tree=a['actual_tree']);p.write_text(json.dumps(d,indent=2)+'\n')
p=out/'RECOVERY.md';s=p.read_text();mark=s.index('\n---\n');s='''## Current recovery checkpoint

SWAP5-NOMACRO-COVERAGE01, own worktree C:/Users/Veldh012/swap5-nomacro-coverage01.
A/B/C/D/E admitted PR1669/1670/1671/1673/1674. Current canonical02ecf51877ec420e8e591e3a99584b78c3f7d59e.
E actual tree4d5aeb4ca357153fd37e2df9903f77d0ca895794 equals qualified7f8b72fc5;
relevant source/workflow diff from executedb7a9d8405 is empty. Frozen release
11529865e76fb2259542f1e770726cd87af27603 unchanged. BLOCK_E_MERGE owns receipt.

E run43423367602 SUCCESS:9 full9864 days,18 touched-unit/controller O0/O2
profiles with immutable original providerO2, exact native2/365/530, real growth
or root uptake, distinct thermal states, reference and all transaction checks.
Maxwater9.997787873191472e-11cm, solute2.0189361551216096e-13mg/cm2. Three original
invalid-input prefixes/refusals preserved; valid derived fixtures honor all
original constraints. No physics/codec/host/kernel/provider/CLI/time-policy
change. Old adapter bundles require rebuild, never rebind. All24 prior selected
descriptors exact; historical qualifications inherited only within dependency scope.

Across A..E:32 additional full configurations37627 model days, zero new independent
historical projects. Whole science/physical energy remains NOT_QUALIFIED; original
FAILs and full-history gaps retained. New water-only hysteresis/snow refused;
both failed cache hypotheses removed. Do not restart local cache/solver loops.

Current own branch codex/nomacro-coverage06 on actual E merge. No own PR/model
run pending. Next F: general experimental external surface-irrigation control,
using existing original event consumer and durable day transactions. Source audit
finds current builder/coupler limited to registered Hupsel/SaltFarm; original
consumer hard-requires solute1/schedule0. Audit durable publisher copying in the
incremental builder. See BLOCK_F_RECOVERY.md before editing. Preserve old protocol
and bounds; declare generic water/chemistry capabilities explicitly and reject
unsupported input atomically. Refresh active peer/canonical delta before code.
Other open register: hydraulic tables, detailed meteo/ET, drainage/surface water,
reservoir/age plus full original state history. No full-coverage claim.

Active serial Codex goal is configured; no scheduled timer and no overlapping
session. Peer last inspected PERF3075fbbb3 / macrocd2bf853e; private evidence not
imported. Later checkpoints replace this pointer. Inventory below is dated baseline.
''' +s[mark:];p.write_text(s)
(out/'BLOCK_F_RECOVERY.md').write_text('''# General original external surface-event integration

WORKSTREAM SWAP5-NOMACRO-COVERAGE01. Own branch codex/nomacro-coverage06,
worktree C:/Users/Veldh012/swap5-nomacro-coverage01. Base actual canonical
02ecf51877ec420e8e591e3a99584b78c3f7d59e, E admitted PR1674 with exact tree.
Status: source audit only; no F implementation, compile/model run or PR pending.
Frozen release11529865e unchanged. Active serial goal, no timer/overlap.

Concrete B/C gap: experimental projects expose original-forcing accept/discard
but not general typed external surface irrigation. Existing original event
consumer/transaction machinery is already present. app/hybrid_water/
irrigation_forcing.py build_bundle restricts project to registered HUPSEL/SALTFARM;
daily_coupling validate_bundle and CoupledDailyColumn mode guards do likewise.
Rendered consumer hard-requires schedule0, SWIRFIX1 and SWSOLU1 with S5IRR001.
Do not silently generalize that chemical contract or fabricate inactive stock.

Proposed cohesive work: reuse the existing original fixed-surface consumer and
explicit typed event metadata for eligible generic no-macro configurations,
including water-only with strictly zero chemical input. Preserve old registered
protocol/default semantics. Validate actual original input selectors/future
schedules and immutable identity before output/worker/publication. Original
scheduled irrigation must not be silently disabled or double-counted. Invalid
water-only chemical input must refuse atomically. Inspect source interfaces and
record the exact compatibility contract before code; invariants2/3/7/13/21/23/29.

Audit question to verify through an actual fresh build: incremental builder
copies .o/.mod/.smod/.f90/day_* but not visibly restart_publish.so/.dll while
metadata retains restart_publisher. Check current source/build behavior rather
than assume publisher availability; do not bypass validation. Preserve compiled
kernel, compiler/FP profile and generated original management state exactly.

Qualification should use real fresh provider/builds on own cloud runner, actual
O0/O2 touched modules/controller, positive/disabled/saline or freshwater events
through the new typed route, native and durable receipt restart/disk recovery,
prepare/discard/replay/accept, two different origins, stale/malformed/cross-model
refusals, independent water/chemical closure and no rejected publication. Select
representative complete forced trajectories and warm/cold actual native endpoint
comparisons where supported. A static capability check or original-forcing
transaction is not evidence that external values reach the physical module.
Retain existing registered external-surface qualification and scientific FAILs.

Peer pressure/time-policy stream last inspected3075fbbb3 had private combined-D
qualification artifacts; macrocd2bf853e independent native-state research. Both
worktrees untouched. Refresh authoritative canonical/peer state before code and
admission; do not import their private experiments. No platform, macro, MODFLOW
or general solver campaign.

Other backlog remains in current coverage register. Reservoir SWBR1 needs an
original-reference/index and aquifer state/ledger audit (original solute update
uses a loop index after the node loop); age2 requires proper conserved age state.
Do not casually admit either through the existing chemical1 scalar receipt.
New water-only hysteresis/snow remains refused after two failed cache hypotheses;
complete original state-block preservation is the required revised strategy.
''')
