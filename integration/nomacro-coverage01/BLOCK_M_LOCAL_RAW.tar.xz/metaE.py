from pathlib import Path
import json
p=Path('C:/Users/Veldh012/swap5-coverage-evidence/run43418605842/nomacro-crop-42f066bf05df510bc7d8dd3f5a3305235762fac5/no-interception-O2-build/BUILD.json');d=json.loads(p.read_text());print(list(d));print(str(d.get('project'))[:500])
