exec(open('C:/Users/Veldh012/swap5-coverage-evidence/auditE.py').read().split('for pat')[0])
for f in p.glob('*.f90'):
 s=f.read_text(encoding='cp1252').splitlines()
 if 'rwu' in f.name.lower():
  for i,l in enumerate(s):
   if 'swap_error' in l.lower() or 'stop ' in l.lower() or 'not implemented' in l.lower():print(f.name,i+1,'\n'.join(s[max(0,i-3):i+3]))
