exec(open('C:/Users/Veldh012/swap5-coverage-evidence/auditE.py').read().split('for pat')[0])
s=(p/'RWU_micro.f90').read_text(encoding='cp1252').splitlines();print('\n'.join(s[623:668]))
