import pathlib,json,math
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');out=root/'integration/nomacro-coverage01';reports={};full=[];windows=[]
for p in sorted((e/'run43880184441').glob('*/RESULT.json')):
 m=json.loads(p.read_text());assert m['status']=='EXPERIMENTAL_FIXED_IRRIGATION_FILE_OPTIONS_PASS' and m['source_commit']=='6afb72468c0060df60694d4b69ee8619fdc93062'
 key=m['configurations'][0]['configuration'];reports[key]=m
 for r in m['configurations']:
  assert r['exact_day_suffix'] and r['exact_native_auxiliary'] and r['active_crop_exact_native_window']==[530,532]
  assert r['maximum_water_residual_cm']<=1e-10 and (r['maximum_solute_residual_mg_cm2'] or 0)<=1e-10
  t=r['fixed_irrigation_event_exact_native_windows'];assert t['windows']==[[4,6]] and t['physical_exact'] and t['native_exact'] and t['origins_unchanged']
  actual=t['actual_fixed_irrigation_cm']['5'];kind=r['original_irrigation_type']
  assert actual['subsurface' if kind==2 else 'gross_surface']>0 and actual['gross_surface' if kind==2 else 'subsurface']==0
  windows.append(dict(configuration=key,optimization=r['optimization'],window=[4,6],physical_exact=True,native_exact=True,origins_unchanged=True,irrigation_type=kind,actual_input_cm=actual))
  assert all(math.isfinite(v) and -50<=v<=80 for v in r['active_native_soil_temperature_C'])
  if r['optimization']=='O2':
   assert r['full_period_pass'] and r['completed_days']==r['requested_days']==1096
   assert all(r[k] for k in ('foreign_fixed_file_policy_refused_before_output','independent_distinct_origins','external_discard_replay_exact','external_disk_recovery','inconsistent_mass_refused_without_commit'))
   full.append(r)
assert len(reports)==len(full)==6 and len(windows)==12
q=dict(status='ALL_SIX_EXTERNAL_FIXED_IRRIGATION_CONFIGURATIONS_QUALIFIED',runtime_source='6afb72468c0060df60694d4b69ee8619fdc93062',run=43880184441,full_configurations=6,complete_model_days=6576,full_period_optimization='O2',O0_scope='Ordinary5,active532 and event6 prefixes/native continuations; not six full O0 periods',actual_touched_native_optimizations=['O0','O2'],original_provider_optimization='O2',maximum_water_residual_cm=max(r['maximum_water_residual_cm'] for r in full),maximum_solute_residual_mg_cm2=max(r['maximum_solute_residual_mg_cm2'] or 0 for r in full),mass_guard_cm=1e-10,mass_guard_changed=False,event_windows=windows,chemical_subsurface='EXPLICIT_NATIVE_REFUSAL; original CDE missing source retained, no silent zero concentration',reversed_or_outside_depth='EXPLICIT_NATIVE_REFUSAL before original node search; original zero-delivery counterexample retained',new_state_codec=False,solver_or_time_policy_changed=False,whole_scientific_equivalence='NOT_QUALIFIED',independent_new_historical_projects=0,reports=reports)
(out/'BLOCK_N_QUALIFICATION.json').write_text(json.dumps(q,indent=2)+'\n')
d=json.loads(next((e/'run43880189052').glob('*/RESULT.json')).read_text());assert d['status']=='EXPERIMENTAL_GENERIC_SURFACE_SMOKE_PASS' and len(d['profiles'])==8
(out/'BLOCK_N_DEFAULT_PRESERVATION_RESULT.json').write_text(json.dumps(d,indent=2)+'\n');print({k:v for k,v in q.items() if k not in ('reports','event_windows')})
