import pathlib,subprocess,sys,json,time,zipfile
root=pathlib.Path.cwd();out=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');sys.path.insert(0,str(root/'tools/solute'));from fixed_irrigation_cases import create
reports=[];events=[]
for key in ('water-file-subsurface-interval','chemical-file-sprinkler'):
 source=out/('N_inline_'+key+'_input');create(source,key,inline=True);bundle=out/('N_inline_'+key+'_build');warm=out/('N_inline_'+key+'_warm')
 common=['--model','HYBRID_NOMACRO_WATER','--experimental-project',str(source),'--reference-work',str(out/'J_windows_provider')]
 for args in [common+['--build-only','--kernel-opt','O0','--donor-opt','O0','--output',str(bundle)],common+['--build-bundle',str(bundle),'--days','6','--checkpoint-at','6','--output',str(warm)]]:
  cmd=[sys.executable,'-B','tools/solute/run_water.py',*args];start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);events.append(dict(command=cmd,seconds=time.perf_counter()-start,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(out/'N_INLINE_EVENTS.json').write_text(json.dumps(events,indent=2)+'\n');assert r.returncode==0,(key,r.stdout,r.stderr)
 rows=lambda p:[json.loads(s) for s in (p/'daily.jsonl').read_text().splitlines()]
 physical=lambda rr:[{k:v for k,v in r.items() if k not in ('column','revision')} for r in rr]
 original=out/('N_'+key+'_warm');assert physical(rows(warm))==physical(rows(original))
 with zipfile.ZipFile(warm/'accepted-column-1-day-6.zip') as a,zipfile.ZipFile(out/('N_'+key+'_endpoint')/'accepted-column-1-day-6.zip') as b:assert all(a.read(n)==b.read(n) for n in ('result.end','macro.bin'))
 reports.append(dict(configuration=key,optimization='O0',physical_all_six_days_exact=True,final_native_payload_exact=True,scope='Independent fresh inline0/file1 input cases; no checkpoint/binary/source identity rebinding'))
 (out/'N_INLINE_RESULT.json').write_text(json.dumps(dict(status='ACTUAL_INLINE_AND_FILE_STORAGE_EQUIVALENCE_PASS',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),profiles=reports),indent=2)+'\n');print(key,'INLINE_FILE_EXACT',flush=True)
