import pathlib,subprocess,json,shutil,re,sys,time
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');reports=[]
for name,base,expected in [('chemical-subsurface','chemical-file-surface','Unsupported fixed subsurface solute irrigation'),('reversed-depth','water-file-subsurface-interval','Invalid fixed subsurface irrigation depth interval/profile')]:
 case=e/('N_refusal_'+name+'_input');shutil.copytree(e/'N_inputs'/base,case);path=case/'fixed-irrigation.irg';text=path.read_text()
 if name=='chemical-subsurface':
  text=text.replace('20.0 1 12.0','20.0 2 12.0')+'\nIR_Z = -30.0\n'
 else:text=text.replace('-20.0 -40.0','-40.0 -20.0')
 path.write_text(text);bundle=e/('N_refusal_'+name+'_build');out=e/('N_refusal_'+name+'_run');events=[]
 common=[sys.executable,'-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(case),'--reference-work',str(e/'J_windows_provider')]
 for cmd,refused in [(common+['--build-only','--kernel-opt','O0','--donor-opt','O0','--output',str(bundle)],False),(common+['--build-bundle',str(bundle),'--days','1','--output',str(out)],True)]:
  t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);events.append(dict(command=cmd,seconds=time.perf_counter()-t,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));assert (r.returncode!=0)==refused,(name,r.stdout,r.stderr)
 assert expected in (out/'original/donor.stderr').read_text();assert not list(out.glob('accepted-*.zip'));assert not (out/'daily.jsonl').exists() or not (out/'daily.jsonl').read_text().strip()
 reports.append(dict(name=name,status='ACTUAL_NATIVE_INPUT_REFUSAL_ZERO_ACCEPTED_DAYS',expected_diagnostic=expected,events=events))
 (e/'N_NATIVE_REFUSALS_RESULT.json').write_text(json.dumps(dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),status='ACTUAL_UNSUPPORTED_CHEMICAL_AND_REVERSED_GEOMETRY_REFUSALS_PASS',profiles=reports),indent=2)+'\n');print(name,'NATIVE_REFUSED',flush=True)
