import pathlib,subprocess,json,hashlib
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');out=root/'integration/nomacro-coverage01';sha=lambda b:hashlib.sha256(b).hexdigest();reports={}
configs=[]
for key in ('water-surface-combined','chemical-surface-combined'):
 a=next((e/'run43867490337').glob('*-'+key+'-*'));configs.append((key,a/(key+'-O0-build'),a/('input-'+key),'O0',None))
configs += [('registered-grass',e/'M_preserve_registered_grass_build',None,'O2','HYBRID_GRASSGROWTH_WATER'),('prescribed-head5',e/'M_preserve_head5_96e24606_fullinputs_build',e/'M_preserved_L_head5_inputs','O0',None)]
for key,prior,inputs,opt,model in configs:
 bundle=e/('N_preserve_'+key+'_build')
 if not (bundle/'BUILD.json').exists():
  cmd=['python','-B','tools/solute/run_water.py','--model',model or 'HYBRID_NOMACRO_WATER','--reference-work',str(e/'J_windows_provider'),'--build-only','--kernel-opt',opt,'--output',str(bundle)]
  cmd+=['--no-macro-release'] if model else ['--experimental-project',str(inputs),'--donor-opt',opt]
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);(e/('N_preserve_'+key+'.stdout')).write_text(r.stdout);(e/('N_preserve_'+key+'.stderr')).write_text(r.stderr);assert r.returncode==0,r.stderr
 a=json.loads((bundle/'BUILD.json').read_text());b=json.loads((prior/'BUILD.json').read_text());assert a['inputs']==b['inputs'];assert set(a['identity']['donor_generated'])==set(b['identity']['donor_generated']);fields={}
 for file,digest in b['identity']['donor_generated'].items():
  before=(prior/file).read_bytes();now=(bundle/file).read_bytes();assert sha(before)==digest and sha(now)==a['identity']['donor_generated'][file]
  assert before.replace(b'\r\n',b'\n')==now.replace(b'\r\n',b'\n'),(key,file)
  fields[file]=dict(prior_actual_sha256=digest,current_actual_sha256=sha(now),normalized_LF_sha256=sha(now.replace(b'\r\n',b'\n')))
 kernel={}
 for file,digest in b['identity']['kernel_sources']:
  now=(root/file).read_bytes();canonical=subprocess.check_output(['git','show','166d4b7b5fe9ba0f6ea3aa8af6f5d55d66a904ad:'+file]);assert now.replace(b'\r\n',b'\n')==canonical
  assert digest in (sha(now),sha(canonical)) and dict(a['identity']['kernel_sources'])[file]==sha(now)
  kernel[file]=dict(prior_actual_sha256=digest,current_actual_sha256=sha(now),Git_blob_sha256=sha(canonical))
 for field in ('floating_point_profile','soil_table_policy','solute_step_policy','time_step_policy'):assert a['identity'].get(field)==b['identity'].get(field)
 assert a['identity'].get('fixed_irrigation_file') is None
 reports[key]=dict(status='ACTUAL_PRIOR_SOURCE_INPUT_AND_POLICY_PRESERVED',generated=fields,kernel_sources=kernel,inputs=a['inputs'],current_BUILD_sha256=sha((bundle/'BUILD.json').read_bytes()),prior_BUILD_sha256=sha((prior/'BUILD.json').read_bytes()),scope='Actual M water/chemical history, registered Grassgrowth or L5 compile; new file1 domain inactive. Distinct recorded EOL/binary/source identities; no capsule rebind')
q=dict(status='N_PRIOR_M_L5_AND_NAMED_SOURCE_PRESERVATION_PASS',runtime_source='6afb72468c0060df60694d4b69ee8619fdc93062',baseline='6136101463762b1dd18419fe0260965eccd482c7',profiles=reports,science='NOT_QUALIFIED')
(out/'BLOCK_N_PRIOR_SOURCE_PRESERVATION.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'])
