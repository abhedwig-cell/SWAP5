import pathlib,subprocess,json,sys,time,zipfile
root=pathlib.Path.cwd();out=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');sys.path.insert(0,str(root/'tools/solute'));from fixed_irrigation_cases import SPECS
reports=[];events=[]
for key,(solute,kind,zone) in SPECS.items():
 source=out/'N_inputs'/key;bundle=out/'N_water_file_surface_geometry_build' if key=='water-file-surface' else out/('N_'+key+'_O0_build');warm=out/('N_'+key+'_warm');cold=out/('N_'+key+'_cold');end=out/('N_'+key+'_endpoint')
 common=['--model','HYBRID_NOMACRO_WATER','--experimental-project',str(source),'--reference-work',str(out/'J_windows_provider')]
 commands=[] if (bundle/'BUILD.json').exists() else [common+['--build-only','--kernel-opt','O0','--donor-opt','O0','--output',str(bundle)]]
 commands += [common+['--build-bundle',str(bundle),'--days','6','--checkpoint-at','4','--output',str(warm)],common+['--build-bundle',str(bundle),'--restart',str(warm/'accepted-column-1-day-4.zip'),'--restart-day','4','--days','6','--checkpoint-at','6','--output',str(cold)],common+['--build-bundle',str(bundle),'--days','6','--checkpoint-at','6','--output',str(end)]]
 for index,args in enumerate(commands):
  cmd=[sys.executable,'-B','tools/solute/run_water.py',*args];start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);events.append(dict(configuration=key,command=cmd,seconds=time.perf_counter()-start,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(out/'N_SHORT_EVENTS.json').write_text(json.dumps(events,indent=2)+'\n');assert r.returncode==0,(key,index,r.stdout,r.stderr)
 rows=lambda p:[json.loads(s) for s in (p/'daily.jsonl').read_text().splitlines()]
 physical=lambda rr:[{k:v for k,v in r.items() if k not in ('column','revision')} for r in rr]
 assert physical(rows(cold))==physical(rows(warm)[4:6])
 with zipfile.ZipFile(cold/'accepted-column-1-day-6.zip') as a,zipfile.ZipFile(end/'accepted-column-1-day-6.zip') as b:assert all(a.read(n)==b.read(n) for n in ('result.end','macro.bin'))
 data=rows(warm);assert len(data)==6 and all(r['committed'] for r in data)
 delivered=data[4]['external_flux_cm'][5 if kind==2 else 3];assert delivered>0
 reports.append(dict(configuration=key,status='ACTUAL_O0_SIX_DAY_OWN_NATIVE_4_TO_6_PASS',irrigation_type=kind,max_water_cm=max(abs(x['independent_residual_cm']) for x in data),max_solute_mg_cm2=max(abs(x.get('solute_independent_residual_mg_cm2',0)) for x in data),actual_original_day5_delivery_cm=delivered,delivery_channel='subsurface' if kind==2 else 'gross_surface',nominal_amount_cm=24*.1,nominal_difference_cm=delivered-24*.1))
 (out/'N_SHORT_RESULT.json').write_text(json.dumps(dict(status='SELECTED_ACTUAL_O0_SHORT_AND_NATIVE_PASS',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),profiles=reports),indent=2)+'\n');print(key,'PASS',flush=True)
