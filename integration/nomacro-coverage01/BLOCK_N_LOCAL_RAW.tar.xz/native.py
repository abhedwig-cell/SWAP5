import pathlib
p=next(pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence/run43416681903').rglob('water-history-O0-build'))
for f in p.glob('*.f90'):
 s=f.read_text(encoding='cp1252')
 if 'my_rwadou' in s.lower() and 'subroutine my_rwadou' in s.lower():print(f, s[s.lower().index('subroutine my_rwadou'):][:2000])
print([x.name for x in p.iterdir()])
