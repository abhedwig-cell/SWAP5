import pathlib,json,subprocess
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');p=root/'integration/nomacro-coverage01';source='e8d78740663a879945f05b4ecd445db30554ceac'
platforms={'Windows':{},'Ubuntu':{}}
for mode in ('water','chemical'):
 key=mode+'-surface-history';w=json.loads((p/('BLOCK_O_WINDOWS_'+mode.upper()+'.json')).read_text());platforms['Windows'][key]=w
 a=next((e/'run43887021490').glob('nomacro-pond-history-'+key+'-*'));r=json.loads((a/'RESULT.json').read_text());assert r['status']=='COMPLETE_SCHEDULED_POND_HISTORY_O0_O2_PASS' and r['source_commit']==source;platforms['Ubuntu'][key]=r
 c=json.loads((a/'pond-component/RESULT.json').read_text());assert c['status']=='PRODUCTION_ORIGINAL_SCHEDULED_POND_CODEC_O0_O2_PASS'
 for opt in ('O0','O2'):
  assert w['profiles'][opt]['all_1096_physical_rows_exact_to_failed_source']
records=[profile for cases in platforms.values() for report in cases.values() for profile in report['profiles'].values()]
assert len(records)==8 and all(r['days']==1096 and len(r['own'])==4 for r in records)
q=dict(status='BOTH_PLATFORMS_COMPLETE_SCHEDULED_POND_HISTORY_O0_O2_QUALIFIED',runtime_source=source,Windows_execution_source=platforms['Windows']['water-surface-history']['source_commit'],Windows_runtime_surface_exact_to_Ubuntu=not bool(subprocess.check_output(['git','diff',platforms['Windows']['water-surface-history']['source_commit'],source,'--','app','src','reference','tools','tests/nomacro_pond_history','tests/nomacro_mixtures'])),runs=[43887021490],platforms=platforms,full_configurations=2,full_trajectories=8,complete_model_days=8768,full_native_windows=32,maximum_water_residual_cm=max(r['budgets']['max_water_cm'] for r in records),maximum_kernel_residual_cm=max(r['budgets']['max_kernel_cm'] for r in records),maximum_solute_residual_mg_cm2=max(r['budgets']['max_solute_mg_cm2'] for r in records),mass_guard_cm=1e-10,tolerances_changed=False,physical_equations_changed=False,old_failed_mixture_evidence='UNCHANGED; four original199to201 native FAILs stay FAIL',whole_scientific_equivalence='NOT_QUALIFIED',whole_energy='NOT_QUALIFIED')
(p/'BLOCK_O_QUALIFICATION.json').write_text(json.dumps(q,indent=2)+'\n');print({k:v for k,v in q.items() if k!='platforms'})
