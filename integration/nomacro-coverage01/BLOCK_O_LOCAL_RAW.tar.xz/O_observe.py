import pathlib,sys,json,importlib.util,hashlib,subprocess,zipfile
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');sys.path[:0]=[str(root/'app/hybrid_water'),str(root/'tools/solute')]
spec=importlib.util.spec_from_file_location('mixtures',root/'tests/nomacro_mixtures/run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
import history_top_state as top,run_water
original=top.render

def observed(source):
 s=original(source).replace('use variables,only:t1900','use variables,only:t1900,pondmx')
 s=s.replace('  version=1;clock=t1900;',"  write(0,*)'O_TOP_SAVE',t1900,pondmx,h0max\n  version=1;clock=t1900;")
 s=s.replace('if(.not.hybrid_top_pending)return',"if(.not.hybrid_top_pending)return\nwrite(0,*)'O_TOP_APPLY_BEFORE',t1900,pondmx,h0max")
 s=s.replace('hybrid_top_pending=.false.\nend subroutine',"write(0,*)'O_TOP_APPLY_AFTER',t1900,pondmx,h0max\nhybrid_top_pending=.false.\nend subroutine")
 return s

top.render=observed
out=e/'O_observation';out.mkdir();inventory=m.fixtures(out);key='water-surface-history';case=out/key;build=out/'diagnostic-build';reference=e/'J_windows_provider'
sys.argv=['run_water','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(case),'--reference-work',str(reference),'--build-only','--kernel-opt','O0','--donor-opt','O0','--output',str(build)]
assert run_water.main()==0
project=m.e.load(case);full=out/'diagnostic-warm';result,data=m.trajectory(build,reference,project,full,201,{199,201},60)
try:own=m.own(build,reference,project,full,data,199,201,out/'diagnostic-own199');error=None
except AssertionError as exc:own=None;error=repr(exc)
logs={p.relative_to(out).as_posix():p.read_text() for p in out.rglob('donor.stderr')}
with zipfile.ZipFile(full/'accepted-column-1-day-201.zip') as a,zipfile.ZipFile(out/'diagnostic-own199/accepted-column-1-day-201.zip') as b:
 differences={n:sum(x!=y for x,y in zip(a.read(n),b.read(n))) for n in ('result.end','macro.bin')}
q=dict(status='DIAGNOSTIC_ONLY_ORIGINAL_POND_CARRY_OBSERVATION',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_render='Actual emitted top source adds only unit0 output at original checkpoint and staged restore; no values changed; NOT production qualification',generated_top_sha256=hashlib.sha256((build/'boundtop.f90').read_bytes()).hexdigest(),build=json.loads((build/'BUILD.json').read_text()),warm=result,native_error=error,native_differing_bytes=differences,observations=logs,scope='One original water surface/history 201-day diagnostic, cold199to201. Old immutable mixture cohort unchanged; no source/capsule rebind')
(e/'O_OBSERVATION.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(dict(status=q['status'],differences=differences,logs=logs),indent=2))
