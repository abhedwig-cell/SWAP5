import pathlib
p=pathlib.Path('tests/hupsel51/verify_successor.py');s=p.read_text()
s=s.replace("CURRENT_RUNTIME = '6afb", "N_RUNTIME = '6afb")
s=s.replace("N_SEALED =", "N_ADMITTED = '8dcda0fb247ae7823d720817d6340114d5227728'\nCURRENT_RUNTIME = 'e8d78740663a879945f05b4ecd445db30554ceac'\nO_WINDOWS = '6bb58557252f3c7ab8da27efe18e8cbe53bffe5d'\nO_SEALED = 'O_SEAL_PLACEHOLDER'\nN_SEALED =",1)
a=s.index('def validate_n(');b=s.index('def verify():',a)
s=s[:a]+s[a:b].replace('CURRENT_RUNTIME','N_RUNTIME').replace("N_RUNTIME,'HEAD','--'","N_RUNTIME,N_ADMITTED,'--'").replace("N_SEALED,'HEAD').decode()","N_SEALED,N_ADMITTED).decode()")+s[b:]
s=s.replace('    n = verify_n()','    n = verify_n()\n    o = verify_o()').replace("prior_composed_runtime=RUNTIME,","current_O_full_days=o['complete_model_days'],current_O_proof_anchor=O_SEALED,\n                prior_composed_runtime=RUNTIME,")
p.write_text(s)
