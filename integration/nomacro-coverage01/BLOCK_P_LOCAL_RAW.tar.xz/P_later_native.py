import pathlib,sys,json,subprocess,contextlib,importlib.util
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');sys.path[:0]=[str(root/'app/hybrid_water'),str(root/'tools/solute')]
spec=importlib.util.spec_from_file_location('mixtures',root/'tests/nomacro_mixtures/run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);reference=e/'J_windows_provider';reports={}

def own_tail(build,reference,project,full,data,start,end,out):
 meta,case=m.validate_bundle(build,reference,project);source=full/f"accepted-column-1-day-{start}.zip";digest=m.sha(source)
 if not out.exists():
  origin=out.with_name(out.name+"-origin");receipt=m.h.verify_checkpoint(source,start,meta["binding"],origin);out.mkdir()
  result=m.h.run(m.h.executable(build,"day_donor"),m.h.executable(build,"day_kernel"),case,out,end,checkpoint_day=start,origin=origin,origin_receipt=receipt,runtime=True,publish_day=end,checkpoint_binding=meta["binding"],model=project.model,project=project);assert result["first_refusal"] is None
 actual=m.rows(out);m.check(actual);assert m.physical(actual)==m.physical(data[start:end])
 assert m.csvlines(out/"original/result_output.csv")[-(end-start):]==m.csvlines(full/"original/result_output.csv")[start-172+2:end-172+2]
 import zipfile
 with zipfile.ZipFile(full/f"accepted-column-1-day-{end}.zip") as a,zipfile.ZipFile(out/f"accepted-column-1-day-{end}.zip") as b:
  assert all(a.read(n)==b.read(n) for n in ("result.end","macro.bin"))
 assert m.sha(source)==digest
 return dict(start=start,end=end,exact_physical=True,exact_csv=True,exact_native=True,origin_unchanged=True,full_trace_origin_day=172)

for mode in ('water','chemical'):
 old=e/('P_'+mode+'_free_local');project=m.e.load(old/'input')
 for opt in ('O0','O2'):
  build=e/('P_current_'+mode+'_'+opt+'_build');warm=e/('P_current_'+mode+'_'+opt+'_warm172');meta,case=m.validate_bundle(build,reference,project)
  out=e/('P_current_'+mode+'_'+opt+'_tail172to903');existed=out.exists()
  if not existed:
   out.mkdir();origin=out/'origin172';receipt=m.h.verify_checkpoint(warm/'accepted-column-1-day-172.zip',172,meta['binding'],origin)
  data=[json.loads(s) for s in (old/(opt+'-full/daily.jsonl')).read_text().splitlines()];actual=[];cuts=(374,535,739,901)
  def tail():
   with contextlib.ExitStack() as stack:
    host=m.h.DailyHost(stack,m.h.executable(build,'day_donor'),m.h.executable(build,'day_kernel'),case,out,[m.h.ColumnStart(day=172,origin=origin,receipt=receipt)],runtime=True,checkpoint_enabled=True,binding=meta['binding'],project=project)
    with (out/'daily.jsonl').open('w') as f:
     for day in range(173,904):
      row=host.step(1,checkpoint=day in set(cuts)|{d+2 for d in cuts});f.write(json.dumps(row)+'\n');f.flush();assert row['committed'] and m.physical([row])==m.physical([data[day-1]]);actual.append(row)
    host.close()
  if existed:
   actual=[json.loads(s) for s in (out/'daily.jsonl').read_text().splitlines()];assert len(actual)==731 and m.physical(actual)==m.physical(data[172:903]);seconds=None
  else:_,seconds=m.bounded(60,tail)
  m.check(actual)
  own=[own_tail(build,reference,project,out,data,cut,cut+2,e/('P_current_'+mode+'_'+opt+'_frost_own'+str(cut))) for cut in cuts]
  reports[mode+'-'+opt]=dict(status='MISSING_LATER_YEAR_FROST_NATIVE_WINDOWS_PASS_ON_CURRENT_EXACT_SOURCE',current_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),native_start_day=172,accepted_days=731,all_physical_rows_exact_to_prior_full=True,model_seconds=seconds,own=own)
  (e/'P_LATER_FROST_NATIVE.json').write_text(json.dumps(dict(status='ALL_FOUR_CURRENT_LATER_YEAR_FROST_NATIVE_PASS' if len(reports)==4 else 'PARTIAL_LATER_FROST_NATIVE',profiles=reports,scope='Only missing later-year native probes; source-identical current capsule172, no whole completed period rerun or old capsule rebinding',science='NOT_QUALIFIED'),indent=2)+'\n');print(mode,opt,'LATER_YEAR_FROST_NATIVE_PASS',flush=True)
