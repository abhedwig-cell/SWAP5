import pathlib,subprocess,json,hashlib,shutil,csv,time
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');provider=e/'J_windows_provider';out=e/'P_guarded_original_reference';out.mkdir();objects=provider/'build/swap-obj';tt=provider/'build/ttutil-obj/libttutil.a';patched=e/'P_current_water_O2_build/frozencond.o';exe=out/'original_guarded.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
command=['gfortran','-o',str(exe),*[str(patched) if p.name=='frozencond.o' else str(p) for p in sorted(objects.glob('*.o'))],str(tt)];r=subprocess.run(command,cwd=out,capture_output=True,text=True,timeout=120);assert r.returncode==0,r.stderr
reports={}
def rows(path):return list(csv.DictReader([s for s in path.read_text(encoding='cp1252').splitlines() if s.strip() and not s.startswith('*')]))
for mode in ('water','chemical'):
 source=e/('P_'+mode+'_free_local/input');case=out/mode;shutil.copytree(source,case);inventory={p.relative_to(source).as_posix():sha(p) for p in source.rglob('*') if p.is_file()};assert all(sha(case/n)==v for n,v in inventory.items())
 started=time.perf_counter();timed_out=False;code=None
 with (case/'original.stdout').open('wb') as log:
  try:r=subprocess.run([str(exe),'./swap.swp'],cwd=case,stdout=log,stderr=subprocess.STDOUT,timeout=30);code=r.returncode
  except subprocess.TimeoutExpired:timed_out=True
 seconds=time.perf_counter()-started;left=rows(case/'result_output.csv') if (case/'result_output.csv').exists() else [];right=rows(e/('P_'+mode+'_free_local/O2-full/original/result_output.csv'));common=min(len(left),len(right));differences={}
 if common:
  for field in left[0].keys()&right[0].keys():
   try:values=[abs(float(a[field])-float(b[field])) for a,b in zip(left[:common],right[:common])]
   except ValueError:continue
   differences[field]=max(values)
 reports[mode]=dict(status='COMPLETE_CORRECTED_ORIGINAL_DIAGNOSTIC_REFERENCE' if not timed_out and (case/'swap.ok').exists() and common==1097 else 'CENSORED_OR_REFUSED_REFERENCE_NOT_QUALIFIED',seconds=seconds,timeout=timed_out,returncode=code,swap_ok=(case/'swap.ok').exists(),original_rows=len(left),swap5_rows=len(right),identical_executed_inputs=inventory,maximum_numeric_csv_differences=differences,error=(case/'swap.err').read_text(encoding='cp1252') if (case/'swap.err').exists() else '',scientific_equivalence='NOT_QUALIFIED')
 q=dict(status='SOURCE_BOUND_DIAGNOSTIC_REFERENCE_COMPLETION_NO_SCIENTIFIC_PROMOTION',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),actual_original_provider=sha(provider/'PREPARED.json'),compiler_command=command,executable_sha256=sha(exe),only_original_object_replaced='frozencond.o',corrected_source_sha256=sha(e/'P_current_water_O2_build/frozencond.f90'),original_objects_sha256={p.name:sha(p) for p in objects.glob('*.o') if p.name!='frozencond.o'},profiles=reports,scope='Complete unmodified original main/reader/physics with only exact admitted FROST-GEOMETRY-01 module; same output-compatible physical input decks as SWAP5; no global B1/macro campaign or new science threshold')
 (e/'P_ORIGINAL_REFERENCE_RESULT.json').write_text(json.dumps(q,indent=2)+'\n');print(mode,reports[mode]['status'],seconds,flush=True)
