import pathlib,subprocess,json,hashlib,sys,importlib.util
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');sys.path[:0]=[str(root/'app/hybrid_water'),str(root/'tools/solute')]
s=importlib.util.spec_from_file_location('mixtures',root/'tests/nomacro_mixtures/run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();profiles={}
for mode in ('water','chemical'):
 priorroot=e/('P_'+mode+'_free_local');case=priorroot/'input';project=m.e.load(case);reference=e/'J_windows_provider';fullrows=[json.loads(s) for s in (priorroot/'O0-full/daily.jsonl').read_text().splitlines()]
 for opt in ('O0','O2'):
  old=priorroot/(opt+'-build');target=e/('P_current_'+mode+'_'+opt+'_build');cmd=['python','-B','tools/solute/run_water.py','--model',m.e.MODEL,'--experimental-project',str(case),'--reference-work',str(reference),'--build-only','--kernel-opt',opt,'--donor-opt',opt,'--output',str(target)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);(e/('P_current_'+mode+'_'+opt+'.stderr')).write_text(r.stderr);assert r.returncode==0,r.stderr
  a=json.loads((target/'BUILD.json').read_text());b=json.loads((old/'BUILD.json').read_text());assert a['inputs']==b['inputs'];assert a['identity']['donor_generated']==b['identity']['donor_generated'];assert a['identity']['kernel_sources']==b['identity']['kernel_sources']
  for file,digest in a['identity']['donor_generated'].items():assert sha(target/file)==sha(old/file)==digest
  for key in ('floating_point_profile','soil_table_policy','solute_step_policy','time_step_policy','frost_reference','micro_lookup_state_policy'):assert a['identity'].get(key)==b['identity'].get(key)
  warm=e/('P_current_'+mode+'_'+opt+'_warm172');report,rows=m.trajectory(target,reference,project,warm,172,{2,4,9,11,170,172},30)
  originalrows=[json.loads(s) for s in (priorroot/(opt+'-full/daily.jsonl')).read_text().splitlines()];assert m.physical(rows)==m.physical(originalrows[:172])
  report['own']=[m.own(target,reference,project,warm,rows,cut,cut+2,e/('P_current_'+mode+'_'+opt+'_own'+str(cut))) for cut in (2,9,170)]
  profiles[mode+'-'+opt]=dict(status='ACTUAL_CURRENT_FREE_FROST_SOURCES_INPUTS_AND_ACTIVE_NATIVE_PRESERVED',prior_source=b.get('source_commit'),generated=a['identity']['donor_generated'],kernel_sources=a['identity']['kernel_sources'],inputs=a['inputs'],actual_prefix=report,all_172_physical_rows_exact_to_prior_full=True,scope='Fresh actual sources/compiler flags and native origins; no capsule binding reassignments, old complete physical trajectories not rerun')
  q=dict(status='P_FOUR_COMPLETED_FREE_FROST_TRAJECTORIES_INHERITED_ON_FRESH_EXACT_SOURCE_AND_ACTIVE_NATIVE_PRESERVATION' if len(profiles)==4 else 'PARTIAL_CURRENT_PRESERVATION',runtime_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prior_executed_source=subprocess.check_output(['git','rev-parse','5a59d1799'],text=True).strip(),profiles=profiles,science='NOT_QUALIFIED')
  (e/'P_CURRENT_FREE_PRESERVATION.json').write_text(json.dumps(q,indent=2)+'\n');print(mode,opt,'CURRENT_SOURCE_AND_ACTIVE_NATIVE_PASS',flush=True)
