import pathlib,sys,importlib.util,json,subprocess,shutil,time
root=pathlib.Path.cwd();e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');sys.path[:0]=[str(root/'app/hybrid_water'),str(root/'tools/solute')]
s=importlib.util.spec_from_file_location('mixtures',root/'tests/nomacro_mixtures/run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
out=e/'P_pond_repair37';out.mkdir();case=out/'input';shutil.copytree(e/'P_water_undrained_v2_local/input',case);project=m.e.load(case);ref=e/'J_windows_provider';profiles={};events=[]
for opt in ('O0','O2'):
 build=out/(opt+'-build');cmd=[sys.executable,'-B','tools/solute/run_water.py','--model',m.e.MODEL,'--experimental-project',str(case),'--reference-work',str(ref),'--build-only','--kernel-opt',opt,'--donor-opt',opt,'--output',str(build)];start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);events.append(dict(command=cmd,seconds=time.perf_counter()-start,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,r.stderr
 full=out/(opt+'-warm');report,rows=m.trajectory(build,ref,project,full,37,{2,4,35,37},60)
 report['own']=[m.own(build,ref,project,full,rows,start,end,out/(opt+'-own'+str(start))) for start,end in [(2,4),(35,37)]];profiles[opt]=report
 q=dict(status='REPAIR37_O0_O2_PASS' if len(profiles)==2 else 'PARTIAL_REPAIR37',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),profiles=profiles,events=events,prior_failed_source='1e395f6d5d53d8c80c095534812f3515c4ad4ec3',old_refusal_day=36,new_accepted_through=37,mass_guard_changed=False,science='NOT_QUALIFIED')
 (e/'P_REPAIR37_RESULT.json').write_text(json.dumps(q,indent=2)+'\n');print(opt,'REPAIR37_AND_EXACT_NATIVE_PASS',flush=True)
