from pathlib import Path
import subprocess,json
root=Path.cwd();e=Path('C:/Users/Veldh012/swap5-coverage-evidence');reports={}
for opt in ('O0','O2'):
 build=e/('Q_event2_'+opt+'_build');run=e/('Q_event2_'+opt+'_run');common=['python','-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(e/'P_water_drained_feddes_local/input'),'--reference-work',str(e/'J_windows_provider')]
 for phase,cmd in [('build',common+['--build-only','--kernel-opt',opt,'--donor-opt',opt,'--output',str(build)]),('run',common+['--build-bundle',str(build),'--days','21','--checkpoint-at','20','--timeout-seconds','30','--output',str(run)])]:
  q=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=180);(e/('Q_event2_'+opt+'_'+phase+'.log')).write_text(q.stdout+'\n'+q.stderr);print(opt,phase,q.returncode,q.stdout[-350:],q.stderr[-350:],flush=True)
  reports[opt+'-'+phase]=dict(returncode=q.returncode,command=cmd)
  (e/'Q_EVENT2_REPLAY_COMMANDS.json').write_text(json.dumps(reports,indent=2)+'\n')
  if phase=='build':assert q.returncode==0,q.stderr
