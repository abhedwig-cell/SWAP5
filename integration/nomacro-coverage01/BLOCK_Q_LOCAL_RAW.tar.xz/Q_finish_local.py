from pathlib import Path
import sys,importlib.util,json,subprocess,time,zipfile
root=Path.cwd();ev=Path('C:/Users/Veldh012/swap5-coverage-evidence');out=ev/'Q_terminal2_water_drained_local';ref=ev/'J_windows_provider'
s=importlib.util.spec_from_file_location('q_owner',root/'tests/nomacro_time_event/run.py');owner=importlib.util.module_from_spec(s);s.loader.exec_module(owner);m=owner.m;checks=owner.checks
from time_event_closure import POLICY
case=out/'input';project=m.e.load(case,time_step_policy=POLICY);result=json.loads((out/'RESULT.json').read_text());assert not subprocess.check_output(['git','diff',result['source_commit'],'HEAD','--','app','src','reference'],text=True).strip()
def save():(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
def existing_own(opt,full,rows,start,end,tag):
 cold=out/(opt+'-'+tag+str(start));actual=m.rows(cold);m.check(actual);assert m.physical(actual)==m.physical(rows[start:end]);assert m.csvlines(cold/'original/result_output.csv')[-(end-start):]==m.csvlines(full/'original/result_output.csv')[start+2:end+2]
 with zipfile.ZipFile(full/f'accepted-column-1-day-{end}.zip') as a,zipfile.ZipFile(cold/f'accepted-column-1-day-{end}.zip') as b:
  for name in ('result.end','macro.bin'):assert a.read(name)==b.read(name)
 return dict(start=start,end=end,exact_physical=True,exact_csv=True,exact_native=True,origin_unchanged=True,model_execution='ALREADY_COMPLETED_NATIVE_RECONSUMED_NO_RERUN',seconds='UNKNOWN_FROM_COMPLETED_RECORD')
for opt in ('O0','O2'):
 build=out/(opt+'-build')
 if opt=='O2':
  cmd=[sys.executable,'-B','tools/solute/run_water.py','--model',m.e.MODEL,'--experimental-project',str(case),'--reference-work',str(ref),'--experimental-time-step-policy',POLICY,'--build-only','--kernel-opt',opt,'--donor-opt',opt,'--output',str(build)];started=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);result['events'].append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-started));save();assert r.returncode==0,r.stderr
  short=out/(opt+'-short');brief,shortrows=m.trajectory(build,ref,project,short,5,{2,4},30);brief['own']=m.own(build,ref,project,short,shortrows,2,4,out/(opt+'-short-own'))
  cuts={2,4,199,201,365,367,530,532,1096};active=(9,170,374,535,739,901);cuts|=set(active)|{v+2 for v in active}
  full=out/(opt+'-full');r,rows=m.trajectory(build,ref,project,full,1096,cuts,60);r['short']=brief;result['profiles'][opt]=r;save()
 else:
  full=out/(opt+'-full');rows=m.rows(full);m.check(rows);r=result['profiles'][opt];assert len(rows)==1096
 active=(9,170,374,535,739,901)
 r['own']=[existing_own(opt,full,rows,start,end,'own') if opt=='O0' else m.own(build,ref,project,full,rows,start,end,out/(opt+f'-own{start}')) for start,end in ((2,4),(199,201),(365,367),(530,532))];save()
 actual=[]
 for line in (full/'original/donor.stdout').read_text().splitlines():
  if line.startswith('HYBRID_FROST_WITNESS '):
   v=list(map(float,line.split()[1:]));assert len(v)==6 and 0<=v[0]<=v[1]<=1;actual.append(v)
 assert len(actual)==1097;initial=actual.pop(0);assert initial[-1]==0 and all(v[-1]==1 for v in actual)
 r['frost_witness']=dict(initial_original_uncomputed_diagnostic=initial,actual_daily_original_records=len(actual),minimum_rfcp=min(v[0] for v in actual),days_with_reduction=sum(v[0]<1 for v in actual),days_with_zero_factor=sum(v[0]==0 for v in actual),original_front_nodes=sorted(set(int(v[2]) for v in actual)),actual_records=actual)
 assert all(any(actual[day-1][0]<1 for day in range(cut+1,cut+3)) for cut in active)
 r['active_frost_exact_native_windows']=[existing_own(opt,full,rows,cut,cut+2,'frost-own') if opt=='O0' else m.own(build,ref,project,full,rows,cut,cut+2,out/(opt+'-frost-own'+str(cut))) for cut in active];save()
 controls=out/(opt+'-controls-completed');controls.mkdir();r['controls']=checks.controls(build,ref,project,controls,full,rows,policy_key='frost_reference');save();print(opt,'FULL_STRICT_NATIVE_AND_TRANSACTIONS_PASS',flush=True)
result['status']='COMPLETE_TIMECONTROL_FROST_DRAINAGE_O0_O2_PASS';result['verification_completion_source']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();result['verification_scope']='O0 complete physical/native execution consumed once; only failed verification setup resumed; O2 fresh on unchanged app/src/reference';save()
