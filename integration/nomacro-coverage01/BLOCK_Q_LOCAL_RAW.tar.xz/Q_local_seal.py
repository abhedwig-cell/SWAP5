import pathlib,json,tarfile,hashlib
e=pathlib.Path('C:/Users/Veldh012/swap5-coverage-evidence');out=pathlib.Path.cwd()/'integration/nomacro-coverage01';raw=out/'BLOCK_Q_LOCAL_RAW.tar.xz';files={}
with tarfile.open(raw,'w:xz',preset=1) as t:
 for base in sorted(e.glob('Q*')):
  for p in ([base] if base.is_file() else base.rglob('*')):
   if not p.is_file() or p.suffix.lower() not in ('.json','.jsonl','.csv','.zip','.bin','.end','.err','.log','.stdout','.stderr','.f90','.swp','.crp','.dra','.bbc','.ini','.met','.irg','.tss','.tgs','.ru','.inp','.cmd','.txt','.py'):continue
   if 'provider' in p.relative_to(e).parts:continue
   rel=p.relative_to(e).as_posix();t.add(p,arcname=rel,recursive=False);files[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
m=dict(archive=raw.name,bytes=raw.stat().st_size,sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),files=files,scope='Actual Q original/corrected clock, complete terminal receipt component, retained failed attempts, all Windows full/native/external controls, exact prior source/native preservation, bounded corrected-original diagnostics and helper methods. Original immutable provider objects/executables excluded; identities retained. No model/macro campaign added by sealing.')
(out/'BLOCK_Q_LOCAL_ARCHIVE.json').write_text(json.dumps(m,indent=2)+'\n');print(raw.name,m['bytes'],m['sha256'])
