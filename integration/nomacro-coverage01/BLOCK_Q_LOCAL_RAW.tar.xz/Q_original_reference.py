from pathlib import Path
import subprocess,json,hashlib,shutil,time,csv
root=Path.cwd();e=Path('C:/Users/Veldh012/swap5-coverage-evidence');ref=e/'J_windows_provider';out=e/'Q_corrected_original_reference';out.mkdir(exist_ok=False);objects=ref/'build/swap-obj';tt=ref/'build/ttutil-obj/libttutil.a';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();replacement={'timecontrol.o':e/'Q_reference_time_event/O2-corrected/timecontrol.o','frozencond.o':e/'P_current_water_O2_build/frozencond.o'};exe=out/'original_corrected.exe';command=['gfortran','-o',str(exe),*[str(replacement.get(p.name,p)) for p in sorted(objects.glob('*.o'))],str(tt)];r=subprocess.run(command,cwd=out,capture_output=True,text=True,timeout=90);assert r.returncode==0,r.stderr
case=out/'input';source=e/'Q_terminal2_water_drained_local/input';shutil.copytree(source,case);inputs={p.name:sha(p) for p in source.iterdir() if p.is_file()};start=time.perf_counter();code=None;timeout=False
with (case/'original.stdout').open('wb') as log:
 try:code=subprocess.run([str(exe),'./swap.swp'],cwd=case,stdout=log,stderr=subprocess.STDOUT,timeout=30).returncode
 except subprocess.TimeoutExpired:timeout=True
seconds=time.perf_counter()-start
rows=lambda p:list(csv.DictReader([s for s in p.read_text(encoding='cp1252').splitlines() if s.strip() and not s.startswith('*')]))
a=rows(case/'result_output.csv') if (case/'result_output.csv').exists() else [];b=rows(e/'Q_terminal2_water_drained_local/O0-full/original/result_output.csv');diff={}
for k in a[0] if a else []:
 try:diff[k]=max(abs(float(x[k])-float(y[k])) for x,y in zip(a,b))
 except ValueError:pass
q=dict(status='COMPLETE_CORRECTED_ORIGINAL_DIAGNOSTIC_REFERENCE' if len(a)==len(b)==1097 and not timeout and (case/'swap.ok').exists() else 'CENSORED_OR_REFUSED_REFERENCE_NOT_QUALIFIED',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),compiler_command=command,executable_sha256=sha(exe),original_objects={p.name:sha(p) for p in objects.glob('*.o') if p.name not in replacement},replaced_objects={k:sha(p) for k,p in replacement.items()},corrected_timecontrol_sha256=sha(e/'Q_reference_time_event/O2-corrected/timecontrol.f90'),corrected_frost_sha256=sha(e/'P_current_water_O2_build/frozencond.f90'),inputs=inputs,returncode=code,timeout=timeout,seconds=seconds,original_rows=len(a),swap5_rows=len(b),maximum_numeric_csv_differences=diff,science='NOT_QUALIFIED',scope='Bounded original complete main/reader with exactly qualified event-closure and frost modules; no B0/macro/global B1 promotion')
(e/'Q_ORIGINAL_REFERENCE_RESULT.json').write_text(json.dumps(q,indent=2)+'\n');print(q['status'],len(a),seconds,flush=True)
