from pathlib import Path
import subprocess,json,hashlib,time
root=Path.cwd();e=Path('C:/Users/Veldh012/swap5-coverage-evidence');ref=e/'J_windows_provider';out=e/'Q_terminal_component';out.mkdir(exist_ok=False);objects=ref/'build/swap-obj';tt=ref/'build/ttutil-obj';reports={};source=root/'app/hybrid_water/terminal_water_receipt.f90';driver=root/'tools/solute/drivers/original_terminal_water_receipt.f90'
for opt in ('O0','O2'):
 target=out/opt;target.mkdir();flags=['-'+opt,'-cpp','-Dlinux','-finit-local-zero','-ffree-line-length-none','-fallow-argument-mismatch','-fcheck=all','-ffpe-trap=invalid,zero,overflow','-ffp-contract=off','-march=x86-64','-mtune=generic','-I',str(objects),'-I',str(tt)]
 commands=[['gfortran',*flags,'-c',str(source),str(driver)],['gfortran','-o',str(target/'terminal.exe'),*[str(p) for p in sorted(objects.glob('*.o')) if p.name!='swap_main.o'],str(target/'terminal_water_receipt.o'),str(target/'original_terminal_water_receipt.o'),str(tt/'libttutil.a')],[str(target/'terminal.exe')]];logs=[]
 for cmd in commands:
  started=time.perf_counter();r=subprocess.run(cmd,cwd=target,capture_output=True,text=True,timeout=90);logs.append(dict(command=cmd,seconds=time.perf_counter()-started,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(target/'commands.json').write_text(json.dumps(logs,indent=2));assert r.returncode==0,r.stderr
 reports[opt]=logs;print(opt,'ACTUAL_ORIGINAL_TERMS_PASS',flush=True)
 (out/'RESULT.json').write_text(json.dumps(reports,indent=2))
assert reports['O0'][-1]['stdout']==reports['O2'][-1]['stdout']
print('O0_O2_EXACT_TERMS_AND_NO_MUTATION_PASS')
