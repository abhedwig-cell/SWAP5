from pathlib import Path
import sys,importlib.util,json,subprocess
root=Path.cwd();e=Path('C:/Users/Veldh012/swap5-coverage-evidence');sys.path.insert(0,str(root/'tests/nomacro_drainage'));s=importlib.util.spec_from_file_location('table_owner',root/'tests/nomacro_drainage/run.py');owner=importlib.util.module_from_spec(s);s.loader.exec_module(owner);m=owner.m
for key,folder in [('water-drain-table','R_water_table_local'),('chemical-drain-table','R_chemical_table_local')]:
 out=e/folder;result=json.loads((out/'RESULT.json').read_text());assert result['status']=='FULL_TABULATED_DRAINAGE_NATIVE_O0_O2_PASS_EXTERNAL_NOT_YET_QUALIFIED';assert not subprocess.check_output(['git','diff',result['source_commit'],'HEAD','--','app','src','reference'],text=True).strip();project=m.e.load(out/'input')
 for opt,r in result['profiles'].items():
  full=out/(opt+'-full');rows=m.rows(full);m.check(rows);controls=out/(opt+'-controls');controls.mkdir();r['controls']=owner.controls(m,out/(opt+'-build'),e/'J_windows_provider',project,controls,full,rows);(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(key,opt,'EXTERNAL_ISOLATION_NATIVE_REFUSALS_PASS',flush=True)
 result['status']='COMPLETE_TABULATED_DRAINAGE_O0_O2_PASS';result['verification_completion_source']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();result['verification_scope']='Completed original f6cea125d full/native trajectories consumed once; remaining external/refusal gates executed on identical app/src/reference';(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
