from pathlib import Path
import subprocess,sys
mode=sys.argv[1];root=Path.cwd();e=Path('C:/Users/Veldh012/swap5-coverage-evidence')
for suffix in ('table','signed'):
 key=mode+'-drain-'+suffix;out=e/('R_repaired_'+mode+'_'+suffix+'_local');cmd=[sys.executable,'-B','tests/nomacro_drainage/run.py','--configuration',key,'--reference-work',str(e/'J_windows_provider'),'--output',str(out)];r=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=240);(e/('R_repaired_'+mode+'_'+suffix+'.log')).write_text(r.stdout+'\n'+r.stderr);print(key,r.returncode,r.stdout[-650:],r.stderr[-1000:],flush=True);assert r.returncode==0,key
