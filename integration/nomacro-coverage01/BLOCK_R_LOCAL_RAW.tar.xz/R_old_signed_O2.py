from pathlib import Path
import subprocess,json
root=Path.cwd();e=Path('C:/Users/Veldh012/swap5-coverage-evidence');base=['python','-B','tools/solute/run_water.py','--model','HYBRID_NOMACRO_WATER','--experimental-project',str(e/'R_water_signed_local/input'),'--reference-work',str(e/'J_windows_provider')];build=e/'R_signed_old_O2_build';run=e/'R_signed_old_O2_prefix53';records=[]
for phase,cmd in [('build',base+['--build-only','--kernel-opt','O2','--donor-opt','O2','--output',str(build)]),('prefix53',base+['--build-bundle',str(build),'--days','53','--checkpoint-at','50','--timeout-seconds','30','--output',str(run)])]:
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);records.append(dict(phase=phase,command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(e/'R_SIGNED_OLD_O2_REPRODUCTION.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==(0 if phase=='build' else 1),(phase,r.stderr)
q=json.loads((run/'RESULT.json').read_text());assert q['committed_days']==50 and q['first_refusal']['day']==51;print('Original R O2 strict day51 FAIL retained',q['first_refusal']['independent_residual_cm'])
