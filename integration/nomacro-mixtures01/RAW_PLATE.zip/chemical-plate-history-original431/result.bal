* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-16 14:44:47

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        60.65 cm       0.2775E+02 mg/cm2
Initial :        97.19 cm       0.0000E+00 mg/cm2
            =============       =================
Change          -36.54 cm       0.2775E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.28
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.02
Bottom flux    :   -72.12    Soil evaporation  :    11.69
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    14.46    Sum               :    50.99


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.4800E+02    Root uptake    :  0.0000E+00
Bottom flux : -0.2025E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.2775E+02    Sum            :  0.0000E+00


Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        59.02 cm       0.5682E+00 mg/cm2
Initial :        60.65 cm       0.2775E+02 mg/cm2
            =============       =================
Change           -1.63 cm      -0.2718E+02 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     7.14
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :    10.00    Transpiration     :    23.82
Bottom flux    :   -39.66    Soil evaporation  :    12.99
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    42.32    Sum               :    43.95


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.2718E+02
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.2718E+02    Sum            :  0.0000E+00


Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        57.03 cm       0.3165E-02 mg/cm2
Initial :        59.02 cm       0.5682E+00 mg/cm2
            =============       =================
Change           -1.99 cm      -0.5650E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :    11.67
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    27.63
Bottom flux    :   -30.72    Soil evaporation  :    12.52
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    49.83    Sum               :    51.82


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux : -0.5650E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         : -0.5650E+00    Sum            :  0.0000E+00

