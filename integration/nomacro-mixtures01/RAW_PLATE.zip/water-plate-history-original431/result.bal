* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-16 14:43:58

Period             :  2002-01-01  until  2002-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        60.65 cm
Initial :        97.19 cm
            =============
Change          -36.54 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    84.18    Interception      :     4.28
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :    35.02
Bottom flux    :   -72.12    Soil evaporation  :    11.69
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    14.46    Sum               :    50.99

Period             :  2003-01-01  until  2003-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        59.02 cm
Initial :        60.65 cm
            =============
Change           -1.63 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    71.98    Interception      :     7.14
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :    10.00    Transpiration     :    23.82
Bottom flux    :   -39.66    Soil evaporation  :    12.99
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    42.32    Sum               :    43.95

Period             :  2004-01-01  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        57.03 cm
Initial :        59.02 cm
            =============
Change           -1.99 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain           :    80.55    Interception      :    11.67
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    27.63
Bottom flux    :   -30.72    Soil evaporation  :    12.52
                             Crack flux        :     0.00
                             Drainage level 1  :     0.00
=========================    ============================
Sum            :    49.83    Sum               :    51.82
