* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-17 09:12:04

Period             :  1900-01-01  until  2002-01-05 
Depth soil profile :  200.00 cm

            Water storage
Final   :        77.45 cm
Initial :        75.19 cm
            =============
Change            2.26 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     0.00    Interception      :     0.00
Runon          :     0.80    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     2.40    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :     0.00
                             Crack flux        :     0.00
                             Drainage level 1  :     0.93
=========================    ============================
Sum            :     3.20    Sum               :     0.94
