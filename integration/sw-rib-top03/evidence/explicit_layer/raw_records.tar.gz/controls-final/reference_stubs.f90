module MOD_swap_base
  implicit none
  integer :: swmacro = 0
  integer :: i_instance = 1
end module MOD_swap_base

module MOD_arrays
  implicit none
  integer, parameter :: macp = 4
  integer, parameter :: mabbc = 4
end module MOD_arrays

module MOD_params
  implicit none
  real(8), parameter :: nihil = 1.0d-12
end module MOD_params

module MOD_grid
  implicit none
  integer, parameter :: numnod = 64
  integer :: grid_i
  real(8), parameter :: z(numnod) = [(-0.05d0*(grid_i-0.5d0),grid_i=1,numnod)]
  real(8), parameter :: dz(numnod) = 0.05d0
  real(8), parameter :: disnod(numnod+1) = [0.025d0,(0.05d0,grid_i=2,numnod),0.025d0]
end module MOD_grid

module variables
  use MOD_grid, only: numnod
  implicit none
  logical :: fldaystart = .false.
  integer :: swbotb = 7
  real(8) :: runon = 0.0d0, epd = 0.0d0, reva = 0.0d0, pondm1 = 0.0d0
  real(8) :: dt = 0.25d0, runots = 0.0d0, t1900 = 1000.0d0
  real(8) :: thetm1(numnod) = 0.30d0, qrot(numnod) = 0.0d0
  integer :: swkimpl = 0, swkmean = 1
  real(8) :: hplate = 0.0d0
  integer :: swbotb3impl = 0, swbotb3resvert = 0
  real(8) :: deepgw = -100.0d0, rimlay = 1.0d0
  integer :: sw4 = 0
  real(8) :: qbotab(2*4) = 0.0d0
  logical :: fldtmin = .false.
  integer :: maxit = 8, maxbacktr = 4
  real(8) :: critdevh2cp = 1.0d-12, critdevh1cp = 1.0d-12, critdevponddt = 1.0d-12
  real(8) :: dtmin = 1.0d-6
  integer :: nodgwl = numnod
  real(8) :: gwlm1 = -2.0d0, hm1(numnod) = -100.0d0
  real(8) :: CritDevBalCp = 1.0d-12, CritDevBalTot = 1.0d-12

  real(8) :: h(numnod) = -100.0d0, theta(numnod) = 0.30d0
  real(8) :: kmean(numnod+1) = 1.0d0, gwlinp = -5.0d0, pond = 0.0d0
  real(8) :: dtold = 0.25d0, qtop = -1.0d0, qbot = -1.0d0, hbot = -100.0d0
  integer :: itnumb(100,2) = 0

  logical :: fllowgwl = .false.
  real(8) :: k(numnod) = 1.0d0, dimoca(numnod) = 0.0d0
  integer :: numbit = 0
  logical :: fldecdt = .false.
  real(8) :: gwl = -2.0d0
end module variables

module MOD_MvG
  implicit none
contains
  real(8) function watcon(node, head)
    integer, intent(in) :: node
    real(8), intent(in) :: head
    if (node < 1 .or. head > huge(head)) error stop 'invalid watcon arguments'
    watcon = 0.30d0
  end function watcon

  real(8) function hconduc(node, head, water_content, frost_factor)
    integer, intent(in) :: node
    real(8), intent(in) :: head, water_content, frost_factor
    if (node < 1 .or. head > huge(head) .or. water_content < -huge(water_content) .or. frost_factor < 0.0d0) &
      error stop 'invalid hconduc arguments'
    hconduc = 1.0d0
  end function hconduc

  real(8) function moiscap(node, head)
    integer, intent(in) :: node
    real(8), intent(in) :: head
    if (node < 1 .or. head > huge(head)) error stop 'invalid moiscap arguments'
    moiscap = 0.0d0
  end function moiscap

  real(8) function dhconduc(node, head, water_content, capacity, frost_factor)
    integer, intent(in) :: node
    real(8), intent(in) :: head, water_content, capacity, frost_factor
    if (node < 1 .or. head > huge(head) .or. water_content < -huge(water_content) .or. &
        capacity < -huge(capacity) .or. frost_factor < 0.0d0) error stop 'invalid dhconduc arguments'
    dhconduc = 0.0d0
  end function dhconduc

  real(8) function cofgen(mode, node)
    integer, intent(in) :: mode, node
    if (mode < 0 .or. node < 1) error stop 'invalid cofgen arguments'
    cofgen = 0.30d0
  end function cofgen
end module MOD_MvG

module MOD_top
  implicit none
  real(8) :: q0 = 0.0d0
  logical :: flrunoff = .false., ftoph = .false.
  real(8) :: hsurf = 0.0d0
contains
  subroutine boundtop(task)
    use variables, only: qtop
    integer, intent(in) :: task
    if (task < 0) error stop 'invalid boundtop task'
    ftoph = .false.
    qtop = -1.0d0
  end subroutine boundtop
  subroutine pondrunoff()
  end subroutine pondrunoff
end module MOD_top

module MOD_meteo
  implicit none
  real(8) :: nraidt = 0.0d0
end module MOD_meteo

module MOD_macropore
  implicit none
contains
  subroutine macropore(task)
    integer, intent(in) :: task
    if (task < 0) error stop 'invalid macropore task'
  end subroutine macropore
end module MOD_macropore

module MOD_rootextraction
  implicit none
contains
  subroutine RootExtraction(task)
    integer, intent(in) :: task
    if (task < 0) error stop 'invalid root extraction task'
  end subroutine RootExtraction
end module MOD_rootextraction

module MOD_snow
  implicit none
  real(8) :: melt = 0.0d0
end module MOD_snow

module MOD_frost
  use MOD_grid, only: numnod
  implicit none
  real(8) :: rfcp(numnod) = 1.0d0
end module MOD_frost

module MOD_drain
  use MOD_grid, only: numnod
  implicit none
  integer, parameter :: nrlevs = 1
  real(8) :: qdra(nrlevs,numnod) = 0.0d0
end module MOD_drain

module MOD_irrigation
  use MOD_grid, only: numnod
  implicit none
  real(8) :: qssdi(numnod) = 0.0d0
  real(8) :: nird = 0.0d0
end module MOD_irrigation

module MOD_swap_mp
  use MOD_grid, only: numnod
  implicit none
  real(8) :: armpss = 0.0d0
  real(8) :: frarmtrx(numnod) = 1.0d0
  real(8) :: qexcmpmtx(numnod) = 0.0d0
  real(8) :: dfdhmp(numnod) = 0.0d0
  integer :: ictopmp = 2
  real(8) :: qmplatss = 0.0d0
  integer :: idecmprat = 0
  logical :: fldecmprat = .false., fldecMPmbf = .false.
end module MOD_swap_mp

real(8) function hcomean(method, kup, klow, dzup, dzlow, node, hup, hlow)
  implicit none
  integer, intent(in) :: method, node
  real(8), intent(in) :: kup, klow, dzup, dzlow, hup, hlow
  real(8) :: a1, a2
  if (method < 1 .or. method > 6 .or. node < 0 .or. dzup <= 0.0d0 .or. dzlow <= 0.0d0 .or. &
      hup > huge(hup) .or. hlow > huge(hlow)) error stop 'invalid hcomean arguments'
  select case (method)
  case (1)
    hcomean = 0.5d0*(kup+klow)
  case (2)
    hcomean = (dzup*kup + dzlow*klow)/(dzup+dzlow)
  case (3)
    hcomean = sqrt(kup*klow)
  case (4)
    a1 = dzup/(dzup+dzlow)
    a2 = 1.0d0-a1
    hcomean = kup**a1 * klow**a2
  case (5)
    hcomean = 1.0d0/(0.5d0/kup + 0.5d0/klow)
  case (6)
    a1 = dzup/(dzup+dzlow)
    a2 = 1.0d0-a1
    hcomean = 1.0d0/(a1/kup + a2/klow)
  end select
end function hcomean

subroutine tridag(n, upper, main, lower, rhs, solution, ierror)
  ! Test-only reference control. Operation order follows SWAP 4.3.1 tridag.f90.
  implicit none
  integer, intent(in) :: n
  real(8), intent(in) :: upper(*), main(*), lower(*), rhs(*)
  real(8), intent(out) :: solution(*)
  integer, intent(out) :: ierror
  real(8), parameter :: small = 0.3d-37
  real(8) :: gam(n), bet
  integer :: i

  if (n <= 0 .or. upper(1) > huge(upper(1)) .or. main(1) > huge(main(1)) .or. &
      lower(1) > huge(lower(1)) .or. rhs(1) > huge(rhs(1))) error stop 'invalid tridag arguments'
  ierror = 0
  if (abs(main(1)) < small) then
    ierror = 1000
    return
  end if
  bet = main(1)
  solution(1) = rhs(1) / bet
  do i = 2, n
    gam(i) = lower(i-1) / bet
    bet = main(i) - upper(i) * gam(i)
    if (abs(bet) < small) then
      ierror = 1000 + i
      return
    end if
    solution(i) = (rhs(i) - upper(i) * solution(i-1)) / bet
  end do
  do i = n-1, 1, -1
    solution(i) = solution(i) - gam(i+1) * solution(i+1)
  end do
end subroutine tridag

subroutine bandec(a, n, m1, m2, np, mp, al, mpl, indx, d)
  implicit none
  integer, intent(in) :: n, m1, m2, np, mp, mpl
  real(8), intent(inout) :: a(*), al(*)
  integer, intent(out) :: indx(*)
  real(8), intent(out) :: d
  integer :: i
  if (m1 < 0 .or. m2 < 0 .or. np < n .or. mp < 1 .or. mpl < 1 .or. a(1) > huge(a(1)) .or. al(1) > huge(al(1))) &
    error stop 'invalid bandec arguments'
  do i = 1, n
    indx(i) = i
  end do
  d = 1.0d0
end subroutine bandec

subroutine banbks(a, n, m1, m2, np, mp, al, mpl, indx, b)
  implicit none
  integer, intent(in) :: n, m1, m2, np, mp, mpl, indx(*)
  real(8), intent(in) :: a(*), al(*)
  real(8), intent(inout) :: b(*)
  if (n <= 0 .or. m1 < 0 .or. m2 < 0 .or. np < n .or. mp < 1 .or. mpl < 1 .or. &
      indx(1) < 1 .or. a(1) > huge(a(1)) .or. al(1) > huge(al(1)) .or. b(1) > huge(b(1))) &
    error stop 'invalid banbks arguments'
end subroutine banbks

real(8) function afgen(table, n, x)
  implicit none
  integer, intent(in) :: n
  real(8), intent(in) :: table(*), x
  if (n <= 0 .or. table(1) > huge(table(1)) .or. x > huge(x)) error stop 'invalid afgen arguments'
  afgen = 0.0d0
end function afgen

subroutine dtdpst(mode, time, text)
  implicit none
  character(len=*), intent(in) :: mode
  real(8), intent(in) :: time
  character(len=*), intent(out) :: text
  if (len(mode) <= 0 .or. time > huge(time)) error stop 'invalid dtdpst arguments'
  text = 'fixture-time'
end subroutine dtdpst

subroutine swap_warning(origin, message)
  implicit none
  character(len=*), intent(in) :: origin, message
  if (len(origin) + len(message) < 0) error stop 'unreachable'
end subroutine swap_warning

subroutine swap_error(origin, message)
  implicit none
  character(len=*), intent(in) :: origin, message
  write(*,'(A,1X,A)') trim(origin), trim(message)
  error stop 'unexpected swap_error in F-SI04 fixture'
end subroutine swap_error
