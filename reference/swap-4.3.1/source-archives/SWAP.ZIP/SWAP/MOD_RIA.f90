! PROGRAM WCKplot generates tables for the volumetric water content according to the RIA parameterization and the
! unsaturated soil hydraulic conductivity for a given set of parameters and matric potentials (h) according to the junction model
! of de Rooij (2024b, in prep.). The code generates tables of the resulting soil water retention curve (SWRC), its derivative,
! and the unsaturated hydraulic conductivity curve (UHCC).
!
! DISCLAIMER
! The source code, executables, and all other files come without any warranty, including any implied warranty of merchantability
! or fitness for a particular purpose. Neither the author nor the Helmholtz Zentrum f�r Umweltforschung � UFZ, GmbH can be held
! liable for any consequence from the use of the codes and/or files or any modifications thereof.
!
! Version 1.0, June 2025(Gerrit de Rooij)
!
!*** Minor changes: July, 2025 by Marius Heinen (WENR)
!***  - removed unused statements
!***  - removed illegal characetrs and TABs
!***  - Initialization of SortedOrder () in SUBROUTINE Inserter
!***  - replaced program WCKplot by MODULE MOD_RIA 
!***  - removed redundant continuation characters at start of continued line
!*** Major changes: July, 2025 by Marius Heinen
!***  - Changes so that system will work for multiple soil layers: 
!***     - allocatable variables in module SHPvariables (and added the iLayer-dimension to all corresponding variables throughout the code)
!***     - subroutine allocate_SHPvariables
!***     - soil layer indicators: iLayer (= soil layer under consideration), nLayer (= total number of soil layers)
!***  - Added TTutil reading routine RIA_Reader (for later use in SWAP)
!***  - In SUBROUTINE SingleKcomponents the last two arguments are made optional (Kliq_out, Kvap_out)
!***  - Return saturated values when h > h_air_entry in WCRIA, SingleKcomponents, RIAderivative
!
! Jirka and Marius:
! Apparently, what consititutes double precision changes over time and may depend on compilers and/or processors. I therefore
! explicitly defined it in the Module below. Feel free to replace it by what you are using. I read Marius' paper about the 
! importance of suing high-precision numbers, so please do not make the standard too lax.
 MODULE DoublePrec
! This module defines the precision of Kind DP. 
   IMPLICIT None
   INTEGER, PARAMETER :: DP = SELECTED_REAL_KIND(20, 300)  
 END MODULE DoublePrec
!
! Jirka and Marius:
! In other codes, I had some difficulty arising from round-off errors and the like, so I now use this module in all my codes
! to specify the numbers the code frequently needs in calculations with an insane number of significant digits. I customize it
! for each code. It worked so far.
 MODULE Numbers 
! This module stores several numbers that appear in the calculations in high precision.
   USE DoublePrec
   IMPLICIT None
   REAL (KIND = DP), PARAMETER :: zero = 0.00000000000000000000_DP, one = 1.00000000000000000000_DP,                                      &
                                  two = 2.00000000000000000000_DP, three = 3.00000000000000000000_DP, ten = 10.00000000000000000000_DP,   &
                                  twenty = 20.00000000000000000000_DP, hundred = 100.0000000000000000000_DP
 END MODULE Numbers
!
! The following module stores various data structures.
 MODULE Types
   USE DoublePrec
   IMPLICIT NONE
! Jirka and Marius: You may or may not need Type PlottingData. Your decision.
   TYPE PlottingData 
!  Data structure to store points on the conductivity and retention curves that can be used to plot graphs.
     REAL (KIND = DP), DIMENSION(:), ALLOCATABLE :: h, pF, WC, Capacity, K, Kliq, Kcap, Kad, Kvap
!    These arrays store the matric potential (h) and the corresponding values of 
!    - pF: the pF (= 10log(-h))
!    - WC: the volumetric liquid water content
!    - Capacity: the derivative d WC / d h of the soil water retention curve
!    - K: the unsaturated hydraulic conductivity (liquid plus vapor)
!    - Kliq: the unsaturated hydraulic conductivity of liquid water
!    - Kcap: the unsaturated hydraulic conductivity of capillary water
!    - Kad: the unsaturated hydraulic conductivity of adsorbed water
!    - Kvap: the equivalent unsaturated hydraulic conductivity of water vapor
   END TYPE PlottingData
!
   TYPE KvapVariables 
!  Data structure to store derived variables of the soil water vapor conductivity.
     REAL (KIND = DP) :: WaterDensity, T, SaturatedVaporDensity, Diffusivity
!    - WaterDensity: the density of liquid water at the specified temperature
!    - T: the temperature in Kelvin
!    - SaturatedVaporDensity: the density of saturated water vapor at the specified temperature
!    - Diffusivity: the diffusivity of water vapor at the specified temperature
   END TYPE KvapVariables
   save
 END MODULE Types
!
! The next module stores parameters that govern the Bisection algorithm.
 MODULE BisParameters
   USE DoublePrec
   USE Numbers, ONLY: one, two
   IMPLICIT None
   INTEGER, Parameter :: MaxBisectionIterations = 100
!  MaxBisectionIterations: maximum number of iterations allowed for the Bisection algorithm to find a root to an equation.
   REAL (KIND = DP), Parameter :: AbsBisectionTolerance = 0.000000100_DP, RelBisectionTolerance = 0.000100000_DP,          &
                                  FirstLowerLimit = one, FirstUpperLimit = two
!  AbsBisectionTolerance, RelBisectionTolerance: absolute and relative tolerance criterion, respectively, to evaluate if the
!    Bisection algorithm converted to a solution. See Subroutine BisectionForC for details.
!  FirstLowerLimit: the initial lower limit used by the Bisection algorithm. See Subroutine BisectionForC for details.
!    Its value is the mathematical minimum for the particular equation for which the root is sought.
!  FirstUpperLimit: the initial upper limit used by the Bisection algorithm. See Subroutine BisectionForC for details.
 END MODULE BisParameters
!
 MODULE ParameterInformation
!  This module stores the identifier of the case at hand, a hard-coded error value and a correction factor that ensures hj
!  is not exactly at its theoretical limit.
   USE DoublePrec
   IMPLICIT None
   CHARACTER (LEN = 120), save :: CaseLabel
!  CaseLabel: user-provided character string that is used to identify the case for which SHP tables are generated.
   REAL (KIND = DP), PARAMETER :: ErrorVal = 9999.00000000000000000000_DP, hjCorrectionFactor = 0.99999000000000000000_DP
!  ErrorVal: value that indicates an error.
!  hjCorrectionFactor: the absolute value of hj calculated by FUNCTION hjRIA needs to be slightly smaller than that given by 
!    Eq. (4) of de Rooij (2022), which this number ensures.
 END MODULE ParameterInformation
!
! The following module stores parameter values that are used to calculate the vapor conductivity (Peters, 2013; de Rooij,
! 2024c, in prep.). It also stores the resulting temperature-dependent variables.
! Jirka and Marius: you may want to adapt Default temperature to your own climate, or make it an input variable. This is only
! relevant if you include vapor conductivity in the overll conductivity function (instead of letting your own model
! for vapor conductivity figure it out) AND if you do not solve the heat equation. In the latter case, you pass on the
! temperature to Module KVapor and to subroutine SingleKcomponents as an argument in the call.
 MODULE KVapor
   USE DoublePrec
   USE Types, ONLY: KvapVariables
   USE Numbers, ONLY: zero
   IMPLICIT NONE
   LOGICAL :: VaporCond 
!  VaporCond: .TRUE. if the bulk soil hydraulic conductivity should include the vapor conductivity, .FALSE. otherwise.
   REAL (KIND = DP) :: Temp ! The default or the given temperature in degrees Celcius. See below for the default value.  
   REAL (KIND = DP), PARAMETER :: M_H2O = 0.01801528000000000000_DP, R = 8.31446261815324000000_DP,                                                         &
                                  g = 9.81000000000000000000_DP, RefDiffusivity = 20908.800000000000000_DP, DiffusivityRefTemp = 288.15000000000000000_DP,  &
                                  DiffusivityExp = 1.7500000000000000000_DP,                                                                                &
                                  DensC1 = 999.85050000000000000000_DP, DensC2 = 0.06001000000000000000_DP, DensC3 = 0.00791700000000000000_DP,             &
                                  DensC4 = 0.00004125600000000000_DP,                                                                                       &
                                  VaporC1 = 0.00100000000000000000_DP, VaporC2 = 31.37160000000000000000_DP, VaporC3 = 6014.79000000000000000000_DP,        &
                                  VaporC4 = 0.00792495000000000000_DP,                                                                                      &
                                  AbsTemp = -273.15000000000000000000_DP, DefaultTemperature = 12.0000000000000000000_DP, LowTemp = zero,                   &
                                  HighTemp = 40.00000000000000000000_DP
!  M_H2O: the molar mass of water in kg mol^-1
!  R: the universal gas constant in kg m^2 s^-2 Kelvin^-1 Mol^-1
!  g: the gravitational acceleration in m s^-2 
!  RefDiffusivity: the leading constant in Eq. 5d of de Rooij (in prep.) in cm^2 d^-1
!  DiffusivityRefTemp: the temperature at which the reference diffusivity in Eq. 5d was determined (15 deg Celcius)
!  DiffusivityExp: the exponent in Eq. 5d of de Rooij (in prep.)
!  Dens1 - Dens4: the constants in Brutsaert's (2005, p. 17) expression for the water density between temperatures of 0 and 40
!    degrees Celcius
!  VaporC1 - VaporC4: the constants in Eq. A5 of Peters (2013) for the density of saturated water vapor
!  AbsTemp: zero Kelvin in degrees Celcius
!  DefaultTemperature: the temperature in degrees Celcius if none is given on input.
!  LowTemp, HighTemp: Brutsaert's (2005, p.17) approximation of the density of liquid water is valid between these temperatures
!    in degrees Celcius.
   TYPE(KvapVariables) :: KvapV
!  KvapV: This data structure stores temperature-dependent variables that govern water vapor diffusion: WaterDensity, T (in
!    Kelvin), SaturatedVaporDensity, and Diffusivity
   save
 END MODULE KVapor
!
 MODULE SmallestValues 
! This module stores the smallest value domain conductivities can have before they are considered negigible.
! This prevents a string of * to be written to output instead of a readable number.
   USE DoublePrec 
   IMPLICIT NONE
   REAL (KIND = DP), PARAMETER :: Kmin = 1.0E-20_DP
!  Kmin: the smallest conductivity (cm per day) not considered equal to zero. 
 END MODULE SmallestValues
!
 MODULE SHPvariables
! This module stores the parameters of the RIA expression for the soil water retention curve (SWRC) and the junction model for the
! unsaturated soil hydraulic conductivity curve (UHCC). The module also stores several variables that appear in the expressions of
! the SWRC and UHCC that do not depend on the matric potential.
! See de Rooij (2024b, in prep.) and routine SingleK for details.
   USE DoublePrec 
   IMPLICIT NONE
   integer :: iLayer, nLayer
   LOGICAL, dimension(:), allocatable :: hdFitted
   LOGICAL :: HeatOn
!  hdFitted: .TRUE. if the value of the matric potential at oven-dryness given on input is the fitted value (that needs to be 
!            multiplied by (1+c) to arrive at the corrected value at which the water content becomes zero).
!            .FALSE. if the corrected value of the matric potential at oven-dryness is given on input.
!  HeatOn: .TRUE. if the heat equation is solved, .FALSE. if the temperature is constant in space and time.
   REAL (KIND = DP), PARAMETER :: mu = -1.50000000000000000000_DP, SpecificStorage = 1.0E-8_DP
!  mu: the value of the exponent of the power law that gives the water film hydraulic conductivity
!  SpecificStorage: the derivative of the saturated section of the SWRC, where the elasiticity of the solid phase allows for 
!    minute changes in water content (Kruseman and de Ridder, 1990, p. 22-23)
!  Marius: perhaps change the value of Specific Storage to the value you are using to avoid a zero derivative of the SWRC.
   REAL (KIND = DP), dimension(:), allocatable :: JU1, JU2, JU3, JU4
!  JU2 - JU3: components of the conductivity curve of JUN and JUV, only dependent on retention curve parameters
!  JU1 and JU4: components of the conductivity curve of JUN  and JUV, dependent on retention and conductivity curve parameters
   REAL (KIND = DP), dimension(:), allocatable :: SWRCalpha, SWRCbeta, SWRChj, SWRCcorrectionFactor, SWRCGhae, SWRCGhj, SWRCExpo, hdTarget
!  Derived variables of the SWRC. They are derived from the parameter values in SWRCpars.
!  - SWRCalpha: alpha 
!  - SWRCbeta: beta
!  - SWRChj: the matric potential at the junction point
!  - SWRCcorrectionFactor: the correction factor (1 + c) to convert hd_fitted to hd_target: hd_target = (1+c)*hd_fitted
!  - SWRCGhae: vGfactor(hae)
!  - SWRCGhj: vGfactor(hj) 
!  - SWRCExpo: n - 1
!  - hdTarget: corrected matric potential at oven-dryness, where the water content reaches zero
   REAL (KIND = DP), dimension(:), allocatable :: UHCCalpha, UHCCbeta, UHCChj, UHCCGhae, UHCCGhj, UHCCExpo
!  Derived variables of the UHCC. They are derived from the parameter values in UHCCpars.
!  - similar to SWRCxxx above, but calculated from different parameter values. Note that the UHCC must use the matric potential
!    at oven-dryness and the associated correction factor of the SWRC.
   REAL (KIND = DP), dimension(:,:), allocatable :: SWRCpars
!  Array with the parameters of the SWRC of the modeled soil, in the following order:
!  - saturated water content
!  - air-entry value (cm H2O)
!  - matric potential at oven-dryness (the fitted value, which needs to be multimplied by (1 + c) to give the value at which the
!    water content reaches zero). See de Rooij (2022, 2024c). (cm H2O)
!  - alpha (1/cm)
!  - n
   REAL (KIND = DP), dimension(:,:), allocatable :: UHCCpars
!  Array with the parameters of the UHCC of the modeled soil, in the following order:
!  - air-entry value (cm H2O)
!  - alpha (1/cm)
!  - n
!  - the saturated hydraulic conductivity (cm/d)
!  - gamma
!  - tau
   save
   contains
   
   subroutine allocate_SHPvariables()
   implicit none
   if (nLayer == 0) stop 'ERROR (allocate_SHPvariables) - nLayer should be initialized > 0'
   ! hdFitted
   if (allocated(hdFitted))             deallocate(hdFitted);             allocate(hdFitted(1:nLayer))
   ! JU1, JU2, JU3, JU4
   if (allocated(JU1))                  deallocate(JU1);                  allocate(JU1(1:nLayer))
   if (allocated(JU2))                  deallocate(JU2);                  allocate(JU2(1:nLayer))
   if (allocated(JU3))                  deallocate(JU3);                  allocate(JU3(1:nLayer))
   if (allocated(JU4))                  deallocate(JU4);                  allocate(JU4(1:nLayer))
   ! SWRCalpha, SWRCbeta, SWRChj, SWRCcorrectionFactor, SWRCGhae, SWRCGhj, SWRCExpo, hdTarget
   if (allocated(SWRCalpha))            deallocate(SWRCalpha);            allocate(SWRCalpha(1:nLayer))
   if (allocated(SWRCbeta))             deallocate(SWRCbeta);             allocate(SWRCbeta(1:nLayer))
   if (allocated(SWRChj))               deallocate(SWRChj);               allocate(SWRChj(1:nLayer))
   if (allocated(SWRCcorrectionFactor)) deallocate(SWRCcorrectionFactor); allocate(SWRCcorrectionFactor(1:nLayer))
   if (allocated(SWRCGhae))             deallocate(SWRCGhae);             allocate(SWRCGhae(1:nLayer))
   if (allocated(SWRCGhj))              deallocate(SWRCGhj);              allocate(SWRCGhj(1:nLayer))
   if (allocated(SWRCExpo))             deallocate(SWRCExpo);             allocate(SWRCExpo(1:nLayer))
   if (allocated(hdTarget))             deallocate(hdTarget);             allocate(hdTarget(1:nLayer))
   ! UHCCalpha, UHCCbeta, UHCChj, UHCCGhae, UHCCGhj, UHCCExpo
   if (allocated(UHCCalpha))            deallocate(UHCCalpha);            allocate(UHCCalpha(1:nLayer))
   if (allocated(UHCCbeta))             deallocate(UHCCbeta);             allocate(UHCCbeta(1:nLayer))
   if (allocated(UHCChj))               deallocate(UHCChj);               allocate(UHCChj(1:nLayer))
   if (allocated(UHCCGhae))             deallocate(UHCCGhae);             allocate(UHCCGhae(1:nLayer))
   if (allocated(UHCCGhj))              deallocate(UHCCGhj);              allocate(UHCCGhj(1:nLayer))
   if (allocated(UHCCExpo))             deallocate(UHCCExpo);             allocate(UHCCExpo(1:nLayer))
   ! SWRCpars, UHCCpars
   if (allocated(SWRCpars))             deallocate(SWRCpars);             allocate(SWRCpars(1:nLayer,1:5))
   if (allocated(UHCCpars))             deallocate(UHCCpars);             allocate(UHCCpars(1:nLayer,1:6))
   end subroutine allocate_SHPvariables
END MODULE SHPvariables
!
module MOD_RIA
! MOD_RIA produces tables of the soil water retention curve (SWRC), its derivative, and the unsaurated soil hydraulic conductivity
! curve (UHCC). The SWRC is described by the RIA parameterization (de Rooij, 2022, 2024a) and the UHCC by the junction model of
! de Rooij (2024b, in prep.). Based on parameter values specified on input, the code determines a set of matric potentials that
! cover the entire range between saturation and oven-dryness. For each of these, the volumetric water content, water capacity,
! and the hydraulic conductivity (for liquid water, water vapor, and the sum of both) are comnputed and written to an output file.
!
! The code contains the following subroutines:
!   SUBROUTINE BisectionForC
!   SUBROUTINE Inserter (only needed in SUBROUTINE TableGenerator)
!   SUBROUTINE RIAjunctionDerivedPars
!   SUBROUTINE SingleKcomponents
!   SUBROUTINE Sorter (only needed in SUBROUTINE Inserter)
!   SUBROUTINE TempDependentTerms
!   SUBROUTINE TableGenerator (only needed to create output)
!   SUBROUTINE Validn
!   SUBROUTINE WCKplotReader 
!   FUNCTION A  
!   FUNCTION betaRIA
!   FUNCTION BisectionFunction 
!   FUNCTION CondVap  
!   FUNCTION CplusOne
!   FUNCTION hjRIA   
!   FUNCTION JU1calc  
!   FUNCTION JU4calc  
!   FUNCTION RIAderivative  
!   FUNCTION vGfactor
!   FUNCTION WCRIA 
!
! Jirka and Marius: of these subroutines and functions, the routines Inserter, Sorter, and TableGenerator are not required in
! Richards' solvers.
!
! References:
!
! Brutsaert, W. 2005. Hydrology. An introduction. Cambridge university Press, Cambridge, UK.
!
! de Rooij, G.H. 2022. Technical note: A sigmoidal soil water retention curve without asymptote that is robust when dry�range
! data are unreliable. Hydrology and Earth System Sciences 26:5849�5858. doi:10.5194/hess-26-5849-2022. https://doi.org/10.5194/hess-26-5849-2022
!
! de Rooij, G. 2024a. Fitting the parameters of the RIA parameterizaton of the soil water retention curve (2.0), Zenodo [code],
! doi: 10.5281/zenodo.14047942. https://zenodo.org/records/13972199
!
! de Rooij, G. 2024b. Fitting the junction model and other models for the unsaturated soil hydraulic conductivity curve, Zenodo [code],
! doi: 10.5281/zenodo.14051087. https://zenodo.org/records/15857834
!
! de Rooij, G.H. 2024c. Averaging or adding domain conductivities to calculate the unsaturated soil hydraulic conductivity.
! Vadose Zone Journal 2024;e20329. doi:10.1002/vzj2.20329. https://doi.org/10.1002/vzj2.20329
!
! de Rooij, G.H. (2025) Fitting the junction model and other parameterizations for the unsaturated soil hydraulic conductivity
! curve: KRIAfitter version 1.0. EGUsphere. doi:10.5194/egusphere-2024-3487. https://doi.org/10.5194/egusphere-2024-3487
!
! de Rooij, G.H., J. Mai, and R. Madi. 2021. Sigmoidal water retention function with improved behavior in dry and wet soils.
! Hydrology and Earth System Sciences 25:983�1007. doi:10.5194/hess-25-983-2021. https://doi.org/10.5194/hess-25-983-2021
!
! Kruseman, G.P., and de Rider, N.A. 1990. Analysis and evaluation of pumping test data, 2nd edition. Publication 47,
! International Institute for Land Reclamation and Improvement, Wageningen, The Netherlands.
!
! van Genuchten, M.Th. 1980. A closed-form equation for predicting the hydraulic conductivity of unsaturated soils.  
! Soil Science Society of America J. 44:892-898. https://doi.org/10.2136/sssaj1980.03615995004400050002x
!
! Subroutine headings may have additional references.
!
! Gerrit H. de Rooij, July 2025.  
!
 CONTAINS

 SUBROUTINE BisectionForC(hae, hdTarget, alpha, n, cPlusOne)
! BisectionForC finds the root cPlusOne of a function, using the iterative bisection algorithm according to Burden and
! Faires (1989, p. 33). The function implemented here can have at most two roots, of which the smallest is of interest.
! The routine first determines the maximum possible value of CplusOne for the smallest root based on two criteria that are
! derived in the User Manual. The routine then finds a range of the x-coordinate in which the root lies, starting from
! prescribed lower and upper limits for the first interval. The lower limit of the first interval is at the theoretical limit
! of the specific equation needed by RIAfitter, so the search only considers intervals with increasing values of x. Once the
! interval with the root is found, the Bisection algorithm is applied to that interval. 
! If the root is not in the permitted range, or if convergence is not achieved with the maximum allowed number of iterations,
! cPlusOne is set to the error value.
! If convergence is not achieved with the maximum allowed number of iterations, a message is written to the output file.
!
! This routine is partially specific for RIAfitter.
!
! Reference
! Burden, R.L., and J.D. Faires. 1989. Numerical Analysis. Fourth edition. PWS-Kent Publishing Company, Boston, U.S.A. 729 pp.
!
! Interface:
! Input
!
! Input argument list:
! hae, alpha, n, hdTarget: SWRC parameters hae, alpha, n, and the corrected hd according to de Rooij (2022). All but hae are
!    passed on to function BiSectionFunction.
!
! Input from modules
! Module BisParameters:
! - MaxBisectionIterations: the maximum number of iterations allowed for finding a solution to the equation.
! - AbsBisectionTolerance: an absolute tolerance criterion to establish if the bisection algorithm converged to a solution.
! - RelBisectionTolerance: a relative tolerance criterion to establish if the bisection algorithm converged to a solution.
! - FirstLowerLimit: the lower limit for the Bisection algorithm at its first iteration.
! - FirstUpperLimit: the upper limit for the Bisection algorithm at its first iteration.
! Module Numbers provides several numbers in high precision.
! The error value is obtained from module ParameterInformation
!
! Output
! 
! Output argument list:
! cPlusOne: the correction factor (1 + c) according to Eq. (11) of de Rooij (2022)
! 
! Output to file:
! If the root was not found, a message is written to the output file designated by the main program.
!
! Gerrit de Rooij, February 2023, modified April 2023 and August 2024. Modified for Richards' solvers: June 2025
!
 USE DoublePrec
 USE Numbers, ONLY: zero, one, two
 USE ParameterInformation, ONLY: ErrorVal
 USE BisParameters
 IMPLICIT None
!
 REAL (Kind = DP), Intent(In) :: hae, hdTarget, alpha, n
 REAL (Kind = DP), Intent(Out) :: cPlusOne
 LOGICAL :: ValidC, LowerLimitChanged ! LowerLimitChanged ensures that yLow is only calculated when its value changed.
 INTEGER :: I ! Loop counter
 REAL (Kind = DP) :: LowerLimit, UpperLimit, Xmax, x, y, yLow
! LowerLimit, UpperLimit: the lower and upper limits of the independent variable in the iterative process
! x: intermediate approximation to the solution of the equation 
! y: value of the equation for successive intermediate approximations to the solution (should converge to zero)
! yLow: the value of the equation when x is at the lower limit
!
! Initialize the necessary variables.
 LowerLimit = FirstLowerLimit
 UpperLimit = FirstUpperLimit
! Find the maximum permissible value of x and store it it Xmax. See the User Manual for the derivation. Temporarily storage in x.
! The next lines (including the first two parts of the IF construct BiSect) are specific to RIAfitter.
 x = (A(alpha, n, hdTarget) / n)**(1 / n) ! This is the point where ln(x) and (x**n)/A have the same slope.
 Xmax = ABS(hdTarget / hae) * EXP(one / (one - n)) ! This is the maximum value of x for which ABS(hj) > ABS(hae).
! By ensuring that x cannot exceed the point where ln(x) and (x**n)/A have the same slope, it is guaranteed that the
! root will be the smaller of the two roots that exist. See the User Manual for details.
 IF (x < Xmax) Xmax = x
 BiSect: IF (ABS(BisectionFunction(alpha, n, hdTarget, Xmax)) < AbsBisectionTolerance) THEN 
!  The root is at the end of the range, no iterations needed.
   ValidC = .TRUE.
   CplusOne = Xmax
 ELSE IF (BisectionFunction(alpha, n, hdTarget, LowerLimit) * BisectionFunction(alpha, n, hdTarget, Xmax) > zero) THEN BiSect
!  There is no root in the permissible range of x. No iterations needed.
   ValidC = .FALSE.
!   WRITE (22, '("The root for the equation that BisectionForC should solve is outside the permitted range of x.")')
!   WRITE (22, '("The inputs are: alpha =  ",ES14.6,". n = ",ES14.6,". hae = ",ES14.6,". hdTarget = ",ES14.6,".")') alpha, n, hae, hdTarget
 ELSE BiSect
   ValidC = .FALSE.
!  Start with the lowest upper limit. If the upper limit is smaller than the root of the equation, double the upper limit,
!  except if the upper limit is too small for the first iteration. Each time, increase the lower limit to equal the upper
!  limit of the previous attempt. The second iteration may be exempt to this.
   RangeFinder: DO
!    Check if the root lies within the current interval. If not, increase the limits. 
!    N.B. This works only if FirstLowerLimit is the theoretical minimum value of the x-coordinate and if the function has
!    only one root. The code above ensures that the interval between FirstLowerLimit and Xmax has one root.
     yLow = BisectionFunction(alpha, n, hdTarget, LowerLimit)
     IF (yLow * BisectionFunction(alpha, n, hdTarget, UpperLimit) > zero) THEN 
!      The root is not in this range. Move to the adjacent section of larger x.
       LowerLimit = UpperLimit
       IF (UpperLimit < two) THEN
         UpperLimit = two
       ELSE   
         UpperLimit = two * LowerLimit 
       END IF
       IF (UpperLimit > Xmax) THEN ! This If construct is specific to RIAfitter.
         UpperLimit = Xmax ! The root is in the final interval.
         EXIT RangeFinder
       END IF
     ELSE ! The root is in this interval. 
       EXIT RangeFinder
     END IF
   END DO RangeFinder
!  The range with the root has been identified. Start the bisection algorithm.
   ValidC = .FALSE.
   Bisection: DO I = 1, MaxBisectionIterations
!    For the first cycle through the loop, the last value of yLow calculated in the loop RangeFinder is valid. 
!    No need to calculate it again.
     IF (I == 1) LowerLimitChanged = .FALSE. 
     x = LowerLimit + (UpperLimit - LowerLimit) / two
     y = BisectionFunction(alpha, n, hdTarget, x)
!    Check for convergence.
     IF (ABS(y) <= AbsBisectionTolerance .OR. ((UpperLimit - LowerLimit) / LowerLimit) <= RelBisectionTolerance) THEN
!      Convergence achieved. Prepare output and leave the DO-loop.
       ValidC = .TRUE.
       cPlusOne = x
       EXIT Bisection
     END IF
     IF (LowerLimitChanged) yLow = BisectionFunction(alpha, n, hdTarget, LowerLimit)
     IF (y * yLow > zero) THEN ! The solution lies between x and UpperLimit.
       LowerLimit = x
       LowerLimitChanged = .TRUE.
     ELSE ! The solution lies between LowerLimit and x.
       UpperLimit = x
       LowerLimitChanged = .FALSE.
     END IF
   END DO Bisection
   IF (.NOT. ValidC) THEN
     WRITE (22, '("No convergence achieved by subroutine BisectionForC for the following inputs:   &
              & alpha =  ",ES14.6,". n = ", ES14.6,". hae = ",ES14.6,". hd = ",ES14.6,".")') alpha, n, hae, hdTarget
   END IF
 END IF BiSect
! If there is no solution, set cPlusOne to the error value.
 IF (.NOT. ValidC) THEN
   cPlusOne = ErrorVal
 END IF
 END SUBROUTINE BisectionForC
! 
 SUBROUTINE Inserter(Host, Guest, Overlap)
! Inserter inserts indivdual values from array Guest (unsorted) into array Host, which is sorted in increasing order. The
! insertions are done in a way that ensures that the updated array remains sorted. If a value in array Guest exactly
! matches a value in array Host, it will be inserted if input parameter Overlap = .TRUE., and be ignored if Overlap = .FALSE.
!
! Interface:
!
! Input
!
! Input from the argument list:
! - Host: array (REAL, DP) with values sorted in increasing order
! - Guest: array (REAL, DP) with unsorted values that need to be inserted in array Host in a way that maintains the sorting order
! - Overlap: .TRUE. if a value in Guest that equals a value in Host needs to be inserted in Host, 
!            .FALSE. if this value should be ignored.
!
! Output
!
! Output to the argument list:
! - The updated value of Host is returned to the calling program unit.
!
! Gerrit de Rooij, May 2025
!
 USE DoublePrec
 IMPLICIT NONE
!
 LOGICAL, Intent(In) :: Overlap
 REAL (KIND = DP), Allocatable, Dimension (:), Intent(InOut) :: Host
 REAL (KIND = DP), Dimension(:), Intent(In) :: Guest
 INTEGER :: SizeHost, SizeGuest, NrOfLargeGuests, NrOfSmallGuests, I, J
 INTEGER, Allocatable, Dimension(:) :: SortedOrder
 REAL (KIND = DP), Allocatable, Dimension(:) :: Guest2, Spare
!
 SizeHost = SIZE(Host)
 SizeGuest = SIZE(Guest)
! Sort a copy of Guest in ascending order. Note that routine Sorter sorts in descending order.
 Allocate (Guest2(1:SizeGuest))
 Allocate (SortedOrder(1:SizeGuest)); SortedOrder = 0
 Guest2 = -Guest
 CALL Sorter(Guest2, SortedOrder)
 DO I = 1, SizeGuest
   Guest2(I) = Guest(SortedOrder(I))
 END DO
 Deallocate (SortedOrder)
! Insert the values of Guest into Host. First find out how many Guests exceed the largest Host-element.
 NrOfLargeGuests = 0
 DO I = 1, SizeGuest
   IF (Guest2(I) > Host(SizeHost)) THEN
     NrOfLargeGuests = SizeGuest - I + 1
     EXIT
   END IF
 END DO
 IF (NrOfLargeGuests > 0) THEN
   Allocate (Spare(1:SizeHost))
   Spare = Host
   Deallocate (Host)
   Allocate (Host(1:SizeHost + NrOfLargeGuests))
   Host(1:SizeHost - NrOfLargeGuests) = Spare
   Deallocate (Spare)
   Host(SizeHost - NrOfLargeGuests + 1:SizeHost) = Guest2(SizeGuest - NrOfLargeGuests + 1:SizeGuest)
 END IF
! Find out how many Guests are smaller than the smallest Host-element.
 NrOfSmallGuests = 0
 DO I = SizeGuest, 1, -1
   IF (Guest2(I) < Host(1)) THEN
     NrOfSmallGuests = I
     EXIT
   END IF
 END DO
 IF (NrOfSmallGuests > 0) THEN
   Allocate (Spare(1:SizeHost))
   Spare = Host
   Deallocate (Host)
   Allocate (Host(1:SizeHost + NrOfSmallGuests))
   Host(NrOfSmallGuests + 1:SizeHost) = Spare
   Deallocate (Spare)
   Host(1:NrOfSmallGuests) = Guest2(1:NrOfSmallGuests)
 END IF
! Now insert the elements of Guest that lie within the extreme values of Host
 DO I = SizeGuest - NrOfLargeGuests, NrOfSmallGuests + 1, -1
   DO J = SizeHost, 2, -1 
!  Starting this loop from the updated end of the enlarged array every time is not the most efficient, but it ensures that
!  subsequent elements of Guest falling between the same elements of Host are correctly inserted.
     !IF (((Guest2(I) == HOST(J-1) .OR. Guest2(I) == Host(J)) .AND. Overlap) .OR. (Guest2(I) > Host(J-1) .AND. Guest2(I) < Host(J))) THEN ! Insert the value.
     IF (((.NOT.(ABS(Guest2(I) - HOST(J-1)) > 0.0D0) .OR. .NOT.(ABS(Guest2(I) - Host(J)) > 0.0D0)) .AND. Overlap) .OR. &
        (Guest2(I) > Host(J-1) .AND. Guest2(I) < Host(J))) THEN ! Insert the value.
       Allocate (Spare(1:SizeHost))
       Spare = Host
       Deallocate (Host)
       SizeHost = SizeHost + 1
       Allocate (Host(1:SizeHost))
       Host(1:J-1) = Spare(1:J-1)
       Host(J) = Guest2(I)
       Host(J+1:SizeHost) = Spare(J:SizeHost-1)
       Deallocate (Spare)
     END IF
   END DO
 END DO
 Deallocate (Guest2)
 END SUBROUTINE Inserter
! 
! Jirka and Marius: 
! The routine below calculates h-independent terms of the SWRC and UHCC, and therefore only needs to be run once.
 SUBROUTINE RIAjunctionDerivedPars
! RIAjunctionDerivedPars calculates derived parameters for the RIA SWRC and the junction model UHCC from the parameter values
! provided on input. The results are stored in Module SHPvariables. Only derived variables that are not dependent on the 
! temperature are calculated.
! 
! Interface:
!
! Input
!
! Input from modules:
! - everything stored in Module SHPvariables except mu and SpecificStorage
! - VaporCond (a logical that determines if the vapor conductivity needs to be calculated), Temp (the termperature in degrees
!   Celcius)), and the data structure KvapV are obtained form Module KVapor.
! - the number one in high precision is obtained from Module Numbers
!
! Output
!
! Output to module:
! - all derived parameters are stored in Module SHPvariables. This module explains the variables.
!
! Gerrit de Rooij, June 2025
! 
 use MOD_swap_base, only: unit_log
 USE Numbers,       ONLY: one
 USE SHPvariables,  ONLY: iLayer, hdFitted, HeatOn, JU1, JU2, JU3, JU4, SWRCalpha, SWRCbeta, SWRChj, SWRCcorrectionFactor, SWRCGhae,       &
                          SWRCGhj, SWRCExpo, hdTarget, UHCCalpha, UHCCbeta, UHCChj, UHCCGhae, UHCCGhj, UHCCExpo, SWRCpars, UHCCpars
 USE KVapor,        ONLY: VaporCond, Temp, KvapV
 IMPLICIT None
!
 SWRCcorrectionFactor(iLayer) = CplusOne(SWRCpars(iLayer,4), SWRCpars(iLayer,5), SWRCpars(iLayer,2), SWRCpars(iLayer,3), hdFitted(iLayer))
! Ensure that the fitted value of hd is passed on to the other program units.
 IF (.NOT. hdFitted(iLayer)) THEN ! The value of hd provided is the corrected one, where the water content reaches zero.
!  Set hdTarget to the corrected value given in SWRCpars(3).
   hdTarget(iLayer) = -ABS(SWRCpars(iLayer,3))
!  Determine the fitted value �of hd from the corrected value. Store this in SWRCpars(3).
   SWRCpars(iLayer,3) = hdTarget(iLayer) / SWRCcorrectionFactor(iLayer)
 ELSE
!  Calculate the corrected value of hd from the fitted value.
   hdTarget(iLayer) = -ABS(SWRCpars(iLayer,3)) * SWRCcorrectionFactor(iLayer)
 END IF
 WRITE(unit_log,'(/,"The fitted hd = ",F11.1,". The corrected value = ",F11.1,". The correction factor c = ",ES14.6,".")')       &
          SWRCpars(iLayer,3), hdTarget(iLayer), SWRCcorrectionFactor(iLayer) - one
! Verify that round-off errors in the input values do not result in physically impossible combinations of hj, hd, and n 
! (see Eq.(4) of de Rooij, 2022a).
 CALL Validn(SWRCpars(iLayer,3), SWRCpars(iLayer,5))
! Calculate the derived parameters
 SWRChj(iLayer) = hjRIA(SWRCpars(iLayer,3), SWRCpars(iLayer,5))
 UHCChj(iLayer) = hjRIA(SWRCpars(iLayer,3), UHCCpars(iLayer,3))
 SWRCalpha(iLayer) = SWRCpars(iLayer,4)
 UHCCalpha(iLayer) = UHCCpars(iLayer,2)
 SWRCbeta(iLayer) = betaRIA(SWRCpars(iLayer,2), SWRChj(iLayer), SWRCalpha(iLayer), SWRCpars(iLayer,5))
 UHCCbeta(iLayer) = betaRIA(UHCCpars(iLayer,1), UHCChj(iLayer), UHCCalpha(iLayer), UHCCpars(iLayer,3))
 SWRCGhae(iLayer) = vGfactor(SWRCpars(iLayer,2), SWRCalpha(iLayer), SWRCpars(iLayer,5))
 UHCCGhae(iLayer) = vGfactor(UHCCpars(iLayer,1), UHCCalpha(iLayer), UHCCpars(iLayer,3))
 SWRCGhj(iLayer) = vGfactor(SWRChj(iLayer), SWRCalpha(iLayer), SWRCpars(iLayer,5))
 UHCCGhj(iLayer) = vGfactor(UHCChj(iLayer), UHCCalpha(iLayer), UHCCpars(iLayer,3))
 SWRCExpo(iLayer) = SWRCpars(iLayer,5) - one
 UHCCExpo(iLayer) = UHCCpars(iLayer,3) - one
 WRITE(unit_log, '(/,"Junction point of the SWRC: ",ES14.6,". Junction point of the UHCC: ",ES14.6,".")') SWRChj(iLayer), UHCChj(iLayer)
! If the heat equation is not solved, calculate the temperature-dependent terms of the vapor conductivity model if needed.
 IF (VaporCond .AND. (.NOT. HeatOn)) CALL TempDependentTerms(Temp, KvapV%WaterDensity, KvapV%T, KvapV%SaturatedVaporDensity, KvapV%Diffusivity)
! Calculate h-independent terms of the conductivity curve that depend on fitting parameters.
 JU1(iLayer) = JU1calc(UHCCpars(iLayer,4), UHCCpars(iLayer,6), UHCCGhae(iLayer), UHCCGhj(iLayer))
 JU2(iLayer) = one - (((ABS(UHCCalpha(iLayer) * UHCChj(iLayer)))**UHCCExpo(iLayer)) * UHCCGhj(iLayer))
 JU3(iLayer) = one - (((ABS(UHCCalpha(iLayer) * UHCCpars(iLayer,1)))**UHCCExpo(iLayer)) * UHCCGhae(iLayer))
 JU4(iLayer) = JU4calc(JU1(iLayer), JU2(iLayer), JU3(iLayer), UHCCpars(iLayer,5))
 END SUBROUTINE RIAjunctionDerivedPars
!
! Jirka and Marius: I placed the temperature Temp in the argument list, although it is also stored on Module KVapor. But because it
! is a state variable like the matric potential (hIn), I find this more consistent. If you wish you cna remove it frm the argument
! list and skip the 'ONLY: etc.' in the USE KVapor statement below. That way, the routine will obtain Temp from the module.
! I use the temperature for the vapor conductivity only. I have not included the effect of temperaturee on the liquid-water
! conductivity, but am willing to do so if you would like me to.
 SUBROUTINE SingleKcomponents(hIn, Temp, K, Kliq_out, Kvap_out)
! SingleKcomponents calculates all constitutive conductivities and the resulting overall conductivity value based on given
! parameter values, a matric potential, and the inclusion or exclusion of the vapor conductivity. See de Rooij (2024b, in prep.)
! for details.
! 
! N.B. The code requires that the unit of length is cm, the unit of time is day, and the unit of temperature is degrees Celsius.
!
! Interface:
!
! Input
! 
! Input argument list:
! - hIn: the matric potential for which the hydraulic conductivity is sought
! - Temp: the temperature (deg Celcius) needed for the calculation of the vapor conductivity
!
! Input from Modules: 
! - Numbers in high precision are provided by Module Numbers.
! - The smallest permissible value of the hydraulic conductivity below which it is set to zero is given by Module SmallestValues.
! - The SWRC parameters (SWRCpars) and UHCC parameters (UHCCpars), derived parameters from both sets, and LOGICAL HeatOn are
!   provided by Module SHPvariables.
! - The LOGICAL VaporCond (determining wether or not the vapor conductivity is needed) is provided by Module KVapor.
! - The derived type KvapV (with temperature-dependent derived variables for the vapor conductivity is given by Module KVapor.
!
! Output
! 
! Output argument list:
! - K: the total hydraulic conductivity (liquid plus vapor if VaporCond = .TRUE.; liquid only if VaporCond = .FALSE.)
! - Kliq: the hydraulic conductivity of liquid water
! - Kvap: the equivalent hydraulic conductivity of water vapor                                                                                                                                                                            
! All output variables have units cm/d
!
! Gerrit de Rooij, October 2024. Modified: May 2025. Modified for Richards' solvers: June 2025
!
 USE DoublePrec
 USE SmallestValues, ONLY: Kmin
 USE Numbers, ONLY: zero, one
 USE SHPvariables, ONLY : iLayer, mu, UHCCGhae, UHCChj, UHCCExpo, hdTarget, JU3, JU4, SWRCpars, UHCCpars, HeatOn
 USE KVapor, ONLY: VaporCond, KvapV
 IMPLICIT NONE
! 
 REAL (KIND = DP), Intent(In) :: hIn, Temp
 REAL (KIND = DP), Intent(Out) :: K
 REAL (KIND = DP), Intent(Out), optional :: Kliq_out, Kvap_out
 REAL (KIND = DP) :: h, alpha, Ghae, vGh, gamma, tau, Kad, Kcap, Kliq, Kvap
! Ensure that the matric potential is negative.
 h = -ABS(hIn)
 gamma = UHCCpars(iLayer,5)
 tau = UHCCpars(iLayer,6)
! Use precalculated values of various derived variables.
 alpha = UHCCpars(iLayer,2)
 Ghae = UHCCGhae(iLayer)
! Calculate the conductivities of the capillary-bound (Kcap) and adsorbed (Kad) water for the various parameterizations.
 IF (hIn > UHCCpars(iLayer,1)) THEN
   Kad = zero
   Kcap = UHCCpars(iLayer,4)
 ELSE IF (h < -ABS(hdTarget(iLayer))) THEN ! The soil is oven-dry.
   Kad = zero
   Kcap = zero
 ELSE IF (h >= -ABS(UHCCpars(iLayer,1))) THEN ! The soil is saturated.
   Kcap = UHCCpars(iLayer,4)
   Kad = zero
 ELSE IF (h < -ABS(UHCChj(iLayer))) THEN ! The soil is in the dry, logarithmic branch.
  Kad = JU4(iLayer) * ((ABS(h / UHCChj(iLayer)))**mu)
  Kcap = zero
 ELSE ! The soil is in the intermediate and wet, sigmoidal branch.
   vGh = vGfactor(h, alpha, UHCCpars(iLayer,3))
   Kcap = one - (((ABS(alpha * h))**UHCCExpo(iLayer)) * vGh)
   Kcap = UHCCpars(iLayer,4) * ((vGh / Ghae)**tau) * ((Kcap / JU3(iLayer))**gamma)
   Kad = zero
 END IF
 IF (Kcap < Kmin) Kcap = zero
 IF (Kad < Kmin) Kad = zero
! Compute the bulk hydraulic conductivity of all liquid water.
 Kliq = Kcap + Kad ! One of these is zero.
 K = Kliq 
! Include the vapor conductivity if necessary. Initialize Kvap first.
 Kvap = zero
 IF (VaporCond) THEN
   IF (h < -ABS(SWRCpars(iLayer,2))) THEN
!    If the heat flow equation is solved, calculate temperature-dependent properties needed for vapor conductivity that are
!    independent of the matric potential.
     IF (HeatOn) CALL TempDependentTerms(Temp, KvapV%WaterDensity, KvapV%T, KvapV%SaturatedVaporDensity, KvapV%Diffusivity)
!    Calculate the vapor conductivity.
     Kvap = CondVap(h, SWRCpars(iLayer,1), WCRIA(h), KvapV%T, KvapV%WaterDensity, KvapV%SaturatedVaporDensity, KvapV%Diffusivity)
     K = Kliq + Kvap
   END IF
 END IF
 if (present(Kliq_out)) Kliq_out = Kliq
 if (present(Kvap_out)) Kvap_out = Kvap
 END SUBROUTINE SingleKcomponents
!
 pure SUBROUTINE Sorter(ArrayToBeSorted, SortedOrder)
! Sorter sorts a 1-dimensional array.
! The algorithm is based on Shell's method as described in Press, W.H., Teukolsky, S.A., Vetterling, W.T., and
! Flannery, B.P. 1996. Numerical Recipes in Fortran 90, 2nd edition, Cambridge University Press, Cambridge, UK (p. 1168), and in
! https://en.wikipedia.org/wiki/Shellsort
!
! Interface:
! 
! Input
!
! Argument list input:
! - ArrayToBeSorted: a one-dimensional array that needs to be sorted.
!
! Output
!
! Argument list output:
! (- SortedArray: the sorted version of the input array. N.B. Commented out.)
! - SortedOrder: an integer array whose elements list the original positions of the corresponding elements in SortedArray. This is
!   helpful if the sorted array was part of a multidimensional one that needs to be sorted according to the dimension passed on to
!   Sorter. 
!
! Gerrit H. de Rooij, January 2018. Updated June 2021.
!
 USE DoublePrec
 IMPLICIT None
 INTEGER :: L, M, N, NrOfElements, P, Q, Step, UpperBound, NewOrder
 INTEGER, Intent(Out), Dimension(:), Allocatable :: SortedOrder
 INTEGER, Dimension(:), Allocatable :: Order
 REAL (KIND = DP) :: New
 REAL (KIND = DP), Intent(In), Dimension (:) :: ArrayToBeSorted
! REAL (KIND = DP), Intent(Out), Dimension (:), Allocatable :: SortedArray
 REAL (KIND = DP), Dimension (:), Allocatable :: Increment, IncrementOld, Dummy
!
 UpperBound = SIZE(ArrayToBeSorted)
! Allocate (SortedArray(1:UpperBound))
 Allocate (SortedOrder(1:UpperBound))
! Start by finding the series of increments of data pairs that need to be sorted. The increment series is defined according to
! Tokuda's sequence (see the Wikipedia reference). 
 Allocate (Increment(1))
 Allocate (IncrementOld(1))
 L = 1
 Increment(1) = 1.00000000000000000000_DP
 DO
   L = L + 1
   IncrementOld = Increment
   Deallocate (Increment)
   Allocate (Increment(L))
   Increment(1: L - 1) = IncrementOld
   Increment(L) = (2.25000000000000000000_DP * Increment(L - 1)) + 1.00000000000000000000_DP
   IF (INT(Increment(L)) > UpperBound) THEN
     EXIT
   END IF
   Deallocate (IncrementOld)
   Allocate (IncrementOld(L))
 END DO
 Deallocate (IncrementOld)
! Start with the sort according to the largest increment and move down to increment 1.
 Sort: DO M = L - 1, 1, -1
!  The size of the increment is determined by Step. It decreases with every passage through the DO loop.          
   Step = INT(Increment(M))
!  Find the subarrays that need to be sorted for this increment and their sizes. The number of subarrays equals the step size. 
   DO N = 1, Step
!    N.B. The division in the next statement contains integers only, and the result will itself be an integer. As the number of
!    the starting element of the subarray increases, the subarray tends to become smaller, as fewer Steps fit in the remainder
!    of the array.
     NrOfElements = ((UpperBound - N) / Step) + 1
!    Prepare the array Dummy and the array with the original positions of the elements in Dummy, that both will be sorted.
     Allocate (Dummy(1:NrOfElements))
     Allocate (Order(1:NrOfElements))
     DO P = 0, NrOfElements - 1
        Dummy(P + 1) = ArrayToBeSorted(N + (P * Step))
        Order(P + 1) = N + (P * Step) ! This stores the original position of the element that will be sorted.
     END DO
!    Sort Dummy and pass on the sorted results to SortedOrder. The sorting algorithm is straight insertion (see Press, W.H.,
!    Teukolsky, S.A., Vetterling, W.T., and Flannery, B.P. 1992. Numerical Recipes in Fortran, 2nd edition, Cambridge 
!    University Press, Cambridge, UK (p.321). 
!    In the first step, the two left-most array elements are sorted. Then, the third is placed in the correct position with 
!    respect to these two, then the fourth with respect to the first three, and so on.
     DO P = 1, NrOfElements - 1
       New = Dummy(P + 1)
       NewOrder = Order(P + 1)
       DO Q = P, 1, -1
!        Run down the already sorted array elements from largest to smallest. Every time when New is smaller than an element,
!        this element is moved one position to the right. If an element is smaller than New, it is inserted in the slot 
!        immediately after that element.
         IF (New < Dummy(Q)) THEN
           Dummy(Q + 1) = Dummy(Q)
           Order(Q + 1) = Order(Q)
           IF (Q == 1) THEN ! New is smaller than all previously sorted elements. Place it in the first slot.
             Dummy(1) = New
             Order(1) = NewOrder
           END IF
         ELSE
           Dummy(Q + 1) = New
           Order(Q + 1) = NewOrder
           EXIT
         END IF
       END DO        
     END DO
     DO P = 0, NrOfElements - 1
!       SortedArray(N + (P * Step)) = Dummy(P + 1)
       SortedOrder(N + (P * Step)) = Order(P + 1)
     END DO
     Deallocate (Dummy)
     Deallocate (Order)
   END DO
 END DO Sort
 Deallocate (Increment)
 END SUBROUTINE Sorter
!
 SUBROUTINE TableGenerator
! TableGenerator produces up to 100 values of the matric potential. For the parameter values of the RIA parameterization of the
! SWRC and the junction model for the UHCC, it calculates the corresponding values of the pF, the volumetric water content, the
! derivative of the SWRC, the unsaturated hydraulic conductivity, as well as the hydraulic conductivity of the liquid water,
! and the equivalent vapor conductivity reflecting diffusive movement of water vapor in the soil gas phase.
! The results are written to a file for further processing by plotting software packages.
!
! Interface:
!
! Input
! 
! Input from Modules:
! - The derived type used to store the points on the various curves, and those of KvapV are obtained from Module Types.
! - Several (derived) variables pertaining to the SWRC and the UHCC are obtained from Module SHPvariables. 
! - The (derived) variables related to the vapor conductivity are obtained from Module KVapor
! - Several numbers in high precision are taken from Module Numbers.
!
! Output

! - The tables with graphing data are written to file SHPtable.OUT. 
! - Various warning and indicators of progress in the computational process are written to file WCKplotProgress.OUT.
!
! Gerrit de Rooij, May 2021. Modified: May 2022, October 2024, June 2025
!
 USE DoublePrec 
 USE ParameterInformation, ONLY: CaseLabel
 USE Numbers, ONLY: zero, one, ten, twenty
 USE SHPvariables, ONLY: iLayer, SWRCpars, UHCCpars, SWRChj, UHCChj, hdTarget, hdFitted, HeatOn
 USE KVapor, ONLY: Temp, VaporCond
 USE Types, ONLY: PlottingData
!
 IMPLICIT NONE
!
 INTEGER :: FreePlottingPoints, I, NrEntries
! FreePlottingPoints is the maximum number of points in the table, excluding the mandodatory points for the hae and hj values of
!   the SWRC and the UHCC.
! I and NrEntries are counters.
 REAL (KIND = DP) :: h, pF, pFInterval, NarrowInterval, OvenDry
! h: soil water suction (cmH2O)
! pF: Log10(h)
! NarrowInterval: the upper limit of the range of h for which plotting points will be calculated at 1 cm intervals of h.
!   The lower limit is AirEntryValue. NarrowInterval is hard-coded as AirEntryValue + 20. If the junction point is within in
!   this interval for RIA, NarrowInterval will be set to its value.
! pFInterval: the interval on the pF scale of two consecutive plotting points between NarrowInterval and OvenDry
!
! For the resulting points on the suction axis, corresponding values of the various hydraulic conductivities and the total water
! content are calculated.
!
! OvenDry: the matric potential at which the water content reaches zero.
! WCS: saturated volumetric water content
!
 REAL (KIND = DP), Dimension(1:4) :: MandatoryPoints 
! Array that stores the air-entry values and the junction points of the SWRC and UHCC.
 REAL (KIND = DP), Dimension(:), Allocatable :: Suction, Spare 
! These arrays grow one data point at a time to accomodate the number of data points. They store the suctions calculated so far
! and are updated for each additional plotting point.
 TYPE(PlottingData) :: hSHPs ! Stores the coordinates of all plotting points.
! Format of hSHPs: REAL (KIND = DP), DIMENSION(:), ALLOCATABLE :: h, pF, WC, Capacity, K, Kliq, Kcap, Kad, Kvap
!
 character(len=3) :: clayer
 character(len=80) :: fout
 FreePlottingPoints = 96 ! This limits the number of points to no more than 100.
! Open the main output file and write the file heading and the temperature.
 write(clayer,'(I3.3)') iLayer
 fout = 'SHPtable_'//clayer//'.OUT'
 OPEN(23, FILE = trim(fout), STATUS = 'REPLACE', ACTION = 'WRITE')
 WRITE(23, '(A,/)') CaseLabel
 WRITE(23, '("hdFitted: ",l1,".  HeatOn: ",l1,".  VaporCond: ",l1,".",/)') hdFitted(iLayer), HeatOn, VaporCond
 WRITE(23, '("Temperature (degrees Celcius): ",F5.1,/)') Temp
 WRITE(23, 200)
200 FORMAT('Tables of the RIA retention curve and the Junction Model conductivity curve',/,                                            &
           '          h       pF  WC-tot     Capacity        K-tot        K-liq        K-vap    --------Logarithms of--------',/,      &
           '     cm-H2O                          1/cm         cm/d         cm/d         cm/d      K-tot      K-liq      K-vap',/,      &
           '_________________________________________________________________________________________________________________')
!!!12345678901xx1234567xx123456xx12345678901xx12345678901xx12345678901xx12345678901xx123456789xx123456789xx123456789
! Determine the air-entry values and junction points to ensure they will be plotting points.
 MandatoryPoints(1) = MIN(ABS(SWRCpars(iLayer,2)), ABS(UHCCpars(iLayer,1)))
 MandatoryPoints(2) = MAX(ABS(SWRCpars(iLayer,2)), ABS(UHCCpars(iLayer,1)))
 MandatoryPoints(3) = MIN(ABS(SWRChj(iLayer)), ABS(UHCChj(iLayer)))
 MandatoryPoints(4) = MAX(ABS(SWRChj(iLayer)), ABS(UHCChj(iLayer)))
! In the next lines, pF is used as a dummy variable. It will be initialized later.
 IF (MandatoryPoints(3) < MandatoryPoints(2)) THEN
   pF = MandatoryPoints(3)
   MandatoryPoints(3) = MandatoryPoints(2)
   MandatoryPoints(2) = pF
   WRITE(21, '(/,"The smallest absolute value of hj is smaller than the largest absolute value of hae.")')
 END IF
 OvenDry = ABS(hdTarget(iLayer))
! Determine the intervals with 1 cm resolution and the equidistant delta pF resolution.
 NarrowInterval = MandatoryPoints(1) + twenty
 IF (NarrowInterval > MandatoryPoints(3)) NarrowInterval = MandatoryPoints(3)
 WRITE(21, 210) NarrowInterval, OvenDry, LOG10(OvenDry) 
210 FORMAT(/,'Absolute values of characteristic matric potentials.',/,                                            &
             'The narrow interval is the range of the tables in SHPtable.OUT with narrowly spaced points.',/,     &
             'End of narrow interval  Suction at oven-dryness  pF at oven-dryness',/,F22.1,2X,F23.1,2X,F18.5)
! Generate the data points. Store them in hSHPs. Start by generating the matric potentials and determining the size of
! the arrays.
 Allocate (Suction(1:2))
 Suction(1) = zero
 h = zero ! h and all expressions for specific matric potentials denote the suction (= ABS(matric potential)) in this routine.
 IF (MandatoryPoints(1) > zero) THEN 
   Suction(2) = MandatoryPoints(1)
!  Round down the air-entry value to the nearest cm to initiate the next batch of plotting points.
   h = AINT(Suction(2), DP)
   NrEntries = 2
 ELSE
   NrEntries = 1
 END IF 
 SmallIncrement: DO
   h = h + one
!  The following statement eliminates a possible (near-)duplicate point at the start of the interval.
   IF (ABS(h - Suction(NrEntries)) < 0.100_DP) h = h + one 
   Allocate (Spare(1:NrEntries))
   Spare = Suction(1:NrEntries)
   Deallocate (Suction)
   NrEntries = NrEntries + 1
   Allocate (Suction(1:NrEntries))
   Suction(1:NrEntries - 1) = Spare
   Deallocate (Spare)
   Suction(NrEntries) = h
   IF (h >= NarrowInterval) THEN
     IF (ABS(h - Suction(NrEntries)) >= 0.100_DP) THEN ! This avoids the repeated storage of the final suction.
       Allocate (Spare(1:NrEntries))
       Spare = Suction(1:NrEntries)
       Deallocate (Suction)
       NrEntries = NrEntries + 1
       Allocate (Suction(1:NrEntries))
       Suction(1:NrEntries - 1) = Spare
       Deallocate (Spare)
       Suction(NrEntries) = h
     END IF
     EXIT SmallIncrement
   END IF
 END DO SmallIncrement
! Continue with the logarithmic increment.
 pF = LOG10(h)
! Limit the total number of points to 100 or fewer.
 pFInterval = (LOG10(OvenDry) - pF) / REAL(FreePlottingPoints - NrEntries, DP)
 pFincrement: DO
   pF = pF + pFInterval
   h = ten**pF   
   IF (h > OvenDry) h = OvenDry ! This eliminates round-off error for the final entry.
   Allocate (Spare(1:NrEntries))
   Spare = Suction(1:NrEntries)
   Deallocate (Suction)
   NrEntries = NrEntries + 1
   Allocate (Suction(1:NrEntries))
   Suction(1:NrEntries - 1) = Spare
   Deallocate (Spare)
   Suction(NrEntries) = h
   ! Leave the loop if the air-dry value or the maximum number of permitted plotting points has been reached (should be the
   ! same without round-off error). 
   IF (h >= OvenDry .OR. NrEntries >= FreePlottingPoints) EXIT pFincrement
 END DO pFincrement
! Calculate the final value.
 pF = LOG10(OvenDry) + (one/ten)
 h = ten**(pF)
 Allocate (Spare(1:NrEntries))
 Spare = Suction(1:NrEntries)
 Deallocate (Suction)
 NrEntries = NrEntries + 1
 Allocate (Suction(1:NrEntries))
 Suction(1:NrEntries - 1) = Spare
 Deallocate (Spare)
 Suction(NrEntries) = h
! Insert all air entry values and junction points into array Suction.
 CALL Inserter(Suction, MandatoryPoints, .FALSE.)
!
! The points of array MandatoryPoints have been added to array Suction, so NrEntries no longer refects its true size.
 NrEntries = SIZE(Suction)
 WRITE(21, '(/,"The number of plotting points of the unsaturated hydraulic conductivity curve is ",I0,".")') NrEntries
 Allocate(hSHPs%h(1:NrEntries))
 Allocate(hSHPs%pF(1:NrEntries)) 
 Allocate(hSHPs%WC(1:NrEntries))
 Allocate(hSHPs%Capacity(1:NrEntries))
 Allocate(hSHPs%K(1:NrEntries))
 Allocate(hSHPs%Kliq(1:NrEntries))
 Allocate(hSHPs%Kvap(1:NrEntries))
!
 DO I = 1, NrEntries
   hSHPs%h(I) = -Suction(I)
   hSHPs%pF(I) = LOG10(Suction(I))
!  Use the independently fitted SWRC parameters to determine the water content, not the ones fitted for K(h).
!  Jirka and Marius: The next three lines show how you find the water content, the soil water capacity, and the total soil
!  hydraulic conductivity, the conductivity of liquid water, and the vapor conductivity. If input Boolean variable
!  CondVap = .TRUE., the vapopr conductivity is calculated and incorporated in the total conductivity. If CondVap = .FALSE., 
!  the vapor conductivity is set to zero, and the overall conductivity equals the liquid conductivity.
!  If you are not interested in the vapor conductivity at all, please let me know, so I can remove the corresponding code, and
!  can make SingleKcomponents a function instead of a subroutine. 
   hSHPs%WC(I) = WCRIA(-Suction(I)) ! This is the water content.
   hSHPs%Capacity(I) = RIAderivative(-Suction(I)) ! This is the slope d(theta) / d(h). N.B. h < 0, hence the slope is positive.
!  In the following line, hSHPs%K(I) is the overall condcutivity, ...%Kliq(I) the conductivity of liquid water, and ...%Kvap
!  the vapor conductivity.
   CALL SingleKcomponents(-Suction(I), Temp, hSHPs%K(I), hSHPs%Kliq(I), hSHPs%Kvap(I))
!  Ensure that negative pF-values are set to the dummy value -1.0, as they will normally not be plotted.
   IF (hSHPs%pF(I) < zero) hSHPs%pF(I) = -one
 END DO
 Deallocate (Suction)
! Write the graph points to output.
 WRITE(23, 220) hSHPs%h(1), hSHPs%WC(1), hSHPs%Capacity(1), hSHPs%K(1), hSHPs%Kliq(1), hSHPs%Kvap(1),                   &
                LOG10(hSHPs%K(1)), LOG10(hSHPs%Kliq(1)), LOG10(hSHPs%Kvap(1))
 DO I = 2, NrEntries
   WRITE(23, 230) hSHPs%h(I), hSHPs%pF(I), hSHPs%WC(I), hSHPs%Capacity(I), hSHPs%K(I), hSHPs%Kliq(I), hSHPs%Kvap(I),    &
                  LOG10(hSHPs%K(I)), LOG10(hSHPs%Kliq(I)), LOG10(hSHPs%Kvap(I))
 END DO
220 FORMAT(F11.1,2X,'-1.0000',2X,F6.4,4(2X,E11.4),3(2X,F9.5)) ! -1.0000 represents Log10(zero).
230 FORMAT(F11.1,1X,F8.5,2X,F6.4,4(2X,E11.4),3(2X,F9.5)) 
 Deallocate(hSHPs%h)
 Deallocate(hSHPs%pF) 
 Deallocate(hSHPs%WC)
 Deallocate(hSHPs%Capacity)
 Deallocate(hSHPs%K)
 Deallocate(hSHPs%Kliq)
 Deallocate(hSHPs%Kvap)
 CLOSE (23)
 END SUBROUTINE TableGenerator
!   
 SUBROUTINE TempDependentTerms(Temp, WaterDensity, AbsoluteTemp, SaturatedVaporDensity, VaporDiffusivity)
! TempDependentTerms computes temperature-dependent terms needed to calculate the vapor conductivity.
!
! Interface:
!
! Input
!
! Argument list input
! - Temp: the temperature in degrees Celcius
!
! Input from modules:
! - constants that appear in the relevant equations, and temperature limits that apply to one of the equations, are obtained from
!   Module KVapor 
!
! Output
!
! Argument list output:
! - WaterDensity: the density of liquid water (arbitrary units, as long as they are consistent with those of the density of
!   saturated water vapor)
! - AbsoluteTemp: the absolute temperature (Kelvin)
! - SaturatedVaporDensity: the density of saturated water vapor (arbitrary units, as long as they are consistent with those
!   of the density of liquid water)
! -VaporDiffusivity: the diffusivity of water vapor (cm^2 / d)
!
! Gerrit de Rooij, June 2025
 USE DoublePrec
 USE KVapor, ONLY: RefDiffusivity, DiffusivityRefTemp, DiffusivityExp, DensC1, DensC2, DensC3, DensC4, VaporC1, VaporC2,         &
                   VaporC3, VaporC4, AbsTemp, LowTemp, HighTemp
 IMPLICIT None
!
 REAL (KIND = DP), Intent(In) :: Temp
 REAL (KIND = DP), Intent(Out) :: WaterDensity, AbsoluteTemp, SaturatedVaporDensity, VaporDiffusivity
!
! The approximation of Brutsaert (2005, p. 17) for the density of liquid water is valiud between 0 and 40 degrees Celcius.
 IF (Temp < LowTemp) THEN 
   WaterDensity = DensC1 + (DensC2 * LowTemp) - (DensC3 * (LowTemp**2)) + (DensC4 * (LowTemp**3))
 ELSE IF (Temp > HighTemp) THEN
   WaterDensity = DensC1 + (DensC2 * HighTemp) - (DensC3 * (HighTemp**2)) + (DensC4 * (HighTemp**3))
 ELSE ! The temperature is in the range for which Brusaert's (2005, p. 17) approximation is valid.
   WaterDensity = DensC1 + (DensC2 * Temp) - (DensC3 * (Temp**2)) + (DensC4 * (Temp**3))
 END IF
 AbsoluteTemp = Temp - AbsTemp
 SaturatedVaporDensity = VaporC1 * (EXP(VaporC2 - (VaporC3 / AbsoluteTemp) - (VaporC4 * AbsoluteTemp))) / AbsoluteTemp
 VaporDiffusivity = RefDiffusivity * ((AbsoluteTemp / DiffusivityRefTemp)**DiffusivityExp)
 END SUBROUTINE TempDependentTerms
!
 SUBROUTINE Validn(hd, n)
! Validn checks if the values of the matric potential at the junction point and at oven-dryness, in combination with the value of n
! are physically acceptable according to the criterion of Eq. (4) of de Rooij (2022). If not, the value of n is modified to ensure
! compliance. The value of the matric potential at junction point is calculated from that at oven dryness and n.
!
! Interface:
!
! Input
!
! Argument list input:
! - hd: the matric potential at oven-dryness (N.B. the uncorrected value should be provided)
! - n: the value of parameter n
!
! Input from Modules:
! - the number one is obtained from Module Numbers in high precision
! - the correction factor hjCorrectionFactor is obtained from Module ParameterInformation
! 
! Output
!
! Argument list output:
! - n: the corrected value of n is returned to the calling program unit
!
! Output to file:
! - If n is corrected, its old and new value are written to an output file designated by the main program.
!
! Gerrit de Rooij, August 2022. Modified: August, 2024.
!
 USE DoublePrec
 USE Numbers, ONLY: one
 USE ParameterInformation, ONLY: hjCorrectionFactor
!
 IMPLICIT NONE
 REAL (KIND = DP), Intent(In) :: hd
 REAL (KIND = DP), Intent(InOut) :: n
 REAL (KIND = DP) :: hj, OldValue
!
 hj = hjRIA(hd, n)
 IF (ABS(hj / hd) >= EXP(one / (one - n))) THEN
!  Modify the value of n to ensure the criterion of Eq. (4) is satisfied.
   OldValue = n
   n = one + (one / LOG(ABS(hd / hj))) ! This reflects the limit in Eq. (4).
   n = n / hjCorrectionFactor ! n has to be larger than its value at the limit.
   WRITE (21, '(/,"Parameter n was changed from ",ES15.7," to ",ES15.7," to satisfy Eq. (4) of de Rooij (2022).")') OldValue, n
 END IF
 END SUBROUTINE Validn
!
! Jirka and Marius:
! SWAP, and Hydrus in forward mode:
! hdFit needs to be .TRUE. if the user gives the fitted value of the matric potential at oven-dryness on input. In that case,
! the fitted value is stored in SWRCpars(3) and denoted hd in the comments.  The code will calculate the corresponding value of
! the correction factor c, and compute the matric potential at which the water content becomes zero as (1+c) * hd, and store this
! value (called 'corrected value' in the comments) in hdTarget. 
! If the user specifies the corrected value on input, hdFit needs to be set to .FALSE. The code then stores the input value in
! hdTarget, and calculates values of hd and c that ensure that (1+c) * hd = hdTarget. This internally calculated value of hd is
! then stored in SWRCpars(3) so the rest of the code works with the fitted value.
!
! Jirka:
! If Hydrus is run in inverse mode, hdFit can be set to .TRUE. if hd is to be fitted. If hd is fixed, it is most probable that 
! the user intends to fix the corrected value (1+c) * hd, i.e., hdTarget. In that case, hdFit should be set to .FALSE. In each
! iteration, routine RIAjunctionDerivedPars then gives SWRCpars(3) (which stores hd) and c values that ensure that
! (1+c) * SWRCpars(3) = hdTarget.
 SUBROUTINE WCKplotReader(InputOK)
! WCKplotReader reads all parameter values of the SWRC and the UHCC, and stores the data in two arrays that are stored in a module.
! If provided in the input file, the temperature is read and stored in a module. Three Boolean variables are alsoe read and
! stored in modules.
!
! Interface:
!
! Input
!
! Input from files:
!
! Input file WCKplot.IN 
! - SWRCpars: an array with the RIA parameters in the following order:
!   - saturated volumetric water content
!   - air-entry value (cm H2O)
!   - matric potential at oven-dryness (cm H2O) (fitted or corrected value)
!   - shape parameter alpha (1/cm H2O)
!   - shape parameter n
! - hdFitted: 'T' if the specified matric potential at oven-dryness is the fitted value, which needs to be multiplied by (1+c)
!             'F' if the matric potential at oven-dryness is the corrected value, at which the water content equals zero
! - HeatOn: 'T' if the temperature varies in space and time, i.e., when the heat eqaution is solved.
!           'F' if the temperature is constant in space and time.
!
! - UHCCpars: an array with the fitting parameters of the junction model in the following order:
!   - air-entry value (cm H2O)
!   - shape parameter alpha (1/cm H2O)
!   - shape parameter n
!   - saturated hydraulic conductivity of capillary water (cm/day)
!   - gamma
!   - tau
! - VaporCond: 'T' if the vapor conductivity should be computed and included in the bulk soil hydraulic conductivity
!              'F' if the vapor conductivity is not desired, and should be set to zero at any matric potential
!
! - Temperature (optional): this temperature is used to compute the vapor conductivity. If it is not specified, the default
!   temperature is used.
!
! The file has the following format:
! Line 1: descriptive label, no more than 120 characters (including spaces)
! Line 2: will not be read (can be used for labels)
! Line 3: The five parameter values, separated by commas or spaces, of the soil water retention curve. After this,
!         a logical (T or F)
!   The parameters (five REALs followed by a LOGICAL) must be specified in the following order:
!   - saturated volumetric water content
!   - air-entry value
!   - matric potential at oven-dryness (fitted or corrected value)
!   - shape parameter alpha
!   - shape parameter n
!   - hdFitted
!   - HeatOn
! Line 4: will not be read (can be used for labels)
! Line 5: The six parameter values, separated by commas or spaces, of the unsaturated soil hydraulic conductivity curve. After
!         this, a logical (T or F)
!   The parameters must be specified in the following order:
!   - air-entry value
!   - shape parameter alpha
!   - shape parameter n
!   - saturated hydraulic conductivity
!   - gamma
!   - tau
!   - VaporCond
! Line 6: will not be read (can be used for labels)
! Line 7: The temperature for which the vapor conductivity is computed
!
! Line 6 and 7 are optional. If they are missing, the hard-coded default temperature will be used.
!
! Input from modules:
! - The error value is obtained from Module ParameterInformation
!
! Output
!
! Output argument list:
! - InputOK: false if an error was detected and the execution needs to be terminated.
! 
! Output to modules:
! - arrays SWRCpars and UHCCpars, and LOGICAL hdFitted are written to module SHPvariables
! - the desired temperature (if provided) and LOGICAL VaporCond are written to module KVapor
! - The case identifier is written to Module ParameterInformation
!
! Output to files
! - The case label and warnings about problems with the input are written to the output file that reports on the execution.
! - The case label and the temperature are written to the main output file.
! 
! Gerrit de Rooij, June 2025.
!
   USE ParameterInformation, ONLY: CaseLabel, ErrorVal
   USE SHPvariables, ONLY: iLayer, SWRCpars, UHCCpars, hdFitted, HeatOn
   USE KVapor, ONLY: Temp, DefaultTemperature, VaporCond
   IMPLICIT NONE
!
   LOGICAL, Intent(Out) :: InputOK
   INTEGER :: I
!
   InputOK = .TRUE.
   ! Read the parameter values.
   OPEN (22, FILE = 'WCKplot.IN', STATUS = 'OLD', ACTION = 'READ')
   SWRCpars(iLayer,1:5) = ErrorVal
   UHCCpars(iLayer,1:6) = ErrorVal
   READ (22, '(A)') CaseLabel
   WRITE(21, '(A)') CaseLabel
   READ (22, *)
   ! Read the RIA parameters for the SWRC, and the logical variable that indicates the nature of the value of the input value of hd
   ! (fitted or corrected) 
   READ (22, *, ERR = 210) (SWRCpars(iLayer,I), I = 1, 5), hdFitted(iLayer), HeatOn
   GO TO 211
210 InputOK = .FALSE.
   WRITE (21, '(/,"The SWRC parameters could not be read. Execution aborted.")')
   ! Ensure all matric potentials have the correct sign.
211 SWRCpars(iLayer,2) = -ABS(SWRCpars(iLayer,2))
   SWRCpars(iLayer,3) = -ABS(SWRCpars(iLayer,3))
   READ (22, *)
   READ (22, *, ERR = 220) (UHCCpars(iLayer,I), I = 1, 6), VaporCond ! The parameters for the UHCC.
   GO TO 221
220 InputOK = .FALSE.
   WRITE (21, '(/,"The UHCC parameters could not be read. Execution aborted.")')
   ! Ensure that the matric potential has the correct sign.
221 UHCCpars(iLayer,1) = -ABS(UHCCpars(iLayer,1))
   Temp = DefaultTemperature
   READ (22, *, END = 230)
   READ (22, *, END = 230) Temp
230 CLOSE (22)
END SUBROUTINE WCKplotReader
 
SUBROUTINE RIA_Reader()
!  See header of subroutine WCKplotReader
   use DoublePrec,            ONLY: DP
   USE Numbers,               ONLY: one
   USE ParameterInformation,  ONLY: CaseLabel, ErrorVal
   USE SHPvariables,          ONLY: allocate_SHPvariables, nLayer, iLayer, SWRCpars, UHCCpars, hdFitted, HeatOn
   USE KVapor,                ONLY: Temp, DefaultTemperature, VaporCond
   implicit none
   ! global
   ! local
   real(8), dimension(:), allocatable  :: dum
   logical                             :: rdinqr
!
   ! input file is already opened by calling routine
   call rdscha('case',      CaseLabel) 
   call rdslog('HeatOn',    HeatOn)
   call rdslog('VaporCond', VaporCond)
   
   ! detemine number of soil layers from length of input records
   call rdinne('RIA_SWRC_wcsat', nLayer)

   ! allocate SHP variables
   call allocate_SHPvariables()
   SWRCpars = ErrorVal
   UHCCpars = ErrorVal
   
   allocate(dum(1:nLayer))
   ! RIA_SWRC_wcsat, RIA_SWRC_hae, RIA_SWRC_hod, RIA_SWRC_alpha, RIA_SWRC_n, RIA_hdfitted
   call rdfdor('RIA_SWRC_wcsat',  0.0d0,   1.0d0, dum, nLayer, nLayer); SWRCpars(1:nLayer,1) = mytransfer(nLayer, dum)
   call rdfdor('RIA_SWRC_hae',   -1.0d3,   0.0d0, dum, nLayer, nLayer); SWRCpars(1:nLayer,2) = mytransfer(nLayer, dum)
   call rdfdor('RIA_SWRC_hod',   -1.0d8,  -1.0d4, dum, nLayer, nLayer); SWRCpars(1:nLayer,3) = mytransfer(nLayer, dum)
   call rdfdor('RIA_SWRC_alpha',  0.0d0,   1.0d1, dum, nLayer, nLayer); SWRCpars(1:nLayer,4) = mytransfer(nLayer, dum)
   call rdfdor('RIA_SWRC_n',      1.05d0,  1.0d2, dum, nLayer, nLayer); SWRCpars(1:nLayer,5) = mytransfer(nLayer, dum)
   call rdflog('RIA_hdfitted', hdfitted, nLayer, nLayer)

   ! RIA_UHCC_hae, RIA_UHCC_alpha, RIA_UHCC_n, RIA_UHCC_ksat, RIA_UHCC_gamma, RIA_UHCC_tau
   call rdfdor('RIA_UHCC_hae',   -1.0d3,   0.0d0, dum, nLayer, nLayer); UHCCpars(1:nLayer,1) = mytransfer(nLayer, dum)
   call rdfdor('RIA_UHCC_alpha',  0.0d0,   1.0d1, dum, nLayer, nLayer); UHCCpars(1:nLayer,2) = mytransfer(nLayer, dum)
   call rdfdor('RIA_UHCC_n',      1.05d0,  1.0d2, dum, nLayer, nLayer); UHCCpars(1:nLayer,3) = mytransfer(nLayer, dum)
   call rdfdor('RIA_UHCC_ksat',   0.0d0,   1.0d4, dum, nLayer, nLayer); UHCCpars(1:nLayer,4) = mytransfer(nLayer, dum)
   call rdfdor('RIA_UHCC_gamma',  0.0d0,   1.0d1, dum, nLayer, nLayer); UHCCpars(1:nLayer,5) = mytransfer(nLayer, dum)
   call rdfdor('RIA_UHCC_tau',    0.0d0,   1.0d2, dum, nLayer, nLayer); UHCCpars(1:nLayer,6) = mytransfer(nLayer, dum)
      
   Temp = DefaultTemperature
   if (rdinqr('Temp')) then
      call rdsdou('Temp', dum(1))
      Temp = dum(1) * one
   end if
      
   ! Some additional derived parameters
   do iLayer = 1, nLayer
      CALL RIAjunctionDerivedPars()
   end do
   
   deallocate(dum)
   
contains

   function mytransfer(n, vals) result(res)
   implicit none
   integer,                intent(in)  :: n
   real(8),  dimension(n), intent(in)  :: vals
   real(dp), dimension(n)              :: res
   integer(8), dimension(n)            :: long
   integer(8), parameter               :: mult = 100000000000_8
   long = int(vals * mult, kind = 8)
   res = (long * one)/(mult * one)
   end function mytransfer
   
END SUBROUTINE RIA_Reader
!
 pure FUNCTION A(alpha, n, hd)
! Function A calculates the term denoted A in the expression for the correction c that needs to be applied to the fitted hd to
! ensure continuity of the soil water retention curve (de Rooij, 2024a, Eq. (10) of hte User Manual).
!
! Interface:
!
! Input
!
! Input argument list:
! - alpha: shape factor alpha (1/L, arbitrary unit of length)
! - n: shape factor n
! - hd: the value of the matric potential (L, arbitrary unit of length) at which the water content reaches zero
!   For the implicit version of the equation for c, this is the target hd (where the water content reaches zero)
!   For the explicit version of the equation, this is the fitted hd, with ABS(hd-fitted) < ABS(hd-target)
!
! Input from modules:
! - the number one is obtained from module Numbers
!
! Output:
!
! - the value of A is returned as the function value
!
! G.H. de Rooij, August 2024
!
 USE DoublePrec
 USE Numbers, ONLY: one
 IMPLICIT None
!
 REAL (KIND = DP), Intent(In) :: alpha, n, hd
 REAL (KIND = DP) :: A
!
 A = one - n
 A = -A * ((alpha * ABS(hd) * EXP(one / A))**n) 
 END FUNCTION A
!
 pure FUNCTION betaRIA(hae, hj, alpha, n)
!
! Function betaRIA calculates the term beta for the RIA parameterization (see WCRIA).
!
! Interface: 
!
! Input
!
! Argument list input:
! - hae: the air-entry value
! - hj: the matric potential at the junction point
! - alpha: shape factor
! - n: shape factor
!
! Output
!
! - beta is returned as the function value.
!
! Gerrit de Rooij, May 2016, modified May 2021
!
 USE DoublePrec
 USE Numbers, ONLY: one, two
 IMPLICIT None
!
 REAL (KIND = DP) :: betaRIA
 REAL (KIND = DP), Intent(In) :: hae, hj, alpha, n
!
 betaRIA = (ABS(alpha * hj))**(n)
 betaRIA = betaRIA * ((one + betaRIA)**((one / n) - two))
 betaRIA = (n - one) * betaRIA / vGfactor(hae, alpha, n) ! Eq. (2) in de Rooij (2022)
 END FUNCTION betaRIA
!
 pure FUNCTION BisectionFunction(alpha, n, hdTarget, x)
! BisectionFunction calculates the function the root of of which subroutine BisectionForC needs to find.
! It is ln(x) � x**n/A, with A a constant depending on the input parameters.

! 
! Interface:
!
! Input
!
! Argument list input:
! - alpha: shape factor alpha (1/L, arbitrary unit of length)
! - n: shape factor n
! - hdTarget: the value of the matric potential at oven-dryness (L, arbitrary unit of length) that needs to be approximated by
!   the fitted value multiplied by a correction factor that is also fitted.
! - x: the coordinate value for which the function value is sought.
!
! Output
!
! - The requested value is returned as the function value.
!
! Gerrit de Rooij, August 2024
!
 USE DoublePrec
 IMPLICIT None
!
 REAL (KIND = DP), Intent(In) :: alpha, n, hdTarget, x
 REAl (KIND = DP) :: BisectionFunction
!
 BisectionFunction = LOG(x) - ((x**n) / A(alpha, n, hdTarget)) 
! See the User Manual of RIAfitter for details of the equation above (de Rooij, 2024a).
 END FUNCTION BisectionFunction
!
 pure FUNCTION CondVap(h_in_cm, Porosity, WaterContent, T, WaterDensity, SaturatedVaporDensity, Diffusivity)
! Function CondVap calculates the equivalent hydraulic conductivity caused by vapor flow according to Peters (2013). 
!
! Interface: 
!
! Input
!
! Input argument list:
! - h_in_cm: the matric potential or the suction (the code can handle either). Unit: cm H2O
! - Porosity: the porosity of the soil
! - WaterContent: the actual water content
! - T: the temperature (Kelvin)
! - WaterDensity: the water density for T
! - SaturatedVaporDensity: the density of saturated water vapor for T (both densities in kg m**-3)
! - Diffusivity: the diffusivity of water vapor in air for T (cm**2 per day)
!
! Input from Modules:
! - Module KVapor supplies various physical constants, coefficients and other factors.
! - Kmin from Module SmallestValues is the largest conductivity that is not set to zero.
! - Module Numbers provides several numbers in high precision.
!
! Output
!
! - The value of the equivalent vapor conductivity (cm per day) is returned through the function (CondVap).
!
! N.B. The following units are assumed. mass: kg; length: m; temperature: degrees Celcius; Time: second.
!      The diffusivity in air (Diffusivity in the argument list) is given in cm**2 per day.
!      At the end, conductivity is converted to cm per day.
!
! Gerrit de Rooij, June 2016. Modified May 2021 and July 2022
!
 USE DoublePrec
 USE Numbers, ONLY: zero, two, three, ten, hundred
 USE KVapor, ONLY: M_H2O, g, R
 USE SmallestValues, ONLY: Kmin
 IMPLICIT NONE
!
 REAL (KIND = DP), INTENT(IN) :: h_in_cm, Porosity, WaterContent, T, WaterDensity, SaturatedVaporDensity, Diffusivity
 REAL (KIND = DP) :: CondVap, RelativeHumidity
!
! Calculate the relative humidity of the soil air.
 RelativeHumidity = EXP(-M_H2O * g * ABS(h_in_cm / hundred) / (R * T)) ! h_in_cm is converted from cm to m H2O.
! Find the effective diffusion coefficient of water vapor.
 IF (Porosity > WaterContent) THEN
   CondVap = Diffusivity * ((Porosity - WaterContent)**(ten / three)) / (Porosity**two)
!  Calculate the vapor conductivity in meters per day.
   CondVap = SaturatedVaporDensity * CondVap * M_H2O * g * RelativeHumidity / (R * T * WaterDensity)
!  Convert to cm per day. The group Mg/RT has units 1/m, so its value is 100 times too large for the target unit cm.
   CondVap = Condvap / hundred
   IF (CondVap < Kmin) CondVap = zero
 ELSE
   CondVap = zero
 END IF
 END FUNCTION CondVap
!
 FUNCTION CplusOne(alpha, n, hae, hdIn, hdFitted)
! CplusOne calculates the correction factor (1 + c) with which the fitted hd must be multiplied to arrive at the desired value of
! hd (called hdTarget elsewhere in the code). hdTarget is the matric potential at oven-dryness in cm H2O.
! If hfFit is .TRUE., the factor (1 + c) can be calculated directly. If hdFit is .FALSE., the underlying equation is implicit 
! in (1 + c) and needs to be solved by iteration.
! If the parameter values are outside the domain for which a value of c can exist, CplusOne returns the error value.
!
! Interface:
! 
! Input
! 
! Argument list input:
! - alpha: shape parameter alpha (1/L; arbitrary unit of length)
! - n: shape parameter n
! - hdIn: if hdFit = .TRUE.: the matric potential (L; arbitrary unit of length) that was fitted, and will give the matric
!         potential at which the water content reaches zero only after multiplication by cPlusOne
!         if hdFit = .FALSE.: the matric potential at which the water content reaches zero (called hdTarget elsewhere in the code)
! - hdFitted: .TRUE. if the value of hdIn is a fitted value (not the value at which the water content reaches zero)
!             .FALSE. if the value of hdIn is the value (either corrected or fixed) at which the water content reaches zero.
!
! Input from modules:
! - the number one in high precision is obtained from module Numbers
! - the error value is obtained from module ParameterInformation
!
! Output:
! The value of the factor (1 + c) is returned as the function value.
!
! Gerrit de Rooij, August 2024
!
 USE DoublePrec
 USE Numbers, ONLY: one
 USE ParameterInformation, ONLY: ErrorVal
 IMPLICIT None
!
 LOGICAL, Intent(In) :: hdFitted
 REAL (KIND = DP), Intent(In) :: alpha, n, hae, hdIn
 REAL (KIND = DP) :: FactorA, CplusOne
!
! The value of hd supplied on input is the fitted or the target value. In the former case, (1+c) has an explicit equation.
 FactorA = A(alpha, n, hdIn)
 IF (hdFitted) THEN 
   CplusOne = EXP(one / FactorA) ! This is the solution of the explicit equation.
 ELSE ! The value of hd supplied on input is the target value. (1+c) has an implicit equation.
   IF (FactorA < n * EXP(one)) THEN 
!    The equation for c does not have a solution.
     CplusOne = ErrorVal
   ELSE 
     CALL BisectionForC(hae, hdIn, alpha, n, cPlusOne) ! Solve the equation by iteration.
   END IF
 END IF
 END FUNCTION CplusOne 
!
 pure FUNCTION hjRIA(hdFitted, n)
!
! Function hjRIA calculates the matric potential at the junction point hj in cm H2O for the RIA parameterization (see WCRIA).
!
! Interface:
!
! Input
!
! Argument list input:
! - hdFitted: the matric potential at oven-dryness
!   N.B. This is the fitted value that needs to be multiplied by a correction value (1 + c) to arrive at the target value at which
!        the water content reaches zero.
! - n: shape parameter n
!
! Input from modules:
! - the number one in high precision is obtained from Module Numbers
! - hjCorrectionFactor: the correction factor to ensure that the absolute value of hj is close to but not at the theoretical
!   limit is given by Module ParameterInformation
!
! Output
!
! - The value of hj is returned as the function value.
!
! Gerrit de Rooij, April 2022, modified August 2022
!
 USE DoublePrec
 USE Numbers, ONLY: one
 USE ParameterInformation, ONLY: hjCorrectionFactor
 IMPLICIT None
!
 REAL (KIND = DP) :: hjRIA
 REAL (KIND = DP), Intent(In) :: hdFitted, n
!
 hjRIA = -ABS(hjCorrectionFactor * hdFitted * EXP(one/(one - n))) ! Eq. (8) in de Rooij (2022), with a minute reduction applied.
 END FUNCTION hjRIA
!
 pure FUNCTION JU1calc(Ksat, tau, Ghae, Ghj)
! JU1calc computes factor JU1 of the junction conductivity model.
!
! Interface:
!
! Input
!
! Argument list input:
! - Ksat: the saturated hydraulic conductivity for liquid water (cm/d)
! - tau:  shape parameter of the conductivity function
! - Ghae: factor appearing in the equation
! - Ghj:  factor appearing in the equation
!
! Output
!
! - The value of the factor JU1 is returned through the function.
!
! Gerrit de Rooij, December 2021
!
 USE DoublePrec
 IMPLICIT NONE 
!
 REAL (KIND = DP), Intent(In) :: Ksat, tau, Ghae, Ghj
 REAL (KIND = DP) :: JU1calc
!
 JU1calc = Ksat * ((Ghj / Ghae)**tau) 
 END FUNCTION JU1calc
!
 pure FUNCTION JU4calc(JU1, JU2, JU3, gamma)
! JU4calc computes factor JU4 of the junction conductivity model.
!
! Interface:
!
! Input
!
! Argument list input:
! - JU1, JU2, JU3: factors of the junction hydraulic conductivity model
! - gamma: shape parameter of the conductivity function
!
! Output
!
! - The value of the factor JU4 is returned through the function.
!
! Gerrit de Rooij, December 2021
!
 USE DoublePrec
 IMPLICIT NONE 
!
 REAL (KIND = DP), Intent(In) :: JU1, JU2, JU3, gamma
 REAL (KIND = DP) :: JU4calc
!
 JU4calc = JU1 * ((JU2 / JU3)**gamma)
 END FUNCTION JU4calc
!
 pure FUNCTION RIAderivative(h)
! RIAderivative calculates the derviative d theta/ d h of the RIA SWRC for a given matric potential h according to de Rooij et al. (2021).
! A zero derivative can cause numerical difficulties. Therefore, the specific storage for confined aquifers is invoked through parameter
! SpecificStorage to ensure a non-zero derivative as long as the soil has liquid water in it. The term with the specific storage will
! generally be negligible compared to the derivative of RIA for unsaturated soils (h < hae).
!
! Interface:
!
! Input
!
! Argument list input:
! - h: the matric potential or suction for which the function value is sought
!
! Input from modules:
! - Module SHPvariables provides the array SWRCpars with the parameters of the RIA SWRC, and several derived parameters.
! - Module Numbers provides several numbers in high precision.
! 
! Output
!
! - The computed value is returned as the function value.
!
! Gerrit de Rooij, June 2025.
! 
 USE DoublePrec
 USE Numbers, ONLY: zero, one, two
 USE SHPvariables, ONLY : iLayer, SWRCpars, SWRCbeta, SWRCGhae, SWRChj, SWRCExpo, hdTarget, SpecificStorage
 IMPLICIT NONE 
!
 REAL (KIND = DP), INTENT(IN) :: h 
 REAL (KIND = DP) :: Help, RIAderivative
!
! IF (ABS(h) < ABS(SWRCpars(iLayer,2))) THEN ! The soil is saturated.
 IF (h > SWRCpars(iLayer,2)) THEN ! The soil is saturated.
   RIAderivative = SpecificStorage
 ELSE IF (ABS(h) >= ABS(hdTarget(iLayer))) THEN ! The soil is dry.
   RIAderivative = zero
 ELSE ! The soil is unsaturated but not dry.
   IF (ABS(h) < ABS(hdTarget(iLayer)) .AND. ABS(h) >= ABS(SWRChj(iLayer))) THEN ! The matric potential is in the dry branch.
     RIAderivative = (SWRCpars(iLayer,1) * SWRCbeta(iLayer) / ABS(h))
   ELSE ! The matric potential is in the intermediate/wet branch.
     Help = ABS(SWRCpars(iLayer,4) * h)
     RIAderivative = SWRCpars(iLayer,1) * SWRCpars(iLayer,4) * (Help**SWRCExpo(iLayer)) * SWRCExpo(iLayer) / SWRCGhae(iLayer)
     RIADerivative = RIAderivative * (((Help**SWRCpars(iLayer,5)) + one)**((one/SWRCpars(iLayer,5)) - two))
   END IF
   RIAderivative = RIAderivative + (SpecificStorage * WCRIA(h) / SWRCpars(iLayer,1))
 END IF
 END FUNCTION RIAderivative
!
 pure FUNCTION vGfactor(h, alpha, n)
!
! Function vGfactor computes a factor that appears in van Genuchten's (1980) retention curve and versions derived from
! it. In the original version it represents the degree of saturation, and thus only depends on the matric potential h
! and the shape factors alpha and n. Note that the value of m in the original expression is assumed to equal 1 - 1/n.
!
! Interface:
!
! Input
!
! Argument list input:
! - h: the matric potential or suction
! - alpha: shape factor alpha
! - n: shape factor n
!
! Output
!
! - The value of the factor is returned through the function (vGfactor).
!
! Gerrit de Rooij, July 2015
!
 USE DoublePrec
 USE Numbers, ONLY: one 
 IMPLICIT None
!
 REAL (KIND = DP) :: vGfactor
 REAL (KIND = DP), Intent(In) :: h, alpha, n
!
 vGfactor = (one + (ABS(alpha * h))**n)**((one / n) - one)
 END FUNCTION vGfactor
!
 pure FUNCTION WCRIA(h)
! WCRIA calculates the volumetric water content as a function of the matric potential, based on the retention function of
! de Rooij et al. (2021) and de Rooij (2022).
!
! Interface:
!
! Input
!
! Input argument list:
! - h: the matric potential or suction (the code can handle either)
!
! Input from Modules:
! - The parameters of the SWRC (SWRCpars) and all derived parameters, including the corrected value of he matric potential at
!   oven-dryness (hdTarget), are obtained from Module SHPvariables.
!   The order of the parameters in array SWRCpars is:
!   - saturated water content
!   - air-entry value
!   - fitted matric potential at oven-dryness (needs to be multiplied by (1+c)
!   - alpha
!   - n
! - The number one is obtained from Module Numbers.
!
! Output
!
! - The volumetric water content is returned as the function value
!
! Gerrit de Rooij, May 2021. Modified: April 2022, February 2023, August 2024. Modified for Richards' solvers: June 2025
!
 USE DoublePrec
 USE Numbers, ONLY: zero
 USE SHPvariables, ONLY: iLayer, SWRCpars, SWRCbeta, SWRChj, SWRCGhae, hdTarget
 IMPLICIT None
!
 REAL (KIND = DP), Intent(In) :: h ! The matric potential or suction for which the volumetric water content is sought.
 REAL (KIND = DP) :: WCRIA
!
 IF (h > SWRCpars(iLayer,2)) THEN
    WCRIA = SWRCpars(iLayer,1)   ! saturated
 ELSE IF (ABS(h) >= ABS(hdTarget(iLayer))) THEN ! The soil is completely dry.
   WCRIA = zero ! The top line of Eq. (1) in de Rooij (2022)
 ELSE IF (ABS(h) >= ABS(SWRChj(iLayer))) THEN ! The soil is in the dry, logarithmic branch.
   WCRIA = SWRCbeta(iLayer) * SWRCpars(iLayer,1) * LOG(ABS(hdTarget(iLayer) / h)) ! Eq. (10) in de Rooij (2022).
 ELSE ! The wet and intermediate sigmoid branch of the retention curve apply.
   IF (ABS(h) >= ABS(SWRCpars(iLayer,2))) THEN ! The soil is in the intermediate, sigmoid branch.
     WCRIA = SWRCpars(iLayer,1) * vGfactor(h, SWRCpars(iLayer,4), SWRCpars(iLayer,5)) / SWRCGhae(iLayer) ! The 3rd line of Eq. (1) in de Rooij (2022).
   ELSE ! The soil is saturated.
     WCRIA = SWRCpars(iLayer,1) ! The bottom line of Eq. (1) of de Rooij (2022)    
   END IF
 END IF
 END FUNCTION WCRIA
!
end module MOD_RIA

! END PROGRAM WCKplot
