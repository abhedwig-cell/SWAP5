import json,os
from pathlib import Path
import run_daily_kernel as run
t=Path(os.environ['TEMP'])
reference=t/'hy481-local-b0-20261109'
origin=t/'hy481-final-cut256-02/continuous/original'
out=t/'hy481-wetonly-from256-01'
out.mkdir()
donor,kernel,case,inputs=run.build(reference,out,checkpoint_day=256,budget_retry=True,shared_pond_transfer=True)
result=run.run(donor,kernel,case,out,481,checkpoint_day=256,origin=origin)
(out/'RESULT.json').write_text(json.dumps(result,indent=2))
print(result['committed_days'])
