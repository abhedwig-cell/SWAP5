import inspect,json,os
from pathlib import Path
import run_daily_kernel as run

t=Path(os.environ['TEMP'])
reference=t/'hy481-local-b0-20261109'
origin=t/'hy481-final-cut256-02/continuous/original'
out=t/'hy481-wetonly-isolation256-01'
out.mkdir()
donor,kernel,case,inputs=run.build(reference,out,checkpoint_day=256,budget_retry=True,shared_pond_transfer=True)
source=inspect.getsource(run.run).replace('1998-01-02','1998-09-15').replace('checkpoint_dir.mkdir()','checkpoint_dir.mkdir(exist_ok=True)')
exec(compile(source,run.__file__,'exec'),run.__dict__)
datasets={}
for label,variants in (('alternating',('original','shifted')),('control_a',('original',)),('control_b',('shifted',))):
    d=out/label
    d.mkdir()
    r=run.run(donor,kernel,case,d,258,variants,checkpoint_day=256,origin=origin)
    if r['first_refusal']: raise RuntimeError(f"{label} refused: {r['first_refusal']['day']}")
    datasets[label]=[json.loads(line) for line in (d/'daily.jsonl').read_text().splitlines()]
for column,label in enumerate(('control_a','control_b'),1):
    assert [dict(x,column=1) for x in datasets['alternating'] if x['column']==column]==datasets[label]
assert datasets['control_a'] != datasets['control_b']
result={'cut':256,'end':258,'column_b_cauchy_date':'1998-09-15','column_b_delta_cm':0.001,
        'alternate_exact':True,'distinct':True,
        'column_b_bbc_sha256':run.sha(out/'control_b/shifted/swap.bbc'),
        'donor_executable_sha256':run.sha(donor),'kernel_executable_sha256':run.sha(kernel)}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
