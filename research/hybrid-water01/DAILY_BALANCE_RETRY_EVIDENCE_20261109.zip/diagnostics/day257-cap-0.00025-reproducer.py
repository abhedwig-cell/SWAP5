import os,sys
import run_daily_kernel as run
original_replace = run.replace
def wet_cap(text, anchor, replacement):
    if anchor == "      budget_total = budget_total + budget_step\\n      call SoilWater(3)":
        pass
    if anchor == "         if (.NOT.fldecdt) call SoilWater(2)":
        marker = "         ! process weather data for specific time"
        text = original_replace(text, marker, f"         if (t1900 >= 36051d0 .and. t1900 < 36052d0) dt = min(dt, {os.environ['HY_WET_CAP']}d0)\n"+marker)
    return original_replace(text, anchor, replacement)
run.replace=wet_cap
sys.exit(run.main())
