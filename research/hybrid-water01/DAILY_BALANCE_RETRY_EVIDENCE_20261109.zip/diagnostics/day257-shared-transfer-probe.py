import json,os,subprocess
from pathlib import Path
import run_daily_kernel as run
t=Path(os.environ['TEMP'])
reference=t/'hy481-local-b0-20261109'
origin=t/'hy481-robust-cut256-01/continuous/original'
out=t/'hy481-wet-pondshared-01'
out.mkdir()
donor,kernel,case,inputs=run.build(reference,out,checkpoint_day=256,budget_retry=True)
build=reference/'build'
obj=build/'swap-obj'
tt=build/'ttutil-obj'
p=out/'headcalc.f90'
s=p.read_text(encoding='cp1252')
s=run.replace(s,'   use hybrid_step_budget, only: projected_water_residual',
              '   use hybrid_step_budget, only: projected_water_residual\n'
              '   use MOD_macropore, only: NumDm, QInTopLatDm')
s=run.replace(s,'   real(8)                          :: QMpLatSsSav','   real(8)                          :: QMpLatSsSav, hybefore, hylateral')
s=run.replace(s,'   if (FlRunoff .OR. ArMpSs > 0.0d0) call pondrunoff ()',"""   hybefore = QMpLatSs
   if (FlRunoff .OR. ArMpSs > 0.0d0) call pondrunoff ()
   if (swmacro == 1 .and. QMpLatSs < hybefore .and. QMpLatSs >= 0d0) then
      hylateral = sum(QInTopLatDm(1:NumDm)) * dt
      if (hylateral > QMpLatSs) QInTopLatDm(1:NumDm) = QInTopLatDm(1:NumDm) * (QMpLatSs/hylateral)
   end if""")
p.write_text(s,encoding='cp1252')
subprocess.run(['gfortran','-O2','-cpp','-Dlinux','-finit-local-zero','-ffree-line-length-none','-fallow-argument-mismatch','-I',str(obj),'-I',str(tt),'-c','headcalc.f90'],cwd=out,check=True)
replacements={f'{stem}.o':out/f'{stem}.o' for stem in ('macropore','swap','swap_main','swap_csv_output','headcalc')}
subprocess.run(['gfortran','-o',str(donor),*(str(replacements.get(p.name,p)) for p in sorted(obj.glob('*.o'))),
                str(out/'hybrid_step_budget.o'),str(tt/'libttutil.a')],cwd=out,check=True)
result=run.run(donor,kernel,case,out,258,checkpoint_day=256,origin=origin)
(out/'RESULT.json').write_text(json.dumps(result,indent=2))
print(result['committed_days'])
