import json,os,subprocess
from pathlib import Path
from run_daily_kernel import run, replace
tmp=Path(os.environ['TEMP'])
old=tmp/'hy481-trace33-deviat'
out=tmp/'hy481-day33-component-01'
out.mkdir()
base=tmp/'hy481-local-b0-20261109'
build=base/'build'
obj=build/'swap-obj'
tt=build/'ttutil-obj'
case=base/'distribution/SWAP_4.3.1/cases/3.macroporeflow'
s=(old/'swap.f90').read_text(encoding='cp1252')
s=replace(s,"only: macrostatevar, macropore\n","only: macrostatevar, macropore, NumDm, QInTopLatDm, QInTopVrtDm\n")
s=replace(s,"iQMpOutDrRap\n","iQMpOutDrRap, armpss, qmplatss, qexcmpmtx\n")
s=replace(s,"volact, outfil,","volact, qtop, qbot, pondm1, epd, reva, runon, runots, outfil,")
s=replace(s,"only: meteo, interception_daily, peva, empreva, epond","only: meteo, interception_daily, peva, empreva, epond, nraidt")
s=replace(s,"only: irrigation, flirrigate","only: irrigation, flirrigate, nird, qssdisum")
s=replace(s,"only: drain\n","only: drain, qdrtot\n")
s=replace(s,"use MOD_grid,            only: numnod","use MOD_re_global, only: qrosum\nuse MOD_grid,            only: numnod")
s=replace(s,"      call SoilWater(3)", """      if (t1900 > 35827.765015d0 .and. t1900 < 35827.765017d0) then
         write(*,'(a,*(1x,es25.17e3))') 'HYBRID_ROUTE', t1900, dt, qtop, qbot, pond, pondm1, &
           epd, reva, runon, runots, nraidt, nird, qssdisum, qdrtot, qrosum, &
           armpss, qmplatss, sum(QInTopLatDm(1:NumDm)), sum(QInTopVrtDm(1:NumDm)), sum(qexcmpmtx(1:numnod))
      end if
      call SoilWater(3)""")
(out/'swap.f90').write_text(s,encoding='cp1252')
subprocess.run(['gfortran','-O2','-cpp','-Dlinux','-finit-local-zero','-ffree-line-length-none','-fallow-argument-mismatch','-I',str(obj),'-I',str(tt),'-c','swap.f90'],cwd=out,check=True)
patched={name: old/name for name in ('swap_main.o','swap_csv_output.o','headcalc.o','macropore.o')}
patched['swap.o']=out/'swap.o'
donor=out/'route_donor.exe'
subprocess.run(['gfortran','-o',str(donor),*(str(patched.get(p.name,p)) for p in sorted(obj.glob('*.o'))),str(tt/'libttutil.a')],cwd=out,check=True)
print(run(donor,old/'day_kernel.exe',case,out,33)['committed_days'])
