* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-12 00:55:27
