module mod_fmr_divdra_serialized_composition
  use, intrinsic :: iso_fortran_env, only: int64, real64
  use mod_fmr_runtime_core, only: fmr_logical_column_t
  use mod_fmr_serialized_reference_backend, only: fmr_b110_physical_forcing_t
  use mod_drainage_spatial_distribution, only: drainage_distribution_parameters_t
  use mod_process_hydraulic_view, only: process_hydraulic_view_t
  use mod_fmr_divdra_runtime_binding, only: fmr_divdra_binding_diagnostics_t, &
       fmr_divdra_multilevel_binding_diagnostics_t, fmr_bind_single_level_signed_divdra, &
       fmr_bind_multilevel_signed_divdra, FMR_DIVDRA_BIND_OK
  use mod_drainage_b19_separate_infiltration_adapter, only: drainage_b19_separate_infiltration_parameters_t
  use mod_fmr_divdra_separate_infiltration_binding, only: fmr_divdra_separate_infiltration_binding_diagnostics_t, &
       fmr_bind_separate_infiltration, FMR_DIVDRA_INF_SPLIT_OK
  use mod_drainage_discharge_layer_transform,only:discharge_layer_top_control_t
  use mod_fmr_divdra_dislayer_binding,only:fmr_bind_dislayer,fmr_divdra_dislayer_diagnostics_t
  implicit none
  private

  integer, parameter, public :: FMR_DIVDRA_COMPOSE_OK = 0
  integer, parameter, public :: FMR_DIVDRA_COMPOSE_INVALID_SHAPE = 1
  integer, parameter, public :: FMR_DIVDRA_COMPOSE_COLUMN_ID_MISMATCH = 2
  integer, parameter, public :: FMR_DIVDRA_COMPOSE_INVALID_FORCING_HANDLE = 3
  integer, parameter, public :: FMR_DIVDRA_COMPOSE_SHARED_FORCING_HANDLE = 4
  integer, parameter, public :: FMR_DIVDRA_COMPOSE_INVALID_PARAMETER_REF = 5
  integer, parameter, public :: FMR_DIVDRA_COMPOSE_INVALID_HYDRAULIC_VIEW_REF = 6
  integer, parameter, public :: FMR_DIVDRA_COMPOSE_BIND_REJECTED = 7

  type, public :: fmr_divdra_serialized_column_request_t
    integer(int64) :: column_id = 0_int64
    logical :: active = .false.
    integer(int64) :: distribution_parameter_ref = 0_int64
    integer(int64) :: hydraulic_view_ref = 0_int64
    real(real64) :: scalar_transfer = 0.0_real64
    integer(int64), allocatable :: distribution_parameter_refs(:)
    real(real64), allocatable :: scalar_transfers(:)
    type(drainage_b19_separate_infiltration_parameters_t), allocatable :: separate_infiltration_controls(:)
    type(discharge_layer_top_control_t),allocatable::discharge_layer_controls(:)
  end type fmr_divdra_serialized_column_request_t

  type, public :: fmr_divdra_serialized_binding_record_t
    integer(int64) :: column_id = 0_int64
    integer :: column_index = 0
    integer(int64) :: forcing_handle = 0_int64
    integer :: composition_status = FMR_DIVDRA_COMPOSE_OK
    type(fmr_divdra_dislayer_diagnostics_t)::discharge_layer_binding
    type(fmr_divdra_binding_diagnostics_t) :: binding
    type(fmr_divdra_separate_infiltration_binding_diagnostics_t) :: separate_infiltration_binding
    logical :: multilevel = .false.
    type(fmr_divdra_multilevel_binding_diagnostics_t) :: multilevel_binding
  end type fmr_divdra_serialized_binding_record_t

  public :: fmr_preflight_serialized_divdra

contains

  subroutine fmr_preflight_serialized_divdra(columns, forcing_registry, requests, distribution_parameters, &
       hydraulic_views, records, status)
    type(fmr_logical_column_t), intent(in) :: columns(:)
    type(fmr_b110_physical_forcing_t), intent(in) :: forcing_registry(:)
    type(fmr_divdra_serialized_column_request_t), intent(in) :: requests(:)
    type(drainage_distribution_parameters_t), intent(in) :: distribution_parameters(:)
    type(process_hydraulic_view_t), intent(in) :: hydraulic_views(:)
    type(fmr_divdra_serialized_binding_record_t), allocatable, intent(out) :: records(:)
    integer, intent(out) :: status

    integer, allocatable :: forcing_use_count(:)
    real(real64), allocatable :: probe(:,:)
    type(fmr_divdra_binding_diagnostics_t) :: bind_diag
    type(fmr_divdra_multilevel_binding_diagnostics_t) :: multi_diag
    type(fmr_divdra_separate_infiltration_binding_diagnostics_t) :: inf_diag
    type(fmr_divdra_dislayer_diagnostics_t)::layer_diag
    type(drainage_distribution_parameters_t), allocatable :: level_parameters(:)
    integer :: i, j, active_count, slot, forcing_index, parameter_index, view_index
    logical :: multilevel

    status = FMR_DIVDRA_COMPOSE_OK
    allocate(records(0))

    if (size(requests) /= size(columns)) then
      status = FMR_DIVDRA_COMPOSE_INVALID_SHAPE
      return
    end if

    allocate(forcing_use_count(size(forcing_registry)))
    forcing_use_count = 0
    do i = 1, size(columns)
      if (columns(i)%forcing_handle >= 1_int64 .and. &
          columns(i)%forcing_handle <= int(size(forcing_registry), int64)) then
        forcing_index = int(columns(i)%forcing_handle)
        forcing_use_count(forcing_index) = forcing_use_count(forcing_index) + 1
      end if
    end do

    do i = 1, size(columns)
      if (requests(i)%column_id /= columns(i)%column_id) then
        status = FMR_DIVDRA_COMPOSE_COLUMN_ID_MISMATCH
        return
      end if
    end do

    active_count = count(requests%active)
    deallocate(records)
    allocate(records(active_count))
    slot = 0

    do i = 1, size(columns)
      if (.not. requests(i)%active) cycle
      slot = slot + 1
      records(slot)%column_id = columns(i)%column_id
      records(slot)%column_index = i
      records(slot)%forcing_handle = columns(i)%forcing_handle

      if (columns(i)%forcing_handle < 1_int64 .or. &
          columns(i)%forcing_handle > int(size(forcing_registry), int64)) then
        status = FMR_DIVDRA_COMPOSE_INVALID_FORCING_HANDLE
        records(slot)%composition_status = status
        return
      end if
      forcing_index = int(columns(i)%forcing_handle)
      if (forcing_use_count(forcing_index) /= 1) then
        status = FMR_DIVDRA_COMPOSE_SHARED_FORCING_HANDLE
        records(slot)%composition_status = status
        return
      end if

      multilevel=allocated(requests(i)%distribution_parameter_refs).or.allocated(requests(i)%scalar_transfers)
      if(multilevel)then
        if(requests(i)%distribution_parameter_ref/=0_int64.or.requests(i)%scalar_transfer/=0.0_real64)then
          status=FMR_DIVDRA_COMPOSE_INVALID_PARAMETER_REF
          records(slot)%composition_status=status
          return
        end if
        if(.not.allocated(requests(i)%distribution_parameter_refs).or..not.allocated(requests(i)%scalar_transfers))then
          status=FMR_DIVDRA_COMPOSE_INVALID_PARAMETER_REF
          records(slot)%composition_status=status
          return
        end if
        if(size(requests(i)%distribution_parameter_refs)<=1.or. &
             size(requests(i)%distribution_parameter_refs)/=size(requests(i)%scalar_transfers))then
          status=FMR_DIVDRA_COMPOSE_INVALID_PARAMETER_REF
          records(slot)%composition_status=status
          return
        end if
        allocate(level_parameters(size(requests(i)%distribution_parameter_refs)))
        do j=1,size(level_parameters)
          if(requests(i)%distribution_parameter_refs(j)<1_int64.or. &
               requests(i)%distribution_parameter_refs(j)>int(size(distribution_parameters),int64))then
            status=FMR_DIVDRA_COMPOSE_INVALID_PARAMETER_REF
            records(slot)%composition_status=status
            return
          end if
          level_parameters(j)=distribution_parameters(int(requests(i)%distribution_parameter_refs(j)))
        end do
      else
        if (requests(i)%distribution_parameter_ref < 1_int64 .or. &
            requests(i)%distribution_parameter_ref > int(size(distribution_parameters), int64)) then
          status = FMR_DIVDRA_COMPOSE_INVALID_PARAMETER_REF
          records(slot)%composition_status = status
          return
        end if
        parameter_index = int(requests(i)%distribution_parameter_ref)
      end if

      if (requests(i)%hydraulic_view_ref < 1_int64 .or. &
          requests(i)%hydraulic_view_ref > int(size(hydraulic_views), int64)) then
        status = FMR_DIVDRA_COMPOSE_INVALID_HYDRAULIC_VIEW_REF
        records(slot)%composition_status = status
        return
      end if
      view_index = int(requests(i)%hydraulic_view_ref)

      if (allocated(probe)) deallocate(probe)
      if (allocated(forcing_registry(forcing_index)%drainage_flux_by_level)) then
        allocate(probe(size(forcing_registry(forcing_index)%drainage_flux_by_level, 1), &
                       size(forcing_registry(forcing_index)%drainage_flux_by_level, 2)))
        probe = forcing_registry(forcing_index)%drainage_flux_by_level
      end if

      if(allocated(requests(i)%discharge_layer_controls))then
        if(multilevel)then
          call fmr_bind_dislayer(level_parameters,hydraulic_views(view_index),requests(i)%scalar_transfers, &
               requests(i)%discharge_layer_controls,probe,layer_diag,requests(i)%separate_infiltration_controls)
          deallocate(level_parameters)
        else
          call fmr_bind_dislayer(distribution_parameters(parameter_index:parameter_index),hydraulic_views(view_index), &
               [requests(i)%scalar_transfer],requests(i)%discharge_layer_controls,probe,layer_diag, &
               requests(i)%separate_infiltration_controls)
        end if
        records(slot)%multilevel=multilevel;records(slot)%discharge_layer_binding=layer_diag
        if(.not.layer_diag%published)then
          status=FMR_DIVDRA_COMPOSE_BIND_REJECTED;records(slot)%composition_status=status;return
        end if
        records(slot)%composition_status=FMR_DIVDRA_COMPOSE_OK;cycle
      end if
      if(allocated(requests(i)%separate_infiltration_controls))then
        if(multilevel)then
          call fmr_bind_separate_infiltration(level_parameters,hydraulic_views(view_index),requests(i)%scalar_transfers, &
               requests(i)%separate_infiltration_controls,probe,inf_diag)
          deallocate(level_parameters)
        else
          call fmr_bind_separate_infiltration(distribution_parameters(parameter_index:parameter_index), &
               hydraulic_views(view_index),[requests(i)%scalar_transfer],requests(i)%separate_infiltration_controls,probe,inf_diag)
        end if
        records(slot)%multilevel=multilevel
        records(slot)%separate_infiltration_binding=inf_diag
        if(inf_diag%status/=FMR_DIVDRA_INF_SPLIT_OK)then
          status=FMR_DIVDRA_COMPOSE_BIND_REJECTED
          records(slot)%composition_status=status
          return
        end if
        records(slot)%composition_status=FMR_DIVDRA_COMPOSE_OK
        cycle
      end if
      records(slot)%multilevel=multilevel
      if(multilevel)then
        call fmr_bind_multilevel_signed_divdra(level_parameters,hydraulic_views(view_index), &
             requests(i)%scalar_transfers,probe,multi_diag)
        records(slot)%multilevel_binding=multi_diag
        if(multi_diag%status/=FMR_DIVDRA_BIND_OK)then
          status=FMR_DIVDRA_COMPOSE_BIND_REJECTED
          records(slot)%composition_status=status
          return
        end if
        deallocate(level_parameters)
      else
        call fmr_bind_single_level_signed_divdra(distribution_parameters(parameter_index), hydraulic_views(view_index), &
             requests(i)%scalar_transfer, probe, bind_diag)
        records(slot)%binding = bind_diag
        if (bind_diag%status /= FMR_DIVDRA_BIND_OK) then
          status = FMR_DIVDRA_COMPOSE_BIND_REJECTED
          records(slot)%composition_status = status
          return
        end if
      end if
      records(slot)%composition_status = FMR_DIVDRA_COMPOSE_OK
    end do
  end subroutine fmr_preflight_serialized_divdra

end module mod_fmr_divdra_serialized_composition
