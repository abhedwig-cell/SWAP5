* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-11-11 21:30:31

Period             :  2004-11-27  until  2004-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        76.02 cm       0.1403E+02 mg/cm2
Initial :        75.25 cm       0.1532E+02 mg/cm2
            =============       =================
Change            0.77 cm      -0.1287E+01 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :     5.78    Interception      :     0.28
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.14
Bottom flux    :     0.00    Soil evaporation  :     0.13
                             Crack flux        :     0.00
                             Drainage level 1  :     4.49
=========================    ============================
Sum            :     5.78    Sum               :     5.04


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.1287E+01
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.1287E+01

