subroutine saltfarm_restart_probe()
 use MOD_grid,only:numnod
 use variables,only:t1900,t,dt,dtold,gwl,gwlm1,qbot,pond,h,theta,k,kmean,dimoca,qrot
 use MOD_frost,only:rfcp
 use MOD_SoilTemperature,only:tsoil
 implicit none
 integer::unit
 open(newunit=unit,file='first-step.bin',access='stream',form='unformatted',status='unknown',position='append')
 write(unit) t1900,t,dt,dtold,gwl,gwlm1,qbot,pond
 write(unit) h(1:numnod),theta(1:numnod),k(1:numnod),kmean(1:numnod),dimoca(1:numnod),qrot(1:numnod),rfcp(1:numnod),tsoil(1:numnod)
 close(unit)
end subroutine
