param([ValidateSet('O0','O2')][string]$Opt)
$ErrorActionPreference = 'Stop'
$ref = Join-Path $env:TEMP 's5-heat-original-base-windows-20261111/reference'
foreach ($project in @('saltfarm','hupsel','grass')) {
 $bundle = Join-Path $env:TEMP ('s5-surface-v2-native-' + $project + '-' + $Opt)
 if ($project -eq 'saltfarm') {
  python -B research/hybrid-water01/qualify_nomacro_saltfarm.py --reference $ref --output $bundle --optimization $Opt > ($bundle + '.stdout') 2> ($bundle + '.stderr')
 } else {
  python -B research/hybrid-water01/qualify_generic_hybrid_waterhost.py --no-macro-release --reference $ref --output $bundle --project $project --optimization $Opt > ($bundle + '.stdout') 2> ($bundle + '.stderr')
 }
 if ($LASTEXITCODE -ne 0) { Write-Output "$project $Opt native FAIL"; exit 1 }; Write-Output "$project $Opt native PASS"
 $controls = $bundle
 if ($project -ne 'saltfarm') {
  $controls = $bundle + '-seasonal'
  python -B research/hybrid-water01/run_hybrid_grass_full.py --bundle $bundle --reference $ref --output $controls --project $project > ($controls + '.stdout') 2> ($controls + '.stderr')
  if ($LASTEXITCODE -ne 0) { Write-Output "$project $Opt full FAIL"; exit 1 }; Write-Output "$project $Opt full PASS"
 }
 if ($project -ne 'grass') {
  $tx = Join-Path $env:TEMP ('s5-surface-v2-transactions-' + $project + '-' + $Opt)
  python -B research/hybrid-water01/qualify_surface_irrigation.py --reference $ref --bundle $bundle --controls (Join-Path $controls 'full') --output $tx --project $project > ($tx + '.stdout') 2> ($tx + '.stderr')
  if ($LASTEXITCODE -ne 0) { Write-Output "$project $Opt surface FAIL"; exit 1 }; Write-Output "$project $Opt surface PASS"
  if ($project -eq 'saltfarm') {
   $day109 = Join-Path $env:TEMP ('s5-surface-v2-day109-' + $Opt)
   python -B research/hybrid-water01/check_saltfarm_day109.py --reference $ref --runs $tx --output $day109 > ($day109 + '.stdout') 2> ($day109 + '.stderr')
   if ($LASTEXITCODE -ne 0) { Write-Output "$project $Opt day109 FAIL"; exit 1 }; Write-Output "$project $Opt day109 PASS"
  }
  $cut = if ($project -eq 'saltfarm') { 107 } else { 4 }
  $accepted = Join-Path $tx ($cut.ToString() + '-modified-shared/external/accepted-column-1-day-' + ($cut+1).ToString() + '.zip')
  $guards = Join-Path $env:TEMP ('s5-surface-v2-guards-' + $project + '-' + $Opt)
  python -B research/hybrid-water01/check_irrigation_inputs.py --reference $ref --bundle (Join-Path $tx 'build') --accepted $accepted --project $project --output $guards > ($guards + '.stdout') 2> ($guards + '.stderr')
  if ($LASTEXITCODE -ne 0) { Write-Output "$project $Opt guards FAIL"; exit 1 }; Write-Output "$project $Opt guards PASS"
 }
 $heat = Join-Path $env:TEMP ('s5-surface-v2-heat-' + $project + '-' + $Opt)
 python -B research/hybrid-water01/qualify_original_heat_accounting.py --base-archive research/hybrid-water01/hybrid-hupsel-windows-20261111.tar.xz --workspace (Join-Path $env:TEMP 's5-heat-original-base-windows-20261111') --output $heat --case ($project + '-' + $Opt) --current-bundle $bundle --control-root $controls --project $project --compact --full-period > ($heat + '.stdout') 2> ($heat + '.stderr')
 if ($LASTEXITCODE -ne 0) { Write-Output "$project $Opt heat FAIL"; exit 1 }
 python -B research/hybrid-water01/check_original_heat_accounting.py --runs $heat --compact > (Join-Path $heat 'check.stdout') 2> (Join-Path $heat 'check.stderr')
 if ($LASTEXITCODE -ne 0) { Write-Output "$project $Opt heat reader FAIL"; exit 1 }; Write-Output "$project $Opt heat PASS"
}
