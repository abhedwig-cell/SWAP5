
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
int s5_shadow_begin(void) {
    pid_t p=fork(); int status=0;
    if(p==0) {alarm(2); return 0;}
    if(p<0) return -1;
    while(waitpid(p,&status,0)<0) {if(errno!=EINTR) return -2;}
    return WIFEXITED(status) && WEXITSTATUS(status)==0 ? 1 : -3;
}
void s5_shadow_end(void) {_exit(0);}
