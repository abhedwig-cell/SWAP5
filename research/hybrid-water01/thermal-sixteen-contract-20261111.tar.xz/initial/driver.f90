program test_thermal_subcycle
 use iso_fortran_env,only:real64
 use mod_soil_temperature_contract
 use mod_process_hydraulic_view,only:process_hydraulic_view_t
 use mod_restricted_soil_temperature_sixteen,only:trial_restricted_soil_temperature
 use mod_restricted_soil_temperature,only:initialize_soil_temperature_parameters, &
      original_trial=>trial_restricted_soil_temperature
 use mod_fmr_thermal_substep_receipt
 implicit none
 type(soil_temperature_parameters_t)::p
 type(soil_temperature_numerical_config_t)::num,single_num
 type(soil_temperature_forcing_t)::f
 type(soil_temperature_state_t)::initial,trial,control,next_state,other,other_trial
 type(soil_temperature_workspace_t)::w,wc,wb
 type(soil_temperature_result_t)::r,rc
 type(soil_temperature_diagnostics_t)::d,dc
 type(process_hydraulic_view_t)::h
 type(fmr_thermal_substep_receipt_t)::receipt
 real(real64),allocatable::v(:),vcontrol(:),saved(:)
 real(real64)::faces(3),a,b,dt,cell(2),defect,error4,error16,cpu4,cpu16
 integer::status,k,top,bottom,cases
 call initialize_soil_temperature_parameters([2d0,3d0],[1d0,2.5d0],[.45d0,.45d0], &
      [.35d0,.35d0],[.15d0,.15d0],[.05d0,.05d0],p,status)
 if(status/=SOIL_TEMP_OK)error stop 'parameters'
 call initialize_soil_temperature_state([12d0,9d0],initial,status)
 if(status/=SOIL_TEMP_OK)error stop 'initial'
 h%active_nodes=2;h%pressure_head=[-100d0,-125d0];h%water_content=[.3d0,.32d0]
 call copy_soil_temperature_profile(initial,saved,status)
 dt=.04d0;cases=0;num%internal_heat_substeps=16
 do top=SOIL_TEMP_TOP_PRESCRIBED_TEMPERATURE,SOIL_TEMP_TOP_TEMPERATURE_FLUX_CORRECTION
 do bottom=SOIL_TEMP_BOTTOM_ZERO_HEAT_FLUX,SOIL_TEMP_BOTTOM_PRESCRIBED_TEMPERATURE
  f%top_boundary_mode=top;f%bottom_boundary_mode=bottom
  f%prescribed_surface_temperature_c=15d0;f%prescribed_top_heat_flux_j_cm2_day=20d0
  f%prescribed_bottom_temperature_c=8d0
  call trial_restricted_soil_temperature(p,num,f,h,h,initial,0d0,dt,w,trial,r,d)
  if(r%status/=SOIL_TEMP_OK.or..not.r%produced)error stop 'private trial'
  if(d%tridiagonal_solves/=16.or.d%constitutive_evaluations/=16)error stop 'missing subsolve'
  control=initial;faces=0d0
  do k=1,16
   a=dt*real(k-1,real64)/16d0;b=dt*real(k,real64)/16d0
   if(k==16)b=dt
   call original_trial(p,single_num,f,h,h,control,a,b,wc,next_state,rc,dc)
   if(rc%status/=SOIL_TEMP_OK)error stop 'original control'
   faces(1)=faces(1)+(b-a)*rc%top_heat_flux_into_soil_j_cm2_day
   faces(2)=faces(2)+(b-a)*wc%face_conductivity_j_cm_k_day(2)* &
        (wc%solution(1)-wc%solution(2))/p%distance_above_cm(2)
   faces(3)=faces(3)-(b-a)*rc%bottom_heat_flux_into_soil_j_cm2_day
   control=next_state
  end do
  call copy_soil_temperature_profile(trial,v,status)
  call copy_soil_temperature_profile(control,vcontrol,status)
  if(maxval(abs(v-vcontrol))>1d-12)error stop 'four original solves differ'
  if(maxval(abs(faces-w%substep_conductive_face_energy_j_cm2))>1d-12)error stop 'integrated faces'
  call capture_fmr_thermal_substep(p,w,f,r,h%water_content,h%water_content,0d0,dt,receipt)
  if(.not.receipt%available)error stop 'missing receipt'
  cell=w%heat_capacity_j_cm3_k*p%dz_cm*(v-saved)
  defect=maxval(abs(cell-(faces(1:2)-faces(2:3))))
  ! The legacy temperature/flux correction explicitly reconstructs its top
  ! boundary from aggregate storage; it is not an independent boundary law.
  if(defect>num%energy_abs_tolerance_j_cm2)error stop 'cellwise energy'
  if(maxval(abs(receipt%conductive_face_energy_j_cm2-faces))>1d-12)error stop 'receipt faces'
  call copy_soil_temperature_profile(initial,vcontrol,status)
  if(maxval(abs(vcontrol-saved))>0d0)error stop 'committed state mutated'
  call indicator(4,error4)
  call indicator(16,error16)
  write(*,'(a,2(i0,a),3(es25.17,a))')'THERMAL_INDICATOR,',top,',',bottom,',', &
       error4,',',error16,',',error16/max(error4,tiny(1d0)),','
  cases=cases+1
 end do
 end do
 ! A/B/A with distinct temperature profiles and private workspaces; a call for
 ! B must not influence A's repeated physical response or mutate A's source.
 call copy_soil_temperature_profile(trial,v,status)
 call initialize_soil_temperature_state([20d0,25d0],other,status)
 call trial_restricted_soil_temperature(p,num,f,h,h,other,0d0,dt,wb,other_trial,r,d)
 if(r%status/=SOIL_TEMP_OK)error stop 'B trial'
 call trial_restricted_soil_temperature(p,num,f,h,h,initial,0d0,dt,w,trial,r,d)
 if(r%status/=SOIL_TEMP_OK)error stop 'A repeat'
 call copy_soil_temperature_profile(trial,vcontrol,status)
 if(maxval(abs(vcontrol-v))>0d0)error stop 'A/B/A contamination'
 call cost(4,cpu4)
 call cost(16,cpu16)
 write(*,'(a,3(es25.17,a))')'THERMAL_KERNEL_SECONDS,',cpu4,',',cpu16,',',cpu16/max(cpu4,tiny(1d0)),','
 ! A rejected call cannot publish an old successful integrated-face receipt.
 f%top_boundary_mode=-999
 call trial_restricted_soil_temperature(p,num,f,h,h,initial,0d0,dt,w,trial,r,d)
 if(r%status==SOIL_TEMP_OK.or.r%produced)error stop 'invalid forcing accepted'
 if(allocated(w%substep_conductive_face_energy_j_cm2))error stop 'stale face receipt'
 call copy_soil_temperature_profile(initial,vcontrol,status)
 if(maxval(abs(vcontrol-saved))>0d0)error stop 'refusal mutated committed state'
 if(cases/=6)error stop 'boundary cases'
 print '(a)','THERMAL_SUBCYCLE_ORIGINAL_SOLVES_FACES_AND_REFUSAL=PASS'
contains
 subroutine step(count,source,t0,t1,target,work)
  integer,intent(in)::count
  type(soil_temperature_state_t),intent(in)::source
  type(soil_temperature_state_t),intent(out)::target
  type(soil_temperature_workspace_t),intent(inout)::work
  real(real64),intent(in)::t0,t1
  type(soil_temperature_numerical_config_t)::policy
  type(soil_temperature_result_t)::result
  type(soil_temperature_diagnostics_t)::diag
  policy%internal_heat_substeps=count
  if(count==4)then
   call original_trial(p,policy,f,h,h,source,t0,t1,work,target,result,diag)
  else
   call trial_restricted_soil_temperature(p,policy,f,h,h,source,t0,t1,work,target,result,diag)
  end if
  if(result%status/=SOIL_TEMP_OK.or..not.result%produced)error stop 'discriminator trial'
 end subroutine
 subroutine indicator(count,error)
  integer,intent(in)::count
  real(real64),intent(out)::error
  type(soil_temperature_state_t)::full,half,finish
  type(soil_temperature_workspace_t)::work
  real(real64),allocatable::vf(:),vh(:)
  integer::s
  call step(count,initial,0d0,dt,full,work)
  call step(count,initial,0d0,dt/2d0,half,work)
  call step(count,half,dt/2d0,dt,finish,work)
  call copy_soil_temperature_profile(full,vf,s)
  if(s/=SOIL_TEMP_OK)error stop 'full profile'
  call copy_soil_temperature_profile(finish,vh,s)
  if(s/=SOIL_TEMP_OK)error stop 'half profile'
  error=maxval(abs(vf-vh))
 end subroutine
 subroutine cost(count,seconds)
  integer,intent(in)::count
  real(real64),intent(out)::seconds
  type(soil_temperature_state_t)::target
  type(soil_temperature_workspace_t)::work
  real(real64)::start,finish
  integer::j
  call cpu_time(start)
  do j=1,20000
   call step(count,initial,0d0,dt,target,work)
  end do
  call cpu_time(finish)
  seconds=(finish-start)/20000d0
 end subroutine
end program
