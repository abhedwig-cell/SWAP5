module mod_canonical_interval_runtime
  use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
  use, intrinsic :: iso_fortran_env, only: real64, int64
  use mod_transaction_reference, only: transaction_state_t, transaction_result_t, transaction_policy_t, &
       transaction_interface_sensitivity_t, execute_reference_interval, TX_STATUS_ACCEPTED, &
       TX_MASS_MISSING_NONE, TX_MASS_MISSING_NONFINITE, TX_MASS_MISSING_UNSPECIFIED, &
       TX_TEMPORAL_NONE, TX_TEMPORAL_MODEL_CERTIFICATE, TX_TEMPORAL_EXTERNAL_FULL_HALF
  use mod_canonical_contracts, only: canonical_physical_model_t, canonical_forcing_t, canonical_interval_t, &
       canonical_numerical_config_t, canonical_result_t, CANONICAL_STATUS_COMPLETED, &
       CANONICAL_STATUS_INVALID_REQUEST, CANONICAL_STATUS_TRANSACTION_FAILED, &
       CANONICAL_STATUS_NO_PROGRESS, CANONICAL_STATUS_SUBSTEP_LIMIT
  implicit none
  private

  public :: run_canonical_interval, canonical_subinterval_target_selector, canonical_subinterval_selection_t

  type, abstract :: canonical_subinterval_selection_t
  contains
    procedure(select_target), deferred :: select
  end type canonical_subinterval_selection_t

  abstract interface
    subroutine select_target(self, cursor, requested_t1, target_t1, max_retries_cap, valid)
      import :: canonical_subinterval_selection_t, real64
      class(canonical_subinterval_selection_t), intent(inout) :: self
      real(real64), intent(in) :: cursor, requested_t1
      real(real64), intent(out) :: target_t1
      integer, intent(out) :: max_retries_cap
      logical, intent(out) :: valid
    end subroutine select_target

    subroutine canonical_subinterval_target_selector(cursor, requested_t1, target_t1, max_retries_cap, valid)
      import :: real64
      real(real64), intent(in) :: cursor, requested_t1
      real(real64), intent(out) :: target_t1
      integer, intent(out) :: max_retries_cap
      logical, intent(out) :: valid
    end subroutine canonical_subinterval_target_selector
  end interface

contains

  subroutine run_canonical_interval(model, committed, forcing, interval, config, result, target_selector, selection)
    class(canonical_physical_model_t), intent(inout) :: model
    class(transaction_state_t), allocatable, intent(inout) :: committed
    class(canonical_forcing_t), intent(in) :: forcing
    type(canonical_interval_t), intent(in) :: interval
    type(canonical_numerical_config_t), intent(in) :: config
    type(canonical_result_t), intent(out) :: result
    procedure(canonical_subinterval_target_selector), optional :: target_selector
    class(canonical_subinterval_selection_t), intent(inout), optional :: selection

    class(transaction_state_t), allocatable :: working
    type(transaction_result_t) :: tx
    type(transaction_policy_t) :: transaction_policy
    type(transaction_interface_sensitivity_t) :: terminal_sensitivity
    real(real64) :: cursor, next_cursor, tol, transaction_t1, proposed_dt, proposal_factor
    real(real64) :: aggregate_bottom_exchange, terminal_bottom_flux, aggregate_transpiration
    logical :: aggregate_transpiration_available
    logical :: aggregate_mass_complete, aggregate_bottom_available, selector_valid, proposal_active, solver_limited
    integer :: isub, max_retries_cap

    result = canonical_result_t()
    terminal_sensitivity = transaction_interface_sensitivity_t()
    result%requested_t0 = interval%t0
    result%requested_t1 = interval%t1
    result%completed_t = interval%t0
    result%mass%interval_t0 = interval%t0
    result%mass%interval_t1 = interval%t1

    if (.not. allocated(committed) .or. interval%t1 <= interval%t0 .or. &
        config%max_committed_substeps <= 0 .or. config%progress_tolerance < 0.0_real64 .or. &
        (present(target_selector) .and. present(selection))) then
      result%status = CANONICAL_STATUS_INVALID_REQUEST
      return
    end if

    if (config%retain_accepted_step_proposal) then
      if (present(target_selector) .or. present(selection) .or. &
          config%transaction%temporal_mode /= TX_TEMPORAL_EXTERNAL_FULL_HALF) then
        result%status = CANONICAL_STATUS_INVALID_REQUEST
        return
      end if
    end if

    ! The externally committed physical state remains untouched until the full
    ! requested [t0,t1] interval has completed. Accepted internal substeps are
    ! committed only into this private working state. Sensitivity follows the
    ! same publication rule: only a fully completed canonical interval exposes
    ! result metadata from the accepted route.
    call committed%clone(working)
    call model%prepare_interval(forcing, interval, config)
    result%mass%missing_contribution_mask = TX_MASS_MISSING_NONE
    aggregate_mass_complete = .true.
    aggregate_transpiration_available=.true.
    aggregate_transpiration=0.0_real64
    aggregate_bottom_available = .true.
    aggregate_bottom_exchange = 0.0_real64
    terminal_bottom_flux = 0.0_real64
    cursor = interval%t0
    proposal_active = .false.
    proposed_dt = 0.0_real64
    solver_limited = .false.

    do isub = 1, config%max_committed_substeps
      transaction_t1 = interval%t1
      if (proposal_active) transaction_t1 = min(interval%t1, cursor + proposed_dt)
      max_retries_cap = config%transaction%max_retries
      selector_valid = .true.
      if (present(target_selector)) then
        call target_selector(cursor, interval%t1, transaction_t1, max_retries_cap, selector_valid)
      else if (present(selection)) then
        call selection%select(cursor, interval%t1, transaction_t1, max_retries_cap, selector_valid)
      end if
      tol = progress_tolerance(config%progress_tolerance, cursor, interval%t1)
      ! Choose the exact endpoint before execution, never relabel a solved trace.
      if (config%retain_accepted_step_proposal .and. proposal_active) then
        if (transaction_t1 < interval%t1 .and. interval%t1-transaction_t1 <= tol) transaction_t1 = interval%t1
      end if
      if (.not. selector_valid .or. .not. ieee_is_finite(transaction_t1) .or. &
          transaction_t1 <= cursor .or. transaction_t1 > interval%t1 .or. max_retries_cap < 0) then
        result%status = CANONICAL_STATUS_INVALID_REQUEST
        result%completed_t = cursor
        result%mass%missing_contribution_mask = ior(result%mass%missing_contribution_mask, &
             TX_MASS_MISSING_UNSPECIFIED)
        return
      end if

      ! The optional execution-policy selector may tighten, but can never
      ! relax, the caller-owned transaction retry budget.
      transaction_policy = config%transaction
      transaction_policy%max_retries = min(config%transaction%max_retries, max_retries_cap)
      call execute_reference_interval(model, working, cursor, transaction_t1, transaction_policy, tx)
      call accumulate_transaction(result, tx)

      if (tx%status /= TX_STATUS_ACCEPTED) then
        result%status = CANONICAL_STATUS_TRANSACTION_FAILED
        result%completed_t = cursor
        result%mass%missing_contribution_mask = ior(result%mass%missing_contribution_mask, &
             TX_MASS_MISSING_UNSPECIFIED)
        return
      end if

      call accumulate_accepted_mass(result, tx, aggregate_mass_complete)
      aggregate_transpiration_available=aggregate_transpiration_available.and.tx%actual_transpiration_available
      if(aggregate_transpiration_available) aggregate_transpiration=aggregate_transpiration+tx%actual_transpiration_amount
      call accumulate_accepted_bottom_interface(tx, aggregate_bottom_available, aggregate_bottom_exchange, &
           terminal_bottom_flux)
      terminal_sensitivity = tx%interface_sensitivity
      next_cursor = tx%accepted_t1
      if (next_cursor <= cursor .or. next_cursor > transaction_t1 + tol) then
        result%status = CANONICAL_STATUS_NO_PROGRESS
        result%completed_t = cursor
        result%mass%missing_contribution_mask = ior(result%mass%missing_contribution_mask, &
             TX_MASS_MISSING_UNSPECIFIED)
        return
      end if

      ! Solver rejection invalidates temporal-only growth for this interval.
      ! Policy memory is private and resets at the next requested interval.
      solver_limited = solver_limited .or. tx%solver_rejections > 0
      if (solver_limited) proposal_active = .false.
      if (config%retain_accepted_step_proposal .and. .not. solver_limited .and. &
          (proposal_active .or. tx%temporal_rejections > 0)) then
        proposal_factor = 2.0_real64
        ! Clamp before division: finite budget/tiny indicator must not overflow
        ! while calculating a proposal whose bounded factor is already known.
        if (tx%temporal_error > 0.0_real64) then
          if (tx%temporal_error > 0.2025_real64 * transaction_policy%temporal_tolerance) proposal_factor = &
               max(0.5_real64, min(2.0_real64, 0.9_real64 * sqrt(transaction_policy%temporal_tolerance / tx%temporal_error)))
        end if
        proposed_dt = tx%accepted_dt * proposal_factor
        proposal_active = ieee_is_finite(proposed_dt) .and. proposed_dt > 0.0_real64
      end if

      cursor = next_cursor
      result%diagnostics%committed_substeps = result%diagnostics%committed_substeps + 1
      result%completed_t = cursor

      if (abs(cursor - interval%t1) <= tol .and. &
          (.not. config%retain_accepted_step_proposal .or. cursor == interval%t1)) then
        call move_alloc(working, committed)
        result%status = CANONICAL_STATUS_COMPLETED
        result%completed = .true.
        result%diagnostics%external_commits = 1
        call finalize_interval_mass(result, aggregate_mass_complete)
        if (aggregate_bottom_available .and. ieee_is_finite(aggregate_bottom_exchange) .and. &
            ieee_is_finite(terminal_bottom_flux)) then
          result%bottom_interface_exchange_available = .true.
          result%bottom_outward_exchange_native = aggregate_bottom_exchange
          result%terminal_bottom_outward_flux_native = terminal_bottom_flux
        end if
        if(aggregate_transpiration_available.and.ieee_is_finite(aggregate_transpiration).and.aggregate_transpiration>=0.0_real64) then
          result%actual_transpiration_available=.true.
          result%actual_transpiration_amount=aggregate_transpiration
        end if
        result%interface_sensitivity = terminal_sensitivity
        if (result%interface_sensitivity%available) then
          result%interface_sensitivity%covers_requested_interval = &
               result%mass%accepted_transaction_count == 1 .and. &
               result%interface_sensitivity%origin_t0 == interval%t0 .and. &
               result%interface_sensitivity%origin_t1 == interval%t1
        end if
        ! Whole-window trajectory sensitivity has a separate semantic carrier.
        ! Only the fully accepted requested canonical interval may publish it.
        call model%accepted_trajectory_direction_snapshot(interval, result%accepted_trajectory_direction)
        return
      end if
    end do

    result%status = CANONICAL_STATUS_SUBSTEP_LIMIT
    result%completed_t = cursor
    result%mass%missing_contribution_mask = ior(result%mass%missing_contribution_mask, &
         TX_MASS_MISSING_UNSPECIFIED)
  end subroutine run_canonical_interval

  subroutine accumulate_accepted_mass(result, tx, aggregate_complete)
    type(canonical_result_t), intent(inout) :: result
    type(transaction_result_t), intent(in) :: tx
    logical, intent(inout) :: aggregate_complete

    if (tx%status /= TX_STATUS_ACCEPTED) return
    if (result%mass%accepted_transaction_count == 0) then
      result%mass%storage_start = tx%accepted_storage_start
    end if
    result%mass%storage_end = tx%accepted_storage_end
    result%mass%total_in = result%mass%total_in + tx%accepted_total_in
    result%mass%total_out = result%mass%total_out + tx%accepted_total_out
    result%mass%accepted_transaction_count = result%mass%accepted_transaction_count + 1
    result%mass%missing_contribution_mask = ior(result%mass%missing_contribution_mask, &
         tx%accepted_missing_contribution_mask)
    aggregate_complete = aggregate_complete .and. tx%accepted_mass_complete
  end subroutine accumulate_accepted_mass

  subroutine accumulate_accepted_bottom_interface(tx, aggregate_available, aggregate_exchange, terminal_flux)
    type(transaction_result_t), intent(in) :: tx
    logical, intent(inout) :: aggregate_available
    real(real64), intent(inout) :: aggregate_exchange, terminal_flux
    real(real64) :: candidate_exchange

    if (tx%status /= TX_STATUS_ACCEPTED) return
    if (.not. aggregate_available) return
    if (.not. tx%bottom_interface_exchange_available) then
      aggregate_available = .false.
      aggregate_exchange = 0.0_real64
      terminal_flux = 0.0_real64
      return
    end if
    candidate_exchange = aggregate_exchange + tx%accepted_bottom_outward_exchange_native
    if (.not. ieee_is_finite(candidate_exchange) .or. &
        .not. ieee_is_finite(tx%terminal_bottom_outward_flux_native)) then
      aggregate_available = .false.
      aggregate_exchange = 0.0_real64
      terminal_flux = 0.0_real64
      return
    end if
    aggregate_exchange = candidate_exchange
    terminal_flux = tx%terminal_bottom_outward_flux_native
  end subroutine accumulate_accepted_bottom_interface

  subroutine finalize_interval_mass(result, aggregate_complete)
    type(canonical_result_t), intent(inout) :: result
    logical, intent(in) :: aggregate_complete
    logical :: finite_terms

    result%mass%storage_change = result%mass%storage_end - result%mass%storage_start
    result%mass%residual = result%mass%storage_change - &
         (result%mass%total_in - result%mass%total_out)
    finite_terms = ieee_is_finite(result%mass%interval_t0) .and. &
         ieee_is_finite(result%mass%interval_t1) .and. &
         ieee_is_finite(result%mass%storage_start) .and. &
         ieee_is_finite(result%mass%storage_end) .and. &
         ieee_is_finite(result%mass%storage_change) .and. &
         ieee_is_finite(result%mass%total_in) .and. &
         ieee_is_finite(result%mass%total_out) .and. ieee_is_finite(result%mass%residual)
    if (.not. finite_terms) then
      result%mass%missing_contribution_mask = ior(result%mass%missing_contribution_mask, &
           TX_MASS_MISSING_NONFINITE)
    end if
    if (result%mass%accepted_transaction_count <= 0) then
      result%mass%missing_contribution_mask = ior(result%mass%missing_contribution_mask, &
           TX_MASS_MISSING_UNSPECIFIED)
    end if
    result%mass%complete = aggregate_complete .and. finite_terms .and. &
         result%mass%accepted_transaction_count > 0 .and. &
         result%mass%missing_contribution_mask == TX_MASS_MISSING_NONE
    if (.not. result%mass%complete .and. &
        result%mass%missing_contribution_mask == TX_MASS_MISSING_NONE) then
      result%mass%missing_contribution_mask = TX_MASS_MISSING_UNSPECIFIED
    end if
  end subroutine finalize_interval_mass

  subroutine accumulate_transaction(result, tx)
    type(canonical_result_t), intent(inout) :: result
    type(transaction_result_t), intent(in) :: tx

    result%diagnostics%transaction_calls = result%diagnostics%transaction_calls + 1
    result%diagnostics%attempts = result%diagnostics%attempts + tx%attempts
    result%diagnostics%retries = result%diagnostics%retries + tx%retries
    result%diagnostics%rollbacks = result%diagnostics%rollbacks + tx%rollbacks
    result%diagnostics%solver_rejections = result%diagnostics%solver_rejections + tx%solver_rejections
    result%diagnostics%temporal_rejections = result%diagnostics%temporal_rejections + tx%temporal_rejections
    result%diagnostics%temporal_certificate_unavailable_rejections = &
         result%diagnostics%temporal_certificate_unavailable_rejections + &
         tx%temporal_certificate_unavailable_rejections
    if (result%diagnostics%temporal_acceptance_source == TX_TEMPORAL_NONE) then
      result%diagnostics%temporal_acceptance_source = tx%temporal_acceptance_source
    else if (tx%temporal_acceptance_source /= TX_TEMPORAL_NONE .and. &
             tx%temporal_acceptance_source /= result%diagnostics%temporal_acceptance_source) then
      result%diagnostics%temporal_acceptance_source = TX_TEMPORAL_NONE
    end if
    result%diagnostics%mass_rejections = result%diagnostics%mass_rejections + tx%mass_rejections
    result%diagnostics%nonlinear_iterations = result%diagnostics%nonlinear_iterations + tx%nonlinear_iterations
    result%diagnostics%internal_retries = result%diagnostics%internal_retries + tx%internal_retries
    result%diagnostics%headcalc_calls = result%diagnostics%headcalc_calls + tx%headcalc_calls
    result%diagnostics%jacobian_builds = result%diagnostics%jacobian_builds + tx%jacobian_builds
    result%diagnostics%linear_solves = result%diagnostics%linear_solves + tx%linear_solves
    result%diagnostics%backtracking_attempts = result%diagnostics%backtracking_attempts + tx%backtracking_attempts
    result%diagnostics%alternative_solver_calls = result%diagnostics%alternative_solver_calls + &
         tx%alternative_solver_calls
    result%diagnostics%workspace_full_resets = result%diagnostics%workspace_full_resets + tx%workspace_full_resets
    result%diagnostics%workspace_zeroed_bytes = result%diagnostics%workspace_zeroed_bytes + tx%workspace_zeroed_bytes
    if (ieee_is_finite(tx%temporal_indicator) .and. tx%temporal_indicator >= 0.0_real64) then
      result%diagnostics%max_temporal_indicator = max(result%diagnostics%max_temporal_indicator, &
           tx%temporal_indicator)
    end if
    if (tx%status == TX_STATUS_ACCEPTED) then
      if (tx%temporal_acceptance_source == TX_TEMPORAL_MODEL_CERTIFICATE) then
        result%diagnostics%max_abs_step_mass_residual = max(result%diagnostics%max_abs_step_mass_residual, &
             abs(tx%accepted_mass_residual))
      else
        result%diagnostics%max_abs_step_mass_residual = max(result%diagnostics%max_abs_step_mass_residual, &
             abs(tx%full_mass_residual), abs(tx%half_mass_residual))
      end if
      result%diagnostics%min_accepted_substep_duration = min(result%diagnostics%min_accepted_substep_duration, &
           tx%accepted_dt)
      result%diagnostics%max_accepted_substep_duration = max(result%diagnostics%max_accepted_substep_duration, &
           tx%accepted_dt)
    end if
  end subroutine accumulate_transaction

  pure real(real64) function progress_tolerance(user_tolerance, t0, t1) result(tol)
    real(real64), intent(in) :: user_tolerance, t0, t1
    tol = max(user_tolerance, 64.0_real64 * epsilon(1.0_real64) * &
         max(1.0_real64, abs(t0), abs(t1)))
  end function progress_tolerance

end module mod_canonical_interval_runtime
