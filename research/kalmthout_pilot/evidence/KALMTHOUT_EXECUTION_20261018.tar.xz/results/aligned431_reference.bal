* Project:       hupsel
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 09:18:16

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        85.54 cm       0.0000E+00 mg/cm2
Initial :        69.18 cm       0.0000E+00 mg/cm2
            =============       =================
Change           16.36 cm       0.0000E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :    19.15
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    71.59
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    90.73


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.0000E+00


Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        78.46 cm       0.0000E+00 mg/cm2
Initial :        85.54 cm       0.0000E+00 mg/cm2
            =============       =================
Change           -7.07 cm       0.0000E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    13.42
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    53.73
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    67.14


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.0000E+00


Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  200.00 cm

            Water storage          Solute storage
Final   :        71.90 cm       0.0000E+00 mg/cm2
Initial :        78.46 cm       0.0000E+00 mg/cm2
            =============       =================
Change           -6.56 cm       0.0000E+00 mg/cm2


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     7.47
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    53.59
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    61.06


Solute balance components (mg/cm2)

In                           Out
=========================    ============================
Rain        :  0.0000E+00    Decomposition  :  0.0000E+00
Irrigation  :  0.0000E+00    Root uptake    :  0.0000E+00
Bottom flux :  0.0000E+00
                             Drainage       :  0.0000E+00
=========================    ============================
Sum         :  0.0000E+00    Sum            :  0.0000E+00

