* Project:       KAL_0042_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:41:56

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        25.84 cm
Initial :        30.47 cm
            =============
Change           -4.62 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -45.11    Soil evaporation  :    66.61
                             Crack flux        :     0.00
=========================    ============================
Sum            :    61.98    Sum               :    66.61

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        24.57 cm
Initial :        25.84 cm
            =============
Change           -1.27 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -18.84    Soil evaporation  :    42.50
                             Crack flux        :     0.00
=========================    ============================
Sum            :    41.23    Sum               :    42.50

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        17.98 cm
Initial :        24.57 cm
            =============
Change           -6.59 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -15.51    Soil evaporation  :    45.58
                             Crack flux        :     0.00
=========================    ============================
Sum            :    38.99    Sum               :    45.58
