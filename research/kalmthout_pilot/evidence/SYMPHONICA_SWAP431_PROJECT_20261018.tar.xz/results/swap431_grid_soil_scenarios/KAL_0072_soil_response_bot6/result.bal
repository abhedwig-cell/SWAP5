* Project:       KAL_0072_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:41:58

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  130.00 cm

            Water storage
Final   :        48.58 cm
Initial :        20.57 cm
            =============
Change           28.01 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     8.60
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    70.47
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    79.08

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  130.00 cm

            Water storage
Final   :        28.09 cm
Initial :        48.58 cm
            =============
Change          -20.49 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    13.42
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    67.14
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    80.56

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  130.00 cm

            Water storage
Final   :        19.81 cm
Initial :        28.09 cm
            =============
Change           -8.28 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    62.78
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    62.78
