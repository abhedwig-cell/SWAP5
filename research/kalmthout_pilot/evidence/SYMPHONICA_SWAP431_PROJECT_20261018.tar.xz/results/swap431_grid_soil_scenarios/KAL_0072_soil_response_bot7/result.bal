* Project:       KAL_0072_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:42:01

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  130.00 cm

            Water storage
Final   :        16.83 cm
Initial :        20.57 cm
            =============
Change           -3.74 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -47.57    Soil evaporation  :    63.25
                             Crack flux        :     0.00
=========================    ============================
Sum            :    59.52    Sum               :    63.25

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  130.00 cm

            Water storage
Final   :        15.78 cm
Initial :        16.83 cm
            =============
Change           -1.05 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -22.23    Soil evaporation  :    38.90
                             Crack flux        :     0.00
=========================    ============================
Sum            :    37.84    Sum               :    38.90

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  130.00 cm

            Water storage
Final   :        12.66 cm
Initial :        15.78 cm
            =============
Change           -3.11 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -15.55    Soil evaporation  :    42.07
                             Crack flux        :     0.00
=========================    ============================
Sum            :    38.95    Sum               :    42.07
