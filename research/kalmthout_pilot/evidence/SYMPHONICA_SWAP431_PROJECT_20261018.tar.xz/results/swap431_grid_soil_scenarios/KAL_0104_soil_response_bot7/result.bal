* Project:       KAL_0104_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:42:42

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        34.38 cm
Initial :        37.11 cm
            =============
Change           -2.73 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -39.78    Soil evaporation  :    70.04
                             Crack flux        :     0.00
=========================    ============================
Sum            :    67.31    Sum               :    70.04

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        29.67 cm
Initial :        34.38 cm
            =============
Change           -4.71 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -14.55    Soil evaporation  :    50.23
                             Crack flux        :     0.00
=========================    ============================
Sum            :    45.52    Sum               :    50.23

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        20.31 cm
Initial :        29.67 cm
            =============
Change           -9.35 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -10.93    Soil evaporation  :    52.93
                             Crack flux        :     0.00
=========================    ============================
Sum            :    43.57    Sum               :    52.93
