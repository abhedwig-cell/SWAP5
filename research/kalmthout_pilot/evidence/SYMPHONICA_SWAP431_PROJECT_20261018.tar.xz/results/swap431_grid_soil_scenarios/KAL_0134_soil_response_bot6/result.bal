* Project:       KAL_0134_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:41:46

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        57.99 cm
Initial :        34.56 cm
            =============
Change           23.42 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :    12.58
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    71.09
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    83.67

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        31.18 cm
Initial :        57.99 cm
            =============
Change          -26.81 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    13.42
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    73.46
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    86.88

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        22.71 cm
Initial :        31.18 cm
            =============
Change           -8.47 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    62.97
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    62.97
