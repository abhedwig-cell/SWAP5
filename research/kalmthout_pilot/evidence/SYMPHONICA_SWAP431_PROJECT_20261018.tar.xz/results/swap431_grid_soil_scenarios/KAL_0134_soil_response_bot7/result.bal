* Project:       KAL_0134_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:41:48

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        30.26 cm
Initial :        34.56 cm
            =============
Change           -4.31 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -42.03    Soil evaporation  :    69.37
                             Crack flux        :     0.00
=========================    ============================
Sum            :    65.06    Sum               :    69.37

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        28.34 cm
Initial :        30.26 cm
            =============
Change           -1.92 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -15.61    Soil evaporation  :    46.38
                             Crack flux        :     0.00
=========================    ============================
Sum            :    44.46    Sum               :    46.38

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        18.95 cm
Initial :        28.34 cm
            =============
Change           -9.38 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -14.64    Soil evaporation  :    49.25
                             Crack flux        :     0.00
=========================    ============================
Sum            :    39.86    Sum               :    49.25
