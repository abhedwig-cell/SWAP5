* Project:       KAL_0136_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:43:05

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        21.06 cm
Initial :        23.55 cm
            =============
Change           -2.49 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -46.43    Soil evaporation  :    63.15
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.66    Sum               :    63.15

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        19.97 cm
Initial :        21.06 cm
            =============
Change           -1.09 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -22.11    Soil evaporation  :    39.06
                             Crack flux        :     0.00
=========================    ============================
Sum            :    37.96    Sum               :    39.06

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        16.64 cm
Initial :        19.97 cm
            =============
Change           -3.33 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -15.70    Soil evaporation  :    42.13
                             Crack flux        :     0.00
=========================    ============================
Sum            :    38.80    Sum               :    42.13
