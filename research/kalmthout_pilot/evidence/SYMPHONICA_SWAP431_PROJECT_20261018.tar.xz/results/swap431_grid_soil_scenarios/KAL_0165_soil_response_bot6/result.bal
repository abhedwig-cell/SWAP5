* Project:       KAL_0165_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:43:48

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  110.00 cm

            Water storage
Final   :        41.80 cm
Initial :        18.42 cm
            =============
Change           23.38 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :    12.60
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    71.11
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    83.71

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  110.00 cm

            Water storage
Final   :        24.17 cm
Initial :        41.80 cm
            =============
Change          -17.63 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    13.42
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    64.28
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    77.70

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  110.00 cm

            Water storage
Final   :        15.53 cm
Initial :        24.17 cm
            =============
Change           -8.64 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    63.14
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    63.14
