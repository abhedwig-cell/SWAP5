* Project:       KAL_0165_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:43:50

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  110.00 cm

            Water storage
Final   :        16.35 cm
Initial :        18.42 cm
            =============
Change           -2.07 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -44.78    Soil evaporation  :    64.38
                             Crack flux        :     0.00
=========================    ============================
Sum            :    62.31    Sum               :    64.38

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  110.00 cm

            Water storage
Final   :        15.64 cm
Initial :        16.35 cm
            =============
Change           -0.72 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -21.40    Soil evaporation  :    39.39
                             Crack flux        :     0.00
=========================    ============================
Sum            :    38.67    Sum               :    39.39

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  110.00 cm

            Water storage
Final   :        12.37 cm
Initial :        15.64 cm
            =============
Change           -3.27 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -14.97    Soil evaporation  :    42.80
                             Crack flux        :     0.00
=========================    ============================
Sum            :    39.53    Sum               :    42.80
