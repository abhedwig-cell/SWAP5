* Project:       KAL_0168_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:44:04

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        16.08 cm
Initial :        17.43 cm
            =============
Change           -1.35 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -46.17    Soil evaporation  :    62.27
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.92    Sum               :    62.27

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        15.22 cm
Initial :        16.08 cm
            =============
Change           -0.86 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -22.78    Soil evaporation  :    38.15
                             Crack flux        :     0.00
=========================    ============================
Sum            :    37.29    Sum               :    38.15

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        13.10 cm
Initial :        15.22 cm
            =============
Change           -2.12 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -15.44    Soil evaporation  :    41.18
                             Crack flux        :     0.00
=========================    ============================
Sum            :    39.06    Sum               :    41.18
