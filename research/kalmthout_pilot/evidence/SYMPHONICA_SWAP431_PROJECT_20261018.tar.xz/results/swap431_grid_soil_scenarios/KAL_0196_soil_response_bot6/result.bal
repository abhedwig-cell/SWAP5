* Project:       KAL_0196_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:41:40

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  110.00 cm

            Water storage
Final   :        42.75 cm
Initial :        32.42 cm
            =============
Change           10.33 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :    24.71
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    72.05
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    96.76

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  110.00 cm

            Water storage
Final   :        33.91 cm
Initial :        42.75 cm
            =============
Change           -8.84 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    13.42
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    55.49
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    68.91

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  110.00 cm

            Water storage
Final   :        25.52 cm
Initial :        33.91 cm
            =============
Change           -8.39 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     5.76
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    57.13
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    62.89
