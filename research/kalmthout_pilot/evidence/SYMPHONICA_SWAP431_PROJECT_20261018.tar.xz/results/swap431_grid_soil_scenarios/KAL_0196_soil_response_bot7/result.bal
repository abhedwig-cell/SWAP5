* Project:       KAL_0196_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:41:44

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  110.00 cm

            Water storage
Final   :        27.94 cm
Initial :        32.42 cm
            =============
Change           -4.48 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -51.11    Soil evaporation  :    60.46
                             Crack flux        :     0.00
=========================    ============================
Sum            :    55.98    Sum               :    60.46

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  110.00 cm

            Water storage
Final   :        26.04 cm
Initial :        27.94 cm
            =============
Change           -1.91 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -23.78    Soil evaporation  :    38.20
                             Crack flux        :     0.00
=========================    ============================
Sum            :    36.29    Sum               :    38.20

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  110.00 cm

            Water storage
Final   :        22.15 cm
Initial :        26.04 cm
            =============
Change           -3.89 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -18.64    Soil evaporation  :    39.74
                             Crack flux        :     0.00
=========================    ============================
Sum            :    35.86    Sum               :    39.74
