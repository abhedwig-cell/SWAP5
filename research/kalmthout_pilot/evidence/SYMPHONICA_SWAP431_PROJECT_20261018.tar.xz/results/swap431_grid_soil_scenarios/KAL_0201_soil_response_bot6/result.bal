* Project:       KAL_0201_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:50:54

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :   80.00 cm

            Water storage
Final   :        30.41 cm
Initial :        10.85 cm
            =============
Change           19.57 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :    15.87
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    71.66
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    87.53

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :   80.00 cm

            Water storage
Final   :        19.04 cm
Initial :        30.41 cm
            =============
Change          -11.37 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    13.42
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    58.02
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    71.44

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :   80.00 cm

            Water storage
Final   :         9.89 cm
Initial :        19.04 cm
            =============
Change           -9.15 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     3.27
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    60.38
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    63.65
