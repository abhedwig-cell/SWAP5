* Project:       KAL_0201_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:51:10

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :   80.00 cm

            Water storage
Final   :         8.70 cm
Initial :        10.85 cm
            =============
Change           -2.15 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -55.16    Soil evaporation  :    54.08
                             Crack flux        :     0.00
=========================    ============================
Sum            :    51.93    Sum               :    54.08

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :   80.00 cm

            Water storage
Final   :         8.11 cm
Initial :         8.70 cm
            =============
Change           -0.59 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -26.04    Soil evaporation  :    34.62
                             Crack flux        :     0.00
=========================    ============================
Sum            :    34.03    Sum               :    34.62

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :   80.00 cm

            Water storage
Final   :         8.33 cm
Initial :         8.11 cm
            =============
Change            0.22 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -18.94    Soil evaporation  :    35.34
                             Crack flux        :     0.00
=========================    ============================
Sum            :    35.56    Sum               :    35.34
