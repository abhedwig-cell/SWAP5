* Project:       KAL_0259_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:45:43

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        35.80 cm
Initial :        38.86 cm
            =============
Change           -3.06 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -44.71    Soil evaporation  :    65.44
                             Crack flux        :     0.00
=========================    ============================
Sum            :    62.38    Sum               :    65.44

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        34.79 cm
Initial :        35.80 cm
            =============
Change           -1.01 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -17.31    Soil evaporation  :    43.77
                             Crack flux        :     0.00
=========================    ============================
Sum            :    42.76    Sum               :    43.77

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        28.48 cm
Initial :        34.79 cm
            =============
Change           -6.31 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -15.15    Soil evaporation  :    45.67
                             Crack flux        :     0.00
=========================    ============================
Sum            :    39.35    Sum               :    45.67
