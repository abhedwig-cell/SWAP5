* Project:       KAL_0321_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:45:57

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        39.28 cm
Initial :        41.66 cm
            =============
Change           -2.38 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -39.43    Soil evaporation  :    70.04
                             Crack flux        :     0.00
=========================    ============================
Sum            :    67.66    Sum               :    70.04

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        33.36 cm
Initial :        39.28 cm
            =============
Change           -5.92 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -14.69    Soil evaporation  :    51.30
                             Crack flux        :     0.00
=========================    ============================
Sum            :    45.38    Sum               :    51.30

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        24.06 cm
Initial :        33.36 cm
            =============
Change           -9.30 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :    -9.85    Soil evaporation  :    53.96
                             Crack flux        :     0.00
=========================    ============================
Sum            :    44.65    Sum               :    53.96
