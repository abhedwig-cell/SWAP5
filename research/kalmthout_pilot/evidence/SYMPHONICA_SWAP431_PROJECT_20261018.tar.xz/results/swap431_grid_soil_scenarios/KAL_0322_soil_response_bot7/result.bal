* Project:       KAL_0322_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:46:01

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        34.17 cm
Initial :        37.76 cm
            =============
Change           -3.59 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -40.66    Soil evaporation  :    70.02
                             Crack flux        :     0.00
=========================    ============================
Sum            :    66.43    Sum               :    70.02

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        31.08 cm
Initial :        34.17 cm
            =============
Change           -3.09 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -15.43    Soil evaporation  :    47.73
                             Crack flux        :     0.00
=========================    ============================
Sum            :    44.64    Sum               :    47.73

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        21.52 cm
Initial :        31.08 cm
            =============
Change           -9.57 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -13.42    Soil evaporation  :    50.65
                             Crack flux        :     0.00
=========================    ============================
Sum            :    41.08    Sum               :    50.65
