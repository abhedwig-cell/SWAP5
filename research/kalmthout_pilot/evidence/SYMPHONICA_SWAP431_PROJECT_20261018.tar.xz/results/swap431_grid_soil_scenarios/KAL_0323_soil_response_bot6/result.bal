* Project:       KAL_0323_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:46:04

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        54.81 cm
Initial :        17.75 cm
            =============
Change           37.06 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    70.03
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    70.03

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        40.34 cm
Initial :        54.81 cm
            =============
Change          -14.47 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    12.43
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    62.11
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    74.54

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        33.18 cm
Initial :        40.34 cm
            =============
Change           -7.16 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    61.66
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    61.66
