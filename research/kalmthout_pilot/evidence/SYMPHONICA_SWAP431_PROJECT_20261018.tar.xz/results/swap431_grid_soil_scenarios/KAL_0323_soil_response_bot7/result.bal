* Project:       KAL_0323_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:46:15

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        14.05 cm
Initial :        17.75 cm
            =============
Change           -3.70 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -59.30    Soil evaporation  :    51.48
                             Crack flux        :     0.00
=========================    ============================
Sum            :    47.79    Sum               :    51.48

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        12.85 cm
Initial :        14.05 cm
            =============
Change           -1.21 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -28.87    Soil evaporation  :    32.41
                             Crack flux        :     0.00
=========================    ============================
Sum            :    31.20    Sum               :    32.41

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        13.13 cm
Initial :        12.85 cm
            =============
Change            0.29 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -21.50    Soil evaporation  :    32.71
                             Crack flux        :     0.00
=========================    ============================
Sum            :    33.00    Sum               :    32.71
