* Project:       KAL_0326_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:46:25

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        13.88 cm
Initial :        15.31 cm
            =============
Change           -1.43 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -48.41    Soil evaporation  :    60.11
                             Crack flux        :     0.00
=========================    ============================
Sum            :    58.68    Sum               :    60.11

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        13.00 cm
Initial :        13.88 cm
            =============
Change           -0.88 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -23.93    Soil evaporation  :    37.02
                             Crack flux        :     0.00
=========================    ============================
Sum            :    36.14    Sum               :    37.02

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        11.93 cm
Initial :        13.00 cm
            =============
Change           -1.07 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -16.02    Soil evaporation  :    39.55
                             Crack flux        :     0.00
=========================    ============================
Sum            :    38.48    Sum               :    39.55
