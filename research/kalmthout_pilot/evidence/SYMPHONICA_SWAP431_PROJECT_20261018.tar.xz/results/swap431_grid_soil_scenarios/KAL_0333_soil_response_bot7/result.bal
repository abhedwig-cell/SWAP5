* Project:       KAL_0333_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:47:05

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        14.81 cm
Initial :        18.69 cm
            =============
Change           -3.88 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -60.10    Soil evaporation  :    50.87
                             Crack flux        :     0.00
=========================    ============================
Sum            :    46.99    Sum               :    50.87

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        13.60 cm
Initial :        14.81 cm
            =============
Change           -1.21 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -29.03    Soil evaporation  :    32.25
                             Crack flux        :     0.00
=========================    ============================
Sum            :    31.04    Sum               :    32.25

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        13.90 cm
Initial :        13.60 cm
            =============
Change            0.30 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -21.81    Soil evaporation  :    32.39
                             Crack flux        :     0.00
=========================    ============================
Sum            :    32.69    Sum               :    32.39
