* Project:       KAL_0356_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:48:06

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  120.00 cm

            Water storage
Final   :        45.21 cm
Initial :        18.61 cm
            =============
Change           26.60 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     9.91
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    70.58
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    80.49

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  120.00 cm

            Water storage
Final   :        25.20 cm
Initial :        45.21 cm
            =============
Change          -20.01 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    13.42
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    66.67
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    80.08

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  120.00 cm

            Water storage
Final   :        17.21 cm
Initial :        25.20 cm
            =============
Change           -7.99 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    62.49
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    62.49
