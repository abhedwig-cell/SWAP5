* Project:       KAL_0356_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:48:12

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  120.00 cm

            Water storage
Final   :        16.57 cm
Initial :        18.61 cm
            =============
Change           -2.04 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -47.13    Soil evaporation  :    62.00
                             Crack flux        :     0.00
=========================    ============================
Sum            :    59.96    Sum               :    62.00

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  120.00 cm

            Water storage
Final   :        15.80 cm
Initial :        16.57 cm
            =============
Change           -0.77 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -22.12    Soil evaporation  :    38.72
                             Crack flux        :     0.00
=========================    ============================
Sum            :    37.95    Sum               :    38.72

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  120.00 cm

            Water storage
Final   :        13.91 cm
Initial :        15.80 cm
            =============
Change           -1.88 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -14.94    Soil evaporation  :    41.44
                             Crack flux        :     0.00
=========================    ============================
Sum            :    39.56    Sum               :    41.44
