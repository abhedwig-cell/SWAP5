* Project:       KAL_0418_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:51:56

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        28.38 cm
Initial :        31.27 cm
            =============
Change           -2.90 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -50.86    Soil evaporation  :    59.12
                             Crack flux        :     0.00
=========================    ============================
Sum            :    56.23    Sum               :    59.12

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        27.35 cm
Initial :        28.38 cm
            =============
Change           -1.03 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -24.19    Soil evaporation  :    36.91
                             Crack flux        :     0.00
=========================    ============================
Sum            :    35.88    Sum               :    36.91

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        26.07 cm
Initial :        27.35 cm
            =============
Change           -1.28 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -16.74    Soil evaporation  :    39.04
                             Crack flux        :     0.00
=========================    ============================
Sum            :    37.76    Sum               :    39.04
