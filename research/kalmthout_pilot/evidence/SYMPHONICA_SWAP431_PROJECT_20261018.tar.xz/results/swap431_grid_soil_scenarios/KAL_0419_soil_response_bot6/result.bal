* Project:       KAL_0419_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:51:59

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        55.57 cm
Initial :        11.65 cm
            =============
Change           43.92 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.66
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    62.51
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    63.17

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        46.33 cm
Initial :        55.57 cm
            =============
Change           -9.24 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    13.43
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    55.89
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    69.32

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        37.96 cm
Initial :        46.33 cm
            =============
Change           -8.38 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     5.37
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    57.51
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    62.88
