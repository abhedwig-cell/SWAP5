* Project:       KAL_0419_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:53:18

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        10.68 cm
Initial :        11.65 cm
            =============
Change           -0.98 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -64.31    Soil evaporation  :    43.76
                             Crack flux        :     0.00
=========================    ============================
Sum            :    42.78    Sum               :    43.76

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :         9.86 cm
Initial :        10.68 cm
            =============
Change           -0.82 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -33.06    Soil evaporation  :    27.83
                             Crack flux        :     0.00
=========================    ============================
Sum            :    27.01    Sum               :    27.83

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        10.78 cm
Initial :         9.86 cm
            =============
Change            0.92 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -26.09    Soil evaporation  :    27.48
                             Crack flux        :     0.00
=========================    ============================
Sum            :    28.41    Sum               :    27.48
