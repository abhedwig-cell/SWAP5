* Project:       KAL_0450_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:53:21

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        55.48 cm
Initial :        16.75 cm
            =============
Change           38.73 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    68.36
                             Crack flux        :     0.00
=========================    ============================
Sum            :   107.09    Sum               :    68.36

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        44.07 cm
Initial :        55.48 cm
            =============
Change          -11.40 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :    12.94
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    58.53
                             Crack flux        :     0.00
=========================    ============================
Sum            :    60.07    Sum               :    71.47

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        36.26 cm
Initial :        44.07 cm
            =============
Change           -7.81 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     2.77
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :     0.00    Soil evaporation  :    59.54
                             Crack flux        :     0.00
=========================    ============================
Sum            :    54.50    Sum               :    62.31
