* Project:       KAL_0450_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:53:37

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        15.40 cm
Initial :        16.75 cm
            =============
Change           -1.35 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -53.76    Soil evaporation  :    54.68
                             Crack flux        :     0.00
=========================    ============================
Sum            :    53.33    Sum               :    54.68

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        14.43 cm
Initial :        15.40 cm
            =============
Change           -0.97 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -27.33    Soil evaporation  :    33.71
                             Crack flux        :     0.00
=========================    ============================
Sum            :    32.74    Sum               :    33.71

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        14.50 cm
Initial :        14.43 cm
            =============
Change            0.07 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -19.61    Soil evaporation  :    34.82
                             Crack flux        :     0.00
=========================    ============================
Sum            :    34.89    Sum               :    34.82
