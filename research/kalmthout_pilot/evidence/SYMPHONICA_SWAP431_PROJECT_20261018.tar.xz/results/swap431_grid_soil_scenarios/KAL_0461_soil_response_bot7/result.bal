* Project:       KAL_0461_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:53:51

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        18.17 cm
Initial :        22.63 cm
            =============
Change           -4.46 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -58.98    Soil evaporation  :    52.57
                             Crack flux        :     0.00
=========================    ============================
Sum            :    48.11    Sum               :    52.57

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        16.73 cm
Initial :        18.17 cm
            =============
Change           -1.43 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -28.86    Soil evaporation  :    32.65
                             Crack flux        :     0.00
=========================    ============================
Sum            :    31.21    Sum               :    32.65

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        16.71 cm
Initial :        16.73 cm
            =============
Change           -0.02 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -21.26    Soil evaporation  :    33.26
                             Crack flux        :     0.00
=========================    ============================
Sum            :    33.24    Sum               :    33.26
