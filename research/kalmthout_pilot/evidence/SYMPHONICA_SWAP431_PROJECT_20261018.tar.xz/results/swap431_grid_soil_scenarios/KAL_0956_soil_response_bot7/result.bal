* Project:       KAL_0956_soil_response
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-18 10:41:33

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        13.87 cm
Initial :        16.27 cm
            =============
Change           -2.40 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -50.58    Soil evaporation  :    58.91
                             Crack flux        :     0.00
=========================    ============================
Sum            :    56.51    Sum               :    58.91

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  150.00 cm

            Water storage
Final   :        12.81 cm
Initial :        13.87 cm
            =============
Change           -1.06 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -24.74    Soil evaporation  :    36.39
                             Crack flux        :     0.00
=========================    ============================
Sum            :    35.33    Sum               :    36.39

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  150.00 cm

            Water storage
Final   :        11.95 cm
Initial :        12.81 cm
            =============
Change           -0.85 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :     0.00
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :     0.00
Bottom flux    :   -16.88    Soil evaporation  :    38.47
                             Crack flux        :     0.00
=========================    ============================
Sum            :    37.62    Sum               :    38.47
