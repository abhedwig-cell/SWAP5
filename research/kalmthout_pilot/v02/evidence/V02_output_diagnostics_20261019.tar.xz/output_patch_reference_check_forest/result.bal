* Project:       K250_00007
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-19 11:25:21

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        50.33 cm
Initial :        82.83 cm
            =============
Change          -32.50 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :    42.56
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    36.96
Bottom flux    :   -43.65    Soil evaporation  :    16.42
                             Crack flux        :     0.00
=========================    ============================
Sum            :    63.44    Sum               :    95.94

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        43.32 cm
Initial :        50.33 cm
            =============
Change           -7.01 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :    28.97
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    17.86
Bottom flux    :    -4.47    Soil evaporation  :    15.77
                             Crack flux        :     0.00
=========================    ============================
Sum            :    55.60    Sum               :    62.61

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  200.00 cm

            Water storage
Final   :        38.17 cm
Initial :        43.32 cm
            =============
Change           -5.15 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :    27.02
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    17.91
Bottom flux    :    -1.18    Soil evaporation  :    13.55
                             Crack flux        :     0.00
=========================    ============================
Sum            :    53.32    Sum               :    58.47
