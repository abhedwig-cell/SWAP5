* Project:       K250_00001
* File content:  overview of actual water and solute balance components
* File name:     result.bal
* Model version: Swap 4.3.1
* Generated at:  2026-10-19 11:15:49

Period             :  2024-01-01  until  2024-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        66.58 cm
Initial :        84.79 cm
            =============
Change          -18.21 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :   107.09    Interception      :    16.16
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    25.41
Bottom flux    :   -56.04    Soil evaporation  :    27.70
                             Crack flux        :     0.00
=========================    ============================
Sum            :    51.05    Sum               :    69.27

Period             :  2025-01-01  until  2025-12-31 
Depth soil profile :  200.00 cm

            Water storage
Final   :        55.76 cm
Initial :        66.58 cm
            =============
Change          -10.82 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    60.07    Interception      :    11.24
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    19.20
Bottom flux    :   -17.57    Soil evaporation  :    22.87
                             Crack flux        :     0.00
=========================    ============================
Sum            :    42.50    Sum               :    53.32

Period             :  2025-01-01  until  2026-10-01 
Depth soil profile :  200.00 cm

            Water storage
Final   :        49.90 cm
Initial :        55.76 cm
            =============
Change           -5.86 cm


Water balance components (cm)

In                           Out
=========================    ============================
Rain + snow    :    54.50    Interception      :    10.60
Runon          :     0.00    Runoff            :     0.00
SSDI           :     0.00
Irrigation     :     0.00    Transpiration     :    20.78
Bottom flux    :    -8.51    Soil evaporation  :    20.44
                             Crack flux        :     0.00
=========================    ============================
Sum            :    45.99    Sum               :    51.82
