
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
int audit_fork_begin(void){pid_t p=fork();int s=0;if(p==0){alarm(3);return 0;}if(p<0)return -1;while(waitpid(p,&s,0)<0){if(errno!=EINTR)return -2;}return WIFEXITED(s)&&WEXITSTATUS(s)==0?1:-3;}
void audit_fork_end(void){_exit(0);}
