from pathlib import Path
import hashlib,json,platform,subprocess,zipfile
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m={'compiler_version':subprocess.check_output([str(r/'compiler/root/usr/bin/x86_64-linux-gnu-gfortran-14'),'--version'],text=True).splitlines()[0],
 'compiler_sha256':sha(r/'compiler/root/usr/bin/x86_64-linux-gnu-gfortran-14'),'frontend_sha256':sha(r/'compiler/root/usr/libexec/gcc/x86_64-linux-gnu/14/f951'),
 'platform':platform.platform(),'flags':['-O2','-cpp','-Dlinux','-finit-local-zero','-ffree-line-length-none','-fallow-argument-mismatch'],
 'link_flags':['-B/usr/lib/gcc/x86_64-linux-gnu/14/'],'ttutil_flags':['-O2','-finit-local-zero','free/fixed-line-length-none'],
 'archive_sha256':sha(r/'SWAP.ZIP'),'ttutil_sha256':sha(r/'distribution/tools/SWAP/source/TTUTIL.ZIP'),
 'deb_packages':{p.name:sha(p) for p in (r/'compiler').glob('*.deb')},
 'raw_sources':{p.name:sha(p) for p in (r/'b0/SWAP').glob('*.f90')},
 'selected_sources':{p.name:sha(p) for p in (r/'build/swap-selected').glob('*.f90')},
 'objects':{p.name:sha(p) for p in (r/'build/swap-obj').glob('*.o')},
 'ttutil_library_sha256':sha(r/'build/ttutil-obj/libttutil.a'),
 'observer_sources':{p.name:sha(p) for p in (r/'observer').glob('*') if p.suffix in ['.f90','.c']},
 'notes':['Documented Intel DEC platform/feature selection on separate build copies; all63 raw B0 members untouched',
 'Full outer distribution archive not retrieved/reverified; nested source archive and member manifest independently verified',
 'GNU14.2-O2 profile only, not Intel or cross-platform equivalence',
 'First link failed due relocated liblto path; explicit -B system GCC directory fixed link only',
 'Initial invocation outside case directory failed to locate swap.bbc before any water calculation; retained under setup-failures']}
(r/'BUILD_IDENTITY.json').write_text(json.dumps(m,indent=2)+'\n')
files=['PREREGISTRATION.json','RESULT.json','RUNS.json','CASE_IDENTITY.json','BUILD_IDENTITY.json','OBSERVER_BUILD.json','file-manifest.sha256',
 'SWAP.ZIP','distribution/tools/SWAP/source/TTUTIL.ZIP','prepare_probe.py','assess.py','seal_evidence.py','observer/headcalc.f90','observer/fork.c',
 'build/swap_b0_gfortran','observer/swap_observer','evidence/tools/vq/b0_source_runner.py']
with zipfile.ZipFile(r/'B0_MACRO_AUDIT01_EVIDENCE.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in files:z.write(r/n,n)
 for p in (r/'build/swap-selected').iterdir():
  if p.is_file():z.write(p,str(p.relative_to(r)))
 for label in ['control','observer','control-output','observer-output']:
  for p in (r/('run-'+label)).rglob('*'):
   if p.is_file():z.write(p,str(p.relative_to(r)))
 for n in ['control.stdout','BUILD.log','original-case/swap.err','original-case/swap.log']:
  if (r/n).exists():z.write(r/n,'setup-failures/'+n)
p=r/'B0_MACRO_AUDIT01_EVIDENCE.zip'
meta={'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p),'git_blob_sha1':hashlib.sha1(b'blob '+str(p.stat().st_size).encode()+b'\0'+p.read_bytes()).hexdigest()}
(r/'EVIDENCE.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
