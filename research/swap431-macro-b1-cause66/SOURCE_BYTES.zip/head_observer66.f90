! TO DO
! module MOD_solve_Richards met public subroutine headcalc
!
! aangeven per variabelel: lokaal, input, output
! sommige globale variabelen mogelijk alleen voor headcalc?
!

! ----------------------------------------------------------------------
subroutine headcalc 
! ----------------------------------------------------------------------
!     date               : April 2005 / Sept 2005
!     purpose            : calculate pressure heads, water contents,
!                          and conductivities for next time step
! ----------------------------------------------------------------------
   ! input
   use MOD_swap_base,      only: swmacro, i_instance
   use MOD_arrays,         only: macp, mabbc
   use MOD_params,         only: nihil
   use MOD_grid,           only: numnod, z, dz, disnod
   use MOD_MvG,            only: watcon, hconduc, moiscap, dhconduc, cofgen
   use MOD_top,            only: q0, flrunoff, ftoph
   use MOD_meteo,          only: nraidt
   use MOD_macropore,      only: macropore
   use MOD_rootextraction, only: RootExtraction
   use MOD_snow,           only: melt
   use MOD_frost,          only: rfcp
   use MOD_top,            only: boundtop, pondrunoff, hsurf
   use MOD_drain,          only: qdra, nrlevs
   use MOD_irrigation,     only: qssdi, nird
   use variables,          only: fldaystart, swbotb, runon, epd, reva, pondm1, dt, runots, t1900, thetm1, qrot,      &
                                 swkimpl, swkmean, hplate, swbotb3impl, swbotb3resvert, deepgw, rimlay,              &
                                 sw4, qbotab, fldtmin, maxit, maxbacktr, critdevh2cp, critdevh1cp, critdevponddt,    &
                                 dtmin, nodgwl, gwlm1, hm1, CritDevBalCp, CritDevBalTot
   ! inout
   use variables,          only: h, theta, kmean, gwlinp, pond, dtold, qtop, qbot, hbot, itnumb
   ! output
   use variables,          only: fllowgwl, k, dimoca, numbit, fldecdt, gwl     ! note: K not always up-to-date at t+Dt

   ! macropore
   use MOD_swap_mp,        only: armpss, frarmtrx, qexcmpmtx, dfdhmp, ictopmp                        ! all input
   use MOD_swap_mp,        only: qmplatss, idecmprat                                                 ! input + output
   use MOD_swap_mp,        only: fldecmprat, fldecMPmbf                                              ! output
   use DIAG19,only:nvec,njac,nrate,nderiv,nback,nfresh,outcome,target,attempts,iter_index,node_u,op_u,detail33,op35_u,node35_u
   implicit none

!  diagnostic local storage only
   logical :: diag_active
   integer :: diag_u
   integer,save :: diag_counter=0
   character(64) :: diag_name
!  local
   integer                          :: i, j, itry,  MaxIt1, NN, iBackTr, ierror
   real(8), dimension(macp)         :: dFdhL, dFdhM, dFdhU     ! elements of Lower, Main and Upper diagonals in coeffcient matrix
   real(8), dimension(macp)         :: difh, F                 ! arrays in solution procedure
   real(8), dimension(macp)         :: sink, source            ! sink/source terms in Richards equation
   real(8), dimension(macp), save   :: dkdh = 0.0d0
   real(8), dimension(macp)         :: hold
   real(8), dimension(macp+1)       :: qv, hgrad
   real(8)                          :: factor, Fmax
   real(8)                          :: factmax, factmax1, sump, sum1, sumold, deviat, q1
   logical                          :: flnonconv, flnonconv3
   logical, dimension(macp)         :: flnonconv1, flnonconv2
   logical, dimension(3)            :: flunsatok               ! Flag indicating the performance of the iteration process
   logical                          :: flboth, flok
   logical, save                    :: flwarn
   integer, save                    :: iwarn, NStep
   character(len=200)               :: message
   character(len=19)                :: datetime
   character(len=10)                :: cval

!  macropore related
   real(8)                          :: QMpLatSsSav

!  functions
   real(8)                          :: hcomean

!  criteria
   real(8), parameter               :: Critdz = 1.0d-5

!---------------------------------------------------------------------

   call cause66_boundary(0)
   diag_active=.false.
   if(abs(t1900-35796.9513533331d0)<1d-9) inquire(file='active.marker',exist=diag_active)
   if(diag_active) then
    diag_counter=diag_counter+1
    write(diag_name,'(a,i0,a)') 'iterations_',diag_counter,'.txt'
    open(newunit=diag_u,file=trim(diag_name),status='replace')
   end if
!  reset some variables at the start of a new day
   if (fldaystart) then
      flwarn = .TRUE.
      iwarn  = 0
   end if
 
!  summation of sink terms (constant for the current time step)
   iBackTr        = 0
   flunsatok(1:3) = .FALSE.
   do i = 1, numnod
      sink(i) = 0.0d0
      do j = 1, nrlevs
         sink(i) = sink(i) + qdra(j,i)
      end do
   end do 
   source(1:numnod) = qssdi(1:numnod)

!  special case: groundwater level specified
   if (swbotb == 1) then
      fllowgwl = .FALSE.
      if (gwlinp >= z(1)-1.0d-4) then

         q0 = (nraidt+nird+melt)*(1.0d0-ArMpSs) + runon - reva - epd
         call pondrunoff ()
         q1 = - q0 + (pond - pondm1)/dt + runots/dt
         theta(1) = watcon(1,gwlinp)
         kmean(1) = hconduc(1,gwlinp,theta(1),rfcp(1))
!        in case of static macropores FrArMtrx < 1
         if (swmacro == 1) kmean(1) = FrArMtrx(1) * kmean(1)

         qv(1) = q1
         do i = 1, numnod
            qv(i+1) = qv(i) + dz(i)*FrArMtrx(i)*(theta(i)-thetm1(i)) / dt + sink(i) - source(i) + qrot(i) 
         end do
         qbot = qv(numnod+1)
         h(1) = gwlinp + disnod(1)*(qv(1)/kmean(1) + 1.0d0)
         do i = 2, numnod
            h(i) = h(i-1) + disnod(i)*(qv(i)/kmean(i) + 1.0d0)    ! gaat dit goed: immers kmean(i) nog behorend bij oude tijd???, maar K(1) werd wel eerst opnieuw berekend
         end do

!        special case: SwKimpl = 1
         if (SwKimpl == 1) then
            do i = 1, numnod
               k(i) = hconduc(i,h(i),theta(i),rfcp(i))
               if (swmacro == 1)  k(i) = FrArMtrx(i) * k(i)
               if (i > 1) then
                  kmean(i)=hcomean(swkmean,k(i-1),k(i),dz(i-1),dz(i), i, h(i-1), h(i))
               end if
            end do
            kmean(numnod+1) = k(numnod)                  
         end if
         !call calcgwl () replaced to call soilwater(3)
!        ready
         if(diag_active) close(diag_u)
         return
      else
         NN = 0
         do while (z(NN+1) > gwlinp .AND. NN < numnod)
            NN = NN + 1
         end do
         if (z(NN+1) < (gwlinp+nihil)) then
!           groundwater within soil profile
            if ((z(NN)-gwlinp) < 1.0d-4 .AND. (NN > 0)) then
!              difference gwlinp with node to small to calculate gradient properly
               gwlinp = z(NN)
               NN     = NN-1
            end if
         else
!           groundwater below soil profile
            fllowgwl = .TRUE.
            hbot     = gwlinp - z(numnod) + 0.5d0*dz(numnod)
         end if
      end if

   else
!     for all other swbotb cases
      NN = numnod
      if (swbotb == 9) NN = numnod - 1
   end if

!  reset conductivities (k, kmean) to time level t
   do i = 1, numnod
      k(i) = hconduc(i,h(i),theta(i),rfcp(i))
!
      if (swmacro == 1)  k(i)     = FrArMtrx(i) * k(i)
      if (i > 1)         kmean(i) = hcomean(swkmean,k(i-1),k(i),dz(i-1),dz(i), i, h(i-1), h(i))
   end do
   kmean(numnod+1) = k(numnod)

!  lower and upper diagnal elements
   if (SwKimpl == 0) then
      dFdhU = 0.0d0
      dFdhL = 0.0d0
      do i = 2, numnod
         dFdhU(i)   = - kmean(i)  /disnod(i)
         dFdhL(i-1) = dFdhU(i)
      end do
   end if

!  gradient in h
   do i = 2, NN
      hgrad(i) = (h(i-1)-h(i))/disnod(i) + 1.0d0
   end do

!  calculate vector F (first time)
   F = 0.0d0
   nvec=nvec+1
   call vector_F(1, hgrad)
   call cause66_boundary(1)
   block
    integer::u66
    open(newunit=u66,file='cause66_F0.txt',position='append',status='unknown')
    write(u66,*) attempts,NN,t1900,dt
    write(u66,*) F(1:NN)
    close(u66)
   end block

!  initial estimate of F inner product
   sumold = 0.5d0 * dot_product(F(1:NN), F(1:NN))

   call diag_log(0)
!  start iteration loop, MaxIt specified in the input
   MaxIt1 = MaxIt
   if (fldtmin .OR. fldecmprat) MaxIt1 = 2*MaxIt
   sump = 0.d0
   do numbit = 1, MaxIt1
      iter_index=numbit

!     store hold and get moiscap
      do i = 1, NN
         hold(i)   = h(i)
         dimoca(i) = moiscap(i, h(i))
      end do

!     special case: SwKimpl = 1
      if (SwKimpl == 1) then
         do i = 1, NN
            dkdh(i)= dhconduc(i,h(i),theta(i),dimoca(i),rfcp(i))
            if (swmacro == 1) dkdh(i) = FrArMtrx(i) * dkdh(i)
         end do
         do i = 2, NN
            dFdhU(i)   = - kmean(i) / disnod(i)
            dFdhL(i-1) = dFdhU(i)
         end do
      end if

!     incorporate Jacobian information in coefficient matrix elements
! FRESH22 localized candidate: current operator for original target head only.
      if(target) flunsatok(1:3)=.false.
      call diag_log(1)
      njac=njac+1
      call jacobian_F()
      call diag_log(2)
      if(detail33.and.attempts==293.and.iter_index==30) call probe35_maybe()
! REJECT26 retains the qualified analytic update; no repeated calibration replay.

!     solve the tridiagonal matrix
      if(target) then
       call jac24_solve(NN,dFdhU,dFdhM,dFdhL,F,difh,ierror)
      else
      call tridag(NN, dFdhU, dFdhM, dFdhL, F, difh, ierror)
      end if

!     in the rare case that TRIDAG fails, use alternative solution
      if (ierror /= 0) then
         call dtdpst ('year-month-day', t1900+1.001d0, datetime)
         write(cval,'(I10)') i_instance
         message = cval//' Tri-band matrix in HeadCalc appeared to be singular at '//adjustl(trim(datetime))//' Alternative SOLVER chosen'
         call swap_warning ('headcalc', message)
         call alternative_solver()
      end if

!     back tracking cycle
      factor = 1.0d0
      do itry = 1, MaxBackTr
         nback=nback+1
         iBackTr = iBackTr + 1
!        factor reduces the change of h (difh) calculated as a full Newton Raphson step

!        update h
         if (fldtmin .AND. numbit > MaxIt) then              
            factmax = 0.0d0
            do i = 1, NN
               if (dabs(hold(i) ) < 1.0d0 ) then
                  factmax = max(factmax, dabs(difh(i))) 
               else
                  factmax = max(factmax, dabs(difh(i) / hold(i)))
               end if
            end do
            factmax1 = min(1.0d0, 1.0d0 / factmax)
            do i = 1, NN
               h(i) = hold(i) - (difh(i) * factmax1) * factor
            end do
         else
            do i = 1, NN
               h(i) = hold(i) - factor * difh(i)
            end do
         end if

!        update theta
         do i = 1, NN
           theta(i) = watcon(i,h(i))
         end do

!        update gradient in h
         do i = 2, NN
            hgrad(i) = (h(i-1)-h(i))/disnod(i) + 1.0d0
         end do

!        special case: update k and kmean if SwKimpl = 1
         if (SwKimpl == 1) then
            call Rootextraction(2)
            do i = 1, NN
               k(i) = hconduc(i,h(i),theta(i),rfcp(i))
               if (swmacro == 1) k(i) = FrArMtrx(i) * k(i)
               if (i > 1) then
                  kmean(i) = hcomean(swkmean, k(i-1), k(i), dz(i-1), dz(i), i, h(i-1), h(i))
               end if
            end do
            kmean(NN+1) = k(NN)
         end if

!        re-calculate F-function
         nvec=nvec+1
         call vector_F(2, hgrad)

!        calculate maximum deviation per compartment and new inner product
         sump = 0.5d0 * dot_product(F(1:NN), F(1:NN))
         sum1 = sum(F(1:NN))
         Fmax = maxval(dabs(F(1:NN)))

         call diag_log(3)
!        test for iteration progress, if Newton-step is too large: reduce dh by multiplication factor
         if (sump < sumold .OR. Fmax < CritDevBalCp) goto 1
         factor = factor / 3.0d0

      end do
 1    continue

!     check on convergence of solution

!     initialize flags
!     main flag for testing the convergence
      flnonconv = .FALSE.

!     flags introduced for debugging purposes
      flnonconv1(1:numnod) = .FALSE.
      flnonconv2(1:numnod) = .FALSE.
      flnonconv3 = .FALSE.

!     apply performance criteria per compartment
      do i = 1, NN

!        test for water balance deviation of soil compartments
         if (dabs(F(i)) >  CritDevBalCp) then
            flnonconv1(i) = .TRUE.
            flnonconv     = .TRUE.
         end if

!        test for change of pressure head
         if (dabs(hold(i)) < 1.0d0) then
            if (abs(h(i)-hold(i) ) > CritDevh2Cp) then
               flnonconv2(i) = .TRUE.
               flnonconv     = .TRUE.
            end if
         else
            if (abs(h(i)-hold(i) )/abs(hold(i)) > CritDevh1Cp) then
               flnonconv2(i) = .TRUE.
               flnonconv     = .TRUE.
            end if
         end if
    
      end do

!     test for waterbalance of ponding layer
      if (ftoph) then
         qtop = -kmean(1)*((hsurf - h(1))/disnod(1) + 1.0d0)
         if (.NOT.flnonconv .AND. (swmacro == 0 .OR. IcTopMp > 1)) then
            deviat = pond - pondm1 + epd*dt + reva*dt - (nraidt+nird+Melt)*dt - runon*dt + runots - qtop * dt
            if (abs(deviat) > CritDevPondDt) then
               flnonconv3 = .TRUE.
               flnonconv  = .TRUE.
            end if
         end if
      end if

!     in case of macropores
      if (swmacro == 1 .AND. IcTopMp == 1) then
         deviat = pond - pondm1 + epd*dt + reva*dt - (nraidt+nird+Melt)*dt - runon*dt + runots - qtop * dt + ArMpSs * (nraidt+nird+Melt)*dt + QMpLatSs
         if (abs(deviat) > CritDevPondDt) then
            flnonconv3 = .TRUE.
            flnonconv  = .TRUE.
         end if
      end if
      if (swmacro == 1 .AND. fldecMPmbf) then
         flnonconv = .TRUE.
      end if
      

!     implemented to improve iteration performance in case of macropores
      if (dt <  0.01d0 .AND. swmacro == 1 .AND. .NOT.flnonconv3) then 
         flok = .TRUE.
         if (dt > 10.d0*dtmin) then
            do i = 1, nodgwl
               if (h(i) > 0.0d0 .AND. flnonconv1(i) .AND. flnonconv2(i)) flok = .FALSE.
            end do
         else
            continue
         end if
         if (flok) then
            if (.NOT.flunsatok(1)) then
               flunsatok(1) = .TRUE.
            else if (.NOT. flunsatok(2)) then
               flunsatok(2) = .TRUE.
            else
               flunsatok(3) = .TRUE.                 
            end if
         else
            flunsatok(1:3) = .FALSE.
         end if
      end if

!     B1 EXPERIMENT V1: certify the current coupled operator at provisional convergence.
      if (swmacro == 1 .AND. .NOT.flnonconv .AND. dabs(sum1) <= CritDevBalTot) then
         call diag_log(5)
         flunsatok(1:3) = .FALSE.
         nfresh=nfresh+1; nvec=nvec+1
         call vector_F(1,hgrad)
         call diag_log(6)
         sump = 0.5d0 * dot_product(F(1:NN),F(1:NN))
         sum1 = sum(F(1:NN))
         Fmax = maxval(dabs(F(1:NN)))
!     initialize flags
!     main flag for testing the convergence
      flnonconv = .FALSE.

!     flags introduced for debugging purposes
      flnonconv1(1:numnod) = .FALSE.
      flnonconv2(1:numnod) = .FALSE.
      flnonconv3 = .FALSE.

!     apply performance criteria per compartment
      do i = 1, NN

!        test for water balance deviation of soil compartments
         if (dabs(F(i)) >  CritDevBalCp) then
            flnonconv1(i) = .TRUE.
            flnonconv     = .TRUE.
         end if

!        test for change of pressure head
         if (dabs(hold(i)) < 1.0d0) then
            if (abs(h(i)-hold(i) ) > CritDevh2Cp) then
               flnonconv2(i) = .TRUE.
               flnonconv     = .TRUE.
            end if
         else
            if (abs(h(i)-hold(i) )/abs(hold(i)) > CritDevh1Cp) then
               flnonconv2(i) = .TRUE.
               flnonconv     = .TRUE.
            end if
         end if
    
      end do

!     test for waterbalance of ponding layer
      if (ftoph) then
         qtop = -kmean(1)*((hsurf - h(1))/disnod(1) + 1.0d0)
         if (.NOT.flnonconv .AND. (swmacro == 0 .OR. IcTopMp > 1)) then
            deviat = pond - pondm1 + epd*dt + reva*dt - (nraidt+nird+Melt)*dt - runon*dt + runots - qtop * dt
            if (abs(deviat) > CritDevPondDt) then
               flnonconv3 = .TRUE.
               flnonconv  = .TRUE.
            end if
         end if
      end if

!     in case of macropores
      if (swmacro == 1 .AND. IcTopMp == 1) then
         deviat = pond - pondm1 + epd*dt + reva*dt - (nraidt+nird+Melt)*dt - runon*dt + runots - qtop * dt + ArMpSs * (nraidt+nird+Melt)*dt + QMpLatSs
         if (abs(deviat) > CritDevPondDt) then
            flnonconv3 = .TRUE.
            flnonconv  = .TRUE.
         end if
      end if
      if (swmacro == 1 .AND. fldecMPmbf) then
         flnonconv = .TRUE.
      end if
      

      end if

      if (dabs(sum1) > CritDevBalTot) flnonconv = .TRUE.

      call diag_log(4)
!     save sump voor next iteration
      sumold = sump

      if (.NOT.flnonconv) then      ! convergence has been reached
     
         call outcome(0,numbit,flnonconv,any(flnonconv1(1:NN)),any(flnonconv2(1:NN)),flnonconv3,fldecMPmbf,sum1,maxval(abs(F(1:NN))),maxloc(abs(F(1:NN)),dim=1))
   call unreduced_trace(0)
!        special case for macropores
         if (swmacro == 1) then
            FlDecMpRat = .FALSE.
            if (IDecMpRat > 0) then
               if (NStep < 10) then
                  NStep = NStep + 1
               end if
               if (dt > dtold .OR. NStep >= 10) then
                  dtold = dt
                  NStep = 0
                  IDecMpRat = IDecMpRat - 1
               end if
            end if
         end if

!        special case swbotb = 1
         if (swbotb == 1 .AND. (.NOT.fllowgwl)) then
!           derive vertical flux profile in order to find qbot as a lower boundary condition for the saturated part of the soil system
            qv(1) = qtop
            do i = NN+1, numnod
               theta(i) = cofgen(2,i)
            end do
            do i = 1, numnod
              qv(i+1) = qv(i) + dz(i)*FrArMtrx(i)*(theta(i)-thetm1(i)) / dt + sink(i) - source(i) + qrot(i)
            end do
            qbot = qv(numnod+1)
!           h in saturated zone
            do i = NN+1, numnod
               h(i) = h(i-1) + disnod(i)*(qv(i)/kmean(i) + 1.0d0)
            end do
         end if
   
!        calculate new groundwater level
         !call calcgwl () replaced to call soilwater(3)

!        recording of number of iteration steps needed
         itnumb(min(100,numbit),1) = itnumb(min(100,numbit),1) + 1 
         itnumb(min(100,numbit),2) = itnumb(min(100,numbit),2) + iBackTr 

         if(diag_active) close(diag_u)

         return
      end if
   ! end do numbit = 1, MaxIt1
   end do

   call outcome(4,numbit,flnonconv,any(flnonconv1(1:NN)),any(flnonconv2(1:NN)),flnonconv3,fldecMPmbf,sum1,maxval(abs(F(1:NN))),maxloc(abs(F(1:NN)),dim=1))
   call unreduced_trace(4)
!  Convergence could not been reached
   if (.NOT.fldtmin) then

!     reset soil state variables
      do j = 1, numnod
         h(j)     = hm1(j)
         theta(j) = thetm1(j)
      end do
      kmean(numnod+1) = k(numnod)
      gwl             = gwlm1
      pond            = pondm1

!     reset and continue iteration with smaller timestep!
      fldecdt = .TRUE.

      if(diag_active) close(diag_u)

      return
   else if (swmacro == 1 .AND. IDecMpRat < 3) then
!     in case of macropores, retry with reduction of exchange fluxes with matrix
      IDecMpRat  = IDecMpRat + 1
      FlDecMpRat = .TRUE.
      dtold      = dt
      fldtmin    = .FALSE.

      if(diag_active) close(diag_u)

      return
   else
!     write warning to screen and log file
      if (flwarn) then
         iwarn = iwarn + 1
         call dtdpst('year-month-day,hour:minute:seconds',t1900,datetime)
         write(cval,'(I10)') i_instance
         message = cval//' No convergence was reached of Richards equation at '//datetime//' no more than 4 warnings per date - SWAP did continue!'
         call swap_warning ('headcalc', message)
         if (iwarn > 3) flwarn = .FALSE.  
      end if

!     continue without convergence !!!
      if(diag_active) close(diag_u)
      return
   end if

   if(diag_active) close(diag_u)
contains

subroutine diag_log(stage)
 use MOD_grid, only:layer
 use MOD_macropore, only:NumDm,FlEndSrpEvt,ICpTpSatZon,ICpTpPerZon,ICpBtPerZon, &
 QOutMtxUnsDmCp,QOutMtxSatDmCp,QInMtxSatDmCp,QInIntSatDmCp,FrMpWalWet,TimAbsCumDmCp
 integer,intent(in)::stage
 call node20_log(stage)
 call node35_log(stage)
 if(.not.diag_active) return
 write(diag_u,*) stage,numbit,itry,factor,maxval(abs(F(1:NN))),sum(F(1:NN)), &
 .5d0*dot_product(F(1:NN),F(1:NN)),sumold,merge(1,0,flunsatok(3)), &
 h(45),QExcMpMtx(45),F(45),dFdhMp(45),cofgen(9,layer(45)), &
 count(FlEndSrpEvt(1:NumDm,45)),ICpTpSatZon,ICpTpPerZon,ICpBtPerZon, &
 maxval(abs(h(1:NN)-hold(1:NN))),maxval(abs(difh(1:NN))), &
 merge(1,0,flnonconv),merge(1,0,flnonconv3),merge(1,0,fldecMPmbf), &
 count(flnonconv1(1:NN)),count(flnonconv2(1:NN)),sum(QOutMtxUnsDmCp(1:NumDm,45)), &
 sum(QOutMtxSatDmCp(1:NumDm,45)),sum(QInMtxSatDmCp(1:NumDm,45)), &
 sum(QInIntSatDmCp(1:NumDm,45)),sum(FrMpWalWet(1:NumDm,45)),maxval(TimAbsCumDmCp(1:NumDm,45))
end subroutine diag_log

subroutine node20_log(stage)
integer,intent(in)::stage
integer::tr,ff(5)
real(8)::fac,hh,dh,jl,jm,ju,mpd
if(.not.detail33) return
! DTMIN57 observer only: log existing arrays after the actual vector evaluation.
if(stage==3) then
 block
  integer :: u57
  open(newunit=u57,file='dtmin57_trials.txt',status='unknown',position='append',action='write')
  write(u57,*) attempts,iter_index,itry,NN,merge(1,0,fldtmin),MaxIt,factor,sumold,sump,Fmax,dt
  write(u57,*) hold(1:NN)
  write(u57,*) difh(1:NN)
  write(u57,*) h(1:NN)
  close(u57)
 end block
end if
tr=0;fac=0;hh=h(47);dh=0;ff=0;jl=0;jm=0;ju=0;mpd=0
if(stage/=0) then
 hh=hold(47)
 if(stage==3.or.stage==4.or.stage==5.or.stage==6) then
  tr=itry;fac=factor;dh=difh(47)
 end if
end if
if(stage==2) then
 jl=dFdhU(47);jm=dFdhM(47);ju=dFdhL(47);mpd=dFdhMp(47)
end if
if(stage==4) ff=[merge(1,0,flnonconv),merge(1,0,flnonconv1(47)),merge(1,0,flnonconv2(47)),merge(1,0,flnonconv3),merge(1,0,fldecMPmbf)]
write(node_u,*) attempts,iter_index,stage,tr,t1900,dt,IDecMpRat,fac,h(46:48),hh,dh,F(47), &
 sum(F(1:NN)),maxval(abs(F(1:NN))),.5d0*dot_product(F(1:NN),F(1:NN)),sumold, &
 merge(1,0,flunsatok(3)),ff,jl,jm,ju,mpd
end subroutine node20_log

subroutine node20_operator(task,grad)
use MOD_macropore,only:NumDm,QExcMtxDmCp,QOutMtxUnsDmCp,QOutMtxSatDmCp,QInMtxSatDmCp,QInIntSatDmCp, &
 FrMpWalWet,TimAbsCumDmCp,FlEndSrpEvt,FrReduQ,ICpTpWaSrDm,ZWaLevDm
integer,intent(in)::task
real(8),intent(in)::grad(macp+1)
if(.not.detail33) return
write(op_u,*) attempts,iter_index,nvec,task,t1900,dt,h(46:48),theta(47),thetm1(47),FrArMtrx(47),dz(47), &
 (theta(47)-thetm1(47))*FrArMtrx(47)*dz(47)/dt,sink(47),-source(47),qrot(47), &
 -kmean(47)*grad(47),kmean(48)*grad(48),-QExcMpMtx(47),F(47),merge(1,0,flunsatok(3)), &
 FrReduQ,QExcMtxDmCp(1:NumDm,47),QOutMtxUnsDmCp(1:NumDm,47),QOutMtxSatDmCp(1:NumDm,47), &
 QInMtxSatDmCp(1:NumDm,47),QInIntSatDmCp(1:NumDm,47),FrMpWalWet(1:NumDm,47), &
 TimAbsCumDmCp(1:NumDm,47),merge(1,0,FlEndSrpEvt(1:NumDm,47)),ICpTpWaSrDm(1:NumDm),ZWaLevDm(1:NumDm)
end subroutine node20_operator

subroutine node35_log(stage)
integer,intent(in)::stage
integer::ic,fc,fh
real(8)::hl,step,jl,jm,ju,mpd
if(.not.detail33) return
do ic=44,57
 hl=h(ic);step=0d0;jl=0d0;jm=0d0;ju=0d0;mpd=0d0;fc=0;fh=0
 if(stage/=0) hl=hold(ic)
 if(stage==3.or.stage==4.or.stage==5.or.stage==6) step=difh(ic)
 if(stage==2) then
  jl=dFdhU(ic);jm=dFdhM(ic);ju=dFdhL(ic);mpd=dFdhMp(ic)
 end if
 if(stage==4) then
  fc=merge(1,0,flnonconv1(ic));fh=merge(1,0,flnonconv2(ic))
 end if
 write(node35_u,*) attempts,iter_index,stage,nvec,ic,h(ic),hl,step,F(ic),jl,jm,ju,mpd,fc,fh
end do
end subroutine

subroutine node35_operator(task,grad)
use MOD_macropore,only:NumDm,QExcMtxDmCp,QOutMtxUnsDmCp,QOutMtxSatDmCp,QInMtxSatDmCp,QInIntSatDmCp,FrReduQ
integer,intent(in)::task
real(8),intent(in)::grad(macp+1)
integer::ic
if(.not.detail33) return
do ic=44,57
 write(op35_u,*) attempts,iter_index,nvec,task,t1900,dt,ic,h(ic),theta(ic),thetm1(ic),F(ic), &
  (theta(ic)-thetm1(ic))*FrArMtrx(ic)*dz(ic)/dt,sink(ic),-source(ic),qrot(ic), &
  -kmean(ic)*grad(ic),kmean(ic+1)*grad(ic+1),-QExcMpMtx(ic),FrReduQ, &
  QExcMtxDmCp(1:NumDm,ic),QOutMtxUnsDmCp(1:NumDm,ic),QOutMtxSatDmCp(1:NumDm,ic), &
  QInMtxSatDmCp(1:NumDm,ic),QInIntSatDmCp(1:NumDm,ic)
end do
end subroutine

subroutine unreduced_trace(kind)
 use MOD_macropore, only:FrReduQ
 integer,intent(in) :: kind
 integer :: u
 integer,save :: counter=0
 logical :: active
 character(40) :: name
 inquire(file='active.marker',exist=active)
 if(detail33) active=.true.
 if(.not.active) return
 counter=counter+1
 write(name,'(a,i0,a)') 'solver_',counter,'.txt'
 open(newunit=u,file=trim(name),status='replace')
 write(u,*) 'outcome',kind,numbit,FrReduQ

 write(u,*) 'controls',t1900,dt,IDecMpRat,NN,numnod,CritDevBalCp,CritDevBalTot,CritDevPondDt
 write(u,*) 'residual',F(1:NN)
 write(u,*) 'sink',sink(1:NN)
 write(u,*) 'source',source(1:NN)
 write(u,*) 'qroot',qrot(1:NN)
 write(u,*) 'qexchange',QExcMpMtx(1:NN)
 write(u,*) 'kmean',kmean(1:NN+1)
 write(u,*) 'hgrad',hgrad(1:NN+1)
 write(u,*) 'h',h(1:NN)
 write(u,*) 'theta',theta(1:NN)
 write(u,*) 'thetm1',thetm1(1:NN)
 write(u,*) 'fraction',FrArMtrx(1:NN)
 write(u,*) 'dz',dz(1:NN)
 write(u,*) 'boundary',qtop,qbot,hsurf,merge(1,0,ftoph),pond,pondm1
 close(u)
end subroutine unreduced_trace

!----------------------------------------------------------------------------------
! Alternative solution procedure in the rare case that TRIDAG failed.
!
! From Numerical Recipes, section 2.4:
! There is no pivoting in TRIDAG. It is for this reason that TRIDAG can fail
! (pause) even when the underlying matrix is nonsingular. In that case, 
! you can instead use the more general method for band diagonal systems,
! by using routines bandec and banbks, as is implemented here.
!----------------------------------------------------------------------------------
   subroutine alternative_solver()
   ! local
   integer                    :: i
   integer, dimension(macp)   :: indx
   real(8), dimension(macp,3) :: a 
   real(8), dimension(macp,1) :: a1
   real(8), dimension(macp)   :: b
   real(8)                    :: d

   do i = 1, NN
      a(i,1) = dFdhU(i)
      a(i,2) = dFdhM(i)
      a(i,3) = dFdhL(i)
   end do
   call bandec(a, NN, 1, 1, macp, 3, a1, 1, indx, d)
   b(1:NN) = F(1:NN)
   call banbks(a,nn,1,1,macp,3,a1,1,indx,b)
   difh(1:NN) = b(1:NN)
   return
   end subroutine alternative_solver

!----------------------------------------------------------------------------------
! Function F: calculate right-hand-side vector F
!----------------------------------------------------------------------------------
subroutine vector_F(iTask, hgrad)
!  global
   integer, intent(in)        :: iTask
   real(8), dimension(macp+1) :: hgrad
!  local
!  functions
   real(8)                    :: afgen

!  top layer
   F(1) = (theta(1) - thetm1(1)) * FrArMtrx(1) * dz(1) / dt + sink(1) - source(1) + qrot(1) + kmean(2) * hgrad(2)

!  depending on iTask
   if (iTask == 2 .AND. swmacro == 1) QMpLatSsSav = QMpLatSs

!  take care of top BC
   call boundtop(2)

!  depending on iTask
   if (swmacro == 1) then
      if (iTask == 1 .OR. .NOT. flunsatok(3)) then 
         nrate=nrate+1
         call MACROPORE(2)
      else
         QMpLatSs = QMpLatSsSav
      end if
   end if

!  take care of top BC: ponding, runoff
   if (FlRunoff .OR. ArMpSs > 0.0d0) call pondrunoff ()

!  first layer, continued
   if (ftoph) then
      hgrad(1) = (hsurf-h(1))/disnod(1) + 1.d0
      F(1)     = F(1) - kmean(1) * hgrad(1)
   else
      F(1) = F(1) + qtop
   end if

!  layers 2 to (NN-1)
   do i = 2, NN-1
      F(i) = (theta(i) - thetm1(i)) * FrArMtrx(i) * dz(i) / dt + sink(i) - source(i) + qrot(i) - kmean(i) * hgrad(i) + kmean(i+1) * hgrad(i+1)
   end do

!  for bottom BC
   if (swbotb == 1 .AND. (.NOT.fllowgwl)) then
      hgrad(NN+1) = h(NN)/(z(nn)-gwlinp) + 1.0d0
   else if (swbotb == 5 .OR. (swbotb == 1 .AND. fllowgwl)) then
      hgrad(NN+1) = (h(NN) - hbot) / disnod(NN+1) + 1.0d0
   else if (swbotb == 9) then
      hgrad(NN+1) = (h(NN) - h(NN+1)) / disnod(NN+1) + 1.0d0
   end if

!  for swbotb = 8, depending on iTask
   if (iTask == 1) then
      if (swbotb == 8 .AND. h(NN) >  Critdz - disnod(NN+1) + hplate) then
         hgrad(NN+1) = (h(NN) - hplate) / disnod(NN+1) + 1.0d0
         flboth = .TRUE.
      else
         flboth = .FALSE.
      end if
   else
      if (swbotb == 8 .AND. flboth) then
         hgrad(NN+1) = (h(NN) - hplate) / disnod(NN+1) + 1.0d0
      end if
   end if

   ! for bottom BC, continued
   if (swbotb == 1 .AND. (.NOT.fllowgwl)) then
      theta(NN) = watcon(NN,h(NN))
      k(NN)     = hconduc(NN,h(NN),theta(NN),rfcp(NN))
      ! in case of static macropores FrArMtrx < 1
      if (swmacro == 1) k(NN) = FrArMtrx(NN) * k(NN)
      kmean(NN+1) = hcomean(swkmean, k(NN), cofgen(3,(NN+1)), dz(NN), dz(NN+1), NN, h(NN), 0.0d0)
      F(NN)       = (theta(NN) - thetm1(NN))*FrArMtrx(NN)*dz(NN)/dt - kmean(NN) * hgrad(NN) + kmean(NN+1) * hgrad(NN+1) + sink(NN) - source(NN) + qrot(NN)
   else
      F(NN) = (theta(NN) - thetm1(NN))*FrArMtrx(NN)*dz(NN)/dt - kmean(NN) * hgrad(NN) + sink(NN) - source(NN) + qrot(NN) 
      if (swbotb == 3 .AND. swbotb3Impl == 1) then
         
         ! Cauchy-relation, implemented as head boundary
         if (SwBotb3ResVert == 0) then
            qbot = - (h(NN)+z(NN)-deepgw) / (disnod(NN+1)/kmean(NN+1)+rimlay)
         else if (SwBotb3ResVert == 1) then
            qbot = - (h(NN)+z(NN)-deepgw) / rimlay
         end if
         
         ! extra groundwater flux might be added
         if (sw4 == 1) qbot = qbot + afgen(qbotab,mabbc*2,t1900+dt)
         F(NN) = F(NN) - qbot     
      
      else if (swbotb == 5 .OR. (swbotb == 1 .AND. fllowgwl)) then
         
         ! pressure head at lower boundary specified
         F(NN) = F(NN) + kmean(NN+1) * hgrad(NN+1)

      else if (swbotb == 9) then
         
         ! pressure head at lower boundary specified
         F(NN) = F(NN) + kmean(NN+1) * hgrad(NN+1)
         !!!F(NN) = F(NN) - qbot
      
      else if (swbotb == 7 .OR. swbotb == -2) then 
         
         ! free drainage option
         kmean(numnod+1) = hconduc(numnod,h(numnod),theta(numnod),rfcp(numnod))
         if (swmacro == 1) kmean(numnod+1) = FrArMtrx(numnod) * kmean(numnod+1)
         qbot = -1.0d0 * kmean(numnod+1)
         F(NN) = F(NN) - qbot
      
      else if (swbotb == 8) then                                  
         
         ! lysimeter option
         if (flboth) then
            hbot = hplate
            F(NN) = F(NN) + kmean(NN+1) * hgrad(NN+1)
         else
            qbot = 0.0d0
         end if
      
      else
         
          ! flux bottom boundary
         F(NN) = F(NN) - qbot
      
      end if

   end if

   if (swmacro == 1) F(1:NN) = F(1:NN) - QExcMpMtx(1:NN)

call node20_operator(iTask,hgrad)
call node35_operator(iTask,hgrad)
end subroutine vector_F

subroutine jacobian_F()

!  first layer
   dFdhM(1) = dimoca(1)*FrArMtrx(1)*dz(1)/dt - dFdhL(1)
 
!  if the head boundary condition applies: add the k1/(0.5*dz1) term to the first element of the main diagonal 
   if (ftoph) dFdhM(1) = dFdhM(1) + kmean(1)/disnod(1)  

!  layers 2 to (NN-1)
   do i = 2, NN-1
      dFdhM(i) = dimoca(i)*FrArMtrx(i)*dz(i)/dt - dFdhU(i) - dFdhL(i) 
   end do

!  last layer: handle bottom BC
   dFdhM(NN) = dimoca(NN)*FrArMtrx(NN)*dz(NN)/dt - dFdhU(NN) 
   if (swbotb == 1 .AND. (.NOT.fllowgwl)) then
      dFdhM(NN) = dFdhM(NN) + kmean(NN+1)/(z(NN)-gwlinp) 
   else if (swbotb == 3 .AND. swbotb3Impl == 1) then ! Cauchy
      if (SwBotb3ResVert == 0) then
         dFdhM(NN) = dFdhM(NN) + 1.0d0 / (disnod(NN+1)/kmean(NN+1) + rimlay)   
      else if (SwBotb3ResVert == 1) then
         dFdhM(NN) = dFdhM(NN) + 1.0d0 / rimlay
      end if
   else if (swbotb == 5 .OR. (swbotb == 1 .AND. fllowgwl) .OR. swbotb == 9) then
      dFdhM(NN) = dFdhM(NN) + kmean(NN+1)/disnod(NN+1)         
   else if (swbotb == 7 .OR. swbotb == -2) then ! implicitly: kmean(NN+1)
      dFdhM(NN) = dFdhM(NN) + dkdh(NN) * 0.5d0
   else if (swbotb == 8 .AND. flboth) then
      dFdhM(NN) = dFdhM(NN) + kmean(NN+1)/disnod(NN+1)
   end if

!  special case when SwKimpl = 1
   if (SwKimpl == 1) then
      if (swbotb == 9) call swap_error ('headcalc', 'swbotb = 9 AND swkimpl = 1 not yet implemented')
!     first layer
      dFdhM(1) = dFdhM(1) + dkdh(1) * hgrad(2) * dkmean(swkmean,k(1),k(2),dz(1),dz(2))
      if (ftoph) dFdhM(1) = dFdhM(1) - dkdh(1) * hgrad(1) * 0.5d0
      dFdhL(1) = dFdhL(1) + dkdh(2) * hgrad(2) * dkmean(swkmean,k(2),k(1),dz(2),dz(1)) 
!     layers 2 to (NN-1)
      do i = 2, NN-1
         dFdhU(i) = dFdhU(i) - dkdh(i-1) * hgrad(i) * dkmean(swkmean,k(i-1),k(i),dz(i-1),dz(i)) 
         dFdhM(i) = dFdhM(i) - dkdh(i) * hgrad(i) * dkmean(swkmean,k(i),k(i-1),dz(i),dz(i-1)) + dkdh(i) * hgrad(i+1) * dkmean(swkmean,k(i),k(i+1),dz(i),dz(i+1))
         dFdhL(i) = dFdhL(i) + dkdh(i+1) * hgrad(i+1) * dkmean(swkmean,k(i+1),k(i),dz(i+1),dz(i)) 
      end do
!     last layer
      dFdhU(NN) = dFdhU(NN) - dkdh(NN-1) * hgrad(NN) * dkmean(swkmean,k(NN-1),k(NN),dz(NN-1),dz(NN)) 
      dFdhM(NN) = dFdhM(NN) - dkdh(NN) * hgrad(NN) * dkmean(swkmean,k(NN),k(NN-1),dz(NN),dz(NN-1))

      if (swbotb == 1 .OR. swbotb == 5 .OR. swbotb == 8 .AND. flboth) then
         dFdhM(NN) = dFdhM(NN) + 0.5d0 * dkdh(NN) * hgrad(NN+1)
      end if
   end if

!  special case macropore
   if (swmacro == 1 .AND. .NOT.flunsatok(3)) then
      nderiv=nderiv+1
      call MACROPORE(3)
      dFdhM(1:NN) = dFdhM(1:NN) - dFdhMp(1:NN)
   end if

end subroutine jacobian_F


      function dkmean(swkmean,kmain,ksub,dzmain,dzsub)
!     d(hcomean)/d(kmain); note kmain = kup in hcomean and ksub = klow in hcomean; dzmain = dzup in hcomena, and dzub = dzlow in hcomean
      implicit none
      ! global
      integer, intent(in)  :: swkmean
      real(8), intent(in)  :: kmain, ksub, dzmain, dzsub
      real(8)              :: dkmean
      ! local
      real(8)              :: a

      if (swkmean == 1) then
         dkmean = 0.5d0
      else if (swkmean == 2) then
         dkmean = dzmain/(dzmain+dzsub)
      else if (swkmean == 3) then
         dkmean = 0.5d0 * dsqrt(ksub / kmain)
      else if (swkmean == 4) then
         a = dzmain/(dzmain+dzsub)
         dkmean = a * (ksub / kmain) ** (1.0d0 - a)
      else if (swkmean == 5) then
         dkmean = 0.5d0/(((0.5d0/kmain)+(0.5d0/ksub))**2 * kmain**2)
      else if (swkmean == 6) then
         a = dzmain/(dzmain+dzsub)
         dkmean = a/(((a/kmain)+((1.0d0-a)/ksub))**2 * kmain**2)
      end if
      return
      end function dkmean

end subroutine headcalc


subroutine cause66_boundary(stage)
 use variables,only:t1900,dt,deepgw,qbot,hbot,gwlinp,rimlay,swbotb,swbotb3impl,swbotb3resvert,sw3,sw4,haqtab,h,kmean
 use MOD_arrays,only:mabbc
 use MOD_grid,only:numnod,z,disnod
 use DIAG19,only:attempts
 implicit none
 integer,intent(in)::stage
 integer::u,st
 character(24)::mode
 real(8)::afgen,before,endpoint
 before=deepgw;endpoint=t1900+dt
 call get_environment_variable('CAUSE66_ENDPOINT',mode,status=st)
 if(st/=0) mode='NONE'
 if(abs(t1900-35797.290431125148d0)>1d-10.or.swbotb/=3.or.swbotb3impl/=1.or.sw3/=2.or.sw4/=0) &
    error stop 'CAUSE66 outside preregistered boundary context'
 if(stage==0) then
  select case(trim(mode))
  case('NONE')
  case('SMALL')
   if(attempts>1) deepgw=afgen(haqtab,mabbc*2,t1900+dt)
  case('LARGE')
   if(attempts==1.and.dt==1d-5) then
    endpoint=t1900+2.0951312035156963d-5
    deepgw=afgen(haqtab,mabbc*2,endpoint)
   end if
  case default
   error stop 'CAUSE66 unselected intervention'
  end select
 end if
 open(newunit=u,file='cause66_boundary.txt',position='append',status='unknown')
 write(u,*) attempts,stage,t1900,dt,endpoint,before,deepgw,qbot,hbot,gwlinp,rimlay, &
   swbotb,swbotb3impl,swbotb3resvert,sw3,sw4,h(numnod),z(numnod),disnod(numnod+1),kmean(numnod+1)
 close(u)
end subroutine cause66_boundary
